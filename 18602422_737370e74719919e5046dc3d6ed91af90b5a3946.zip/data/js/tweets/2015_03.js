Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Electronic Intifada",
      "screen_name" : "intifada",
      "indices" : [ 108, 117 ],
      "id_str" : "6721522",
      "id" : 6721522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AYlFDR1PUW",
      "expanded_url" : "http:\/\/electronicintifada.net\/blogs\/ali-abunimah\/univ-southampton-cancels-conference-after-government-israel-lobby-pressure",
      "display_url" : "electronicintifada.net\/blogs\/ali-abun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583008569831866368",
  "text" : "Univ. of Southampton cancels conference after government, Israel lobby pressure  http:\/\/t.co\/AYlFDR1PUW via @intifada",
  "id" : 583008569831866368,
  "created_at" : "2015-03-31 20:50:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582995343819702272",
  "geo" : { },
  "id_str" : "582995653027987457",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl  or untrustworthy? ;)",
  "id" : 582995653027987457,
  "in_reply_to_status_id" : 582995343819702272,
  "created_at" : "2015-03-31 19:59:29 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google OS",
      "screen_name" : "googleos",
      "indices" : [ 55, 64 ],
      "id_str" : "7882062",
      "id" : 7882062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/OgOz6GyauB",
      "expanded_url" : "http:\/\/googlesystem.blogspot.com\/2015\/03\/play-pac-man-in-google-maps.html",
      "display_url" : "googlesystem.blogspot.com\/2015\/03\/play-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582994397135908864",
  "text" : "Play Pac-Man in Google Maps http:\/\/t.co\/OgOz6GyauB via @googleos",
  "id" : 582994397135908864,
  "created_at" : "2015-03-31 19:54:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google OS",
      "screen_name" : "googleos",
      "indices" : [ 59, 68 ],
      "id_str" : "7882062",
      "id" : 7882062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/Dor7BSEmed",
      "expanded_url" : "http:\/\/googlesystem.blogspot.com\/2015\/03\/chrome-selfie-share-reaction.html",
      "display_url" : "googlesystem.blogspot.com\/2015\/03\/chrome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582959472160718849",
  "text" : "Chrome Selfie: Share a Reaction http:\/\/t.co\/Dor7BSEmed via @googleos",
  "id" : 582959472160718849,
  "created_at" : "2015-03-31 17:35:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/O9C2mSXt94",
      "expanded_url" : "http:\/\/www.reelapp.com\/970fcc#1",
      "display_url" : "reelapp.com\/970fcc#1"
    } ]
  },
  "in_reply_to_status_id_str" : "582807400102686720",
  "geo" : { },
  "id_str" : "582880474919485440",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves i don't think this saw light of day http:\/\/t.co\/O9C2mSXt94 no wait..uh oh.. :)",
  "id" : 582880474919485440,
  "in_reply_to_status_id" : 582807400102686720,
  "created_at" : "2015-03-31 12:21:49 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 0, 11 ],
      "id_str" : "14548913",
      "id" : 14548913
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 12, 23 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/DJNJxaNlmB",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/corrective-feedback",
      "display_url" : "indiegogo.com\/projects\/corre\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "582871241259917312",
  "geo" : { },
  "id_str" : "582875274527809536",
  "in_reply_to_user_id" : 14548913,
  "text" : "@NikPeachey @JenMac_ESL possibility to help out this project by crowdfunding https:\/\/t.co\/DJNJxaNlmB",
  "id" : 582875274527809536,
  "in_reply_to_status_id" : 582871241259917312,
  "created_at" : "2015-03-31 12:01:09 +0000",
  "in_reply_to_screen_name" : "NikPeachey",
  "in_reply_to_user_id_str" : "14548913",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 17, 28 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582871231088594944",
  "geo" : { },
  "id_str" : "582872978284789760",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @lexicoloco pretty snazzy search features ngram has now",
  "id" : 582872978284789760,
  "in_reply_to_status_id" : 582871231088594944,
  "created_at" : "2015-03-31 11:52:01 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/Wd7l7PmPkB",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=*_DET+historic+&year_start=1800&year_end=2000&corpus=15&smoothing=3&share=&direct_url=t2%3B%2C*_DET%20historic%3B%2Cc0%3B%2Cs0%3B%3Bthe_DET%20historic%3B%2Cc0%3B%3Ba_DET%20historic%3B%2Cc0%3B%3Ban_DET%20historic%3B%2Cc0%3B%3Bthis_DET%20historic%3B%2Cc0%3B%3BThe_DET%20historic%3B%2Cc0%3B%3Bthat_DET%20historic%3B%2Cc0%3B%3Bthese_DET%20historic%3B%2Cc0%3B%3Bsome_DET%20historic%3B%2Cc0%3B%3BThis_DET%20historic%3B%2Cc0%3B%3Bno_DET%20historic%3B%2Cc0",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "582869156195893248",
  "geo" : { },
  "id_str" : "582869963729461249",
  "in_reply_to_user_id" : 18602422,
  "text" : "@lexicoloco determiner historic https:\/\/t.co\/Wd7l7PmPkB",
  "id" : 582869963729461249,
  "in_reply_to_status_id" : 582869156195893248,
  "created_at" : "2015-03-31 11:40:03 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/ubRsuCuIP7",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=a+historic+*%2Can+historic+*&year_start=1800&year_end=2000&corpus=15&smoothing=3&share=&direct_url=t2%3B%2Ca%20historic%20*%3B%2Cc0%3B%2Cs0%3B%3Ba%20historic%20fact%3B%2Cc0%3B%3Ba%20historic%20event%3B%2Cc0%3B%3Ba%20historic%20and%3B%2Cc0%3B%3Ba%20historic%20moment%3B%2Cc0%3B%3Ba%20historic%20occasion%3B%2Cc0%3B%3Ba%20historic%20interest%3B%2Cc0%3B%3Ba%20historic%20site%3B%2Cc0%3B%3Ba%20historic%20document%3B%2Cc0%3B%3Ba%20historic%20landmark%3B%2Cc0%3B%3Ba%20historic%20building%3B%2Cc0%3B.t2%3B%2Can%20historic%20*%3B%2Cc0%3B%2Cs0%3B%3Ban%20historic%20fact%3B%2Cc0%3B%3Ban%20historic%20event%3B%2Cc0%3B%3Ban%20historic%20occasion%3B%2Cc0%3B%3Ban%20historic%20interest%3B%2Cc0%3B%3Ban%20historic%20and%3B%2Cc0%3B%3Ban%20historic%20name%3B%2Cc0%3B%3Ban%20historic%20character%3B%2Cc0%3B%3Ban%20historic%20moment%3B%2Cc0%3B%3Ban%20historic%20document%3B%2Cc0%3B%3Ban%20historic%20past%3B%2Cc0",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "582866610735751168",
  "geo" : { },
  "id_str" : "582869156195893248",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco very! was curious to see what follows https:\/\/t.co\/ubRsuCuIP7",
  "id" : 582869156195893248,
  "in_reply_to_status_id" : 582866610735751168,
  "created_at" : "2015-03-31 11:36:50 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Lebedev",
      "screen_name" : "JLebedev_ESL",
      "indices" : [ 104, 117 ],
      "id_str" : "3033094945",
      "id" : 3033094945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/59HtjBrnXI",
      "expanded_url" : "http:\/\/wp.me\/pjaNC-1cD",
      "display_url" : "wp.me\/pjaNC-1cD"
    } ]
  },
  "geo" : { },
  "id_str" : "582864267856244737",
  "text" : "TESOL 2015: Supporting and Developing Academic Writing with Corpus Resources http:\/\/t.co\/59HtjBrnXI via @JLebedev_ESL",
  "id" : 582864267856244737,
  "created_at" : "2015-03-31 11:17:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "indices" : [ 3, 15 ],
      "id_str" : "3112144043",
      "id" : 3112144043
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/582845602297487360\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/gSuR7XuGMl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBau-65UMAAeqQa.png",
      "id_str" : "582845597775835136",
      "id" : 582845597775835136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBau-65UMAAeqQa.png",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1211,
        "resize" : "fit",
        "w" : 1654
      } ],
      "display_url" : "pic.twitter.com\/gSuR7XuGMl"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "ESL",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582856389619482624",
  "text" : "RT @bee_visible: #ELT and #ESL teachers! Do you have a story to tell? http:\/\/t.co\/gSuR7XuGMl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/582845602297487360\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/gSuR7XuGMl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBau-65UMAAeqQa.png",
        "id_str" : "582845597775835136",
        "id" : 582845597775835136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBau-65UMAAeqQa.png",
        "sizes" : [ {
          "h" : 439,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1211,
          "resize" : "fit",
          "w" : 1654
        } ],
        "display_url" : "pic.twitter.com\/gSuR7XuGMl"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 9, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582845602297487360",
    "text" : "#ELT and #ESL teachers! Do you have a story to tell? http:\/\/t.co\/gSuR7XuGMl",
    "id" : 582845602297487360,
    "created_at" : "2015-03-31 10:03:14 +0000",
    "user" : {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "protected" : false,
      "id_str" : "3112144043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629055941850320901\/kumvict0_normal.png",
      "id" : 3112144043,
      "verified" : false
    }
  },
  "id" : 582856389619482624,
  "created_at" : "2015-03-31 10:46:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582805371493969920",
  "geo" : { },
  "id_str" : "582828653974806528",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves good point though my corpus analysis leaves a lot to be desired :\/",
  "id" : 582828653974806528,
  "in_reply_to_status_id" : 582805371493969920,
  "created_at" : "2015-03-31 08:55:54 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582807400102686720",
  "geo" : { },
  "id_str" : "582827079189704705",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves ha though fengshui could have something to it :)",
  "id" : 582827079189704705,
  "in_reply_to_status_id" : 582807400102686720,
  "created_at" : "2015-03-31 08:49:38 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582818216004620288",
  "geo" : { },
  "id_str" : "582826651253358592",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike there's also issue of small \"errors\" adding up to result in unintelligibility",
  "id" : 582826651253358592,
  "in_reply_to_status_id" : 582818216004620288,
  "created_at" : "2015-03-31 08:47:56 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Q5VMnGVOkh",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/03\/shadow-reading-experiment.html",
      "display_url" : "how-i-see-it-now.blogspot.com\/2015\/03\/shadow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582794971004170240",
  "text" : "RT @HanaTicha: My Shadow-reading experiment http:\/\/t.co\/Q5VMnGVOkh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/Q5VMnGVOkh",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/03\/shadow-reading-experiment.html",
        "display_url" : "how-i-see-it-now.blogspot.com\/2015\/03\/shadow\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "582772570358988800",
    "text" : "My Shadow-reading experiment http:\/\/t.co\/Q5VMnGVOkh",
    "id" : 582772570358988800,
    "created_at" : "2015-03-31 05:13:02 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 582794971004170240,
  "created_at" : "2015-03-31 06:42:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 105, 113 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/mYjYquPL7b",
      "expanded_url" : "https:\/\/youtu.be\/aCREVmaRaeg",
      "display_url" : "youtu.be\/aCREVmaRaeg"
    } ]
  },
  "geo" : { },
  "id_str" : "582765170621059072",
  "text" : "Am I Mad Enough To Crash A Plane Into A Mountain? Russell Brand The Trew...: https:\/\/t.co\/mYjYquPL7b via @YouTube",
  "id" : 582765170621059072,
  "created_at" : "2015-03-31 04:43:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 122, 138 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/VPd3EoXxWt",
      "expanded_url" : "http:\/\/wp.me\/p4HLYW-bG",
      "display_url" : "wp.me\/p4HLYW-bG"
    } ]
  },
  "geo" : { },
  "id_str" : "582763842717003776",
  "text" : "TESOL Convention 2015: 'Building bridges between online corpora and grammar textbooks' by Ash\u2026 http:\/\/t.co\/VPd3EoXxWt via @MarekKiczkowiak",
  "id" : 582763842717003776,
  "created_at" : "2015-03-31 04:38:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/0Oc54qGZq3",
      "expanded_url" : "http:\/\/www.lextutor.ca\/freq\/comp\/zipf.html",
      "display_url" : "lextutor.ca\/freq\/comp\/zipf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582652582121893889",
  "text" : "Tom Cobb's neat demo of how Zipf's law about singletons does not mean no recycling in texts http:\/\/t.co\/0Oc54qGZq3 #corpuslinguistics",
  "id" : 582652582121893889,
  "created_at" : "2015-03-30 21:16:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "indices" : [ 116, 132 ],
      "id_str" : "117051544",
      "id" : 117051544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/7wpALfy3Qr",
      "expanded_url" : "http:\/\/cup.linguistlist.org\/journals\/does-the-socio-cultural-context-influence-the-way-chinese-people-write-business-english\/#.VRmrMEwTZ1A.twitter",
      "display_url" : "cup.linguistlist.org\/journals\/does-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582633350004867072",
  "text" : "Does the socio-cultural context influence the way Chinese people write business English? http:\/\/t.co\/7wpALfy3Qr via @cambUP_langling",
  "id" : 582633350004867072,
  "created_at" : "2015-03-30 19:59:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582619904442048512",
  "geo" : { },
  "id_str" : "582622457732956161",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves true though resource allocation is a sig consideration that will constrain any vision",
  "id" : 582622457732956161,
  "in_reply_to_status_id" : 582619904442048512,
  "created_at" : "2015-03-30 19:16:33 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 0, 11 ],
      "id_str" : "90695737",
      "id" : 90695737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582599192629153792",
  "in_reply_to_user_id" : 90695737,
  "text" : "@yvetteinmb oops sorry wrong tweet thx for blog share :)",
  "id" : 582599192629153792,
  "created_at" : "2015-03-30 17:44:06 +0000",
  "in_reply_to_screen_name" : "yvetteinmb",
  "in_reply_to_user_id_str" : "90695737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 0, 11 ],
      "id_str" : "90695737",
      "id" : 90695737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582597499971567616",
  "in_reply_to_user_id" : 90695737,
  "text" : "@yvetteinmb thanks for PHaVE dictionary share, welcome any feedback :)",
  "id" : 582597499971567616,
  "created_at" : "2015-03-30 17:37:22 +0000",
  "in_reply_to_screen_name" : "yvetteinmb",
  "in_reply_to_user_id_str" : "90695737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/aSwApr8H4N",
      "expanded_url" : "https:\/\/www.jacobinmag.com\/2015\/03\/education-technology-gates-erickson\/",
      "display_url" : "jacobinmag.com\/2015\/03\/educat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "582541086725406720",
  "geo" : { },
  "id_str" : "582597357394620416",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves amen brother, have u seen this other fine non-believer sermon? https:\/\/t.co\/aSwApr8H4N",
  "id" : 582597357394620416,
  "in_reply_to_status_id" : 582541086725406720,
  "created_at" : "2015-03-30 17:36:48 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitalrevolution",
      "indices" : [ 63, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5hIKX0edxZ",
      "expanded_url" : "http:\/\/bit.ly\/1G86SRa",
      "display_url" : "bit.ly\/1G86SRa"
    } ]
  },
  "geo" : { },
  "id_str" : "582525915701362688",
  "text" : "RT @tornhalves: Technology is religion. At the vanguard of the #digitalrevolution are the new evangelists. The atheist delusion. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "digitalrevolution",
        "indices" : [ 47, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/5hIKX0edxZ",
        "expanded_url" : "http:\/\/bit.ly\/1G86SRa",
        "display_url" : "bit.ly\/1G86SRa"
      } ]
    },
    "geo" : { },
    "id_str" : "582510450027446272",
    "text" : "Technology is religion. At the vanguard of the #digitalrevolution are the new evangelists. The atheist delusion. http:\/\/t.co\/5hIKX0edxZ",
    "id" : 582510450027446272,
    "created_at" : "2015-03-30 11:51:28 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 582525915701362688,
  "created_at" : "2015-03-30 12:52:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582505207441031168",
  "geo" : { },
  "id_str" : "582525810030059520",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE yes, wonder what u would find? thx for sharing :)",
  "id" : 582525810030059520,
  "in_reply_to_status_id" : 582505207441031168,
  "created_at" : "2015-03-30 12:52:30 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 3, 14 ],
      "id_str" : "327186537",
      "id" : 327186537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "auselt",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/YRbObIxdbj",
      "expanded_url" : "http:\/\/www.speechinaction.org\/blog\/",
      "display_url" : "speechinaction.org\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "582482711794860032",
  "text" : "RT @chimponobo: Some listening for thought on R. Cauldwell's blog #auselt http:\/\/t.co\/YRbObIxdbj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "auselt",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/YRbObIxdbj",
        "expanded_url" : "http:\/\/www.speechinaction.org\/blog\/",
        "display_url" : "speechinaction.org\/blog\/"
      } ]
    },
    "geo" : { },
    "id_str" : "582436629786198016",
    "text" : "Some listening for thought on R. Cauldwell's blog #auselt http:\/\/t.co\/YRbObIxdbj",
    "id" : 582436629786198016,
    "created_at" : "2015-03-30 06:58:08 +0000",
    "user" : {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "protected" : false,
      "id_str" : "327186537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703504370713780224\/Ffd779uj_normal.jpg",
      "id" : 327186537,
      "verified" : false
    }
  },
  "id" : 582482711794860032,
  "created_at" : "2015-03-30 10:01:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 69, 84 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/tcecTSvD8w",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1cI",
      "display_url" : "wp.me\/p3qkCB-1cI"
    } ]
  },
  "geo" : { },
  "id_str" : "582482443367804928",
  "text" : "Product or Process? Teachers or Learners? http:\/\/t.co\/tcecTSvD8w via @GeoffreyJordan",
  "id" : 582482443367804928,
  "created_at" : "2015-03-30 10:00:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Prepaid Economy",
      "screen_name" : "prepaid_africa",
      "indices" : [ 3, 18 ],
      "id_str" : "1153763124",
      "id" : 1153763124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/zBpOOANa6e",
      "expanded_url" : "http:\/\/ow.ly\/KWJqb",
      "display_url" : "ow.ly\/KWJqb"
    } ]
  },
  "geo" : { },
  "id_str" : "582394350375682048",
  "text" : "RT @prepaid_africa: Edutopia | Jacobin http:\/\/t.co\/zBpOOANa6e Education is not a design problem with a technical solution",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/zBpOOANa6e",
        "expanded_url" : "http:\/\/ow.ly\/KWJqb",
        "display_url" : "ow.ly\/KWJqb"
      } ]
    },
    "geo" : { },
    "id_str" : "582244825120010242",
    "text" : "Edutopia | Jacobin http:\/\/t.co\/zBpOOANa6e Education is not a design problem with a technical solution",
    "id" : 582244825120010242,
    "created_at" : "2015-03-29 18:15:58 +0000",
    "user" : {
      "name" : "The Prepaid Economy",
      "screen_name" : "prepaid_africa",
      "protected" : false,
      "id_str" : "1153763124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3391149470\/bb2906c4eb76a1a1d9e6d72f4b1dd295_normal.jpeg",
      "id" : 1153763124,
      "verified" : false
    }
  },
  "id" : 582394350375682048,
  "created_at" : "2015-03-30 04:10:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/n9TZuIRFn0",
      "expanded_url" : "http:\/\/tinyletter.com\/audreywatters\/letters\/hack-education-weekly-newsletter-no-104",
      "display_url" : "tinyletter.com\/audreywatters\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582386675717914624",
  "text" : "RT @audreywatters: Hack Education Weekly Newsletter, No. 104 http:\/\/t.co\/n9TZuIRFn0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/n9TZuIRFn0",
        "expanded_url" : "http:\/\/tinyletter.com\/audreywatters\/letters\/hack-education-weekly-newsletter-no-104",
        "display_url" : "tinyletter.com\/audreywatters\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "582038351089262592",
    "text" : "Hack Education Weekly Newsletter, No. 104 http:\/\/t.co\/n9TZuIRFn0",
    "id" : 582038351089262592,
    "created_at" : "2015-03-29 04:35:31 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 582386675717914624,
  "created_at" : "2015-03-30 03:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 3, 16 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/tWm07WgMLr",
      "expanded_url" : "http:\/\/www.glenys-hanson.info\/lesson-in-trust\/#.VRBwJpaWag4.twitter",
      "display_url" : "glenys-hanson.info\/lesson-in-trus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582262139517313024",
  "text" : "RT @GlenysHanson: What could be more weird than a language teacher who almost never speaks in class? http:\/\/t.co\/tWm07WgMLr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/tWm07WgMLr",
        "expanded_url" : "http:\/\/www.glenys-hanson.info\/lesson-in-trust\/#.VRBwJpaWag4.twitter",
        "display_url" : "glenys-hanson.info\/lesson-in-trus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580096333702381570",
    "text" : "What could be more weird than a language teacher who almost never speaks in class? http:\/\/t.co\/tWm07WgMLr",
    "id" : 580096333702381570,
    "created_at" : "2015-03-23 19:58:38 +0000",
    "user" : {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "protected" : false,
      "id_str" : "527238447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488943744226299904\/6SULCTUl_normal.png",
      "id" : 527238447,
      "verified" : false
    }
  },
  "id" : 582262139517313024,
  "created_at" : "2015-03-29 19:24:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582252512784326656",
  "geo" : { },
  "id_str" : "582256841255751680",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 hi yes press spacebar once is what u want I think?",
  "id" : 582256841255751680,
  "in_reply_to_status_id" : 582252512784326656,
  "created_at" : "2015-03-29 19:03:43 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582251221374930944",
  "geo" : { },
  "id_str" : "582251981336633344",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 if press spacebar once you get dropdown list, is that what they wanted? also add help file now any comments on that welcome :)",
  "id" : 582251981336633344,
  "in_reply_to_status_id" : 582251221374930944,
  "created_at" : "2015-03-29 18:44:24 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 3, 16 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/RCiono2GLf",
      "expanded_url" : "http:\/\/wp.me\/p15Ewi-3f2",
      "display_url" : "wp.me\/p15Ewi-3f2"
    } ]
  },
  "geo" : { },
  "id_str" : "582251533728874496",
  "text" : "RT @harrisonmike: Ever thought of trying interaction\u00A0analyses? http:\/\/t.co\/RCiono2GLf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/RCiono2GLf",
        "expanded_url" : "http:\/\/wp.me\/p15Ewi-3f2",
        "display_url" : "wp.me\/p15Ewi-3f2"
      } ]
    },
    "geo" : { },
    "id_str" : "582247285720911872",
    "text" : "Ever thought of trying interaction\u00A0analyses? http:\/\/t.co\/RCiono2GLf",
    "id" : 582247285720911872,
    "created_at" : "2015-03-29 18:25:45 +0000",
    "user" : {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "protected" : false,
      "id_str" : "1685397408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697937835127672832\/Z5BuTNo2_normal.jpg",
      "id" : 1685397408,
      "verified" : false
    }
  },
  "id" : 582251533728874496,
  "created_at" : "2015-03-29 18:42:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Pearson ELT USA",
      "screen_name" : "PearsonELTUSA",
      "indices" : [ 14, 28 ],
      "id_str" : "28831191",
      "id" : 28831191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582228263281516544",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @PearsonELTUSA thanks for sharing post :)",
  "id" : 582228263281516544,
  "created_at" : "2015-03-29 17:10:09 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582217432078688256",
  "geo" : { },
  "id_str" : "582227597221892096",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 hi great, what do they mean by simple list?",
  "id" : 582227597221892096,
  "in_reply_to_status_id" : 582217432078688256,
  "created_at" : "2015-03-29 17:07:31 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol15",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 77, 84 ]
    }, {
      "text" : "iatefl2015",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PiSYWoKKiE",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-TU",
      "display_url" : "wp.me\/pgHyE-TU"
    } ]
  },
  "geo" : { },
  "id_str" : "582183667537088512",
  "text" : "What is the ideal title for a talk\/poster at IATEFL and TESOL 2015? #tesol15 #iatefl #iatefl2015 #eltchat #keltchat\u2026 http:\/\/t.co\/PiSYWoKKiE",
  "id" : 582183667537088512,
  "created_at" : "2015-03-29 14:12:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 105, 113 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ypRP8DslUR",
      "expanded_url" : "https:\/\/youtu.be\/3EYAnXl-Ye8",
      "display_url" : "youtu.be\/3EYAnXl-Ye8"
    } ]
  },
  "geo" : { },
  "id_str" : "582075258112483328",
  "text" : "Am I Really The 4th Most Influential Thinker? Russell Brand The Trews (E...: https:\/\/t.co\/ypRP8DslUR via @YouTube",
  "id" : 582075258112483328,
  "created_at" : "2015-03-29 07:02:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Easy Tweets",
      "screen_name" : "eesytweets",
      "indices" : [ 106, 117 ],
      "id_str" : "3109092022",
      "id" : 3109092022
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/heyboyle\/status\/582031083203506176\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xbVKqbXEia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBPKLxtWEAAAntm.png",
      "id_str" : "582031080531824640",
      "id" : 582031080531824640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBPKLxtWEAAAntm.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 791
      } ],
      "display_url" : "pic.twitter.com\/xbVKqbXEia"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/heyboyle\/status\/582031083203506176\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xbVKqbXEia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBPKL4jW4AAi7DY.png",
      "id_str" : "582031082368983040",
      "id" : 582031082368983040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBPKL4jW4AAi7DY.png",
      "sizes" : [ {
        "h" : 607,
        "resize" : "fit",
        "w" : 783
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 783
      } ],
      "display_url" : "pic.twitter.com\/xbVKqbXEia"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/heyboyle\/status\/582031083203506176\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xbVKqbXEia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBPKL5WXEAAmG6P.png",
      "id_str" : "582031082582904832",
      "id" : 582031082582904832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBPKL5WXEAAmG6P.png",
      "sizes" : [ {
        "h" : 614,
        "resize" : "fit",
        "w" : 712
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 712
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xbVKqbXEia"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 30, 34 ]
    }, {
      "text" : "CEF",
      "indices" : [ 78, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582074421772480513",
  "text" : "RT @heyboyle: I'm building an #ELT site that filters real tweets by topic and #CEF level. Follow my robot @eesytweets for a taste. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Easy Tweets",
        "screen_name" : "eesytweets",
        "indices" : [ 92, 103 ],
        "id_str" : "3109092022",
        "id" : 3109092022
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/heyboyle\/status\/582031083203506176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xbVKqbXEia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBPKLxtWEAAAntm.png",
        "id_str" : "582031080531824640",
        "id" : 582031080531824640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBPKLxtWEAAAntm.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 791
        } ],
        "display_url" : "pic.twitter.com\/xbVKqbXEia"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/heyboyle\/status\/582031083203506176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xbVKqbXEia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBPKL4jW4AAi7DY.png",
        "id_str" : "582031082368983040",
        "id" : 582031082368983040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBPKL4jW4AAi7DY.png",
        "sizes" : [ {
          "h" : 607,
          "resize" : "fit",
          "w" : 783
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 783
        } ],
        "display_url" : "pic.twitter.com\/xbVKqbXEia"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/heyboyle\/status\/582031083203506176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xbVKqbXEia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBPKL5WXEAAmG6P.png",
        "id_str" : "582031082582904832",
        "id" : 582031082582904832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBPKL5WXEAAmG6P.png",
        "sizes" : [ {
          "h" : 614,
          "resize" : "fit",
          "w" : 712
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 712
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xbVKqbXEia"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 16, 20 ]
      }, {
        "text" : "CEF",
        "indices" : [ 64, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582031083203506176",
    "text" : "I'm building an #ELT site that filters real tweets by topic and #CEF level. Follow my robot @eesytweets for a taste. http:\/\/t.co\/xbVKqbXEia",
    "id" : 582031083203506176,
    "created_at" : "2015-03-29 04:06:38 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 582074421772480513,
  "created_at" : "2015-03-29 06:58:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Easy Tweets",
      "screen_name" : "eesytweets",
      "indices" : [ 10, 21 ],
      "id_str" : "3109092022",
      "id" : 3109092022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582031083203506176",
  "geo" : { },
  "id_str" : "582069638915313664",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @eesytweets neat will u be doing a writeup of this?",
  "id" : 582069638915313664,
  "in_reply_to_status_id" : 582031083203506176,
  "created_at" : "2015-03-29 06:39:50 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "indices" : [ 3, 14 ],
      "id_str" : "13498092",
      "id" : 13498092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/0AYbrukNxb",
      "expanded_url" : "http:\/\/tefl.posthaven.com\/bored-of-boardcraft-part-2",
      "display_url" : "tefl.posthaven.com\/bored-of-board\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581952284415930369",
  "text" : "RT @rogerdupuy: Bored of Boardcraft: Part 2 http:\/\/t.co\/0AYbrukNxb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/posthaven.com\" rel=\"nofollow\"\u003EPosthaven\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/0AYbrukNxb",
        "expanded_url" : "http:\/\/tefl.posthaven.com\/bored-of-boardcraft-part-2",
        "display_url" : "tefl.posthaven.com\/bored-of-board\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581943515388731393",
    "text" : "Bored of Boardcraft: Part 2 http:\/\/t.co\/0AYbrukNxb",
    "id" : 581943515388731393,
    "created_at" : "2015-03-28 22:18:40 +0000",
    "user" : {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "protected" : false,
      "id_str" : "13498092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708559032143912960\/gINmiTzD_normal.jpg",
      "id" : 13498092,
      "verified" : false
    }
  },
  "id" : 581952284415930369,
  "created_at" : "2015-03-28 22:53:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/YrMkKlUXuR",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2015\/mar\/28\/saudi-planes-pound-yemeni-capital-in-second-night-of-bombing-witnesses-say",
      "display_url" : "theguardian.com\/world\/2015\/mar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581946331905830912",
  "text" : "RT @pchallinor: Islamic fundamentalist bombings kill 39 civilians http:\/\/t.co\/YrMkKlUXuR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/YrMkKlUXuR",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2015\/mar\/28\/saudi-planes-pound-yemeni-capital-in-second-night-of-bombing-witnesses-say",
        "display_url" : "theguardian.com\/world\/2015\/mar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581781987561717760",
    "text" : "Islamic fundamentalist bombings kill 39 civilians http:\/\/t.co\/YrMkKlUXuR",
    "id" : 581781987561717760,
    "created_at" : "2015-03-28 11:36:49 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 581946331905830912,
  "created_at" : "2015-03-28 22:29:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 0, 8 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 17, 26 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apps4mfl",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/5a1Znh3FVW",
      "expanded_url" : "http:\/\/www.apps4efl.com\/",
      "display_url" : "apps4efl.com"
    } ]
  },
  "in_reply_to_status_id_str" : "581805513689681920",
  "geo" : { },
  "id_str" : "581812774650703873",
  "in_reply_to_user_id" : 279078759,
  "text" : "@LahiffP there's @apps4efl http:\/\/t.co\/5a1Znh3FVW for English #apps4mfl",
  "id" : 581812774650703873,
  "in_reply_to_status_id" : 581805513689681920,
  "created_at" : "2015-03-28 13:39:09 +0000",
  "in_reply_to_screen_name" : "LahiffP",
  "in_reply_to_user_id_str" : "279078759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cassetteboy",
      "screen_name" : "Cassetteboy",
      "indices" : [ 3, 15 ],
      "id_str" : "41780094",
      "id" : 41780094
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsCanChange",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/FDvJHnp6SF",
      "expanded_url" : "https:\/\/youtu.be\/vbLGG5UGEKw",
      "display_url" : "youtu.be\/vbLGG5UGEKw"
    } ]
  },
  "geo" : { },
  "id_str" : "581799374256226304",
  "text" : "RT @Cassetteboy: Inspired by Nick Clegg's Uptown Funk (not really) we uploaded a new political rap earlier - https:\/\/t.co\/FDvJHnp6SF  #Thin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsCanChange",
        "indices" : [ 117, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/FDvJHnp6SF",
        "expanded_url" : "https:\/\/youtu.be\/vbLGG5UGEKw",
        "display_url" : "youtu.be\/vbLGG5UGEKw"
      } ]
    },
    "geo" : { },
    "id_str" : "581540323618226176",
    "text" : "Inspired by Nick Clegg's Uptown Funk (not really) we uploaded a new political rap earlier - https:\/\/t.co\/FDvJHnp6SF  #ThingsCanChange",
    "id" : 581540323618226176,
    "created_at" : "2015-03-27 19:36:32 +0000",
    "user" : {
      "name" : "Cassetteboy",
      "screen_name" : "Cassetteboy",
      "protected" : false,
      "id_str" : "41780094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1094942111\/twitter_logo3_normal.png",
      "id" : 41780094,
      "verified" : false
    }
  },
  "id" : 581799374256226304,
  "created_at" : "2015-03-28 12:45:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pronunciaton",
      "indices" : [ 35, 48 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "auselt",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/P5olQ7o3WN",
      "expanded_url" : "http:\/\/www.dictiome.com\/add",
      "display_url" : "dictiome.com\/add"
    } ]
  },
  "geo" : { },
  "id_str" : "581793950392041472",
  "text" : "help add transcriptions to Dictome #pronunciaton database http:\/\/t.co\/P5olQ7o3WN #eltchat #keltchat #auselt",
  "id" : 581793950392041472,
  "created_at" : "2015-03-28 12:24:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 102, 110 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/SzRmyRXJH8",
      "expanded_url" : "https:\/\/youtu.be\/gEYI8LEp03A?list=PLG09kZHOtEVdAwYJNMczXc_2PdLsciALg",
      "display_url" : "youtu.be\/gEYI8LEp03A?li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581770273290080256",
  "text" : "Luke Meddings presents at the 36th TESOL Greece International Conference: https:\/\/t.co\/SzRmyRXJH8 via @YouTube",
  "id" : 581770273290080256,
  "created_at" : "2015-03-28 10:50:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eduardo Kastika",
      "screen_name" : "EduardoKastika",
      "indices" : [ 0, 15 ],
      "id_str" : "310462398",
      "id" : 310462398
    }, {
      "name" : "Almude\u03B7\u03B1 Fern\u00E1nde\u0225",
      "screen_name" : "almudena_fdez",
      "indices" : [ 16, 30 ],
      "id_str" : "70230255",
      "id" : 70230255
    }, {
      "name" : "Roc\u00EDo Mart\u00EDnez Samp.",
      "screen_name" : "rociomsampere",
      "indices" : [ 31, 45 ],
      "id_str" : "380847682",
      "id" : 380847682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/ORSKVvMdLy",
      "expanded_url" : "https:\/\/translate.google.com\/translate?sl=en&tl=es&js=y&prev=_t&hl=en&ie=UTF-8&u=http%3A%2F%2Fwww.willatworklearning.com%2F2006%2F05%2Fpeople_remember.html&edit-text=&act=url",
      "display_url" : "translate.google.com\/translate?sl=e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "568058613383749632",
  "geo" : { },
  "id_str" : "581763022043144192",
  "in_reply_to_user_id" : 310462398,
  "text" : "@EduardoKastika @almudena_fdez @rociomsampere \u00A1Hola! https:\/\/t.co\/ORSKVvMdLy",
  "id" : 581763022043144192,
  "in_reply_to_status_id" : 568058613383749632,
  "created_at" : "2015-03-28 10:21:27 +0000",
  "in_reply_to_screen_name" : "EduardoKastika",
  "in_reply_to_user_id_str" : "310462398",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Thirkell",
      "screen_name" : "adrianthirkell",
      "indices" : [ 0, 15 ],
      "id_str" : "249569430",
      "id" : 249569430
    }, {
      "name" : "Vipula Sharma",
      "screen_name" : "VipulaSharma1",
      "indices" : [ 90, 104 ],
      "id_str" : "2204959478",
      "id" : 2204959478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581753017524858880",
  "geo" : { },
  "id_str" : "581753520451424256",
  "in_reply_to_user_id" : 249569430,
  "text" : "@adrianthirkell i just saw zombie pyramid posted so linked to say it is false, looks like @VipulaSharma1 did not like it blocked by her now",
  "id" : 581753520451424256,
  "in_reply_to_status_id" : 581753017524858880,
  "created_at" : "2015-03-28 09:43:42 +0000",
  "in_reply_to_screen_name" : "adrianthirkell",
  "in_reply_to_user_id_str" : "249569430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Thirkell",
      "screen_name" : "adrianthirkell",
      "indices" : [ 0, 15 ],
      "id_str" : "249569430",
      "id" : 249569430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581752060313411584",
  "geo" : { },
  "id_str" : "581752469753094144",
  "in_reply_to_user_id" : 249569430,
  "text" : "@adrianthirkell hi r u referring to zombie learning pyramid?",
  "id" : 581752469753094144,
  "in_reply_to_status_id" : 581752060313411584,
  "created_at" : "2015-03-28 09:39:31 +0000",
  "in_reply_to_screen_name" : "adrianthirkell",
  "in_reply_to_user_id_str" : "249569430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Darren Kuropatwa",
      "screen_name" : "dkuropatwa",
      "indices" : [ 129, 140 ],
      "id_str" : "5634392",
      "id" : 5634392
    }, {
      "name" : "Rochelle Lockridge",
      "screen_name" : "Rockylou22",
      "indices" : [ 139, 140 ],
      "id_str" : "58716218",
      "id" : 58716218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/xkth0DHzci",
      "expanded_url" : "http:\/\/wp.me\/pf0PM-aHz",
      "display_url" : "wp.me\/pf0PM-aHz"
    } ]
  },
  "geo" : { },
  "id_str" : "581752192786415616",
  "text" : "RT @cogdog: CogDogBlogged: The 60,000 Times Faster Claim Gets Dialed Back to 1982 http:\/\/t.co\/xkth0DHzci I am still on the case! @dkuropatw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darren Kuropatwa",
        "screen_name" : "dkuropatwa",
        "indices" : [ 117, 128 ],
        "id_str" : "5634392",
        "id" : 5634392
      }, {
        "name" : "Rochelle Lockridge",
        "screen_name" : "Rockylou22",
        "indices" : [ 129, 140 ],
        "id_str" : "58716218",
        "id" : 58716218
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/xkth0DHzci",
        "expanded_url" : "http:\/\/wp.me\/pf0PM-aHz",
        "display_url" : "wp.me\/pf0PM-aHz"
      } ]
    },
    "geo" : { },
    "id_str" : "581504990096707584",
    "text" : "CogDogBlogged: The 60,000 Times Faster Claim Gets Dialed Back to 1982 http:\/\/t.co\/xkth0DHzci I am still on the case! @dkuropatwa @rockylou22",
    "id" : 581504990096707584,
    "created_at" : "2015-03-27 17:16:08 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 581752192786415616,
  "created_at" : "2015-03-28 09:38:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#asiaEDchat",
      "screen_name" : "asiaEDchat",
      "indices" : [ 0, 11 ],
      "id_str" : "2739861048",
      "id" : 2739861048
    }, {
      "name" : "Vipula Sharma",
      "screen_name" : "VipulaSharma1",
      "indices" : [ 12, 26 ],
      "id_str" : "2204959478",
      "id" : 2204959478
    }, {
      "name" : "Adrian Thirkell",
      "screen_name" : "adrianthirkell",
      "indices" : [ 27, 42 ],
      "id_str" : "249569430",
      "id" : 249569430
    }, {
      "name" : "Shona Davidson",
      "screen_name" : "shonadavidson",
      "indices" : [ 43, 57 ],
      "id_str" : "28169798",
      "id" : 28169798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581746791533563904",
  "geo" : { },
  "id_str" : "581748483209715712",
  "in_reply_to_user_id" : 2739861048,
  "text" : "@asiaEDchat @VipulaSharma1 @adrianthirkell @shonadavidson sure say a discussion on how false info like learning pyramids is spread",
  "id" : 581748483209715712,
  "in_reply_to_status_id" : 581746791533563904,
  "created_at" : "2015-03-28 09:23:41 +0000",
  "in_reply_to_screen_name" : "asiaEDchat",
  "in_reply_to_user_id_str" : "2739861048",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581734126270746624",
  "geo" : { },
  "id_str" : "581743922352918528",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo you could get some good booze for the price of that corpus though :)",
  "id" : 581743922352918528,
  "in_reply_to_status_id" : 581734126270746624,
  "created_at" : "2015-03-28 09:05:34 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 3, 16 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ttZLAV86L3",
      "expanded_url" : "https:\/\/www.phonetik.uni-muenchen.de\/Bas\/BasALCeng.html",
      "display_url" : "phonetik.uni-muenchen.de\/Bas\/BasALCeng.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581743786323275776",
  "text" : "RT @RobertASzabo: Bavarian Archive for Speech Signals\nAlcohol Language Corpus - ALC https:\/\/t.co\/ttZLAV86L3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/ttZLAV86L3",
        "expanded_url" : "https:\/\/www.phonetik.uni-muenchen.de\/Bas\/BasALCeng.html",
        "display_url" : "phonetik.uni-muenchen.de\/Bas\/BasALCeng.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581734126270746624",
    "text" : "Bavarian Archive for Speech Signals\nAlcohol Language Corpus - ALC https:\/\/t.co\/ttZLAV86L3",
    "id" : 581734126270746624,
    "created_at" : "2015-03-28 08:26:38 +0000",
    "user" : {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "protected" : false,
      "id_str" : "145285777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666724461559812096\/XTsQWxw6_normal.jpg",
      "id" : 145285777,
      "verified" : false
    }
  },
  "id" : 581743786323275776,
  "created_at" : "2015-03-28 09:05:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vipula Sharma",
      "screen_name" : "VipulaSharma1",
      "indices" : [ 0, 14 ],
      "id_str" : "2204959478",
      "id" : 2204959478
    }, {
      "name" : "Adrian Thirkell",
      "screen_name" : "adrianthirkell",
      "indices" : [ 15, 30 ],
      "id_str" : "249569430",
      "id" : 249569430
    }, {
      "name" : "Shona Davidson",
      "screen_name" : "shonadavidson",
      "indices" : [ 31, 45 ],
      "id_str" : "28169798",
      "id" : 28169798
    }, {
      "name" : "#asiaEDchat",
      "screen_name" : "asiaEDchat",
      "indices" : [ 46, 57 ],
      "id_str" : "2739861048",
      "id" : 2739861048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/qKtMZbRogm",
      "expanded_url" : "http:\/\/www.willatworklearning.com\/2006\/05\/people_remember.html",
      "display_url" : "willatworklearning.com\/2006\/05\/people\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "581719130891407361",
  "geo" : { },
  "id_str" : "581740811609604096",
  "in_reply_to_user_id" : 2204959478,
  "text" : "@VipulaSharma1 @adrianthirkell @shonadavidson @asiaEDchat this zombie pyramid is hard to kill http:\/\/t.co\/qKtMZbRogm",
  "id" : 581740811609604096,
  "in_reply_to_status_id" : 581719130891407361,
  "created_at" : "2015-03-28 08:53:12 +0000",
  "in_reply_to_screen_name" : "VipulaSharma1",
  "in_reply_to_user_id_str" : "2204959478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Mackin",
      "screen_name" : "EllieMackin",
      "indices" : [ 3, 15 ],
      "id_str" : "2154486266",
      "id" : 2154486266
    }, {
      "name" : "Vitae",
      "screen_name" : "chroniclevitae",
      "indices" : [ 86, 101 ],
      "id_str" : "1546041438",
      "id" : 1546041438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/oBDenHJYFI",
      "expanded_url" : "https:\/\/chroniclevitae.com\/news\/953-lip-syncing-to-the-academic-conversation",
      "display_url" : "chroniclevitae.com\/news\/953-lip-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581559363095121921",
  "text" : "RT @EllieMackin: Lip-Syncing to the Academic Conversation https:\/\/t.co\/oBDenHJYFI via @chroniclevitae",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vitae",
        "screen_name" : "chroniclevitae",
        "indices" : [ 69, 84 ],
        "id_str" : "1546041438",
        "id" : 1546041438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/oBDenHJYFI",
        "expanded_url" : "https:\/\/chroniclevitae.com\/news\/953-lip-syncing-to-the-academic-conversation",
        "display_url" : "chroniclevitae.com\/news\/953-lip-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581547296556511232",
    "text" : "Lip-Syncing to the Academic Conversation https:\/\/t.co\/oBDenHJYFI via @chroniclevitae",
    "id" : 581547296556511232,
    "created_at" : "2015-03-27 20:04:14 +0000",
    "user" : {
      "name" : "Ellie Mackin",
      "screen_name" : "EllieMackin",
      "protected" : false,
      "id_str" : "2154486266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762708059957370881\/gs-l25bD_normal.jpg",
      "id" : 2154486266,
      "verified" : false
    }
  },
  "id" : 581559363095121921,
  "created_at" : "2015-03-27 20:52:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 61, 76 ],
      "id_str" : "16045268",
      "id" : 16045268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/2pVKtoFVnb",
      "expanded_url" : "http:\/\/bit.ly\/1F208D9",
      "display_url" : "bit.ly\/1F208D9"
    } ]
  },
  "geo" : { },
  "id_str" : "581556267208085504",
  "text" : "Essay challenging Kevin Carey's new book on higher education @insidehighered http:\/\/t.co\/2pVKtoFVnb",
  "id" : 581556267208085504,
  "created_at" : "2015-03-27 20:39:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 12, 25 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/9S3rZRmkrT",
      "expanded_url" : "http:\/\/lct.iaush.ac.ir\/pdf_5124_c8dcdbc3cbb49883dbb12ec10b6e8da1.html",
      "display_url" : "lct.iaush.ac.ir\/pdf_5124_c8dcd\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "581448533007605760",
  "geo" : { },
  "id_str" : "581500277959843841",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha @harrisonmike hi maybe something like this may help? http:\/\/t.co\/9S3rZRmkrT",
  "id" : 581500277959843841,
  "in_reply_to_status_id" : 581448533007605760,
  "created_at" : "2015-03-27 16:57:24 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 3, 14 ],
      "id_str" : "857732892",
      "id" : 857732892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "EFL",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "lexis",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/n2UgxXwdcW",
      "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/03\/the-lexical-approach-and-natural-selection\/",
      "display_url" : "lexicallab.com\/2015\/03\/the-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581428828872011777",
  "text" : "RT @LexicalLab: #ELT #EFL #lexis New post by Dr. Ivor Timmis about how best to choose which lexical items to focus on in class: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "EFL",
        "indices" : [ 5, 9 ]
      }, {
        "text" : "lexis",
        "indices" : [ 10, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/n2UgxXwdcW",
        "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/03\/the-lexical-approach-and-natural-selection\/",
        "display_url" : "lexicallab.com\/2015\/03\/the-le\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581424120342142976",
    "text" : "#ELT #EFL #lexis New post by Dr. Ivor Timmis about how best to choose which lexical items to focus on in class: http:\/\/t.co\/n2UgxXwdcW",
    "id" : 581424120342142976,
    "created_at" : "2015-03-27 11:54:47 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 581428828872011777,
  "created_at" : "2015-03-27 12:13:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 79, 91 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 92, 107 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/i2NhOGVa03",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/google-community\/",
      "display_url" : "eflnotes.wordpress.com\/google-communi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "581281808744103937",
  "geo" : { },
  "id_str" : "581333069614981120",
  "in_reply_to_user_id" : 2311153903,
  "text" : "check out the G+ CL community https:\/\/t.co\/i2NhOGVa03 as endorsed by the Folse @NewbieCELTA @DavidHarbinson",
  "id" : 581333069614981120,
  "in_reply_to_status_id" : 581281808744103937,
  "created_at" : "2015-03-27 05:52:59 +0000",
  "in_reply_to_screen_name" : "NewbieCELTA",
  "in_reply_to_user_id_str" : "2311153903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "David Wiley, PhD",
      "screen_name" : "opencontent",
      "indices" : [ 26, 38 ],
      "id_str" : "4514361",
      "id" : 4514361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/ezvLJcm4V3",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/03\/26\/paper-thoughts-and-the-remix-hypothesis\/",
      "display_url" : "hapgood.us\/2015\/03\/26\/pap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581189213628022784",
  "text" : "RT @holden: A response to @opencontent's excellent post: http:\/\/t.co\/ezvLJcm4V3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Wiley, PhD",
        "screen_name" : "opencontent",
        "indices" : [ 14, 26 ],
        "id_str" : "4514361",
        "id" : 4514361
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/ezvLJcm4V3",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/03\/26\/paper-thoughts-and-the-remix-hypothesis\/",
        "display_url" : "hapgood.us\/2015\/03\/26\/pap\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581165827057180672",
    "text" : "A response to @opencontent's excellent post: http:\/\/t.co\/ezvLJcm4V3",
    "id" : 581165827057180672,
    "created_at" : "2015-03-26 18:48:25 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 581189213628022784,
  "created_at" : "2015-03-26 20:21:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    }, {
      "name" : "Colin Batchelor",
      "screen_name" : "my_disposition",
      "indices" : [ 8, 23 ],
      "id_str" : "153460121",
      "id" : 153460121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581116040828059649",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a @my_disposition thanks for RT :)",
  "id" : 581116040828059649,
  "created_at" : "2015-03-26 15:30:35 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Warre",
      "screen_name" : "RobbioDobbio",
      "indices" : [ 63, 76 ],
      "id_str" : "373998042",
      "id" : 373998042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/qYMHnFTpeA",
      "expanded_url" : "http:\/\/wp.me\/p37ScC-dd",
      "display_url" : "wp.me\/p37ScC-dd"
    } ]
  },
  "geo" : { },
  "id_str" : "581098786736476160",
  "text" : "Advanced Relative Clause Pictionary http:\/\/t.co\/qYMHnFTpeA via @RobbioDobbio",
  "id" : 581098786736476160,
  "created_at" : "2015-03-26 14:22:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "187481025",
      "id" : 187481025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/1I55YE8YAi",
      "expanded_url" : "http:\/\/www.eslwriting.org\/about-rob-whyte\/learn-english-ten-video-prompts-for-esl-writing-class\/",
      "display_url" : "eslwriting.org\/about-rob-whyt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580988056968175616",
  "text" : "RT @eslwriter: 10 short videos to use as conversation and writing prompts in the #ESL class. http:\/\/t.co\/1I55YE8YAi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 66, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/1I55YE8YAi",
        "expanded_url" : "http:\/\/www.eslwriting.org\/about-rob-whyte\/learn-english-ten-video-prompts-for-esl-writing-class\/",
        "display_url" : "eslwriting.org\/about-rob-whyt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580889442950324225",
    "text" : "10 short videos to use as conversation and writing prompts in the #ESL class. http:\/\/t.co\/1I55YE8YAi",
    "id" : 580889442950324225,
    "created_at" : "2015-03-26 00:30:10 +0000",
    "user" : {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "protected" : false,
      "id_str" : "187481025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682332531\/cd44653e5843c08c6938f41dc15668bc_normal.png",
      "id" : 187481025,
      "verified" : false
    }
  },
  "id" : 580988056968175616,
  "created_at" : "2015-03-26 07:02:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Democracy Now!",
      "screen_name" : "democracynow",
      "indices" : [ 3, 16 ],
      "id_str" : "16935292",
      "id" : 16935292
    }, {
      "name" : "IPPNW",
      "screen_name" : "IPPNW",
      "indices" : [ 119, 125 ],
      "id_str" : "15694182",
      "id" : 15694182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/EPY5BDcLZh",
      "expanded_url" : "http:\/\/owl.li\/KNAxt",
      "display_url" : "owl.li\/KNAxt"
    } ]
  },
  "geo" : { },
  "id_str" : "580873612858626048",
  "text" : "RT @democracynow: Study: U.S. Wars Have Left over 1 Million Dead in Iraq, Afghanistan, Pakistan http:\/\/t.co\/EPY5BDcLZh @ippnw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IPPNW",
        "screen_name" : "IPPNW",
        "indices" : [ 101, 107 ],
        "id_str" : "15694182",
        "id" : 15694182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/EPY5BDcLZh",
        "expanded_url" : "http:\/\/owl.li\/KNAxt",
        "display_url" : "owl.li\/KNAxt"
      } ]
    },
    "geo" : { },
    "id_str" : "580844268702568448",
    "text" : "Study: U.S. Wars Have Left over 1 Million Dead in Iraq, Afghanistan, Pakistan http:\/\/t.co\/EPY5BDcLZh @ippnw",
    "id" : 580844268702568448,
    "created_at" : "2015-03-25 21:30:39 +0000",
    "user" : {
      "name" : "Democracy Now!",
      "screen_name" : "democracynow",
      "protected" : false,
      "id_str" : "16935292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420934536969461760\/-ZK_2p2-_normal.png",
      "id" : 16935292,
      "verified" : true
    }
  },
  "id" : 580873612858626048,
  "created_at" : "2015-03-25 23:27:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Masters Of TESOL",
      "screen_name" : "motcast",
      "indices" : [ 3, 11 ],
      "id_str" : "2859583682",
      "id" : 2859583682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DorothyChun",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "ESL",
      "indices" : [ 139, 143 ]
    }, {
      "text" : "EFL",
      "indices" : [ 143, 144 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ty0kaDzvck",
      "expanded_url" : "http:\/\/wp.me\/p5dOWM-2d",
      "display_url" : "wp.me\/p5dOWM-2d"
    } ]
  },
  "geo" : { },
  "id_str" : "580857297246797824",
  "text" : "RT @motcast: Visualisation expert #DorothyChun explains why &amp; how to teach intonation in episode 5 http:\/\/t.co\/ty0kaDzvck Teach better #ESL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DorothyChun",
        "indices" : [ 21, 33 ]
      }, {
        "text" : "ESL",
        "indices" : [ 126, 130 ]
      }, {
        "text" : "EFL",
        "indices" : [ 131, 135 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 136, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/ty0kaDzvck",
        "expanded_url" : "http:\/\/wp.me\/p5dOWM-2d",
        "display_url" : "wp.me\/p5dOWM-2d"
      } ]
    },
    "geo" : { },
    "id_str" : "580142615238029312",
    "text" : "Visualisation expert #DorothyChun explains why &amp; how to teach intonation in episode 5 http:\/\/t.co\/ty0kaDzvck Teach better #ESL #EFL #TESOL",
    "id" : 580142615238029312,
    "created_at" : "2015-03-23 23:02:32 +0000",
    "user" : {
      "name" : "Masters Of TESOL",
      "screen_name" : "motcast",
      "protected" : false,
      "id_str" : "2859583682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524053249024741376\/o-CPnLly_normal.jpeg",
      "id" : 2859583682,
      "verified" : false
    }
  },
  "id" : 580857297246797824,
  "created_at" : "2015-03-25 22:22:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yvonne Hynson",
      "screen_name" : "YVNZCBLISS",
      "indices" : [ 0, 11 ],
      "id_str" : "149271125",
      "id" : 149271125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580847526053560320",
  "in_reply_to_user_id" : 149271125,
  "text" : "@YVNZCBLISS thx for RT :) suggestions welcome for PHaVE dictionary",
  "id" : 580847526053560320,
  "created_at" : "2015-03-25 21:43:36 +0000",
  "in_reply_to_screen_name" : "YVNZCBLISS",
  "in_reply_to_user_id_str" : "149271125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The English Guy",
      "screen_name" : "TheEnglishGuyUK",
      "indices" : [ 0, 16 ],
      "id_str" : "2348573732",
      "id" : 2348573732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580813582398545920",
  "in_reply_to_user_id" : 2348573732,
  "text" : "@TheEnglishGuyUK appreciate RT, welcome any suggestions for PHaVE dictionary",
  "id" : 580813582398545920,
  "created_at" : "2015-03-25 19:28:43 +0000",
  "in_reply_to_screen_name" : "TheEnglishGuyUK",
  "in_reply_to_user_id_str" : "2348573732",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580790291688497152",
  "geo" : { },
  "id_str" : "580813360301793280",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheers for share Leo, how's Canada?",
  "id" : 580813360301793280,
  "in_reply_to_status_id" : 580790291688497152,
  "created_at" : "2015-03-25 19:27:50 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "indices" : [ 0, 12 ],
      "id_str" : "3112144043",
      "id" : 3112144043
    }, {
      "name" : "Anabel Fern\u00E1ndez",
      "screen_name" : "dimodeca",
      "indices" : [ 13, 22 ],
      "id_str" : "1235503316",
      "id" : 1235503316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580756440924704768",
  "in_reply_to_user_id" : 3112144043,
  "text" : "@bee_visible @dimodeca thanks for RTing PHaVE dict, if u have any suggestions let me know",
  "id" : 580756440924704768,
  "created_at" : "2015-03-25 15:41:40 +0000",
  "in_reply_to_screen_name" : "bee_visible",
  "in_reply_to_user_id_str" : "3112144043",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 12, 23 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 24, 36 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 37, 46 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 47, 53 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580744350377877504",
  "geo" : { },
  "id_str" : "580755606308564992",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @patrickelt @SophiaKhan4 @Marisa_C @ebefl woah, well i would not put myself in such circles but thank you :)",
  "id" : 580755606308564992,
  "in_reply_to_status_id" : 580744350377877504,
  "created_at" : "2015-03-25 15:38:21 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 10, 25 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 89, 101 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "580695579866603520",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C @AnthonyTeacher thx for RT, added help file any comments please let me know cc @AnneHendler http:\/\/t.co\/feVV1F8lKr",
  "id" : 580695579866603520,
  "created_at" : "2015-03-25 11:39:49 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 14, 27 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580531776835231745",
  "geo" : { },
  "id_str" : "580613654862790656",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard @sbrowntweets hi sorry it stands for bibliography, guess usual abbrev is biblio but because twitter :)",
  "id" : 580613654862790656,
  "in_reply_to_status_id" : 580531776835231745,
  "created_at" : "2015-03-25 06:14:17 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOL15",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580608331066286080",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall the for sharing have fun at #TESOL15 :)",
  "id" : 580608331066286080,
  "created_at" : "2015-03-25 05:53:07 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580544079634808832",
  "geo" : { },
  "id_str" : "580607599269306368",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler OK noted thanks!",
  "id" : 580607599269306368,
  "in_reply_to_status_id" : 580544079634808832,
  "created_at" : "2015-03-25 05:50:13 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 75, 85 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/klGbI2cuAs",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-cw",
      "display_url" : "wp.me\/p3sNrs-cw"
    } ]
  },
  "geo" : { },
  "id_str" : "580607474111275009",
  "text" : "Storytelling in the classroom | Webinar summary http:\/\/t.co\/klGbI2cuAs via @adi_rajan",
  "id" : 580607474111275009,
  "created_at" : "2015-03-25 05:49:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580522544702337024",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers for RT Anne if u have any comments on dictionary let me know :)",
  "id" : 580522544702337024,
  "created_at" : "2015-03-25 00:12:14 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phrasalverb",
      "indices" : [ 6, 18 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "auselt",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 114, 121 ]
    }, {
      "text" : "esl",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "efl",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "580513751956365312",
  "text" : "PHaVE #phrasalverb dictionary now with added TED video examples http:\/\/t.co\/feVV1F8lKr #eltchat #keltchat #auselt #AusELT #esl #efl",
  "id" : 580513751956365312,
  "created_at" : "2015-03-24 23:37:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/ekzhGkXFvp",
      "expanded_url" : "http:\/\/tinyurl.com\/n7df37z",
      "display_url" : "tinyurl.com\/n7df37z"
    } ]
  },
  "geo" : { },
  "id_str" : "580329466460807169",
  "text" : "RT @TonyMcEnery: Speak English, Italian, Portuguese or Chinese? Help us to extend our semantic tagger to other languages here: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/ekzhGkXFvp",
        "expanded_url" : "http:\/\/tinyurl.com\/n7df37z",
        "display_url" : "tinyurl.com\/n7df37z"
      } ]
    },
    "geo" : { },
    "id_str" : "580328055585054721",
    "text" : "Speak English, Italian, Portuguese or Chinese? Help us to extend our semantic tagger to other languages here: http:\/\/t.co\/ekzhGkXFvp",
    "id" : 580328055585054721,
    "created_at" : "2015-03-24 11:19:25 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 580329466460807169,
  "created_at" : "2015-03-24 11:25:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580303939322658816",
  "geo" : { },
  "id_str" : "580315085899452416",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery that gave me stitches :0",
  "id" : 580315085899452416,
  "in_reply_to_status_id" : 580303939322658816,
  "created_at" : "2015-03-24 10:27:52 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/5itiN8gilT",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=18393#more-18393",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=18393#m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580313030434664448",
  "text" : "RT @TonyMcEnery: Auditory flutter fusion and the daleks - plus a little relaxation, dalek style: http:\/\/t.co\/5itiN8gilT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/5itiN8gilT",
        "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=18393#more-18393",
        "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=18393#m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580303939322658816",
    "text" : "Auditory flutter fusion and the daleks - plus a little relaxation, dalek style: http:\/\/t.co\/5itiN8gilT",
    "id" : 580303939322658816,
    "created_at" : "2015-03-24 09:43:35 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 580313030434664448,
  "created_at" : "2015-03-24 10:19:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 73, 88 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/hYOy2ubK3R",
      "expanded_url" : "http:\/\/wp.me\/p39fMp-uK",
      "display_url" : "wp.me\/p39fMp-uK"
    } ]
  },
  "geo" : { },
  "id_str" : "580312361954881536",
  "text" : "RT @HanaTicha: Learn English with Dreamreader http:\/\/t.co\/hYOy2ubK3R via @LjiljanaHavran &gt; lovely post wih a handy tip on practising Aviati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ljiljana Havran",
        "screen_name" : "LjiljanaHavran",
        "indices" : [ 58, 73 ],
        "id_str" : "1395825290",
        "id" : 1395825290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/hYOy2ubK3R",
        "expanded_url" : "http:\/\/wp.me\/p39fMp-uK",
        "display_url" : "wp.me\/p39fMp-uK"
      } ]
    },
    "geo" : { },
    "id_str" : "580264386096459777",
    "text" : "Learn English with Dreamreader http:\/\/t.co\/hYOy2ubK3R via @LjiljanaHavran &gt; lovely post wih a handy tip on practising Aviation English",
    "id" : 580264386096459777,
    "created_at" : "2015-03-24 07:06:25 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 580312361954881536,
  "created_at" : "2015-03-24 10:17:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580270199305306112",
  "geo" : { },
  "id_str" : "580312268191195136",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets nice vocab bib by one of the commenters",
  "id" : 580312268191195136,
  "in_reply_to_status_id" : 580270199305306112,
  "created_at" : "2015-03-24 10:16:41 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ITTC Bournemouth",
      "screen_name" : "ITTC_TEFL",
      "indices" : [ 3, 13 ],
      "id_str" : "1139785639",
      "id" : 1139785639
    }, {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 101, 112 ],
      "id_str" : "16316886",
      "id" : 16316886
    }, {
      "name" : "Mededitor",
      "screen_name" : "Mededitor",
      "indices" : [ 117, 127 ],
      "id_str" : "14123701",
      "id" : 14123701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/063s4gWl70",
      "expanded_url" : "http:\/\/flip.it\/Ur8eQ",
      "display_url" : "flip.it\/Ur8eQ"
    } ]
  },
  "geo" : { },
  "id_str" : "580150720353198080",
  "text" : "RT @ITTC_TEFL: Interesting BrEng v USEng 'rude to' and great eg of #corpuslinguistics tool GloBWE RT @lynneguist: RT @Mededitor: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lynne Murphy",
        "screen_name" : "lynneguist",
        "indices" : [ 86, 97 ],
        "id_str" : "16316886",
        "id" : 16316886
      }, {
        "name" : "Mededitor",
        "screen_name" : "Mededitor",
        "indices" : [ 102, 112 ],
        "id_str" : "14123701",
        "id" : 14123701
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 52, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/063s4gWl70",
        "expanded_url" : "http:\/\/flip.it\/Ur8eQ",
        "display_url" : "flip.it\/Ur8eQ"
      } ]
    },
    "geo" : { },
    "id_str" : "575713780375617537",
    "text" : "Interesting BrEng v USEng 'rude to' and great eg of #corpuslinguistics tool GloBWE RT @lynneguist: RT @Mededitor: http:\/\/t.co\/063s4gWl70",
    "id" : 575713780375617537,
    "created_at" : "2015-03-11 17:43:56 +0000",
    "user" : {
      "name" : "ITTC Bournemouth",
      "screen_name" : "ITTC_TEFL",
      "protected" : false,
      "id_str" : "1139785639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567707900420706305\/L_uM-0Y__normal.jpeg",
      "id" : 1139785639,
      "verified" : false
    }
  },
  "id" : 580150720353198080,
  "created_at" : "2015-03-23 23:34:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 3, 12 ],
      "id_str" : "413454135",
      "id" : 413454135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningenglish",
      "indices" : [ 14, 30 ]
    }, {
      "text" : "teachingenglish",
      "indices" : [ 31, 47 ]
    }, {
      "text" : "ESL",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "ELT",
      "indices" : [ 134, 138 ]
    }, {
      "text" : "ESOL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "EFL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "ELL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/9T4YviUWgJ",
      "expanded_url" : "http:\/\/garethsgradedstories.blogspot.com",
      "display_url" : "garethsgradedstories.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "580148114998300673",
  "text" : "RT @reasons4: #learningenglish?#teachingenglish? There're now 13 graded stories for classroom or at home http:\/\/t.co\/9T4YviUWgJ  #ESL #ELT \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "learningenglish",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "teachingenglish",
        "indices" : [ 17, 33 ]
      }, {
        "text" : "ESL",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "ELT",
        "indices" : [ 120, 124 ]
      }, {
        "text" : "ESOL",
        "indices" : [ 125, 130 ]
      }, {
        "text" : "EFL",
        "indices" : [ 131, 135 ]
      }, {
        "text" : "ELL",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/9T4YviUWgJ",
        "expanded_url" : "http:\/\/garethsgradedstories.blogspot.com",
        "display_url" : "garethsgradedstories.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "580146252500856832",
    "text" : "#learningenglish?#teachingenglish? There're now 13 graded stories for classroom or at home http:\/\/t.co\/9T4YviUWgJ  #ESL #ELT #ESOL #EFL #ELL",
    "id" : 580146252500856832,
    "created_at" : "2015-03-23 23:16:59 +0000",
    "user" : {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "protected" : false,
      "id_str" : "413454135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1640992210\/image_normal.jpg",
      "id" : 413454135,
      "verified" : false
    }
  },
  "id" : 580148114998300673,
  "created_at" : "2015-03-23 23:24:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/8DA61AJjmB",
      "expanded_url" : "http:\/\/www.researchgate.net\/profile\/Barbara_Malt\/publication\/236973798_Speaking_vs._Thinking_about_Objects_and_Actions\/links\/0046351a8f416ae29a000000.pdf",
      "display_url" : "researchgate.net\/profile\/Barbar\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "580140680003059714",
  "geo" : { },
  "id_str" : "580144325880913920",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @kevchanwow hi leo that study is available here http:\/\/t.co\/8DA61AJjmB",
  "id" : 580144325880913920,
  "in_reply_to_status_id" : 580140680003059714,
  "created_at" : "2015-03-23 23:09:20 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 20, 31 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/UBzTcBCHbb",
      "expanded_url" : "http:\/\/leoxicon.blogspot.jp\/2015\/03\/messy-semantic-fields.html",
      "display_url" : "leoxicon.blogspot.jp\/2015\/03\/messy-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580142049804099584",
  "text" : "RT @kevchanwow: via @leoselivan categorising and some of the ways language effects how we see our world: http:\/\/t.co\/UBzTcBCHbb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 4, 15 ],
        "id_str" : "408365496",
        "id" : 408365496
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/UBzTcBCHbb",
        "expanded_url" : "http:\/\/leoxicon.blogspot.jp\/2015\/03\/messy-semantic-fields.html",
        "display_url" : "leoxicon.blogspot.jp\/2015\/03\/messy-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "579831659572244480",
    "text" : "via @leoselivan categorising and some of the ways language effects how we see our world: http:\/\/t.co\/UBzTcBCHbb",
    "id" : 579831659572244480,
    "created_at" : "2015-03-23 02:26:55 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 580142049804099584,
  "created_at" : "2015-03-23 23:00:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 38, 47 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/xxU8ZHKJll",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/DxDES4kd3x3",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580137903935893504",
  "text" : "check out what #corpuslinguistics bod @cainesap  says about 2 spoken corpuses he is compiling https:\/\/t.co\/xxU8ZHKJll",
  "id" : 580137903935893504,
  "created_at" : "2015-03-23 22:43:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 12, 27 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 28, 44 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 45, 54 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580045739369328641",
  "geo" : { },
  "id_str" : "580067907058724864",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt @GeoffreyJordan @michaelegriffin @bealer81 i feel sorry for that teacher who commented on deleted post :)",
  "id" : 580067907058724864,
  "in_reply_to_status_id" : 580045739369328641,
  "created_at" : "2015-03-23 18:05:40 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/WJWHjTfUQ2",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/3-sxswedu-highlights\/",
      "display_url" : "decentralisedteachingandlearning.com\/3-sxswedu-high\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580065828902699009",
  "text" : "3 SXSWedu highlights http:\/\/t.co\/WJWHjTfUQ2",
  "id" : 580065828902699009,
  "created_at" : "2015-03-23 17:57:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason West",
      "screen_name" : "EnglishOutThere",
      "indices" : [ 0, 16 ],
      "id_str" : "66951936",
      "id" : 66951936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579725995353214976",
  "geo" : { },
  "id_str" : "580065112008077312",
  "in_reply_to_user_id" : 66951936,
  "text" : "@EnglishOutThere yr welcome :)",
  "id" : 580065112008077312,
  "in_reply_to_status_id" : 579725995353214976,
  "created_at" : "2015-03-23 17:54:34 +0000",
  "in_reply_to_screen_name" : "EnglishOutThere",
  "in_reply_to_user_id_str" : "66951936",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580050204340183041",
  "geo" : { },
  "id_str" : "580059837842743297",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers firefox can do video chat now; the image via browser was kinda distorted",
  "id" : 580059837842743297,
  "in_reply_to_status_id" : 580050204340183041,
  "created_at" : "2015-03-23 17:33:36 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580046892471611392",
  "geo" : { },
  "id_str" : "580047516596600832",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers hehe can't seem to chat via browser",
  "id" : 580047516596600832,
  "in_reply_to_status_id" : 580046892471611392,
  "created_at" : "2015-03-23 16:44:39 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Dusoulier",
      "screen_name" : "PatrickDusoulie",
      "indices" : [ 3, 19 ],
      "id_str" : "2323011278",
      "id" : 2323011278
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 40, 52 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 21, 39 ]
    }, {
      "text" : "frontnational",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZrWOF3dJTC",
      "expanded_url" : "http:\/\/goo.gl\/1OBzHg",
      "display_url" : "goo.gl\/1OBzHg"
    } ]
  },
  "geo" : { },
  "id_str" : "579902423940112384",
  "text" : "RT @PatrickDusoulie: #corpuslinguistics @TonyMcEnery #frontnational Corpus linguistics methods applied to the Le Pens' speeches : http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 19, 31 ],
        "id_str" : "849729062",
        "id" : 849729062
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 0, 18 ]
      }, {
        "text" : "frontnational",
        "indices" : [ 32, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/ZrWOF3dJTC",
        "expanded_url" : "http:\/\/goo.gl\/1OBzHg",
        "display_url" : "goo.gl\/1OBzHg"
      } ]
    },
    "geo" : { },
    "id_str" : "579695497641893888",
    "text" : "#corpuslinguistics @TonyMcEnery #frontnational Corpus linguistics methods applied to the Le Pens' speeches : http:\/\/t.co\/ZrWOF3dJTC",
    "id" : 579695497641893888,
    "created_at" : "2015-03-22 17:25:51 +0000",
    "user" : {
      "name" : "Patrick Dusoulier",
      "screen_name" : "PatrickDusoulie",
      "protected" : false,
      "id_str" : "2323011278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429933514792783872\/KFFY8tX3_normal.jpeg",
      "id" : 2323011278,
      "verified" : false
    }
  },
  "id" : 579902423940112384,
  "created_at" : "2015-03-23 07:08:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    }, {
      "name" : "James O'Hagan",
      "screen_name" : "jimohagan",
      "indices" : [ 53, 63 ],
      "id_str" : "4060901",
      "id" : 4060901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/KsZkFhxead",
      "expanded_url" : "http:\/\/bit.ly\/1bmbYy2",
      "display_url" : "bit.ly\/1bmbYy2"
    } ]
  },
  "geo" : { },
  "id_str" : "579729790674030592",
  "text" : "RT @mcleod: A Critical Review of Puentedura\u2019s SAMR | @jimohagan http:\/\/t.co\/KsZkFhxead",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James O'Hagan",
        "screen_name" : "jimohagan",
        "indices" : [ 41, 51 ],
        "id_str" : "4060901",
        "id" : 4060901
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/KsZkFhxead",
        "expanded_url" : "http:\/\/bit.ly\/1bmbYy2",
        "display_url" : "bit.ly\/1bmbYy2"
      } ]
    },
    "geo" : { },
    "id_str" : "579658859918278656",
    "text" : "A Critical Review of Puentedura\u2019s SAMR | @jimohagan http:\/\/t.co\/KsZkFhxead",
    "id" : 579658859918278656,
    "created_at" : "2015-03-22 15:00:16 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 579729790674030592,
  "created_at" : "2015-03-22 19:42:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GCHQ",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "privacy",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zwwYRMKzoM",
      "expanded_url" : "http:\/\/ow.ly\/KDkfD",
      "display_url" : "ow.ly\/KDkfD"
    } ]
  },
  "geo" : { },
  "id_str" : "579727803882541057",
  "text" : "RT @patrickDurusau: GCHQ May Be Spying On You! #GCHQ #privacy http:\/\/t.co\/zwwYRMKzoM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GCHQ",
        "indices" : [ 27, 32 ]
      }, {
        "text" : "privacy",
        "indices" : [ 33, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/zwwYRMKzoM",
        "expanded_url" : "http:\/\/ow.ly\/KDkfD",
        "display_url" : "ow.ly\/KDkfD"
      } ]
    },
    "geo" : { },
    "id_str" : "579507937216987136",
    "text" : "GCHQ May Be Spying On You! #GCHQ #privacy http:\/\/t.co\/zwwYRMKzoM",
    "id" : 579507937216987136,
    "created_at" : "2015-03-22 05:00:33 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 579727803882541057,
  "created_at" : "2015-03-22 19:34:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth Hardman",
      "screen_name" : "hardmanken8",
      "indices" : [ 65, 77 ],
      "id_str" : "797513364",
      "id" : 797513364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/91v4R6gaBg",
      "expanded_url" : "http:\/\/wp.me\/p2E1VB-fq",
      "display_url" : "wp.me\/p2E1VB-fq"
    } ]
  },
  "geo" : { },
  "id_str" : "579724953886593026",
  "text" : "Engineering Stories Free This Weekend http:\/\/t.co\/91v4R6gaBg via @hardmanken8",
  "id" : 579724953886593026,
  "created_at" : "2015-03-22 19:22:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579720126213275648",
  "geo" : { },
  "id_str" : "579720485765824512",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha nice :)",
  "id" : 579720485765824512,
  "in_reply_to_status_id" : 579720126213275648,
  "created_at" : "2015-03-22 19:05:09 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579718280878907392",
  "geo" : { },
  "id_str" : "579719760155451392",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha doesn't really apply to blogs more for commercial sites",
  "id" : 579719760155451392,
  "in_reply_to_status_id" : 579718280878907392,
  "created_at" : "2015-03-22 19:02:16 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 78, 93 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/EkCDsM2dNU",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1b5",
      "display_url" : "wp.me\/p3qkCB-1b5"
    } ]
  },
  "geo" : { },
  "id_str" : "579719349948256256",
  "text" : "Ms. Potts and Teaching the Present Perfect  Part 2 http:\/\/t.co\/EkCDsM2dNU via @GeoffreyJordan",
  "id" : 579719349948256256,
  "created_at" : "2015-03-22 19:00:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 10, 20 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/5ka2CUXjPO",
      "expanded_url" : "http:\/\/www.glenys-hanson.info\/pedagogical-articles-pronunciation-spelling\/karaoke-pronunciation\/",
      "display_url" : "glenys-hanson.info\/pedagogical-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579436011853361152",
  "text" : "@hippo016 @HanaTicha another name karoake pronunciation http:\/\/t.co\/5ka2CUXjPO :)",
  "id" : 579436011853361152,
  "created_at" : "2015-03-22 00:14:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579235961537740800",
  "geo" : { },
  "id_str" : "579392339774464000",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp have u thought about settings saved automatically on quitting program?",
  "id" : 579392339774464000,
  "in_reply_to_status_id" : 579235961537740800,
  "created_at" : "2015-03-21 21:21:13 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579386585285857281",
  "geo" : { },
  "id_str" : "579386730639441920",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski yeah also called think-aloud protocol",
  "id" : 579386730639441920,
  "in_reply_to_status_id" : 579386585285857281,
  "created_at" : "2015-03-21 20:58:55 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579378786078167040",
  "geo" : { },
  "id_str" : "579385442841280512",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski sure i liked the verbal protocol feel to the post, def need to trial stuff more myself before inflicting students :)",
  "id" : 579385442841280512,
  "in_reply_to_status_id" : 579378786078167040,
  "created_at" : "2015-03-21 20:53:48 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/TRr6E934LS",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/03\/the-truth-they-dont-want-you-to-read.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/03\/the-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579384628005511169",
  "text" : "RT @pchallinor: New mudgeonry: The truth they don't want you to read http:\/\/t.co\/TRr6E934LS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/TRr6E934LS",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/03\/the-truth-they-dont-want-you-to-read.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/03\/the-tr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577900872925065216",
    "text" : "New mudgeonry: The truth they don't want you to read http:\/\/t.co\/TRr6E934LS",
    "id" : 577900872925065216,
    "created_at" : "2015-03-17 18:34:39 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 579384628005511169,
  "created_at" : "2015-03-21 20:50:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/o1i5MlM3LY",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/03\/06\/grassroots-language-technology-paul-raine-apps4efl\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/03\/06\/gra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "579255967080136704",
  "geo" : { },
  "id_str" : "579381794958524416",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha forgot to add u can read interview with apps4efl developer https:\/\/t.co\/o1i5MlM3LY",
  "id" : 579381794958524416,
  "in_reply_to_status_id" : 579255967080136704,
  "created_at" : "2015-03-21 20:39:18 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 47, 56 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/5f8PG56HmB",
      "expanded_url" : "http:\/\/wp.me\/p3MdWw-cl",
      "display_url" : "wp.me\/p3MdWw-cl"
    } ]
  },
  "geo" : { },
  "id_str" : "579378671095570434",
  "text" : "Revising KWL Charts http:\/\/t.co\/5f8PG56HmB via @Ashowski",
  "id" : 579378671095570434,
  "created_at" : "2015-03-21 20:26:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 47, 54 ],
      "id_str" : "704177088",
      "id" : 704177088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/hk1M0DPvih",
      "expanded_url" : "http:\/\/wp.me\/P24Rm0-a9",
      "display_url" : "wp.me\/P24Rm0-a9"
    } ]
  },
  "geo" : { },
  "id_str" : "579281032203120640",
  "text" : "League of Explorers http:\/\/t.co\/hk1M0DPvih via @dBr_wn",
  "id" : 579281032203120640,
  "created_at" : "2015-03-21 13:58:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579235961537740800",
  "geo" : { },
  "id_str" : "579275083065212928",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp nice :), is there a list of new features for next version somewhere?",
  "id" : 579275083065212928,
  "in_reply_to_status_id" : 579235961537740800,
  "created_at" : "2015-03-21 13:35:16 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9rrRcvwqcb",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/03\/21\/doxxing\/",
      "display_url" : "hackeducation.com\/2015\/03\/21\/dox\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579271807431258112",
  "text" : "RT @audreywatters: I gotta edit this way more but fuck those people who want to justify doxxing as a strategy in edu http:\/\/t.co\/9rrRcvwqcb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/9rrRcvwqcb",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/03\/21\/doxxing\/",
        "display_url" : "hackeducation.com\/2015\/03\/21\/dox\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "579192235662557184",
    "text" : "I gotta edit this way more but fuck those people who want to justify doxxing as a strategy in edu http:\/\/t.co\/9rrRcvwqcb",
    "id" : 579192235662557184,
    "created_at" : "2015-03-21 08:06:04 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 579271807431258112,
  "created_at" : "2015-03-21 13:22:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579255967080136704",
  "geo" : { },
  "id_str" : "579258474376351744",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha a pleasure have a good Sat :)",
  "id" : 579258474376351744,
  "in_reply_to_status_id" : 579255967080136704,
  "created_at" : "2015-03-21 12:29:17 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5a1Znh3FVW",
      "expanded_url" : "http:\/\/www.apps4efl.com\/",
      "display_url" : "apps4efl.com"
    } ]
  },
  "in_reply_to_status_id_str" : "579241437847547904",
  "geo" : { },
  "id_str" : "579252293029228544",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha hi do you know apps4efl? another very useful free site by another teacher from Japan http:\/\/t.co\/5a1Znh3FVW",
  "id" : 579252293029228544,
  "in_reply_to_status_id" : 579241437847547904,
  "created_at" : "2015-03-21 12:04:43 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/2FvBh9WazS",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/03\/dream-reader.html",
      "display_url" : "how-i-see-it-now.blogspot.com\/2015\/03\/dream-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579251773438877696",
  "text" : "RT @HanaTicha: Just blogged: Dream Reader  http:\/\/t.co\/2FvBh9WazS &gt; sharing a useful website with some useful tips (hopefully) on how to us\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/2FvBh9WazS",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/03\/dream-reader.html",
        "display_url" : "how-i-see-it-now.blogspot.com\/2015\/03\/dream-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "579241437847547904",
    "text" : "Just blogged: Dream Reader  http:\/\/t.co\/2FvBh9WazS &gt; sharing a useful website with some useful tips (hopefully) on how to use it.",
    "id" : 579241437847547904,
    "created_at" : "2015-03-21 11:21:35 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 579251773438877696,
  "created_at" : "2015-03-21 12:02:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579211512679661568",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp hi is there a recent open file function in forthcoming antconc?",
  "id" : 579211512679661568,
  "created_at" : "2015-03-21 09:22:40 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 98, 106 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/x4dmzbCGUr",
      "expanded_url" : "https:\/\/youtu.be\/fFNCRPl_L_Y",
      "display_url" : "youtu.be\/fFNCRPl_L_Y"
    } ]
  },
  "geo" : { },
  "id_str" : "579206597555183616",
  "text" : "What's The Problem With Comic Relief? Russell Brand The Trews (E281): https:\/\/t.co\/x4dmzbCGUr via @YouTube",
  "id" : 579206597555183616,
  "created_at" : "2015-03-21 09:03:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Cxe7SFy0gh",
      "expanded_url" : "http:\/\/www.crlt.umich.edu\/gsis\/p2_5",
      "display_url" : "crlt.umich.edu\/gsis\/p2_5"
    } ]
  },
  "geo" : { },
  "id_str" : "579200018416078848",
  "text" : "RT @TESOLacademic: Some generic strategies for effective lesson planning http:\/\/t.co\/Cxe7SFy0gh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/Cxe7SFy0gh",
        "expanded_url" : "http:\/\/www.crlt.umich.edu\/gsis\/p2_5",
        "display_url" : "crlt.umich.edu\/gsis\/p2_5"
      } ]
    },
    "geo" : { },
    "id_str" : "578202094764732416",
    "text" : "Some generic strategies for effective lesson planning http:\/\/t.co\/Cxe7SFy0gh",
    "id" : 578202094764732416,
    "created_at" : "2015-03-18 14:31:36 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 579200018416078848,
  "created_at" : "2015-03-21 08:37:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 3, 18 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/hm3BtFGC0r",
      "expanded_url" : "http:\/\/goo.gl\/RITKS7",
      "display_url" : "goo.gl\/RITKS7"
    } ]
  },
  "geo" : { },
  "id_str" : "579191309791064064",
  "text" : "RT @dreadnought001: http:\/\/t.co\/hm3BtFGC0r linguistics expert explains best way to learn language in info age",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klinkerapps.com\" rel=\"nofollow\"\u003ETalon (Classic)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/hm3BtFGC0r",
        "expanded_url" : "http:\/\/goo.gl\/RITKS7",
        "display_url" : "goo.gl\/RITKS7"
      } ]
    },
    "geo" : { },
    "id_str" : "579152382757588992",
    "text" : "http:\/\/t.co\/hm3BtFGC0r linguistics expert explains best way to learn language in info age",
    "id" : 579152382757588992,
    "created_at" : "2015-03-21 05:27:42 +0000",
    "user" : {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "protected" : false,
      "id_str" : "83207734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503606579573178370\/GqHxIpPe_normal.jpeg",
      "id" : 83207734,
      "verified" : false
    }
  },
  "id" : 579191309791064064,
  "created_at" : "2015-03-21 08:02:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/EAzUIh4j7o",
      "expanded_url" : "http:\/\/yohasebe.com\/tcse\/",
      "display_url" : "yohasebe.com\/tcse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "579045072865492993",
  "text" : "Ted Corpus Search Engine now includes a number of translations as well as search via url http:\/\/t.co\/EAzUIh4j7o #corpuslinguistics",
  "id" : 579045072865492993,
  "created_at" : "2015-03-20 22:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/K4NDQRdYQr",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/antconc\/",
      "display_url" : "laurenceanthony.net\/software\/antco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578996420012843009",
  "text" : "RT @antlabjp: For anyone who wants to do keyword lists in AntConc against the BNC, a BNC reference word list is now available at http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/K4NDQRdYQr",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/antconc\/",
        "display_url" : "laurenceanthony.net\/software\/antco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578990998782636033",
    "text" : "For anyone who wants to do keyword lists in AntConc against the BNC, a BNC reference word list is now available at http:\/\/t.co\/K4NDQRdYQr",
    "id" : 578990998782636033,
    "created_at" : "2015-03-20 18:46:25 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 578996420012843009,
  "created_at" : "2015-03-20 19:07:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/CtbwJ64i1y",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2015\/03\/lost-in-translation.html",
      "display_url" : "giaklamata.blogspot.fr\/2015\/03\/lost-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578996269806436353",
  "text" : "Lost in Translation http:\/\/t.co\/CtbwJ64i1y",
  "id" : 578996269806436353,
  "created_at" : "2015-03-20 19:07:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/2Ad4sHhzTz",
      "expanded_url" : "http:\/\/eepurl.com\/bhyn3r",
      "display_url" : "eepurl.com\/bhyn3r"
    } ]
  },
  "geo" : { },
  "id_str" : "578987862756052992",
  "text" : "RT @lovermob: Why not record this weekend?: http:\/\/t.co\/2Ad4sHhzTz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/2Ad4sHhzTz",
        "expanded_url" : "http:\/\/eepurl.com\/bhyn3r",
        "display_url" : "eepurl.com\/bhyn3r"
      } ]
    },
    "geo" : { },
    "id_str" : "578979419445968897",
    "text" : "Why not record this weekend?: http:\/\/t.co\/2Ad4sHhzTz",
    "id" : 578979419445968897,
    "created_at" : "2015-03-20 18:00:25 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 578987862756052992,
  "created_at" : "2015-03-20 18:33:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "indices" : [ 0, 9 ],
      "id_str" : "21451640",
      "id" : 21451640
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 10, 21 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/UUKuq3ve9r",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/UeANcr79eVr",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "578247081128800256",
  "geo" : { },
  "id_str" : "578976048911642624",
  "in_reply_to_user_id" : 21451640,
  "text" : "@WrightDW @heatherfro hi to make future lists compatible with antconc you could have a read of this https:\/\/t.co\/UUKuq3ve9r",
  "id" : 578976048911642624,
  "in_reply_to_status_id" : 578247081128800256,
  "created_at" : "2015-03-20 17:47:01 +0000",
  "in_reply_to_screen_name" : "WrightDW",
  "in_reply_to_user_id_str" : "21451640",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Carl Packman)))",
      "screen_name" : "CarlPackman",
      "indices" : [ 3, 15 ],
      "id_str" : "56486253",
      "id" : 56486253
    }, {
      "name" : "Andrew McGettigan",
      "screen_name" : "amcgettigan",
      "indices" : [ 47, 59 ],
      "id_str" : "260875567",
      "id" : 260875567
    }, {
      "name" : "London Review (LRB)",
      "screen_name" : "LRB",
      "indices" : [ 62, 66 ],
      "id_str" : "23975060",
      "id" : 23975060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longreads",
      "indices" : [ 103, 113 ]
    }, {
      "text" : "rethinkrecovery",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/H8sWfoyV9t",
      "expanded_url" : "http:\/\/www.lrb.co.uk\/v37\/n05\/andrew-mcgettigan\/cash-today",
      "display_url" : "lrb.co.uk\/v37\/n05\/andrew\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578940809011191808",
  "text" : "RT @CarlPackman: If you haven't read it,here's @amcgettigan's @LRB article on student loans. Fantastic #longreads #rethinkrecovery http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew McGettigan",
        "screen_name" : "amcgettigan",
        "indices" : [ 30, 42 ],
        "id_str" : "260875567",
        "id" : 260875567
      }, {
        "name" : "London Review (LRB)",
        "screen_name" : "LRB",
        "indices" : [ 45, 49 ],
        "id_str" : "23975060",
        "id" : 23975060
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "longreads",
        "indices" : [ 86, 96 ]
      }, {
        "text" : "rethinkrecovery",
        "indices" : [ 97, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/H8sWfoyV9t",
        "expanded_url" : "http:\/\/www.lrb.co.uk\/v37\/n05\/andrew-mcgettigan\/cash-today",
        "display_url" : "lrb.co.uk\/v37\/n05\/andrew\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578925368951861248",
    "text" : "If you haven't read it,here's @amcgettigan's @LRB article on student loans. Fantastic #longreads #rethinkrecovery http:\/\/t.co\/H8sWfoyV9t",
    "id" : 578925368951861248,
    "created_at" : "2015-03-20 14:25:38 +0000",
    "user" : {
      "name" : "(((Carl Packman)))",
      "screen_name" : "CarlPackman",
      "protected" : false,
      "id_str" : "56486253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729695634199023620\/ZtqnkRrt_normal.jpg",
      "id" : 56486253,
      "verified" : false
    }
  },
  "id" : 578940809011191808,
  "created_at" : "2015-03-20 15:26:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 3, 14 ],
      "id_str" : "18880320",
      "id" : 18880320
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 82, 93 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/578233305989914625\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2FczOPVn5i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZMIKNUsAAMn9F.jpg",
      "id_str" : "578233305226588160",
      "id" : 578233305226588160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZMIKNUsAAMn9F.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2FczOPVn5i"
    } ],
    "hashtags" : [ {
      "text" : "iTDI",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IfFWN9Z4wS",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/",
      "display_url" : "itdi.pro\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "578930136084557824",
  "text" : "RT @chucksandy: Read the lastest #iTDI Blog issue yet? It's pretty great. Curator @kevchanwow's got the knack! http:\/\/t.co\/IfFWN9Z4wS http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 66, 77 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/578233305989914625\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2FczOPVn5i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZMIKNUsAAMn9F.jpg",
        "id_str" : "578233305226588160",
        "id" : 578233305226588160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZMIKNUsAAMn9F.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2FczOPVn5i"
      } ],
      "hashtags" : [ {
        "text" : "iTDI",
        "indices" : [ 17, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/IfFWN9Z4wS",
        "expanded_url" : "http:\/\/itdi.pro\/blog\/",
        "display_url" : "itdi.pro\/blog\/"
      } ]
    },
    "geo" : { },
    "id_str" : "578233305989914625",
    "text" : "Read the lastest #iTDI Blog issue yet? It's pretty great. Curator @kevchanwow's got the knack! http:\/\/t.co\/IfFWN9Z4wS http:\/\/t.co\/2FczOPVn5i",
    "id" : 578233305989914625,
    "created_at" : "2015-03-18 16:35:37 +0000",
    "user" : {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "protected" : false,
      "id_str" : "18880320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620217802465513472\/poN-d2nR_normal.jpg",
      "id" : 18880320,
      "verified" : false
    }
  },
  "id" : 578930136084557824,
  "created_at" : "2015-03-20 14:44:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 74, 90 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/4lpToHWl4h",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-JU",
      "display_url" : "wp.me\/pbMLY-JU"
    } ]
  },
  "geo" : { },
  "id_str" : "578918160461639680",
  "text" : "Complexity Thinking in German Englischdidaktik http:\/\/t.co\/4lpToHWl4h via @wordpressdotcom",
  "id" : 578918160461639680,
  "created_at" : "2015-03-20 13:56:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Almude\u03B7\u03B1 Fern\u00E1nde\u0225",
      "screen_name" : "almudena_fdez",
      "indices" : [ 0, 14 ],
      "id_str" : "70230255",
      "id" : 70230255
    }, {
      "name" : "Andrea Ramirez",
      "screen_name" : "Andrea_Ramiort",
      "indices" : [ 15, 30 ],
      "id_str" : "340222006",
      "id" : 340222006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "578895020595523584",
  "geo" : { },
  "id_str" : "578897069248770048",
  "in_reply_to_user_id" : 70230255,
  "text" : "@almudena_fdez @Andrea_Ramiort hehe great :) maybe next one could use most frequent uses and meanings of get? http:\/\/t.co\/feVV1F8lKr",
  "id" : 578897069248770048,
  "in_reply_to_status_id" : 578895020595523584,
  "created_at" : "2015-03-20 12:33:11 +0000",
  "in_reply_to_screen_name" : "almudena_fdez",
  "in_reply_to_user_id_str" : "70230255",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 106, 112 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/TEcZFo9BT0",
      "expanded_url" : "http:\/\/www.salon.com\/2014\/03\/05\/teaching_with_strep_throat_and_working_in_fear_kaplan_courses_ugly_underside\/",
      "display_url" : "salon.com\/2014\/03\/05\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578892654571835392",
  "text" : "Teaching with strep throat and working in fear: Kaplan course\u2019s ugly underside http:\/\/t.co\/TEcZFo9BT0 via @Salon",
  "id" : 578892654571835392,
  "created_at" : "2015-03-20 12:15:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Worgan",
      "screen_name" : "michelleworgan",
      "indices" : [ 0, 15 ],
      "id_str" : "20764799",
      "id" : 20764799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578701233604702208",
  "in_reply_to_user_id" : 20764799,
  "text" : "@michelleworgan hi could i DM u regarding your phrasal verb stories? thx",
  "id" : 578701233604702208,
  "created_at" : "2015-03-19 23:35:00 +0000",
  "in_reply_to_screen_name" : "michelleworgan",
  "in_reply_to_user_id_str" : "20764799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578683613111300097",
  "geo" : { },
  "id_str" : "578684965698854912",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona also was i blinded by my usual dealings with anglo academics to international comm issues",
  "id" : 578684965698854912,
  "in_reply_to_status_id" : 578683613111300097,
  "created_at" : "2015-03-19 22:30:21 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578683613111300097",
  "geo" : { },
  "id_str" : "578684788317519874",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona  got some advice from someone in Italy, aparently politeness in emails in Italy academia somewhat sensitive",
  "id" : 578684788317519874,
  "in_reply_to_status_id" : 578683613111300097,
  "created_at" : "2015-03-19 22:29:39 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/2wClFLBBTl",
      "expanded_url" : "http:\/\/ow.ly\/KugZU",
      "display_url" : "ow.ly\/KugZU"
    } ]
  },
  "geo" : { },
  "id_str" : "578660829735841792",
  "text" : "RT @umasslinguistic: The word is the crime http:\/\/t.co\/2wClFLBBTl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/2wClFLBBTl",
        "expanded_url" : "http:\/\/ow.ly\/KugZU",
        "display_url" : "ow.ly\/KugZU"
      } ]
    },
    "geo" : { },
    "id_str" : "578659797446328321",
    "text" : "The word is the crime http:\/\/t.co\/2wClFLBBTl",
    "id" : 578659797446328321,
    "created_at" : "2015-03-19 20:50:21 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 578660829735841792,
  "created_at" : "2015-03-19 20:54:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578656754130620417",
  "text" : "got the paper though so silver lining and all :)",
  "id" : 578656754130620417,
  "created_at" : "2015-03-19 20:38:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578656640695705600",
  "text" : "I am really surprised by your incerdibly poor knowledge of the basics of\ne-mail corresponding with a stranger.",
  "id" : 578656640695705600,
  "created_at" : "2015-03-19 20:37:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578656616893001728",
  "text" : "blimey been told off fr improper email etiquette after requesting a paper from Italian academic, yet to get details, telling off follows:",
  "id" : 578656616893001728,
  "created_at" : "2015-03-19 20:37:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Gillett",
      "screen_name" : "UEfAP",
      "indices" : [ 3, 9 ],
      "id_str" : "235529625",
      "id" : 235529625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/pqt8YwLNkT",
      "expanded_url" : "http:\/\/UEfAP.com",
      "display_url" : "UEfAP.com"
    }, {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/DceZ3HslF4",
      "expanded_url" : "http:\/\/www.uefap.net",
      "display_url" : "uefap.net"
    } ]
  },
  "geo" : { },
  "id_str" : "578572367129104384",
  "text" : "RT @UEfAP: New version of http:\/\/t.co\/pqt8YwLNkT at http:\/\/t.co\/DceZ3HslF4 Works better on smartphones and tablets. Feedback would be appre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/pqt8YwLNkT",
        "expanded_url" : "http:\/\/UEfAP.com",
        "display_url" : "UEfAP.com"
      }, {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/DceZ3HslF4",
        "expanded_url" : "http:\/\/www.uefap.net",
        "display_url" : "uefap.net"
      } ]
    },
    "geo" : { },
    "id_str" : "578233861156544512",
    "text" : "New version of http:\/\/t.co\/pqt8YwLNkT at http:\/\/t.co\/DceZ3HslF4 Works better on smartphones and tablets. Feedback would be appreciated.",
    "id" : 578233861156544512,
    "created_at" : "2015-03-18 16:37:50 +0000",
    "user" : {
      "name" : "Andy Gillett",
      "screen_name" : "UEfAP",
      "protected" : false,
      "id_str" : "235529625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1210092848\/uefap_512_normal.png",
      "id" : 235529625,
      "verified" : false
    }
  },
  "id" : 578572367129104384,
  "created_at" : "2015-03-19 15:02:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 42, 49 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL2015",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578569985494245376",
  "text" : "RT @lexicojules: A request to prep for my @MaWSIG PCE talk on corpus tools 4 ELT writers: What language question would you like to ask a co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MaWSIG",
        "screen_name" : "MaWSIG",
        "indices" : [ 25, 32 ],
        "id_str" : "1096618700",
        "id" : 1096618700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL2015",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575226285875687424",
    "text" : "A request to prep for my @MaWSIG PCE talk on corpus tools 4 ELT writers: What language question would you like to ask a corpus? #IATEFL2015",
    "id" : 575226285875687424,
    "created_at" : "2015-03-10 09:26:48 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 578569985494245376,
  "created_at" : "2015-03-19 14:53:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAP",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "tleap",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HH6ZGOzQGt",
      "expanded_url" : "http:\/\/ow.ly\/KsKzT",
      "display_url" : "ow.ly\/KsKzT"
    } ]
  },
  "geo" : { },
  "id_str" : "578569776815071232",
  "text" : "RT @lexicojules: A new wordy blog post about 'suggest' as a reporting verb - tentative or as confident as you dare? #EAP #tleap http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAP",
        "indices" : [ 99, 103 ]
      }, {
        "text" : "tleap",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/HH6ZGOzQGt",
        "expanded_url" : "http:\/\/ow.ly\/KsKzT",
        "display_url" : "ow.ly\/KsKzT"
      } ]
    },
    "geo" : { },
    "id_str" : "577951981391720448",
    "text" : "A new wordy blog post about 'suggest' as a reporting verb - tentative or as confident as you dare? #EAP #tleap http:\/\/t.co\/HH6ZGOzQGt",
    "id" : 577951981391720448,
    "created_at" : "2015-03-17 21:57:44 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 578569776815071232,
  "created_at" : "2015-03-19 14:52:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Dale",
      "screen_name" : "joedale",
      "indices" : [ 0, 8 ],
      "id_str" : "5923092",
      "id" : 5923092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578500833953890304",
  "geo" : { },
  "id_str" : "578507865385742336",
  "in_reply_to_user_id" : 5923092,
  "text" : "@joedale hi are u aware of any papers looking at current policy with failed policy of teaching French at primary level in the 1960s?",
  "id" : 578507865385742336,
  "in_reply_to_status_id" : 578500833953890304,
  "created_at" : "2015-03-19 10:46:37 +0000",
  "in_reply_to_screen_name" : "joedale",
  "in_reply_to_user_id_str" : "5923092",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578487134996316160",
  "geo" : { },
  "id_str" : "578487969708941312",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava from quick go, looks like BYU needs a decent proper-noun tagger :)",
  "id" : 578487969708941312,
  "in_reply_to_status_id" : 578487134996316160,
  "created_at" : "2015-03-19 09:27:34 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Eu0Xsf0CHL",
      "expanded_url" : "http:\/\/corpus.byu.edu\/crowdsourcing.asp",
      "display_url" : "corpus.byu.edu\/crowdsourcing.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578487134996316160",
  "text" : "help to annotate TV subtitles and\/or fill short survey on #corpuslinguistics tools from BYU and teaching http:\/\/t.co\/Eu0Xsf0CHL",
  "id" : 578487134996316160,
  "created_at" : "2015-03-19 09:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578466622219890688",
  "geo" : { },
  "id_str" : "578475705287196672",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway if u use defaut settings should work, it bugs if u select Display network between co-occuring words.",
  "id" : 578475705287196672,
  "in_reply_to_status_id" : 578466622219890688,
  "created_at" : "2015-03-19 08:38:50 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "indices" : [ 24, 33 ],
      "id_str" : "21451640",
      "id" : 21451640
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/578451164255141888\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/AyzAFcOkGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAcSRLPWUAALBrn.png",
      "id_str" : "578451163424641024",
      "id" : 578451163424641024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAcSRLPWUAALBrn.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/AyzAFcOkGu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/95eyTgCdXJ",
      "expanded_url" : "http:\/\/nickbeauchamp.com\/projects\/plotmapper.php",
      "display_url" : "nickbeauchamp.com\/projects\/plotm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "578307059638263808",
  "geo" : { },
  "id_str" : "578451164255141888",
  "in_reply_to_user_id" : 21451640,
  "text" : "another angle on speech @WrightDW using http:\/\/t.co\/95eyTgCdXJ http:\/\/t.co\/AyzAFcOkGu",
  "id" : 578451164255141888,
  "in_reply_to_status_id" : 578307059638263808,
  "created_at" : "2015-03-19 07:01:19 +0000",
  "in_reply_to_screen_name" : "WrightDW",
  "in_reply_to_user_id_str" : "21451640",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "indices" : [ 3, 12 ],
      "id_str" : "21451640",
      "id" : 21451640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 31, 38 ]
    }, {
      "text" : "budget",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/DbzfFKGF80",
      "expanded_url" : "http:\/\/goo.gl\/iz0Le0",
      "display_url" : "goo.gl\/iz0Le0"
    } ]
  },
  "geo" : { },
  "id_str" : "578328383353929728",
  "text" : "RT @WrightDW: New blog post: A #corpus analysis of today's #budget speech. How does it compare with Osborne's other budgets? http:\/\/t.co\/Db\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "budget",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/DbzfFKGF80",
        "expanded_url" : "http:\/\/goo.gl\/iz0Le0",
        "display_url" : "goo.gl\/iz0Le0"
      } ]
    },
    "geo" : { },
    "id_str" : "578307059638263808",
    "text" : "New blog post: A #corpus analysis of today's #budget speech. How does it compare with Osborne's other budgets? http:\/\/t.co\/DbzfFKGF80",
    "id" : 578307059638263808,
    "created_at" : "2015-03-18 21:28:42 +0000",
    "user" : {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "protected" : false,
      "id_str" : "21451640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640879905828413441\/nAGX4y8Z_normal.jpg",
      "id" : 21451640,
      "verified" : false
    }
  },
  "id" : 578328383353929728,
  "created_at" : "2015-03-18 22:53:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 0, 9 ],
      "id_str" : "364412485",
      "id" : 364412485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578226089866215424",
  "geo" : { },
  "id_str" : "578233272423096320",
  "in_reply_to_user_id" : 364412485,
  "text" : "@_dr_kim_ pleasure thks for post :)",
  "id" : 578233272423096320,
  "in_reply_to_status_id" : 578226089866215424,
  "created_at" : "2015-03-18 16:35:29 +0000",
  "in_reply_to_screen_name" : "_dr_kim_",
  "in_reply_to_user_id_str" : "364412485",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 97, 106 ],
      "id_str" : "364412485",
      "id" : 364412485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/EPfKsWfw91",
      "expanded_url" : "http:\/\/wp.me\/p2upSM-1CE",
      "display_url" : "wp.me\/p2upSM-1CE"
    } ]
  },
  "geo" : { },
  "id_str" : "578217512514547712",
  "text" : "Learn to analyze a workplace audience to deliver an effective message http:\/\/t.co\/EPfKsWfw91 via @_dr_kim_",
  "id" : 578217512514547712,
  "created_at" : "2015-03-18 15:32:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/O9C2mSXt94",
      "expanded_url" : "http:\/\/www.reelapp.com\/970fcc#1",
      "display_url" : "reelapp.com\/970fcc#1"
    } ]
  },
  "geo" : { },
  "id_str" : "578209887475339264",
  "text" : "anyone ever heard of this seemingly aborted conf? http:\/\/t.co\/O9C2mSXt94 :)",
  "id" : 578209887475339264,
  "created_at" : "2015-03-18 15:02:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 52, 58 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/Rc7vrJZKcD",
      "expanded_url" : "http:\/\/www.apprendreaapprendre.com\/tests\/index.php",
      "display_url" : "apprendreaapprendre.com\/tests\/index.php"
    } ]
  },
  "geo" : { },
  "id_str" : "578179740290408448",
  "text" : "Learning styles in France http:\/\/t.co\/Rc7vrJZKcD cc @ebefl",
  "id" : 578179740290408448,
  "created_at" : "2015-03-18 13:02:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1LmKa7gSTG",
      "expanded_url" : "http:\/\/www.numerama.com\/magazine\/32516-moi-censure-par-la-france-pour-mes-opinions-politiques.html",
      "display_url" : "numerama.com\/magazine\/32516\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578164905746006016",
  "text" : "RT @ggreenwald: Creator of website banned by France denies charges - in healthy countries, this happens in court, *before punishment http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/1LmKa7gSTG",
        "expanded_url" : "http:\/\/www.numerama.com\/magazine\/32516-moi-censure-par-la-france-pour-mes-opinions-politiques.html",
        "display_url" : "numerama.com\/magazine\/32516\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578161899520536576",
    "text" : "Creator of website banned by France denies charges - in healthy countries, this happens in court, *before punishment http:\/\/t.co\/1LmKa7gSTG",
    "id" : 578161899520536576,
    "created_at" : "2015-03-18 11:51:53 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 578164905746006016,
  "created_at" : "2015-03-18 12:03:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sri Lanka Campaign",
      "screen_name" : "SLcampaign",
      "indices" : [ 3, 14 ],
      "id_str" : "150971374",
      "id" : 150971374
    }, {
      "name" : "Gardiner Harris",
      "screen_name" : "GardinerHarris",
      "indices" : [ 74, 89 ],
      "id_str" : "317176953",
      "id" : 317176953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jxX0D4nwno",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/03\/16\/world\/asia\/sri-lankas-tamil-minority-grows-impatient-with-just-promises.html?ref=world&_r=0",
      "display_url" : "nytimes.com\/2015\/03\/16\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578164558604447744",
  "text" : "RT @SLcampaign: \"You visited my land? How did it look?\" Evictees speak to @GardinerHarris about SL military's ongoing grip of North http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gardiner Harris",
        "screen_name" : "GardinerHarris",
        "indices" : [ 58, 73 ],
        "id_str" : "317176953",
        "id" : 317176953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/jxX0D4nwno",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/03\/16\/world\/asia\/sri-lankas-tamil-minority-grows-impatient-with-just-promises.html?ref=world&_r=0",
        "display_url" : "nytimes.com\/2015\/03\/16\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578162705544138752",
    "text" : "\"You visited my land? How did it look?\" Evictees speak to @GardinerHarris about SL military's ongoing grip of North http:\/\/t.co\/jxX0D4nwno",
    "id" : 578162705544138752,
    "created_at" : "2015-03-18 11:55:05 +0000",
    "user" : {
      "name" : "Sri Lanka Campaign",
      "screen_name" : "SLcampaign",
      "protected" : false,
      "id_str" : "150971374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000759053596\/11c386ded730b635978067d73567de91_normal.jpeg",
      "id" : 150971374,
      "verified" : false
    }
  },
  "id" : 578164558604447744,
  "created_at" : "2015-03-18 12:02:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CP MacLochlainn",
      "screen_name" : "CPMacL2008",
      "indices" : [ 3, 14 ],
      "id_str" : "733617661",
      "id" : 733617661
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 139, 140 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/578121567214800896\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/7pkUn69SyO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAXmgD8VEAE9VRT.png",
      "id_str" : "578121565675524097",
      "id" : 578121565675524097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAXmgD8VEAE9VRT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7pkUn69SyO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Su3qrnFSvP",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/789-love-for-libya-2011-2015.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578164155728969728",
  "text" : "RT @CPMacL2008: Britain's Love For Libya: 2011-2015 http:\/\/t.co\/Su3qrnFSvP http:\/\/t.co\/7pkUn69SyO The usual brilliant analysis from the fel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 128, 138 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/578121567214800896\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/7pkUn69SyO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAXmgD8VEAE9VRT.png",
        "id_str" : "578121565675524097",
        "id" : 578121565675524097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAXmgD8VEAE9VRT.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7pkUn69SyO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/Su3qrnFSvP",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/789-love-for-libya-2011-2015.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578163253366362112",
    "text" : "Britain's Love For Libya: 2011-2015 http:\/\/t.co\/Su3qrnFSvP http:\/\/t.co\/7pkUn69SyO The usual brilliant analysis from the fella's @medialens",
    "id" : 578163253366362112,
    "created_at" : "2015-03-18 11:57:16 +0000",
    "user" : {
      "name" : "CP MacLochlainn",
      "screen_name" : "CPMacL2008",
      "protected" : false,
      "id_str" : "733617661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000304978111\/63fba6721445c3d5b93a8e390735abae_normal.jpeg",
      "id" : 733617661,
      "verified" : false
    }
  },
  "id" : 578164155728969728,
  "created_at" : "2015-03-18 12:00:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 119, 133 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/B4cQa4lgLl",
      "expanded_url" : "http:\/\/bit.ly\/1O4T6me",
      "display_url" : "bit.ly\/1O4T6me"
    } ]
  },
  "geo" : { },
  "id_str" : "578102569316147201",
  "text" : "RT @tornhalves: Education going digital and lifting whole chapters from Orwell: School as Panopticon. Nowhere to hide. @audreywatters http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 103, 117 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/B4cQa4lgLl",
        "expanded_url" : "http:\/\/bit.ly\/1O4T6me",
        "display_url" : "bit.ly\/1O4T6me"
      } ]
    },
    "geo" : { },
    "id_str" : "578100281679859713",
    "text" : "Education going digital and lifting whole chapters from Orwell: School as Panopticon. Nowhere to hide. @audreywatters http:\/\/t.co\/B4cQa4lgLl",
    "id" : 578100281679859713,
    "created_at" : "2015-03-18 07:47:02 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 578102569316147201,
  "created_at" : "2015-03-18 07:56:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 76, 92 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/wn8JETws4v",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-Dm",
      "display_url" : "wp.me\/p25Kfd-Dm"
    } ]
  },
  "geo" : { },
  "id_str" : "578101266959609856",
  "text" : "An interview with Neil Millington of Dreamreader http:\/\/t.co\/wn8JETws4v via @michaelegriffin",
  "id" : 578101266959609856,
  "created_at" : "2015-03-18 07:50:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/7x05c9SfJy",
      "expanded_url" : "https:\/\/youtu.be\/16N22K06Hto",
      "display_url" : "youtu.be\/16N22K06Hto"
    } ]
  },
  "geo" : { },
  "id_str" : "578027685231898624",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet possible marketing angle? https:\/\/t.co\/7x05c9SfJy :)",
  "id" : 578027685231898624,
  "created_at" : "2015-03-18 02:58:34 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/rBnkLjLbXY",
      "expanded_url" : "http:\/\/gu.com\/p\/46kgt\/stw",
      "display_url" : "gu.com\/p\/46kgt\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "577982916191502336",
  "text" : "UN officials accused of bowing to Israeli pressure over children's rights list http:\/\/t.co\/rBnkLjLbXY",
  "id" : 577982916191502336,
  "created_at" : "2015-03-18 00:00:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "indices" : [ 3, 11 ],
      "id_str" : "96139902",
      "id" : 96139902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldaily",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/GZIuvG53Bn",
      "expanded_url" : "http:\/\/www.downes.ca\/post\/63539",
      "display_url" : "downes.ca\/post\/63539"
    } ]
  },
  "geo" : { },
  "id_str" : "577968029486739457",
  "text" : "RT @oldaily: Zuckerberg and Gates-Backed Startup Seeks To Shake Up African Education #oldaily http:\/\/t.co\/GZIuvG53Bn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.downes.ca\" rel=\"nofollow\"\u003EOLDaily\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oldaily",
        "indices" : [ 72, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/GZIuvG53Bn",
        "expanded_url" : "http:\/\/www.downes.ca\/post\/63539",
        "display_url" : "downes.ca\/post\/63539"
      } ]
    },
    "geo" : { },
    "id_str" : "577797555842486272",
    "text" : "Zuckerberg and Gates-Backed Startup Seeks To Shake Up African Education #oldaily http:\/\/t.co\/GZIuvG53Bn",
    "id" : 577797555842486272,
    "created_at" : "2015-03-17 11:44:06 +0000",
    "user" : {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "protected" : false,
      "id_str" : "96139902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000106238229\/f8a550530e001b52581340d3e3d8e60c_normal.jpeg",
      "id" : 96139902,
      "verified" : false
    }
  },
  "id" : 577968029486739457,
  "created_at" : "2015-03-17 23:01:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Rolin Moe",
      "screen_name" : "RMoeJo",
      "indices" : [ 8, 15 ],
      "id_str" : "170832237",
      "id" : 170832237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577928171862908929",
  "geo" : { },
  "id_str" : "577965144082399232",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden @RMoeJo yeah recall is like a test of memory not memorisation per se",
  "id" : 577965144082399232,
  "in_reply_to_status_id" : 577928171862908929,
  "created_at" : "2015-03-17 22:50:03 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/v7jsYoLyeC",
      "expanded_url" : "http:\/\/www.teflcommute.com\/forthcoming-topics\/",
      "display_url" : "teflcommute.com\/forthcoming-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577952127047348225",
  "text" : "TEFLcommute http:\/\/t.co\/v7jsYoLyeC",
  "id" : 577952127047348225,
  "created_at" : "2015-03-17 21:58:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 3, 16 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6rUy9NFf5v",
      "expanded_url" : "http:\/\/www.googlefeud.com\/",
      "display_url" : "googlefeud.com"
    } ]
  },
  "geo" : { },
  "id_str" : "577946046065733632",
  "text" : "RT @WatchedPotts: Pro tip: Publish one academic paper about Google autocomplete, and forever receive emails about fun games like this http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6rUy9NFf5v",
        "expanded_url" : "http:\/\/www.googlefeud.com\/",
        "display_url" : "googlefeud.com"
      } ]
    },
    "geo" : { },
    "id_str" : "577877411863388161",
    "text" : "Pro tip: Publish one academic paper about Google autocomplete, and forever receive emails about fun games like this http:\/\/t.co\/6rUy9NFf5v",
    "id" : 577877411863388161,
    "created_at" : "2015-03-17 17:01:26 +0000",
    "user" : {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "protected" : false,
      "id_str" : "702925903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697731311428100096\/7yDHWq88_normal.jpg",
      "id" : 702925903,
      "verified" : false
    }
  },
  "id" : 577946046065733632,
  "created_at" : "2015-03-17 21:34:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "indices" : [ 3, 16 ],
      "id_str" : "381086898",
      "id" : 381086898
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 74, 80 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/zQ9vdAQLNL",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/arts\/culturebox\/2006\/03\/irelands_crack_habit.html?wpsrc=sh_all_tab_tw_top",
      "display_url" : "slate.com\/articles\/arts\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577932560648552449",
  "text" : "RT @e_d_driscoll: Ireland was invented in 1991\nhttp:\/\/t.co\/zQ9vdAQLNL via @slate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 56, 62 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/zQ9vdAQLNL",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/arts\/culturebox\/2006\/03\/irelands_crack_habit.html?wpsrc=sh_all_tab_tw_top",
        "display_url" : "slate.com\/articles\/arts\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577930239524913153",
    "text" : "Ireland was invented in 1991\nhttp:\/\/t.co\/zQ9vdAQLNL via @slate",
    "id" : 577930239524913153,
    "created_at" : "2015-03-17 20:31:21 +0000",
    "user" : {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "protected" : false,
      "id_str" : "381086898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656584309415895040\/sBLrsGsl_normal.jpg",
      "id" : 381086898,
      "verified" : false
    }
  },
  "id" : 577932560648552449,
  "created_at" : "2015-03-17 20:40:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rolin Moe",
      "screen_name" : "RMoeJo",
      "indices" : [ 0, 7 ],
      "id_str" : "170832237",
      "id" : 170832237
    }, {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 8, 15 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577856933324947456",
  "geo" : { },
  "id_str" : "577925694358949888",
  "in_reply_to_user_id" : 170832237,
  "text" : "@RMoeJo @holden possibly, transformative?",
  "id" : 577925694358949888,
  "in_reply_to_status_id" : 577856933324947456,
  "created_at" : "2015-03-17 20:13:17 +0000",
  "in_reply_to_screen_name" : "RMoeJo",
  "in_reply_to_user_id_str" : "170832237",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Climate Progress",
      "screen_name" : "climateprogress",
      "indices" : [ 103, 119 ],
      "id_str" : "28657802",
      "id" : 28657802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/P9rb2Jhd9g",
      "expanded_url" : "http:\/\/thkpr.gs\/3630404",
      "display_url" : "thkpr.gs\/3630404"
    } ]
  },
  "geo" : { },
  "id_str" : "577871577527664640",
  "text" : "NASA: Earth Tops Hottest 12 Months On Record Again, Thanks To Warm February http:\/\/t.co\/P9rb2Jhd9g via @climateprogress",
  "id" : 577871577527664640,
  "created_at" : "2015-03-17 16:38:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Rolin Moe",
      "screen_name" : "RMoeJo",
      "indices" : [ 8, 15 ],
      "id_str" : "170832237",
      "id" : 170832237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577854919182405633",
  "geo" : { },
  "id_str" : "577855699214028800",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden @RMoeJo yeah it depends on def, i took it as memory traces, transferring stm into ltm etc",
  "id" : 577855699214028800,
  "in_reply_to_status_id" : 577854919182405633,
  "created_at" : "2015-03-17 15:35:09 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Rolin Moe",
      "screen_name" : "RMoeJo",
      "indices" : [ 8, 15 ],
      "id_str" : "170832237",
      "id" : 170832237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577852609286922240",
  "geo" : { },
  "id_str" : "577854247099875328",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden @RMoeJo that sounds like more \"memorisation\" :)",
  "id" : 577854247099875328,
  "in_reply_to_status_id" : 577852609286922240,
  "created_at" : "2015-03-17 15:29:23 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577851879201251328",
  "geo" : { },
  "id_str" : "577852491607474176",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden and it is very domain dependent no?",
  "id" : 577852491607474176,
  "in_reply_to_status_id" : 577851879201251328,
  "created_at" : "2015-03-17 15:22:24 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577851879201251328",
  "geo" : { },
  "id_str" : "577852082897707008",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden how do u get deeper content knowledge with less memorisation?",
  "id" : 577852082897707008,
  "in_reply_to_status_id" : 577851879201251328,
  "created_at" : "2015-03-17 15:20:47 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 79, 93 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/YgXN2HjBvC",
      "expanded_url" : "http:\/\/wp.me\/p1l5Kr-7Y",
      "display_url" : "wp.me\/p1l5Kr-7Y"
    } ]
  },
  "geo" : { },
  "id_str" : "577845580363378688",
  "text" : "What style of language do scientists really prefer? http:\/\/t.co\/YgXN2HjBvC via @SnoozeInBrief",
  "id" : 577845580363378688,
  "created_at" : "2015-03-17 14:54:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577843737730109441",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx for RT :)",
  "id" : 577843737730109441,
  "created_at" : "2015-03-17 14:47:37 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 119, 128 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistic",
      "indices" : [ 24, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/TlTNFirQ3S",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/jfAewZedFPT",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577839060322000896",
  "text" : "check out some next gen #corpuslinguistic writing tools for students WriteAway and Linggle https:\/\/t.co\/TlTNFirQ3S h\/t @langstat",
  "id" : 577839060322000896,
  "created_at" : "2015-03-17 14:29:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 12, 24 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Yf7gh9t5OJ",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/app\/basic\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/app\/basic\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "577725705011728384",
  "geo" : { },
  "id_str" : "577749803322486784",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @nathanghall hi Steve consider joining G+ CL community https:\/\/t.co\/Yf7gh9t5OJ",
  "id" : 577749803322486784,
  "in_reply_to_status_id" : 577725705011728384,
  "created_at" : "2015-03-17 08:34:21 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 3, 18 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    }, {
      "name" : "Geoffrey Nunberg",
      "screen_name" : "GeoffNunberg",
      "indices" : [ 82, 95 ],
      "id_str" : "39396057",
      "id" : 39396057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreshAir",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577716288660844544",
  "text" : "RT @EvilJoeMcVeigh: \"Every time we avoid saying comprised of, the pedants win.\" - @GeoffNunberg on #FreshAir. A linguistics report done rig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Nunberg",
        "screen_name" : "GeoffNunberg",
        "indices" : [ 62, 75 ],
        "id_str" : "39396057",
        "id" : 39396057
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreshAir",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "577713871986802688",
    "text" : "\"Every time we avoid saying comprised of, the pedants win.\" - @GeoffNunberg on #FreshAir. A linguistics report done right! Huzzah!",
    "id" : 577713871986802688,
    "created_at" : "2015-03-17 06:11:35 +0000",
    "user" : {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "protected" : false,
      "id_str" : "1327355143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633574005530693632\/omOKH3tm_normal.png",
      "id" : 1327355143,
      "verified" : false
    }
  },
  "id" : 577716288660844544,
  "created_at" : "2015-03-17 06:21:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/CsoOqCd85R",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/03\/their-great-achievement.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/03\/their-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577583574402093056",
  "text" : "RT @pchallinor: Mothering mudgeonry: Their great achievement http:\/\/t.co\/CsoOqCd85R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/CsoOqCd85R",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/03\/their-great-achievement.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/03\/their-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577115478553944064",
    "text" : "Mothering mudgeonry: Their great achievement http:\/\/t.co\/CsoOqCd85R",
    "id" : 577115478553944064,
    "created_at" : "2015-03-15 14:33:47 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 577583574402093056,
  "created_at" : "2015-03-16 21:33:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Brand",
      "screen_name" : "rustyrockets",
      "indices" : [ 3, 16 ],
      "id_str" : "19562228",
      "id" : 19562228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/nYIevQHzB4",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1pCPaLPpJp0",
      "display_url" : "youtube.com\/watch?v=1pCPaL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577569469351985152",
  "text" : "RT @rustyrockets: Today's Trews asks \"Elton John Vs Dolce &amp; Gabbana - Are We All 'Synthetic Children'?\":  https:\/\/t.co\/nYIevQHzB4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/nYIevQHzB4",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1pCPaLPpJp0",
        "display_url" : "youtube.com\/watch?v=1pCPaL\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577527363073929217",
    "text" : "Today's Trews asks \"Elton John Vs Dolce &amp; Gabbana - Are We All 'Synthetic Children'?\":  https:\/\/t.co\/nYIevQHzB4",
    "id" : 577527363073929217,
    "created_at" : "2015-03-16 17:50:27 +0000",
    "user" : {
      "name" : "Russell Brand",
      "screen_name" : "rustyrockets",
      "protected" : false,
      "id_str" : "19562228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621999224176177152\/EWhKVkHM_normal.png",
      "id" : 19562228,
      "verified" : true
    }
  },
  "id" : 577569469351985152,
  "created_at" : "2015-03-16 20:37:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toeic",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "english",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/dOYZ7c8OWU",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-TI",
      "display_url" : "wp.me\/pgHyE-TI"
    } ]
  },
  "geo" : { },
  "id_str" : "577511764763365376",
  "text" : "Dictionnaire Cobra 2 - fast by name fast by nature http:\/\/t.co\/dOYZ7c8OWU #toeic #english #eltchat",
  "id" : 577511764763365376,
  "created_at" : "2015-03-16 16:48:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 12, 27 ],
      "id_str" : "14732889",
      "id" : 14732889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577460858504241152",
  "geo" : { },
  "id_str" : "577463227233206272",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @BritishCouncil there is a PDF d\/l available once u register I think",
  "id" : 577463227233206272,
  "in_reply_to_status_id" : 577460858504241152,
  "created_at" : "2015-03-16 13:35:36 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 12, 27 ],
      "id_str" : "14732889",
      "id" : 14732889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DNAEHRfmGC",
      "expanded_url" : "http:\/\/www.englishprofile.org\/index.php\/wordlists",
      "display_url" : "englishprofile.org\/index.php\/word\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "577432901089816576",
  "geo" : { },
  "id_str" : "577451683913027584",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @BritishCouncil i think they have incorporated it into English Profile http:\/\/t.co\/DNAEHRfmGC?",
  "id" : 577451683913027584,
  "in_reply_to_status_id" : 577432901089816576,
  "created_at" : "2015-03-16 12:49:44 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577373977653456897",
  "geo" : { },
  "id_str" : "577422306240294912",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol ok thanks for info",
  "id" : 577422306240294912,
  "in_reply_to_status_id" : 577373977653456897,
  "created_at" : "2015-03-16 10:53:00 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fromm",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/F6GuWP9mUi",
      "expanded_url" : "http:\/\/bit.ly\/1ER2abw",
      "display_url" : "bit.ly\/1ER2abw"
    } ]
  },
  "geo" : { },
  "id_str" : "577237050774200321",
  "text" : "RT @tornhalves: Erich #Fromm on our \"just do it\" culture: emancipation as a conservative enterprise in a Brave New Corporate World http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fromm",
        "indices" : [ 6, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/F6GuWP9mUi",
        "expanded_url" : "http:\/\/bit.ly\/1ER2abw",
        "display_url" : "bit.ly\/1ER2abw"
      } ]
    },
    "geo" : { },
    "id_str" : "577196419230072832",
    "text" : "Erich #Fromm on our \"just do it\" culture: emancipation as a conservative enterprise in a Brave New Corporate World http:\/\/t.co\/F6GuWP9mUi",
    "id" : 577196419230072832,
    "created_at" : "2015-03-15 19:55:24 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 577237050774200321,
  "created_at" : "2015-03-15 22:36:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577175509685153792",
  "geo" : { },
  "id_str" : "577205323196473344",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol great, how much feedback is optimal via texting? i.e how many words\/characters could u text in time available?",
  "id" : 577205323196473344,
  "in_reply_to_status_id" : 577175509685153792,
  "created_at" : "2015-03-15 20:30:47 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSPAN 5",
      "screen_name" : "CSPANFive",
      "indices" : [ 3, 13 ],
      "id_str" : "3091735275",
      "id" : 3091735275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/bmvk9EQIou",
      "expanded_url" : "http:\/\/ift.tt\/1Eg4JP4",
      "display_url" : "ift.tt\/1Eg4JP4"
    } ]
  },
  "geo" : { },
  "id_str" : "577204265858519041",
  "text" : "RT @CSPANFive: CSPAN daily summary: GOVERNMENT AND UKRAINE AND UKRAINIAN http:\/\/t.co\/bmvk9EQIou",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/bmvk9EQIou",
        "expanded_url" : "http:\/\/ift.tt\/1Eg4JP4",
        "display_url" : "ift.tt\/1Eg4JP4"
      } ]
    },
    "geo" : { },
    "id_str" : "576993942648037376",
    "text" : "CSPAN daily summary: GOVERNMENT AND UKRAINE AND UKRAINIAN http:\/\/t.co\/bmvk9EQIou",
    "id" : 576993942648037376,
    "created_at" : "2015-03-15 06:30:50 +0000",
    "user" : {
      "name" : "CSPAN 5",
      "screen_name" : "CSPANFive",
      "protected" : false,
      "id_str" : "3091735275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576842621055729664\/WCkeow6m_normal.png",
      "id" : 3091735275,
      "verified" : false
    }
  },
  "id" : 577204265858519041,
  "created_at" : "2015-03-15 20:26:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loreto Urbina M.",
      "screen_name" : "LoretoUrbinaMon",
      "indices" : [ 3, 19 ],
      "id_str" : "77878451",
      "id" : 77878451
    }, {
      "name" : "Mawuna KOUTONIN",
      "screen_name" : "siliconafrica",
      "indices" : [ 139, 140 ],
      "id_str" : "434119641",
      "id" : 434119641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/MgattyjJiA",
      "expanded_url" : "http:\/\/www.siliconafrica.com\/france-colonial-tax\/",
      "display_url" : "siliconafrica.com\/france-colonia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577144180188803073",
  "text" : "RT @LoretoUrbinaMon: 14 African Countries Forced by France to Pay Colonial Tax For the Benefits of Slavery and Colonization http:\/\/t.co\/Mga\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mawuna KOUTONIN",
        "screen_name" : "siliconafrica",
        "indices" : [ 126, 140 ],
        "id_str" : "434119641",
        "id" : 434119641
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/MgattyjJiA",
        "expanded_url" : "http:\/\/www.siliconafrica.com\/france-colonial-tax\/",
        "display_url" : "siliconafrica.com\/france-colonia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577084092212244480",
    "text" : "14 African Countries Forced by France to Pay Colonial Tax For the Benefits of Slavery and Colonization http:\/\/t.co\/MgattyjJiA @siliconafrica",
    "id" : 577084092212244480,
    "created_at" : "2015-03-15 12:29:03 +0000",
    "user" : {
      "name" : "Loreto Urbina M.",
      "screen_name" : "LoretoUrbinaMon",
      "protected" : false,
      "id_str" : "77878451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427604638012293120\/rKCp3_GO_normal.jpeg",
      "id" : 77878451,
      "verified" : false
    }
  },
  "id" : 577144180188803073,
  "created_at" : "2015-03-15 16:27:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "Mawuna KOUTONIN",
      "screen_name" : "siliconafrica",
      "indices" : [ 125, 139 ],
      "id_str" : "434119641",
      "id" : 434119641
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/linguisticpulse\/status\/577130691281838080\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/wd8M9Dibqd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAJhTcdWcAABxFY.png",
      "id_str" : "577130688941551616",
      "id" : 577130688941551616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAJhTcdWcAABxFY.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/wd8M9Dibqd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/hZsyxZWpsp",
      "expanded_url" : "http:\/\/bit.ly\/1xptJB3",
      "display_url" : "bit.ly\/1xptJB3"
    } ]
  },
  "geo" : { },
  "id_str" : "577138364450754561",
  "text" : "RT @linguisticpulse: different words, EXPAT and IMMIGRANT, &amp; different expectations for newcomers http:\/\/t.co\/hZsyxZWpsp @siliconafrica htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mawuna KOUTONIN",
        "screen_name" : "siliconafrica",
        "indices" : [ 104, 118 ],
        "id_str" : "434119641",
        "id" : 434119641
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/linguisticpulse\/status\/577130691281838080\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/wd8M9Dibqd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAJhTcdWcAABxFY.png",
        "id_str" : "577130688941551616",
        "id" : 577130688941551616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAJhTcdWcAABxFY.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/wd8M9Dibqd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/hZsyxZWpsp",
        "expanded_url" : "http:\/\/bit.ly\/1xptJB3",
        "display_url" : "bit.ly\/1xptJB3"
      } ]
    },
    "in_reply_to_status_id_str" : "577109190596009985",
    "geo" : { },
    "id_str" : "577130691281838080",
    "in_reply_to_user_id" : 1400748798,
    "text" : "different words, EXPAT and IMMIGRANT, &amp; different expectations for newcomers http:\/\/t.co\/hZsyxZWpsp @siliconafrica http:\/\/t.co\/wd8M9Dibqd",
    "id" : 577130691281838080,
    "in_reply_to_status_id" : 577109190596009985,
    "created_at" : "2015-03-15 15:34:14 +0000",
    "in_reply_to_screen_name" : "linguisticpulse",
    "in_reply_to_user_id_str" : "1400748798",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 577138364450754561,
  "created_at" : "2015-03-15 16:04:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 3, 16 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 57, 72 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/BTwZzgFxt0",
      "expanded_url" : "http:\/\/wp.me\/p5xSWM-8B",
      "display_url" : "wp.me\/p5xSWM-8B"
    } ]
  },
  "geo" : { },
  "id_str" : "577049704984395777",
  "text" : "RT @ZhenyaDnipro: KWHL charts http:\/\/t.co\/BTwZzgFxt0 via @DavidHarbinson &gt; adding the 'H' into traditional KWL and thinking how it will mak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Harbinson",
        "screen_name" : "DavidHarbinson",
        "indices" : [ 39, 54 ],
        "id_str" : "853078675",
        "id" : 853078675
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/BTwZzgFxt0",
        "expanded_url" : "http:\/\/wp.me\/p5xSWM-8B",
        "display_url" : "wp.me\/p5xSWM-8B"
      } ]
    },
    "geo" : { },
    "id_str" : "577046274156990464",
    "text" : "KWHL charts http:\/\/t.co\/BTwZzgFxt0 via @DavidHarbinson &gt; adding the 'H' into traditional KWL and thinking how it will make a difference",
    "id" : 577046274156990464,
    "created_at" : "2015-03-15 09:58:47 +0000",
    "user" : {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "protected" : false,
      "id_str" : "2248486418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766906932875714560\/KfDv1cK8_normal.jpg",
      "id" : 2248486418,
      "verified" : false
    }
  },
  "id" : 577049704984395777,
  "created_at" : "2015-03-15 10:12:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "indices" : [ 3, 13 ],
      "id_str" : "303905601",
      "id" : 303905601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mfltwitterati",
      "indices" : [ 114, 128 ]
    }, {
      "text" : "langchat",
      "indices" : [ 129, 138 ]
    }, {
      "text" : "tprs",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "aimlang",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/MnXgs9hsg9",
      "expanded_url" : "http:\/\/frenchteachernet.blogspot.co.uk\/2015\/03\/method-evangelists.html",
      "display_url" : "frenchteachernet.blogspot.co.uk\/2015\/03\/method\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "576738561795497985",
  "text" : "RT @spsmith45: Busy blogging week here in Charente Maritime! Latest: on method evangelists http:\/\/t.co\/MnXgs9hsg9 #mfltwitterati #langchat \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mfltwitterati",
        "indices" : [ 99, 113 ]
      }, {
        "text" : "langchat",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "tprs",
        "indices" : [ 124, 129 ]
      }, {
        "text" : "aimlang",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/MnXgs9hsg9",
        "expanded_url" : "http:\/\/frenchteachernet.blogspot.co.uk\/2015\/03\/method-evangelists.html",
        "display_url" : "frenchteachernet.blogspot.co.uk\/2015\/03\/method\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "576716626877419520",
    "text" : "Busy blogging week here in Charente Maritime! Latest: on method evangelists http:\/\/t.co\/MnXgs9hsg9 #mfltwitterati #langchat #tprs #aimlang",
    "id" : 576716626877419520,
    "created_at" : "2015-03-14 12:08:53 +0000",
    "user" : {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "protected" : false,
      "id_str" : "303905601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766281389037813760\/eXdJEsQr_normal.jpg",
      "id" : 303905601,
      "verified" : false
    }
  },
  "id" : 576738561795497985,
  "created_at" : "2015-03-14 13:36:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576721351899242496",
  "geo" : { },
  "id_str" : "576722654809456643",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hmm if so maybe time to get out a bit more! :)",
  "id" : 576722654809456643,
  "in_reply_to_status_id" : 576721351899242496,
  "created_at" : "2015-03-14 12:32:50 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/VAi91BkgzL",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1426317875.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "576716369468719105",
  "text" : "ITV: Remembering Afghanistan - Kate Garraway: \"It's so inspirational, not just the incredible work...http:\/\/t.co\/VAi91BkgzL",
  "id" : 576716369468719105,
  "created_at" : "2015-03-14 12:07:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576713533397815296",
  "geo" : { },
  "id_str" : "576713859328802816",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd yr welcome seems int talk thx for yr tweets",
  "id" : 576713859328802816,
  "in_reply_to_status_id" : 576713533397815296,
  "created_at" : "2015-03-14 11:57:53 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576712984145354752",
  "geo" : { },
  "id_str" : "576713383862538240",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd stroop",
  "id" : 576713383862538240,
  "in_reply_to_status_id" : 576712984145354752,
  "created_at" : "2015-03-14 11:56:00 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 0, 8 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576374542047834113",
  "geo" : { },
  "id_str" : "576680067469815808",
  "in_reply_to_user_id" : 2176726134,
  "text" : "@olyaelt nice! :)",
  "id" : 576680067469815808,
  "in_reply_to_status_id" : 576374542047834113,
  "created_at" : "2015-03-14 09:43:36 +0000",
  "in_reply_to_screen_name" : "olyaelt",
  "in_reply_to_user_id_str" : "2176726134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576313844609478656",
  "geo" : { },
  "id_str" : "576457415576543232",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks for hat tip Shona have a good w\/e :)",
  "id" : 576457415576543232,
  "in_reply_to_status_id" : 576313844609478656,
  "created_at" : "2015-03-13 18:58:52 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 88, 104 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/7e8QG7VIln",
      "expanded_url" : "http:\/\/wp.me\/p3VIfJ-4s",
      "display_url" : "wp.me\/p3VIfJ-4s"
    } ]
  },
  "geo" : { },
  "id_str" : "576453913425100800",
  "text" : "Cultures of coding - BBC Micro Bits and Young Digital Makers http:\/\/t.co\/7e8QG7VIln via @wordpressdotcom",
  "id" : 576453913425100800,
  "created_at" : "2015-03-13 18:44:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 0, 8 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576351886405677056",
  "in_reply_to_user_id" : 2176726134,
  "text" : "@olyaelt hi  Olya thanks for RT are u in person at conf?",
  "id" : 576351886405677056,
  "created_at" : "2015-03-13 11:59:32 +0000",
  "in_reply_to_screen_name" : "olyaelt",
  "in_reply_to_user_id_str" : "2176726134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "indices" : [ 0, 15 ],
      "id_str" : "186543637",
      "id" : 186543637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576332655752581120",
  "geo" : { },
  "id_str" : "576351663080017920",
  "in_reply_to_user_id" : 186543637,
  "text" : "@nastyageinrikh what's a metodichka?",
  "id" : 576351663080017920,
  "in_reply_to_status_id" : 576332655752581120,
  "created_at" : "2015-03-13 11:58:39 +0000",
  "in_reply_to_screen_name" : "nastyageinrikh",
  "in_reply_to_user_id_str" : "186543637",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "emf5",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576266729342550016",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva thx for share r u there live at #emf5 ?",
  "id" : 576266729342550016,
  "created_at" : "2015-03-13 06:21:09 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 40, 46 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576266074041249792",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott hi Scott read yr ref on @ebefl post to Hoey stylistics article on Chomsky, do u have a e-copy to send? thx",
  "id" : 576266074041249792,
  "created_at" : "2015-03-13 06:18:33 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "emf5",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/ZpcwOhCdHr",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-To",
      "display_url" : "wp.me\/pgHyE-To"
    } ]
  },
  "geo" : { },
  "id_str" : "576180023222149120",
  "text" : "E-merging forum 5: Some related notes http:\/\/t.co\/ZpcwOhCdHr #emf5",
  "id" : 576180023222149120,
  "created_at" : "2015-03-13 00:36:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576154814423441408",
  "geo" : { },
  "id_str" : "576160462829707264",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar looks like a bug in the results e.g. reports 3 pages of result, clk on 2nd and reports pg2 of 14 results &amp; pg3 disappears",
  "id" : 576160462829707264,
  "in_reply_to_status_id" : 576154814423441408,
  "created_at" : "2015-03-12 23:18:53 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576154814423441408",
  "geo" : { },
  "id_str" : "576155814601363456",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar yeah normal Google is very noisy but still ... hmm",
  "id" : 576155814601363456,
  "in_reply_to_status_id" : 576154814423441408,
  "created_at" : "2015-03-12 23:00:25 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576149224481538048",
  "geo" : { },
  "id_str" : "576154624341708800",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar scholar says \"would be...\" more frequent",
  "id" : 576154624341708800,
  "in_reply_to_status_id" : 576149224481538048,
  "created_at" : "2015-03-12 22:55:41 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576149224481538048",
  "geo" : { },
  "id_str" : "576154067292012544",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar only 11 hits in google scholar though?",
  "id" : 576154067292012544,
  "in_reply_to_status_id" : 576149224481538048,
  "created_at" : "2015-03-12 22:53:28 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Ford",
      "screen_name" : "EdSacredProfane",
      "indices" : [ 3, 19 ],
      "id_str" : "2288627443",
      "id" : 2288627443
    }, {
      "name" : "James Mannion",
      "screen_name" : "pedagog_machine",
      "indices" : [ 139, 140 ],
      "id_str" : "367360404",
      "id" : 367360404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/i02W93OtjH",
      "expanded_url" : "http:\/\/wp.me\/p3eEtK-9r",
      "display_url" : "wp.me\/p3eEtK-9r"
    } ]
  },
  "geo" : { },
  "id_str" : "576119875665584128",
  "text" : "RT @EdSacredProfane: Wanted! Pioneers to trial a new platform for teachers: professional development through small\u2026 http:\/\/t.co\/i02W93OtjH \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Mannion",
        "screen_name" : "pedagog_machine",
        "indices" : [ 122, 138 ],
        "id_str" : "367360404",
        "id" : 367360404
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/i02W93OtjH",
        "expanded_url" : "http:\/\/wp.me\/p3eEtK-9r",
        "display_url" : "wp.me\/p3eEtK-9r"
      } ]
    },
    "geo" : { },
    "id_str" : "576115993795125248",
    "text" : "Wanted! Pioneers to trial a new platform for teachers: professional development through small\u2026 http:\/\/t.co\/i02W93OtjH via @pedagog_machine",
    "id" : 576115993795125248,
    "created_at" : "2015-03-12 20:22:11 +0000",
    "user" : {
      "name" : "Peter Ford",
      "screen_name" : "EdSacredProfane",
      "protected" : false,
      "id_str" : "2288627443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738287938295988224\/QGpUz-dR_normal.jpg",
      "id" : 2288627443,
      "verified" : false
    }
  },
  "id" : 576119875665584128,
  "created_at" : "2015-03-12 20:37:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/n1EFrWH4X8",
      "expanded_url" : "http:\/\/ow.ly\/K6yaC",
      "display_url" : "ow.ly\/K6yaC"
    } ]
  },
  "geo" : { },
  "id_str" : "576025104989220865",
  "text" : "RT @umasslinguistic: In case you are local: \u00ABComment \u00E9valuer la situation linguistique de la France?\u00BB http:\/\/t.co\/n1EFrWH4X8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/n1EFrWH4X8",
        "expanded_url" : "http:\/\/ow.ly\/K6yaC",
        "display_url" : "ow.ly\/K6yaC"
      } ]
    },
    "geo" : { },
    "id_str" : "576022491770056704",
    "text" : "In case you are local: \u00ABComment \u00E9valuer la situation linguistique de la France?\u00BB http:\/\/t.co\/n1EFrWH4X8",
    "id" : 576022491770056704,
    "created_at" : "2015-03-12 14:10:38 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 576025104989220865,
  "created_at" : "2015-03-12 14:21:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575850757020196864",
  "geo" : { },
  "id_str" : "575969173739843584",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole nice :) the lang learning and teach stream looks great",
  "id" : 575969173739843584,
  "in_reply_to_status_id" : 575850757020196864,
  "created_at" : "2015-03-12 10:38:46 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 3, 13 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thai",
      "indices" : [ 112, 117 ]
    }, {
      "text" : "language",
      "indices" : [ 143, 146 ]
    }, {
      "text" : "ELT",
      "indices" : [ 145, 146 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/N4gPfnXvlb",
      "expanded_url" : "http:\/\/ptefldactyl.blogspot.co.uk\/2015\/03\/yes-you-can-break-window-with-ashtray_12.html",
      "display_url" : "ptefldactyl.blogspot.co.uk\/2015\/03\/yes-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575952477641650176",
  "text" : "RT @pterolaur: New blog post &gt;&gt; Yes, you can break a window with an ashtray (some thoughts about learning #Thai): http:\/\/t.co\/N4gPfnXvlb #l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thai",
        "indices" : [ 97, 102 ]
      }, {
        "text" : "language",
        "indices" : [ 128, 137 ]
      }, {
        "text" : "ELT",
        "indices" : [ 138, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/N4gPfnXvlb",
        "expanded_url" : "http:\/\/ptefldactyl.blogspot.co.uk\/2015\/03\/yes-you-can-break-window-with-ashtray_12.html",
        "display_url" : "ptefldactyl.blogspot.co.uk\/2015\/03\/yes-yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575938416988160000",
    "text" : "New blog post &gt;&gt; Yes, you can break a window with an ashtray (some thoughts about learning #Thai): http:\/\/t.co\/N4gPfnXvlb #language #ELT",
    "id" : 575938416988160000,
    "created_at" : "2015-03-12 08:36:33 +0000",
    "user" : {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "protected" : false,
      "id_str" : "90093887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704308862669619200\/NV6131_3_normal.jpg",
      "id" : 90093887,
      "verified" : false
    }
  },
  "id" : 575952477641650176,
  "created_at" : "2015-03-12 09:32:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/sZ5QpSkNT5",
      "expanded_url" : "http:\/\/www.washingtonsblog.com\/2015\/03\/tentative-deal-reached-settle-ukraine-war.html",
      "display_url" : "washingtonsblog.com\/2015\/03\/tentat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575950693036650496",
  "text" : "Tentative Deal Reached to Settle Ukraine War http:\/\/t.co\/sZ5QpSkNT5",
  "id" : 575950693036650496,
  "created_at" : "2015-03-12 09:25:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Simpson",
      "screen_name" : "pevansimpson",
      "indices" : [ 3, 16 ],
      "id_str" : "230954247",
      "id" : 230954247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COCA",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "collocations",
      "indices" : [ 39, 52 ]
    }, {
      "text" : "edtech",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/xZJJ7SpO5w",
      "expanded_url" : "http:\/\/newsmanager.commpartners.com\/tesolcallis\/issues\/2015-03-03\/7.html",
      "display_url" : "newsmanager.commpartners.com\/tesolcallis\/is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575753994515124225",
  "text" : "RT @pevansimpson: Using #COCA to teach #collocations http:\/\/t.co\/xZJJ7SpO5w #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COCA",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "collocations",
        "indices" : [ 21, 34 ]
      }, {
        "text" : "edtech",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/xZJJ7SpO5w",
        "expanded_url" : "http:\/\/newsmanager.commpartners.com\/tesolcallis\/issues\/2015-03-03\/7.html",
        "display_url" : "newsmanager.commpartners.com\/tesolcallis\/is\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575748388513185793",
    "text" : "Using #COCA to teach #collocations http:\/\/t.co\/xZJJ7SpO5w #edtech",
    "id" : 575748388513185793,
    "created_at" : "2015-03-11 20:01:27 +0000",
    "user" : {
      "name" : "Evan Simpson",
      "screen_name" : "pevansimpson",
      "protected" : false,
      "id_str" : "230954247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453387820497793024\/9zJ3BD_C_normal.jpeg",
      "id" : 230954247,
      "verified" : false
    }
  },
  "id" : 575753994515124225,
  "created_at" : "2015-03-11 20:23:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/x8ZPwLL6ex",
      "expanded_url" : "http:\/\/bit.ly\/1GrUklA",
      "display_url" : "bit.ly\/1GrUklA"
    } ]
  },
  "geo" : { },
  "id_str" : "575713677376118784",
  "text" : "RT @tornhalves: How could the #edtech revolutionaries overlook the death of the individual? Our call for a second Renaissance http:\/\/t.co\/x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 14, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/x8ZPwLL6ex",
        "expanded_url" : "http:\/\/bit.ly\/1GrUklA",
        "display_url" : "bit.ly\/1GrUklA"
      } ]
    },
    "geo" : { },
    "id_str" : "575687832473354240",
    "text" : "How could the #edtech revolutionaries overlook the death of the individual? Our call for a second Renaissance http:\/\/t.co\/x8ZPwLL6ex",
    "id" : 575687832473354240,
    "created_at" : "2015-03-11 16:00:49 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 575713677376118784,
  "created_at" : "2015-03-11 17:43:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "indices" : [ 3, 13 ],
      "id_str" : "13192",
      "id" : 13192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/GkoId4oSkM",
      "expanded_url" : "https:\/\/danielrapp.github.io\/doppler\/",
      "display_url" : "danielrapp.github.io\/doppler\/"
    } ]
  },
  "geo" : { },
  "id_str" : "575681538370707457",
  "text" : "RT @avibryant: Definitely the coolest Javascript hack I've seen today: using your laptop mic\/speaker for motion detection. https:\/\/t.co\/Gko\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/GkoId4oSkM",
        "expanded_url" : "https:\/\/danielrapp.github.io\/doppler\/",
        "display_url" : "danielrapp.github.io\/doppler\/"
      } ]
    },
    "geo" : { },
    "id_str" : "575403318727475200",
    "text" : "Definitely the coolest Javascript hack I've seen today: using your laptop mic\/speaker for motion detection. https:\/\/t.co\/GkoId4oSkM",
    "id" : 575403318727475200,
    "created_at" : "2015-03-10 21:10:16 +0000",
    "user" : {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "protected" : false,
      "id_str" : "13192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762794521801265153\/oRPjI4ya_normal.jpg",
      "id" : 13192,
      "verified" : false
    }
  },
  "id" : 575681538370707457,
  "created_at" : "2015-03-11 15:35:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fr3YJvmrbq",
      "expanded_url" : "https:\/\/zcomm.org\/zblogs\/hillary-clinton-and-the-crisis-of-liberal-feminism\/",
      "display_url" : "zcomm.org\/zblogs\/hillary\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575592482471309312",
  "text" : "Hillary Clinton and the Crisis of Liberal Feminism https:\/\/t.co\/fr3YJvmrbq",
  "id" : 575592482471309312,
  "created_at" : "2015-03-11 09:41:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/kVpmCJh5EV",
      "expanded_url" : "http:\/\/youtu.be\/UgxLvwKhvmY",
      "display_url" : "youtu.be\/UgxLvwKhvmY"
    } ]
  },
  "geo" : { },
  "id_str" : "575586618159075328",
  "text" : "Ezra Levant vs Noam Chomsky: The Complete Interview: http:\/\/t.co\/kVpmCJh5EV via @YouTube",
  "id" : 575586618159075328,
  "created_at" : "2015-03-11 09:18:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEAS",
      "screen_name" : "NEAS_Australia",
      "indices" : [ 0, 15 ],
      "id_str" : "927168978",
      "id" : 927168978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575579462001147904",
  "in_reply_to_user_id" : 927168978,
  "text" : "@NEAS_Australia thanks for RT :)",
  "id" : 575579462001147904,
  "created_at" : "2015-03-11 08:50:12 +0000",
  "in_reply_to_screen_name" : "NEAS_Australia",
  "in_reply_to_user_id_str" : "927168978",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AyitiAnaliz",
      "screen_name" : "HaitiAnalysis",
      "indices" : [ 3, 17 ],
      "id_str" : "512885774",
      "id" : 512885774
    }, {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 51, 59 ],
      "id_str" : "1652541",
      "id" : 1652541
    }, {
      "name" : "Andrew Cawthorne",
      "screen_name" : "AndrewCawthorne",
      "indices" : [ 115, 131 ],
      "id_str" : "112845275",
      "id" : 112845275
    }, {
      "name" : "FAIR",
      "screen_name" : "FAIRmediawatch",
      "indices" : [ 132, 140 ],
      "id_str" : "54679731",
      "id" : 54679731
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 139, 140 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jEemJE1brZ",
      "expanded_url" : "https:\/\/zcomm.org\/zblogs\/timidly-double-standards-from-reuters-extraordinary-but-not-unusual\/",
      "display_url" : "zcomm.org\/zblogs\/timidly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575418588074479616",
  "text" : "RT @HaitiAnalysis: Timidity, Double Standards from @Reuters :Extraordinary but not Unusual https:\/\/t.co\/jEemJE1brZ @AndrewCawthorne @FAIRme\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reuters Top News",
        "screen_name" : "Reuters",
        "indices" : [ 32, 40 ],
        "id_str" : "1652541",
        "id" : 1652541
      }, {
        "name" : "Andrew Cawthorne",
        "screen_name" : "AndrewCawthorne",
        "indices" : [ 96, 112 ],
        "id_str" : "112845275",
        "id" : 112845275
      }, {
        "name" : "FAIR",
        "screen_name" : "FAIRmediawatch",
        "indices" : [ 113, 128 ],
        "id_str" : "54679731",
        "id" : 54679731
      }, {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 129, 139 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/jEemJE1brZ",
        "expanded_url" : "https:\/\/zcomm.org\/zblogs\/timidly-double-standards-from-reuters-extraordinary-but-not-unusual\/",
        "display_url" : "zcomm.org\/zblogs\/timidly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575390187313745920",
    "text" : "Timidity, Double Standards from @Reuters :Extraordinary but not Unusual https:\/\/t.co\/jEemJE1brZ @AndrewCawthorne @FAIRmediawatch @medialens",
    "id" : 575390187313745920,
    "created_at" : "2015-03-10 20:18:05 +0000",
    "user" : {
      "name" : "AyitiAnaliz",
      "screen_name" : "HaitiAnalysis",
      "protected" : false,
      "id_str" : "512885774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658204635375665152\/0I1_9iQA_normal.jpg",
      "id" : 512885774,
      "verified" : false
    }
  },
  "id" : 575418588074479616,
  "created_at" : "2015-03-10 22:10:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575405867757080576",
  "geo" : { },
  "id_str" : "575414760939876353",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons stay safe!",
  "id" : 575414760939876353,
  "in_reply_to_status_id" : 575405867757080576,
  "created_at" : "2015-03-10 21:55:44 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0hGMfRFPAv",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1426015826.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575413334670970880",
  "text" : "Snowmail...\"Putin's Russia is rapidly becoming a real danger\"...short email to 6 Pilgers...http:\/\/t.co\/0hGMfRFPAv",
  "id" : 575413334670970880,
  "created_at" : "2015-03-10 21:50:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/K54HJcskjF",
      "expanded_url" : "http:\/\/wp.me\/p3hrws-5x",
      "display_url" : "wp.me\/p3hrws-5x"
    } ]
  },
  "geo" : { },
  "id_str" : "575404214106648576",
  "text" : "\"First writing\" tips http:\/\/t.co\/K54HJcskjF via @wordpressdotcom",
  "id" : 575404214106648576,
  "created_at" : "2015-03-10 21:13:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575402455502090242",
  "geo" : { },
  "id_str" : "575403340290482177",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons yikes!",
  "id" : 575403340290482177,
  "in_reply_to_status_id" : 575402455502090242,
  "created_at" : "2015-03-10 21:10:21 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/SXUYleOyx6",
      "expanded_url" : "http:\/\/bit.ly\/1HuSaD1",
      "display_url" : "bit.ly\/1HuSaD1"
    } ]
  },
  "geo" : { },
  "id_str" : "575401814314590208",
  "text" : "RT @mcleod: 60 apps in 60 seconds http:\/\/t.co\/SXUYleOyx6 #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/SXUYleOyx6",
        "expanded_url" : "http:\/\/bit.ly\/1HuSaD1",
        "display_url" : "bit.ly\/1HuSaD1"
      } ]
    },
    "geo" : { },
    "id_str" : "575385764936171520",
    "text" : "60 apps in 60 seconds http:\/\/t.co\/SXUYleOyx6 #edtech",
    "id" : 575385764936171520,
    "created_at" : "2015-03-10 20:00:31 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 575401814314590208,
  "created_at" : "2015-03-10 21:04:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    }, {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 35, 48 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/A8h7jPKFzX",
      "expanded_url" : "http:\/\/ske.li\/b2n",
      "display_url" : "ske.li\/b2n"
    } ]
  },
  "geo" : { },
  "id_str" : "575396685381304322",
  "text" : "RT @SketchEngine: Learn how to use @SketchEngine Simple query properly. It is sufficient for many basic corpus searches: http:\/\/t.co\/A8h7jP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sketch Engine",
        "screen_name" : "SketchEngine",
        "indices" : [ 17, 30 ],
        "id_str" : "841197134",
        "id" : 841197134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/A8h7jPKFzX",
        "expanded_url" : "http:\/\/ske.li\/b2n",
        "display_url" : "ske.li\/b2n"
      } ]
    },
    "geo" : { },
    "id_str" : "575322254264922112",
    "text" : "Learn how to use @SketchEngine Simple query properly. It is sufficient for many basic corpus searches: http:\/\/t.co\/A8h7jPKFzX",
    "id" : 575322254264922112,
    "created_at" : "2015-03-10 15:48:09 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 575396685381304322,
  "created_at" : "2015-03-10 20:43:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 13, 28 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575337001508954112",
  "geo" : { },
  "id_str" : "575337640892973056",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @DavidHarbinson true that glossed david's q before realising not the q ak!",
  "id" : 575337640892973056,
  "in_reply_to_status_id" : 575337001508954112,
  "created_at" : "2015-03-10 16:49:17 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 13, 28 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/7DYtdpFyYX",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=37688564",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "575332396502937600",
  "geo" : { },
  "id_str" : "575336458053115904",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @DavidHarbinson five before seems most common in US spoken http:\/\/t.co\/7DYtdpFyYX",
  "id" : 575336458053115904,
  "in_reply_to_status_id" : 575332396502937600,
  "created_at" : "2015-03-10 16:44:35 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Kp5H9YOWxL",
      "expanded_url" : "http:\/\/CorrectiveFeedback.com",
      "display_url" : "CorrectiveFeedback.com"
    }, {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/UtClklpdgA",
      "expanded_url" : "http:\/\/bokomarupublications.blogspot.com\/2015\/03\/crowdfunding-correctivefeedbackcom.html",
      "display_url" : "bokomarupublications.blogspot.com\/2015\/03\/crowdf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575332365511299073",
  "text" : "Crowdfunding http:\/\/t.co\/Kp5H9YOWxL http:\/\/t.co\/UtClklpdgA",
  "id" : 575332365511299073,
  "created_at" : "2015-03-10 16:28:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Emmerson",
      "screen_name" : "PaulEmmersonCom",
      "indices" : [ 3, 19 ],
      "id_str" : "224395256",
      "id" : 224395256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jT7bBY7dWf",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce53xcuzx\/e1e0",
      "display_url" : "cards.twitter.com\/cards\/18ce53xc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575325958636486656",
  "text" : "RT @PaulEmmersonCom: Flashcard fun! Perfect when you only have a few minutes. New cards added monthly. #ESL #IATEFL. https:\/\/t.co\/jT7bBY7dWf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "IATEFL",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/jT7bBY7dWf",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce53xcuzx\/e1e0",
        "display_url" : "cards.twitter.com\/cards\/18ce53xc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575325563092537345",
    "text" : "Flashcard fun! Perfect when you only have a few minutes. New cards added monthly. #ESL #IATEFL. https:\/\/t.co\/jT7bBY7dWf",
    "id" : 575325563092537345,
    "created_at" : "2015-03-10 16:01:17 +0000",
    "user" : {
      "name" : "Paul Emmerson",
      "screen_name" : "PaulEmmersonCom",
      "protected" : false,
      "id_str" : "224395256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1186264814\/Paul_Photo_normal.PNG",
      "id" : 224395256,
      "verified" : false
    }
  },
  "id" : 575325958636486656,
  "created_at" : "2015-03-10 16:02:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/6mKBSRCEi8",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1425994401.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575325298973085696",
  "text" : "Putin under fire at Guardian for 'cult of masculinity' keeping women down, yet ...http:\/\/t.co\/6mKBSRCEi8",
  "id" : 575325298973085696,
  "created_at" : "2015-03-10 16:00:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran Donaghy",
      "screen_name" : "kierandonaghy",
      "indices" : [ 1, 15 ],
      "id_str" : "135272434",
      "id" : 135272434
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "videogrep",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/00glRAAQG7",
      "expanded_url" : "http:\/\/lav.io\/2014\/06\/videogrep-automatic-supercuts-with-python\/",
      "display_url" : "lav.io\/2014\/06\/videog\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "575009188490973185",
  "geo" : { },
  "id_str" : "575019312488013824",
  "in_reply_to_user_id" : 135272434,
  "text" : ".@kierandonaghy if you want to customise videos used try #videogrep http:\/\/t.co\/00glRAAQG7",
  "id" : 575019312488013824,
  "in_reply_to_status_id" : 575009188490973185,
  "created_at" : "2015-03-09 19:44:22 +0000",
  "in_reply_to_screen_name" : "kierandonaghy",
  "in_reply_to_user_id_str" : "135272434",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran Donaghy",
      "screen_name" : "kierandonaghy",
      "indices" : [ 3, 17 ],
      "id_str" : "135272434",
      "id" : 135272434
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "elt",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 141, 144 ]
    }, {
      "text" : "FilmInAction",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/lxXBQNp0qA",
      "expanded_url" : "http:\/\/playphrase.me\/",
      "display_url" : "playphrase.me"
    } ]
  },
  "geo" : { },
  "id_str" : "575018294450782208",
  "text" : "RT @kierandonaghy: Excellent resource for students to learn vocabulary &amp; expressions through film clips http:\/\/t.co\/lxXBQNp0qA #esl #elt #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esl",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "elt",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "efl",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "FilmInAction",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/lxXBQNp0qA",
        "expanded_url" : "http:\/\/playphrase.me\/",
        "display_url" : "playphrase.me"
      } ]
    },
    "geo" : { },
    "id_str" : "575009188490973185",
    "text" : "Excellent resource for students to learn vocabulary &amp; expressions through film clips http:\/\/t.co\/lxXBQNp0qA #esl #elt #efl #FilmInAction",
    "id" : 575009188490973185,
    "created_at" : "2015-03-09 19:04:08 +0000",
    "user" : {
      "name" : "Kieran Donaghy",
      "screen_name" : "kierandonaghy",
      "protected" : false,
      "id_str" : "135272434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690627057320075270\/iDFeAHK-_normal.jpg",
      "id" : 135272434,
      "verified" : false
    }
  },
  "id" : 575018294450782208,
  "created_at" : "2015-03-09 19:40:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 82, 91 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/GkUbOSF2IT",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-6y",
      "display_url" : "wp.me\/p28EmH-6y"
    } ]
  },
  "geo" : { },
  "id_str" : "574946451312222208",
  "text" : "Spew test, anyone? On teaching and learning vocabulary http:\/\/t.co\/GkUbOSF2IT via @whyshona",
  "id" : 574946451312222208,
  "created_at" : "2015-03-09 14:54:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 66, 81 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/huph4gjEFo",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-18R",
      "display_url" : "wp.me\/p3qkCB-18R"
    } ]
  },
  "geo" : { },
  "id_str" : "574838739102474240",
  "text" : "Ms. Potts Presents the Present Perfect http:\/\/t.co\/huph4gjEFo via @GeoffreyJordan",
  "id" : 574838739102474240,
  "created_at" : "2015-03-09 07:46:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574677889083424768",
  "geo" : { },
  "id_str" : "574680161334988800",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway that seems a groovy site, groovy concordancer as well",
  "id" : 574680161334988800,
  "in_reply_to_status_id" : 574677889083424768,
  "created_at" : "2015-03-08 21:16:42 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574675957077917696",
  "geo" : { },
  "id_str" : "574677839179563010",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway do u think u may blog about it?",
  "id" : 574677839179563010,
  "in_reply_to_status_id" : 574675957077917696,
  "created_at" : "2015-03-08 21:07:28 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574151774266880000",
  "geo" : { },
  "id_str" : "574673283641176064",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thx webcorp is useful, must make an effort to use it more, do you use it much?",
  "id" : 574673283641176064,
  "in_reply_to_status_id" : 574151774266880000,
  "created_at" : "2015-03-08 20:49:22 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574648604217991168",
  "geo" : { },
  "id_str" : "574671951937040384",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 doh! well all the best for your prep for the language",
  "id" : 574671951937040384,
  "in_reply_to_status_id" : 574648604217991168,
  "created_at" : "2015-03-08 20:44:04 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574486699729797120",
  "geo" : { },
  "id_str" : "574640622310723584",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu yr welcome an interesting lineage for pi",
  "id" : 574640622310723584,
  "in_reply_to_status_id" : 574486699729797120,
  "created_at" : "2015-03-08 18:39:35 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574496513155555328",
  "geo" : { },
  "id_str" : "574640472045547520",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thanks Gemma :) r u in Germany now?",
  "id" : 574640472045547520,
  "in_reply_to_status_id" : 574496513155555328,
  "created_at" : "2015-03-08 18:38:59 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 11, 22 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574205986237370368",
  "geo" : { },
  "id_str" : "574251336071581696",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim @bethcagnol cheers for the ideas may try some in #piratebox chat box",
  "id" : 574251336071581696,
  "in_reply_to_status_id" : 574205986237370368,
  "created_at" : "2015-03-07 16:52:42 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ITtbqmkrGi",
      "expanded_url" : "http:\/\/elang.ujf-grenoble.fr\/anglais\/licence\/banque_de_cours\/mcse_list_of_words\/mcse_list_of_words.php",
      "display_url" : "elang.ujf-grenoble.fr\/anglais\/licenc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "574132450886025218",
  "geo" : { },
  "id_str" : "574139928097001473",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway are u aware of this list of acad words adapted for French users of English? http:\/\/t.co\/ITtbqmkrGi",
  "id" : 574139928097001473,
  "in_reply_to_status_id" : 574132450886025218,
  "created_at" : "2015-03-07 09:30:00 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574132450886025218",
  "geo" : { },
  "id_str" : "574132641496178688",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway sure, thx for a comprehensive set of exercises :)",
  "id" : 574132641496178688,
  "in_reply_to_status_id" : 574132450886025218,
  "created_at" : "2015-03-07 09:01:03 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 3, 13 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "words",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "EFL",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "ESL",
      "indices" : [ 133, 137 ]
    }, {
      "text" : "elearning",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/l79C7SyVBc",
      "expanded_url" : "http:\/\/www.english-studies.org\/sitemenu\/2langex\/ex\/page1\/page1.html",
      "display_url" : "english-studies.org\/sitemenu\/2lang\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "574132126234382336",
  "text" : "RT @curvedway: Vocab Ex generated with Gerry's Vocabulary Teacher\nhttp:\/\/t.co\/l79C7SyVBc \n\u2014&gt;Word Formation in Context\n#words\n#EFL #ESL #ele\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "words",
        "indices" : [ 106, 112 ]
      }, {
        "text" : "EFL",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "ESL",
        "indices" : [ 118, 122 ]
      }, {
        "text" : "elearning",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/l79C7SyVBc",
        "expanded_url" : "http:\/\/www.english-studies.org\/sitemenu\/2langex\/ex\/page1\/page1.html",
        "display_url" : "english-studies.org\/sitemenu\/2lang\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "574129358836789248",
    "text" : "Vocab Ex generated with Gerry's Vocabulary Teacher\nhttp:\/\/t.co\/l79C7SyVBc \n\u2014&gt;Word Formation in Context\n#words\n#EFL #ESL #elearning",
    "id" : 574129358836789248,
    "created_at" : "2015-03-07 08:48:00 +0000",
    "user" : {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "protected" : false,
      "id_str" : "124707247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439859868434837505\/-h531G_i_normal.jpeg",
      "id" : 124707247,
      "verified" : false
    }
  },
  "id" : 574132126234382336,
  "created_at" : "2015-03-07 08:59:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574126427525804032",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx for RT hope yr w\/e has started well :)",
  "id" : 574126427525804032,
  "created_at" : "2015-03-07 08:36:21 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Footnote",
      "screen_name" : "FootnoteMedia",
      "indices" : [ 0, 14 ],
      "id_str" : "593919531",
      "id" : 593919531
    }, {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 15, 26 ],
      "id_str" : "134191406",
      "id" : 134191406
    }, {
      "name" : "Andrew Ng",
      "screen_name" : "AndrewYNg",
      "indices" : [ 27, 37 ],
      "id_str" : "216939636",
      "id" : 216939636
    }, {
      "name" : "K. Lindsay Hunter",
      "screen_name" : "Paleo_Bonegirl",
      "indices" : [ 38, 53 ],
      "id_str" : "14746356",
      "id" : 14746356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573929884227076097",
  "geo" : { },
  "id_str" : "573931765305376768",
  "in_reply_to_user_id" : 593919531,
  "text" : "@FootnoteMedia @AchilleasK @AndrewYNg @Paleo_Bonegirl hmm am sure drone victims and their relatives will be comforted by this :\/",
  "id" : 573931765305376768,
  "in_reply_to_status_id" : 573929884227076097,
  "created_at" : "2015-03-06 19:42:50 +0000",
  "in_reply_to_screen_name" : "FootnoteMedia",
  "in_reply_to_user_id_str" : "593919531",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 0, 16 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 17, 33 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573591095432601600",
  "geo" : { },
  "id_str" : "573868140150521858",
  "in_reply_to_user_id" : 2561325079,
  "text" : "@MarekKiczkowiak @MichaelChesnut2 lk fwd to results of your survey, any prelim findings?",
  "id" : 573868140150521858,
  "in_reply_to_status_id" : 573591095432601600,
  "created_at" : "2015-03-06 15:30:01 +0000",
  "in_reply_to_screen_name" : "MarekKiczkowiak",
  "in_reply_to_user_id_str" : "2561325079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "PCMag",
      "screen_name" : "PCMag",
      "indices" : [ 13, 19 ],
      "id_str" : "15066271",
      "id" : 15066271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/AeTL02ZDth",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=aE8hn5Yv9NA&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=aE8hn5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "573859545111392256",
  "geo" : { },
  "id_str" : "573860114559598592",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu @PCMag hi peter u may be interested in connection btw commodore computers and raspberry pi https:\/\/t.co\/AeTL02ZDth",
  "id" : 573860114559598592,
  "in_reply_to_status_id" : 573859545111392256,
  "created_at" : "2015-03-06 14:58:07 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573854262528184321",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes thanks for share, how's the conference going?",
  "id" : 573854262528184321,
  "created_at" : "2015-03-06 14:34:52 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 76, 83 ]
    }, {
      "text" : "elt",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "auselt",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "langtech",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/pyNi3zNrHk",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Tg",
      "display_url" : "wp.me\/pgHyE-Tg"
    } ]
  },
  "geo" : { },
  "id_str" : "573838225057296384",
  "text" : "Grassroots language technology: Paul Raine, Apps4Efl http:\/\/t.co\/pyNi3zNrHk #edtech #elt #eltchat #eltchinwag #keltchat #auselt #langtech",
  "id" : 573838225057296384,
  "created_at" : "2015-03-06 13:31:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573822636955942912",
  "geo" : { },
  "id_str" : "573824436660477952",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery does it have spelling variants?",
  "id" : 573824436660477952,
  "in_reply_to_status_id" : 573822636955942912,
  "created_at" : "2015-03-06 12:36:21 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/TGfY2HiSBG",
      "expanded_url" : "http:\/\/wp.me\/p5Lz0Y-2q",
      "display_url" : "wp.me\/p5Lz0Y-2q"
    } ]
  },
  "geo" : { },
  "id_str" : "573771611519713280",
  "text" : "Education Vocabulary http:\/\/t.co\/TGfY2HiSBG via @wordpressdotcom",
  "id" : 573771611519713280,
  "created_at" : "2015-03-06 09:06:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/573430471637536768\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TmlhrRvAZU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_U7-Y0XEAAzgBl.jpg",
      "id_str" : "573430470559600640",
      "id" : 573430470559600640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_U7-Y0XEAAzgBl.jpg",
      "sizes" : [ {
        "h" : 1318,
        "resize" : "fit",
        "w" : 2187
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TmlhrRvAZU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Vh0cMGEeQh",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/788-a-conspiracy-of-silence-hsbc-the-guardian-and-the-defrauded-british-public.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573524776003764224",
  "text" : "RT @medialens: \u2018A Conspiracy Of Silence' - HSBC, The Guardian And The Defrauded British Public.\nNew alert: \nhttp:\/\/t.co\/Vh0cMGEeQh http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/573430471637536768\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/TmlhrRvAZU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_U7-Y0XEAAzgBl.jpg",
        "id_str" : "573430470559600640",
        "id" : 573430470559600640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_U7-Y0XEAAzgBl.jpg",
        "sizes" : [ {
          "h" : 1318,
          "resize" : "fit",
          "w" : 2187
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TmlhrRvAZU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Vh0cMGEeQh",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/788-a-conspiracy-of-silence-hsbc-the-guardian-and-the-defrauded-british-public.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573430471637536768",
    "text" : "\u2018A Conspiracy Of Silence' - HSBC, The Guardian And The Defrauded British Public.\nNew alert: \nhttp:\/\/t.co\/Vh0cMGEeQh http:\/\/t.co\/TmlhrRvAZU",
    "id" : 573430471637536768,
    "created_at" : "2015-03-05 10:30:52 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 573524776003764224,
  "created_at" : "2015-03-05 16:45:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLW Nottingham",
      "screen_name" : "UoN_CLW",
      "indices" : [ 0, 8 ],
      "id_str" : "3055425035",
      "id" : 3055425035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573489743457030144",
  "geo" : { },
  "id_str" : "573517098904915968",
  "in_reply_to_user_id" : 3055425035,
  "text" : "@UoN_CLW ok thx",
  "id" : 573517098904915968,
  "in_reply_to_status_id" : 573489743457030144,
  "created_at" : "2015-03-05 16:15:06 +0000",
  "in_reply_to_screen_name" : "UoN_CLW",
  "in_reply_to_user_id_str" : "3055425035",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/grrrXXG8RK",
      "expanded_url" : "http:\/\/gu.com\/p\/46bt5\/stw",
      "display_url" : "gu.com\/p\/46bt5\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "573513693826314241",
  "text" : "The demonisation of Russia risks paving the way for war | Seumas Milne http:\/\/t.co\/grrrXXG8RK",
  "id" : 573513693826314241,
  "created_at" : "2015-03-05 16:01:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 3, 15 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    }, {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 120, 128 ],
      "id_str" : "374391424",
      "id" : 374391424
    }, {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 129, 140 ],
      "id_str" : "22779473",
      "id" : 22779473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keltchat",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "rppln",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/4cGUUOvkGJ",
      "expanded_url" : "http:\/\/goo.gl\/forms\/fqElr5qStP",
      "display_url" : "goo.gl\/forms\/fqElr5qS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573460561452736512",
  "text" : "RT @NewbieCELTA: Hi! survey of ELTers abt Task Feedback http:\/\/t.co\/4cGUUOvkGJ help inform small prez! thx! :)#keltchat @iTDipro @ELTExperi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "itdi.pro",
        "screen_name" : "iTDipro",
        "indices" : [ 103, 111 ],
        "id_str" : "374391424",
        "id" : 374391424
      }, {
        "name" : "Martin Sketchley",
        "screen_name" : "ELTExperiences",
        "indices" : [ 112, 127 ],
        "id_str" : "22779473",
        "id" : 22779473
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "keltchat",
        "indices" : [ 93, 102 ]
      }, {
        "text" : "rppln",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/4cGUUOvkGJ",
        "expanded_url" : "http:\/\/goo.gl\/forms\/fqElr5qStP",
        "display_url" : "goo.gl\/forms\/fqElr5qS\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573097905344548865",
    "text" : "Hi! survey of ELTers abt Task Feedback http:\/\/t.co\/4cGUUOvkGJ help inform small prez! thx! :)#keltchat @iTDipro @ELTExperiences #rppln",
    "id" : 573097905344548865,
    "created_at" : "2015-03-04 12:29:22 +0000",
    "user" : {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "protected" : false,
      "id_str" : "2311153903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596701364119437312\/aGLFxLe0_normal.jpg",
      "id" : 2311153903,
      "verified" : false
    }
  },
  "id" : 573460561452736512,
  "created_at" : "2015-03-05 12:30:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 10, 23 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573444098293661696",
  "geo" : { },
  "id_str" : "573455534768164864",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson @perezparedes @cilc2015 yr welcome, thx for reminding me about it as i found i needed to update some broken links :)",
  "id" : 573455534768164864,
  "in_reply_to_status_id" : 573444098293661696,
  "created_at" : "2015-03-05 12:10:28 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "auselt",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573425124122202112",
  "text" : "#auselt hi, anyone mentioned twitter lists yet? if not do use them great for filtering :)",
  "id" : 573425124122202112,
  "created_at" : "2015-03-05 10:09:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 18, 27 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 41, 50 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/4OG8Jj7ikO",
      "expanded_url" : "http:\/\/www.perezparedes.es\/big-data-and-corpus-linguistics\/",
      "display_url" : "perezparedes.es\/big-data-and-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573423519545094144",
  "text" : "RT @perezparedes: @muranava mentioned by @perayson in @cilc2015 keynote http:\/\/t.co\/4OG8Jj7ikO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Paul Rayson",
        "screen_name" : "perayson",
        "indices" : [ 23, 32 ],
        "id_str" : "263108959",
        "id" : 263108959
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/4OG8Jj7ikO",
        "expanded_url" : "http:\/\/www.perezparedes.es\/big-data-and-corpus-linguistics\/",
        "display_url" : "perezparedes.es\/big-data-and-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573415865028386816",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava mentioned by @perayson in @cilc2015 keynote http:\/\/t.co\/4OG8Jj7ikO",
    "id" : 573415865028386816,
    "created_at" : "2015-03-05 09:32:50 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 573423519545094144,
  "created_at" : "2015-03-05 10:03:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 14, 23 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573415865028386816",
  "geo" : { },
  "id_str" : "573423138391912448",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes @perayson @cilc2015 cool! thx for mention hope the conference is going great :)",
  "id" : 573423138391912448,
  "in_reply_to_status_id" : 573415865028386816,
  "created_at" : "2015-03-05 10:01:44 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Mozhgan_Savabi",
      "screen_name" : "Mozhgan_Savabi",
      "indices" : [ 136, 140 ],
      "id_str" : "731700276",
      "id" : 731700276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/aaaiNWwh0N",
      "expanded_url" : "http:\/\/www.rachelcarsonprisen.no\/eng\/Prize-Winners\/Mozhgan-Savabieasfahani",
      "display_url" : "rachelcarsonprisen.no\/eng\/Prize-Winn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573413663664689152",
  "text" : "RT @medialens: Rachel Carson Prize awarded to Dr. Mozhgan Savabieasfahani for research on birth defects in Iraq: http:\/\/t.co\/aaaiNWwh0N @Mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozhgan_Savabi",
        "screen_name" : "Mozhgan_Savabi",
        "indices" : [ 121, 136 ],
        "id_str" : "731700276",
        "id" : 731700276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/aaaiNWwh0N",
        "expanded_url" : "http:\/\/www.rachelcarsonprisen.no\/eng\/Prize-Winners\/Mozhgan-Savabieasfahani",
        "display_url" : "rachelcarsonprisen.no\/eng\/Prize-Winn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573365008211554304",
    "text" : "Rachel Carson Prize awarded to Dr. Mozhgan Savabieasfahani for research on birth defects in Iraq: http:\/\/t.co\/aaaiNWwh0N @Mozhgan_Savabi",
    "id" : 573365008211554304,
    "created_at" : "2015-03-05 06:10:45 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 573413663664689152,
  "created_at" : "2015-03-05 09:24:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573256223354589184",
  "geo" : { },
  "id_str" : "573259417040359424",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim yr welcome, some interesting things there for sure",
  "id" : 573259417040359424,
  "in_reply_to_status_id" : 573256223354589184,
  "created_at" : "2015-03-04 23:11:10 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/kn3KHLVhQ9",
      "expanded_url" : "http:\/\/explore.tandfonline.com\/page\/ed\/international-and-foreign-language-students",
      "display_url" : "explore.tandfonline.com\/page\/ed\/intern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573255429339422720",
  "text" : "Free Article Collection till 31st December 2015 http:\/\/t.co\/kn3KHLVhQ9 #eltchat",
  "id" : 573255429339422720,
  "created_at" : "2015-03-04 22:55:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 0, 16 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/anx3MkRFkZ",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/13488678.2014.880252",
      "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573254286206881792",
  "in_reply_to_user_id" : 2561325079,
  "text" : "@MarekKiczkowiak hi seen this? An exploratory study of Hong Kong students\u2019 perceptions of N\/NESTs in ELT http:\/\/t.co\/anx3MkRFkZ",
  "id" : 573254286206881792,
  "created_at" : "2015-03-04 22:50:47 +0000",
  "in_reply_to_screen_name" : "MarekKiczkowiak",
  "in_reply_to_user_id_str" : "2561325079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nurph",
      "screen_name" : "Nurph",
      "indices" : [ 30, 36 ],
      "id_str" : "164768029",
      "id" : 164768029
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573243444388372480",
  "text" : "thanks all #eltchat lk fwd to @nurph replay",
  "id" : 573243444388372480,
  "created_at" : "2015-03-04 22:07:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 23, 34 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573242007151230977",
  "geo" : { },
  "id_str" : "573242288815652864",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol @HadaLitim @naomishema \/thumbs up\/ :) #eltchat",
  "id" : 573242288815652864,
  "in_reply_to_status_id" : 573242007151230977,
  "created_at" : "2015-03-04 22:03:06 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 23, 34 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573239713068277760",
  "geo" : { },
  "id_str" : "573241202956509185",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol @HadaLitim @naomishema been interested for texting-in-class-use but my imagination is limited :( any pointers? thx",
  "id" : 573241202956509185,
  "in_reply_to_status_id" : 573239713068277760,
  "created_at" : "2015-03-04 21:58:47 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 23, 34 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573238198597386240",
  "geo" : { },
  "id_str" : "573239333131575296",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol @HadaLitim @naomishema hi, what kind of txting things? #eltchat",
  "id" : 573239333131575296,
  "in_reply_to_status_id" : 573238198597386240,
  "created_at" : "2015-03-04 21:51:21 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    }, {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 58, 71 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/fzr8U9vKVM",
      "expanded_url" : "http:\/\/ske.li\/b2d",
      "display_url" : "ske.li\/b2d"
    } ]
  },
  "geo" : { },
  "id_str" : "573088439660351488",
  "text" : "RT @SketchEngine: Have you ever tried multiword sketch in @SketchEngine? It is nice tool for studying MWEs in (large) corpora. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sketch Engine",
        "screen_name" : "SketchEngine",
        "indices" : [ 40, 53 ],
        "id_str" : "841197134",
        "id" : 841197134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/fzr8U9vKVM",
        "expanded_url" : "http:\/\/ske.li\/b2d",
        "display_url" : "ske.li\/b2d"
      } ]
    },
    "geo" : { },
    "id_str" : "573059310927941632",
    "text" : "Have you ever tried multiword sketch in @SketchEngine? It is nice tool for studying MWEs in (large) corpora. http:\/\/t.co\/fzr8U9vKVM",
    "id" : 573059310927941632,
    "created_at" : "2015-03-04 09:56:01 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 573088439660351488,
  "created_at" : "2015-03-04 11:51:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/TM1CUCTVa9",
      "expanded_url" : "http:\/\/landdestroyer.blogspot.com\/2015\/03\/obama-netanyahu-fallout-is-theater.html?spref=tw",
      "display_url" : "landdestroyer.blogspot.com\/2015\/03\/obama-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572907422123200512",
  "text" : "Obama-Netanyahu \"Fallout\" is Theater - Planned in 2009 http:\/\/t.co\/TM1CUCTVa9",
  "id" : 572907422123200512,
  "created_at" : "2015-03-03 23:52:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572896952578416640",
  "geo" : { },
  "id_str" : "572897144304218112",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 just saw the vid he certainly appears so, bless :)",
  "id" : 572897144304218112,
  "in_reply_to_status_id" : 572896952578416640,
  "created_at" : "2015-03-03 23:11:37 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572896515636781056",
  "geo" : { },
  "id_str" : "572896718741749761",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 my surprise at the news no idea he was in a relationship after his wife passed",
  "id" : 572896718741749761,
  "in_reply_to_status_id" : 572896515636781056,
  "created_at" : "2015-03-03 23:09:56 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572895013723623425",
  "geo" : { },
  "id_str" : "572896398187880448",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 woah :)",
  "id" : 572896398187880448,
  "in_reply_to_status_id" : 572895013723623425,
  "created_at" : "2015-03-03 23:08:39 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Jane Solomon",
      "screen_name" : "janesolomon",
      "indices" : [ 111, 123 ],
      "id_str" : "70704540",
      "id" : 70704540
    }, {
      "name" : "Orion Montoya",
      "screen_name" : "mdcclv",
      "indices" : [ 124, 131 ],
      "id_str" : "7586132",
      "id" : 7586132
    }, {
      "name" : "M. Rebekah Otto",
      "screen_name" : "bekahotto",
      "indices" : [ 132, 140 ],
      "id_str" : "29496060",
      "id" : 29496060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/hRj6snNAdc",
      "expanded_url" : "http:\/\/idibon.com\/future-dictionary\/",
      "display_url" : "idibon.com\/future-diction\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572889196307869696",
  "text" : "RT @TSchnoebelen: Notes on The Future of the Dictionary \/ The Dictionary of the Future: http:\/\/t.co\/hRj6snNAdc @janesolomon @mdcclv @bekaho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Solomon",
        "screen_name" : "janesolomon",
        "indices" : [ 93, 105 ],
        "id_str" : "70704540",
        "id" : 70704540
      }, {
        "name" : "Orion Montoya",
        "screen_name" : "mdcclv",
        "indices" : [ 106, 113 ],
        "id_str" : "7586132",
        "id" : 7586132
      }, {
        "name" : "M. Rebekah Otto",
        "screen_name" : "bekahotto",
        "indices" : [ 114, 124 ],
        "id_str" : "29496060",
        "id" : 29496060
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/hRj6snNAdc",
        "expanded_url" : "http:\/\/idibon.com\/future-dictionary\/",
        "display_url" : "idibon.com\/future-diction\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "572854964134912002",
    "text" : "Notes on The Future of the Dictionary \/ The Dictionary of the Future: http:\/\/t.co\/hRj6snNAdc @janesolomon @mdcclv @bekahotto",
    "id" : 572854964134912002,
    "created_at" : "2015-03-03 20:24:01 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 572889196307869696,
  "created_at" : "2015-03-03 22:40:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 103, 111 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/TmODrVftfY",
      "expanded_url" : "http:\/\/youtu.be\/mlaVHxUSiNk",
      "display_url" : "youtu.be\/mlaVHxUSiNk"
    } ]
  },
  "geo" : { },
  "id_str" : "572874695072079873",
  "text" : "Two-in-one photography: Light as wave and particle! (sous-titres fran\u00E7ais): http:\/\/t.co\/TmODrVftfY via @YouTube",
  "id" : 572874695072079873,
  "created_at" : "2015-03-03 21:42:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 98, 113 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/9xkAHF3Zpu",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4Qe",
      "display_url" : "wp.me\/p93oK-4Qe"
    } ]
  },
  "geo" : { },
  "id_str" : "572873291213352961",
  "text" : "'By God, believe in something' - Michael Sheen's St David's Day Speech http:\/\/t.co\/9xkAHF3Zpu via @bellacaledonia",
  "id" : 572873291213352961,
  "created_at" : "2015-03-03 21:36:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Almude\u03B7\u03B1 Fern\u00E1nde\u0225",
      "screen_name" : "almudena_fdez",
      "indices" : [ 0, 14 ],
      "id_str" : "70230255",
      "id" : 70230255
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/malee_saru\/status\/567214722907254784\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/CJpaUwOyHs",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B98mqgeIEAA3XiD.png",
      "id_str" : "567214589784625152",
      "id" : 567214589784625152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B98mqgeIEAA3XiD.png",
      "sizes" : [ {
        "h" : 820,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/CJpaUwOyHs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572795415277522944",
  "geo" : { },
  "id_str" : "572796666497126400",
  "in_reply_to_user_id" : 70230255,
  "text" : "@almudena_fdez have u seen this one? https:\/\/t.co\/CJpaUwOyHs :)",
  "id" : 572796666497126400,
  "in_reply_to_status_id" : 572795415277522944,
  "created_at" : "2015-03-03 16:32:21 +0000",
  "in_reply_to_screen_name" : "almudena_fdez",
  "in_reply_to_user_id_str" : "70230255",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 3, 14 ],
      "id_str" : "857732892",
      "id" : 857732892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/sEzlC8NIsO",
      "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/03\/phrasal-verbs-myths-and-realities\/",
      "display_url" : "lexicallab.com\/2015\/03\/phrasa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572750861950185475",
  "text" : "RT @LexicalLab: Everything you ever wanted to know about phrasal verbs, but were afraid to ask! New guest post on our website: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/sEzlC8NIsO",
        "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/03\/phrasal-verbs-myths-and-realities\/",
        "display_url" : "lexicallab.com\/2015\/03\/phrasa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "572746993979797504",
    "text" : "Everything you ever wanted to know about phrasal verbs, but were afraid to ask! New guest post on our website: http:\/\/t.co\/sEzlC8NIsO",
    "id" : 572746993979797504,
    "created_at" : "2015-03-03 13:14:59 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 572750861950185475,
  "created_at" : "2015-03-03 13:30:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/DS4nroIwYz",
      "expanded_url" : "http:\/\/interc.pt\/1M3OY3R",
      "display_url" : "interc.pt\/1M3OY3R"
    } ]
  },
  "geo" : { },
  "id_str" : "572496204715692032",
  "text" : "UK Media Regulator Again Threatens RT for \u201CBias\u201D: This Time, Airing \u201CAnti-Western Views\u201D http:\/\/t.co\/DS4nroIwYz",
  "id" : 572496204715692032,
  "created_at" : "2015-03-02 20:38:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 28, 40 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/2dXORCGbLL",
      "expanded_url" : "https:\/\/medium.com\/@NafeezAhmed\/death-drugs-and-hsbc-355ed9ef5316?source=tw-lo_dnt_5e1adef67db3-1425322286820",
      "display_url" : "medium.com\/@NafeezAhmed\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572469308611297281",
  "text" : "\u201CDeath, drugs, and HSBC\u201D by @NafeezAhmed https:\/\/t.co\/2dXORCGbLL",
  "id" : 572469308611297281,
  "created_at" : "2015-03-02 18:51:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strong Language",
      "screen_name" : "stronglang",
      "indices" : [ 48, 59 ],
      "id_str" : "2918426355",
      "id" : 2918426355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/A6MBrozMgh",
      "expanded_url" : "http:\/\/wp.me\/p5sCW4-gl",
      "display_url" : "wp.me\/p5sCW4-gl"
    } ]
  },
  "geo" : { },
  "id_str" : "572417871827079168",
  "text" : "Women give more shit http:\/\/t.co\/A6MBrozMgh via @stronglang",
  "id" : 572417871827079168,
  "created_at" : "2015-03-02 15:27:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tec15",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "eltindia",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/rRlwdYNrZu",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-bn",
      "display_url" : "wp.me\/p3sNrs-bn"
    } ]
  },
  "geo" : { },
  "id_str" : "572415990765621249",
  "text" : "RT @adi_rajan: TEC15 Day 2 | Using the Collins Dictionary Corpus | Talk summary #tec15 #eltindia http:\/\/t.co\/rRlwdYNrZu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tec15",
        "indices" : [ 65, 71 ]
      }, {
        "text" : "eltindia",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/rRlwdYNrZu",
        "expanded_url" : "http:\/\/wp.me\/p3sNrs-bn",
        "display_url" : "wp.me\/p3sNrs-bn"
      } ]
    },
    "geo" : { },
    "id_str" : "572414939450634240",
    "text" : "TEC15 Day 2 | Using the Collins Dictionary Corpus | Talk summary #tec15 #eltindia http:\/\/t.co\/rRlwdYNrZu",
    "id" : 572414939450634240,
    "created_at" : "2015-03-02 15:15:31 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 572415990765621249,
  "created_at" : "2015-03-02 15:19:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Travelocity",
      "screen_name" : "travelocity",
      "indices" : [ 45, 57 ],
      "id_str" : "18819574",
      "id" : 18819574
    }, {
      "name" : "Travelocity Help",
      "screen_name" : "TravelocityHelp",
      "indices" : [ 64, 80 ],
      "id_str" : "1877047459",
      "id" : 1877047459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572410083222659075",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin sorry about yr bad exp with @travelocity &amp; @TravelocityHelp not used them &amp; now never will",
  "id" : 572410083222659075,
  "created_at" : "2015-03-02 14:56:13 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Travelocity",
      "screen_name" : "travelocity",
      "indices" : [ 102, 114 ],
      "id_str" : "18819574",
      "id" : 18819574
    }, {
      "name" : "Travelocity Help",
      "screen_name" : "TravelocityHelp",
      "indices" : [ 139, 140 ],
      "id_str" : "1877047459",
      "id" : 1877047459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572399004111245313",
  "text" : "RT @michaelegriffin: Hello friends. I'd consider it a personal favor if you do your best to never use @travelocity again. Thanks for nothin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Travelocity",
        "screen_name" : "travelocity",
        "indices" : [ 81, 93 ],
        "id_str" : "18819574",
        "id" : 18819574
      }, {
        "name" : "Travelocity Help",
        "screen_name" : "TravelocityHelp",
        "indices" : [ 120, 136 ],
        "id_str" : "1877047459",
        "id" : 1877047459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "565175633534152705",
    "geo" : { },
    "id_str" : "572396740885626881",
    "in_reply_to_user_id" : 394053348,
    "text" : "Hello friends. I'd consider it a personal favor if you do your best to never use @travelocity again. Thanks for nothing @TravelocityHelp!",
    "id" : 572396740885626881,
    "in_reply_to_status_id" : 565175633534152705,
    "created_at" : "2015-03-02 14:03:12 +0000",
    "in_reply_to_screen_name" : "michaelegriffin",
    "in_reply_to_user_id_str" : "394053348",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 572399004111245313,
  "created_at" : "2015-03-02 14:12:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/u9bL9Wvl4o",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/02\/just-keeping-order-in-playground.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/02\/just-k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572140430973927426",
  "text" : "RT @pchallinor: New mudgeonry: Just keeping order in the playground http:\/\/t.co\/u9bL9Wvl4o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/u9bL9Wvl4o",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/02\/just-keeping-order-in-playground.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/02\/just-k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570935276622585857",
    "text" : "New mudgeonry: Just keeping order in the playground http:\/\/t.co\/u9bL9Wvl4o",
    "id" : 570935276622585857,
    "created_at" : "2015-02-26 13:15:52 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 572140430973927426,
  "created_at" : "2015-03-01 21:04:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572110919024525312",
  "geo" : { },
  "id_str" : "572111402133024770",
  "in_reply_to_user_id" : 1479290418,
  "text" : "@usage_based it's like shrugging your shoulders",
  "id" : 572111402133024770,
  "in_reply_to_status_id" : 572110919024525312,
  "created_at" : "2015-03-01 19:09:22 +0000",
  "in_reply_to_screen_name" : "usage_based",
  "in_reply_to_user_id_str" : "1479290418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 83, 99 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/znEY04Lvif",
      "expanded_url" : "http:\/\/wp.me\/p16czy-el",
      "display_url" : "wp.me\/p16czy-el"
    } ]
  },
  "geo" : { },
  "id_str" : "572109848910929920",
  "text" : "If you're not a linguist, don't do linguistic research: http:\/\/t.co\/znEY04Lvif via @wordpressdotcom",
  "id" : 572109848910929920,
  "created_at" : "2015-03-01 19:03:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571730609921495041",
  "geo" : { },
  "id_str" : "571819316053729280",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hi Leo cheers for share :)",
  "id" : 571819316053729280,
  "in_reply_to_status_id" : 571730609921495041,
  "created_at" : "2015-02-28 23:48:43 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]