Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Z9YgoISGKU",
      "expanded_url" : "http:\/\/www.counterfire.org\/articles\/analysis\/17971-time-is-tight-the-challenges-to-jeremy-corbyn-s-campaign",
      "display_url" : "counterfire.org\/articles\/analy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638368914737614849",
  "text" : "Time is tight: the challenges to Jeremy Corbyn\u2019s campaign http:\/\/t.co\/Z9YgoISGKU",
  "id" : 638368914737614849,
  "created_at" : "2015-08-31 15:13:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Greg Ashman",
      "screen_name" : "greg_ashman",
      "indices" : [ 22, 34 ],
      "id_str" : "614246029",
      "id" : 614246029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638327282990321664",
  "geo" : { },
  "id_str" : "638350234721079296",
  "in_reply_to_user_id" : 614246029,
  "text" : "@thisbyanychance tell @greg_ashman more about spelling 85%",
  "id" : 638350234721079296,
  "in_reply_to_status_id" : 638327282990321664,
  "created_at" : "2015-08-31 13:58:50 +0000",
  "in_reply_to_screen_name" : "greg_ashman",
  "in_reply_to_user_id_str" : "614246029",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638349742678888448",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava more about spelling 85%",
  "id" : 638349742678888448,
  "created_at" : "2015-08-31 13:56:53 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638342058411995136",
  "geo" : { },
  "id_str" : "638343759449706496",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo lordy stack-a-slave-tris :\/",
  "id" : 638343759449706496,
  "in_reply_to_status_id" : 638342058411995136,
  "created_at" : "2015-08-31 13:33:06 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 17, 23 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 51, 67 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638326117242286080",
  "geo" : { },
  "id_str" : "638326945021886464",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @ebefl cheers Marc will add it to @thisbyanychance",
  "id" : 638326945021886464,
  "in_reply_to_status_id" : 638326117242286080,
  "created_at" : "2015-08-31 12:26:17 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "indices" : [ 3, 18 ],
      "id_str" : "20098015",
      "id" : 20098015
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidschneider\/status\/638258752400039936\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/bxJKOwS9OD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNuM8-YWcAAyH8y.png",
      "id_str" : "638258751368228864",
      "id" : 638258751368228864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNuM8-YWcAAyH8y.png",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bxJKOwS9OD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638314561297379328",
  "text" : "RT @davidschneider: Jeremy Corbyn: a guide to selective quoting. http:\/\/t.co\/bxJKOwS9OD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/davidschneider\/status\/638258752400039936\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/bxJKOwS9OD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNuM8-YWcAAyH8y.png",
        "id_str" : "638258751368228864",
        "id" : 638258751368228864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNuM8-YWcAAyH8y.png",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bxJKOwS9OD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638258752400039936",
    "text" : "Jeremy Corbyn: a guide to selective quoting. http:\/\/t.co\/bxJKOwS9OD",
    "id" : 638258752400039936,
    "created_at" : "2015-08-31 07:55:19 +0000",
    "user" : {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "protected" : false,
      "id_str" : "20098015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/85074940\/profilepic_normal.jpg",
      "id" : 20098015,
      "verified" : true
    }
  },
  "id" : 638314561297379328,
  "created_at" : "2015-08-31 11:37:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Olson",
      "screen_name" : "mark_olson",
      "indices" : [ 0, 11 ],
      "id_str" : "3688491",
      "id" : 3688491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638146695222595584",
  "in_reply_to_user_id" : 3688491,
  "text" : "@mark_olson hi there was wondering if you had done any more on storyboard? thx!",
  "id" : 638146695222595584,
  "created_at" : "2015-08-31 00:30:02 +0000",
  "in_reply_to_screen_name" : "mark_olson",
  "in_reply_to_user_id_str" : "3688491",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/85b5c8nyST",
      "expanded_url" : "http:\/\/www.sodiumhaze.org\/2015\/08\/29\/golden-corby-awards-vote-now-for-the-most-hapless-anti-corbyn-hack\/",
      "display_url" : "sodiumhaze.org\/2015\/08\/29\/gol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638029891791900673",
  "text" : "Golden Corby awards \u2013 vote now for the most hapless anti-Corbyn hack http:\/\/t.co\/85b5c8nyST",
  "id" : 638029891791900673,
  "created_at" : "2015-08-30 16:45:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637674841072607232",
  "geo" : { },
  "id_str" : "637676770964148225",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan me too :\/",
  "id" : 637676770964148225,
  "in_reply_to_status_id" : 637674841072607232,
  "created_at" : "2015-08-29 17:22:44 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637673715803770880",
  "geo" : { },
  "id_str" : "637673983840788480",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher a pleasure looking fwd to reading about dysfluency",
  "id" : 637673983840788480,
  "in_reply_to_status_id" : 637673715803770880,
  "created_at" : "2015-08-29 17:11:39 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/637251149607911424\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/9lD8LapknF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNf4iuFW8AEsbA3.png",
      "id_str" : "637251147665960961",
      "id" : 637251147665960961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNf4iuFW8AEsbA3.png",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 865
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 865
      } ],
      "display_url" : "pic.twitter.com\/9lD8LapknF"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/rz80LLXY5q",
      "expanded_url" : "http:\/\/bit.ly\/1JvMNCf",
      "display_url" : "bit.ly\/1JvMNCf"
    } ]
  },
  "geo" : { },
  "id_str" : "637671065234337792",
  "text" : "RT @DonaldClark: Top 10 stupid mistakes in design of Multiple Choice questions #edtech http:\/\/t.co\/rz80LLXY5q http:\/\/t.co\/9lD8LapknF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/637251149607911424\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/9lD8LapknF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNf4iuFW8AEsbA3.png",
        "id_str" : "637251147665960961",
        "id" : 637251147665960961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNf4iuFW8AEsbA3.png",
        "sizes" : [ {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 865
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 865
        } ],
        "display_url" : "pic.twitter.com\/9lD8LapknF"
      } ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 62, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/rz80LLXY5q",
        "expanded_url" : "http:\/\/bit.ly\/1JvMNCf",
        "display_url" : "bit.ly\/1JvMNCf"
      } ]
    },
    "geo" : { },
    "id_str" : "637251149607911424",
    "text" : "Top 10 stupid mistakes in design of Multiple Choice questions #edtech http:\/\/t.co\/rz80LLXY5q http:\/\/t.co\/9lD8LapknF",
    "id" : 637251149607911424,
    "created_at" : "2015-08-28 13:11:28 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 637671065234337792,
  "created_at" : "2015-08-29 17:00:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/637646570108882944\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/vKPXplFwq8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNlgLSNWoAEHO84.png",
      "id_str" : "637646569232310273",
      "id" : 637646569232310273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNlgLSNWoAEHO84.png",
      "sizes" : [ {
        "h" : 303,
        "resize" : "fit",
        "w" : 313
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 313
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 313
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 313
      } ],
      "display_url" : "pic.twitter.com\/vKPXplFwq8"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/YtrAxwsqKF",
      "expanded_url" : "http:\/\/bit.ly\/1JnUo6J",
      "display_url" : "bit.ly\/1JnUo6J"
    } ]
  },
  "geo" : { },
  "id_str" : "637670312230920194",
  "text" : "RT @DonaldClark: 10 essential online learning writing tips &amp; psychology behind them #edtech  http:\/\/t.co\/YtrAxwsqKF http:\/\/t.co\/vKPXplFwq8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/637646570108882944\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/vKPXplFwq8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNlgLSNWoAEHO84.png",
        "id_str" : "637646569232310273",
        "id" : 637646569232310273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNlgLSNWoAEHO84.png",
        "sizes" : [ {
          "h" : 303,
          "resize" : "fit",
          "w" : 313
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 313
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 313
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 313
        } ],
        "display_url" : "pic.twitter.com\/vKPXplFwq8"
      } ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/YtrAxwsqKF",
        "expanded_url" : "http:\/\/bit.ly\/1JnUo6J",
        "display_url" : "bit.ly\/1JnUo6J"
      } ]
    },
    "geo" : { },
    "id_str" : "637646570108882944",
    "text" : "10 essential online learning writing tips &amp; psychology behind them #edtech  http:\/\/t.co\/YtrAxwsqKF http:\/\/t.co\/vKPXplFwq8",
    "id" : 637646570108882944,
    "created_at" : "2015-08-29 15:22:43 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 637670312230920194,
  "created_at" : "2015-08-29 16:57:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 84, 99 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/Vr3b6l2hUl",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-wtf-what-the-font-typography-and-elt",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637669355015307264",
  "text" : "Research Bites: WTF: What The Font? - Typography and ELT http:\/\/t.co\/Vr3b6l2hUl via @AnthonyTeacher",
  "id" : 637669355015307264,
  "created_at" : "2015-08-29 16:53:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "indices" : [ 139, 140 ],
      "id_str" : "23783700",
      "id" : 23783700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637653958748733440",
  "text" : "RT @TonyMcEnery: The #corpusMOOC starts in 1 month! Includes a great new conversation about dictionary production with Michael Rundell of @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Macmillan Dictionary",
        "screen_name" : "MacDictionary",
        "indices" : [ 121, 135 ],
        "id_str" : "23783700",
        "id" : 23783700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637605041361301504",
    "text" : "The #corpusMOOC starts in 1 month! Includes a great new conversation about dictionary production with Michael Rundell of @MacDictionary",
    "id" : 637605041361301504,
    "created_at" : "2015-08-29 12:37:42 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 637653958748733440,
  "created_at" : "2015-08-29 15:52:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637279227235172352",
  "geo" : { },
  "id_str" : "637300459661864960",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites thx i faved yr RT earlier :)",
  "id" : 637300459661864960,
  "in_reply_to_status_id" : 637279227235172352,
  "created_at" : "2015-08-28 16:27:24 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/Uln2puBMAt",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/08\/beware-of-chilcot\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637239836311687168",
  "text" : "RT @CraigMurrayOrg: New post: Beware of Chilcot http:\/\/t.co\/Uln2puBMAt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/Uln2puBMAt",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/08\/beware-of-chilcot\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637230787847450624",
    "text" : "New post: Beware of Chilcot http:\/\/t.co\/Uln2puBMAt",
    "id" : 637230787847450624,
    "created_at" : "2015-08-28 11:50:33 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 637239836311687168,
  "created_at" : "2015-08-28 12:26:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bodo Winter",
      "screen_name" : "BodoWinter",
      "indices" : [ 3, 14 ],
      "id_str" : "3239583325",
      "id" : 3239583325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PT6aBUmtYu",
      "expanded_url" : "http:\/\/languagegoldmine.com\/",
      "display_url" : "languagegoldmine.com"
    } ]
  },
  "geo" : { },
  "id_str" : "637048643321790464",
  "text" : "RT @BodoWinter: Just released The Language Goldmine: A lightweight list of linguistic databases, suggestions welcome: http:\/\/t.co\/PT6aBUmtYu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/PT6aBUmtYu",
        "expanded_url" : "http:\/\/languagegoldmine.com\/",
        "display_url" : "languagegoldmine.com"
      } ]
    },
    "geo" : { },
    "id_str" : "636536976007659520",
    "text" : "Just released The Language Goldmine: A lightweight list of linguistic databases, suggestions welcome: http:\/\/t.co\/PT6aBUmtYu",
    "id" : 636536976007659520,
    "created_at" : "2015-08-26 13:53:36 +0000",
    "user" : {
      "name" : "Bodo Winter",
      "screen_name" : "BodoWinter",
      "protected" : false,
      "id_str" : "3239583325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607801072879468544\/seKGk4SI_normal.png",
      "id" : 3239583325,
      "verified" : false
    }
  },
  "id" : 637048643321790464,
  "created_at" : "2015-08-27 23:46:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ZRBHhwj9ue",
      "expanded_url" : "http:\/\/gu.com\/p\/4bp7z\/stw",
      "display_url" : "gu.com\/p\/4bp7z\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "636989045910962177",
  "text" : "How will Labour top losing the election? By losing its own leadership contest | Frankie Boyle http:\/\/t.co\/ZRBHhwj9ue",
  "id" : 636989045910962177,
  "created_at" : "2015-08-27 19:49:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/OvMPb4SMy6",
      "expanded_url" : "https:\/\/twitter.com\/holden\/status\/636619388880203776",
      "display_url" : "twitter.com\/holden\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636679829102850048",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard Rose think you will like this :) https:\/\/t.co\/OvMPb4SMy6",
  "id" : 636679829102850048,
  "created_at" : "2015-08-26 23:21:14 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/RTFN7QYCB7",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/08\/25\/battle-the-status-quo-in-your-classroom\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/08\/25\/bat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636452844166586368",
  "text" : "RT @getgreatenglish: Sick of work? I was too. This might be a way to reclaim some pleasure. https:\/\/t.co\/RTFN7QYCB7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/RTFN7QYCB7",
        "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/08\/25\/battle-the-status-quo-in-your-classroom\/",
        "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/08\/25\/bat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636438787875143680",
    "text" : "Sick of work? I was too. This might be a way to reclaim some pleasure. https:\/\/t.co\/RTFN7QYCB7",
    "id" : 636438787875143680,
    "created_at" : "2015-08-26 07:23:26 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 636452844166586368,
  "created_at" : "2015-08-26 08:19:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Haile",
      "screen_name" : "shikorina78",
      "indices" : [ 3, 15 ],
      "id_str" : "246031350",
      "id" : 246031350
    }, {
      "name" : "Oxford Dictionaries",
      "screen_name" : "OxfordWords",
      "indices" : [ 101, 113 ],
      "id_str" : "249150179",
      "id" : 249150179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bm1iukmMC8",
      "expanded_url" : "https:\/\/twitter.com\/robinsloan\/status\/636276665891459072",
      "display_url" : "twitter.com\/robinsloan\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636312739284131840",
  "text" : "RT @shikorina78: Fascinating! Wonder if someone can do the same with the Oxford Learners Dictionary? @OxfordWords https:\/\/t.co\/bm1iukmMC8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oxford Dictionaries",
        "screen_name" : "OxfordWords",
        "indices" : [ 84, 96 ],
        "id_str" : "249150179",
        "id" : 249150179
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/bm1iukmMC8",
        "expanded_url" : "https:\/\/twitter.com\/robinsloan\/status\/636276665891459072",
        "display_url" : "twitter.com\/robinsloan\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636294605097574400",
    "text" : "Fascinating! Wonder if someone can do the same with the Oxford Learners Dictionary? @OxfordWords https:\/\/t.co\/bm1iukmMC8",
    "id" : 636294605097574400,
    "created_at" : "2015-08-25 21:50:30 +0000",
    "user" : {
      "name" : "Debbie Haile",
      "screen_name" : "shikorina78",
      "protected" : false,
      "id_str" : "246031350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480842156911779840\/vEI4IBsB_normal.jpeg",
      "id" : 246031350,
      "verified" : false
    }
  },
  "id" : 636312739284131840,
  "created_at" : "2015-08-25 23:02:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    }, {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 11, 25 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636271883676160000",
  "geo" : { },
  "id_str" : "636278722925043712",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway @englishbanana may not have CBs but possibly CB mentality :\/",
  "id" : 636278722925043712,
  "in_reply_to_status_id" : 636271883676160000,
  "created_at" : "2015-08-25 20:47:23 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/IVmk6LosPv",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/missionary-man.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/missio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636276259090206720",
  "text" : "RT @pchallinor: New mudgeonry: Missionary man http:\/\/t.co\/IVmk6LosPv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/IVmk6LosPv",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/missionary-man.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/missio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636253845803433985",
    "text" : "New mudgeonry: Missionary man http:\/\/t.co\/IVmk6LosPv",
    "id" : 636253845803433985,
    "created_at" : "2015-08-25 19:08:32 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 636276259090206720,
  "created_at" : "2015-08-25 20:37:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 80, 94 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/0XlhuFlTDq",
      "expanded_url" : "http:\/\/englishbanana.com\/teaching-english\/teach-english-without-a-course-book-free-resources\/",
      "display_url" : "englishbanana.com\/teaching-engli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636267936219549697",
  "text" : "Teach English without a Course Book - FREE Resources http:\/\/t.co\/0XlhuFlTDq via @englishbanana",
  "id" : 636267936219549697,
  "created_at" : "2015-08-25 20:04:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636256629206458369",
  "geo" : { },
  "id_str" : "636262679590649856",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 my pleasure a very good post :)",
  "id" : 636262679590649856,
  "in_reply_to_status_id" : 636256629206458369,
  "created_at" : "2015-08-25 19:43:38 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/636119814730346496\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PxOmxjItpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNPzmadWIAEhmhr.png",
      "id_str" : "636119813652357121",
      "id" : 636119813652357121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNPzmadWIAEhmhr.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/PxOmxjItpf"
    } ],
    "hashtags" : [ {
      "text" : "Labour",
      "indices" : [ 105, 112 ]
    }, {
      "text" : "Corbyn",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/bjzPV5CddC",
      "expanded_url" : "http:\/\/www.wrestlingwithneoliberalism.com\/",
      "display_url" : "wrestlingwithneoliberalism.com"
    } ]
  },
  "geo" : { },
  "id_str" : "636254701135208448",
  "text" : "RT @josipa74: Thatcher, Miner's Strike &amp; Big Daddy\u2014what more could you want? http:\/\/t.co\/bjzPV5CddC  #Labour #Corbyn http:\/\/t.co\/PxOmxjItpf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/636119814730346496\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/PxOmxjItpf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNPzmadWIAEhmhr.png",
        "id_str" : "636119813652357121",
        "id" : 636119813652357121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNPzmadWIAEhmhr.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        } ],
        "display_url" : "pic.twitter.com\/PxOmxjItpf"
      } ],
      "hashtags" : [ {
        "text" : "Labour",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "Corbyn",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/bjzPV5CddC",
        "expanded_url" : "http:\/\/www.wrestlingwithneoliberalism.com\/",
        "display_url" : "wrestlingwithneoliberalism.com"
      } ]
    },
    "geo" : { },
    "id_str" : "636119814730346496",
    "text" : "Thatcher, Miner's Strike &amp; Big Daddy\u2014what more could you want? http:\/\/t.co\/bjzPV5CddC  #Labour #Corbyn http:\/\/t.co\/PxOmxjItpf",
    "id" : 636119814730346496,
    "created_at" : "2015-08-25 10:15:57 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 636254701135208448,
  "created_at" : "2015-08-25 19:11:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 75, 90 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/Fg47RVjMn6",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1mi",
      "display_url" : "wp.me\/p3qkCB-1mi"
    } ]
  },
  "geo" : { },
  "id_str" : "636254083050041344",
  "text" : "Are we on the brink of a paradigm shift in ELT? http:\/\/t.co\/Fg47RVjMn6 via @GeoffreyJordan",
  "id" : 636254083050041344,
  "created_at" : "2015-08-25 19:09:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 10, 20 ],
      "id_str" : "124707247",
      "id" : 124707247
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 21, 33 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636094755785584640",
  "geo" : { },
  "id_str" : "636253744171233281",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @curvedway @eltresearch thanks folks :)",
  "id" : 636253744171233281,
  "in_reply_to_status_id" : 636094755785584640,
  "created_at" : "2015-08-25 19:08:08 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carmen Herrero",
      "screen_name" : "CarmenHerrero14",
      "indices" : [ 0, 16 ],
      "id_str" : "561174293",
      "id" : 561174293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636108277974233089",
  "geo" : { },
  "id_str" : "636253446312718340",
  "in_reply_to_user_id" : 561174293,
  "text" : "@CarmenHerrero14 thanks for sharing :)",
  "id" : 636253446312718340,
  "in_reply_to_status_id" : 636108277974233089,
  "created_at" : "2015-08-25 19:06:57 +0000",
  "in_reply_to_screen_name" : "CarmenHerrero14",
  "in_reply_to_user_id_str" : "561174293",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sententiae antiquae",
      "screen_name" : "sentantiq",
      "indices" : [ 0, 10 ],
      "id_str" : "396163676",
      "id" : 396163676
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 11, 18 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635917781368631297",
  "geo" : { },
  "id_str" : "635918608489689089",
  "in_reply_to_user_id" : 396163676,
  "text" : "@sentantiq @DiLeed Donald Trump must be one of the most free currently ;)",
  "id" : 635918608489689089,
  "in_reply_to_status_id" : 635917781368631297,
  "created_at" : "2015-08-24 20:56:25 +0000",
  "in_reply_to_screen_name" : "sentantiq",
  "in_reply_to_user_id_str" : "396163676",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Ashman",
      "screen_name" : "greg_ashman",
      "indices" : [ 50, 62 ],
      "id_str" : "614246029",
      "id" : 614246029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/0q2ijZKWiS",
      "expanded_url" : "http:\/\/wp.me\/p3A026-1Z",
      "display_url" : "wp.me\/p3A026-1Z"
    } ]
  },
  "geo" : { },
  "id_str" : "635796050326999041",
  "text" : "Actionizing Thinkiness http:\/\/t.co\/0q2ijZKWiS via @greg_ashman",
  "id" : 635796050326999041,
  "created_at" : "2015-08-24 12:49:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/uwNHsYjrkJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=C_Gz_iTuRMM&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=C_Gz_i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635598369029754880",
  "text" : "RT @courosa: The Karate Kid from the perspective that Daniel is in fact the REAL bully ... https:\/\/t.co\/uwNHsYjrkJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/uwNHsYjrkJ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=C_Gz_iTuRMM&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=C_Gz_i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635553794646892544",
    "text" : "The Karate Kid from the perspective that Daniel is in fact the REAL bully ... https:\/\/t.co\/uwNHsYjrkJ",
    "id" : 635553794646892544,
    "created_at" : "2015-08-23 20:46:47 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 635598369029754880,
  "created_at" : "2015-08-23 23:43:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/TI9aRrRWRZ",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/inappropriately-interventionised.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/inappr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635580065133252608",
  "text" : "RT @pchallinor: New mudgeonry: Inappropriately interventionised http:\/\/t.co\/TI9aRrRWRZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/TI9aRrRWRZ",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/inappropriately-interventionised.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/inappr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633337397527359488",
    "text" : "New mudgeonry: Inappropriately interventionised http:\/\/t.co\/TI9aRrRWRZ",
    "id" : 633337397527359488,
    "created_at" : "2015-08-17 17:59:37 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 635580065133252608,
  "created_at" : "2015-08-23 22:31:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "indices" : [ 3, 19 ],
      "id_str" : "303429700",
      "id" : 303429700
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/welshnotbritish\/status\/635515344682098689\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/m75OjxcGCd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNHN1obWsAAOjtx.png",
      "id_str" : "635515343704862720",
      "id" : 635515343704862720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNHN1obWsAAOjtx.png",
      "sizes" : [ {
        "h" : 302,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/m75OjxcGCd"
    } ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "RedTories",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635577104432766976",
  "text" : "RT @welshnotbritish: It's interesting that not one Labour MP in Wales has publicly backed #Corbyn. #RedTories http:\/\/t.co\/m75OjxcGCd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/welshnotbritish\/status\/635515344682098689\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/m75OjxcGCd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNHN1obWsAAOjtx.png",
        "id_str" : "635515343704862720",
        "id" : 635515343704862720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNHN1obWsAAOjtx.png",
        "sizes" : [ {
          "h" : 302,
          "resize" : "fit",
          "w" : 666
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 666
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/m75OjxcGCd"
      } ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "RedTories",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635515344682098689",
    "text" : "It's interesting that not one Labour MP in Wales has publicly backed #Corbyn. #RedTories http:\/\/t.co\/m75OjxcGCd",
    "id" : 635515344682098689,
    "created_at" : "2015-08-23 18:14:00 +0000",
    "user" : {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "protected" : false,
      "id_str" : "303429700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639477893924564992\/MZGR5nLW_normal.png",
      "id" : 303429700,
      "verified" : false
    }
  },
  "id" : 635577104432766976,
  "created_at" : "2015-08-23 22:19:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/uh1HP9UhIS",
      "expanded_url" : "https:\/\/zcomm.org\/zblogs\/amnesty-still-asks-us-and-saudi-governments-to-ensure-only-the-good-syrian-rebels-are-armed\/",
      "display_url" : "zcomm.org\/zblogs\/amnesty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635575601294786561",
  "text" : "RT @rosendo_joe: Amnesty Still Asks US and Saudi Governments to ensure only the good Syrian Rebels are armed\nhttps:\/\/t.co\/uh1HP9UhIS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/uh1HP9UhIS",
        "expanded_url" : "https:\/\/zcomm.org\/zblogs\/amnesty-still-asks-us-and-saudi-governments-to-ensure-only-the-good-syrian-rebels-are-armed\/",
        "display_url" : "zcomm.org\/zblogs\/amnesty\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635516830518517760",
    "text" : "Amnesty Still Asks US and Saudi Governments to ensure only the good Syrian Rebels are armed\nhttps:\/\/t.co\/uh1HP9UhIS",
    "id" : 635516830518517760,
    "created_at" : "2015-08-23 18:19:54 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 635575601294786561,
  "created_at" : "2015-08-23 22:13:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635572144974512129",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran thx for share!",
  "id" : 635572144974512129,
  "created_at" : "2015-08-23 21:59:42 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635568769566384129",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach cheers for RT Claire :)",
  "id" : 635568769566384129,
  "created_at" : "2015-08-23 21:46:17 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/mVr6Bv2ELF",
      "expanded_url" : "http:\/\/wpo.st\/8uaW0",
      "display_url" : "wpo.st\/8uaW0"
    } ]
  },
  "geo" : { },
  "id_str" : "635568597033746432",
  "text" : "Renowned researcher: 'Why I am no longer comfortable' in the field of educational measurement http:\/\/t.co\/mVr6Bv2ELF",
  "id" : 635568597033746432,
  "created_at" : "2015-08-23 21:45:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 12, 24 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635494343877468160",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @paul_sensei many thx for RT",
  "id" : 635494343877468160,
  "created_at" : "2015-08-23 16:50:33 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635419789251362817",
  "geo" : { },
  "id_str" : "635494105771065344",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ha thanks Marc :)",
  "id" : 635494105771065344,
  "in_reply_to_status_id" : 635419789251362817,
  "created_at" : "2015-08-23 16:49:36 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Cowley",
      "screen_name" : "Sue_Cowley",
      "indices" : [ 3, 14 ],
      "id_str" : "1094790043",
      "id" : 1094790043
    }, {
      "name" : "Unseen Flirtations",
      "screen_name" : "unseenflirt",
      "indices" : [ 103, 115 ],
      "id_str" : "230701906",
      "id" : 230701906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/6bKzxC2Gnz",
      "expanded_url" : "https:\/\/unseenflirtspoetry.wordpress.com\/2015\/08\/22\/becoming-yourself-a-teachers-journey-to-authenticity\/",
      "display_url" : "unseenflirtspoetry.wordpress.com\/2015\/08\/22\/bec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635383374748753921",
  "text" : "RT @Sue_Cowley: \"my lessons have been tea-stained by events of my life\"\nA journey to authenticity with @unseenflirt aka Mr Boakye\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unseen Flirtations",
        "screen_name" : "unseenflirt",
        "indices" : [ 87, 99 ],
        "id_str" : "230701906",
        "id" : 230701906
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/6bKzxC2Gnz",
        "expanded_url" : "https:\/\/unseenflirtspoetry.wordpress.com\/2015\/08\/22\/becoming-yourself-a-teachers-journey-to-authenticity\/",
        "display_url" : "unseenflirtspoetry.wordpress.com\/2015\/08\/22\/bec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635379663351775232",
    "text" : "\"my lessons have been tea-stained by events of my life\"\nA journey to authenticity with @unseenflirt aka Mr Boakye\nhttps:\/\/t.co\/6bKzxC2Gnz",
    "id" : 635379663351775232,
    "created_at" : "2015-08-23 09:14:51 +0000",
    "user" : {
      "name" : "Sue Cowley",
      "screen_name" : "Sue_Cowley",
      "protected" : false,
      "id_str" : "1094790043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746500334974025728\/eilV4r4a_normal.jpg",
      "id" : 1094790043,
      "verified" : false
    }
  },
  "id" : 635383374748753921,
  "created_at" : "2015-08-23 09:29:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "efl",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/WeMseShdG8",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/08\/23\/quick-cup-of-coca-compare",
      "display_url" : "eflnotes.wordpress.com\/2015\/08\/23\/qui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635376117528965120",
  "text" : "Quick cup of COCA - compare #elt #efl #corpusmooc https:\/\/t.co\/WeMseShdG8",
  "id" : 635376117528965120,
  "created_at" : "2015-08-23 09:00:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 41, 56 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/aueOatW89q",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1lO",
      "display_url" : "wp.me\/p3qkCB-1lO"
    } ]
  },
  "geo" : { },
  "id_str" : "635374764123623424",
  "text" : "Test Validity http:\/\/t.co\/aueOatW89q via @GeoffreyJordan",
  "id" : 635374764123623424,
  "created_at" : "2015-08-23 08:55:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Cowley",
      "screen_name" : "Sue_Cowley",
      "indices" : [ 3, 14 ],
      "id_str" : "1094790043",
      "id" : 1094790043
    }, {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 54, 64 ],
      "id_str" : "87903271",
      "id" : 87903271
    }, {
      "name" : "Labour Teachers",
      "screen_name" : "labourteachers",
      "indices" : [ 69, 84 ],
      "id_str" : "228023645",
      "id" : 228023645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/0S2uqO9EwH",
      "expanded_url" : "http:\/\/www.labourteachers.org.uk\/pessimistic-bees-jamestheo\/",
      "display_url" : "labourteachers.org.uk\/pessimistic-be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635211076028760064",
  "text" : "RT @Sue_Cowley: This is a great piece of writing from @JamesTheo via @labourteachers\n\"Pessimistic Bees\"\nhttp:\/\/t.co\/0S2uqO9EwH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Theobald",
        "screen_name" : "JamesTheo",
        "indices" : [ 38, 48 ],
        "id_str" : "87903271",
        "id" : 87903271
      }, {
        "name" : "Labour Teachers",
        "screen_name" : "labourteachers",
        "indices" : [ 53, 68 ],
        "id_str" : "228023645",
        "id" : 228023645
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/0S2uqO9EwH",
        "expanded_url" : "http:\/\/www.labourteachers.org.uk\/pessimistic-bees-jamestheo\/",
        "display_url" : "labourteachers.org.uk\/pessimistic-be\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635188694299881472",
    "text" : "This is a great piece of writing from @JamesTheo via @labourteachers\n\"Pessimistic Bees\"\nhttp:\/\/t.co\/0S2uqO9EwH",
    "id" : 635188694299881472,
    "created_at" : "2015-08-22 20:36:00 +0000",
    "user" : {
      "name" : "Sue Cowley",
      "screen_name" : "Sue_Cowley",
      "protected" : false,
      "id_str" : "1094790043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746500334974025728\/eilV4r4a_normal.jpg",
      "id" : 1094790043,
      "verified" : false
    }
  },
  "id" : 635211076028760064,
  "created_at" : "2015-08-22 22:04:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 0, 8 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632048516567826432",
  "geo" : { },
  "id_str" : "634860315260387328",
  "in_reply_to_user_id" : 9242922,
  "text" : "@Sugatam can you point where it mentions internet based in draft? thx",
  "id" : 634860315260387328,
  "in_reply_to_status_id" : 632048516567826432,
  "created_at" : "2015-08-21 22:51:08 +0000",
  "in_reply_to_screen_name" : "Sugatam",
  "in_reply_to_user_id_str" : "9242922",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandra Guzm\u00E1n",
      "screen_name" : "lalepandra",
      "indices" : [ 0, 11 ],
      "id_str" : "1465816465",
      "id" : 1465816465
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 12, 19 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634379560570585088",
  "geo" : { },
  "id_str" : "634486559899844608",
  "in_reply_to_user_id" : 1465816465,
  "text" : "@lalepandra @EdLaur a puzzle why publishers still churn out the plastic?",
  "id" : 634486559899844608,
  "in_reply_to_status_id" : 634379560570585088,
  "created_at" : "2015-08-20 22:05:58 +0000",
  "in_reply_to_screen_name" : "lalepandra",
  "in_reply_to_user_id_str" : "1465816465",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/eWBpjqNVp1",
      "expanded_url" : "http:\/\/fusion.net\/story\/184066\/what-presidential-candidates-are-selling\/",
      "display_url" : "fusion.net\/story\/184066\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634485728169361409",
  "text" : "RT @sam_lavigne: all the crap presidential candidates sell on their web stores:\nhttp:\/\/t.co\/eWBpjqNVp1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/eWBpjqNVp1",
        "expanded_url" : "http:\/\/fusion.net\/story\/184066\/what-presidential-candidates-are-selling\/",
        "display_url" : "fusion.net\/story\/184066\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634481138887733248",
    "text" : "all the crap presidential candidates sell on their web stores:\nhttp:\/\/t.co\/eWBpjqNVp1",
    "id" : 634481138887733248,
    "created_at" : "2015-08-20 21:44:26 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 634485728169361409,
  "created_at" : "2015-08-20 22:02:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 90, 106 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/y06ly8jbnh",
      "expanded_url" : "http:\/\/wp.me\/p4Z8Gv-4Z",
      "display_url" : "wp.me\/p4Z8Gv-4Z"
    } ]
  },
  "geo" : { },
  "id_str" : "634406938651004933",
  "text" : "What Jeremy Corbyn supporters can learn from Margaret Thatcher http:\/\/t.co\/y06ly8jbnh via @wordpressdotcom",
  "id" : 634406938651004933,
  "created_at" : "2015-08-20 16:49:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Va2E5UAbTd",
      "expanded_url" : "http:\/\/goo.gl\/5oPvmJ",
      "display_url" : "goo.gl\/5oPvmJ"
    }, {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/OPJzPeSom0",
      "expanded_url" : "https:\/\/goo.gl\/Ukniy2",
      "display_url" : "goo.gl\/Ukniy2"
    } ]
  },
  "geo" : { },
  "id_str" : "634344070756868096",
  "text" : "RT @josipa74: Free #ELT activity - Bad Subtitles 2! http:\/\/t.co\/Va2E5UAbTd https:\/\/t.co\/OPJzPeSom0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 5, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/Va2E5UAbTd",
        "expanded_url" : "http:\/\/goo.gl\/5oPvmJ",
        "display_url" : "goo.gl\/5oPvmJ"
      }, {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/OPJzPeSom0",
        "expanded_url" : "https:\/\/goo.gl\/Ukniy2",
        "display_url" : "goo.gl\/Ukniy2"
      } ]
    },
    "geo" : { },
    "id_str" : "634301245717614592",
    "text" : "Free #ELT activity - Bad Subtitles 2! http:\/\/t.co\/Va2E5UAbTd https:\/\/t.co\/OPJzPeSom0",
    "id" : 634301245717614592,
    "created_at" : "2015-08-20 09:49:36 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 634344070756868096,
  "created_at" : "2015-08-20 12:39:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634321186307092481",
  "geo" : { },
  "id_str" : "634342065984421888",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur who has cd rom players these days? :\/",
  "id" : 634342065984421888,
  "in_reply_to_status_id" : 634321186307092481,
  "created_at" : "2015-08-20 12:31:48 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634285732589277184",
  "geo" : { },
  "id_str" : "634285989993816065",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith i am waiting for the locusts myself :\/",
  "id" : 634285989993816065,
  "in_reply_to_status_id" : 634285732589277184,
  "created_at" : "2015-08-20 08:48:59 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634282474319704064",
  "geo" : { },
  "id_str" : "634283966464434178",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith wonder what next natural event Pearson will use as ad copy avalanche-&gt;tidal wave-&gt;?",
  "id" : 634283966464434178,
  "in_reply_to_status_id" : 634282474319704064,
  "created_at" : "2015-08-20 08:40:56 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634278325398073348",
  "geo" : { },
  "id_str" : "634282627239944192",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith illthought out metaphor - desert &amp; ocean unique ecosystems adapted to its context, Pearson wants to terraform education?",
  "id" : 634282627239944192,
  "in_reply_to_status_id" : 634278325398073348,
  "created_at" : "2015-08-20 08:35:37 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/pCNTBvqCP4",
      "expanded_url" : "http:\/\/eveningharold.com\/2015\/08\/18\/jeremy-corbyn-launches-scathing-attack-on-jeremy-corbyn\/",
      "display_url" : "eveningharold.com\/2015\/08\/18\/jer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634068117652639744",
  "text" : "Jeremy Corbyn launches scathing attack on Jeremy Corbyn http:\/\/t.co\/pCNTBvqCP4",
  "id" : 634068117652639744,
  "created_at" : "2015-08-19 18:23:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633968331108806656",
  "geo" : { },
  "id_str" : "634013493637857280",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites yr welcome, have u come across any other speech corpora yet?",
  "id" : 634013493637857280,
  "in_reply_to_status_id" : 633968331108806656,
  "created_at" : "2015-08-19 14:46:10 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 17, 27 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    }, {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 28, 43 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633949966847733761",
  "geo" : { },
  "id_str" : "634013271255875584",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @pronbites @myles_klynhout i think books which have looked at this are best bet at the moment due to scarcity of raw data",
  "id" : 634013271255875584,
  "in_reply_to_status_id" : 633949966847733761,
  "created_at" : "2015-08-19 14:45:17 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 3, 16 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/VU7Jr6PVpv",
      "expanded_url" : "http:\/\/bit.ly\/versatile_deske",
      "display_url" : "bit.ly\/versatile_deske"
    } ]
  },
  "geo" : { },
  "id_str" : "634008049829715968",
  "text" : "RT @versatilepub: Discovering English http:\/\/t.co\/VU7Jr6PVpv. Use code FGA815 at checkout for free mail shipping or 50% off ground shipping\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/VU7Jr6PVpv",
        "expanded_url" : "http:\/\/bit.ly\/versatile_deske",
        "display_url" : "bit.ly\/versatile_deske"
      } ]
    },
    "geo" : { },
    "id_str" : "633999017559621632",
    "text" : "Discovering English http:\/\/t.co\/VU7Jr6PVpv. Use code FGA815 at checkout for free mail shipping or 50% off ground shipping till Aug 24.",
    "id" : 633999017559621632,
    "created_at" : "2015-08-19 13:48:39 +0000",
    "user" : {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "protected" : false,
      "id_str" : "3243120760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596936187534704640\/HR5PkkoP_normal.jpg",
      "id" : 3243120760,
      "verified" : false
    }
  },
  "id" : 634008049829715968,
  "created_at" : "2015-08-19 14:24:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 113, 123 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    }, {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 124, 139 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/A1KZbJAGw5",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/LFKHrz4tXSu",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633948921971240960",
  "text" : "think of a rare thing then think publically avail spoken corpora i bet it is rarer :) https:\/\/t.co\/A1KZbJAGw5 cc @pronbites @myles_klynhout",
  "id" : 633948921971240960,
  "created_at" : "2015-08-19 10:29:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/290FLxpwcD",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/08\/trashing-corbyn-promoting-brown.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/08\/trashi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633929105369624576",
  "text" : "RT @johnwhilley: Trashing Corbyn, promoting Brown - Guardian's version of morality politics http:\/\/t.co\/290FLxpwcD #Corbyn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/290FLxpwcD",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/08\/trashing-corbyn-promoting-brown.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/08\/trashi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633924725937426432",
    "text" : "Trashing Corbyn, promoting Brown - Guardian's version of morality politics http:\/\/t.co\/290FLxpwcD #Corbyn",
    "id" : 633924725937426432,
    "created_at" : "2015-08-19 08:53:27 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 633929105369624576,
  "created_at" : "2015-08-19 09:10:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633660596341239808",
  "geo" : { },
  "id_str" : "633815522497429505",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler is there a sense that in th = having workbook mentally very close &amp; of the = having workbook in mind a bit further away?",
  "id" : 633815522497429505,
  "in_reply_to_status_id" : 633660596341239808,
  "created_at" : "2015-08-19 01:39:30 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "indices" : [ 0, 11 ],
      "id_str" : "1559079607",
      "id" : 1559079607
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 12, 28 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 29, 41 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 42, 57 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 58, 70 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 71, 79 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/dur3pCyIwZ",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=40987215",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "633809784974770177",
  "geo" : { },
  "id_str" : "633814980303941632",
  "in_reply_to_user_id" : 1559079607,
  "text" : "@TesalKoksi @getgreatenglish @AnneHendler @DavidHarbinson @nathanghall @seburnt cld explore a bit reg diffs here http:\/\/t.co\/dur3pCyIwZ",
  "id" : 633814980303941632,
  "in_reply_to_status_id" : 633809784974770177,
  "created_at" : "2015-08-19 01:37:21 +0000",
  "in_reply_to_screen_name" : "TesalKoksi",
  "in_reply_to_user_id_str" : "1559079607",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 22, 38 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Huffington Post UK",
      "screen_name" : "HuffPostUK",
      "indices" : [ 47, 58 ],
      "id_str" : "271413771",
      "id" : 271413771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633795156588695552",
  "geo" : { },
  "id_str" : "633809566422171649",
  "in_reply_to_user_id" : 820940430,
  "text" : "@thisbyanychance tell @MichaelChesnut2 to tell @HuffPostUK about accents",
  "id" : 633809566422171649,
  "in_reply_to_status_id" : 633795156588695552,
  "created_at" : "2015-08-19 01:15:50 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 40, 49 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633808951944081408",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava to tell @muranava about accents",
  "id" : 633808951944081408,
  "created_at" : "2015-08-19 01:13:24 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633807913862230016",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about brain gym",
  "id" : 633807913862230016,
  "created_at" : "2015-08-19 01:09:16 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633802602828931072",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about learning styles",
  "id" : 633802602828931072,
  "created_at" : "2015-08-19 00:48:10 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633799847112507392",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about prediction",
  "id" : 633799847112507392,
  "created_at" : "2015-08-19 00:37:13 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633798616403021824",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about algorithm",
  "id" : 633798616403021824,
  "created_at" : "2015-08-19 00:32:20 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633783602107449344",
  "geo" : { },
  "id_str" : "633791914882543617",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 since when is 2014 new research in a 2015 story? how about a poll of most &amp; least recycled bigoted stories? :\/",
  "id" : 633791914882543617,
  "in_reply_to_status_id" : 633783602107449344,
  "created_at" : "2015-08-19 00:05:42 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 80, 95 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/RYmnyIcvNA",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1lr",
      "display_url" : "wp.me\/p3qkCB-1lr"
    } ]
  },
  "geo" : { },
  "id_str" : "633775497802067968",
  "text" : "Harmer on Testing (A PC Version of 2 Previous Posts) http:\/\/t.co\/RYmnyIcvNA via @GeoffreyJordan",
  "id" : 633775497802067968,
  "created_at" : "2015-08-18 23:00:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Espinoza Cotta",
      "screen_name" : "edtech2innovate",
      "indices" : [ 7, 23 ],
      "id_str" : "33694548",
      "id" : 33694548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/DIYcKY8uIs",
      "expanded_url" : "http:\/\/azargrammar.com\/teacherTalk\/blog\/2015\/08\/listening-from-the-bottom-up\/",
      "display_url" : "azargrammar.com\/teacherTalk\/bl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "633766522473873408",
  "geo" : { },
  "id_str" : "633775004207972352",
  "in_reply_to_user_id" : 33694548,
  "text" : "indeed @edtech2innovate some similar activities listed here with refs http:\/\/t.co\/DIYcKY8uIs",
  "id" : 633775004207972352,
  "in_reply_to_status_id" : 633766522473873408,
  "created_at" : "2015-08-18 22:58:30 +0000",
  "in_reply_to_screen_name" : "edtech2innovate",
  "in_reply_to_user_id_str" : "33694548",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 123, 139 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/YNVDEFEwFQ",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-Mg",
      "display_url" : "wp.me\/p4E5tZ-Mg"
    } ]
  },
  "geo" : { },
  "id_str" : "633760494306902016",
  "text" : "Micro-listening skills (Part 2) - More micro-listening tasks for the foreign language classroom http:\/\/t.co\/YNVDEFEwFQ via @gianfrancocont9",
  "id" : 633760494306902016,
  "created_at" : "2015-08-18 22:00:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FIPLV",
      "screen_name" : "FIPLV",
      "indices" : [ 3, 9 ],
      "id_str" : "552622475",
      "id" : 552622475
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 134, 140 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/h26udJFzPh",
      "expanded_url" : "http:\/\/wp.me\/p21myX-oD",
      "display_url" : "wp.me\/p21myX-oD"
    } ]
  },
  "geo" : { },
  "id_str" : "633760186352713728",
  "text" : "RT @FIPLV: Analyse des besoins des employeurs fran\u00E7ais au regard des comp\u00E9tences en langues vivantes \u00E9tra\u2026 http:\/\/t.co\/h26udJFzPh via @word\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 123, 139 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/h26udJFzPh",
        "expanded_url" : "http:\/\/wp.me\/p21myX-oD",
        "display_url" : "wp.me\/p21myX-oD"
      } ]
    },
    "geo" : { },
    "id_str" : "633608082791223296",
    "text" : "Analyse des besoins des employeurs fran\u00E7ais au regard des comp\u00E9tences en langues vivantes \u00E9tra\u2026 http:\/\/t.co\/h26udJFzPh via @wordpressdotcom",
    "id" : 633608082791223296,
    "created_at" : "2015-08-18 11:55:13 +0000",
    "user" : {
      "name" : "FIPLV",
      "screen_name" : "FIPLV",
      "protected" : false,
      "id_str" : "552622475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2109401859\/logo_normal.jpg",
      "id" : 552622475,
      "verified" : false
    }
  },
  "id" : 633760186352713728,
  "created_at" : "2015-08-18 21:59:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrien Barbaresi",
      "screen_name" : "adbarbaresi",
      "indices" : [ 3, 15 ],
      "id_str" : "222584301",
      "id" : 222584301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/c5n2Jwo2Rh",
      "expanded_url" : "https:\/\/twitter.com\/najdae\/status\/632471014253928448",
      "display_url" : "twitter.com\/najdae\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633578137092276224",
  "text" : "RT @adbarbaresi: Interesting analysis of the difference between original and tech industry definitions of hacking https:\/\/t.co\/c5n2Jwo2Rh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/c5n2Jwo2Rh",
        "expanded_url" : "https:\/\/twitter.com\/najdae\/status\/632471014253928448",
        "display_url" : "twitter.com\/najdae\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633574371450339328",
    "text" : "Interesting analysis of the difference between original and tech industry definitions of hacking https:\/\/t.co\/c5n2Jwo2Rh",
    "id" : 633574371450339328,
    "created_at" : "2015-08-18 09:41:16 +0000",
    "user" : {
      "name" : "Adrien Barbaresi",
      "screen_name" : "adbarbaresi",
      "protected" : false,
      "id_str" : "222584301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731494811858014208\/NmvcMdyD_normal.jpg",
      "id" : 222584301,
      "verified" : false
    }
  },
  "id" : 633578137092276224,
  "created_at" : "2015-08-18 09:56:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "187481025",
      "id" : 187481025
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eslwriter\/status\/633572461557092354\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tfdz019Fs9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMrmy5-UwAY6fOG.jpg",
      "id_str" : "633572459829051398",
      "id" : 633572459829051398,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMrmy5-UwAY6fOG.jpg",
      "sizes" : [ {
        "h" : 2000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tfdz019Fs9"
    } ],
    "hashtags" : [ {
      "text" : "Teach",
      "indices" : [ 15, 21 ]
    }, {
      "text" : "ESL",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/QvoEh5U0pt",
      "expanded_url" : "http:\/\/www.eslwriting.org\/14128\/teaching-english-writing-paraphrasing-synonyms\/",
      "display_url" : "eslwriting.org\/14128\/teaching\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633574587259846657",
  "text" : "RT @eslwriter: #Teach #ESL writing and looking for skills-based activities? Try paraphrasing with synonyms. http:\/\/t.co\/QvoEh5U0pt http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eslwriter\/status\/633572461557092354\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/tfdz019Fs9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMrmy5-UwAY6fOG.jpg",
        "id_str" : "633572459829051398",
        "id" : 633572459829051398,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMrmy5-UwAY6fOG.jpg",
        "sizes" : [ {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tfdz019Fs9"
      } ],
      "hashtags" : [ {
        "text" : "Teach",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/QvoEh5U0pt",
        "expanded_url" : "http:\/\/www.eslwriting.org\/14128\/teaching-english-writing-paraphrasing-synonyms\/",
        "display_url" : "eslwriting.org\/14128\/teaching\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633572461557092354",
    "text" : "#Teach #ESL writing and looking for skills-based activities? Try paraphrasing with synonyms. http:\/\/t.co\/QvoEh5U0pt http:\/\/t.co\/tfdz019Fs9",
    "id" : 633572461557092354,
    "created_at" : "2015-08-18 09:33:40 +0000",
    "user" : {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "protected" : false,
      "id_str" : "187481025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682332531\/cd44653e5843c08c6938f41dc15668bc_normal.png",
      "id" : 187481025,
      "verified" : false
    }
  },
  "id" : 633574587259846657,
  "created_at" : "2015-08-18 09:42:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "indices" : [ 0, 11 ],
      "id_str" : "1559079607",
      "id" : 1559079607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633449372093673472",
  "geo" : { },
  "id_str" : "633572662191751168",
  "in_reply_to_user_id" : 1559079607,
  "text" : "@TesalKoksi thanks :)",
  "id" : 633572662191751168,
  "in_reply_to_status_id" : 633449372093673472,
  "created_at" : "2015-08-18 09:34:28 +0000",
  "in_reply_to_screen_name" : "TesalKoksi",
  "in_reply_to_user_id_str" : "1559079607",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 13, 29 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633439947496644608",
  "geo" : { },
  "id_str" : "633572623998394368",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @getgreatenglish cheers :)",
  "id" : 633572623998394368,
  "in_reply_to_status_id" : 633439947496644608,
  "created_at" : "2015-08-18 09:34:19 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633430764844109824",
  "geo" : { },
  "id_str" : "633572491189977089",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard heywha? noway! ;)",
  "id" : 633572491189977089,
  "in_reply_to_status_id" : 633430764844109824,
  "created_at" : "2015-08-18 09:33:47 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633349859425284096",
  "geo" : { },
  "id_str" : "633387138931912704",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx Rose,  i found one of the repos longer exists, updated! do u know any good ones?",
  "id" : 633387138931912704,
  "in_reply_to_status_id" : 633349859425284096,
  "created_at" : "2015-08-17 21:17:16 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 123, 139 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ii2ak5jSkl",
      "expanded_url" : "http:\/\/wp.me\/p5wDY2-7s",
      "display_url" : "wp.me\/p5wDY2-7s"
    } ]
  },
  "geo" : { },
  "id_str" : "633386031010717696",
  "text" : "Diary of a Newbie Teacher Part Three: The dark(er) side of being a freelance English teacher i\u2026 http:\/\/t.co\/ii2ak5jSkl via @wordpressdotcom",
  "id" : 633386031010717696,
  "created_at" : "2015-08-17 21:12:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/PiP5RrM4Zj",
      "expanded_url" : "http:\/\/www.sodiumhaze.org\/2015\/08\/17\/the-golden-corby-awards-for-hilariously-useless-anti-corbyn-smears\/",
      "display_url" : "sodiumhaze.org\/2015\/08\/17\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633338390214234112",
  "text" : "\u2018The Golden Corby\u2019 awards for hilariously useless anti-Corbyn smears http:\/\/t.co\/PiP5RrM4Zj",
  "id" : 633338390214234112,
  "created_at" : "2015-08-17 18:03:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 0, 10 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633307432022855681",
  "geo" : { },
  "id_str" : "633307947284738048",
  "in_reply_to_user_id" : 444977554,
  "text" : "@joannacre sure very nice idea thanks",
  "id" : 633307947284738048,
  "in_reply_to_status_id" : 633307432022855681,
  "created_at" : "2015-08-17 16:02:35 +0000",
  "in_reply_to_screen_name" : "joannacre",
  "in_reply_to_user_id_str" : "444977554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 3, 13 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/joannacre\/status\/633302714567389184\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/2uFZf8l9Zn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMnxdmXUsAEsR4f.jpg",
      "id_str" : "633302713439137793",
      "id" : 633302713439137793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMnxdmXUsAEsR4f.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/2uFZf8l9Zn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/TtAiuB84UY",
      "expanded_url" : "https:\/\/myeltrambles.wordpress.com\/2015\/08\/17\/a-fish-a-thesis-and-ibid-teaching-academic-writing-through-drawings",
      "display_url" : "myeltrambles.wordpress.com\/2015\/08\/17\/a-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633305959788642304",
  "text" : "RT @joannacre: A fish, a thesis and ibid: Teaching (academic) writing through\u00A0drawings https:\/\/t.co\/TtAiuB84UY http:\/\/t.co\/2uFZf8l9Zn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/joannacre\/status\/633302714567389184\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/2uFZf8l9Zn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMnxdmXUsAEsR4f.jpg",
        "id_str" : "633302713439137793",
        "id" : 633302713439137793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMnxdmXUsAEsR4f.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/2uFZf8l9Zn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/TtAiuB84UY",
        "expanded_url" : "https:\/\/myeltrambles.wordpress.com\/2015\/08\/17\/a-fish-a-thesis-and-ibid-teaching-academic-writing-through-drawings",
        "display_url" : "myeltrambles.wordpress.com\/2015\/08\/17\/a-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633302714567389184",
    "text" : "A fish, a thesis and ibid: Teaching (academic) writing through\u00A0drawings https:\/\/t.co\/TtAiuB84UY http:\/\/t.co\/2uFZf8l9Zn",
    "id" : 633302714567389184,
    "created_at" : "2015-08-17 15:41:48 +0000",
    "user" : {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "protected" : false,
      "id_str" : "444977554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3251727601\/179472a3feae34c6561a1dd313c450b9_normal.jpeg",
      "id" : 444977554,
      "verified" : false
    }
  },
  "id" : 633305959788642304,
  "created_at" : "2015-08-17 15:54:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633263702611853312",
  "geo" : { },
  "id_str" : "633272418308636672",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish good idea to use more interesting motivational theories :)",
  "id" : 633272418308636672,
  "in_reply_to_status_id" : 633263702611853312,
  "created_at" : "2015-08-17 13:41:24 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 22, 38 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633259366800470016",
  "geo" : { },
  "id_str" : "633260190754828289",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@thisbyanychance tell @getgreatenglish to tell DipTESOL about learning styles",
  "id" : 633260190754828289,
  "in_reply_to_status_id" : 633259366800470016,
  "created_at" : "2015-08-17 12:52:49 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 22, 32 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632953421088333824",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @adi_rajan to tell IATEFL YLT webinar about brain gym",
  "id" : 632953421088333824,
  "created_at" : "2015-08-16 16:33:49 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madeuphashtag",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632952795851804672",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava to tell #madeuphashtag about brain gym",
  "id" : 632952795851804672,
  "created_at" : "2015-08-16 16:31:20 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632872086327939073",
  "geo" : { },
  "id_str" : "632928539877244928",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig yr welcome, hope it went well",
  "id" : 632928539877244928,
  "in_reply_to_status_id" : 632872086327939073,
  "created_at" : "2015-08-16 14:54:57 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 38, 54 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Bzz4ODMxhB",
      "expanded_url" : "http:\/\/wp.me\/p577Go-mx",
      "display_url" : "wp.me\/p577Go-mx"
    } ]
  },
  "geo" : { },
  "id_str" : "632871328270434304",
  "text" : "Word Snap! http:\/\/t.co\/Bzz4ODMxhB via @tekhnologicblog",
  "id" : 632871328270434304,
  "created_at" : "2015-08-16 11:07:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "esl",
      "indices" : [ 135, 139 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/YfNcH013vh",
      "expanded_url" : "https:\/\/goo.gl\/NgaTFQ",
      "display_url" : "goo.gl\/NgaTFQ"
    } ]
  },
  "geo" : { },
  "id_str" : "632870627683233793",
  "text" : "RT @taw_sig: Conversation on Freire is today! 1.30 GMT - Ch. 2 of Edu. for Critical Consciousness. Info: https:\/\/t.co\/YfNcH013vh  #elt #esl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "esl",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "tefl",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/YfNcH013vh",
        "expanded_url" : "https:\/\/goo.gl\/NgaTFQ",
        "display_url" : "goo.gl\/NgaTFQ"
      } ]
    },
    "geo" : { },
    "id_str" : "632868899852283904",
    "text" : "Conversation on Freire is today! 1.30 GMT - Ch. 2 of Edu. for Critical Consciousness. Info: https:\/\/t.co\/YfNcH013vh  #elt #esl #tefl",
    "id" : 632868899852283904,
    "created_at" : "2015-08-16 10:57:58 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 632870627683233793,
  "created_at" : "2015-08-16 11:04:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Polly Toynbee",
      "screen_name" : "pollytoynbee",
      "indices" : [ 6, 19 ],
      "id_str" : "226195230",
      "id" : 226195230
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/632864928391688192\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/5P4Bwo5BY1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMhjTHKWwAA2335.png",
      "id_str" : "632864927636701184",
      "id" : 632864927636701184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMhjTHKWwAA2335.png",
      "sizes" : [ {
        "h" : 615,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5P4Bwo5BY1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632864928391688192",
  "text" : "would @pollytoynbee pass an IELTS from these comments to polling table data? http:\/\/t.co\/5P4Bwo5BY1",
  "id" : 632864928391688192,
  "created_at" : "2015-08-16 10:42:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VJDay",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/OPuPmD0v2h",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/a-solemn-day-rah-rah-hooray.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/a-sole\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632635864909283328",
  "text" : "RT @pchallinor: New mudgeonry: A solemn day http:\/\/t.co\/OPuPmD0v2h #VJDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VJDay",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/OPuPmD0v2h",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/a-solemn-day-rah-rah-hooray.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/a-sole\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632518196420083712",
    "text" : "New mudgeonry: A solemn day http:\/\/t.co\/OPuPmD0v2h #VJDay",
    "id" : 632518196420083712,
    "created_at" : "2015-08-15 11:44:24 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 632635864909283328,
  "created_at" : "2015-08-15 19:31:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/rwX8scZ3tU",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/08\/10\/digpedlab\/",
      "display_url" : "hackeducation.com\/2015\/08\/10\/dig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632624577693253632",
  "text" : "Teaching Machines and Turing Machines: The History of the Future of Labor and Learning http:\/\/t.co\/rwX8scZ3tU",
  "id" : 632624577693253632,
  "created_at" : "2015-08-15 18:47:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ehpnt8qac2",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/08\/15\/criticism\/",
      "display_url" : "hackeducation.com\/2015\/08\/15\/cri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632603304242118656",
  "text" : "And So, Without Ed-Tech Criticism... http:\/\/t.co\/ehpnt8qac2",
  "id" : 632603304242118656,
  "created_at" : "2015-08-15 17:22:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/bs52991qLF",
      "expanded_url" : "http:\/\/www.tesol-france.org\/uploaded_files\/files\/TESOL%20France%20Colloquium%202015%20Preliminary%20Schedule.pdf",
      "display_url" : "tesol-france.org\/uploaded_files\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632582945291829248",
  "text" : "Prelim @tesolfr 2015 conf prog available http:\/\/t.co\/bs52991qLF",
  "id" : 632582945291829248,
  "created_at" : "2015-08-15 16:01:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 78, 90 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/dfGupA9oD3",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics\/2\/steps\/45555?utm_campaign=Share+Links&utm_medium=futurelearn-open_step&utm_source=twitter",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632563782619918336",
  "text" : "How to: Use the GraphColl tool - Corpus Linguistics: Method, Analysis,... via @FutureLearn https:\/\/t.co\/dfGupA9oD3 #corpusmooc",
  "id" : 632563782619918336,
  "created_at" : "2015-08-15 14:45:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 88, 104 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/2CRkVZwWEo",
      "expanded_url" : "http:\/\/wp.me\/p4V5DN-4x",
      "display_url" : "wp.me\/p4V5DN-4x"
    } ]
  },
  "geo" : { },
  "id_str" : "632552540253634560",
  "text" : "Revealed! How Jeremy Corbyn is wiping out humanity! An essay http:\/\/t.co\/2CRkVZwWEo via @wordpressdotcom",
  "id" : 632552540253634560,
  "created_at" : "2015-08-15 14:00:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/adi_rajan\/status\/632443814074937348\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/j9twGmFTSp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMbkTA0UEAAyxGb.png",
      "id_str" : "632443812980199424",
      "id" : 632443812980199424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMbkTA0UEAAyxGb.png",
      "sizes" : [ {
        "h" : 708,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 885,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 885,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/j9twGmFTSp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/sLBE8AEOPK",
      "expanded_url" : "https:\/\/adirajan.wordpress.com\/2015\/08\/15\/e-moderating-reflections-week-5-the-vakman-cometh",
      "display_url" : "adirajan.wordpress.com\/2015\/08\/15\/e-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632538146471866368",
  "text" : "RT @adi_rajan: E-moderating Reflections Week 5 | The VAKman\u00A0cometh https:\/\/t.co\/sLBE8AEOPK http:\/\/t.co\/j9twGmFTSp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/adi_rajan\/status\/632443814074937348\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/j9twGmFTSp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMbkTA0UEAAyxGb.png",
        "id_str" : "632443812980199424",
        "id" : 632443812980199424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMbkTA0UEAAyxGb.png",
        "sizes" : [ {
          "h" : 708,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 885,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 885,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/j9twGmFTSp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/sLBE8AEOPK",
        "expanded_url" : "https:\/\/adirajan.wordpress.com\/2015\/08\/15\/e-moderating-reflections-week-5-the-vakman-cometh",
        "display_url" : "adirajan.wordpress.com\/2015\/08\/15\/e-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632443814074937348",
    "text" : "E-moderating Reflections Week 5 | The VAKman\u00A0cometh https:\/\/t.co\/sLBE8AEOPK http:\/\/t.co\/j9twGmFTSp",
    "id" : 632443814074937348,
    "created_at" : "2015-08-15 06:48:50 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 632538146471866368,
  "created_at" : "2015-08-15 13:03:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrien Barbaresi",
      "screen_name" : "adbarbaresi",
      "indices" : [ 3, 15 ],
      "id_str" : "222584301",
      "id" : 222584301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/W0lDvIv7JQ",
      "expanded_url" : "http:\/\/www.keybr.com\/",
      "display_url" : "keybr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "632242338484482048",
  "text" : "RT @adbarbaresi: The gamification of typing lessons http:\/\/t.co\/W0lDvIv7JQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/laterbro.com\" rel=\"nofollow\"\u003ELaterBro.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/W0lDvIv7JQ",
        "expanded_url" : "http:\/\/www.keybr.com\/",
        "display_url" : "keybr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "632190092740792320",
    "text" : "The gamification of typing lessons http:\/\/t.co\/W0lDvIv7JQ",
    "id" : 632190092740792320,
    "created_at" : "2015-08-14 14:00:38 +0000",
    "user" : {
      "name" : "Adrien Barbaresi",
      "screen_name" : "adbarbaresi",
      "protected" : false,
      "id_str" : "222584301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731494811858014208\/NmvcMdyD_normal.jpg",
      "id" : 222584301,
      "verified" : false
    }
  },
  "id" : 632242338484482048,
  "created_at" : "2015-08-14 17:28:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 46, 55 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 80, 92 ],
      "id_str" : "65045121",
      "id" : 65045121
    }, {
      "name" : "Seumas Milne",
      "screen_name" : "SeumasMilne",
      "indices" : [ 93, 105 ],
      "id_str" : "319675272",
      "id" : 319675272
    }, {
      "name" : "GeorgeMonbiot",
      "screen_name" : "GeorgeMonbiot",
      "indices" : [ 106, 120 ],
      "id_str" : "198584761",
      "id" : 198584761
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 121, 131 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "indices" : [ 132, 140 ],
      "id_str" : "117777690",
      "id" : 117777690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/uTcArXrtDc",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/08\/time-to-boycott-and-exit-guardian.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/08\/time-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632241612727283713",
  "text" : "RT @johnwhilley: Time to boycott and exit the @guardian http:\/\/t.co\/uTcArXrtDc  @OwenJones84 @SeumasMilne @GeorgeMonbiot @medialens @jeremy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 29, 38 ],
        "id_str" : "87818409",
        "id" : 87818409
      }, {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 63, 75 ],
        "id_str" : "65045121",
        "id" : 65045121
      }, {
        "name" : "Seumas Milne",
        "screen_name" : "SeumasMilne",
        "indices" : [ 76, 88 ],
        "id_str" : "319675272",
        "id" : 319675272
      }, {
        "name" : "GeorgeMonbiot",
        "screen_name" : "GeorgeMonbiot",
        "indices" : [ 89, 103 ],
        "id_str" : "198584761",
        "id" : 198584761
      }, {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 104, 114 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "Jeremy Corbyn MP",
        "screen_name" : "jeremycorbyn",
        "indices" : [ 115, 128 ],
        "id_str" : "117777690",
        "id" : 117777690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/uTcArXrtDc",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/08\/time-to-boycott-and-exit-guardian.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/08\/time-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632192598648745984",
    "text" : "Time to boycott and exit the @guardian http:\/\/t.co\/uTcArXrtDc  @OwenJones84 @SeumasMilne @GeorgeMonbiot @medialens @jeremycorbyn  #Corbyn",
    "id" : 632192598648745984,
    "created_at" : "2015-08-14 14:10:35 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 632241612727283713,
  "created_at" : "2015-08-14 17:25:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "indices" : [ 3, 18 ],
      "id_str" : "20098015",
      "id" : 20098015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631965269305520128",
  "text" : "RT @davidschneider: Units of time, in increasing order:\nSecond\nMinute\nHour\nDay\nWeek\nMonth\nYear\nDecade\nCentury\nMillenium\nAeon\nChilcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631799166038097920",
    "text" : "Units of time, in increasing order:\nSecond\nMinute\nHour\nDay\nWeek\nMonth\nYear\nDecade\nCentury\nMillenium\nAeon\nChilcot",
    "id" : 631799166038097920,
    "created_at" : "2015-08-13 12:07:14 +0000",
    "user" : {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "protected" : false,
      "id_str" : "20098015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/85074940\/profilepic_normal.jpg",
      "id" : 20098015,
      "verified" : true
    }
  },
  "id" : 631965269305520128,
  "created_at" : "2015-08-13 23:07:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/HbfYohRCQu",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/we-cannot-allow-public-to-interfere.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/we-can\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631965104452583424",
  "text" : "RT @pchallinor: New mudgeonry: We cannot allow the public to interfere http:\/\/t.co\/HbfYohRCQu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/HbfYohRCQu",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/we-cannot-allow-public-to-interfere.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/we-can\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631890350764859392",
    "text" : "New mudgeonry: We cannot allow the public to interfere http:\/\/t.co\/HbfYohRCQu",
    "id" : 631890350764859392,
    "created_at" : "2015-08-13 18:09:34 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 631965104452583424,
  "created_at" : "2015-08-13 23:06:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Geraldine Mark",
      "screen_name" : "_GelMark",
      "indices" : [ 11, 20 ],
      "id_str" : "579727372",
      "id" : 579727372
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 21, 36 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631937180970172420",
  "geo" : { },
  "id_str" : "631953440336248832",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass @_GelMark @CambridgeUPELT ok thx",
  "id" : 631953440336248832,
  "in_reply_to_status_id" : 631937180970172420,
  "created_at" : "2015-08-13 22:20:15 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/wPppX2y63o",
      "expanded_url" : "http:\/\/tinysubversions.com\/stuff\/sxsw-panel-generator\/?word=.gUxyX%20TkLpq%20dvOyX%20IIkc%20UjOQbzQ%20QOpq%40%40%20.QTLVNbvjG%20Zj%20vHObyzn%20xBLs%20LpB%20LQSGAHDb%20rfImZQbzGGNQ%20EfDPkD%20Qk%20BxpB%20ETjBb%20Lpq%20Uj%20WzQSs%40%40%3EyX%3C%3EyX%3C%3FrqzOGjQ%20TNH%20lj%20zVjb%20pqOA%20zs%20IfOc%20UjkqhHgx%20yzpqLDA%20%2CvjkBxTmw%20JmjTP%20THl%20gLQm%20ULzs%20QSD%20pwkDA%20WvS%20%2CbyzvdkbzW%20uxTPHyh%20WLbSX-pGySzQzT%20dvOEfTzWvm%20zDq%20vOSfhCL%20IIkc%20IzUxJ%20Lpq%20IIkZ%20IIOA%20qxDc%20vzDq%20gvx%20azIJuHG%20dvkvTSzI%20zqkyHnxZ%20TOzpq%20zUkIuSLyBQ%20hfLp%20QfHHq%20pGzqWL%20WUOl%20USw%20QBvzySJ%20%2CbTzpwSLB%20LpB%20Qk%20pGLBWL%40%40%20.bfjjB%2FbzwTNjQzy%20dvkbm%20%2Cfjjpwb%20TLBlS%20vS%20ZH%20TjQknWS%20zpq%20QS%40%40%20%3E2p%2F%3CdvOvySzI%40%40%20lj%20akflqLv%40%40%20QbzwwmQ%40%40%20qUzgmBb%40%40%20hILp%40%40%20%3AbyzDGSLB%40%40%20gvS%20BUSA%40%40%20bfHjpwb%40%40%20qSpc%40%40%3E2p%3C",
      "display_url" : "tinysubversions.com\/stuff\/sxsw-pan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631953025741942784",
  "text" : "What Schools Want and Teachers: Help Student Success Netflix of Learning http:\/\/t.co\/wPppX2y63o",
  "id" : 631953025741942784,
  "created_at" : "2015-08-13 22:18:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/APpOkzPECr",
      "expanded_url" : "http:\/\/tinysubversions.com\/stuff\/sxsw-panel-generator",
      "display_url" : "tinysubversions.com\/stuff\/sxsw-pan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631952934171881472",
  "text" : "RT @tinysubversions: Uh hi, I made a toy that generates SXSW panel names and descriptions. You can even pick a topic to generate from http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/APpOkzPECr",
        "expanded_url" : "http:\/\/tinysubversions.com\/stuff\/sxsw-panel-generator",
        "display_url" : "tinysubversions.com\/stuff\/sxsw-pan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631580443222142976",
    "text" : "Uh hi, I made a toy that generates SXSW panel names and descriptions. You can even pick a topic to generate from http:\/\/t.co\/APpOkzPECr",
    "id" : 631580443222142976,
    "created_at" : "2015-08-12 21:38:06 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 631952934171881472,
  "created_at" : "2015-08-13 22:18:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631945094258495488",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about gender neuroscience",
  "id" : 631945094258495488,
  "created_at" : "2015-08-13 21:47:06 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631943889868292096",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about Dale cone",
  "id" : 631943889868292096,
  "created_at" : "2015-08-13 21:42:18 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631943173476999169",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about Dale's cone",
  "id" : 631943173476999169,
  "created_at" : "2015-08-13 21:39:28 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631934075452821504",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about algorithm",
  "id" : 631934075452821504,
  "created_at" : "2015-08-13 21:03:19 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Geraldine Mark",
      "screen_name" : "_GelMark",
      "indices" : [ 11, 20 ],
      "id_str" : "579727372",
      "id" : 579727372
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 21, 36 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631917108029464576",
  "geo" : { },
  "id_str" : "631924744019935232",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass @_GelMark @CambridgeUPELT nice, is there a way to interact with this programmatically?",
  "id" : 631924744019935232,
  "in_reply_to_status_id" : 631917108029464576,
  "created_at" : "2015-08-13 20:26:14 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 3, 13 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Geraldine Mark",
      "screen_name" : "_GelMark",
      "indices" : [ 79, 88 ],
      "id_str" : "579727372",
      "id" : 579727372
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 121, 136 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "corpus",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "grammar",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/OoSeZw8jXn",
      "expanded_url" : "http:\/\/www.englishprofile.org\/english-grammar-profile",
      "display_url" : "englishprofile.org\/english-gramma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631922775813398528",
  "text" : "RT @TEFLclass: Check out the results of four years of corpus grammar work with @_GelMark http:\/\/t.co\/OoSeZw8jXn #eltchat @CambridgeUPELT #c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geraldine Mark",
        "screen_name" : "_GelMark",
        "indices" : [ 64, 73 ],
        "id_str" : "579727372",
        "id" : 579727372
      }, {
        "name" : "Cambridge ELT",
        "screen_name" : "CambridgeUPELT",
        "indices" : [ 106, 121 ],
        "id_str" : "73107903",
        "id" : 73107903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "corpus",
        "indices" : [ 122, 129 ]
      }, {
        "text" : "grammar",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/OoSeZw8jXn",
        "expanded_url" : "http:\/\/www.englishprofile.org\/english-grammar-profile",
        "display_url" : "englishprofile.org\/english-gramma\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631917108029464576",
    "text" : "Check out the results of four years of corpus grammar work with @_GelMark http:\/\/t.co\/OoSeZw8jXn #eltchat @CambridgeUPELT #corpus #grammar",
    "id" : 631917108029464576,
    "created_at" : "2015-08-13 19:55:53 +0000",
    "user" : {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "protected" : false,
      "id_str" : "469244585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000353527279\/c15d358a877f62d20d0e180a1da73b4c_normal.jpeg",
      "id" : 469244585,
      "verified" : false
    }
  },
  "id" : 631922775813398528,
  "created_at" : "2015-08-13 20:18:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 54, 69 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/ysJ2inkNEF",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1le",
      "display_url" : "wp.me\/p3qkCB-1le"
    } ]
  },
  "geo" : { },
  "id_str" : "631910229626736640",
  "text" : "Harmer Sinks to New Depths http:\/\/t.co\/ysJ2inkNEF via @GeoffreyJordan",
  "id" : 631910229626736640,
  "created_at" : "2015-08-13 19:28:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631907991868932096",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about guessing from context",
  "id" : 631907991868932096,
  "created_at" : "2015-08-13 19:19:40 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631905495910096897",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about skimming scanning",
  "id" : 631905495910096897,
  "created_at" : "2015-08-13 19:09:45 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631880661721325569",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about mindset",
  "id" : 631880661721325569,
  "created_at" : "2015-08-13 17:31:04 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Dykes",
      "screen_name" : "jonathandykes1",
      "indices" : [ 76, 91 ],
      "id_str" : "247811466",
      "id" : 247811466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/aHl7BZjuyF",
      "expanded_url" : "http:\/\/wp.me\/p4Vgvf-X",
      "display_url" : "wp.me\/p4Vgvf-X"
    } ]
  },
  "geo" : { },
  "id_str" : "631865093161119744",
  "text" : "The Market for Digital English Language Learning http:\/\/t.co\/aHl7BZjuyF via @jonathandykes1",
  "id" : 631865093161119744,
  "created_at" : "2015-08-13 16:29:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/mcULDjh7GJ",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/more-fun-in-great-game.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/more-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631598802097545217",
  "text" : "RT @pchallinor: New mudgeonry: More fun in the Great Game http:\/\/t.co\/mcULDjh7GJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/mcULDjh7GJ",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/more-fun-in-great-game.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/more-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630396577543254016",
    "text" : "New mudgeonry: More fun in the Great Game http:\/\/t.co\/mcULDjh7GJ",
    "id" : 630396577543254016,
    "created_at" : "2015-08-09 15:13:50 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 631598802097545217,
  "created_at" : "2015-08-12 22:51:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Burin",
      "screen_name" : "rickburin",
      "indices" : [ 3, 13 ],
      "id_str" : "104141256",
      "id" : 104141256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/CrjdPfEQdz",
      "expanded_url" : "https:\/\/twitter.com\/campbellclaret\/status\/630704203917303808",
      "display_url" : "twitter.com\/campbellclaret\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631597791383564288",
  "text" : "RT @rickburin: Corbyn could destroy Labour within 45 minutes - claim. https:\/\/t.co\/CrjdPfEQdz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/CrjdPfEQdz",
        "expanded_url" : "https:\/\/twitter.com\/campbellclaret\/status\/630704203917303808",
        "display_url" : "twitter.com\/campbellclaret\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630755704664649728",
    "text" : "Corbyn could destroy Labour within 45 minutes - claim. https:\/\/t.co\/CrjdPfEQdz",
    "id" : 630755704664649728,
    "created_at" : "2015-08-10 15:00:53 +0000",
    "user" : {
      "name" : "Rick Burin",
      "screen_name" : "rickburin",
      "protected" : false,
      "id_str" : "104141256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636252547586654208\/iftjuyve_normal.jpg",
      "id" : 104141256,
      "verified" : false
    }
  },
  "id" : 631597791383564288,
  "created_at" : "2015-08-12 22:47:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631593834565120000",
  "geo" : { },
  "id_str" : "631594968910536704",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith thanks for news on these boogiemen, need to be ever vigilant for sure :\/",
  "id" : 631594968910536704,
  "in_reply_to_status_id" : 631593834565120000,
  "created_at" : "2015-08-12 22:35:49 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631590934803795968",
  "geo" : { },
  "id_str" : "631592559882711041",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson okay was a throwaway tweet though was thinking why reinterpret a weak concept?",
  "id" : 631592559882711041,
  "in_reply_to_status_id" : 631590934803795968,
  "created_at" : "2015-08-12 22:26:15 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Matt Bury",
      "screen_name" : "matbury",
      "indices" : [ 14, 22 ],
      "id_str" : "38153900",
      "id" : 38153900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631590934803795968",
  "geo" : { },
  "id_str" : "631592150283763712",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @matbury ok though can't see comment facility on post?",
  "id" : 631592150283763712,
  "in_reply_to_status_id" : 631590934803795968,
  "created_at" : "2015-08-12 22:24:37 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1buhf41ady",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1715",
      "display_url" : "cass.lancs.ac.uk\/?p=1715"
    } ]
  },
  "geo" : { },
  "id_str" : "631591144091176960",
  "text" : "RT @CorpusSocialSci: The Spoken British National Corpus 2014 \u2013 project update now available. Read more at http:\/\/t.co\/1buhf41ady",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/1buhf41ady",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1715",
        "display_url" : "cass.lancs.ac.uk\/?p=1715"
      } ]
    },
    "geo" : { },
    "id_str" : "631092125401223168",
    "text" : "The Spoken British National Corpus 2014 \u2013 project update now available. Read more at http:\/\/t.co\/1buhf41ady",
    "id" : 631092125401223168,
    "created_at" : "2015-08-11 13:17:42 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 631591144091176960,
  "created_at" : "2015-08-12 22:20:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 104, 119 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/UJQBbql4Ja",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/adapting-academic-reading-circles-for-the-listening-and-speaking-classroom",
      "display_url" : "anthonyteacher.com\/blog\/adapting-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631590795628408832",
  "text" : "Adapting \"Academic Reading Circles\" for the Listening and Speaking Classroom http:\/\/t.co\/UJQBbql4Ja via @AnthonyTeacher",
  "id" : 631590795628408832,
  "created_at" : "2015-08-12 22:19:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631586754349395969",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about mindset",
  "id" : 631586754349395969,
  "created_at" : "2015-08-12 22:03:11 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Matt Bury",
      "screen_name" : "matbury",
      "indices" : [ 14, 22 ],
      "id_str" : "38153900",
      "id" : 38153900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631573780075290624",
  "geo" : { },
  "id_str" : "631583104247943169",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @matbury hmm interesting though rescueing one dodgy concept with one trendy concept is debateable :)",
  "id" : 631583104247943169,
  "in_reply_to_status_id" : 631573780075290624,
  "created_at" : "2015-08-12 21:48:40 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631533280349831168",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about skimming scanning",
  "id" : 631533280349831168,
  "created_at" : "2015-08-12 18:30:42 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631449827583377408",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about prediction",
  "id" : 631449827583377408,
  "created_at" : "2015-08-12 12:59:05 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 22, 28 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631446048985231360",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @ebefl about prediction",
  "id" : 631446048985231360,
  "created_at" : "2015-08-12 12:44:04 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 22, 31 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631410412693680128",
  "in_reply_to_user_id" : 3416415189,
  "text" : "@thisbyanychance tell @muranava about cats",
  "id" : 631410412693680128,
  "created_at" : "2015-08-12 10:22:28 +0000",
  "in_reply_to_screen_name" : "thisbyanychance",
  "in_reply_to_user_id_str" : "3416415189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631084944677302272",
  "geo" : { },
  "id_str" : "631086722227552256",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew uh oh samr? :\/",
  "id" : 631086722227552256,
  "in_reply_to_status_id" : 631084944677302272,
  "created_at" : "2015-08-11 12:56:14 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631040926102622209",
  "geo" : { },
  "id_str" : "631049852777009153",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish yr welcome yes thx though seems to be going as fast as ever hope",
  "id" : 631049852777009153,
  "in_reply_to_status_id" : 631040926102622209,
  "created_at" : "2015-08-11 10:29:43 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631028214345936896",
  "geo" : { },
  "id_str" : "631031165001056256",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha see you've been busy on the blogging front as usual, somethings to catch up on, thanks :)",
  "id" : 631031165001056256,
  "in_reply_to_status_id" : 631028214345936896,
  "created_at" : "2015-08-11 09:15:28 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Carmody",
      "screen_name" : "tcarmody",
      "indices" : [ 3, 12 ],
      "id_str" : "14439168",
      "id" : 14439168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631025749168885760",
  "text" : "RT @tcarmody: Google: \u201CDon\u2019t be evil\u201D\nAlphabet: \u201CEvil is just one of our businesses\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630846568019529728",
    "text" : "Google: \u201CDon\u2019t be evil\u201D\nAlphabet: \u201CEvil is just one of our businesses\u201D",
    "id" : 630846568019529728,
    "created_at" : "2015-08-10 21:01:57 +0000",
    "user" : {
      "name" : "Tim Carmody",
      "screen_name" : "tcarmody",
      "protected" : false,
      "id_str" : "14439168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765088996078809088\/cBzjJ6D3_normal.jpg",
      "id" : 14439168,
      "verified" : true
    }
  },
  "id" : 631025749168885760,
  "created_at" : "2015-08-11 08:53:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 62, 72 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/OQDOZyW15H",
      "expanded_url" : "http:\/\/wp.me\/p6aVNf-nW",
      "display_url" : "wp.me\/p6aVNf-nW"
    } ]
  },
  "geo" : { },
  "id_str" : "631023445887852544",
  "text" : "The right question, the right time http:\/\/t.co\/OQDOZyW15H via @HanaTicha",
  "id" : 631023445887852544,
  "created_at" : "2015-08-11 08:44:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 3, 9 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 78, 90 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Ar9iqgpU9u",
      "expanded_url" : "http:\/\/wp.me\/p2izcv-jU",
      "display_url" : "wp.me\/p2izcv-jU"
    } ]
  },
  "geo" : { },
  "id_str" : "631020955482112000",
  "text" : "RT @GemL1: when they're just not feeling it (a thing that happened today) via @annehendler http:\/\/t.co\/Ar9iqgpU9u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
        "screen_name" : "AnneHendler",
        "indices" : [ 67, 79 ],
        "id_str" : "525013404",
        "id" : 525013404
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Ar9iqgpU9u",
        "expanded_url" : "http:\/\/wp.me\/p2izcv-jU",
        "display_url" : "wp.me\/p2izcv-jU"
      } ]
    },
    "geo" : { },
    "id_str" : "630835515575652356",
    "text" : "when they're just not feeling it (a thing that happened today) via @annehendler http:\/\/t.co\/Ar9iqgpU9u",
    "id" : 630835515575652356,
    "created_at" : "2015-08-10 20:18:01 +0000",
    "user" : {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "protected" : false,
      "id_str" : "486146568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652399796112740353\/sQhaCdI__normal.jpg",
      "id" : 486146568,
      "verified" : false
    }
  },
  "id" : 631020955482112000,
  "created_at" : "2015-08-11 08:34:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/KkYOUNAOYp",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/08\/10\/the-constraints-of-the-syllabus-the-restraints-of-the-teacher",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/08\/10\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631020747251675136",
  "text" : "RT @getgreatenglish: Work during holidays, critical pedagogy and word lists and more. My latest post: https:\/\/t.co\/KkYOUNAOYp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/KkYOUNAOYp",
        "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/08\/10\/the-constraints-of-the-syllabus-the-restraints-of-the-teacher",
        "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/08\/10\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631008819955392512",
    "text" : "Work during holidays, critical pedagogy and word lists and more. My latest post: https:\/\/t.co\/KkYOUNAOYp",
    "id" : 631008819955392512,
    "created_at" : "2015-08-11 07:46:40 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 631020747251675136,
  "created_at" : "2015-08-11 08:34:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PwueD9w4nb",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/aug15\/idea.htm",
      "display_url" : "hltmag.co.uk\/aug15\/idea.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "631020498474942464",
  "text" : "RT @ELTResearch: Just had this practical piece published in the always excellent HLT-  2 simple ideas for using corpora in class. \nhttp:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/PwueD9w4nb",
        "expanded_url" : "http:\/\/www.hltmag.co.uk\/aug15\/idea.htm",
        "display_url" : "hltmag.co.uk\/aug15\/idea.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "631008012715618304",
    "text" : "Just had this practical piece published in the always excellent HLT-  2 simple ideas for using corpora in class. \nhttp:\/\/t.co\/PwueD9w4nb",
    "id" : 631008012715618304,
    "created_at" : "2015-08-11 07:43:28 +0000",
    "user" : {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "protected" : false,
      "id_str" : "3308043417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720360015383654400\/Zq4CQgZv_normal.jpg",
      "id" : 3308043417,
      "verified" : false
    }
  },
  "id" : 631020498474942464,
  "created_at" : "2015-08-11 08:33:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/PTQTwr3CD3",
      "expanded_url" : "http:\/\/go.shr.lc\/1KP2tXu",
      "display_url" : "go.shr.lc\/1KP2tXu"
    } ]
  },
  "geo" : { },
  "id_str" : "629034141963689985",
  "text" : "RT @leninology: LENIN'S TOMB: Polls do not win political arguments, newspaper shows - http:\/\/t.co\/PTQTwr3CD3 &lt;&lt; on the manufacturing of con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/PTQTwr3CD3",
        "expanded_url" : "http:\/\/go.shr.lc\/1KP2tXu",
        "display_url" : "go.shr.lc\/1KP2tXu"
      } ]
    },
    "geo" : { },
    "id_str" : "628696879564500992",
    "text" : "LENIN'S TOMB: Polls do not win political arguments, newspaper shows - http:\/\/t.co\/PTQTwr3CD3 &lt;&lt; on the manufacturing of consent.",
    "id" : 628696879564500992,
    "created_at" : "2015-08-04 22:39:51 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 629034141963689985,
  "created_at" : "2015-08-05 21:00:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/2txDpD1lvh",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/bloody-minded.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/bloody\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628864509617291264",
  "text" : "RT @pchallinor: New mudgeonry: Bloody-minded http:\/\/t.co\/2txDpD1lvh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/2txDpD1lvh",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/bloody-minded.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/bloody\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628641415447212032",
    "text" : "New mudgeonry: Bloody-minded http:\/\/t.co\/2txDpD1lvh",
    "id" : 628641415447212032,
    "created_at" : "2015-08-04 18:59:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 628864509617291264,
  "created_at" : "2015-08-05 09:45:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/EtOFKBDmsh",
      "expanded_url" : "https:\/\/peterviney.wordpress.com\/rants\/on-the-road-information-overkill\/",
      "display_url" : "peterviney.wordpress.com\/rants\/on-the-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628853196614684672",
  "text" : "On The Road: Information overkill https:\/\/t.co\/EtOFKBDmsh",
  "id" : 628853196614684672,
  "created_at" : "2015-08-05 09:01:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 3, 11 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "spokendiscourse",
      "indices" : [ 103, 119 ]
    }, {
      "text" : "tefl",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/FJKwLhmznr",
      "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2015\/08\/04\/active-listening-a-lesson-plan-version-2-0\/",
      "display_url" : "eltgeek.wordpress.com\/2015\/08\/04\/act\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628700848206561280",
  "text" : "RT @olyaelt: Strategies for active listening: an authentic video and an accompanying lesson plan. #elt #spokendiscourse #tefl\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "spokendiscourse",
        "indices" : [ 90, 106 ]
      }, {
        "text" : "tefl",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/FJKwLhmznr",
        "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2015\/08\/04\/active-listening-a-lesson-plan-version-2-0\/",
        "display_url" : "eltgeek.wordpress.com\/2015\/08\/04\/act\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628678581384814592",
    "text" : "Strategies for active listening: an authentic video and an accompanying lesson plan. #elt #spokendiscourse #tefl\nhttps:\/\/t.co\/FJKwLhmznr",
    "id" : 628678581384814592,
    "created_at" : "2015-08-04 21:27:08 +0000",
    "user" : {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "protected" : false,
      "id_str" : "2176726134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592983544823042049\/GQ3T3m4K_normal.jpg",
      "id" : 2176726134,
      "verified" : false
    }
  },
  "id" : 628700848206561280,
  "created_at" : "2015-08-04 22:55:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Transcripts",
      "screen_name" : "OpenTranscripts",
      "indices" : [ 3, 19 ],
      "id_str" : "2308359312",
      "id" : 2308359312
    }, {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 35, 44 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/L0jeyplYut",
      "expanded_url" : "http:\/\/opentranscripts.org\/transcript\/semantic-space-literal-robots\/",
      "display_url" : "opentranscripts.org\/transcript\/sem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628684316344774656",
  "text" : "RT @OpenTranscripts: At Eyeo 2015, @aparrish presented her thoughts on a framework for \"Exploring (Semantic) Space With (Literal) Robots\" h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allison Parrish",
        "screen_name" : "aparrish",
        "indices" : [ 14, 23 ],
        "id_str" : "6857962",
        "id" : 6857962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/L0jeyplYut",
        "expanded_url" : "http:\/\/opentranscripts.org\/transcript\/semantic-space-literal-robots\/",
        "display_url" : "opentranscripts.org\/transcript\/sem\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628630245784981504",
    "text" : "At Eyeo 2015, @aparrish presented her thoughts on a framework for \"Exploring (Semantic) Space With (Literal) Robots\" http:\/\/t.co\/L0jeyplYut",
    "id" : 628630245784981504,
    "created_at" : "2015-08-04 18:15:04 +0000",
    "user" : {
      "name" : "Open Transcripts",
      "screen_name" : "OpenTranscripts",
      "protected" : false,
      "id_str" : "2308359312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582623755005927424\/gnvjb5ZL_normal.png",
      "id" : 2308359312,
      "verified" : false
    }
  },
  "id" : 628684316344774656,
  "created_at" : "2015-08-04 21:49:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/8HHEqtQ6HB",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/its-good-clean-fight.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/its-go\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628614897681735681",
  "text" : "RT @pchallinor: New mudgeonry: It's a good clean fight http:\/\/t.co\/8HHEqtQ6HB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/8HHEqtQ6HB",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/08\/its-good-clean-fight.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/08\/its-go\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628276523921993734",
    "text" : "New mudgeonry: It's a good clean fight http:\/\/t.co\/8HHEqtQ6HB",
    "id" : 628276523921993734,
    "created_at" : "2015-08-03 18:49:30 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 628614897681735681,
  "created_at" : "2015-08-04 17:14:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 85, 97 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/iXOcCIZ0L3",
      "expanded_url" : "http:\/\/wp.me\/p633Ji-26H",
      "display_url" : "wp.me\/p633Ji-26H"
    } ]
  },
  "geo" : { },
  "id_str" : "628601303367831553",
  "text" : "Assange: the untold story of an epic struggle for justice http:\/\/t.co\/iXOcCIZ0L3 via @OffGuardian",
  "id" : 628601303367831553,
  "created_at" : "2015-08-04 16:20:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 3, 14 ],
      "id_str" : "18880320",
      "id" : 18880320
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 121, 132 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/628437104712744960\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/75it2umD8m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLioN2kUMAEcfti.jpg",
      "id_str" : "628437103957782529",
      "id" : 628437103957782529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLioN2kUMAEcfti.jpg",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 751
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 751
      } ],
      "display_url" : "pic.twitter.com\/75it2umD8m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Zj1XjMMI5x",
      "expanded_url" : "http:\/\/itdi.pro\/itdihome\/summer2015.php",
      "display_url" : "itdi.pro\/itdihome\/summe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628492810157727744",
  "text" : "RT @chucksandy: Educator, author, editor, mentor, father, friend Kevin Stein puts it all together http:\/\/t.co\/Zj1XjMMI5x @kevchanwow http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 105, 116 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/628437104712744960\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/75it2umD8m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLioN2kUMAEcfti.jpg",
        "id_str" : "628437103957782529",
        "id" : 628437103957782529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLioN2kUMAEcfti.jpg",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 751
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 751
        } ],
        "display_url" : "pic.twitter.com\/75it2umD8m"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Zj1XjMMI5x",
        "expanded_url" : "http:\/\/itdi.pro\/itdihome\/summer2015.php",
        "display_url" : "itdi.pro\/itdihome\/summe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628437104712744960",
    "text" : "Educator, author, editor, mentor, father, friend Kevin Stein puts it all together http:\/\/t.co\/Zj1XjMMI5x @kevchanwow http:\/\/t.co\/75it2umD8m",
    "id" : 628437104712744960,
    "created_at" : "2015-08-04 05:27:36 +0000",
    "user" : {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "protected" : false,
      "id_str" : "18880320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620217802465513472\/poN-d2nR_normal.jpg",
      "id" : 18880320,
      "verified" : false
    }
  },
  "id" : 628492810157727744,
  "created_at" : "2015-08-04 09:08:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    }, {
      "name" : "Useless Press",
      "screen_name" : "theuselesspress",
      "indices" : [ 31, 47 ],
      "id_str" : "3368852195",
      "id" : 3368852195
    }, {
      "name" : "Adrian Chen",
      "screen_name" : "AdrianChen",
      "indices" : [ 51, 62 ],
      "id_str" : "20605481",
      "id" : 20605481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/VHi1FaednF",
      "expanded_url" : "http:\/\/uselesspress.org",
      "display_url" : "uselesspress.org"
    } ]
  },
  "geo" : { },
  "id_str" : "628225222328631296",
  "text" : "RT @sam_lavigne: Just launched @theuselesspress w\/ @AdrianChen and Alix Rule. We publish internet things &amp; we have a cool website: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Useless Press",
        "screen_name" : "theuselesspress",
        "indices" : [ 14, 30 ],
        "id_str" : "3368852195",
        "id" : 3368852195
      }, {
        "name" : "Adrian Chen",
        "screen_name" : "AdrianChen",
        "indices" : [ 34, 45 ],
        "id_str" : "20605481",
        "id" : 20605481
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VHi1FaednF",
        "expanded_url" : "http:\/\/uselesspress.org",
        "display_url" : "uselesspress.org"
      } ]
    },
    "geo" : { },
    "id_str" : "628211843685728256",
    "text" : "Just launched @theuselesspress w\/ @AdrianChen and Alix Rule. We publish internet things &amp; we have a cool website: http:\/\/t.co\/VHi1FaednF",
    "id" : 628211843685728256,
    "created_at" : "2015-08-03 14:32:29 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 628225222328631296,
  "created_at" : "2015-08-03 15:25:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 3, 15 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/AuIWRzgLc1",
      "expanded_url" : "http:\/\/bit.ly\/1Hj5iZq",
      "display_url" : "bit.ly\/1Hj5iZq"
    } ]
  },
  "geo" : { },
  "id_str" : "628193019922153472",
  "text" : "RT @LanguageLog: French vs. English: When I travel around the world and come upon parallel translations of French and English, ... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/AuIWRzgLc1",
        "expanded_url" : "http:\/\/bit.ly\/1Hj5iZq",
        "display_url" : "bit.ly\/1Hj5iZq"
      } ]
    },
    "geo" : { },
    "id_str" : "627952860026638336",
    "text" : "French vs. English: When I travel around the world and come upon parallel translations of French and English, ... http:\/\/t.co\/AuIWRzgLc1",
    "id" : 627952860026638336,
    "created_at" : "2015-08-02 21:23:23 +0000",
    "user" : {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "protected" : false,
      "id_str" : "20148973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011503265\/gerund2_normal.jpg",
      "id" : 20148973,
      "verified" : false
    }
  },
  "id" : 628193019922153472,
  "created_at" : "2015-08-03 13:17:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627485682651394048",
  "geo" : { },
  "id_str" : "628182542911414272",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei OK thx :)",
  "id" : 628182542911414272,
  "in_reply_to_status_id" : 627485682651394048,
  "created_at" : "2015-08-03 12:36:03 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2CXWbTRSk6",
      "expanded_url" : "https:\/\/www.academia.edu\/14571203\/Automatic_monitoring_of_quick-types_a_tool_to_visualise_progress_and_detect_cheating",
      "display_url" : "academia.edu\/14571203\/Autom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628181262809845760",
  "text" : "Automatic monitoring of quick-types: a tool to visualise progress and detect cheating, Malcolm Prentice\nhttps:\/\/t.co\/2CXWbTRSk6",
  "id" : 628181262809845760,
  "created_at" : "2015-08-03 12:30:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Melville",
      "screen_name" : "JamesMelville",
      "indices" : [ 3, 17 ],
      "id_str" : "20675681",
      "id" : 20675681
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JamesMelville\/status\/627472085716205568\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/tvOqax7EZO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLU6hG_XAAEl7s5.jpg",
      "id_str" : "627472063574507521",
      "id" : 627472063574507521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLU6hG_XAAEl7s5.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/tvOqax7EZO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628177342997921792",
  "text" : "RT @JamesMelville: How gain 'followers' &amp; 'friends' without using Twitter or Facebook.\nTake a bow, Peter White. http:\/\/t.co\/tvOqax7EZO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JamesMelville\/status\/627472085716205568\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/tvOqax7EZO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLU6hG_XAAEl7s5.jpg",
        "id_str" : "627472063574507521",
        "id" : 627472063574507521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLU6hG_XAAEl7s5.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/tvOqax7EZO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627472085716205568",
    "text" : "How gain 'followers' &amp; 'friends' without using Twitter or Facebook.\nTake a bow, Peter White. http:\/\/t.co\/tvOqax7EZO",
    "id" : 627472085716205568,
    "created_at" : "2015-08-01 13:32:57 +0000",
    "user" : {
      "name" : "James Melville",
      "screen_name" : "JamesMelville",
      "protected" : false,
      "id_str" : "20675681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766878115280936960\/8qif430z_normal.jpg",
      "id" : 20675681,
      "verified" : false
    }
  },
  "id" : 628177342997921792,
  "created_at" : "2015-08-03 12:15:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 3, 9 ],
      "id_str" : "105883895",
      "id" : 105883895
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 22, 37 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tdsig\/status\/628101399952400384\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/oKW3nZDfGw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLd25MzWcAAAB6e.png",
      "id_str" : "628101398102700032",
      "id" : 628101398102700032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLd25MzWcAAAB6e.png",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 694
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 694
      } ],
      "display_url" : "pic.twitter.com\/oKW3nZDfGw"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/tdsig\/status\/628101399952400384\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/oKW3nZDfGw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLd24o7WoAAYHkq.jpg",
      "id_str" : "628101388472590336",
      "id" : 628101388472590336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLd24o7WoAAYHkq.jpg",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/oKW3nZDfGw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/cvL9y26X8B",
      "expanded_url" : "http:\/\/tesltoronto.org\/tobelta15",
      "display_url" : "tesltoronto.org\/tobelta15"
    } ]
  },
  "geo" : { },
  "id_str" : "628171828813516800",
  "text" : "RT @tdsig: Don't miss @_divyamadhavan! Friday August 7 CET 17:30 \u2013 More info: http:\/\/t.co\/cvL9y26X8B http:\/\/t.co\/oKW3nZDfGw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Divya Madhavan",
        "screen_name" : "_divyamadhavan",
        "indices" : [ 11, 26 ],
        "id_str" : "408492806",
        "id" : 408492806
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tdsig\/status\/628101399952400384\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/oKW3nZDfGw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLd25MzWcAAAB6e.png",
        "id_str" : "628101398102700032",
        "id" : 628101398102700032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLd25MzWcAAAB6e.png",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 161,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 694
        } ],
        "display_url" : "pic.twitter.com\/oKW3nZDfGw"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/tdsig\/status\/628101399952400384\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/oKW3nZDfGw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLd24o7WoAAYHkq.jpg",
        "id_str" : "628101388472590336",
        "id" : 628101388472590336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLd24o7WoAAYHkq.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/oKW3nZDfGw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/cvL9y26X8B",
        "expanded_url" : "http:\/\/tesltoronto.org\/tobelta15",
        "display_url" : "tesltoronto.org\/tobelta15"
      } ]
    },
    "geo" : { },
    "id_str" : "628101399952400384",
    "text" : "Don't miss @_divyamadhavan! Friday August 7 CET 17:30 \u2013 More info: http:\/\/t.co\/cvL9y26X8B http:\/\/t.co\/oKW3nZDfGw",
    "id" : 628101399952400384,
    "created_at" : "2015-08-03 07:13:37 +0000",
    "user" : {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "protected" : false,
      "id_str" : "105883895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665107598\/tdsig-ico-facebook-twitter_normal.jpg",
      "id" : 105883895,
      "verified" : false
    }
  },
  "id" : 628171828813516800,
  "created_at" : "2015-08-03 11:53:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/dbwcRyAN1n",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2015\/08\/acid-test.html?m=1",
      "display_url" : "giaklamata.blogspot.fr\/2015\/08\/acid-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628170683420381184",
  "text" : "Acid test http:\/\/t.co\/dbwcRyAN1n",
  "id" : 628170683420381184,
  "created_at" : "2015-08-03 11:48:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT Assoc Berlin",
      "screen_name" : "eltabb",
      "indices" : [ 3, 10 ],
      "id_str" : "18966557",
      "id" : 18966557
    }, {
      "name" : "Tom Heaven",
      "screen_name" : "ReaOnSpree",
      "indices" : [ 90, 101 ],
      "id_str" : "68504404",
      "id" : 68504404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lessonjam",
      "indices" : [ 42, 52 ]
    }, {
      "text" : "elt",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 130, 138 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/3hAZMBdCqc",
      "expanded_url" : "http:\/\/tomheaven.com\/cairo-berlin-lesson-jam\/",
      "display_url" : "tomheaven.com\/cairo-berlin-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627937466532671488",
  "text" : "RT @eltabb: Find out what happened at the #lessonjam with Cairo yesterday, coordinated by @ReaOnSpree http:\/\/t.co\/3hAZMBdCqc #elt #eltchat \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Heaven",
        "screen_name" : "ReaOnSpree",
        "indices" : [ 78, 89 ],
        "id_str" : "68504404",
        "id" : 68504404
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lessonjam",
        "indices" : [ 30, 40 ]
      }, {
        "text" : "elt",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 118, 126 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/3hAZMBdCqc",
        "expanded_url" : "http:\/\/tomheaven.com\/cairo-berlin-lesson-jam\/",
        "display_url" : "tomheaven.com\/cairo-berlin-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627914789587652608",
    "text" : "Find out what happened at the #lessonjam with Cairo yesterday, coordinated by @ReaOnSpree http:\/\/t.co\/3hAZMBdCqc #elt #eltchat #iatefl",
    "id" : 627914789587652608,
    "created_at" : "2015-08-02 18:52:06 +0000",
    "user" : {
      "name" : "ELT Assoc Berlin",
      "screen_name" : "eltabb",
      "protected" : false,
      "id_str" : "18966557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615267428029870080\/Kq_vLLQV_normal.png",
      "id" : 18966557,
      "verified" : false
    }
  },
  "id" : 627937466532671488,
  "created_at" : "2015-08-02 20:22:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 3, 11 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    }, {
      "name" : "Tekh",
      "screen_name" : "Tekhnologic",
      "indices" : [ 90, 102 ],
      "id_str" : "1336152278",
      "id" : 1336152278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/3K7DqtmASU",
      "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2015\/08\/02\/creating-revision-board-games-the-easy-way\/",
      "display_url" : "eltgeek.wordpress.com\/2015\/08\/02\/cre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627937412119965696",
  "text" : "RT @olyaelt: For busy teachers: creating board games in a few clicks. With special thx to @Tekhnologic, whose template I adapted. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tekh",
        "screen_name" : "Tekhnologic",
        "indices" : [ 77, 89 ],
        "id_str" : "1336152278",
        "id" : 1336152278
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3K7DqtmASU",
        "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2015\/08\/02\/creating-revision-board-games-the-easy-way\/",
        "display_url" : "eltgeek.wordpress.com\/2015\/08\/02\/cre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627915801669058560",
    "text" : "For busy teachers: creating board games in a few clicks. With special thx to @Tekhnologic, whose template I adapted. https:\/\/t.co\/3K7DqtmASU",
    "id" : 627915801669058560,
    "created_at" : "2015-08-02 18:56:07 +0000",
    "user" : {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "protected" : false,
      "id_str" : "2176726134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592983544823042049\/GQ3T3m4K_normal.jpg",
      "id" : 2176726134,
      "verified" : false
    }
  },
  "id" : 627937412119965696,
  "created_at" : "2015-08-02 20:22:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mededitor",
      "screen_name" : "Mededitor",
      "indices" : [ 3, 13 ],
      "id_str" : "14123701",
      "id" : 14123701
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Mededitor\/status\/627846019158425600\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/AndnlG2cRp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLaOoJsUAAAKbUt.jpg",
      "id_str" : "627846018512453632",
      "id" : 627846018512453632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLaOoJsUAAAKbUt.jpg",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AndnlG2cRp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/OWYBh8uSEK",
      "expanded_url" : "http:\/\/www.macleans.ca\/society\/life\/in-the-midst-of-the-canadian-vowel-shift\/",
      "display_url" : "macleans.ca\/society\/life\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627937038826926080",
  "text" : "RT @Mededitor: Meanwhile, in Canada, a vowel shift is underway: http:\/\/t.co\/OWYBh8uSEK http:\/\/t.co\/AndnlG2cRp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Mededitor\/status\/627846019158425600\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/AndnlG2cRp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLaOoJsUAAAKbUt.jpg",
        "id_str" : "627846018512453632",
        "id" : 627846018512453632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLaOoJsUAAAKbUt.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AndnlG2cRp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/OWYBh8uSEK",
        "expanded_url" : "http:\/\/www.macleans.ca\/society\/life\/in-the-midst-of-the-canadian-vowel-shift\/",
        "display_url" : "macleans.ca\/society\/life\/i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627846019158425600",
    "text" : "Meanwhile, in Canada, a vowel shift is underway: http:\/\/t.co\/OWYBh8uSEK http:\/\/t.co\/AndnlG2cRp",
    "id" : 627846019158425600,
    "created_at" : "2015-08-02 14:18:50 +0000",
    "user" : {
      "name" : "Mededitor",
      "screen_name" : "Mededitor",
      "protected" : false,
      "id_str" : "14123701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717702576792342528\/snaG4RBw_normal.jpg",
      "id" : 14123701,
      "verified" : false
    }
  },
  "id" : 627937038826926080,
  "created_at" : "2015-08-02 20:20:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 3, 8 ],
      "id_str" : "23818581",
      "id" : 23818581
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VICE\/status\/627867724916486144\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/3tRGEkQmDW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLaM8UZWgAAuu6N.jpg",
      "id_str" : "627844165959843840",
      "id" : 627844165959843840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLaM8UZWgAAuu6N.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3tRGEkQmDW"
    } ],
    "hashtags" : [ {
      "text" : "GiveYourMoneyToWomen",
      "indices" : [ 75, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/yC35vTaa9C",
      "expanded_url" : "http:\/\/bit.ly\/1OIpA45",
      "display_url" : "bit.ly\/1OIpA45"
    } ]
  },
  "geo" : { },
  "id_str" : "627935350372044800",
  "text" : "RT @VICE: We spoke to Lauren Chief Elk, the woman behind the viral hashtag #GiveYourMoneyToWomen http:\/\/t.co\/yC35vTaa9C http:\/\/t.co\/3tRGEkQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VICE\/status\/627867724916486144\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/3tRGEkQmDW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLaM8UZWgAAuu6N.jpg",
        "id_str" : "627844165959843840",
        "id" : 627844165959843840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLaM8UZWgAAuu6N.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3tRGEkQmDW"
      } ],
      "hashtags" : [ {
        "text" : "GiveYourMoneyToWomen",
        "indices" : [ 65, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/yC35vTaa9C",
        "expanded_url" : "http:\/\/bit.ly\/1OIpA45",
        "display_url" : "bit.ly\/1OIpA45"
      } ]
    },
    "geo" : { },
    "id_str" : "627867724916486144",
    "text" : "We spoke to Lauren Chief Elk, the woman behind the viral hashtag #GiveYourMoneyToWomen http:\/\/t.co\/yC35vTaa9C http:\/\/t.co\/3tRGEkQmDW",
    "id" : 627867724916486144,
    "created_at" : "2015-08-02 15:45:05 +0000",
    "user" : {
      "name" : "VICE",
      "screen_name" : "VICE",
      "protected" : false,
      "id_str" : "23818581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672036189273120768\/4_Esv2H4_normal.jpg",
      "id" : 23818581,
      "verified" : true
    }
  },
  "id" : 627935350372044800,
  "created_at" : "2015-08-02 20:13:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 48, 56 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/3QPFjovXKA",
      "expanded_url" : "http:\/\/musicfordeckchairs.com\/blog\/2015\/08\/02\/service-as-a-service\/",
      "display_url" : "musicfordeckchairs.com\/blog\/2015\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627765167573569536",
  "text" : "Service as a Service http:\/\/t.co\/3QPFjovXKA via @KateMfD",
  "id" : 627765167573569536,
  "created_at" : "2015-08-02 08:57:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 3, 13 ],
      "id_str" : "87903271",
      "id" : 87903271
    }, {
      "name" : "Tom Bennett",
      "screen_name" : "tombennett71",
      "indices" : [ 85, 98 ],
      "id_str" : "208996041",
      "id" : 208996041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/UNtK7GG2yF",
      "expanded_url" : "https:\/\/www.tes.co.uk\/news\/blog\/sugata-mitra-and-hole-research",
      "display_url" : "tes.co.uk\/news\/blog\/suga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627481734968438784",
  "text" : "RT @JamesTheo: Sugata Mitra and the Hole in the Research https:\/\/t.co\/UNtK7GG2yF via @tombennett71",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Bennett",
        "screen_name" : "tombennett71",
        "indices" : [ 70, 83 ],
        "id_str" : "208996041",
        "id" : 208996041
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/UNtK7GG2yF",
        "expanded_url" : "https:\/\/www.tes.co.uk\/news\/blog\/sugata-mitra-and-hole-research",
        "display_url" : "tes.co.uk\/news\/blog\/suga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627400064395292672",
    "text" : "Sugata Mitra and the Hole in the Research https:\/\/t.co\/UNtK7GG2yF via @tombennett71",
    "id" : 627400064395292672,
    "created_at" : "2015-08-01 08:46:46 +0000",
    "user" : {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "protected" : false,
      "id_str" : "87903271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724679297391276033\/Fy8vphs6_normal.jpg",
      "id" : 87903271,
      "verified" : false
    }
  },
  "id" : 627481734968438784,
  "created_at" : "2015-08-01 14:11:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627401955636326404",
  "geo" : { },
  "id_str" : "627460037825441792",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo hi thx for the mention",
  "id" : 627460037825441792,
  "in_reply_to_status_id" : 627401955636326404,
  "created_at" : "2015-08-01 12:45:05 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]