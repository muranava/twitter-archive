Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michaelcraiggradwell",
      "screen_name" : "michaelcraig",
      "indices" : [ 0, 13 ],
      "id_str" : "805969",
      "id" : 805969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197068054407036929",
  "geo" : { },
  "id_str" : "197072258320183296",
  "in_reply_to_user_id" : 805969,
  "text" : "@michaelcraig mike, you shld open make yr account public and get many more followers!",
  "id" : 197072258320183296,
  "in_reply_to_status_id" : 197068054407036929,
  "created_at" : "2012-04-30 21:17:42 +0000",
  "in_reply_to_screen_name" : "michaelcraig",
  "in_reply_to_user_id_str" : "805969",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197051419046576130",
  "text" : "RT @samplereality: Apple's greatest trick was convincing educators that it cared about learning. Hasn't been true in two decades.&lt;-lol",
  "id" : 197051419046576130,
  "created_at" : "2012-04-30 19:54:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elinda Gjondedaj",
      "screen_name" : "ElindaGjondedaj",
      "indices" : [ 0, 16 ],
      "id_str" : "72877592",
      "id" : 72877592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197038459494465538",
  "geo" : { },
  "id_str" : "197046707555532801",
  "in_reply_to_user_id" : 72877592,
  "text" : "@ElindaGjondedaj yr welcome, hope u found it useful",
  "id" : 197046707555532801,
  "in_reply_to_status_id" : 197038459494465538,
  "created_at" : "2012-04-30 19:36:10 +0000",
  "in_reply_to_screen_name" : "ElindaGjondedaj",
  "in_reply_to_user_id_str" : "72877592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elinda Gjondedaj",
      "screen_name" : "ElindaGjondedaj",
      "indices" : [ 0, 16 ],
      "id_str" : "72877592",
      "id" : 72877592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/BU3yz9ME",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "in_reply_to_status_id_str" : "196916808094203904",
  "geo" : { },
  "id_str" : "196943383720239105",
  "in_reply_to_user_id" : 72877592,
  "text" : "@ElindaGjondedaj hi you may find my post about steps to protect against phishing attempts helpful? - http:\/\/t.co\/BU3yz9ME",
  "id" : 196943383720239105,
  "in_reply_to_status_id" : 196916808094203904,
  "created_at" : "2012-04-30 12:45:36 +0000",
  "in_reply_to_screen_name" : "ElindaGjondedaj",
  "in_reply_to_user_id_str" : "72877592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 87, 97 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ieENwCCN",
      "expanded_url" : "http:\/\/youtu.be\/NPQg2egMfBQ",
      "display_url" : "youtu.be\/NPQg2egMfBQ"
    } ]
  },
  "geo" : { },
  "id_str" : "196368171219943424",
  "text" : "Malalai Joya outlines some realities in Afghanistan http:\/\/t.co\/ieENwCCN\nHT Plus Ultra @medialens",
  "id" : 196368171219943424,
  "created_at" : "2012-04-28 22:39:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.netvibes.com\/\" rel=\"nofollow\"\u003ENetvibes Widget (deprecated)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Fhk656Jt",
      "expanded_url" : "http:\/\/www.globalresearch.ca\/index.php?context=va&aid=30533",
      "display_url" : "globalresearch.ca\/index.php?cont\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195826913523150848",
  "text" : "Info\/context about student strikes in Canada http:\/\/t.co\/Fhk656Jt",
  "id" : 195826913523150848,
  "created_at" : "2012-04-27 10:49:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 0, 15 ],
      "id_str" : "944237276",
      "id" : 944237276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195584506483310594",
  "in_reply_to_user_id" : 236921161,
  "text" : "@brad5patterson raises the webinar stakes by broadcasting from a car, taking a break from surfing!",
  "id" : 195584506483310594,
  "created_at" : "2012-04-26 18:45:54 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonia Clare",
      "screen_name" : "antoniaclare",
      "indices" : [ 0, 13 ],
      "id_str" : "135882693",
      "id" : 135882693
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 14, 22 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 23, 31 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 32, 48 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195544704664879104",
  "geo" : { },
  "id_str" : "195550674933653504",
  "in_reply_to_user_id" : 135882693,
  "text" : "@antoniaclare @cgoodey @seburnt @RebuffetBroadus unfortunately i only caught the very end, will look out for recording link.",
  "id" : 195550674933653504,
  "in_reply_to_status_id" : 195544704664879104,
  "created_at" : "2012-04-26 16:31:28 +0000",
  "in_reply_to_screen_name" : "antoniaclare",
  "in_reply_to_user_id_str" : "135882693",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "EFL",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/QZ2dr5S0",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2012\/04\/4-approach-challenge-or-attempt-to.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2012\/04\/4-appr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195546810608123905",
  "text" : "RT @kevchanwow: A new post on prying open my usually closed mind: http:\/\/t.co\/QZ2dr5S0 #ELT #ELTchat #EFL&lt;---a v interesting series brewing",
  "id" : 195546810608123905,
  "created_at" : "2012-04-26 16:16:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonia Clare",
      "screen_name" : "antoniaclare",
      "indices" : [ 18, 31 ],
      "id_str" : "135882693",
      "id" : 135882693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/LMwnerGn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=JoTmAX12DQk",
      "display_url" : "youtube.com\/watch?v=JoTmAX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195542697702989825",
  "text" : "great ELT song HT @antoniaclare http:\/\/t.co\/LMwnerGn",
  "id" : 195542697702989825,
  "created_at" : "2012-04-26 15:59:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NHS",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/txjEWgjL",
      "expanded_url" : "http:\/\/bit.ly\/InXEz0",
      "display_url" : "bit.ly\/InXEz0"
    } ]
  },
  "geo" : { },
  "id_str" : "195442365345955840",
  "text" : "RT @medialens: Media Alert: 'People Will Die\u2019 - The End Of The #NHS. Part 2: Buried By The BBC http:\/\/t.co\/txjEWgjL",
  "id" : 195442365345955840,
  "created_at" : "2012-04-26 09:21:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 14, 26 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195176128548311040",
  "geo" : { },
  "id_str" : "195177424886050817",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph @chadsansing nice! wld be interested in reading more about how u used it. a possible post?",
  "id" : 195177424886050817,
  "in_reply_to_status_id" : 195176128548311040,
  "created_at" : "2012-04-25 15:48:18 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/a7zdO4q7",
      "expanded_url" : "http:\/\/j.mp\/IBobdY",
      "display_url" : "j.mp\/IBobdY"
    } ]
  },
  "geo" : { },
  "id_str" : "195158437661908993",
  "text" : "RT @leoselivan: Have you tried Cruxbot ? - A web application to summarize web pages http:\/\/t.co\/a7zdO4q7&lt;--interesting web tool, thx",
  "id" : 195158437661908993,
  "created_at" : "2012-04-25 14:32:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 66, 81 ],
      "id_str" : "944237276",
      "id" : 944237276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/i6J1F4aM",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2012\/04\/pay-what-you-want\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194908645107044353",
  "text" : "'Pay What You Want' Works http:\/\/t.co\/i6J1F4aM &lt;--sure to make @brad5patterson smile",
  "id" : 194908645107044353,
  "created_at" : "2012-04-24 22:00:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/CXGRqcpr",
      "expanded_url" : "http:\/\/youtu.be\/_sUeGC-8dyk",
      "display_url" : "youtu.be\/_sUeGC-8dyk"
    } ]
  },
  "geo" : { },
  "id_str" : "194876437654802432",
  "text" : "my new model of a classroom\nhttp:\/\/t.co\/CXGRqcpr :)",
  "id" : 194876437654802432,
  "created_at" : "2012-04-24 19:52:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonia Clare",
      "screen_name" : "antoniaclare",
      "indices" : [ 0, 13 ],
      "id_str" : "135882693",
      "id" : 135882693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194697846883229696",
  "geo" : { },
  "id_str" : "194772005701156864",
  "in_reply_to_user_id" : 135882693,
  "text" : "@antoniaclare hi missed webinar on creativity, is there\/will there be a recording?",
  "id" : 194772005701156864,
  "in_reply_to_status_id" : 194697846883229696,
  "created_at" : "2012-04-24 12:57:19 +0000",
  "in_reply_to_screen_name" : "antoniaclare",
  "in_reply_to_user_id_str" : "135882693",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 43, 53 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/ecMqlaPM",
      "expanded_url" : "http:\/\/bit.ly\/I00L0o",
      "display_url" : "bit.ly\/I00L0o"
    } ]
  },
  "geo" : { },
  "id_str" : "194533201090318336",
  "text" : "\u2018People Will Die: The End Of The NHS.' via @MediaLens http:\/\/t.co\/ecMqlaPM",
  "id" : 194533201090318336,
  "created_at" : "2012-04-23 21:08:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194507540468473856",
  "geo" : { },
  "id_str" : "194507821373587456",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras excellent!",
  "id" : 194507821373587456,
  "in_reply_to_status_id" : 194507540468473856,
  "created_at" : "2012-04-23 19:27:33 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/WhgQag3r",
      "expanded_url" : "http:\/\/www.ipadforums.net\/ipad-os\/20566-emails-stuck-outbox-ios-4-2-1-a.html",
      "display_url" : "ipadforums.net\/ipad-os\/20566-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "194503884985737217",
  "geo" : { },
  "id_str" : "194505862352613378",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras read this? http:\/\/t.co\/WhgQag3r",
  "id" : 194505862352613378,
  "in_reply_to_status_id" : 194503884985737217,
  "created_at" : "2012-04-23 19:19:45 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 32, 43 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/AnT3cFJV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WbLAt2Hc7Rw",
      "display_url" : "youtube.com\/watch?v=WbLAt2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194502772052344833",
  "text" : "yes comp Qs just watching video @naomishema posted in cmmts on yr comp Q post http:\/\/t.co\/AnT3cFJV #eapchat",
  "id" : 194502772052344833,
  "created_at" : "2012-04-23 19:07:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194499161536729088",
  "text" : "have used sometimes comp questions inserted btw text para; and finding texts which nat lead to info gap is always grt #eapchat",
  "id" : 194499161536729088,
  "created_at" : "2012-04-23 18:53:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194497648835833857",
  "geo" : { },
  "id_str" : "194498191184494594",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt yes getting them to do it saves me time as well :) #eapchat",
  "id" : 194498191184494594,
  "in_reply_to_status_id" : 194497648835833857,
  "created_at" : "2012-04-23 18:49:17 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194497677801701377",
  "text" : "guess need to do more while reading tasks, that text you gave is grt example thx. #eapchat",
  "id" : 194497677801701377,
  "created_at" : "2012-04-23 18:47:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194497462046687232",
  "text" : "after reading - comprehension questions set by students is a fav as well #eapchat",
  "id" : 194497462046687232,
  "created_at" : "2012-04-23 18:46:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194495728301776896",
  "geo" : { },
  "id_str" : "194496363164217344",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt i think my 'raft' of good ideas to implement is titanic size :\/ #eapchat",
  "id" : 194496363164217344,
  "in_reply_to_status_id" : 194495728301776896,
  "created_at" : "2012-04-23 18:42:01 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194495764070805504",
  "text" : "re stratgey, mainly prediction tasks i guess for me and more recently discussion opportunities of text #eapchat",
  "id" : 194495764070805504,
  "created_at" : "2012-04-23 18:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194494858516381696",
  "geo" : { },
  "id_str" : "194495236121182209",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt definitely! along with a whole raft of other things i need to get round to doing! #eapchat",
  "id" : 194495236121182209,
  "in_reply_to_status_id" : 194494858516381696,
  "created_at" : "2012-04-23 18:37:32 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194494608338718720",
  "text" : "no similarities to ARC i.e.roles but would love to implement such a system  #eapchat",
  "id" : 194494608338718720,
  "created_at" : "2012-04-23 18:35:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194493298134614016",
  "text" : "lyrics are quite motivating for students, short form, interesting words etc #eapchat",
  "id" : 194493298134614016,
  "created_at" : "2012-04-23 18:29:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "hakan_sentrk",
      "indices" : [ 85, 98 ],
      "id_str" : "118198984",
      "id" : 118198984
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/rulDoM5o",
      "expanded_url" : "http:\/\/teach-me-tech.blogspot.fr\/search\/label\/prezi",
      "display_url" : "teach-me-tech.blogspot.fr\/search\/label\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194492236606603265",
  "text" : "re tools: prezi like tools useful for intensive reading e.g.\nhttp:\/\/t.co\/rulDoM5o by @hakan_sentrk  #eapchat",
  "id" : 194492236606603265,
  "created_at" : "2012-04-23 18:25:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194492017877852160",
  "text" : "most of my texts are from online; and updated as and when; sometimes get ss to find txt but not very often #eapchat",
  "id" : 194492017877852160,
  "created_at" : "2012-04-23 18:24:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194489949167423488",
  "text" : "the blog implementation of intensive reading is a grt idea, leveraging web tools #eapchat",
  "id" : 194489949167423488,
  "created_at" : "2012-04-23 18:16:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194489132901351424",
  "text" : "\/raises hand\/ #eapchat",
  "id" : 194489132901351424,
  "created_at" : "2012-04-23 18:13:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 0, 9 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194477346697388032",
  "geo" : { },
  "id_str" : "194482531322699776",
  "in_reply_to_user_id" : 130149739,
  "text" : "@jimscriv interesting fact on shard! shame a lot of todays corporate patrons of culture seem so mediocre & meanspirited.",
  "id" : 194482531322699776,
  "in_reply_to_status_id" : 194477346697388032,
  "created_at" : "2012-04-23 17:47:03 +0000",
  "in_reply_to_screen_name" : "jimscriv",
  "in_reply_to_user_id_str" : "130149739",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    }, {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 13, 22 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/sPqbk3i1",
      "expanded_url" : "http:\/\/www.placehacking.co.uk\/2012\/04\/07\/climbing-shard-glass\/",
      "display_url" : "placehacking.co.uk\/2012\/04\/07\/cli\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "194462031871623168",
  "geo" : { },
  "id_str" : "194475643205976064",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden @jimscriv creative physical trespassing e.g. http:\/\/t.co\/sPqbk3i1, creative brand trespassing a topic for the class?",
  "id" : 194475643205976064,
  "in_reply_to_status_id" : 194462031871623168,
  "created_at" : "2012-04-23 17:19:41 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194431530351865856",
  "geo" : { },
  "id_str" : "194472166404792320",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt thks for responses, certainly collectable in a post :) what were ss reactions to blog work? anything u wld do diff in future?",
  "id" : 194472166404792320,
  "in_reply_to_status_id" : 194431530351865856,
  "created_at" : "2012-04-23 17:05:52 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194422121445855232",
  "geo" : { },
  "id_str" : "194429783239692290",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns re VEEPS thx for heads up Armando Iannucci writing means quality laughs! d\/l now :)",
  "id" : 194429783239692290,
  "in_reply_to_status_id" : 194422121445855232,
  "created_at" : "2012-04-23 14:17:27 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194424658752307202",
  "geo" : { },
  "id_str" : "194425661035790336",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt  how many groups set up blog? easy\/difficlt to set up? how they co-ordinated writing? how did they revise txt? do anything diffrnt?",
  "id" : 194425661035790336,
  "in_reply_to_status_id" : 194424658752307202,
  "created_at" : "2012-04-23 14:01:04 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194424050922160129",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt your students blog is very impressive any plans to write a post on their experiences of setting it up and writing it?",
  "id" : 194424050922160129,
  "created_at" : "2012-04-23 13:54:40 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/194399121900187648\/photo\/1",
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/7i67N3ir",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArKk-K3CMAEhTkK.jpg",
      "id_str" : "194399121904381953",
      "id" : 194399121904381953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArKk-K3CMAEhTkK.jpg",
      "sizes" : [ {
        "h" : 822,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 532
      } ],
      "display_url" : "pic.twitter.com\/7i67N3ir"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/wIaOftT0",
      "expanded_url" : "http:\/\/perdre-la-raison.blogspot.fr\/2012\/04\/marine-le-pen-et-nicolas-sarkozy-en.html",
      "display_url" : "perdre-la-raison.blogspot.fr\/2012\/04\/marine\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194399121900187648",
  "text" : "The Kooples HT Neal via http:\/\/t.co\/wIaOftT0 http:\/\/t.co\/7i67N3ir",
  "id" : 194399121900187648,
  "created_at" : "2012-04-23 12:15:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 0, 11 ],
      "id_str" : "14387055",
      "id" : 14387055
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 21, 29 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194397426948386816",
  "in_reply_to_user_id" : 14387055,
  "text" : "@heikephilp hi again @seburnt #vrtwebcon recording link not activated?",
  "id" : 194397426948386816,
  "created_at" : "2012-04-23 12:08:52 +0000",
  "in_reply_to_screen_name" : "heikephilp",
  "in_reply_to_user_id_str" : "14387055",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 0, 15 ],
      "id_str" : "944237276",
      "id" : 944237276
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 67, 81 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193674632073707520",
  "geo" : { },
  "id_str" : "194392680455880704",
  "in_reply_to_user_id" : 236921161,
  "text" : "@brad5patterson that's great that u and yr team will be looking at @audreywatters edtech questions!",
  "id" : 194392680455880704,
  "in_reply_to_status_id" : 193674632073707520,
  "created_at" : "2012-04-23 11:50:01 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/4uP47Dlp",
      "expanded_url" : "http:\/\/lancelot.adobeconnect.com\/p82pagdprn0\/",
      "display_url" : "lancelot.adobeconnect.com\/p82pagdprn0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "194391673059545088",
  "text" : "@harrisonmike #vrtwebcon recording http:\/\/t.co\/4uP47Dlp&lt;--reminds us we don't only live in a visual culture #eltchat",
  "id" : 194391673059545088,
  "created_at" : "2012-04-23 11:46:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 0, 11 ],
      "id_str" : "14387055",
      "id" : 14387055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194385025632964609",
  "geo" : { },
  "id_str" : "194387910471073792",
  "in_reply_to_user_id" : 14387055,
  "text" : "@heikephilp hi, was there any activity on the Unconferences on Sunday?",
  "id" : 194387910471073792,
  "in_reply_to_status_id" : 194385025632964609,
  "created_at" : "2012-04-23 11:31:04 +0000",
  "in_reply_to_screen_name" : "heikephilp",
  "in_reply_to_user_id_str" : "14387055",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193808532817182722",
  "geo" : { },
  "id_str" : "194098726623645696",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hmm, subversive topic u say? how about teachers too interested in listening to lectures and playing x factor? ;)",
  "id" : 194098726623645696,
  "in_reply_to_status_id" : 193808532817182722,
  "created_at" : "2012-04-22 16:21:57 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193787170153172992",
  "geo" : { },
  "id_str" : "193787721079197696",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt ah right thought it was today! good luck if i don't catch u then!",
  "id" : 193787721079197696,
  "in_reply_to_status_id" : 193787170153172992,
  "created_at" : "2012-04-21 19:46:07 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193783947715547136",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt ru running on time for yr #vrtwebcon pres?",
  "id" : 193783947715547136,
  "created_at" : "2012-04-21 19:31:08 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193781657881423872",
  "geo" : { },
  "id_str" : "193782355750699010",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hmm shame maybe unconference may pick up on sunday?",
  "id" : 193782355750699010,
  "in_reply_to_status_id" : 193781657881423872,
  "created_at" : "2012-04-21 19:24:48 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193780912528424960",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan do u know what's going on or not with Unconference #vrtwebcon?",
  "id" : 193780912528424960,
  "created_at" : "2012-04-21 19:19:04 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "valueformoney",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/NEnmfJY2",
      "expanded_url" : "http:\/\/huff.to\/JdFEci",
      "display_url" : "huff.to\/JdFEci"
    } ]
  },
  "geo" : { },
  "id_str" : "193660191361871872",
  "text" : "Primary school pays 152 grand for a mention http:\/\/t.co\/NEnmfJY2 #valueformoney?",
  "id" : 193660191361871872,
  "created_at" : "2012-04-21 11:19:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/pyzKJLHV",
      "expanded_url" : "http:\/\/on.wsj.com\/I9SBX1",
      "display_url" : "on.wsj.com\/I9SBX1"
    } ]
  },
  "geo" : { },
  "id_str" : "193613169334300672",
  "text" : "MT @audreywatters: Nonsense on top of nonsense when used on NY state's standardized test http:\/\/t.co\/pyzKJLHV &lt;--standardized folly!",
  "id" : 193613169334300672,
  "created_at" : "2012-04-21 08:12:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/WM6lMw4P",
      "expanded_url" : "https:\/\/lancelot.adobeconnect.com\/_a875817169\/vrt4?launcher=false",
      "display_url" : "lancelot.adobeconnect.com\/_a875817169\/vr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193475565188157441",
  "text" : "https:\/\/t.co\/WM6lMw4P unconference #vrtwebcon discussing limitations on students digital literacy..;)",
  "id" : 193475565188157441,
  "created_at" : "2012-04-20 23:05:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/WM6lMw4P",
      "expanded_url" : "https:\/\/lancelot.adobeconnect.com\/_a875817169\/vrt4?launcher=false",
      "display_url" : "lancelot.adobeconnect.com\/_a875817169\/vr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193469596064432128",
  "text" : "https:\/\/t.co\/WM6lMw4P unconference #vrtwebcon, am only one in here!",
  "id" : 193469596064432128,
  "created_at" : "2012-04-20 22:42:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193467744157564930",
  "text" : "anyone doing unconference at #vrtwebcon?",
  "id" : 193467744157564930,
  "created_at" : "2012-04-20 22:34:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193334339344404480",
  "geo" : { },
  "id_str" : "193432784243662848",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB ah so made of cotton then :) i was just describing what i could see is all! they kinda looked edible though.",
  "id" : 193432784243662848,
  "in_reply_to_status_id" : 193334339344404480,
  "created_at" : "2012-04-20 20:15:44 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193292336862732289",
  "geo" : { },
  "id_str" : "193293029438799872",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow lkn thru tweets looks like yr hat and bio caused a bigger stir than post itself!",
  "id" : 193293029438799872,
  "in_reply_to_status_id" : 193292336862732289,
  "created_at" : "2012-04-20 11:00:24 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193291180644114432",
  "geo" : { },
  "id_str" : "193291670232633345",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB cotton stumped cream?",
  "id" : 193291670232633345,
  "in_reply_to_status_id" : 193291180644114432,
  "created_at" : "2012-04-20 10:55:00 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 24, 33 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 34, 50 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 51, 62 ],
      "id_str" : "228469472",
      "id" : 228469472
    }, {
      "name" : "Meltem \u0130PEK-\u00D6NER",
      "screen_name" : "mltmpk",
      "indices" : [ 63, 70 ],
      "id_str" : "276205109",
      "id" : 276205109
    }, {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 71, 78 ],
      "id_str" : "20324125",
      "id" : 20324125
    }, {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 79, 92 ],
      "id_str" : "29655018",
      "id" : 29655018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193277667691331584",
  "geo" : { },
  "id_str" : "193290419491180544",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @kevchanwow @Marisa_C @michaelegriffin @naomishema @mltmpk @hartle @ShellTerrell cheers hope you all have a great friday\/we #ff",
  "id" : 193290419491180544,
  "in_reply_to_status_id" : 193277667691331584,
  "created_at" : "2012-04-20 10:50:01 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Interactive",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193290027927748608",
  "text" : "ooh QTads just ported to OpenPandora #Interactive Fiction",
  "id" : 193290027927748608,
  "created_at" : "2012-04-20 10:48:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193017062124298241",
  "geo" : { },
  "id_str" : "193060748459651073",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph not much more u can do then i suppose?",
  "id" : 193060748459651073,
  "in_reply_to_status_id" : 193017062124298241,
  "created_at" : "2012-04-19 19:37:23 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193015697406820352",
  "geo" : { },
  "id_str" : "193016188350107650",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph in that case you could have a private word with student?",
  "id" : 193016188350107650,
  "in_reply_to_status_id" : 193015697406820352,
  "created_at" : "2012-04-19 16:40:20 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193014798156435456",
  "geo" : { },
  "id_str" : "193015349493510144",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph do they 'disrupt' class? if yes then upto teacher as how to deal.",
  "id" : 193015349493510144,
  "in_reply_to_status_id" : 193014798156435456,
  "created_at" : "2012-04-19 16:37:00 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193013584777854976",
  "geo" : { },
  "id_str" : "193013968569253889",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph an imrpovement on body odour? :) not being flippant any concern of the teachers?",
  "id" : 193013968569253889,
  "in_reply_to_status_id" : 193013584777854976,
  "created_at" : "2012-04-19 16:31:30 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 51, 62 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/3QTzaV1O",
      "expanded_url" : "http:\/\/www.paulgravett.com\/index.php\/articles\/article\/r._crumb1\/",
      "display_url" : "paulgravett.com\/index.php\/arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192984223341215744",
  "text" : "new Robert Crumb interview http:\/\/t.co\/3QTzaV1O HT @boingboing",
  "id" : 192984223341215744,
  "created_at" : "2012-04-19 14:33:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Sakamoto ",
      "screen_name" : "barbsaka",
      "indices" : [ 3, 12 ],
      "id_str" : "2970224781",
      "id" : 2970224781
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 47, 58 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 39, 43 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "jalt",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/73oSgkVm",
      "expanded_url" : "http:\/\/bit.ly\/J7Fwxz",
      "display_url" : "bit.ly\/J7Fwxz"
    } ]
  },
  "geo" : { },
  "id_str" : "192973763938230272",
  "text" : "MT @barbsaka: Grt pst abt using lit in #EFL by @kevchanwow \"Because we all love a good story!\" http:\/\/t.co\/73oSgkVm #eltchat #jalt&lt;--agreed!",
  "id" : 192973763938230272,
  "created_at" : "2012-04-19 13:51:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Banville",
      "screen_name" : "SeanBanville",
      "indices" : [ 3, 16 ],
      "id_str" : "32352423",
      "id" : 32352423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/eK70GPcc",
      "expanded_url" : "http:\/\/bit.ly\/IQZZlv",
      "display_url" : "bit.ly\/IQZZlv"
    } ]
  },
  "geo" : { },
  "id_str" : "192965078482563073",
  "text" : "MT @SeanBanville: \"UN wives ask Mrs Assad to stop Syria violence\" http:\/\/t.co\/eK70GPcc&lt;--Do u thnk mre thn +2+ambdrs wives shd take part?",
  "id" : 192965078482563073,
  "created_at" : "2012-04-19 13:17:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "edchat",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "esl",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "efl",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "tesol",
      "indices" : [ 118, 124 ]
    }, {
      "text" : "esol",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/2fItUAbD",
      "expanded_url" : "http:\/\/new.livestream.com\/live-ttt\/ttt293",
      "display_url" : "new.livestream.com\/live-ttt\/ttt293"
    } ]
  },
  "geo" : { },
  "id_str" : "192958157037907968",
  "text" : "Minecraft curious? see recorded session http:\/\/t.co\/2fItUAbD by Teachers Teaching Teachers #eltchat #edchat #esl #efl #tesol #esol",
  "id" : 192958157037907968,
  "created_at" : "2012-04-19 12:49:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Levin",
      "screen_name" : "MinecraftTeachr",
      "indices" : [ 82, 98 ],
      "id_str" : "266369226",
      "id" : 266369226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "edtech",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/2fItUAbD",
      "expanded_url" : "http:\/\/new.livestream.com\/live-ttt\/ttt293",
      "display_url" : "new.livestream.com\/live-ttt\/ttt293"
    } ]
  },
  "geo" : { },
  "id_str" : "192776815817928704",
  "text" : "interested in Minecraft? watch live webcast http:\/\/t.co\/2fItUAbD #eltchat #edtech @MinecraftTeachr",
  "id" : 192776815817928704,
  "created_at" : "2012-04-19 00:49:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192712662927425536",
  "text" : "intersted in strangest comments from obsvs? mine - body posture, don't hunch yr shoulders! :) #eltchat",
  "id" : 192712662927425536,
  "created_at" : "2012-04-18 20:34:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humblebrag",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/MJtCXT0E",
      "expanded_url" : "http:\/\/www.grantland.com\/story\/_\/id\/7825801\/tyler-creator-rest-april-humblebrag--",
      "display_url" : "grantland.com\/story\/_\/id\/782\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192651919494352896",
  "text" : "MT @michaelegriffin: Ohh #humblebrag \nhttp:\/\/t.co\/MJtCXT0E&gt;\"This is like a Larry David complaint, but the rapper version.\"&lt;--great line!",
  "id" : 192651919494352896,
  "created_at" : "2012-04-18 16:32:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/HtyYNYxD",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2012\/4\/17\/163255\/758",
      "display_url" : "eurotrib.com\/story\/2012\/4\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192638526578364416",
  "text" : "Sarkozy Danse Macabre http:\/\/t.co\/HtyYNYxD",
  "id" : 192638526578364416,
  "created_at" : "2012-04-18 15:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 12, 22 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 23, 39 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192274809265209345",
  "geo" : { },
  "id_str" : "192275767617536000",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @JosetteLB @michaelegriffin too cold for t-shirts today :( playing rnd flashing new rom on phone atm will post pic after.",
  "id" : 192275767617536000,
  "in_reply_to_status_id" : 192274809265209345,
  "created_at" : "2012-04-17 15:38:09 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 12, 22 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 23, 39 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192273893455699969",
  "geo" : { },
  "id_str" : "192274520940351488",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @JosetteLB @michaelegriffin sorry to but in, just to let u know you are the best triple act on ELT twitter :) keep up gd wk!",
  "id" : 192274520940351488,
  "in_reply_to_status_id" : 192273893455699969,
  "created_at" : "2012-04-17 15:33:12 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Ih1ej9iM",
      "expanded_url" : "http:\/\/youtu.be\/Z3Uv6bfL5lQ",
      "display_url" : "youtu.be\/Z3Uv6bfL5lQ"
    } ]
  },
  "geo" : { },
  "id_str" : "192249139172605952",
  "text" : "oath of allegiance - had to check world clock to confirm am living in 21st century http:\/\/t.co\/Ih1ej9iM",
  "id" : 192249139172605952,
  "created_at" : "2012-04-17 13:52:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/AQCY0kWx",
      "expanded_url" : "http:\/\/bit.ly\/HZHcbA",
      "display_url" : "bit.ly\/HZHcbA"
    } ]
  },
  "geo" : { },
  "id_str" : "192239980754649089",
  "text" : "MT @chadsansing: pretty sweet media\/despotism\/propaganda game http:\/\/t.co\/AQCY0kWx &lt;--has critical thinking possibilites #eltchat",
  "id" : 192239980754649089,
  "created_at" : "2012-04-17 13:15:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Levin",
      "screen_name" : "MinecraftTeachr",
      "indices" : [ 3, 19 ],
      "id_str" : "266369226",
      "id" : 266369226
    }, {
      "name" : "Liam O'Donnell",
      "screen_name" : "liamodonnell",
      "indices" : [ 20, 33 ],
      "id_str" : "12730992",
      "id" : 12730992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Minecraft",
      "indices" : [ 62, 72 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/ISG4b2bf",
      "expanded_url" : "http:\/\/bit.ly\/ISp5ow",
      "display_url" : "bit.ly\/ISp5ow"
    } ]
  },
  "geo" : { },
  "id_str" : "192219403973181440",
  "text" : "MT @MinecraftTeachr @liamodonnell: \"Teachers Guide: Five ways #Minecraft can boost student writing skills\" http:\/\/t.co\/ISG4b2bf #eltchat",
  "id" : 192219403973181440,
  "created_at" : "2012-04-17 11:54:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blythe Musteric",
      "screen_name" : "Blythe_Musteric",
      "indices" : [ 0, 16 ],
      "id_str" : "41420245",
      "id" : 41420245
    }, {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "indices" : [ 17, 28 ],
      "id_str" : "13498092",
      "id" : 13498092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "untesol",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191784808144314368",
  "geo" : { },
  "id_str" : "191821392000458753",
  "in_reply_to_user_id" : 41420245,
  "text" : "@Blythe_Musteric @rogerdupuy me too! #untesol",
  "id" : 191821392000458753,
  "in_reply_to_status_id" : 191784808144314368,
  "created_at" : "2012-04-16 09:32:38 +0000",
  "in_reply_to_screen_name" : "Blythe_Musteric",
  "in_reply_to_user_id_str" : "41420245",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191663432175599616",
  "geo" : { },
  "id_str" : "191821154149863424",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt may11 so can happen anytime now till then!",
  "id" : 191821154149863424,
  "in_reply_to_status_id" : 191663432175599616,
  "created_at" : "2012-04-16 09:31:41 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191621413885587456",
  "geo" : { },
  "id_str" : "191624099573923840",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph great, commented on a post, there will still be anti-spam measures so don't worry!",
  "id" : 191624099573923840,
  "in_reply_to_status_id" : 191621413885587456,
  "created_at" : "2012-04-15 20:28:40 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Whiteside",
      "screen_name" : "nutrich",
      "indices" : [ 3, 11 ],
      "id_str" : "95495064",
      "id" : 95495064
    }, {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "indices" : [ 63, 74 ],
      "id_str" : "13498092",
      "id" : 13498092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/MErBaXtb",
      "expanded_url" : "http:\/\/post.ly\/6NLNt",
      "display_url" : "post.ly\/6NLNt"
    } ]
  },
  "geo" : { },
  "id_str" : "191615594234249216",
  "text" : "MT @nutrich: The Speaker-less Session http:\/\/t.co\/MErBaXtb via @rogerdupuy &lt;--a groundswell building amongst edu bloggers",
  "id" : 191615594234249216,
  "created_at" : "2012-04-15 19:54:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Stults",
      "screen_name" : "JustinStults",
      "indices" : [ 0, 13 ],
      "id_str" : "294217312",
      "id" : 294217312
    }, {
      "name" : "Xanthe",
      "screen_name" : "xanlan",
      "indices" : [ 14, 21 ],
      "id_str" : "39527659",
      "id" : 39527659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/aOs8Uu9A",
      "expanded_url" : "http:\/\/youtu.be\/rIABo0d9MVE",
      "display_url" : "youtu.be\/rIABo0d9MVE"
    } ]
  },
  "geo" : { },
  "id_str" : "191578279352872961",
  "in_reply_to_user_id" : 294217312,
  "text" : "@JustinStults @xanlan Every presentation ever http:\/\/t.co\/aOs8Uu9A&lt;--might find it useful in yr presentation course",
  "id" : 191578279352872961,
  "created_at" : "2012-04-15 17:26:35 +0000",
  "in_reply_to_screen_name" : "JustinStults",
  "in_reply_to_user_id_str" : "294217312",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 12, 20 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191566747021754369",
  "geo" : { },
  "id_str" : "191567561425551360",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @seburnt wow another reason to attend! hoping my soon to be born son will allow me time off for the conference!",
  "id" : 191567561425551360,
  "in_reply_to_status_id" : 191566747021754369,
  "created_at" : "2012-04-15 16:44:00 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191563165333594112",
  "geo" : { },
  "id_str" : "191565069337903104",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt sweet, if u r giving a talk i will make a big effort to attend!!",
  "id" : 191565069337903104,
  "in_reply_to_status_id" : 191563165333594112,
  "created_at" : "2012-04-15 16:34:06 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191543829353070595",
  "geo" : { },
  "id_str" : "191563028230193153",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt great, on holiday\/business, both? in paris?",
  "id" : 191563028230193153,
  "in_reply_to_status_id" : 191543829353070595,
  "created_at" : "2012-04-15 16:25:59 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/vnYF4GGF",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2012\/4\/13\/111751\/205",
      "display_url" : "eurotrib.com\/story\/2012\/4\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191521592868741120",
  "text" : "Austerity Kills http:\/\/t.co\/vnYF4GGF",
  "id" : 191521592868741120,
  "created_at" : "2012-04-15 13:41:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 25, 36 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/U5mvnQCx",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/04\/14\/g20-hacker-cops-dig-up-back-y.html",
      "display_url" : "boingboing.net\/2012\/04\/14\/g20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191490405651587073",
  "text" : "http:\/\/t.co\/U5mvnQCx via @BoingBoing&lt;--very definition of showtrial",
  "id" : 191490405651587073,
  "created_at" : "2012-04-15 11:37:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191410395297218560",
  "geo" : { },
  "id_str" : "191463474289848321",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt yes i am in france! i have a lot of relatives in toronto :)",
  "id" : 191463474289848321,
  "in_reply_to_status_id" : 191410395297218560,
  "created_at" : "2012-04-15 09:50:24 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/OCf3ilVY",
      "expanded_url" : "http:\/\/www.litopia.com\/radio\/our-man-in-the-cold\/",
      "display_url" : "litopia.com\/radio\/our-man-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191351422065967104",
  "text" : "\"he sd it's like playn a vid gme - when u walk into foreign office \nthere r [Iraqi WMDs]\"&lt;-put [ ] wit bogeyman du jour http:\/\/t.co\/OCf3ilVY",
  "id" : 191351422065967104,
  "created_at" : "2012-04-15 02:25:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191282105563611138",
  "geo" : { },
  "id_str" : "191285330253586433",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol grt thks dm sent",
  "id" : 191285330253586433,
  "in_reply_to_status_id" : 191282105563611138,
  "created_at" : "2012-04-14 22:02:31 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191279474791288833",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol hi i was at yr talk today and trying fnd burcu akyol plagiarism post u mentioned? unfort no search tool on her site. thx!",
  "id" : 191279474791288833,
  "created_at" : "2012-04-14 21:39:15 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191270520128405507",
  "geo" : { },
  "id_str" : "191271109595897856",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt ah i thought it had already started!",
  "id" : 191271109595897856,
  "in_reply_to_status_id" : 191270520128405507,
  "created_at" : "2012-04-14 21:06:00 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191267383741120512",
  "geo" : { },
  "id_str" : "191268328982056960",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hmm so shall i begin what all then?",
  "id" : 191268328982056960,
  "in_reply_to_status_id" : 191267383741120512,
  "created_at" : "2012-04-14 20:54:57 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191266163655835648",
  "geo" : { },
  "id_str" : "191267240522424320",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt is that a song line? :\/",
  "id" : 191267240522424320,
  "in_reply_to_status_id" : 191266163655835648,
  "created_at" : "2012-04-14 20:50:38 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "esp",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "eap",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/MsF8Xyfs",
      "expanded_url" : "http:\/\/fourc.ca\/lectures\/",
      "display_url" : "fourc.ca\/lectures\/"
    } ]
  },
  "geo" : { },
  "id_str" : "191265739116777472",
  "text" : "MT @seburnt: The disconnect between students and content lectures http:\/\/t.co\/MsF8Xyfs #eltchat #esp #eap&lt;-- a needed initiative",
  "id" : 191265739116777472,
  "created_at" : "2012-04-14 20:44:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190794848570314752",
  "geo" : { },
  "id_str" : "190812133599088641",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow i dictated story twice (after showing a wordle image of it) once just to listen&react, 2nd to note numbers,held their attn well!",
  "id" : 190812133599088641,
  "in_reply_to_status_id" : 190794848570314752,
  "created_at" : "2012-04-13 14:42:12 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 59, 71 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/ZzpyNLOr",
      "expanded_url" : "http:\/\/soundcloud.com\/platformlondon-1",
      "display_url" : "soundcloud.com\/platformlondon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190447565739794432",
  "text" : "some great critical thinking audio http:\/\/t.co\/ZzpyNLOr HT @theregister",
  "id" : 190447565739794432,
  "created_at" : "2012-04-12 14:33:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elmira Merve Oflaz",
      "screen_name" : "oflazmerve",
      "indices" : [ 0, 11 ],
      "id_str" : "263866847",
      "id" : 263866847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190432855871078401",
  "in_reply_to_user_id" : 263866847,
  "text" : "@oflazmerve retweet much appreciated!",
  "id" : 190432855871078401,
  "created_at" : "2012-04-12 13:35:05 +0000",
  "in_reply_to_screen_name" : "oflazmerve",
  "in_reply_to_user_id_str" : "263866847",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 97, 106 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "esol",
      "indices" : [ 75, 80 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/6ljdz2lr",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-2g",
      "display_url" : "wp.me\/p2e2Wf-2g"
    } ]
  },
  "geo" : { },
  "id_str" : "190432567252627456",
  "text" : "RT @teflerinha: Creating effective reading tasks http:\/\/t.co\/6ljdz2lr #elt #esol&lt;--great tips @tejucole #eltchat",
  "id" : 190432567252627456,
  "created_at" : "2012-04-12 13:33:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 0, 10 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190430280832655360",
  "geo" : { },
  "id_str" : "190432052573765632",
  "in_reply_to_user_id" : 34347535,
  "text" : "@StanCarey wow, another layer to the passage.",
  "id" : 190432052573765632,
  "in_reply_to_status_id" : 190430280832655360,
  "created_at" : "2012-04-12 13:31:54 +0000",
  "in_reply_to_screen_name" : "StanCarey",
  "in_reply_to_user_id_str" : "34347535",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 3, 13 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Zmvv0Sfv",
      "expanded_url" : "http:\/\/bit.ly\/HtYc81",
      "display_url" : "bit.ly\/HtYc81"
    } ]
  },
  "geo" : { },
  "id_str" : "190427952582893568",
  "text" : "RT @StanCarey: Wild kids on the black road http:\/\/t.co\/Zmvv0Sfv (a short passage by Daniel Woodrell) #books&lt;--powerful passage! #eltchat",
  "id" : 190427952582893568,
  "created_at" : "2012-04-12 13:15:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190121579844349952",
  "geo" : { },
  "id_str" : "190195160498438145",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheers for RT on edu conferences! hopefully the groundswell in twitterverse and interwebs amongst educators can mve things!",
  "id" : 190195160498438145,
  "in_reply_to_status_id" : 190121579844349952,
  "created_at" : "2012-04-11 21:50:34 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 12, 24 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 25, 38 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190079095458119680",
  "geo" : { },
  "id_str" : "190107084153565184",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @sandymillin @aClilToClimb glad to help! added a reply to yr comment.",
  "id" : 190107084153565184,
  "in_reply_to_status_id" : 190079095458119680,
  "created_at" : "2012-04-11 16:00:35 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190029109827616768",
  "text" : "plagiarism, copyright, publishers; 3 of a kind ELT blog posts in the space of 3 days? what's going on? boogles the mind! #eltchat",
  "id" : 190029109827616768,
  "created_at" : "2012-04-11 10:50:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "elt",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "esl",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "tesol",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "efl",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/2kNbx05W",
      "expanded_url" : "http:\/\/bit.ly\/Iq0Jjd",
      "display_url" : "bit.ly\/Iq0Jjd"
    } ]
  },
  "geo" : { },
  "id_str" : "190023208970354688",
  "text" : "RT @audreywatters: On Educational Data Mining http:\/\/t.co\/2kNbx05W #eltchat #eapchat #elt #esl #tesol #efl",
  "id" : 190023208970354688,
  "created_at" : "2012-04-11 10:27:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 3, 15 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/wtcJb3cc",
      "expanded_url" : "http:\/\/wp.me\/p18yiK-n5",
      "display_url" : "wp.me\/p18yiK-n5"
    } ]
  },
  "geo" : { },
  "id_str" : "190015876815257603",
  "text" : "RT @sandymillin: Giant noughts and crosses http:\/\/t.co\/wtcJb3cc #eltchat&lt;--nice game for TOEIC thx!",
  "id" : 190015876815257603,
  "created_at" : "2012-04-11 09:58:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189828944621617155",
  "text" : "plagiarism, copyright, publishers; 3 of a kind ELT blog posts in the space of 3 days? what's going on? boogles the mind!",
  "id" : 189828944621617155,
  "created_at" : "2012-04-10 21:35:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/189825841495158786\/photo\/1",
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/dcAILeER",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqJlmNvCMAAhoY-.jpg",
      "id_str" : "189825841499353088",
      "id" : 189825841499353088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqJlmNvCMAAhoY-.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 416
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 416
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 416
      } ],
      "display_url" : "pic.twitter.com\/dcAILeER"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189825841495158786",
  "text" : "some pre London Olympics Inoculation ;) http:\/\/t.co\/dcAILeER",
  "id" : 189825841495158786,
  "created_at" : "2012-04-10 21:23:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 87, 98 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/yOkIZnwQ",
      "expanded_url" : "http:\/\/www.postsecret.com\/",
      "display_url" : "postsecret.com"
    } ]
  },
  "geo" : { },
  "id_str" : "189815064998576128",
  "text" : "hmm these secret postcards could liven up TOEIC exam classes.. http:\/\/t.co\/yOkIZnwQ HT @boingboing",
  "id" : 189815064998576128,
  "created_at" : "2012-04-10 20:40:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 3, 12 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 71, 75 ]
    }, {
      "text" : "eltcaht",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "YLEng",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "YLsig",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/U8pNEcVX",
      "expanded_url" : "http:\/\/wp.me\/p1WVfI-23",
      "display_url" : "wp.me\/p1WVfI-23"
    } ]
  },
  "geo" : { },
  "id_str" : "189689766479015936",
  "text" : "RT @vmorgana: Multi-word verbs and young learners http:\/\/t.co\/U8pNEcVX #elt #eltcaht #YLEng  #YLsig&lt;--interesting read, one to bkmrk!",
  "id" : 189689766479015936,
  "created_at" : "2012-04-10 12:22:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189651338202857472",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph can you enable anonymous posting on your blog? ta!",
  "id" : 189651338202857472,
  "created_at" : "2012-04-10 09:49:37 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 62, 71 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "indices" : [ 72, 84 ],
      "id_str" : "30663558",
      "id" : 30663558
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 85, 98 ],
      "id_str" : "39718253",
      "id" : 39718253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/QyjYkS1Y",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7y",
      "display_url" : "wp.me\/pgHyE-7y"
    } ]
  },
  "geo" : { },
  "id_str" : "189465066838573056",
  "text" : "please make it stop,another #iatefl post http:\/\/t.co\/QyjYkS1Y @chiasuan @lclandfield @LukeMeddings at robert o'neill (if he was on twitter)",
  "id" : 189465066838573056,
  "created_at" : "2012-04-09 21:29:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/G5WJwqDX",
      "expanded_url" : "http:\/\/bit.ly\/Icd0vd",
      "display_url" : "bit.ly\/Icd0vd"
    } ]
  },
  "geo" : { },
  "id_str" : "189451097885253632",
  "text" : "MT @yearinthelifeof: TEFLTastic Alex: A London summer school with no classroom http:\/\/t.co\/G5WJwqDX&lt;--fab idea!",
  "id" : 189451097885253632,
  "created_at" : "2012-04-09 20:33:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 12, 24 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 25, 38 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/BU3yz9ME",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "in_reply_to_status_id_str" : "189439979217367041",
  "geo" : { },
  "id_str" : "189441786064801792",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @sandymillin @aClilToClimb in addition to viruses a lot of phishing on twitter recently, some tips here http:\/\/t.co\/BU3yz9ME",
  "id" : 189441786064801792,
  "in_reply_to_status_id" : 189439979217367041,
  "created_at" : "2012-04-09 19:56:56 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/QyjYkS1Y",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7y",
      "display_url" : "wp.me\/pgHyE-7y"
    } ]
  },
  "geo" : { },
  "id_str" : "189414895832408064",
  "text" : "Can u help me add to my #iatefl 3?http:\/\/t.co\/QyjYkS1Y #eltchat",
  "id" : 189414895832408064,
  "created_at" : "2012-04-09 18:10:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189412882562293760",
  "text" : "cheers folks! #eapchat",
  "id" : 189412882562293760,
  "created_at" : "2012-04-09 18:02:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189411063740112896",
  "text" : "here too, in fact wasn't sure what 5 para essay was to start with! :) #eapchat",
  "id" : 189411063740112896,
  "created_at" : "2012-04-09 17:54:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189407436917051392",
  "text" : "as @yearinthelifeof has already said models need to be adapted to writing required so is 5 para essay flexible enough? #eapchat",
  "id" : 189407436917051392,
  "created_at" : "2012-04-09 17:40:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189406221692964864",
  "text" : "i have labelled all my graphs, i have numbered all my figures etc #eapchat",
  "id" : 189406221692964864,
  "created_at" : "2012-04-09 17:35:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189405819996090368",
  "text" : "have only done technical report writing so chklist may say - i have listed all my refs, i have not used personal pronouns, etc #eapchat",
  "id" : 189405819996090368,
  "created_at" : "2012-04-09 17:34:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Bunea",
      "screen_name" : "DanielaArghir",
      "indices" : [ 0, 14 ],
      "id_str" : "116991118",
      "id" : 116991118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189402159761211392",
  "geo" : { },
  "id_str" : "189403394291679233",
  "in_reply_to_user_id" : 116991118,
  "text" : "@DanielaArghir agreed checklists are a good first step in getting Ss to recognise, how to get them to produce? #eapchat",
  "id" : 189403394291679233,
  "in_reply_to_status_id" : 189402159761211392,
  "created_at" : "2012-04-09 17:24:22 +0000",
  "in_reply_to_screen_name" : "DanielaArghir",
  "in_reply_to_user_id_str" : "116991118",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189402360974544896",
  "text" : "what non-English organisational writing diffs are there? e.g commonly seen in French writing is 'long' sentences... #eapchat",
  "id" : 189402360974544896,
  "created_at" : "2012-04-09 17:20:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189401664598458369",
  "text" : "MT @yearinthelifeof:5 parag essay is that it only exists in how to write classes. Few actual ass My maignments follow this model #eapchat",
  "id" : 189401664598458369,
  "created_at" : "2012-04-09 17:17:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189401407407919104",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott has a good recent post about writing genre #eapchat",
  "id" : 189401407407919104,
  "created_at" : "2012-04-09 17:16:29 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189400823661477889",
  "text" : "related problem of giving them clear models of referencing #eapchat",
  "id" : 189400823661477889,
  "created_at" : "2012-04-09 17:14:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189398934928625664",
  "text" : "what i find difficult is not getting students to organise their writing but to stop them plagiarising! #eapchat",
  "id" : 189398934928625664,
  "created_at" : "2012-04-09 17:06:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189398606300712960",
  "text" : "yes models are good for low levels #eapchat",
  "id" : 189398606300712960,
  "created_at" : "2012-04-09 17:05:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189397911434567680",
  "text" : "so what is the 5 para essay?\n #eapchat",
  "id" : 189397911434567680,
  "created_at" : "2012-04-09 17:02:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/ZkSgl09y",
      "expanded_url" : "http:\/\/www.academicwords.info\/",
      "display_url" : "academicwords.info"
    } ]
  },
  "geo" : { },
  "id_str" : "189387455114379265",
  "text" : "RT @thornburyscott: Brand new Academic Word Lists (based on COCA) from BYU: http:\/\/t.co\/ZkSgl09y",
  "id" : 189387455114379265,
  "created_at" : "2012-04-09 16:21:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/aw3LNs7Z",
      "expanded_url" : "http:\/\/c4lpt.co.uk\/directory-of-learning-performance-tools\/",
      "display_url" : "c4lpt.co.uk\/directory-of-l\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "189324910198390785",
  "geo" : { },
  "id_str" : "189326270197272576",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB i got that link from this very handy directory of online tools http:\/\/t.co\/aw3LNs7Z",
  "id" : 189326270197272576,
  "in_reply_to_status_id" : 189324910198390785,
  "created_at" : "2012-04-09 12:17:54 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/h3KhEIHp",
      "expanded_url" : "http:\/\/www.memidex.com\/",
      "display_url" : "memidex.com"
    } ]
  },
  "in_reply_to_status_id_str" : "189318809151221760",
  "geo" : { },
  "id_str" : "189322547165278208",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB habe u tried http:\/\/t.co\/h3KhEIHp? is very fast dictionary\/thesaurus",
  "id" : 189322547165278208,
  "in_reply_to_status_id" : 189318809151221760,
  "created_at" : "2012-04-09 12:03:07 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/CZkGfznr",
      "expanded_url" : "http:\/\/www.placehacking.co.uk\/",
      "display_url" : "placehacking.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "189298360186970112",
  "text" : "Place Hacking http:\/\/t.co\/CZkGfznr&lt;--amazing vignettes from meatspace infrastructure!",
  "id" : 189298360186970112,
  "created_at" : "2012-04-09 10:27:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 3, 17 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ltsig",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/aw3LNs7Z",
      "expanded_url" : "http:\/\/c4lpt.co.uk\/directory-of-learning-performance-tools\/",
      "display_url" : "c4lpt.co.uk\/directory-of-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189295392641384448",
  "text" : "RT @grahamstanley: Over 2,000 tools for learning and working in education http:\/\/t.co\/aw3LNs7Z #ltsig &lt;--woah what a directory!",
  "id" : 189295392641384448,
  "created_at" : "2012-04-09 10:15:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "ELT",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/fARyPEkJ",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2012\/04\/measurements-short-story-for-ells.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2012\/04\/measur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189290066034696192",
  "text" : "MT @kevchanwow: Measurements.  A short story for ELLs. http:\/\/t.co\/fARyPEkJ #ELTchat #ELT&lt;---pound for pound one of kevin's best",
  "id" : 189290066034696192,
  "created_at" : "2012-04-09 09:54:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 34, 49 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/rlAr3Ec9",
      "expanded_url" : "http:\/\/youtu.be\/lp8QSGcS0QI",
      "display_url" : "youtu.be\/lp8QSGcS0QI"
    } ]
  },
  "geo" : { },
  "id_str" : "189138044463489025",
  "text" : "just seen http:\/\/t.co\/rlAr3Ec9 by @thornburyscott &lt;--nice overview of some theories of grammer",
  "id" : 189138044463489025,
  "created_at" : "2012-04-08 23:49:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189075191610097664",
  "geo" : { },
  "id_str" : "189077540231577600",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan one time my wife started to play hit me in frustration during her writers block, kinda helped! :)",
  "id" : 189077540231577600,
  "in_reply_to_status_id" : 189075191610097664,
  "created_at" : "2012-04-08 19:49:33 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/pztbCl3v",
      "expanded_url" : "http:\/\/fourc.ca\/eapchat\/",
      "display_url" : "fourc.ca\/eapchat\/"
    } ]
  },
  "geo" : { },
  "id_str" : "189043636158205953",
  "text" : "RT @seburnt: Monday, April 9 #EAPchat topic: The pros and cons of the 5-paragraph essay model http:\/\/t.co\/pztbCl3v",
  "id" : 189043636158205953,
  "created_at" : "2012-04-08 17:34:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/lGhiVdNv",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1333886019.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189025943615049728",
  "text" : "To the 'Liberal' commentariat Galloway is Orwell's 'memory hole' made flesh.- http:\/\/t.co\/lGhiVdNv",
  "id" : 189025943615049728,
  "created_at" : "2012-04-08 16:24:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/TrqUdUdS",
      "expanded_url" : "http:\/\/ti.me\/wEwnn5",
      "display_url" : "ti.me\/wEwnn5"
    } ]
  },
  "geo" : { },
  "id_str" : "189017657851379712",
  "text" : "Kids Who Use Facebook Do Worse in School http:\/\/t.co\/TrqUdUdS&lt;--i like idea of 1min tech breaks",
  "id" : 189017657851379712,
  "created_at" : "2012-04-08 15:51:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 12, 22 ],
      "id_str" : "102353142",
      "id" : 102353142
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 128, 139 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188960602633412609",
  "geo" : { },
  "id_str" : "188961531814359040",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @willycard true also there seems to be awareness that something is not right about communicative approach e.g. read @hughdellar",
  "id" : 188961531814359040,
  "in_reply_to_status_id" : 188960602633412609,
  "created_at" : "2012-04-08 12:08:34 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Barbara Sakamoto ",
      "screen_name" : "barbsaka",
      "indices" : [ 12, 21 ],
      "id_str" : "2970224781",
      "id" : 2970224781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188959755195269120",
  "geo" : { },
  "id_str" : "188960387427860480",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @barbsaka to me what's even more interesting is how can we OWN our data? how can we wrest it back from Google et al?",
  "id" : 188960387427860480,
  "in_reply_to_status_id" : 188959755195269120,
  "created_at" : "2012-04-08 12:04:01 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    }, {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 101, 110 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188957550190931969",
  "geo" : { },
  "id_str" : "188959019145248768",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard looks like u don't agree!? :) thera are some pertinent questions on their blog, hopefully @jimscriv and underhill will reply",
  "id" : 188959019145248768,
  "in_reply_to_status_id" : 188957550190931969,
  "created_at" : "2012-04-08 11:58:35 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Williams",
      "screen_name" : "donaldthesane",
      "indices" : [ 3, 17 ],
      "id_str" : "370274508",
      "id" : 370274508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/FC25ejLJ",
      "expanded_url" : "http:\/\/wp.me\/p1jA0y-cK",
      "display_url" : "wp.me\/p1jA0y-cK"
    } ]
  },
  "geo" : { },
  "id_str" : "188957721243029504",
  "text" : "RT @donaldthesane: Bunny Rabbits & Chocolate http:\/\/t.co\/FC25ejLJ &lt;--Bill Hicks sorely missed!",
  "id" : 188957721243029504,
  "created_at" : "2012-04-08 11:53:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188955589110546432",
  "in_reply_to_user_id" : 421819983,
  "text" : "@DariusPercy have you been phished?",
  "id" : 188955589110546432,
  "created_at" : "2012-04-08 11:44:57 +0000",
  "in_reply_to_screen_name" : "GoodGrammarGuy",
  "in_reply_to_user_id_str" : "421819983",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188951710440501248",
  "geo" : { },
  "id_str" : "188952075726622720",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin ah right wow every word! cor blimey!",
  "id" : 188952075726622720,
  "in_reply_to_status_id" : 188951710440501248,
  "created_at" : "2012-04-08 11:31:00 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188950275220979713",
  "geo" : { },
  "id_str" : "188950997870198784",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin it's a bit down the post : ...you...predict what students might say in response to the task.",
  "id" : 188950997870198784,
  "in_reply_to_status_id" : 188950275220979713,
  "created_at" : "2012-04-08 11:26:43 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 3, 14 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "IH Roma - Manzoni",
      "screen_name" : "IHRoma",
      "indices" : [ 32, 39 ],
      "id_str" : "419460697",
      "id" : 419460697
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "elt",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/7G0iSMUu",
      "expanded_url" : "http:\/\/bit.ly\/Hs51HS",
      "display_url" : "bit.ly\/Hs51HS"
    } ]
  },
  "geo" : { },
  "id_str" : "188948913221414913",
  "text" : "MT @steve_muir: @leoselivan: RT @IHRoma: Great resource for lexically-minded teachers  http:\/\/t.co\/7G0iSMUu #eltchat #elt &lt;--agreed!",
  "id" : 188948913221414913,
  "created_at" : "2012-04-08 11:18:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 3, 14 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "Don Williams",
      "screen_name" : "donaldthesane",
      "indices" : [ 76, 90 ],
      "id_str" : "370274508",
      "id" : 370274508
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 119, 128 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/aqQ1mrmT",
      "expanded_url" : "http:\/\/bit.ly\/HoBMIS",
      "display_url" : "bit.ly\/HoBMIS"
    }, {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/rhXot2i6",
      "expanded_url" : "http:\/\/bit.ly\/I6x5jc",
      "display_url" : "bit.ly\/I6x5jc"
    } ]
  },
  "geo" : { },
  "id_str" : "188948411662344192",
  "text" : "RT @steve_muir: Came across 2 great blogs recently: http:\/\/t.co\/aqQ1mrmT by @donaldthesane and http:\/\/t.co\/rhXot2i6 by @muranava&lt;--thx!",
  "id" : 188948411662344192,
  "created_at" : "2012-04-08 11:16:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 36, 47 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/KHB2C8LA",
      "expanded_url" : "http:\/\/hughdellar.wordpress.com\/2012\/04\/06\/activating-memory-in-the-language-classroom\/",
      "display_url" : "hughdellar.wordpress.com\/2012\/04\/06\/act\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "188775388623806464",
  "geo" : { },
  "id_str" : "188948008107376640",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin that's interesting @hughdellar in his latest post (http:\/\/t.co\/KHB2C8LA) suggests doing what korean schools r doing! :)",
  "id" : 188948008107376640,
  "in_reply_to_status_id" : 188775388623806464,
  "created_at" : "2012-04-08 11:14:50 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188756197896237056",
  "text" : "IDB OLPC report Peru - Our results suggest that computers by themselves,..,do not increase achievement in curricular areas.&lt;--noshtsherlock!",
  "id" : 188756197896237056,
  "created_at" : "2012-04-07 22:32:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188736812204826624",
  "text" : "Obese American Inc pumps house bubble, the ripples cross the ocean,\nyou're cast onto slagheap\nof long-term unemployed.&lt;--non-BBC DGently :)",
  "id" : 188736812204826624,
  "created_at" : "2012-04-07 21:15:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188685862886838273",
  "text" : "enjoying Dirk Gently pilot episode and bonus it has Helene Baxendale!",
  "id" : 188685862886838273,
  "created_at" : "2012-04-07 17:53:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188678037976530945",
  "geo" : { },
  "id_str" : "188679552036376576",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin ah right it's a good thing right?",
  "id" : 188679552036376576,
  "in_reply_to_status_id" : 188678037976530945,
  "created_at" : "2012-04-07 17:28:05 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188670707914391554",
  "geo" : { },
  "id_str" : "188675826785587200",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin is that diff =different or difficult? sorry won't be able to answer but am interested in question",
  "id" : 188675826785587200,
  "in_reply_to_status_id" : 188670707914391554,
  "created_at" : "2012-04-07 17:13:17 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 64, 77 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188675545498791938",
  "text" : "if someone has blocked can they still see @ messages? am hoping @aClilToClimb has accidently blkd me!",
  "id" : 188675545498791938,
  "created_at" : "2012-04-07 17:12:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188660253003481088",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb can't follow u? been blocked?",
  "id" : 188660253003481088,
  "created_at" : "2012-04-07 16:11:24 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188547750403641344",
  "geo" : { },
  "id_str" : "188550661368061952",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin not one blog post just the DNT theme with acronym SIT seemed very funny!",
  "id" : 188550661368061952,
  "in_reply_to_status_id" : 188547750403641344,
  "created_at" : "2012-04-07 08:55:55 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/BU3yz9ME",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "in_reply_to_status_id_str" : "188546926160003073",
  "geo" : { },
  "id_str" : "188548190461632512",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb got some tips for safer browsing? why not cmt here http:\/\/t.co\/BU3yz9ME",
  "id" : 188548190461632512,
  "in_reply_to_status_id" : 188546926160003073,
  "created_at" : "2012-04-07 08:46:06 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188539326731255808",
  "geo" : { },
  "id_str" : "188546251007082496",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @kevingiddens hard to tell how serious\/joking his writing is! e.g. at first SIT sounds made up! :O",
  "id" : 188546251007082496,
  "in_reply_to_status_id" : 188539326731255808,
  "created_at" : "2012-04-07 08:38:23 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/KHB2C8LA",
      "expanded_url" : "http:\/\/hughdellar.wordpress.com\/2012\/04\/06\/activating-memory-in-the-language-classroom\/",
      "display_url" : "hughdellar.wordpress.com\/2012\/04\/06\/act\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188322757195476992",
  "text" : "RT @hughdellar: Activating memory in the language classroom http:\/\/t.co\/KHB2C8LA&lt;--working link!",
  "id" : 188322757195476992,
  "created_at" : "2012-04-06 17:50:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/1iiB3Ehq",
      "expanded_url" : "http:\/\/wp.me\/p2kILc-w",
      "display_url" : "wp.me\/p2kILc-w"
    } ]
  },
  "geo" : { },
  "id_str" : "188284629898371072",
  "text" : "RT @hughdellar: Activating memory in the language classroom http:\/\/t.co\/1iiB3Ehq &lt;--dang, fast becoming number one ELT blog imo",
  "id" : 188284629898371072,
  "created_at" : "2012-04-06 15:18:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 65, 79 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/BIVM4DoM",
      "expanded_url" : "http:\/\/truth-out.org\/opinion\/item\/8305-the-assault-on-public-education",
      "display_url" : "truth-out.org\/opinion\/item\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188067400653094912",
  "text" : "Chomsky, The Assault on Public Education http:\/\/t.co\/BIVM4DoM HT @audreywatters",
  "id" : 188067400653094912,
  "created_at" : "2012-04-06 00:55:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grammar",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188014974344511489",
  "text" : "Contemporary Conditionals - If a backside could have 3 cheeks, then British politics is that 3-cheeked backside #grammar #eltchat",
  "id" : 188014974344511489,
  "created_at" : "2012-04-05 21:27:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 95, 110 ],
      "id_str" : "58839737",
      "id" : 58839737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/aOs8Uu9A",
      "expanded_url" : "http:\/\/youtu.be\/rIABo0d9MVE",
      "display_url" : "youtu.be\/rIABo0d9MVE"
    } ]
  },
  "geo" : { },
  "id_str" : "187994906961252352",
  "text" : "Every Presentation Ever:http:\/\/t.co\/aOs8Uu9A&lt;--grt video to use in a presentation class, HT @feedtheteacher:",
  "id" : 187994906961252352,
  "created_at" : "2012-04-05 20:07:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "esp",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/bNPM7HeQ",
      "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/",
      "display_url" : "businessenglishideas.blogspot.de"
    } ]
  },
  "geo" : { },
  "id_str" : "187905969076961280",
  "text" : "MT @Charlesrei1: Building a corpus and key word list http:\/\/t.co\/bNPM7HeQ #besig #esp &lt;--gd video though free tool such as antconc available",
  "id" : 187905969076961280,
  "created_at" : "2012-04-05 14:14:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/DYjoIRiV",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "187894066757910530",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 hi enjoying yr video on making key word list, there is a free tool antconc http:\/\/t.co\/DYjoIRiV, tried commenting but cant!",
  "id" : 187894066757910530,
  "created_at" : "2012-04-05 13:26:51 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187874056735956992",
  "geo" : { },
  "id_str" : "187875583840092161",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab yr welcome, glad it worked out for you :)",
  "id" : 187875583840092161,
  "in_reply_to_status_id" : 187874056735956992,
  "created_at" : "2012-04-05 12:13:24 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/uONbVEZx",
      "expanded_url" : "http:\/\/www.david-amador.com\/2011\/12\/revert-to-the-old-tweetdeck\/",
      "display_url" : "david-amador.com\/2011\/12\/revert\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "187862692294438912",
  "geo" : { },
  "id_str" : "187863070956208128",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab try this also link to old versions in that post http:\/\/t.co\/uONbVEZx",
  "id" : 187863070956208128,
  "in_reply_to_status_id" : 187862692294438912,
  "created_at" : "2012-04-05 11:23:41 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 73, 89 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 24 ],
      "url" : "http:\/\/t.co\/csmTFFkP",
      "expanded_url" : "http:\/\/kevingiddens.posterous.com\/",
      "display_url" : "kevingiddens.posterous.com"
    } ]
  },
  "geo" : { },
  "id_str" : "187802965946531840",
  "text" : "lol http:\/\/t.co\/csmTFFkP Do Nothing Teaching , my kind of teaching :) HT @michaelegriffin",
  "id" : 187802965946531840,
  "created_at" : "2012-04-05 07:24:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 45, 56 ],
      "id_str" : "281918842",
      "id" : 281918842
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 57, 72 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/187695830998847490\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/a8ej5D32",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AprUXSTCEAEtb3V.png",
      "id_str" : "187695831003041793",
      "id" : 187695831003041793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AprUXSTCEAEtb3V.png",
      "sizes" : [ {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1102
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a8ej5D32"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187695830998847490",
  "text" : "Compare and contrast image activity #eltchat @wetheround @georgegalloway http:\/\/t.co\/a8ej5D32",
  "id" : 187695830998847490,
  "created_at" : "2012-04-05 00:19:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187686243541319680",
  "text" : "@SiegelChat ta!",
  "id" : 187686243541319680,
  "created_at" : "2012-04-04 23:41:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187650788074590208",
  "geo" : { },
  "id_str" : "187651860629434368",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan ah right thanks!",
  "id" : 187651860629434368,
  "in_reply_to_status_id" : 187650788074590208,
  "created_at" : "2012-04-04 21:24:24 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187648440560386050",
  "geo" : { },
  "id_str" : "187650286389698560",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan not sure what NESTs are but #eltchat was about directives, and standards though unfort wasn't paying enough attention!",
  "id" : 187650286389698560,
  "in_reply_to_status_id" : 187648440560386050,
  "created_at" : "2012-04-04 21:18:09 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187648830295113728",
  "text" : "thx all for chat #eltchat",
  "id" : 187648830295113728,
  "created_at" : "2012-04-04 21:12:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 3, 12 ],
      "id_str" : "136001411",
      "id" : 136001411
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 14, 25 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187643815488794624",
  "text" : "RT @SueAnnan: @bethcagnol  Tefl the non-stick qualification? hehe #eltchat",
  "id" : 187643815488794624,
  "created_at" : "2012-04-04 20:52:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187637954364190721",
  "text" : "hmm maybe am lucky but not had to suffer any 'directives'...is that different from policies? #eltchat",
  "id" : 187637954364190721,
  "created_at" : "2012-04-04 20:29:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 11, 20 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187596541278695425",
  "geo" : { },
  "id_str" : "187604708905594880",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @chiasuan sorry WAVE just got here!",
  "id" : 187604708905594880,
  "in_reply_to_status_id" : 187596541278695425,
  "created_at" : "2012-04-04 18:17:02 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "efl",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "esl",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "elt",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/TePwXjbK",
      "expanded_url" : "http:\/\/wp.me\/p18yiK-mG",
      "display_url" : "wp.me\/p18yiK-mG"
    } ]
  },
  "geo" : { },
  "id_str" : "187555541260832769",
  "text" : "MT @sandymillinA post #iatefl survey on obscene\/offensive language in English http:\/\/t.co\/TePwXjbK #eltchat #efl #esl #elt",
  "id" : 187555541260832769,
  "created_at" : "2012-04-04 15:01:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187527674011455490",
  "geo" : { },
  "id_str" : "187528039725416449",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt no worries, have a good day!",
  "id" : 187528039725416449,
  "in_reply_to_status_id" : 187527674011455490,
  "created_at" : "2012-04-04 13:12:23 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 27, 35 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187526628052697088",
  "text" : "or save it for an eapchat? @seburnt #tblchat",
  "id" : 187526628052697088,
  "created_at" : "2012-04-04 13:06:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "kevchanow",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187526441288740864",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hi tyson maybe we can cont #tblchat? while #kevchanow gets some shut eye!",
  "id" : 187526441288740864,
  "created_at" : "2012-04-04 13:06:02 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187525809077092353",
  "text" : "okay fait de beau reves! #tblchat",
  "id" : 187525809077092353,
  "created_at" : "2012-04-04 13:03:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187525500506353664",
  "text" : "recently used a 15mn video docu, sts wrote op, 5 new words\/phrases and comment on classmates opinion - done on shared google doc #tblchat",
  "id" : 187525500506353664,
  "created_at" : "2012-04-04 13:02:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187524433651564544",
  "text" : "i have used tbl in writing\/poster work not really for speaking #tblchat",
  "id" : 187524433651564544,
  "created_at" : "2012-04-04 12:58:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187523447377760256",
  "text" : "i see yes for speaking based tbls is an issue i guess #tblchat",
  "id" : 187523447377760256,
  "created_at" : "2012-04-04 12:54:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187523177851797504",
  "text" : "what do u mean by that, \"hearing themselves\"? #tblchat",
  "id" : 187523177851797504,
  "created_at" : "2012-04-04 12:53:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBLchat",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187522046857711616",
  "geo" : { },
  "id_str" : "187522374357368833",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow TBL task based learning? #TBLchat",
  "id" : 187522374357368833,
  "in_reply_to_status_id" : 187522046857711616,
  "created_at" : "2012-04-04 12:49:52 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 19, 30 ],
      "id_str" : "228469472",
      "id" : 228469472
    }, {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 85, 92 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/Oq6BG6Hd",
      "expanded_url" : "http:\/\/bit.ly\/Hc7mo6",
      "display_url" : "bit.ly\/Hc7mo6"
    } ]
  },
  "geo" : { },
  "id_str" : "187472715685437440",
  "text" : "MT @leoselivan: RT @naomishema: The Silence of the Audience http:\/\/t.co\/Oq6BG6Hd via @hartle &gt; yes we must STOP the Hannibal Lecturing!",
  "id" : 187472715685437440,
  "created_at" : "2012-04-04 09:32:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 84, 91 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "eap",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/ckxWVG6U",
      "expanded_url" : "http:\/\/new-aesthetic.tumblr.com\/",
      "display_url" : "new-aesthetic.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "187296772320800769",
  "text" : "if you teach multi-media students chk the New Aesthetic tumblr http:\/\/t.co\/ckxWVG6U #edtech #eapchat #eap",
  "id" : 187296772320800769,
  "created_at" : "2012-04-03 21:53:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "elt",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "esl",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "tesol",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/3qTjirC9",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7g",
      "display_url" : "wp.me\/pgHyE-7g"
    } ]
  },
  "geo" : { },
  "id_str" : "187272311672537088",
  "text" : "new blog post for Top Gear's Richard Hammond fans ;) http:\/\/t.co\/3qTjirC9 #eltchat #eapchat #elt #esl #tesol",
  "id" : 187272311672537088,
  "created_at" : "2012-04-03 20:16:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 3, 9 ],
      "id_str" : "14647570",
      "id" : 14647570
    }, {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 80, 92 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/1NyhhcJA",
      "expanded_url" : "http:\/\/bit.ly\/HvyrrQ",
      "display_url" : "bit.ly\/HvyrrQ"
    }, {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/37bLVqXB",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=3882",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=3882"
    } ]
  },
  "geo" : { },
  "id_str" : "187196891480600576",
  "text" : "RT @SciAm http:\/\/t.co\/1NyhhcJA Neuroscientists: We Don\u2019t Really Know  Either HT @LanguageLog & do chk their list http:\/\/t.co\/37bLVqXB",
  "id" : 187196891480600576,
  "created_at" : "2012-04-03 15:16:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "ELT",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "EFL",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Y6IHF3wJ",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/",
      "display_url" : "theotherthingsmatter.blogspot.jp"
    } ]
  },
  "geo" : { },
  "id_str" : "187190503207473152",
  "text" : "MT @kevchanwow: New blog post on motivation. Connected? http:\/\/t.co\/Y6IHF3wJ #ELTchat #ELT #EFL #TESOL &lt;--thx for link to yr vocab card prop",
  "id" : 187190503207473152,
  "created_at" : "2012-04-03 14:51:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187178684808044546",
  "geo" : { },
  "id_str" : "187181815264575488",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan  \"Adverbs, like the passive voice, seem to have been created with the timid writer in mind.\" hmm \/rolls eyes\/",
  "id" : 187181815264575488,
  "in_reply_to_status_id" : 187178684808044546,
  "created_at" : "2012-04-03 14:16:37 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 66, 70 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "eap",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "tesol",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "elt",
      "indices" : [ 92, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/3qTjirC9",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7g",
      "display_url" : "wp.me\/pgHyE-7g"
    } ]
  },
  "geo" : { },
  "id_str" : "187180903615832066",
  "text" : "new blog post Jigsaw listening for engineers http:\/\/t.co\/3qTjirC9 #esl #eapchat #eap #tesol #elt",
  "id" : 187180903615832066,
  "created_at" : "2012-04-03 14:12:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/rTZzj3ni",
      "expanded_url" : "http:\/\/www.prepareforsuccess.org.uk\/listening_to_lectures.html",
      "display_url" : "prepareforsuccess.org.uk\/listening_to_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186866640061874176",
  "text" : "anyone tired this resource? http:\/\/t.co\/rTZzj3ni #EAPchat",
  "id" : 186866640061874176,
  "created_at" : "2012-04-02 17:24:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186863464369758208",
  "text" : "do we need to find out prev experience of lectures ss have? esp if from abroad? #EAPchat",
  "id" : 186863464369758208,
  "created_at" : "2012-04-02 17:11:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186861300779991040",
  "text" : "unfort will be  lurking mostly today #EAPchat",
  "id" : 186861300779991040,
  "created_at" : "2012-04-02 17:03:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/hTx5aJtf",
      "expanded_url" : "http:\/\/infiniteeltideas.wordpress.com\/2012\/03\/31\/batman-pulled-over-by-police\/",
      "display_url" : "infiniteeltideas.wordpress.com\/2012\/03\/31\/bat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186853841411645440",
  "text" : "collaborative lesson brainstorming http:\/\/t.co\/hTx5aJtf &lt;--the more the merrier!",
  "id" : 186853841411645440,
  "created_at" : "2012-04-02 16:33:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186580769899159553",
  "text" : "how do you tell non-April fool days apart?!",
  "id" : 186580769899159553,
  "created_at" : "2012-04-01 22:28:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/BU3yz9ME",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "geo" : { },
  "id_str" : "186545908282966017",
  "text" : "if you are a clicking freak some advice to stay safe online http:\/\/t.co\/BU3yz9ME",
  "id" : 186545908282966017,
  "created_at" : "2012-04-01 20:09:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/VTxH1Gik",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6D",
      "display_url" : "wp.me\/pgHyE-6D"
    } ]
  },
  "geo" : { },
  "id_str" : "186533260883542016",
  "text" : "@harrisonmike thks for RT http:\/\/t.co\/VTxH1Gik did not show up on interactions before!",
  "id" : 186533260883542016,
  "created_at" : "2012-04-01 19:19:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Wilson",
      "screen_name" : "kenwilsonlondon",
      "indices" : [ 11, 27 ],
      "id_str" : "29030280",
      "id" : 29030280
    }, {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 28, 40 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/JCkZfuFp",
      "expanded_url" : "http:\/\/explainthisimage.com\/",
      "display_url" : "explainthisimage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "186479044995448832",
  "text" : "if you saw @kenwilsonlondon @IATEFLResig webinar and looking for unusual images http:\/\/t.co\/JCkZfuFp though many images poss offensive",
  "id" : 186479044995448832,
  "created_at" : "2012-04-01 15:44:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/x17sWTX9",
      "expanded_url" : "http:\/\/jefreybulla.tumblr.com\/post\/20267460376\/girls-around-me-alternatives",
      "display_url" : "jefreybulla.tumblr.com\/post\/202674603\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186471126250164224",
  "text" : "alternative programs to girls around me http:\/\/t.co\/x17sWTX9",
  "id" : 186471126250164224,
  "created_at" : "2012-04-01 15:12:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/6M7juDTu",
      "expanded_url" : "http:\/\/www.cultofmac.com\/157641\/this-creepy-app-isnt-just-stalking-women-without-their-knowledge-its-a-wake-up-call-about-facebook-privacy\/",
      "display_url" : "cultofmac.com\/157641\/this-cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186470600448024576",
  "text" : "http:\/\/t.co\/6M7juDTu&lt;-- good material to discuss info we share online",
  "id" : 186470600448024576,
  "created_at" : "2012-04-01 15:10:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/H71e5JLh",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1333152062.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186450668444319744",
  "text" : "one of the most interesting comments on Galloway and media reaction http:\/\/t.co\/H71e5JLh",
  "id" : 186450668444319744,
  "created_at" : "2012-04-01 13:51:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elmira Merve Oflaz",
      "screen_name" : "oflazmerve",
      "indices" : [ 0, 11 ],
      "id_str" : "263866847",
      "id" : 263866847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/BU3yz9ME",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "geo" : { },
  "id_str" : "186364307854991360",
  "in_reply_to_user_id" : 263866847,
  "text" : "@oflazmerve thks for RT of http:\/\/t.co\/BU3yz9ME",
  "id" : 186364307854991360,
  "created_at" : "2012-04-01 08:08:08 +0000",
  "in_reply_to_screen_name" : "oflazmerve",
  "in_reply_to_user_id_str" : "263866847",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 41, 52 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "esl",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "tefl",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "esol",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "elt",
      "indices" : [ 116, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/i8w2waM5",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.fr\/2012\/03\/please-read-my-lips.html",
      "display_url" : "theotherthingsmatter.blogspot.fr\/2012\/03\/please\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186363049689612290",
  "text" : "something different to try in class from @kevchanwow  - lip reading  http:\/\/t.co\/i8w2waM5 #eltchat #esl #tefl #esol #elt",
  "id" : 186363049689612290,
  "created_at" : "2012-04-01 08:03:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/sCb1AmEt",
      "expanded_url" : "http:\/\/gu.com\/p\/36ht7\/tw",
      "display_url" : "gu.com\/p\/36ht7\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "186354230343380994",
  "text" : "http:\/\/t.co\/sCb1AmEt This was Bradford's version of the riots by Geoerge Galloway",
  "id" : 186354230343380994,
  "created_at" : "2012-04-01 07:28:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "esl",
      "indices" : [ 67, 71 ]
    }, {
      "text" : "tesol",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "elt",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "tefl",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "edchat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/BU3yz9ME",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "geo" : { },
  "id_str" : "186344809068376064",
  "text" : "new blog post on staying safe online http:\/\/t.co\/BU3yz9ME #eltchat #esl #tesol #elt #tefl #edchat",
  "id" : 186344809068376064,
  "created_at" : "2012-04-01 06:50:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]