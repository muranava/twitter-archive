Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Jones",
      "screen_name" : "S_Jones76",
      "indices" : [ 3, 13 ],
      "id_str" : "3308234392",
      "id" : 3308234392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/S_Jones76\/status\/714390814294732800\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/gOtT3X96uC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoGqNHXEAEXuKK.jpg",
      "id_str" : "714390813036449793",
      "id" : 714390813036449793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoGqNHXEAEXuKK.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/gOtT3X96uC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715653461245825025",
  "text" : "RT @S_Jones76: My favourite typo this Easter weekend... https:\/\/t.co\/gOtT3X96uC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/S_Jones76\/status\/714390814294732800\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/gOtT3X96uC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoGqNHXEAEXuKK.jpg",
        "id_str" : "714390813036449793",
        "id" : 714390813036449793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoGqNHXEAEXuKK.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 405
        } ],
        "display_url" : "pic.twitter.com\/gOtT3X96uC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714390814294732800",
    "text" : "My favourite typo this Easter weekend... https:\/\/t.co\/gOtT3X96uC",
    "id" : 714390814294732800,
    "created_at" : "2016-03-28 09:56:57 +0000",
    "user" : {
      "name" : "Steve Jones",
      "screen_name" : "S_Jones76",
      "protected" : false,
      "id_str" : "3308234392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606476742140788736\/xuGhKk1Z_normal.jpg",
      "id" : 3308234392,
      "verified" : false
    }
  },
  "id" : 715653461245825025,
  "created_at" : "2016-03-31 21:34:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 49, 64 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/8PL3NYmTib",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/31\/mike-long-on-recasts\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/31\/mik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715647106858541057",
  "text" : "Mike Long on Recasts https:\/\/t.co\/8PL3NYmTib via @GeoffreyJordan",
  "id" : 715647106858541057,
  "created_at" : "2016-03-31 21:09:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hippoedtech",
      "screen_name" : "hippoedtech",
      "indices" : [ 65, 77 ],
      "id_str" : "713345621650980864",
      "id" : 713345621650980864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/tlDnRErgEV",
      "expanded_url" : "http:\/\/hippoedtech.com\/how-can-i-improve-my-vocabulary-1\/",
      "display_url" : "hippoedtech.com\/how-can-i-impr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715641282002071561",
  "text" : "How can I improve my vocabulary (1)? https:\/\/t.co\/tlDnRErgEV via @hippoedtech",
  "id" : 715641282002071561,
  "created_at" : "2016-03-31 20:45:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715567546045480960",
  "geo" : { },
  "id_str" : "715620281151320064",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher do u have any good sources?",
  "id" : 715620281151320064,
  "in_reply_to_status_id" : 715567546045480960,
  "created_at" : "2016-03-31 19:22:25 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "controversial",
      "indices" : [ 106, 120 ]
    }, {
      "text" : "elt",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "ELF",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XJRXTq9tZO",
      "expanded_url" : "https:\/\/www.etprofessional.com\/5-more-reasons-why-native-speakers-need-to-learn-to-speak-english-internationally.aspx",
      "display_url" : "etprofessional.com\/5-more-reasons\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715552957090148352",
  "text" : "RT @chiasuan: Here are 5 more reasons why native speakers need to learn to speak English internationally.\n#controversial #elt #ELF\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "controversial",
        "indices" : [ 92, 106 ]
      }, {
        "text" : "elt",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "ELF",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XJRXTq9tZO",
        "expanded_url" : "https:\/\/www.etprofessional.com\/5-more-reasons-why-native-speakers-need-to-learn-to-speak-english-internationally.aspx",
        "display_url" : "etprofessional.com\/5-more-reasons\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715549309845049344",
    "text" : "Here are 5 more reasons why native speakers need to learn to speak English internationally.\n#controversial #elt #ELF\nhttps:\/\/t.co\/XJRXTq9tZO",
    "id" : 715549309845049344,
    "created_at" : "2016-03-31 14:40:24 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 715552957090148352,
  "created_at" : "2016-03-31 14:54:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/iROJaHVVt3",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/27\/real-tasks-guide-longs-tblt\/Long",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/27\/rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715551303812968449",
  "text" : "RT @GeoffreyJordan: The article I summarised recently https:\/\/t.co\/iROJaHVVt3, Long (2016). In defense of tasks and TBLT is out today. A.R.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/iROJaHVVt3",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/27\/real-tasks-guide-longs-tblt\/Long",
        "display_url" : "criticalelt.wordpress.com\/2016\/03\/27\/rea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715548717496082432",
    "text" : "The article I summarised recently https:\/\/t.co\/iROJaHVVt3, Long (2016). In defense of tasks and TBLT is out today. A.R.A.L. 36, pp. 5-33.",
    "id" : 715548717496082432,
    "created_at" : "2016-03-31 14:38:03 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 715551303812968449,
  "created_at" : "2016-03-31 14:48:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 28, 44 ],
      "id_str" : "149239362",
      "id" : 149239362
    }, {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 45, 56 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715536666203533312",
  "geo" : { },
  "id_str" : "715546958719483904",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish  @umasslinguistic @gdlinguist thanks a lot for sharing y'all : ) got any good trivia?",
  "id" : 715546958719483904,
  "in_reply_to_status_id" : 715536666203533312,
  "created_at" : "2016-03-31 14:31:03 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/cpdffnEQvR",
      "expanded_url" : "http:\/\/handsupproject.org\/2016\/03\/31\/heres-your-chants\/",
      "display_url" : "handsupproject.org\/2016\/03\/31\/her\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715546663486664704",
  "text" : "Here's your chants! https:\/\/t.co\/cpdffnEQvR via @wordpressdotcom",
  "id" : 715546663486664704,
  "created_at" : "2016-03-31 14:29:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "tesol",
      "indices" : [ 54, 60 ]
    }, {
      "text" : "efl",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "tefl",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "esl",
      "indices" : [ 72, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/nkj35IMXKj",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/03\/31\/exploiting-linguistics-in-the-language-class\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/03\/31\/exp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715536666203533312",
  "text" : "Exploiting linguistics in the language class #eltchat #tesol #efl #tefl #esl https:\/\/t.co\/nkj35IMXKj",
  "id" : 715536666203533312,
  "created_at" : "2016-03-31 13:50:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715525673213820928",
  "geo" : { },
  "id_str" : "715526537467076608",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin i like vying for office as it is close to lying for office : 0",
  "id" : 715526537467076608,
  "in_reply_to_status_id" : 715525673213820928,
  "created_at" : "2016-03-31 13:09:55 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/Y3fqP5zTMD",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=46431469",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715523938982309888",
  "geo" : { },
  "id_str" : "715525174506995712",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin any good? https:\/\/t.co\/Y3fqP5zTMD",
  "id" : 715525174506995712,
  "in_reply_to_status_id" : 715523938982309888,
  "created_at" : "2016-03-31 13:04:30 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data science blogs",
      "screen_name" : "dsguidebiz",
      "indices" : [ 3, 14 ],
      "id_str" : "3596154496",
      "id" : 3596154496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/lDVmcWtYBM",
      "expanded_url" : "http:\/\/idibon.com\/culture-sensitive-customer-service\/?utm_source=rss&utm_medium=rss&utm_campaign=culture-sensitive-customer-service",
      "display_url" : "idibon.com\/culture-sensit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715508629735153664",
  "text" : "RT @dsguidebiz: Culture-sensitive customer service https:\/\/t.co\/lDVmcWtYBM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dsguide.biz\/reader\" rel=\"nofollow\"\u003EDsGuide bot #2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/lDVmcWtYBM",
        "expanded_url" : "http:\/\/idibon.com\/culture-sensitive-customer-service\/?utm_source=rss&utm_medium=rss&utm_campaign=culture-sensitive-customer-service",
        "display_url" : "idibon.com\/culture-sensit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714543497274134528",
    "text" : "Culture-sensitive customer service https:\/\/t.co\/lDVmcWtYBM",
    "id" : 714543497274134528,
    "created_at" : "2016-03-28 20:03:39 +0000",
    "user" : {
      "name" : "Data science blogs",
      "screen_name" : "dsguidebiz",
      "protected" : false,
      "id_str" : "3596154496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669343069167329280\/B3csG1rP_normal.jpg",
      "id" : 3596154496,
      "verified" : false
    }
  },
  "id" : 715508629735153664,
  "created_at" : "2016-03-31 11:58:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715284639359873028",
  "geo" : { },
  "id_str" : "715505330285907968",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish thanks for RTing &amp; joining in : )",
  "id" : 715505330285907968,
  "in_reply_to_status_id" : 715284639359873028,
  "created_at" : "2016-03-31 11:45:38 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BPS Research Digest",
      "screen_name" : "ResearchDigest",
      "indices" : [ 3, 18 ],
      "id_str" : "24862758",
      "id" : 24862758
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ResearchDigest\/status\/715120969493426176\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/C1TzaMUPiZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ceyeu37WQAAs6I0.jpg",
      "id_str" : "715120968969109504",
      "id" : 715120968969109504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ceyeu37WQAAs6I0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1400,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/C1TzaMUPiZ"
    } ],
    "hashtags" : [ {
      "text" : "PsychCrunch",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/NMe0Uh6coO",
      "expanded_url" : "http:\/\/digest.bps.org.uk\/2016\/03\/episode-5.html",
      "display_url" : "digest.bps.org.uk\/2016\/03\/episod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715500852136558593",
  "text" : "RT @ResearchDigest: It's landed! Episode 5 of #PsychCrunch How To Learn A New Language: https:\/\/t.co\/NMe0Uh6coO Sit back. Listen. Enjoy. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ResearchDigest\/status\/715120969493426176\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/C1TzaMUPiZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ceyeu37WQAAs6I0.jpg",
        "id_str" : "715120968969109504",
        "id" : 715120968969109504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ceyeu37WQAAs6I0.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/C1TzaMUPiZ"
      } ],
      "hashtags" : [ {
        "text" : "PsychCrunch",
        "indices" : [ 26, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/NMe0Uh6coO",
        "expanded_url" : "http:\/\/digest.bps.org.uk\/2016\/03\/episode-5.html",
        "display_url" : "digest.bps.org.uk\/2016\/03\/episod\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715306392639389696",
    "text" : "It's landed! Episode 5 of #PsychCrunch How To Learn A New Language: https:\/\/t.co\/NMe0Uh6coO Sit back. Listen. Enjoy. https:\/\/t.co\/C1TzaMUPiZ",
    "id" : 715306392639389696,
    "created_at" : "2016-03-30 22:35:08 +0000",
    "user" : {
      "name" : "BPS Research Digest",
      "screen_name" : "ResearchDigest",
      "protected" : false,
      "id_str" : "24862758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479279662783160321\/gnQfqK6T_normal.jpeg",
      "id" : 24862758,
      "verified" : false
    }
  },
  "id" : 715500852136558593,
  "created_at" : "2016-03-31 11:27:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715498347411451904",
  "text" : "@getgreatenglishyr no worries; about 2 weeks to go : )",
  "id" : 715498347411451904,
  "created_at" : "2016-03-31 11:17:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 35, 43 ],
      "id_str" : "612473",
      "id" : 612473
    }, {
      "name" : "MSF International",
      "screen_name" : "MSF",
      "indices" : [ 61, 65 ],
      "id_str" : "2195671183",
      "id" : 2195671183
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/715488245451063296\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/HLx8T1DWqO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce3sxHsUIAASCmX.jpg",
      "id_str" : "715488244444438528",
      "id" : 715488244444438528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce3sxHsUIAASCmX.jpg",
      "sizes" : [ {
        "h" : 96,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 54,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 120,
        "resize" : "crop",
        "w" : 120
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/HLx8T1DWqO"
    } ],
    "hashtags" : [ {
      "text" : "Kunduz",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "Afghanistan",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/bxQSaEv2AV",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2016\/815-kunduz-killers-go-free.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715491878129434624",
  "text" : "RT @medialens: Deceptive bias from @BBCNews on US bombing of @MSF hospital in #Kunduz #Afghanistan. https:\/\/t.co\/bxQSaEv2AV https:\/\/t.co\/HL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 20, 28 ],
        "id_str" : "612473",
        "id" : 612473
      }, {
        "name" : "MSF International",
        "screen_name" : "MSF",
        "indices" : [ 46, 50 ],
        "id_str" : "2195671183",
        "id" : 2195671183
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/715488245451063296\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/HLx8T1DWqO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce3sxHsUIAASCmX.jpg",
        "id_str" : "715488244444438528",
        "id" : 715488244444438528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce3sxHsUIAASCmX.jpg",
        "sizes" : [ {
          "h" : 96,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 54,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 120,
          "resize" : "crop",
          "w" : 120
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/HLx8T1DWqO"
      } ],
      "hashtags" : [ {
        "text" : "Kunduz",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "Afghanistan",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/bxQSaEv2AV",
        "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2016\/815-kunduz-killers-go-free.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715488245451063296",
    "text" : "Deceptive bias from @BBCNews on US bombing of @MSF hospital in #Kunduz #Afghanistan. https:\/\/t.co\/bxQSaEv2AV https:\/\/t.co\/HLx8T1DWqO",
    "id" : 715488245451063296,
    "created_at" : "2016-03-31 10:37:45 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 715491878129434624,
  "created_at" : "2016-03-31 10:52:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Al Jazeera News",
      "screen_name" : "AJENews",
      "indices" : [ 85, 93 ],
      "id_str" : "18424289",
      "id" : 18424289
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 94, 102 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 116, 129 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "halliburton",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/mW2v1OqtwL",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-hOz",
      "display_url" : "wp.me\/pSoaD-hOz"
    } ]
  },
  "geo" : { },
  "id_str" : "715473196833570816",
  "text" : "RT @patrickDurusau: World's Biggest Bribe Scandal: Part 1... https:\/\/t.co\/mW2v1OqtwL @AJENews @nytimes #halliburton @YourAnonNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Al Jazeera News",
        "screen_name" : "AJENews",
        "indices" : [ 65, 73 ],
        "id_str" : "18424289",
        "id" : 18424289
      }, {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 74, 82 ],
        "id_str" : "807095",
        "id" : 807095
      }, {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 96, 109 ],
        "id_str" : "279390084",
        "id" : 279390084
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "halliburton",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/mW2v1OqtwL",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-hOz",
        "display_url" : "wp.me\/pSoaD-hOz"
      } ]
    },
    "geo" : { },
    "id_str" : "715356069908848641",
    "text" : "World's Biggest Bribe Scandal: Part 1... https:\/\/t.co\/mW2v1OqtwL @AJENews @nytimes #halliburton @YourAnonNews",
    "id" : 715356069908848641,
    "created_at" : "2016-03-31 01:52:32 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 715473196833570816,
  "created_at" : "2016-03-31 09:37:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 72, 88 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/OqAeCaW2JY",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2016\/03\/31\/error-treatment-not-straightforward-shock\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2016\/03\/31\/err\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715471937313513473",
  "text" : "Error Treatment: Not Straightforward Shock! https:\/\/t.co\/OqAeCaW2JY via @getgreatenglish",
  "id" : 715471937313513473,
  "created_at" : "2016-03-31 09:32:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iyad el-Baghdadi",
      "screen_name" : "iyad_elbaghdadi",
      "indices" : [ 3, 19 ],
      "id_str" : "18725815",
      "id" : 18725815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/EKKUXgGeUj",
      "expanded_url" : "https:\/\/twitter.com\/FRANCE24\/status\/715221594382032896",
      "display_url" : "twitter.com\/FRANCE24\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715295157244063744",
  "text" : "RT @iyad_elbaghdadi: How to be an asshole to Muslims, women, and black people all at once https:\/\/t.co\/EKKUXgGeUj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/EKKUXgGeUj",
        "expanded_url" : "https:\/\/twitter.com\/FRANCE24\/status\/715221594382032896",
        "display_url" : "twitter.com\/FRANCE24\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715292191774609408",
    "text" : "How to be an asshole to Muslims, women, and black people all at once https:\/\/t.co\/EKKUXgGeUj",
    "id" : 715292191774609408,
    "created_at" : "2016-03-30 21:38:42 +0000",
    "user" : {
      "name" : "Iyad el-Baghdadi",
      "screen_name" : "iyad_elbaghdadi",
      "protected" : false,
      "id_str" : "18725815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542423097253441537\/bjOF70A6_normal.jpeg",
      "id" : 18725815,
      "verified" : true
    }
  },
  "id" : 715295157244063744,
  "created_at" : "2016-03-30 21:50:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 72, 76 ],
      "id_str" : "4816",
      "id" : 4816
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 77, 86 ],
      "id_str" : "2729061",
      "id" : 2729061
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 87, 100 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Robert Graham \u2744",
      "screen_name" : "ErrataRob",
      "indices" : [ 101, 111 ],
      "id_str" : "15300995",
      "id" : 15300995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "surveillance",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/eyyMQrcwMX",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-hOl",
      "display_url" : "wp.me\/pSoaD-hOl"
    } ]
  },
  "geo" : { },
  "id_str" : "715293801842143240",
  "text" : "RT @patrickDurusau: Walking the Walk on Privacy https:\/\/t.co\/eyyMQrcwMX @eff @doctorow @YourAnonNews @ErrataRob #privacy #surveillance",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFF",
        "screen_name" : "EFF",
        "indices" : [ 52, 56 ],
        "id_str" : "4816",
        "id" : 4816
      }, {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 57, 66 ],
        "id_str" : "2729061",
        "id" : 2729061
      }, {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 67, 80 ],
        "id_str" : "279390084",
        "id" : 279390084
      }, {
        "name" : "Robert Graham \u2744",
        "screen_name" : "ErrataRob",
        "indices" : [ 81, 91 ],
        "id_str" : "15300995",
        "id" : 15300995
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "surveillance",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/eyyMQrcwMX",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-hOl",
        "display_url" : "wp.me\/pSoaD-hOl"
      } ]
    },
    "geo" : { },
    "id_str" : "715289411215351808",
    "text" : "Walking the Walk on Privacy https:\/\/t.co\/eyyMQrcwMX @eff @doctorow @YourAnonNews @ErrataRob #privacy #surveillance",
    "id" : 715289411215351808,
    "created_at" : "2016-03-30 21:27:39 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 715293801842143240,
  "created_at" : "2016-03-30 21:45:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dodgson",
      "screen_name" : "DaveDodgson",
      "indices" : [ 3, 15 ],
      "id_str" : "112962705",
      "id" : 112962705
    }, {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 78, 93 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DGBL",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/CfCra22gBs",
      "expanded_url" : "https:\/\/www.etprofessional.com\/Learning_to_play_the_studentsway_25769832021.aspx?y=F25JQ96CMGVZQFTCLRUQ47M2FZXG5ZXYNQ68QDZ",
      "display_url" : "etprofessional.com\/Learning_to_pl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715293002500063232",
  "text" : "RT @DaveDodgson: Learning to play the students\u2019 way - my article on #DGBL for @ETprofessional : https:\/\/t.co\/CfCra22gBs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ETpro",
        "screen_name" : "ETprofessional",
        "indices" : [ 61, 76 ],
        "id_str" : "501629829",
        "id" : 501629829
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DGBL",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/CfCra22gBs",
        "expanded_url" : "https:\/\/www.etprofessional.com\/Learning_to_play_the_studentsway_25769832021.aspx?y=F25JQ96CMGVZQFTCLRUQ47M2FZXG5ZXYNQ68QDZ",
        "display_url" : "etprofessional.com\/Learning_to_pl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705829390966464513",
    "text" : "Learning to play the students\u2019 way - my article on #DGBL for @ETprofessional : https:\/\/t.co\/CfCra22gBs",
    "id" : 705829390966464513,
    "created_at" : "2016-03-04 18:56:55 +0000",
    "user" : {
      "name" : "David Dodgson",
      "screen_name" : "DaveDodgson",
      "protected" : false,
      "id_str" : "112962705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656174667644993537\/JBY5vVk__normal.jpg",
      "id" : 112962705,
      "verified" : false
    }
  },
  "id" : 715293002500063232,
  "created_at" : "2016-03-30 21:41:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/xhwmxHWZru",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/Zy4fyxdiYtj",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715284639359873028",
  "text" : "I'm on the street or I'm in the street? How would you find out? https:\/\/t.co\/xhwmxHWZru",
  "id" : 715284639359873028,
  "created_at" : "2016-03-30 21:08:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 10, 22 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 23, 35 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 36, 47 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Mairead Moriarty",
      "screen_name" : "MawsMoriarty",
      "indices" : [ 48, 61 ],
      "id_str" : "2353100574",
      "id" : 2353100574
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 62, 70 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 71, 87 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715247424751538176",
  "geo" : { },
  "id_str" : "715280678527614978",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @ELTResearch @TonyMcEnery @eilymurphy @MawsMoriarty @seburnt @getgreatenglish thanks for the RTs folks : )",
  "id" : 715280678527614978,
  "in_reply_to_status_id" : 715247424751538176,
  "created_at" : "2016-03-30 20:52:57 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715252381697642496",
  "geo" : { },
  "id_str" : "715276579392393216",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch ok added : ) good luck for yr talk!",
  "id" : 715276579392393216,
  "in_reply_to_status_id" : 715252381697642496,
  "created_at" : "2016-03-30 20:36:40 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "tesol16",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "tefl",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "esl",
      "indices" : [ 56, 60 ]
    }, {
      "text" : "elt",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/lMRAqhUyhG",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/03\/30\/iatefl-2016-corpus-carnival\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/03\/30\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715247424751538176",
  "text" : "#IATEFL 2016 - Corpus carnival! #eltchat #tesol16 #tefl #esl #elt https:\/\/t.co\/lMRAqhUyhG",
  "id" : 715247424751538176,
  "created_at" : "2016-03-30 18:40:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 45, 60 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/H71hkklxfn",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/30\/the-language-gym\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/30\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715231859093929985",
  "text" : "The Language Gym https:\/\/t.co\/H71hkklxfn via @GeoffreyJordan",
  "id" : 715231859093929985,
  "created_at" : "2016-03-30 17:38:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordsEye",
      "screen_name" : "wordseye",
      "indices" : [ 36, 45 ],
      "id_str" : "1104171271",
      "id" : 1104171271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "typeapicture",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/khzA8EyRiS",
      "expanded_url" : "https:\/\/www.wordseye.com\/view-picture\/44296",
      "display_url" : "wordseye.com\/view-picture\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715198946105274368",
  "text" : "Wordseye - Eric Cantona by mura via @wordseye  #typeapicture  https:\/\/t.co\/khzA8EyRiS",
  "id" : 715198946105274368,
  "created_at" : "2016-03-30 15:28:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/88r8froceN",
      "expanded_url" : "https:\/\/twitter.com\/langstat\/status\/714975574981148672",
      "display_url" : "twitter.com\/langstat\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715114735436480512",
  "text" : "#corpusresources #corpuslinguistics  https:\/\/t.co\/88r8froceN",
  "id" : 715114735436480512,
  "created_at" : "2016-03-30 09:53:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 3, 15 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheTeflShow\/status\/714941887283486720\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/EFS3ytNA37",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cev723jWQAAAc1C.jpg",
      "id_str" : "714941885912072192",
      "id" : 714941885912072192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cev723jWQAAAc1C.jpg",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 495
      } ],
      "display_url" : "pic.twitter.com\/EFS3ytNA37"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/0qVPedbxED",
      "expanded_url" : "http:\/\/theteflshow.com\/2016\/03\/29\/interview-with-paul-walsh-part-2",
      "display_url" : "theteflshow.com\/2016\/03\/29\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715057426085634048",
  "text" : "RT @TheTeflShow: The TEFL show presents part 2 of our recent interview with Paul Walsh. https:\/\/t.co\/0qVPedbxED https:\/\/t.co\/EFS3ytNA37",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheTeflShow\/status\/714941887283486720\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/EFS3ytNA37",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cev723jWQAAAc1C.jpg",
        "id_str" : "714941885912072192",
        "id" : 714941885912072192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cev723jWQAAAc1C.jpg",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 495
        } ],
        "display_url" : "pic.twitter.com\/EFS3ytNA37"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/0qVPedbxED",
        "expanded_url" : "http:\/\/theteflshow.com\/2016\/03\/29\/interview-with-paul-walsh-part-2",
        "display_url" : "theteflshow.com\/2016\/03\/29\/int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714941887283486720",
    "text" : "The TEFL show presents part 2 of our recent interview with Paul Walsh. https:\/\/t.co\/0qVPedbxED https:\/\/t.co\/EFS3ytNA37",
    "id" : 714941887283486720,
    "created_at" : "2016-03-29 22:26:43 +0000",
    "user" : {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "protected" : false,
      "id_str" : "3996937557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656210205261320192\/GVe23PWJ_normal.jpg",
      "id" : 3996937557,
      "verified" : false
    }
  },
  "id" : 715057426085634048,
  "created_at" : "2016-03-30 06:05:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 58, 73 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/sXS6Sigog1",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/29\/theoretical-constructs-in-sla\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/29\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714921190704431105",
  "text" : "Theoretical Constructs in SLA https:\/\/t.co\/sXS6Sigog1 via @GeoffreyJordan",
  "id" : 714921190704431105,
  "created_at" : "2016-03-29 21:04:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714688766108123136",
  "geo" : { },
  "id_str" : "714703005858267137",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock any pre-print copy of your article to read? : )",
  "id" : 714703005858267137,
  "in_reply_to_status_id" : 714688766108123136,
  "created_at" : "2016-03-29 06:37:29 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 78, 94 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/UeOzdS6V7Z",
      "expanded_url" : "https:\/\/linguisticpulse.com\/2016\/03\/28\/denying-language-privilege-in-academic-publishing\/",
      "display_url" : "linguisticpulse.com\/2016\/03\/28\/den\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714580273669734400",
  "text" : "Denying language privilege in academic publishing https:\/\/t.co\/UeOzdS6V7Z via @wordpressdotcom",
  "id" : 714580273669734400,
  "created_at" : "2016-03-28 22:29:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ijqQFdCFsU",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/668577829588705281",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/XlTyl4k23a",
      "expanded_url" : "https:\/\/twitter.com\/harrisonmike\/status\/714572876138024960",
      "display_url" : "twitter.com\/harrisonmike\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714574286531510272",
  "text" : "no worries there will be exobiological backup generator that costs salary of 2 teachers  https:\/\/t.co\/ijqQFdCFsU : ) https:\/\/t.co\/XlTyl4k23a",
  "id" : 714574286531510272,
  "created_at" : "2016-03-28 22:06:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714570027932979205",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike what happened to that mitra tweet?",
  "id" : 714570027932979205,
  "created_at" : "2016-03-28 21:49:05 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 96, 107 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/yWrOXUkKjz",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/03\/28\/visual-appearance-of-corpus-resources-is-a-barrier-to-uptake-in-elt\/",
      "display_url" : "corpling4efl.wordpress.com\/2016\/03\/28\/vis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714558376517173249",
  "text" : "Visual appearance of corpus resources is a barrier to uptake in ELT https:\/\/t.co\/yWrOXUkKjz via @Za_Maikeru",
  "id" : 714558376517173249,
  "created_at" : "2016-03-28 21:02:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714544571162750977",
  "geo" : { },
  "id_str" : "714548510163599360",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona oh sweet : ) thanks!",
  "id" : 714548510163599360,
  "in_reply_to_status_id" : 714544571162750977,
  "created_at" : "2016-03-28 20:23:35 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 10, 21 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714358751101325312",
  "geo" : { },
  "id_str" : "714520028914302976",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @lexicoj0hn thanks for sharing John : )",
  "id" : 714520028914302976,
  "in_reply_to_status_id" : 714358751101325312,
  "created_at" : "2016-03-28 18:30:24 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/74iTmWUArC",
      "expanded_url" : "https:\/\/thepostmodernguy.wordpress.com",
      "display_url" : "thepostmodernguy.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "714511385229725696",
  "text" : "another new blog ELT &amp; postmodernism https:\/\/t.co\/74iTmWUArC #eltchat",
  "id" : 714511385229725696,
  "created_at" : "2016-03-28 17:56:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714485520005537793",
  "geo" : { },
  "id_str" : "714509932591259648",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thx, sounds like a great Smashwords review comment ; )",
  "id" : 714509932591259648,
  "in_reply_to_status_id" : 714485520005537793,
  "created_at" : "2016-03-28 17:50:17 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Barbara Anna",
      "screen_name" : "bar_zie",
      "indices" : [ 13, 21 ],
      "id_str" : "2231464708",
      "id" : 2231464708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714485351364997121",
  "geo" : { },
  "id_str" : "714509697575960576",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @bar_zie thanks for sharing! : )",
  "id" : 714509697575960576,
  "in_reply_to_status_id" : 714485351364997121,
  "created_at" : "2016-03-28 17:49:21 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "indices" : [ 78, 84 ],
      "id_str" : "1114312832",
      "id" : 1114312832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/zAsxkwy2DE",
      "expanded_url" : "http:\/\/digitalmobilelanguagelearning.org\/2016\/03\/peer-grading-in-a-speech-class-using-google-forms\/",
      "display_url" : "digitalmobilelanguagelearning.org\/2016\/03\/peer-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714472902188474368",
  "text" : "Peer Grading in a Speech Class using Google Forms https:\/\/t.co\/zAsxkwy2DE via @DiMLL",
  "id" : 714472902188474368,
  "created_at" : "2016-03-28 15:23:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 10, 18 ],
      "id_str" : "209484168",
      "id" : 209484168
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 19, 34 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714389403997716480",
  "geo" : { },
  "id_str" : "714470209373995008",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @scoopit @LjiljanaHavran thx Ljiljana!",
  "id" : 714470209373995008,
  "in_reply_to_status_id" : 714389403997716480,
  "created_at" : "2016-03-28 15:12:26 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714389403997716480",
  "geo" : { },
  "id_str" : "714467999676243968",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks Shona : )",
  "id" : 714467999676243968,
  "in_reply_to_status_id" : 714389403997716480,
  "created_at" : "2016-03-28 15:03:39 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 10, 25 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 26, 41 ],
      "id_str" : "95419070",
      "id" : 95419070
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 42, 57 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714358751101325312",
  "geo" : { },
  "id_str" : "714457502377779200",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @GeoffreyJordan @corpusloanword @AnthonyTeacher thanks folks, a couple of bonus Q's added to post",
  "id" : 714457502377779200,
  "in_reply_to_status_id" : 714358751101325312,
  "created_at" : "2016-03-28 14:21:57 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 10, 20 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 21, 33 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714358751101325312",
  "geo" : { },
  "id_str" : "714380813400408064",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @RudyLoock @ELTResearch thanks for sharing : )",
  "id" : 714380813400408064,
  "in_reply_to_status_id" : 714358751101325312,
  "created_at" : "2016-03-28 09:17:13 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 4, 22 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "auselt",
      "indices" : [ 85, 92 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/bkWNlnf2RF",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/",
      "display_url" : "corpling4efl.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "714380576820707329",
  "text" : "new #corpuslinguistics  for efl site nice https:\/\/t.co\/bkWNlnf2RF #eltchat #keltchat #auselt #eltchinwag",
  "id" : 714380576820707329,
  "created_at" : "2016-03-28 09:16:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 38, 46 ]
    }, {
      "text" : "tefl",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "esl",
      "indices" : [ 53, 57 ]
    }, {
      "text" : "tesol",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 65, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/HeFXhKzhpl",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/03\/28\/coming-up-in-byu-coca-mini-interview-with-prof-mark-davies\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/03\/28\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714358751101325312",
  "text" : "Mini-interview with Prof. Mark Davies #eltchat #tefl #esl #tesol #corpuslinguistics https:\/\/t.co\/HeFXhKzhpl user interface preview!",
  "id" : 714358751101325312,
  "created_at" : "2016-03-28 07:49:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/8pwB2EepGx",
      "expanded_url" : "http:\/\/www.emolinguistics.org.uk\/#!about-emolinguistics\/c2414",
      "display_url" : "emolinguistics.org.uk\/#!about-emolin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714231827486142464",
  "text" : "https:\/\/t.co\/8pwB2EepGx : )",
  "id" : 714231827486142464,
  "created_at" : "2016-03-27 23:25:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 57, 72 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/4KgIia3rqv",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/27\/real-tasks-guide-longs-tblt\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/27\/rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714215089432313856",
  "text" : "Real Tasks Guide Long's TBLT https:\/\/t.co\/4KgIia3rqv via @GeoffreyJordan",
  "id" : 714215089432313856,
  "created_at" : "2016-03-27 22:18:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Lewin-Jones",
      "screen_name" : "JennyLewinJones",
      "indices" : [ 2, 18 ],
      "id_str" : "1484808264",
      "id" : 1484808264
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 19, 32 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/714138930782797824\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/uq6c4RnicQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CekhkmFWIAE0wCT.jpg",
      "id_str" : "714138928496910337",
      "id" : 714138928496910337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CekhkmFWIAE0wCT.jpg",
      "sizes" : [ {
        "h" : 388,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 649
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 649
      } ],
      "display_url" : "pic.twitter.com\/uq6c4RnicQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714066686333362176",
  "geo" : { },
  "id_str" : "714138930782797824",
  "in_reply_to_user_id" : 1484808264,
  "text" : ". @JennyLewinJones @perezparedes PMQs Cameron vs Corbyn n-grams https:\/\/t.co\/uq6c4RnicQ",
  "id" : 714138930782797824,
  "in_reply_to_status_id" : 714066686333362176,
  "created_at" : "2016-03-27 17:16:03 +0000",
  "in_reply_to_screen_name" : "JennyLewinJones",
  "in_reply_to_user_id_str" : "1484808264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DiscourseNet",
      "screen_name" : "DiscourseNet",
      "indices" : [ 0, 13 ],
      "id_str" : "2747657225",
      "id" : 2747657225
    }, {
      "name" : "UniversidadDeNavarra",
      "screen_name" : "unav",
      "indices" : [ 14, 19 ],
      "id_str" : "17152842",
      "id" : 17152842
    }, {
      "name" : "paderborn",
      "screen_name" : "paderborn",
      "indices" : [ 20, 30 ],
      "id_str" : "15928332",
      "id" : 15928332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713892418349895680",
  "geo" : { },
  "id_str" : "714091865776209920",
  "in_reply_to_user_id" : 2747657225,
  "text" : "@DiscourseNet @unav @paderborn hi i mean the multi-modal corpus",
  "id" : 714091865776209920,
  "in_reply_to_status_id" : 713892418349895680,
  "created_at" : "2016-03-27 14:09:02 +0000",
  "in_reply_to_screen_name" : "DiscourseNet",
  "in_reply_to_user_id_str" : "2747657225",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vanessa beeley",
      "screen_name" : "VanessaBeeley",
      "indices" : [ 86, 100 ],
      "id_str" : "956171191",
      "id" : 956171191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/TalU5c1tiq",
      "expanded_url" : "https:\/\/thewallwillfall.wordpress.com\/2016\/03\/27\/yemen-17-year-old-girl-describes-life-under-saudi-bombs\/",
      "display_url" : "thewallwillfall.wordpress.com\/2016\/03\/27\/yem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714090320787554304",
  "text" : "Yemen:  17 Year Old Girl Describes Life under Saudi Bombs https:\/\/t.co\/TalU5c1tiq via @VanessaBeeley",
  "id" : 714090320787554304,
  "created_at" : "2016-03-27 14:02:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/rc4rvIluq9",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv240VJa",
      "display_url" : "tmblr.co\/ZuWOEv240VJa"
    } ]
  },
  "geo" : { },
  "id_str" : "713994668170719233",
  "text" : "RT @AllThingsLing: Novel sentences: \u201CArgentina's new president choked on a fake moustache\u00A0he\u00A0was wearing as part of a Freddie ... https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/rc4rvIluq9",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv240VJa",
        "display_url" : "tmblr.co\/ZuWOEv240VJa"
      } ]
    },
    "geo" : { },
    "id_str" : "713855628209483777",
    "text" : "Novel sentences: \u201CArgentina's new president choked on a fake moustache\u00A0he\u00A0was wearing as part of a Freddie ... https:\/\/t.co\/rc4rvIluq9",
    "id" : 713855628209483777,
    "created_at" : "2016-03-26 22:30:19 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 713994668170719233,
  "created_at" : "2016-03-27 07:42:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 3, 14 ],
      "id_str" : "21158543",
      "id" : 21158543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/MR5y2BnnGx",
      "expanded_url" : "https:\/\/twitter.com\/induswaliarch\/status\/713445111091306500",
      "display_url" : "twitter.com\/induswaliarch\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713849865109954561",
  "text" : "RT @mixosaurus: Goldsmith seeking to exploit Hindu &amp; Muslim divisions with a side order of racial stereotyping https:\/\/t.co\/MR5y2BnnGx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/MR5y2BnnGx",
        "expanded_url" : "https:\/\/twitter.com\/induswaliarch\/status\/713445111091306500",
        "display_url" : "twitter.com\/induswaliarch\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "713790677100937216",
    "text" : "Goldsmith seeking to exploit Hindu &amp; Muslim divisions with a side order of racial stereotyping https:\/\/t.co\/MR5y2BnnGx",
    "id" : 713790677100937216,
    "created_at" : "2016-03-26 18:12:13 +0000",
    "user" : {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "protected" : false,
      "id_str" : "21158543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497125168477523970\/a60pRivO_normal.png",
      "id" : 21158543,
      "verified" : false
    }
  },
  "id" : 713849865109954561,
  "created_at" : "2016-03-26 22:07:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "indices" : [ 73, 87 ],
      "id_str" : "3187104424",
      "id" : 3187104424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/LGsuO4iLtc",
      "expanded_url" : "https:\/\/grammarianism.wordpress.com\/2016\/03\/26\/grammar-in-schools-some-qas-and-a-plea\/",
      "display_url" : "grammarianism.wordpress.com\/2016\/03\/26\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713737683894407169",
  "text" : "Grammar in schools: some Q&amp;As and a plea https:\/\/t.co\/LGsuO4iLtc via @EngliciousUCL",
  "id" : 713737683894407169,
  "created_at" : "2016-03-26 14:41:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 116, 132 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/5KO1LfjCYP",
      "expanded_url" : "http:\/\/pdcinmfl.com\/",
      "display_url" : "pdcinmfl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "713717044093562880",
  "text" : "interesting project The Professional Development Consortium in Modern Foreign Languages https:\/\/t.co\/5KO1LfjCYP via @gianfrancocont9",
  "id" : 713717044093562880,
  "created_at" : "2016-03-26 13:19:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Alper",
      "screen_name" : "ThatEricAlper",
      "indices" : [ 3, 17 ],
      "id_str" : "22018221",
      "id" : 22018221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Z9GhV6JCL1",
      "expanded_url" : "http:\/\/wp.me\/p26Qb8-gzR",
      "display_url" : "wp.me\/p26Qb8-gzR"
    } ]
  },
  "geo" : { },
  "id_str" : "713494179498868737",
  "text" : "RT @ThatEricAlper: Lou Reed's 'Walk On The Wild Side' Phonetically Replicated By Twitter Usernames: https:\/\/t.co\/Z9GhV6JCL1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Z9GhV6JCL1",
        "expanded_url" : "http:\/\/wp.me\/p26Qb8-gzR",
        "display_url" : "wp.me\/p26Qb8-gzR"
      } ]
    },
    "geo" : { },
    "id_str" : "710209149620113408",
    "text" : "Lou Reed's 'Walk On The Wild Side' Phonetically Replicated By Twitter Usernames: https:\/\/t.co\/Z9GhV6JCL1",
    "id" : 710209149620113408,
    "created_at" : "2016-03-16 21:00:30 +0000",
    "user" : {
      "name" : "Eric Alper",
      "screen_name" : "ThatEricAlper",
      "protected" : false,
      "id_str" : "22018221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652285840962519040\/BNchJKJh_normal.jpg",
      "id" : 22018221,
      "verified" : false
    }
  },
  "id" : 713494179498868737,
  "created_at" : "2016-03-25 22:34:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 18, 27 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 28, 41 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeaquotetesl",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713464345074802688",
  "text" : "RT @nathanghall: .@muranava @tesolmatthew \"Grammar is not caused. It is.\" - a misquoted Emily Dickinson #makeaquotetesl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 1, 10 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Matthew Noble",
        "screen_name" : "tesolmatthew",
        "indices" : [ 11, 24 ],
        "id_str" : "1519875330",
        "id" : 1519875330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "makeaquotetesl",
        "indices" : [ 87, 102 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "713460085373140992",
    "geo" : { },
    "id_str" : "713464104858439681",
    "in_reply_to_user_id" : 18602422,
    "text" : ".@muranava @tesolmatthew \"Grammar is not caused. It is.\" - a misquoted Emily Dickinson #makeaquotetesl",
    "id" : 713464104858439681,
    "in_reply_to_status_id" : 713460085373140992,
    "created_at" : "2016-03-25 20:34:32 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 713464345074802688,
  "created_at" : "2016-03-25 20:35:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/3qdLKlhon9",
      "expanded_url" : "https:\/\/raw.githubusercontent.com\/alvations\/Quotables\/master\/author-quote.txt",
      "display_url" : "raw.githubusercontent.com\/alvations\/Quot\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713459212408504320",
  "geo" : { },
  "id_str" : "713460085373140992",
  "in_reply_to_user_id" : 18602422,
  "text" : "@tesolmatthew a quote corpus here https:\/\/t.co\/3qdLKlhon9",
  "id" : 713460085373140992,
  "in_reply_to_status_id" : 713459212408504320,
  "created_at" : "2016-03-25 20:18:34 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeAQuoteTESL",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713456561734160384",
  "geo" : { },
  "id_str" : "713459212408504320",
  "in_reply_to_user_id" : 18602422,
  "text" : "@tesolmatthew The rule is, grammar tomorrow and grammar yesterday - but never grammar today. (Michael) Lewis Carrol #MakeAQuoteTESL",
  "id" : 713459212408504320,
  "in_reply_to_status_id" : 713456561734160384,
  "created_at" : "2016-03-25 20:15:06 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 14, 25 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 26, 41 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeAQuoteTESL",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713441916520570880",
  "geo" : { },
  "id_str" : "713456561734160384",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @leoselivan @thornburyscott or #MakeAQuoteTESL?",
  "id" : 713456561734160384,
  "in_reply_to_status_id" : 713441916520570880,
  "created_at" : "2016-03-25 20:04:34 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/713450284673052672\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/Ntuy8YjaYP",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CeavJ_AWsAQ_PWC.jpg",
      "id_str" : "713450177051406340",
      "id" : 713450177051406340,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CeavJ_AWsAQ_PWC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Ntuy8YjaYP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713439899349868545",
  "geo" : { },
  "id_str" : "713450284673052672",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan seems so https:\/\/t.co\/Ntuy8YjaYP",
  "id" : 713450284673052672,
  "in_reply_to_status_id" : 713439899349868545,
  "created_at" : "2016-03-25 19:39:37 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DiscourseNet",
      "screen_name" : "DiscourseNet",
      "indices" : [ 0, 13 ],
      "id_str" : "2747657225",
      "id" : 2747657225
    }, {
      "name" : "UniversidadDeNavarra",
      "screen_name" : "unav",
      "indices" : [ 14, 19 ],
      "id_str" : "17152842",
      "id" : 17152842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712964152990502912",
  "geo" : { },
  "id_str" : "713360860270428160",
  "in_reply_to_user_id" : 2747657225,
  "text" : "@DiscourseNet @unav guess it is not publically available?",
  "id" : 713360860270428160,
  "in_reply_to_status_id" : 712964152990502912,
  "created_at" : "2016-03-25 13:44:17 +0000",
  "in_reply_to_screen_name" : "DiscourseNet",
  "in_reply_to_user_id_str" : "2747657225",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajib Ahmed",
      "screen_name" : "kajolvomora",
      "indices" : [ 3, 15 ],
      "id_str" : "95624725",
      "id" : 95624725
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hello",
      "indices" : [ 17, 23 ]
    }, {
      "text" : "research",
      "indices" : [ 67, 76 ]
    }, {
      "text" : "publishing",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "productivity",
      "indices" : [ 89, 102 ]
    }, {
      "text" : "creativity",
      "indices" : [ 103, 114 ]
    }, {
      "text" : "elt",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "dhaka",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/4nCELLlN1u",
      "expanded_url" : "https:\/\/youtu.be\/qgexboNXV-Q",
      "display_url" : "youtu.be\/qgexboNXV-Q"
    } ]
  },
  "geo" : { },
  "id_str" : "713357337185161217",
  "text" : "RT @kajolvomora: #Hello (Academic Version) https:\/\/t.co\/4nCELLlN1u #research #publishing #productivity #creativity #elt #dhaka",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hello",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "research",
        "indices" : [ 50, 59 ]
      }, {
        "text" : "publishing",
        "indices" : [ 60, 71 ]
      }, {
        "text" : "productivity",
        "indices" : [ 72, 85 ]
      }, {
        "text" : "creativity",
        "indices" : [ 86, 97 ]
      }, {
        "text" : "elt",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "dhaka",
        "indices" : [ 103, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/4nCELLlN1u",
        "expanded_url" : "https:\/\/youtu.be\/qgexboNXV-Q",
        "display_url" : "youtu.be\/qgexboNXV-Q"
      } ]
    },
    "geo" : { },
    "id_str" : "713356596231991296",
    "text" : "#Hello (Academic Version) https:\/\/t.co\/4nCELLlN1u #research #publishing #productivity #creativity #elt #dhaka",
    "id" : 713356596231991296,
    "created_at" : "2016-03-25 13:27:20 +0000",
    "user" : {
      "name" : "Rajib Ahmed",
      "screen_name" : "kajolvomora",
      "protected" : false,
      "id_str" : "95624725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625776258966622208\/jXp5VtIV_normal.jpg",
      "id" : 95624725,
      "verified" : false
    }
  },
  "id" : 713357337185161217,
  "created_at" : "2016-03-25 13:30:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 12, 27 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713345300749021184",
  "geo" : { },
  "id_str" : "713356238625640448",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @thornburyscott were u pleased to say that or is that a Murphy in your pocket : )",
  "id" : 713356238625640448,
  "in_reply_to_status_id" : 713345300749021184,
  "created_at" : "2016-03-25 13:25:55 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 0, 9 ],
      "id_str" : "364412485",
      "id" : 364412485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713330403566874624",
  "geo" : { },
  "id_str" : "713333457099833345",
  "in_reply_to_user_id" : 364412485,
  "text" : "@_dr_kim_ another reason to question utility of native\/nonnative distinctions?",
  "id" : 713333457099833345,
  "in_reply_to_status_id" : 713330403566874624,
  "created_at" : "2016-03-25 11:55:23 +0000",
  "in_reply_to_screen_name" : "_dr_kim_",
  "in_reply_to_user_id_str" : "364412485",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/21AWopPrDR",
      "expanded_url" : "https:\/\/www.britishcouncil.org\/voices-magazine\/how-reform-university-english-language-department",
      "display_url" : "britishcouncil.org\/voices-magazin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713206248577978368",
  "geo" : { },
  "id_str" : "713226459620503553",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith  just not cricket old boy not like how it should be done https:\/\/t.co\/21AWopPrDR dam yankees",
  "id" : 713226459620503553,
  "in_reply_to_status_id" : 713206248577978368,
  "created_at" : "2016-03-25 04:50:13 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted O'Neill (DB-\u7ADC\u725B)",
      "screen_name" : "gotanda",
      "indices" : [ 0, 8 ],
      "id_str" : "9875912",
      "id" : 9875912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713156657639886848",
  "geo" : { },
  "id_str" : "713158496351600640",
  "in_reply_to_user_id" : 9875912,
  "text" : "@gotanda those keys were boss",
  "id" : 713158496351600640,
  "in_reply_to_status_id" : 713156657639886848,
  "created_at" : "2016-03-25 00:20:10 +0000",
  "in_reply_to_screen_name" : "gotanda",
  "in_reply_to_user_id_str" : "9875912",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 0, 7 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713128258607390720",
  "geo" : { },
  "id_str" : "713158124765622276",
  "in_reply_to_user_id" : 20536157,
  "text" : "@google good on you! can, while u are at it can you apply \"equal rights &amp; equal treatment\" for your tax obligations? kthxbai",
  "id" : 713158124765622276,
  "in_reply_to_status_id" : 713128258607390720,
  "created_at" : "2016-03-25 00:18:41 +0000",
  "in_reply_to_screen_name" : "google",
  "in_reply_to_user_id_str" : "20536157",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SGI Tesol Training",
      "screen_name" : "TesolTrainingUK",
      "indices" : [ 79, 95 ],
      "id_str" : "353681537",
      "id" : 353681537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/ovmdIS5BwG",
      "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/uncategorized\/tefl-how-to-record-student-improvement-objectively\/",
      "display_url" : "tesoltraining.co.uk\/blog\/uncategor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713126002000584704",
  "text" : "TEFL how to record student improvement objectively https:\/\/t.co\/ovmdIS5BwG via @TesolTrainingUk",
  "id" : 713126002000584704,
  "created_at" : "2016-03-24 22:11:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713108933955686402",
  "geo" : { },
  "id_str" : "713109286365372417",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo u have great twitter literacy is there a college for that? : )",
  "id" : 713109286365372417,
  "in_reply_to_status_id" : 713108933955686402,
  "created_at" : "2016-03-24 21:04:37 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 3, 12 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/i4u6Z38aFQ",
      "expanded_url" : "https:\/\/twitter.com\/alexislloyd\/status\/713099394837585920",
      "display_url" : "twitter.com\/alexislloyd\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713108346325348352",
  "text" : "RT @aparrish: this is a great post. \"stop trying to make bots act like people\" is really good advice https:\/\/t.co\/i4u6Z38aFQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/i4u6Z38aFQ",
        "expanded_url" : "https:\/\/twitter.com\/alexislloyd\/status\/713099394837585920",
        "display_url" : "twitter.com\/alexislloyd\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "713104384524161025",
    "text" : "this is a great post. \"stop trying to make bots act like people\" is really good advice https:\/\/t.co\/i4u6Z38aFQ",
    "id" : 713104384524161025,
    "created_at" : "2016-03-24 20:45:08 +0000",
    "user" : {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "protected" : false,
      "id_str" : "6857962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753298903072641024\/J2ItyKut_normal.jpg",
      "id" : 6857962,
      "verified" : false
    }
  },
  "id" : 713108346325348352,
  "created_at" : "2016-03-24 21:00:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CaSMa Research",
      "screen_name" : "CaSMaResearch",
      "indices" : [ 42, 56 ],
      "id_str" : "2797652043",
      "id" : 2797652043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/72yuOOpoHQ",
      "expanded_url" : "http:\/\/casma.wp.horizon.ac.uk\/2016\/03\/24\/apple-vs-fbi\/",
      "display_url" : "casma.wp.horizon.ac.uk\/2016\/03\/24\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713034286069387264",
  "text" : "Apple vs. FBI https:\/\/t.co\/72yuOOpoHQ via @CaSMaResearch",
  "id" : 713034286069387264,
  "created_at" : "2016-03-24 16:06:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/712990602816851968\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/IY3BSkr7sA",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CeUNDfgW4AATiXt.jpg",
      "id_str" : "712990469656076288",
      "id" : 712990469656076288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CeUNDfgW4AATiXt.jpg",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 294
      } ],
      "display_url" : "pic.twitter.com\/IY3BSkr7sA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712989087888748546",
  "geo" : { },
  "id_str" : "712990602816851968",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle not this either? dat disappoint son : ) https:\/\/t.co\/IY3BSkr7sA",
  "id" : 712990602816851968,
  "in_reply_to_status_id" : 712989087888748546,
  "created_at" : "2016-03-24 13:13:01 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/3N3JSWMKja",
      "expanded_url" : "https:\/\/twitter.com\/Jonathan_K_Cook\/status\/712965776425271297",
      "display_url" : "twitter.com\/Jonathan_K_Coo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712980720340377600",
  "text" : "RT @medialens: The truth of Isis in a single, forbidden sentence: 'We and our unquenchable greed created this monster.' https:\/\/t.co\/3N3JSW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/3N3JSWMKja",
        "expanded_url" : "https:\/\/twitter.com\/Jonathan_K_Cook\/status\/712965776425271297",
        "display_url" : "twitter.com\/Jonathan_K_Coo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712970950829072384",
    "text" : "The truth of Isis in a single, forbidden sentence: 'We and our unquenchable greed created this monster.' https:\/\/t.co\/3N3JSWMKja",
    "id" : 712970950829072384,
    "created_at" : "2016-03-24 11:54:55 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 712980720340377600,
  "created_at" : "2016-03-24 12:33:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Heart ELT",
      "screen_name" : "Heart_ELT",
      "indices" : [ 24, 34 ],
      "id_str" : "4299874096",
      "id" : 4299874096
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/712979223867211777\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/oVSZ1Rfa1b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeUC00IWwAEwbm6.jpg",
      "id_str" : "712979222378233857",
      "id" : 712979222378233857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeUC00IWwAEwbm6.jpg",
      "sizes" : [ {
        "h" : 849,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1449,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1447
      } ],
      "display_url" : "pic.twitter.com\/oVSZ1Rfa1b"
    } ],
    "hashtags" : [ {
      "text" : "grassroots",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "ELT",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "refugee",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712980417742315520",
  "text" : "RT @josipa74: Well done @Heart_ELT  for their #grassroots project 'A-Z of Hope' - #ELT activities for #refugee children! https:\/\/t.co\/oVSZ1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heart ELT",
        "screen_name" : "Heart_ELT",
        "indices" : [ 10, 20 ],
        "id_str" : "4299874096",
        "id" : 4299874096
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/712979223867211777\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/oVSZ1Rfa1b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeUC00IWwAEwbm6.jpg",
        "id_str" : "712979222378233857",
        "id" : 712979222378233857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeUC00IWwAEwbm6.jpg",
        "sizes" : [ {
          "h" : 849,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1449,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1447
        } ],
        "display_url" : "pic.twitter.com\/oVSZ1Rfa1b"
      } ],
      "hashtags" : [ {
        "text" : "grassroots",
        "indices" : [ 32, 43 ]
      }, {
        "text" : "ELT",
        "indices" : [ 68, 72 ]
      }, {
        "text" : "refugee",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712979223867211777",
    "text" : "Well done @Heart_ELT  for their #grassroots project 'A-Z of Hope' - #ELT activities for #refugee children! https:\/\/t.co\/oVSZ1Rfa1b",
    "id" : 712979223867211777,
    "created_at" : "2016-03-24 12:27:48 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 712980417742315520,
  "created_at" : "2016-03-24 12:32:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik Lukes",
      "screen_name" : "techczech",
      "indices" : [ 0, 10 ],
      "id_str" : "29427973",
      "id" : 29427973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/HC3fckWZ7S",
      "expanded_url" : "http:\/\/arxiv.org\/ftp\/arxiv\/papers\/0809\/0809.5250.pdf",
      "display_url" : "arxiv.org\/ftp\/arxiv\/pape\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "711882382111088644",
  "geo" : { },
  "id_str" : "712978431584108544",
  "in_reply_to_user_id" : 29427973,
  "text" : "@techczech strange that low citation papers in humanities is taken for all science? https:\/\/t.co\/HC3fckWZ7S",
  "id" : 712978431584108544,
  "in_reply_to_status_id" : 711882382111088644,
  "created_at" : "2016-03-24 12:24:39 +0000",
  "in_reply_to_screen_name" : "techczech",
  "in_reply_to_user_id_str" : "29427973",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stu.",
      "screen_name" : "dysondoc",
      "indices" : [ 3, 12 ],
      "id_str" : "947708048",
      "id" : 947708048
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dysondoc\/status\/712907038834171905\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/RTeQ2KGr02",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeTBLHwWAAAMHCi.jpg",
      "id_str" : "712907037835919360",
      "id" : 712907037835919360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeTBLHwWAAAMHCi.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/RTeQ2KGr02"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712971289552617472",
  "text" : "RT @dysondoc: Imagine the trouble she has trying to introduce herself in France. https:\/\/t.co\/RTeQ2KGr02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dysondoc\/status\/712907038834171905\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/RTeQ2KGr02",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeTBLHwWAAAMHCi.jpg",
        "id_str" : "712907037835919360",
        "id" : 712907037835919360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeTBLHwWAAAMHCi.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 405
        } ],
        "display_url" : "pic.twitter.com\/RTeQ2KGr02"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712907038834171905",
    "text" : "Imagine the trouble she has trying to introduce herself in France. https:\/\/t.co\/RTeQ2KGr02",
    "id" : 712907038834171905,
    "created_at" : "2016-03-24 07:40:57 +0000",
    "user" : {
      "name" : "Stu.",
      "screen_name" : "dysondoc",
      "protected" : false,
      "id_str" : "947708048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678470530132000769\/nW_pz0om_normal.jpg",
      "id" : 947708048,
      "verified" : false
    }
  },
  "id" : 712971289552617472,
  "created_at" : "2016-03-24 11:56:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Brussels",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "BrusselsAttacks",
      "indices" : [ 111, 127 ]
    }, {
      "text" : "Nato",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/0q6dUp9oTq",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2016\/03\/brussels-attacks-no-live-media-outside.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2016\/03\/brusse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712964714066755585",
  "text" : "RT @johnwhilley: Brussels attacks: no live media outside Nato's terror base  https:\/\/t.co\/0q6dUp9oTq #Brussels #BrusselsAttacks #Nato",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Brussels",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "BrusselsAttacks",
        "indices" : [ 94, 110 ]
      }, {
        "text" : "Nato",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/0q6dUp9oTq",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2016\/03\/brussels-attacks-no-live-media-outside.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2016\/03\/brusse\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712963440831279104",
    "text" : "Brussels attacks: no live media outside Nato's terror base  https:\/\/t.co\/0q6dUp9oTq #Brussels #BrusselsAttacks #Nato",
    "id" : 712963440831279104,
    "created_at" : "2016-03-24 11:25:05 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 712964714066755585,
  "created_at" : "2016-03-24 11:30:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712955844997079040",
  "text" : "one upside of going through recovered files after disk crash is finding interesting forgotten texts",
  "id" : 712955844997079040,
  "created_at" : "2016-03-24 10:54:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "indices" : [ 53, 64 ],
      "id_str" : "402209787",
      "id" : 402209787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/AQgihEYd83",
      "expanded_url" : "http:\/\/patthomson.net\/2016\/03\/24\/holiday-strategy-get-to-know-your-acwri-history\/",
      "display_url" : "patthomson.net\/2016\/03\/24\/hol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712939767726522368",
  "text" : "the perils of provenance https:\/\/t.co\/AQgihEYd83 via @ThomsonPat",
  "id" : 712939767726522368,
  "created_at" : "2016-03-24 09:51:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/712781295676481538\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/EUGBJAxb7E",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CeROy9MWQAA2Ogl.jpg",
      "id_str" : "712781278358159360",
      "id" : 712781278358159360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CeROy9MWQAA2Ogl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/EUGBJAxb7E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712777210831183872",
  "geo" : { },
  "id_str" : "712781295676481538",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch great thx https:\/\/t.co\/EUGBJAxb7E",
  "id" : 712781295676481538,
  "in_reply_to_status_id" : 712777210831183872,
  "created_at" : "2016-03-23 23:21:18 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 83, 91 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/bXH9ySv5lm",
      "expanded_url" : "https:\/\/youtu.be\/WSDSWPWFkXU",
      "display_url" : "youtu.be\/WSDSWPWFkXU"
    } ]
  },
  "geo" : { },
  "id_str" : "712780807618883584",
  "text" : "Josef Fruehwald : Prolegomena to a Grammar of Knitting https:\/\/t.co\/bXH9ySv5lm via @YouTube lol'd some of this but most went over me head :)",
  "id" : 712780807618883584,
  "created_at" : "2016-03-23 23:19:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 48, 58 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/CozArADK3o",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/03\/23\/finding-how-to-lose\/",
      "display_url" : "samkriss.wordpress.com\/2016\/03\/23\/fin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712779306884272128",
  "text" : "Finding how to lose https:\/\/t.co\/CozArADK3o via @sam_kriss",
  "id" : 712779306884272128,
  "created_at" : "2016-03-23 23:13:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712776614933897216",
  "geo" : { },
  "id_str" : "712777036545331200",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch when u download that file it is labelled with no;, title,author label would be cool save me time renaming : )",
  "id" : 712777036545331200,
  "in_reply_to_status_id" : 712776614933897216,
  "created_at" : "2016-03-23 23:04:22 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 10, 18 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712690514961833988",
  "geo" : { },
  "id_str" : "712776317712916480",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @seburnt ta Tyson : )",
  "id" : 712776317712916480,
  "in_reply_to_status_id" : 712690514961833988,
  "created_at" : "2016-03-23 23:01:31 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712771774027599874",
  "geo" : { },
  "id_str" : "712772139716362240",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson oh cool thanks : )",
  "id" : 712772139716362240,
  "in_reply_to_status_id" : 712771774027599874,
  "created_at" : "2016-03-23 22:44:55 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 10, 21 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712690514961833988",
  "geo" : { },
  "id_str" : "712771154260455424",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @JenMac_ESL thanks for sharing : )",
  "id" : 712771154260455424,
  "in_reply_to_status_id" : 712690514961833988,
  "created_at" : "2016-03-23 22:41:00 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 31, 40 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712766445550182400",
  "geo" : { },
  "id_str" : "712767594651062272",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish @SueAnnan maybe Marc is thinking about  qualitative evidence?",
  "id" : 712767594651062272,
  "in_reply_to_status_id" : 712766445550182400,
  "created_at" : "2016-03-23 22:26:51 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 31, 40 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712766445550182400",
  "geo" : { },
  "id_str" : "712767188919316480",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish @SueAnnan law of small numbers?",
  "id" : 712767188919316480,
  "in_reply_to_status_id" : 712766445550182400,
  "created_at" : "2016-03-23 22:25:15 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/712732814043688960\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/7DVr6nOOSU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeQitbDWIAA-zNA.jpg",
      "id_str" : "712732804782628864",
      "id" : 712732804782628864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeQitbDWIAA-zNA.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/7DVr6nOOSU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712732814043688960",
  "text" : "Social media overload with multi window on Marshmellow https:\/\/t.co\/7DVr6nOOSU",
  "id" : 712732814043688960,
  "created_at" : "2016-03-23 20:08:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 101, 117 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 118, 130 ],
      "id_str" : "319110295",
      "id" : 319110295
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lovermob\/status\/712671470456029184\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DONjTO8wek",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CePq7PTWIAEpFjX.jpg",
      "id_str" : "712671469495525377",
      "id" : 712671469495525377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CePq7PTWIAEpFjX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DONjTO8wek"
    } ],
    "hashtags" : [ {
      "text" : "BNC2014",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712721930630119424",
  "text" : "RT @lovermob: Work and food: The most prominent Spoken #BNC2014 conversation topics in recent months @CorpusSocialSci @CambridgeUP https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 87, 103 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      }, {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 104, 116 ],
        "id_str" : "319110295",
        "id" : 319110295
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lovermob\/status\/712671470456029184\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DONjTO8wek",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CePq7PTWIAEpFjX.jpg",
        "id_str" : "712671469495525377",
        "id" : 712671469495525377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CePq7PTWIAEpFjX.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DONjTO8wek"
      } ],
      "hashtags" : [ {
        "text" : "BNC2014",
        "indices" : [ 41, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712671470456029184",
    "text" : "Work and food: The most prominent Spoken #BNC2014 conversation topics in recent months @CorpusSocialSci @CambridgeUP https:\/\/t.co\/DONjTO8wek",
    "id" : 712671470456029184,
    "created_at" : "2016-03-23 16:04:54 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 712721930630119424,
  "created_at" : "2016-03-23 19:25:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712690514961833988",
  "geo" : { },
  "id_str" : "712707917569458176",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @HadaLitim thanks Hada : )",
  "id" : 712707917569458176,
  "in_reply_to_status_id" : 712690514961833988,
  "created_at" : "2016-03-23 18:29:43 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 0, 9 ],
      "id_str" : "364412485",
      "id" : 364412485
    }, {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 10, 18 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711980956417171456",
  "geo" : { },
  "id_str" : "712707481550655488",
  "in_reply_to_user_id" : 364412485,
  "text" : "@_dr_kim_ @NNgroup ...from my RSI wristed hands : )",
  "id" : 712707481550655488,
  "in_reply_to_status_id" : 711980956417171456,
  "created_at" : "2016-03-23 18:27:59 +0000",
  "in_reply_to_screen_name" : "_dr_kim_",
  "in_reply_to_user_id_str" : "364412485",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712688484302135296",
  "geo" : { },
  "id_str" : "712690929862356992",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher will have to investigate thx",
  "id" : 712690929862356992,
  "in_reply_to_status_id" : 712688484302135296,
  "created_at" : "2016-03-23 17:22:13 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/1gSRFcHvdu",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/wordlists\/",
      "display_url" : "eflnotes.wordpress.com\/wordlists\/"
    } ]
  },
  "geo" : { },
  "id_str" : "712690514961833988",
  "text" : "Engineering Academic Formulas List 2015 added to wordlists https:\/\/t.co\/1gSRFcHvdu",
  "id" : 712690514961833988,
  "created_at" : "2016-03-23 17:20:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol16",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/O76kNI6WvE",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/EE8t39U9NV7",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712684403533750272",
  "text" : "#tesol16 corpus related talks https:\/\/t.co\/O76kNI6WvE",
  "id" : 712684403533750272,
  "created_at" : "2016-03-23 16:56:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    }, {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "indices" : [ 12, 19 ],
      "id_str" : "16817883",
      "id" : 16817883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712658034640744449",
  "geo" : { },
  "id_str" : "712672858972037120",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist @scifri that's some eggcellent advice : )",
  "id" : 712672858972037120,
  "in_reply_to_status_id" : 712658034640744449,
  "created_at" : "2016-03-23 16:10:25 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Quizlet",
      "screen_name" : "quizlet",
      "indices" : [ 16, 24 ],
      "id_str" : "19879256",
      "id" : 19879256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712663202467823617",
  "geo" : { },
  "id_str" : "712664044247891968",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @quizlet what does it do?",
  "id" : 712664044247891968,
  "in_reply_to_status_id" : 712663202467823617,
  "created_at" : "2016-03-23 15:35:23 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712661419095957505",
  "geo" : { },
  "id_str" : "712663760842964992",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch thx, have u considered user friendly pdf titles for download instead of numbers?",
  "id" : 712663760842964992,
  "in_reply_to_status_id" : 712661419095957505,
  "created_at" : "2016-03-23 15:34:15 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/712649984601112581\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/LNApwCn4rr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CePXXx_WEAQlI-N.jpg",
      "id_str" : "712649969610657796",
      "id" : 712649969610657796,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CePXXx_WEAQlI-N.jpg",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/LNApwCn4rr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712649387365806080",
  "geo" : { },
  "id_str" : "712649984601112581",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura https:\/\/t.co\/LNApwCn4rr",
  "id" : 712649984601112581,
  "in_reply_to_status_id" : 712649387365806080,
  "created_at" : "2016-03-23 14:39:31 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712647038215839745",
  "geo" : { },
  "id_str" : "712649269153542145",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura :(",
  "id" : 712649269153542145,
  "in_reply_to_status_id" : 712647038215839745,
  "created_at" : "2016-03-23 14:36:40 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Flores",
      "screen_name" : "nelsonlflores",
      "indices" : [ 3, 17 ],
      "id_str" : "248343882",
      "id" : 248343882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712632567816667136",
  "text" : "RT @nelsonlflores: The media is so impressed by Malia Obama translating for her father. I wish they realized immigrant children do this all\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712617528976142336",
    "text" : "The media is so impressed by Malia Obama translating for her father. I wish they realized immigrant children do this all the time.",
    "id" : 712617528976142336,
    "created_at" : "2016-03-23 12:30:33 +0000",
    "user" : {
      "name" : "Nelson Flores",
      "screen_name" : "nelsonlflores",
      "protected" : false,
      "id_str" : "248343882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765210656652025856\/Fjr5rQXh_normal.jpg",
      "id" : 248343882,
      "verified" : false
    }
  },
  "id" : 712632567816667136,
  "created_at" : "2016-03-23 13:30:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan",
      "screen_name" : "DanSaunders151",
      "indices" : [ 3, 18 ],
      "id_str" : "610147513",
      "id" : 610147513
    }, {
      "name" : "Ern Malley",
      "screen_name" : "trewloy",
      "indices" : [ 20, 28 ],
      "id_str" : "3499936877",
      "id" : 3499936877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712631985051725824",
  "text" : "RT @DanSaunders151: @trewloy I asked a quaker eating porridge if he was enjoying breakfast. \"nomnombeyeahnomsgoodnom\" he said.  A typically\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ern Malley",
        "screen_name" : "trewloy",
        "indices" : [ 0, 8 ],
        "id_str" : "3499936877",
        "id" : 3499936877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "712571296371052544",
    "geo" : { },
    "id_str" : "712573898605338625",
    "in_reply_to_user_id" : 3499936877,
    "text" : "@trewloy I asked a quaker eating porridge if he was enjoying breakfast. \"nomnombeyeahnomsgoodnom\" he said.  A typically mealy mouthed reply.",
    "id" : 712573898605338625,
    "in_reply_to_status_id" : 712571296371052544,
    "created_at" : "2016-03-23 09:37:11 +0000",
    "in_reply_to_screen_name" : "trewloy",
    "in_reply_to_user_id_str" : "3499936877",
    "user" : {
      "name" : "Dan",
      "screen_name" : "DanSaunders151",
      "protected" : false,
      "id_str" : "610147513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636850958924926976\/vk4-QhF1_normal.jpg",
      "id" : 610147513,
      "verified" : false
    }
  },
  "id" : 712631985051725824,
  "created_at" : "2016-03-23 13:27:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 3, 14 ],
      "id_str" : "288409122",
      "id" : 288409122
    }, {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 76, 87 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/gWofapbEKD",
      "expanded_url" : "http:\/\/infernalmachine.co.uk\/bombing-the-grey-zone\/",
      "display_url" : "infernalmachine.co.uk\/bombing-the-gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712626573527138304",
  "text" : "RT @MattCarr55: Brussels: Bombing the Grey Zone https:\/\/t.co\/gWofapbEKD via @MattCarr55",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Carr",
        "screen_name" : "MattCarr55",
        "indices" : [ 60, 71 ],
        "id_str" : "288409122",
        "id" : 288409122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/gWofapbEKD",
        "expanded_url" : "http:\/\/infernalmachine.co.uk\/bombing-the-grey-zone\/",
        "display_url" : "infernalmachine.co.uk\/bombing-the-gr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712605902331908096",
    "text" : "Brussels: Bombing the Grey Zone https:\/\/t.co\/gWofapbEKD via @MattCarr55",
    "id" : 712605902331908096,
    "created_at" : "2016-03-23 11:44:21 +0000",
    "user" : {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "protected" : false,
      "id_str" : "288409122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708018901335085058\/-SENrQyC_normal.jpg",
      "id" : 288409122,
      "verified" : false
    }
  },
  "id" : 712626573527138304,
  "created_at" : "2016-03-23 13:06:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/6RyRRE1LJ9",
      "expanded_url" : "https:\/\/github.com\/tastyminerals\/nn_search2",
      "display_url" : "github.com\/tastyminerals\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712594947275366401",
  "text" : "nn-search2 nice tool for profiling text by POS https:\/\/t.co\/6RyRRE1LJ9 #corpusresources",
  "id" : 712594947275366401,
  "created_at" : "2016-03-23 11:00:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/tnhmXr3SzH",
      "expanded_url" : "https:\/\/www.greenleft.org.au\/node\/61400",
      "display_url" : "greenleft.org.au\/node\/61400"
    } ]
  },
  "geo" : { },
  "id_str" : "712590398955397120",
  "text" : "RT @medialens: John Pilger: A world war has begun - break the silence https:\/\/t.co\/tnhmXr3SzH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/tnhmXr3SzH",
        "expanded_url" : "https:\/\/www.greenleft.org.au\/node\/61400",
        "display_url" : "greenleft.org.au\/node\/61400"
      } ]
    },
    "geo" : { },
    "id_str" : "712553638141497344",
    "text" : "John Pilger: A world war has begun - break the silence https:\/\/t.co\/tnhmXr3SzH",
    "id" : 712553638141497344,
    "created_at" : "2016-03-23 08:16:40 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 712590398955397120,
  "created_at" : "2016-03-23 10:42:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 12, 27 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KWD8Iap4ph",
      "expanded_url" : "http:\/\/web.archive.org\/web\/20160323070730\/https:\/\/criticalelt.wordpress.com\/2016\/03\/22\/will-you-wont-you-will-you-wont-you-wont-you-join-the-dance\/",
      "display_url" : "web.archive.org\/web\/2016032307\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712542926476337153",
  "geo" : { },
  "id_str" : "712543478585106432",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @GeoffreyJordan hmm looks like Geoff has pulled it? a copy here https:\/\/t.co\/KWD8Iap4ph",
  "id" : 712543478585106432,
  "in_reply_to_status_id" : 712542926476337153,
  "created_at" : "2016-03-23 07:36:18 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/A3DOikUCEY",
      "expanded_url" : "http:\/\/image.slidesharecdn.com\/academia-150812200559-lva1-app6892\/95\/academia-28-638.jpg?cb=1439410281",
      "display_url" : "image.slidesharecdn.com\/academia-15081\u2026"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BiKnE8HRYg",
      "expanded_url" : "http:\/\/www.slideshare.net\/geraldcarter1\/academia-51559796",
      "display_url" : "slideshare.net\/geraldcarter1\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712534254920531970",
  "geo" : { },
  "id_str" : "712535144897372161",
  "in_reply_to_user_id" : 18602422,
  "text" : "@GeoffreyJordan re academia have u seen this table Geoff?https:\/\/t.co\/A3DOikUCEY it's from this slideshow https:\/\/t.co\/BiKnE8HRYg",
  "id" : 712535144897372161,
  "in_reply_to_status_id" : 712534254920531970,
  "created_at" : "2016-03-23 07:03:11 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 96, 111 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/kgzwFfkWi4",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/22\/will-you-wont-you-will-you-wont-you-wont-you-join-the-dance\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/22\/wil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712534254920531970",
  "text" : "Will you, won't you, will you, won't you, won't you join the dance? https:\/\/t.co\/kgzwFfkWi4 via @GeoffreyJordan",
  "id" : 712534254920531970,
  "created_at" : "2016-03-23 06:59:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Autumn Westphal",
      "screen_name" : "autumnwestphal",
      "indices" : [ 0, 15 ],
      "id_str" : "3118586194",
      "id" : 3118586194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712307361709498368",
  "geo" : { },
  "id_str" : "712309371229888512",
  "in_reply_to_user_id" : 3118586194,
  "text" : "@autumnwestphal not read it yet, read a few of his papers at uni",
  "id" : 712309371229888512,
  "in_reply_to_status_id" : 712307361709498368,
  "created_at" : "2016-03-22 16:06:02 +0000",
  "in_reply_to_screen_name" : "autumnwestphal",
  "in_reply_to_user_id_str" : "3118586194",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 75, 91 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/jdQPbSxXjo",
      "expanded_url" : "http:\/\/educationbookcast.com\/2016\/03\/21\/11-thinking-fast-and-slow-by-daniel-kahneman\/",
      "display_url" : "educationbookcast.com\/2016\/03\/21\/11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712306224289685504",
  "text" : "11. Thinking, Fast and Slow by Daniel Kahneman https:\/\/t.co\/jdQPbSxXjo via @wordpressdotcom",
  "id" : 712306224289685504,
  "created_at" : "2016-03-22 15:53:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/7mdImOcNiP",
      "expanded_url" : "http:\/\/eltjam.com\/building-an-elt-bot\/",
      "display_url" : "eltjam.com\/building-an-el\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712229382715252736",
  "text" : "RT @NicolaPrentis: ELTjam's weekend experiment: Building an ELT Bot https:\/\/t.co\/7mdImOcNiP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/7mdImOcNiP",
        "expanded_url" : "http:\/\/eltjam.com\/building-an-elt-bot\/",
        "display_url" : "eltjam.com\/building-an-el\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712221153037840384",
    "text" : "ELTjam's weekend experiment: Building an ELT Bot https:\/\/t.co\/7mdImOcNiP",
    "id" : 712221153037840384,
    "created_at" : "2016-03-22 10:15:29 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 712229382715252736,
  "created_at" : "2016-03-22 10:48:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Colin",
      "screen_name" : "Catherine_Colin",
      "indices" : [ 3, 19 ],
      "id_str" : "324881798",
      "id" : 324881798
    }, {
      "name" : "Monsieur Le Prof",
      "screen_name" : "MsieurLeProf",
      "indices" : [ 71, 84 ],
      "id_str" : "379872730",
      "id" : 379872730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/5ZRBpGoQkN",
      "expanded_url" : "https:\/\/medium.com\/@coursdudimanche\/present-simple-et-present-be-ing-avec-hodor-69cccaacecee#.mx08kcbpn",
      "display_url" : "medium.com\/@coursdudimanc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711953586729652225",
  "text" : "RT @Catherine_Colin: \u201CPr\u00E9sent simple et Pr\u00E9sent Be-Ing avec HODOR.\u201D by @MsieurLeProf https:\/\/t.co\/5ZRBpGoQkN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monsieur Le Prof",
        "screen_name" : "MsieurLeProf",
        "indices" : [ 50, 63 ],
        "id_str" : "379872730",
        "id" : 379872730
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/5ZRBpGoQkN",
        "expanded_url" : "https:\/\/medium.com\/@coursdudimanche\/present-simple-et-present-be-ing-avec-hodor-69cccaacecee#.mx08kcbpn",
        "display_url" : "medium.com\/@coursdudimanc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700595376286474240",
    "text" : "\u201CPr\u00E9sent simple et Pr\u00E9sent Be-Ing avec HODOR.\u201D by @MsieurLeProf https:\/\/t.co\/5ZRBpGoQkN",
    "id" : 700595376286474240,
    "created_at" : "2016-02-19 08:18:48 +0000",
    "user" : {
      "name" : "Catherine Colin",
      "screen_name" : "Catherine_Colin",
      "protected" : false,
      "id_str" : "324881798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490455097910906880\/uuIwCRo8_normal.jpeg",
      "id" : 324881798,
      "verified" : false
    }
  },
  "id" : 711953586729652225,
  "created_at" : "2016-03-21 16:32:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 0, 9 ],
      "id_str" : "364412485",
      "id" : 364412485
    }, {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 56, 64 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711941916842205184",
  "geo" : { },
  "id_str" : "711951504060633088",
  "in_reply_to_user_id" : 364412485,
  "text" : "@_dr_kim_  true though looks like rss feed did not make @NNgroup cut?",
  "id" : 711951504060633088,
  "in_reply_to_status_id" : 711941916842205184,
  "created_at" : "2016-03-21 16:24:00 +0000",
  "in_reply_to_screen_name" : "_dr_kim_",
  "in_reply_to_user_id_str" : "364412485",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 10, 18 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711949405910396928",
  "geo" : { },
  "id_str" : "711950984931622915",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @grvsmth a bit of both? : )",
  "id" : 711950984931622915,
  "in_reply_to_status_id" : 711949405910396928,
  "created_at" : "2016-03-21 16:21:56 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 9, 18 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711945298428432385",
  "geo" : { },
  "id_str" : "711947364118994948",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @whyshona i don't believe that : )",
  "id" : 711947364118994948,
  "in_reply_to_status_id" : 711945298428432385,
  "created_at" : "2016-03-21 16:07:33 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 105, 114 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/QQBWH8qUxN",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-ck",
      "display_url" : "wp.me\/p28EmH-ck"
    } ]
  },
  "geo" : { },
  "id_str" : "711943419942277120",
  "text" : "\"A sophisticated and ingenious procedure\" for language teaching and research https:\/\/t.co\/QQBWH8qUxN via @whyshona",
  "id" : 711943419942277120,
  "created_at" : "2016-03-21 15:51:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/c8W0Ca6MM0",
      "expanded_url" : "http:\/\/englishspeechservices.com\/words-of-the-week\/sausage-anne-egg-mcmuffin\/",
      "display_url" : "englishspeechservices.com\/words-of-the-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711802716826247169",
  "text" : "Sausage anne egg McMuffin - https:\/\/t.co\/c8W0Ca6MM0",
  "id" : 711802716826247169,
  "created_at" : "2016-03-21 06:32:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711646359288320000",
  "geo" : { },
  "id_str" : "711649348082335744",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew needs like and share buttons : )",
  "id" : 711649348082335744,
  "in_reply_to_status_id" : 711646359288320000,
  "created_at" : "2016-03-20 20:23:21 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711646941654831104",
  "geo" : { },
  "id_str" : "711647196572229632",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew u know twitter embeds gifs for you now",
  "id" : 711647196572229632,
  "in_reply_to_status_id" : 711646941654831104,
  "created_at" : "2016-03-20 20:14:48 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711639151309774849",
  "geo" : { },
  "id_str" : "711645052565626880",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew the Gregg article is academic version of a rap diss : )",
  "id" : 711645052565626880,
  "in_reply_to_status_id" : 711639151309774849,
  "created_at" : "2016-03-20 20:06:16 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711639151309774849",
  "geo" : { },
  "id_str" : "711644250514006018",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @GeoffreyJordan i wld hazard a guess he would evaluate the arguments and not the tone of article",
  "id" : 711644250514006018,
  "in_reply_to_status_id" : 711639151309774849,
  "created_at" : "2016-03-20 20:03:05 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Journalism Tools",
      "screen_name" : "Journalism2ls",
      "indices" : [ 90, 104 ],
      "id_str" : "2222123156",
      "id" : 2222123156
    }, {
      "name" : "Kirk Borne",
      "screen_name" : "KirkDBorne",
      "indices" : [ 105, 116 ],
      "id_str" : "534563976",
      "id" : 534563976
    }, {
      "name" : "Google News Lab",
      "screen_name" : "googlenewslab",
      "indices" : [ 117, 131 ],
      "id_str" : "3245142196",
      "id" : 3245142196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "verification",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/vmjtRGNFuT",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-hLz",
      "display_url" : "wp.me\/pSoaD-hLz"
    } ]
  },
  "geo" : { },
  "id_str" : "711642300099723266",
  "text" : "RT @patrickDurusau: Face2Face - Facial Mimicry In Real-Time Video https:\/\/t.co\/vmjtRGNFuT @Journalism2ls @KirkDBorne @googlenewslab #verifi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Journalism Tools",
        "screen_name" : "Journalism2ls",
        "indices" : [ 70, 84 ],
        "id_str" : "2222123156",
        "id" : 2222123156
      }, {
        "name" : "Kirk Borne",
        "screen_name" : "KirkDBorne",
        "indices" : [ 85, 96 ],
        "id_str" : "534563976",
        "id" : 534563976
      }, {
        "name" : "Google News Lab",
        "screen_name" : "googlenewslab",
        "indices" : [ 97, 111 ],
        "id_str" : "3245142196",
        "id" : 3245142196
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "verification",
        "indices" : [ 112, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/vmjtRGNFuT",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-hLz",
        "display_url" : "wp.me\/pSoaD-hLz"
      } ]
    },
    "geo" : { },
    "id_str" : "711624208862863360",
    "text" : "Face2Face - Facial Mimicry In Real-Time Video https:\/\/t.co\/vmjtRGNFuT @Journalism2ls @KirkDBorne @googlenewslab #verification",
    "id" : 711624208862863360,
    "created_at" : "2016-03-20 18:43:27 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 711642300099723266,
  "created_at" : "2016-03-20 19:55:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711637041818144768",
  "geo" : { },
  "id_str" : "711637375856877568",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @GeoffreyJordan just read Gregg's article i would think",
  "id" : 711637375856877568,
  "in_reply_to_status_id" : 711637041818144768,
  "created_at" : "2016-03-20 19:35:46 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/711636942253907969\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/q1d48q2JKC",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CeA9xONWoAAj4Z5.jpg",
      "id_str" : "711636656961527808",
      "id" : 711636656961527808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CeA9xONWoAAj4Z5.jpg",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q1d48q2JKC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711632394957119488",
  "geo" : { },
  "id_str" : "711636942253907969",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew aiight those r some solid chops for some ELT battle raps https:\/\/t.co\/q1d48q2JKC",
  "id" : 711636942253907969,
  "in_reply_to_status_id" : 711632394957119488,
  "created_at" : "2016-03-20 19:34:03 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol2016",
      "indices" : [ 59, 69 ]
    }, {
      "text" : "iatefl2016",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711628024014196737",
  "geo" : { },
  "id_str" : "711632604974419969",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew sources say possibly un-publicized events at #tesol2016 &amp; #iatefl2016 : )",
  "id" : 711632604974419969,
  "in_reply_to_status_id" : 711628024014196737,
  "created_at" : "2016-03-20 19:16:49 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711628024014196737",
  "geo" : { },
  "id_str" : "711630038962200576",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @GeoffreyJordan dunno a glimpse into a brewing elt rap battle? ; )",
  "id" : 711630038962200576,
  "in_reply_to_status_id" : 711628024014196737,
  "created_at" : "2016-03-20 19:06:37 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "criticalELTraps",
      "indices" : [ 55, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/49fg3RNwuf",
      "expanded_url" : "https:\/\/drive.google.com\/open?id=0B7FW2BYaBgeiaG84YndOMEVRWUU",
      "display_url" : "drive.google.com\/open?id=0B7FW2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "711623341950443526",
  "geo" : { },
  "id_str" : "711625876534857732",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @GeoffreyJordan lost recording unearthed #criticalELTraps https:\/\/t.co\/49fg3RNwuf",
  "id" : 711625876534857732,
  "in_reply_to_status_id" : 711623341950443526,
  "created_at" : "2016-03-20 18:50:04 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/711594648800636928\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/vDie1qgOIt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeAXj8-VIAUzWKo.jpg",
      "id_str" : "711594647554957317",
      "id" : 711594647554957317,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeAXj8-VIAUzWKo.jpg",
      "sizes" : [ {
        "h" : 388,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 516
      } ],
      "display_url" : "pic.twitter.com\/vDie1qgOIt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/rvrTR5246y",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/20\/larsen-freeman-lost-in-complexity-bullshit-baffles-brains",
      "display_url" : "criticalelt.wordpress.com\/2016\/03\/20\/lar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711598247257702401",
  "text" : "RT @GeoffreyJordan: Larsen-Freeman Lost in Complexity: Bullshit Baffles\u00A0Brains https:\/\/t.co\/rvrTR5246y https:\/\/t.co\/vDie1qgOIt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/711594648800636928\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/vDie1qgOIt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeAXj8-VIAUzWKo.jpg",
        "id_str" : "711594647554957317",
        "id" : 711594647554957317,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeAXj8-VIAUzWKo.jpg",
        "sizes" : [ {
          "h" : 388,
          "resize" : "fit",
          "w" : 516
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 516
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 516
        } ],
        "display_url" : "pic.twitter.com\/vDie1qgOIt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/rvrTR5246y",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/03\/20\/larsen-freeman-lost-in-complexity-bullshit-baffles-brains",
        "display_url" : "criticalelt.wordpress.com\/2016\/03\/20\/lar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "711594648800636928",
    "text" : "Larsen-Freeman Lost in Complexity: Bullshit Baffles\u00A0Brains https:\/\/t.co\/rvrTR5246y https:\/\/t.co\/vDie1qgOIt",
    "id" : 711594648800636928,
    "created_at" : "2016-03-20 16:45:59 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 711598247257702401,
  "created_at" : "2016-03-20 17:00:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711533644951756804",
  "geo" : { },
  "id_str" : "711536625667481601",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle ok thought referring specific to article; 70% Eng Literacy rates forms foundation fr Phil success so non-accent factors?",
  "id" : 711536625667481601,
  "in_reply_to_status_id" : 711533644951756804,
  "created_at" : "2016-03-20 12:55:25 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 10, 21 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711529269701316608",
  "geo" : { },
  "id_str" : "711531766494994432",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @lauraahaha is accent reduction futile for winning business as Philippines seems to be doing?",
  "id" : 711531766494994432,
  "in_reply_to_status_id" : 711529269701316608,
  "created_at" : "2016-03-20 12:36:07 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 64, 76 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/711324277019156480\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3O0UifuQ07",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd8hqRSWIAUfNio.jpg",
      "id_str" : "711324276226400261",
      "id" : 711324276226400261,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd8hqRSWIAUfNio.jpg",
      "sizes" : [ {
        "h" : 173,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3O0UifuQ07"
    } ],
    "hashtags" : [ {
      "text" : "streetfightingmath",
      "indices" : [ 16, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/jefIIZwIwN",
      "expanded_url" : "http:\/\/cepr.net\/blogs\/beat-the-press\/new-york-times-hypes-financial-industry-scare-story-on-public-pensions",
      "display_url" : "cepr.net\/blogs\/beat-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711324277019156480",
  "text" : "nice example of #streetfightingmath https:\/\/t.co\/jefIIZwIwN h\/t @rosendo_joe https:\/\/t.co\/3O0UifuQ07",
  "id" : 711324277019156480,
  "created_at" : "2016-03-19 22:51:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Agora Paris-Saclay",
      "screen_name" : "Agora_UPSaclay",
      "indices" : [ 22, 37 ],
      "id_str" : "3042393513",
      "id" : 3042393513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711246355042213889",
  "geo" : { },
  "id_str" : "711248259499618304",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden OK thanks! cc @Agora_UPSaclay",
  "id" : 711248259499618304,
  "in_reply_to_status_id" : 711246355042213889,
  "created_at" : "2016-03-19 17:49:34 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711027707664932864",
  "geo" : { },
  "id_str" : "711243752891928578",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden hi what would u say r differences between wikity and say a copy post WP plugin? thx",
  "id" : 711243752891928578,
  "in_reply_to_status_id" : 711027707664932864,
  "created_at" : "2016-03-19 17:31:39 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "WordBrewery",
      "screen_name" : "WordBrewery",
      "indices" : [ 12, 24 ],
      "id_str" : "4747778602",
      "id" : 4747778602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711220164340142080",
  "geo" : { },
  "id_str" : "711229753873801216",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @WordBrewery there is link to full text; translations dodgy; but interesting execution overall",
  "id" : 711229753873801216,
  "in_reply_to_status_id" : 711220164340142080,
  "created_at" : "2016-03-19 16:36:01 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indieedtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/mWxpiAPc86",
      "expanded_url" : "http:\/\/hackeducation.com\/2016\/03\/18\/i-love-my-label",
      "display_url" : "hackeducation.com\/2016\/03\/18\/i-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711199612808335360",
  "text" : "RT @audreywatters: \"I Love My Label\" - Resisting the Pre-Packaged Sound (Student) in Ed-Tech https:\/\/t.co\/mWxpiAPc86 (My talk today at Davi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indieedtech",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/mWxpiAPc86",
        "expanded_url" : "http:\/\/hackeducation.com\/2016\/03\/18\/i-love-my-label",
        "display_url" : "hackeducation.com\/2016\/03\/18\/i-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "711008492706869248",
    "text" : "\"I Love My Label\" - Resisting the Pre-Packaged Sound (Student) in Ed-Tech https:\/\/t.co\/mWxpiAPc86 (My talk today at Davidson) #indieedtech",
    "id" : 711008492706869248,
    "created_at" : "2016-03-19 01:56:49 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 711199612808335360,
  "created_at" : "2016-03-19 14:36:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordBrewery",
      "screen_name" : "WordBrewery",
      "indices" : [ 3, 15 ],
      "id_str" : "4747778602",
      "id" : 4747778602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovation",
      "indices" : [ 125, 136 ]
    }, {
      "text" : "edtech",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "languages",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/BnU9U5mIQN",
      "expanded_url" : "http:\/\/WordBrewery.com",
      "display_url" : "WordBrewery.com"
    } ]
  },
  "geo" : { },
  "id_str" : "711109128953929728",
  "text" : "RT @WordBrewery: Welcome! https:\/\/t.co\/BnU9U5mIQN teaches languages with relevant sentences containing high-frequency words. #innovation #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovation",
        "indices" : [ 108, 119 ]
      }, {
        "text" : "edtech",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "languages",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/BnU9U5mIQN",
        "expanded_url" : "http:\/\/WordBrewery.com",
        "display_url" : "WordBrewery.com"
      } ]
    },
    "geo" : { },
    "id_str" : "710918726246391809",
    "text" : "Welcome! https:\/\/t.co\/BnU9U5mIQN teaches languages with relevant sentences containing high-frequency words. #innovation #edtech #languages",
    "id" : 710918726246391809,
    "created_at" : "2016-03-18 20:00:07 +0000",
    "user" : {
      "name" : "WordBrewery",
      "screen_name" : "WordBrewery",
      "protected" : false,
      "id_str" : "4747778602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702285624057929728\/1FGhsj9c_normal.jpg",
      "id" : 4747778602,
      "verified" : false
    }
  },
  "id" : 711109128953929728,
  "created_at" : "2016-03-19 08:36:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 52, 68 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/wXYiJxBkxt",
      "expanded_url" : "http:\/\/wp.me\/p7fdaP-1Ul",
      "display_url" : "wp.me\/p7fdaP-1Ul"
    } ]
  },
  "geo" : { },
  "id_str" : "710924663279509504",
  "text" : "Can we get a pineapple? https:\/\/t.co\/wXYiJxBkxt via @wordpressdotcom",
  "id" : 710924663279509504,
  "created_at" : "2016-03-18 20:23:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 95, 109 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndieEdTech",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710878954715025408",
  "text" : "RT @samplereality: Much of what higher ed institutions do comes down to templating students. - @audreywatters #IndieEdTech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 76, 90 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IndieEdTech",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "710875077399674880",
    "text" : "Much of what higher ed institutions do comes down to templating students. - @audreywatters #IndieEdTech",
    "id" : 710875077399674880,
    "created_at" : "2016-03-18 17:06:40 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 710878954715025408,
  "created_at" : "2016-03-18 17:22:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Lanclos",
      "screen_name" : "DonnaLanclos",
      "indices" : [ 3, 16 ],
      "id_str" : "436886909",
      "id" : 436886909
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 114, 128 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndieEdTech",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710878816080674816",
  "text" : "RT @DonnaLanclos: I like this pushing back against the inevitability of scale as a metric of success #IndieEdTech @audreywatters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 96, 110 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IndieEdTech",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "710876432898121728",
    "text" : "I like this pushing back against the inevitability of scale as a metric of success #IndieEdTech @audreywatters",
    "id" : 710876432898121728,
    "created_at" : "2016-03-18 17:12:03 +0000",
    "user" : {
      "name" : "Donna Lanclos",
      "screen_name" : "DonnaLanclos",
      "protected" : false,
      "id_str" : "436886909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747441208151015425\/zz2pnX46_normal.jpg",
      "id" : 436886909,
      "verified" : false
    }
  },
  "id" : 710878816080674816,
  "created_at" : "2016-03-18 17:21:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 127, 140 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndieEdTech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710878472940478464",
  "text" : "RT @samplereality: Despite what tech evangelists say, you can't learn everything online. Huge swaths of walled-in knowledge. - @audreywatte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 108, 122 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IndieEdTech",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "710863992596664320",
    "text" : "Despite what tech evangelists say, you can't learn everything online. Huge swaths of walled-in knowledge. - @audreywatters #IndieEdTech",
    "id" : 710863992596664320,
    "created_at" : "2016-03-18 16:22:37 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 710878472940478464,
  "created_at" : "2016-03-18 17:20:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/jF3shtBK4q",
      "expanded_url" : "http:\/\/gu.com\/p\/4hj9y\/stw",
      "display_url" : "gu.com\/p\/4hj9y\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "710875285265190912",
  "text" : "RT @MayoushLoves: France\u2019s state of emergency takes many unexpected forms \u2013 pupils are now allowed to smoke in school https:\/\/t.co\/jF3shtBK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/jF3shtBK4q",
        "expanded_url" : "http:\/\/gu.com\/p\/4hj9y\/stw",
        "display_url" : "gu.com\/p\/4hj9y\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "710870826564886530",
    "text" : "France\u2019s state of emergency takes many unexpected forms \u2013 pupils are now allowed to smoke in school https:\/\/t.co\/jF3shtBK4q",
    "id" : 710870826564886530,
    "created_at" : "2016-03-18 16:49:47 +0000",
    "user" : {
      "name" : "MS",
      "screen_name" : "MayoushWrites",
      "protected" : false,
      "id_str" : "585316486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543276547772125186\/wYJ_QDfM_normal.jpeg",
      "id" : 585316486,
      "verified" : false
    }
  },
  "id" : 710875285265190912,
  "created_at" : "2016-03-18 17:07:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 3, 17 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ck2Z663UFb",
      "expanded_url" : "https:\/\/chuffed.org\/project\/the-hands-up-project",
      "display_url" : "chuffed.org\/project\/the-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710843800307027968",
  "text" : "RT @nickbilbrough: 1 hour to go to support the Hands Up Project :-)\nhttps:\/\/t.co\/ck2Z663UFb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/ck2Z663UFb",
        "expanded_url" : "https:\/\/chuffed.org\/project\/the-hands-up-project",
        "display_url" : "chuffed.org\/project\/the-ha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710843064244428800",
    "text" : "1 hour to go to support the Hands Up Project :-)\nhttps:\/\/t.co\/ck2Z663UFb",
    "id" : 710843064244428800,
    "created_at" : "2016-03-18 14:59:27 +0000",
    "user" : {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "protected" : false,
      "id_str" : "273391079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705302580944117760\/4q5JmOoa_normal.jpg",
      "id" : 273391079,
      "verified" : false
    }
  },
  "id" : 710843800307027968,
  "created_at" : "2016-03-18 15:02:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/uNdeFlP7dd",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2016\/mar\/18\/us-military-face-punishment-afghan-hospital-strike-kunduz",
      "display_url" : "theguardian.com\/us-news\/2016\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710843401567137793",
  "text" : "RT @pchallinor: Punishment for killing 42 people could include being told not to do it again https:\/\/t.co\/uNdeFlP7dd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/uNdeFlP7dd",
        "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2016\/mar\/18\/us-military-face-punishment-afghan-hospital-strike-kunduz",
        "display_url" : "theguardian.com\/us-news\/2016\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710842566879649793",
    "text" : "Punishment for killing 42 people could include being told not to do it again https:\/\/t.co\/uNdeFlP7dd",
    "id" : 710842566879649793,
    "created_at" : "2016-03-18 14:57:29 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 710843401567137793,
  "created_at" : "2016-03-18 15:00:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 99, 115 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/UwI608RJFw",
      "expanded_url" : "http:\/\/wp.me\/p577Go-1sv",
      "display_url" : "wp.me\/p577Go-1sv"
    } ]
  },
  "geo" : { },
  "id_str" : "710826743851061250",
  "text" : "Color Blindness in the Classroom: Part 1 - Color Blind Friendly Charts https:\/\/t.co\/UwI608RJFw via @tekhnologicblog",
  "id" : 710826743851061250,
  "created_at" : "2016-03-18 13:54:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 74, 85 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/3K3p85VEqH",
      "expanded_url" : "http:\/\/wp.me\/p1wqwD-11C",
      "display_url" : "wp.me\/p1wqwD-11C"
    } ]
  },
  "geo" : { },
  "id_str" : "710812676339998721",
  "text" : "Academisation: a cautionary tale from Holland https:\/\/t.co\/3K3p85VEqH via @IOE_London",
  "id" : 710812676339998721,
  "created_at" : "2016-03-18 12:58:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710708159405494277",
  "geo" : { },
  "id_str" : "710713125306306560",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona gd luck!",
  "id" : 710713125306306560,
  "in_reply_to_status_id" : 710708159405494277,
  "created_at" : "2016-03-18 06:23:08 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "earlymorningstarts",
      "indices" : [ 54, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710712825551921152",
  "text" : "Bah another useful item of clothing eaten up by metro #earlymorningstarts",
  "id" : 710712825551921152,
  "created_at" : "2016-03-18 06:21:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/710435001645584384\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Ioge6Hmy5y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdv43oKWAAE1VA6.jpg",
      "id_str" : "710435000798281729",
      "id" : 710435000798281729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdv43oKWAAE1VA6.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Ioge6Hmy5y"
    } ],
    "hashtags" : [ {
      "text" : "Israel",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "Gaza",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/z2NyKdEEZH",
      "expanded_url" : "https:\/\/www.middleeastmonitor.com\/articles\/debate\/24525-israel-is-attacking-and-killing-palestinian-civilians-in-the-gaza-strip",
      "display_url" : "middleeastmonitor.com\/articles\/debat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710691108230184960",
  "text" : "RT @medialens: #Israel is attacking, and killing, Palestinian civilians in the #Gaza Strip. https:\/\/t.co\/z2NyKdEEZH https:\/\/t.co\/Ioge6Hmy5y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/710435001645584384\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/Ioge6Hmy5y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdv43oKWAAE1VA6.jpg",
        "id_str" : "710435000798281729",
        "id" : 710435000798281729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdv43oKWAAE1VA6.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Ioge6Hmy5y"
      } ],
      "hashtags" : [ {
        "text" : "Israel",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Gaza",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/z2NyKdEEZH",
        "expanded_url" : "https:\/\/www.middleeastmonitor.com\/articles\/debate\/24525-israel-is-attacking-and-killing-palestinian-civilians-in-the-gaza-strip",
        "display_url" : "middleeastmonitor.com\/articles\/debat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710435001645584384",
    "text" : "#Israel is attacking, and killing, Palestinian civilians in the #Gaza Strip. https:\/\/t.co\/z2NyKdEEZH https:\/\/t.co\/Ioge6Hmy5y",
    "id" : 710435001645584384,
    "created_at" : "2016-03-17 11:57:58 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 710691108230184960,
  "created_at" : "2016-03-18 04:55:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 0, 13 ],
      "id_str" : "920491754",
      "id" : 920491754
    }, {
      "name" : "Kelly J. Cunningham",
      "screen_name" : "ESLCunningham",
      "indices" : [ 14, 28 ],
      "id_str" : "242909458",
      "id" : 242909458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710597653860589568",
  "geo" : { },
  "id_str" : "710598367701819393",
  "in_reply_to_user_id" : 18602422,
  "text" : "@GretchenAMcC @ESLCunningham hand and head gestures according to paper",
  "id" : 710598367701819393,
  "in_reply_to_status_id" : 710597653860589568,
  "created_at" : "2016-03-17 22:47:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 0, 13 ],
      "id_str" : "920491754",
      "id" : 920491754
    }, {
      "name" : "Kelly J. Cunningham",
      "screen_name" : "ESLCunningham",
      "indices" : [ 14, 28 ],
      "id_str" : "242909458",
      "id" : 242909458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/HFxB541U62",
      "expanded_url" : "https:\/\/github.com\/maxipesfix\/receptionist_corpus",
      "display_url" : "github.com\/maxipesfix\/rec\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "710548256879714304",
  "geo" : { },
  "id_str" : "710597653860589568",
  "in_reply_to_user_id" : 920491754,
  "text" : "@GretchenAMcC @ESLCunningham there's non-verbal corpus of receptionist encounters not sure if it has gestures https:\/\/t.co\/HFxB541U62",
  "id" : 710597653860589568,
  "in_reply_to_status_id" : 710548256879714304,
  "created_at" : "2016-03-17 22:44:17 +0000",
  "in_reply_to_screen_name" : "GretchenAMcC",
  "in_reply_to_user_id_str" : "920491754",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simone Giertz",
      "screen_name" : "SimoneGiertz",
      "indices" : [ 3, 16 ],
      "id_str" : "897861037",
      "id" : 897861037
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SimoneGiertz\/status\/710123373850959872\/video\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/NxpXhk0NMM",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/710122717786349568\/pu\/img\/n-4oQiQj-P8ZGxwl.jpg",
      "id_str" : "710122717786349568",
      "id" : 710122717786349568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/710122717786349568\/pu\/img\/n-4oQiQj-P8ZGxwl.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NxpXhk0NMM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710579496873824256",
  "text" : "RT @SimoneGiertz: I made a robot to help me argue on the internet https:\/\/t.co\/NxpXhk0NMM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SimoneGiertz\/status\/710123373850959872\/video\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/NxpXhk0NMM",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/710122717786349568\/pu\/img\/n-4oQiQj-P8ZGxwl.jpg",
        "id_str" : "710122717786349568",
        "id" : 710122717786349568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/710122717786349568\/pu\/img\/n-4oQiQj-P8ZGxwl.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NxpXhk0NMM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "710123373850959872",
    "text" : "I made a robot to help me argue on the internet https:\/\/t.co\/NxpXhk0NMM",
    "id" : 710123373850959872,
    "created_at" : "2016-03-16 15:19:40 +0000",
    "user" : {
      "name" : "Simone Giertz",
      "screen_name" : "SimoneGiertz",
      "protected" : false,
      "id_str" : "897861037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718085961738006529\/SDLHn39O_normal.jpg",
      "id" : 897861037,
      "verified" : true
    }
  },
  "id" : 710579496873824256,
  "created_at" : "2016-03-17 21:32:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 53, 69 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/DucZXIn3K6",
      "expanded_url" : "http:\/\/wp.me\/p3VIfJ-be",
      "display_url" : "wp.me\/p3VIfJ-be"
    } ]
  },
  "geo" : { },
  "id_str" : "710574859810689025",
  "text" : "Educating Silicon Valley https:\/\/t.co\/DucZXIn3K6 via @wordpressdotcom",
  "id" : 710574859810689025,
  "created_at" : "2016-03-17 21:13:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 75, 85 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/1tfZ8LWItS",
      "expanded_url" : "http:\/\/wp.me\/p6aVNf-1z6",
      "display_url" : "wp.me\/p6aVNf-1z6"
    } ]
  },
  "geo" : { },
  "id_str" : "710571605727055872",
  "text" : "Collaborative writing with a methodology tweak https:\/\/t.co\/1tfZ8LWItS via @HanaTicha",
  "id" : 710571605727055872,
  "created_at" : "2016-03-17 21:00:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kaam jawaan ki mauth",
      "screen_name" : "naziasmirza",
      "indices" : [ 3, 15 ],
      "id_str" : "256910790",
      "id" : 256910790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/PflbHXiAww",
      "expanded_url" : "https:\/\/twitter.com\/nabilaramdani\/status\/710560047915528192",
      "display_url" : "twitter.com\/nabilaramdani\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710568170327773188",
  "text" : "RT @naziasmirza: Corruption - funny how it's only seen to be a problem in the developing world despite flourishing here as always  https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/PflbHXiAww",
        "expanded_url" : "https:\/\/twitter.com\/nabilaramdani\/status\/710560047915528192",
        "display_url" : "twitter.com\/nabilaramdani\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710562308750229506",
    "text" : "Corruption - funny how it's only seen to be a problem in the developing world despite flourishing here as always  https:\/\/t.co\/PflbHXiAww",
    "id" : 710562308750229506,
    "created_at" : "2016-03-17 20:23:50 +0000",
    "user" : {
      "name" : "kaam jawaan ki mauth",
      "screen_name" : "naziasmirza",
      "protected" : false,
      "id_str" : "256910790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757479938266103808\/cVF0N0zG_normal.jpg",
      "id" : 256910790,
      "verified" : false
    }
  },
  "id" : 710568170327773188,
  "created_at" : "2016-03-17 20:47:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/MLUyeSCHzc",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/03\/hitting-wrong-scroungers.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/03\/hittin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710567054135435268",
  "text" : "RT @pchallinor: New mudgeonry: Hitting the wrong scroungers https:\/\/t.co\/MLUyeSCHzc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/MLUyeSCHzc",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/03\/hitting-wrong-scroungers.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/03\/hittin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710563014584438784",
    "text" : "New mudgeonry: Hitting the wrong scroungers https:\/\/t.co\/MLUyeSCHzc",
    "id" : 710563014584438784,
    "created_at" : "2016-03-17 20:26:38 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 710567054135435268,
  "created_at" : "2016-03-17 20:42:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710542914812813314",
  "text" : "Yo publishers a new printing should not mean a revised reading text dang is this an anti-piracy thang? Now have sts with differing books!",
  "id" : 710542914812813314,
  "created_at" : "2016-03-17 19:06:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asya Ageyska",
      "screen_name" : "cqd_de_mgy",
      "indices" : [ 0, 11 ],
      "id_str" : "2397441097",
      "id" : 2397441097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710409856080072704",
  "geo" : { },
  "id_str" : "710421906386763776",
  "in_reply_to_user_id" : 2397441097,
  "text" : "@cqd_de_mgy thanks!",
  "id" : 710421906386763776,
  "in_reply_to_status_id" : 710409856080072704,
  "created_at" : "2016-03-17 11:05:56 +0000",
  "in_reply_to_screen_name" : "cqd_de_mgy",
  "in_reply_to_user_id_str" : "2397441097",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 10, 22 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709459567445483520",
  "geo" : { },
  "id_str" : "710196719779192833",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @usage_based thanks for RT :)",
  "id" : 710196719779192833,
  "in_reply_to_status_id" : 709459567445483520,
  "created_at" : "2016-03-16 20:11:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Andrew Kern",
      "screen_name" : "pastramimachine",
      "indices" : [ 14, 30 ],
      "id_str" : "444927395",
      "id" : 444927395
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 139, 140 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710191028544864257",
  "text" : "RT @mbeisen: .@pastramimachine i agree - I've always want to just post shit on the Internet, but the rest of you fuckers wanted journals so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kern",
        "screen_name" : "pastramimachine",
        "indices" : [ 1, 17 ],
        "id_str" : "444927395",
        "id" : 444927395
      }, {
        "name" : "PLOS",
        "screen_name" : "PLOS",
        "indices" : [ 135, 140 ],
        "id_str" : "12819112",
        "id" : 12819112
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "709839291761999872",
    "geo" : { },
    "id_str" : "709839520460484608",
    "in_reply_to_user_id" : 444927395,
    "text" : ".@pastramimachine i agree - I've always want to just post shit on the Internet, but the rest of you fuckers wanted journals so we made @PLOS",
    "id" : 709839520460484608,
    "in_reply_to_status_id" : 709839291761999872,
    "created_at" : "2016-03-15 20:31:44 +0000",
    "in_reply_to_screen_name" : "pastramimachine",
    "in_reply_to_user_id_str" : "444927395",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693283079616507904\/NpYT1Hek_normal.png",
      "id" : 19843630,
      "verified" : false
    }
  },
  "id" : 710191028544864257,
  "created_at" : "2016-03-16 19:48:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710173165146734593",
  "geo" : { },
  "id_str" : "710187753854656514",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT corrupted drive i think",
  "id" : 710187753854656514,
  "in_reply_to_status_id" : 710173165146734593,
  "created_at" : "2016-03-16 19:35:29 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 3, 12 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aparrish\/status\/710165376689164288\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/tRAwNo1bLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdsDpZNWIAIG_oe.jpg",
      "id_str" : "710165375917367298",
      "id" : 710165375917367298,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdsDpZNWIAIG_oe.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 338
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 338
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 338
      } ],
      "display_url" : "pic.twitter.com\/tRAwNo1bLA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/7QtAhG7ezg",
      "expanded_url" : "http:\/\/gutenberg-poetry.decontextualize.com\/",
      "display_url" : "gutenberg-poetry.decontextualize.com"
    } ]
  },
  "geo" : { },
  "id_str" : "710168145722548224",
  "text" : "RT @aparrish: I made an autocomplete interface with all of the lines of poetry on Project Gutenberg: https:\/\/t.co\/7QtAhG7ezg https:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aparrish\/status\/710165376689164288\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/tRAwNo1bLA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdsDpZNWIAIG_oe.jpg",
        "id_str" : "710165375917367298",
        "id" : 710165375917367298,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdsDpZNWIAIG_oe.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 338
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 338
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 319
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 338
        } ],
        "display_url" : "pic.twitter.com\/tRAwNo1bLA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/7QtAhG7ezg",
        "expanded_url" : "http:\/\/gutenberg-poetry.decontextualize.com\/",
        "display_url" : "gutenberg-poetry.decontextualize.com"
      } ]
    },
    "geo" : { },
    "id_str" : "710165376689164288",
    "text" : "I made an autocomplete interface with all of the lines of poetry on Project Gutenberg: https:\/\/t.co\/7QtAhG7ezg https:\/\/t.co\/tRAwNo1bLA",
    "id" : 710165376689164288,
    "created_at" : "2016-03-16 18:06:34 +0000",
    "user" : {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "protected" : false,
      "id_str" : "6857962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753298903072641024\/J2ItyKut_normal.jpg",
      "id" : 6857962,
      "verified" : false
    }
  },
  "id" : 710168145722548224,
  "created_at" : "2016-03-16 18:17:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 3, 12 ],
      "id_str" : "364412485",
      "id" : 364412485
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_dr_kim_\/status\/710137071386537985\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9YcTCoBgRn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdrp5ydUIAA2J5R.jpg",
      "id_str" : "710137070270816256",
      "id" : 710137070270816256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdrp5ydUIAA2J5R.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com\/9YcTCoBgRn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/pgEJySFOOH",
      "expanded_url" : "http:\/\/proswrite.com\/2016\/03\/16\/the-subgenre-of-the-executive-summary\/",
      "display_url" : "proswrite.com\/2016\/03\/16\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710149683021271041",
  "text" : "RT @_dr_kim_: The (sub)genre of the executive\u00A0summary https:\/\/t.co\/pgEJySFOOH https:\/\/t.co\/9YcTCoBgRn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_dr_kim_\/status\/710137071386537985\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/9YcTCoBgRn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdrp5ydUIAA2J5R.jpg",
        "id_str" : "710137070270816256",
        "id" : 710137070270816256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdrp5ydUIAA2J5R.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/9YcTCoBgRn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/pgEJySFOOH",
        "expanded_url" : "http:\/\/proswrite.com\/2016\/03\/16\/the-subgenre-of-the-executive-summary\/",
        "display_url" : "proswrite.com\/2016\/03\/16\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710137071386537985",
    "text" : "The (sub)genre of the executive\u00A0summary https:\/\/t.co\/pgEJySFOOH https:\/\/t.co\/9YcTCoBgRn",
    "id" : 710137071386537985,
    "created_at" : "2016-03-16 16:14:06 +0000",
    "user" : {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "protected" : false,
      "id_str" : "364412485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748257669085990912\/cY2QfaJJ_normal.jpg",
      "id" : 364412485,
      "verified" : false
    }
  },
  "id" : 710149683021271041,
  "created_at" : "2016-03-16 17:04:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/710124545261309952\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/Fl8JJP89iz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cdref5uWIAAAvUe.jpg",
      "id_str" : "710124530916794368",
      "id" : 710124530916794368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cdref5uWIAAAvUe.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/Fl8JJP89iz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710119399596818432",
  "geo" : { },
  "id_str" : "710124545261309952",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish fingers crossed! https:\/\/t.co\/Fl8JJP89iz",
  "id" : 710124545261309952,
  "in_reply_to_status_id" : 710119399596818432,
  "created_at" : "2016-03-16 15:24:19 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710118617573031936",
  "geo" : { },
  "id_str" : "710118971580813314",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish it's an external drive with loads of fam pics hoping i can recover them!",
  "id" : 710118971580813314,
  "in_reply_to_status_id" : 710118617573031936,
  "created_at" : "2016-03-16 15:02:10 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710116819630219264",
  "geo" : { },
  "id_str" : "710117151546478592",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d yeah would need to host code myself to change twitter share function",
  "id" : 710117151546478592,
  "in_reply_to_status_id" : 710116819630219264,
  "created_at" : "2016-03-16 14:54:56 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/710116887024287745\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/fQ0x7fFq9Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdrXi5jWAAIjXKq.jpg",
      "id_str" : "710116885828861954",
      "id" : 710116885828861954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdrXi5jWAAIjXKq.jpg",
      "sizes" : [ {
        "h" : 78,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 45,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 78,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 78,
        "resize" : "crop",
        "w" : 78
      }, {
        "h" : 78,
        "resize" : "fit",
        "w" : 587
      } ],
      "display_url" : "pic.twitter.com\/fQ0x7fFq9Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710116887024287745",
  "text" : "hard disk woes : ( https:\/\/t.co\/fQ0x7fFq9Y",
  "id" : 710116887024287745,
  "created_at" : "2016-03-16 14:53:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710069467942920192",
  "geo" : { },
  "id_str" : "710116613060730880",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d cheers Magnus : )",
  "id" : 710116613060730880,
  "in_reply_to_status_id" : 710069467942920192,
  "created_at" : "2016-03-16 14:52:48 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710029690166185984",
  "geo" : { },
  "id_str" : "710116544748109824",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock merci Rudy : )",
  "id" : 710116544748109824,
  "in_reply_to_status_id" : 710029690166185984,
  "created_at" : "2016-03-16 14:52:32 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 10, 21 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "English@EHU",
      "screen_name" : "English_EHU",
      "indices" : [ 22, 34 ],
      "id_str" : "2303187841",
      "id" : 2303187841
    }, {
      "name" : "DH Group at FBK",
      "screen_name" : "DH_FBK",
      "indices" : [ 35, 42 ],
      "id_str" : "1598324696",
      "id" : 1598324696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709459567445483520",
  "geo" : { },
  "id_str" : "710116473960796161",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @congabonga @English_EHU @DH_FBK many thanks for sharing this :)",
  "id" : 710116473960796161,
  "in_reply_to_status_id" : 709459567445483520,
  "created_at" : "2016-03-16 14:52:15 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 3, 12 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/apps4efl\/status\/709742369407574016\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/RX62kkrK6f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdmC7IxUMAArlti.jpg",
      "id_str" : "709742368765784064",
      "id" : 709742368765784064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdmC7IxUMAArlti.jpg",
      "sizes" : [ {
        "h" : 805,
        "resize" : "fit",
        "w" : 891
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 891
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RX62kkrK6f"
    } ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/xrPE00kYCr",
      "expanded_url" : "http:\/\/textgenie.apps4efl.com",
      "display_url" : "textgenie.apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "709742558105178112",
  "text" : "RT @apps4efl: Text Genie (https:\/\/t.co\/xrPE00kYCr) now offers readability and lexical complexity analyses for any text #langchat https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/apps4efl\/status\/709742369407574016\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/RX62kkrK6f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdmC7IxUMAArlti.jpg",
        "id_str" : "709742368765784064",
        "id" : 709742368765784064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdmC7IxUMAArlti.jpg",
        "sizes" : [ {
          "h" : 805,
          "resize" : "fit",
          "w" : 891
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 805,
          "resize" : "fit",
          "w" : 891
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/RX62kkrK6f"
      } ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/xrPE00kYCr",
        "expanded_url" : "http:\/\/textgenie.apps4efl.com",
        "display_url" : "textgenie.apps4efl.com"
      } ]
    },
    "geo" : { },
    "id_str" : "709742369407574016",
    "text" : "Text Genie (https:\/\/t.co\/xrPE00kYCr) now offers readability and lexical complexity analyses for any text #langchat https:\/\/t.co\/RX62kkrK6f",
    "id" : 709742369407574016,
    "created_at" : "2016-03-15 14:05:41 +0000",
    "user" : {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "protected" : false,
      "id_str" : "2594237072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652102680504963072\/peqnCRQT_normal.png",
      "id" : 2594237072,
      "verified" : false
    }
  },
  "id" : 709742558105178112,
  "created_at" : "2016-03-15 14:06:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asa Winstanley",
      "screen_name" : "AsaWinstanley",
      "indices" : [ 3, 17 ],
      "id_str" : "75033178",
      "id" : 75033178
    }, {
      "name" : "Hilary Aked",
      "screen_name" : "hilary_aked",
      "indices" : [ 37, 49 ],
      "id_str" : "91797532",
      "id" : 91797532
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 55, 70 ],
      "id_str" : "14732889",
      "id" : 14732889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/G7vMbGfivG",
      "expanded_url" : "https:\/\/electronicintifada.net\/content\/billionaire-donor-using-british-council-combat-israel-boycott\/15991",
      "display_url" : "electronicintifada.net\/content\/billio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709693580600864768",
  "text" : "RT @AsaWinstanley: Brilliant work by @hilary_aked: How @BritishCouncil is secretly funding (in it's own words) \"anti-BDS activities\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hilary Aked",
        "screen_name" : "hilary_aked",
        "indices" : [ 18, 30 ],
        "id_str" : "91797532",
        "id" : 91797532
      }, {
        "name" : "British Council",
        "screen_name" : "BritishCouncil",
        "indices" : [ 36, 51 ],
        "id_str" : "14732889",
        "id" : 14732889
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/G7vMbGfivG",
        "expanded_url" : "https:\/\/electronicintifada.net\/content\/billionaire-donor-using-british-council-combat-israel-boycott\/15991",
        "display_url" : "electronicintifada.net\/content\/billio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709436657179746304",
    "text" : "Brilliant work by @hilary_aked: How @BritishCouncil is secretly funding (in it's own words) \"anti-BDS activities\" https:\/\/t.co\/G7vMbGfivG",
    "id" : 709436657179746304,
    "created_at" : "2016-03-14 17:50:54 +0000",
    "user" : {
      "name" : "Asa Winstanley",
      "screen_name" : "AsaWinstanley",
      "protected" : false,
      "id_str" : "75033178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732860857101750272\/wKwI-mHh_normal.jpg",
      "id" : 75033178,
      "verified" : false
    }
  },
  "id" : 709693580600864768,
  "created_at" : "2016-03-15 10:51:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 112, 125 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 126, 135 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppleVsFBI",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/SHx7WHFQfP",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-hKI",
      "display_url" : "wp.me\/pSoaD-hKI"
    } ]
  },
  "geo" : { },
  "id_str" : "709636061136289792",
  "text" : "RT @patrickDurusau: You Can Help Increase Frustration at the FBI, Yes! You! https:\/\/t.co\/SHx7WHFQfP #AppleVsFBI @YourAnonNews @doctorow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 92, 105 ],
        "id_str" : "279390084",
        "id" : 279390084
      }, {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 106, 115 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AppleVsFBI",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/SHx7WHFQfP",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-hKI",
        "display_url" : "wp.me\/pSoaD-hKI"
      } ]
    },
    "geo" : { },
    "id_str" : "709443722006695937",
    "text" : "You Can Help Increase Frustration at the FBI, Yes! You! https:\/\/t.co\/SHx7WHFQfP #AppleVsFBI @YourAnonNews @doctorow",
    "id" : 709443722006695937,
    "created_at" : "2016-03-14 18:18:58 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 709636061136289792,
  "created_at" : "2016-03-15 07:03:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 64, 80 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/ObN5wjBmua",
      "expanded_url" : "http:\/\/wp.me\/p75ue9-6k",
      "display_url" : "wp.me\/p75ue9-6k"
    } ]
  },
  "geo" : { },
  "id_str" : "709631053116395520",
  "text" : "10. Flow by Mih\u00E1ly Cs\u00EDkszentmih\u00E1lyi https:\/\/t.co\/ObN5wjBmua via @wordpressdotcom",
  "id" : 709631053116395520,
  "created_at" : "2016-03-15 06:43:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 0, 13 ],
      "id_str" : "920491754",
      "id" : 920491754
    }, {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 14, 23 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709087473578553347",
  "geo" : { },
  "id_str" : "709517361892696065",
  "in_reply_to_user_id" : 920491754,
  "text" : "@GretchenAMcC @aparrish &amp; corresponding increase in frequency of their nagware : )",
  "id" : 709517361892696065,
  "in_reply_to_status_id" : 709087473578553347,
  "created_at" : "2016-03-14 23:11:35 +0000",
  "in_reply_to_screen_name" : "GretchenAMcC",
  "in_reply_to_user_id_str" : "920491754",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/LxCThE4Wv7",
      "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/618387",
      "display_url" : "smashwords.com\/books\/view\/618\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709084658798088192",
  "geo" : { },
  "id_str" : "709516688081952769",
  "in_reply_to_user_id" : 6857962,
  "text" : "@aparrish meh got used to interface hope they don't change it too much or will need new edition of https:\/\/t.co\/LxCThE4Wv7 : )",
  "id" : 709516688081952769,
  "in_reply_to_status_id" : 709084658798088192,
  "created_at" : "2016-03-14 23:08:55 +0000",
  "in_reply_to_screen_name" : "aparrish",
  "in_reply_to_user_id_str" : "6857962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709514259168960512",
  "geo" : { },
  "id_str" : "709515478729936897",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen night night : )",
  "id" : 709515478729936897,
  "in_reply_to_status_id" : 709514259168960512,
  "created_at" : "2016-03-14 23:04:06 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709512606466383872",
  "geo" : { },
  "id_str" : "709513619101376516",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen lol 2 diff posts really; let me know if u got any questions on that",
  "id" : 709513619101376516,
  "in_reply_to_status_id" : 709512606466383872,
  "created_at" : "2016-03-14 22:56:43 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 67, 77 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/5o9LCSg90d",
      "expanded_url" : "http:\/\/wp.me\/p1PBvi-U6",
      "display_url" : "wp.me\/p1PBvi-U6"
    } ]
  },
  "geo" : { },
  "id_str" : "709512894791032833",
  "text" : "Neil deGrasse Tyson: pedantry in space https:\/\/t.co\/5o9LCSg90d via @sam_kriss",
  "id" : 709512894791032833,
  "created_at" : "2016-03-14 22:53:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/P0rgkdX84f",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/FBJxCSXKQ5q",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709510992825180161",
  "geo" : { },
  "id_str" : "709511399177900032",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen no worries btw if u have biology\/medical kinda students u cld check this to get related abstracts https:\/\/t.co\/P0rgkdX84f",
  "id" : 709511399177900032,
  "in_reply_to_status_id" : 709510992825180161,
  "created_at" : "2016-03-14 22:47:54 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709510518227263488",
  "geo" : { },
  "id_str" : "709510871773487104",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen yeah i guess u could : )",
  "id" : 709510871773487104,
  "in_reply_to_status_id" : 709510518227263488,
  "created_at" : "2016-03-14 22:45:48 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709509890541297664",
  "geo" : { },
  "id_str" : "709510020652769280",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen ah well there's sci-hub now : )",
  "id" : 709510020652769280,
  "in_reply_to_status_id" : 709509890541297664,
  "created_at" : "2016-03-14 22:42:25 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709508967706337280",
  "geo" : { },
  "id_str" : "709509259206246400",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen did not know it was down : )",
  "id" : 709509259206246400,
  "in_reply_to_status_id" : 709508967706337280,
  "created_at" : "2016-03-14 22:39:24 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709508635945279488",
  "geo" : { },
  "id_str" : "709509078406602753",
  "in_reply_to_user_id" : 18602422,
  "text" : "@EAPstephen i did not get the tantalise\/disappoint thing",
  "id" : 709509078406602753,
  "in_reply_to_status_id" : 709508635945279488,
  "created_at" : "2016-03-14 22:38:40 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709507810103533568",
  "geo" : { },
  "id_str" : "709508635945279488",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen good post; they can be valuable resources",
  "id" : 709508635945279488,
  "in_reply_to_status_id" : 709507810103533568,
  "created_at" : "2016-03-14 22:36:55 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/709508415685586944\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/UDPRmUHyni",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdiuJOrW4AAj0_n.jpg",
      "id_str" : "709508414892859392",
      "id" : 709508414892859392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdiuJOrW4AAj0_n.jpg",
      "sizes" : [ {
        "h" : 51,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 89,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 1395
      } ],
      "display_url" : "pic.twitter.com\/UDPRmUHyni"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/4ZtxCAbKmY",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1HSI30l7C7H5vQXd_DprSow-2tV3OPe7WySszMQqfZEI",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709508415685586944",
  "text" : "another tickler from Cameron County Letter Generator https:\/\/t.co\/4ZtxCAbKmY https:\/\/t.co\/UDPRmUHyni",
  "id" : 709508415685586944,
  "created_at" : "2016-03-14 22:36:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/kACYsTEzwf",
      "expanded_url" : "http:\/\/eaping.blogspot.com\/2016\/03\/oh-abstract.html?spref=tw",
      "display_url" : "eaping.blogspot.com\/2016\/03\/oh-abs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709507771381784576",
  "text" : "EAPing: Oh, absTRACT! https:\/\/t.co\/kACYsTEzwf",
  "id" : 709507771381784576,
  "created_at" : "2016-03-14 22:33:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709498995576594433",
  "geo" : { },
  "id_str" : "709505430523871232",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 dunno where?",
  "id" : 709505430523871232,
  "in_reply_to_status_id" : 709498995576594433,
  "created_at" : "2016-03-14 22:24:11 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/wWhoCBO68P",
      "expanded_url" : "http:\/\/eflmagazine.com\/beginners-guide-to-the-lexical-approach\/#comment-3832",
      "display_url" : "eflmagazine.com\/beginners-guid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709504400990019590",
  "text" : "oh a new ELT keyboard warrior? https:\/\/t.co\/wWhoCBO68P : )",
  "id" : 709504400990019590,
  "created_at" : "2016-03-14 22:20:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timemapper",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 98, 116 ]
    }, {
      "text" : "corpusresources",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/tT5ggcxxo3",
      "expanded_url" : "http:\/\/timemapper.okfnlabs.org\/muranava\/history-of-computerised-corpus-tools",
      "display_url" : "timemapper.okfnlabs.org\/muranava\/histo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709459567445483520",
  "text" : "A (brief) history of computerised corpus tools is back up at #timemapper  https:\/\/t.co\/tT5ggcxxo3 #corpuslinguistics #corpusresources",
  "id" : 709459567445483520,
  "created_at" : "2016-03-14 19:21:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/709414369495490561\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/jtTcnvJP3G",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdhYj10WIAEdKhm.jpg",
      "id_str" : "709414314076151809",
      "id" : 709414314076151809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdhYj10WIAEdKhm.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jtTcnvJP3G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709414369495490561",
  "text" : "oh dear some internet pundits can sure gush about A.I. https:\/\/t.co\/jtTcnvJP3G",
  "id" : 709414369495490561,
  "created_at" : "2016-03-14 16:22:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709413108905672704",
  "geo" : { },
  "id_str" : "709413808931000320",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall yr welcome, enjoy your week too : )",
  "id" : 709413808931000320,
  "in_reply_to_status_id" : 709413108905672704,
  "created_at" : "2016-03-14 16:20:06 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 85, 97 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/b1bwSQ2uF6",
      "expanded_url" : "http:\/\/wp.me\/p3cig0-Cr",
      "display_url" : "wp.me\/p3cig0-Cr"
    } ]
  },
  "geo" : { },
  "id_str" : "709412952659595264",
  "text" : "Adapting texts for use in the English language classroom https:\/\/t.co\/b1bwSQ2uF6 via @nathanghall",
  "id" : 709412952659595264,
  "created_at" : "2016-03-14 16:16:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709313423222378496",
  "geo" : { },
  "id_str" : "709410731981201408",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski il faut acheter un nouveau dictionnaire je crois : )",
  "id" : 709410731981201408,
  "in_reply_to_status_id" : 709313423222378496,
  "created_at" : "2016-03-14 16:07:53 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709299071262072832",
  "geo" : { },
  "id_str" : "709301658996641792",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski d\u00E9sol\u00E9 c'est une mauvaise blague :)",
  "id" : 709301658996641792,
  "in_reply_to_status_id" : 709299071262072832,
  "created_at" : "2016-03-14 08:54:28 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709293052150595584",
  "geo" : { },
  "id_str" : "709298640414744576",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski you know I have a post about just that...",
  "id" : 709298640414744576,
  "in_reply_to_status_id" : 709293052150595584,
  "created_at" : "2016-03-14 08:42:28 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 3, 9 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 135, 139 ]
    }, {
      "text" : "publishing",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/hF1QDLNSeK",
      "expanded_url" : "https:\/\/eltmarketing.wordpress.com\/2016\/03\/14\/learning-from-the-games-industry\/",
      "display_url" : "eltmarketing.wordpress.com\/2016\/03\/14\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709277534895079424",
  "text" : "RT @idc74: Better later than never. First blog post of 2016: what publishers can learn from the games industry https:\/\/t.co\/hF1QDLNSeK #elt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "publishing",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/hF1QDLNSeK",
        "expanded_url" : "https:\/\/eltmarketing.wordpress.com\/2016\/03\/14\/learning-from-the-games-industry\/",
        "display_url" : "eltmarketing.wordpress.com\/2016\/03\/14\/lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709257489783595008",
    "text" : "Better later than never. First blog post of 2016: what publishers can learn from the games industry https:\/\/t.co\/hF1QDLNSeK #elt #publishing",
    "id" : 709257489783595008,
    "created_at" : "2016-03-14 05:58:57 +0000",
    "user" : {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "protected" : false,
      "id_str" : "290521216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716598365597736961\/kLEOaMTk_normal.jpg",
      "id" : 290521216,
      "verified" : false
    }
  },
  "id" : 709277534895079424,
  "created_at" : "2016-03-14 07:18:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 3, 11 ],
      "id_str" : "374391424",
      "id" : 374391424
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 39, 54 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 109, 114 ]
    }, {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "freeCPD",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Vz0trfa4Vn",
      "expanded_url" : "http:\/\/itdi.pro\/itdihome\/summer2015.php",
      "display_url" : "itdi.pro\/itdihome\/summe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709273642023133184",
  "text" : "RT @iTDipro: Correct Me If I'm Wrong - @thornburyscott's Intensive session + 25 more are all free to view on #iTDi https:\/\/t.co\/Vz0trfa4Vn \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 26, 41 ],
        "id_str" : "23090474",
        "id" : 23090474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "ELT",
        "indices" : [ 126, 130 ]
      }, {
        "text" : "freeCPD",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/Vz0trfa4Vn",
        "expanded_url" : "http:\/\/itdi.pro\/itdihome\/summer2015.php",
        "display_url" : "itdi.pro\/itdihome\/summe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709246561625071616",
    "text" : "Correct Me If I'm Wrong - @thornburyscott's Intensive session + 25 more are all free to view on #iTDi https:\/\/t.co\/Vz0trfa4Vn #ELT #freeCPD",
    "id" : 709246561625071616,
    "created_at" : "2016-03-14 05:15:32 +0000",
    "user" : {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "protected" : false,
      "id_str" : "374391424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1597476537\/iTDinstituteTwitter_normal.png",
      "id" : 374391424,
      "verified" : false
    }
  },
  "id" : 709273642023133184,
  "created_at" : "2016-03-14 07:03:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 13, 25 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709100383403118592",
  "geo" : { },
  "id_str" : "709102790342283264",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava cc @ThomasPride",
  "id" : 709102790342283264,
  "in_reply_to_status_id" : 709100383403118592,
  "created_at" : "2016-03-13 19:44:14 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/709100383403118592\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/2EhDo5e60B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdc7CoBWAAAUfFx.jpg",
      "id_str" : "709100382622973952",
      "id" : 709100382622973952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdc7CoBWAAAUfFx.jpg",
      "sizes" : [ {
        "h" : 195,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 1360
      }, {
        "h" : 65,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2EhDo5e60B"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/4ZtxCAbKmY",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1HSI30l7C7H5vQXd_DprSow-2tV3OPe7WySszMQqfZEI",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709100383403118592",
  "text" : "this Cameron County Letter Generator example tickled me :) https:\/\/t.co\/4ZtxCAbKmY https:\/\/t.co\/2EhDo5e60B",
  "id" : 709100383403118592,
  "created_at" : "2016-03-13 19:34:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 82, 100 ]
    }, {
      "text" : "ellchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/7FlI3Vi1pj",
      "expanded_url" : "http:\/\/buff.ly\/1YNpKwP",
      "display_url" : "buff.ly\/1YNpKwP"
    } ]
  },
  "geo" : { },
  "id_str" : "709090457905733632",
  "text" : "RT @leoselivan: What corpora have done for us? | Leoxicon https:\/\/t.co\/7FlI3Vi1pj #corpuslinguistics #ellchat #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 66, 84 ]
      }, {
        "text" : "ellchat",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "elt",
        "indices" : [ 94, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/7FlI3Vi1pj",
        "expanded_url" : "http:\/\/buff.ly\/1YNpKwP",
        "display_url" : "buff.ly\/1YNpKwP"
      } ]
    },
    "geo" : { },
    "id_str" : "709075635730309120",
    "text" : "What corpora have done for us? | Leoxicon https:\/\/t.co\/7FlI3Vi1pj #corpuslinguistics #ellchat #elt",
    "id" : 709075635730309120,
    "created_at" : "2016-03-13 17:56:20 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 709090457905733632,
  "created_at" : "2016-03-13 18:55:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/4ZtxCAbKmY",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1HSI30l7C7H5vQXd_DprSow-2tV3OPe7WySszMQqfZEI",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709025628213919745",
  "text" : "Cameron's County letter generator's gone a bit funny https:\/\/t.co\/4ZtxCAbKmY",
  "id" : 709025628213919745,
  "created_at" : "2016-03-13 14:37:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709015671242407940",
  "geo" : { },
  "id_str" : "709017847800930308",
  "in_reply_to_user_id" : 6857962,
  "text" : "@aparrish success! thanks greatly : )",
  "id" : 709017847800930308,
  "in_reply_to_status_id" : 709015671242407940,
  "created_at" : "2016-03-13 14:06:42 +0000",
  "in_reply_to_screen_name" : "aparrish",
  "in_reply_to_user_id_str" : "6857962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/52NXL0GcCv",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1HSI30l7C7H5vQXd_DprSow-2tV3OPe7WySszMQqfZEI\/edit?usp=sharing",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709008303477661696",
  "geo" : { },
  "id_str" : "709008423438970881",
  "in_reply_to_user_id" : 18602422,
  "text" : "@aparrish https:\/\/t.co\/52NXL0GcCv",
  "id" : 709008423438970881,
  "in_reply_to_status_id" : 709008303477661696,
  "created_at" : "2016-03-13 13:29:15 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709001780823265280",
  "geo" : { },
  "id_str" : "709008303477661696",
  "in_reply_to_user_id" : 18602422,
  "text" : "@aparrish doh here is shareable linke; when i copy paste your example spreadsheet it does not work but making a copy works",
  "id" : 709008303477661696,
  "in_reply_to_status_id" : 709001780823265280,
  "created_at" : "2016-03-13 13:28:46 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/5MDpFlFwfh",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1HSI30l7C7H5vQXd_DprSow-2tV3OPe7WySszMQqfZEI\/pubhtml",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709000612067860481",
  "geo" : { },
  "id_str" : "709001780823265280",
  "in_reply_to_user_id" : 6857962,
  "text" : "@aparrish yeah it works with yours; this is my sheet https:\/\/t.co\/5MDpFlFwfh",
  "id" : 709001780823265280,
  "in_reply_to_status_id" : 709000612067860481,
  "created_at" : "2016-03-13 13:02:51 +0000",
  "in_reply_to_screen_name" : "aparrish",
  "in_reply_to_user_id_str" : "6857962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/708999527701815297\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Uiw69It7l1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdbfUC-WoAAzd1P.jpg",
      "id_str" : "708999526846210048",
      "id" : 708999526846210048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdbfUC-WoAAzd1P.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 551
      } ],
      "display_url" : "pic.twitter.com\/Uiw69It7l1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708998525711945730",
  "geo" : { },
  "id_str" : "708999527701815297",
  "in_reply_to_user_id" : 6857962,
  "text" : "@aparrish i get this default(?) screen when i try to use my spreadsheet https:\/\/t.co\/Uiw69It7l1",
  "id" : 708999527701815297,
  "in_reply_to_status_id" : 708998525711945730,
  "created_at" : "2016-03-13 12:53:54 +0000",
  "in_reply_to_screen_name" : "aparrish",
  "in_reply_to_user_id_str" : "6857962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/6dldZpAmcL",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/index.html",
      "display_url" : "cfgg.decontextualize.com\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "708984802066751488",
  "in_reply_to_user_id" : 6857962,
  "text" : "@aparrish hi is this https:\/\/t.co\/6dldZpAmcL context free grammar generator still working?",
  "id" : 708984802066751488,
  "created_at" : "2016-03-13 11:55:23 +0000",
  "in_reply_to_screen_name" : "aparrish",
  "in_reply_to_user_id_str" : "6857962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Baty",
      "screen_name" : "Phil_Baty",
      "indices" : [ 3, 13 ],
      "id_str" : "354880191",
      "id" : 354880191
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Phil_Baty\/status\/708950819903815680\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/QJ2xCLG3If",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdazAW2W0AA7VWc.jpg",
      "id_str" : "708950810072371200",
      "id" : 708950810072371200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdazAW2W0AA7VWc.jpg",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/QJ2xCLG3If"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/l46ezyLLTp",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/books\/review-what-works-gender-equality-by-design-iris-bohnet-harvard-university-press",
      "display_url" : "timeshighereducation.com\/books\/review-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708972169594798080",
  "text" : "RT @Phil_Baty: To assume sexism is a thing of the past is to fly in the face of the wealth of evidence https:\/\/t.co\/l46ezyLLTp https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Phil_Baty\/status\/708950819903815680\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/QJ2xCLG3If",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdazAW2W0AA7VWc.jpg",
        "id_str" : "708950810072371200",
        "id" : 708950810072371200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdazAW2W0AA7VWc.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QJ2xCLG3If"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/l46ezyLLTp",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/books\/review-what-works-gender-equality-by-design-iris-bohnet-harvard-university-press",
        "display_url" : "timeshighereducation.com\/books\/review-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708950819903815680",
    "text" : "To assume sexism is a thing of the past is to fly in the face of the wealth of evidence https:\/\/t.co\/l46ezyLLTp https:\/\/t.co\/QJ2xCLG3If",
    "id" : 708950819903815680,
    "created_at" : "2016-03-13 09:40:21 +0000",
    "user" : {
      "name" : "Phil Baty",
      "screen_name" : "Phil_Baty",
      "protected" : false,
      "id_str" : "354880191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643823317598777344\/HImQkrL8_normal.jpg",
      "id" : 354880191,
      "verified" : false
    }
  },
  "id" : 708972169594798080,
  "created_at" : "2016-03-13 11:05:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/708762082959712256\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/86lZsTZfxR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdYHW7-WAAAMD5z.jpg",
      "id_str" : "708762081995128832",
      "id" : 708762081995128832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdYHW7-WAAAMD5z.jpg",
      "sizes" : [ {
        "h" : 80,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 157,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 157,
        "resize" : "fit",
        "w" : 671
      } ],
      "display_url" : "pic.twitter.com\/86lZsTZfxR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708762082959712256",
  "text" : "\"Splain said\" MonCo corpus poetry https:\/\/t.co\/86lZsTZfxR",
  "id" : 708762082959712256,
  "created_at" : "2016-03-12 21:10:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/708738434559582208\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/YAL1DxEMD6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdXxzAjW4AAiMEo.jpg",
      "id_str" : "708738375004643328",
      "id" : 708738375004643328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdXxzAjW4AAiMEo.jpg",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 352
      } ],
      "display_url" : "pic.twitter.com\/YAL1DxEMD6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708738434559582208",
  "text" : "Weekend Forecast: Net Pundit A.I. bullshit storm https:\/\/t.co\/YAL1DxEMD6",
  "id" : 708738434559582208,
  "created_at" : "2016-03-12 19:36:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708721012544835585",
  "geo" : { },
  "id_str" : "708735299287969792",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson hehe, puzzle was shared by my friend's 10yr old : )",
  "id" : 708735299287969792,
  "in_reply_to_status_id" : 708721012544835585,
  "created_at" : "2016-03-12 19:23:57 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708702979273179137",
  "text" : "RT @ibogost: Weblog became Blog, but Webinar didn't become Binar. Yet. \n\nBinar Stars.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "708456690731974656",
    "text" : "Weblog became Blog, but Webinar didn't become Binar. Yet. \n\nBinar Stars.",
    "id" : 708456690731974656,
    "created_at" : "2016-03-12 00:56:52 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677930477752193025\/DUdmOVVK_normal.jpg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 708702979273179137,
  "created_at" : "2016-03-12 17:15:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/WtLdYNdch1",
      "expanded_url" : "https:\/\/twitter.com\/ErrataRob\/status\/708426095201226752",
      "display_url" : "twitter.com\/ErrataRob\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708702766080860162",
  "text" : "RT @patrickDurusau: Truer words are rarely spoken! +1! https:\/\/t.co\/WtLdYNdch1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/WtLdYNdch1",
        "expanded_url" : "https:\/\/twitter.com\/ErrataRob\/status\/708426095201226752",
        "display_url" : "twitter.com\/ErrataRob\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708479482139701248",
    "text" : "Truer words are rarely spoken! +1! https:\/\/t.co\/WtLdYNdch1",
    "id" : 708479482139701248,
    "created_at" : "2016-03-12 02:27:26 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 708702766080860162,
  "created_at" : "2016-03-12 17:14:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver O'Brien",
      "screen_name" : "oobr",
      "indices" : [ 3, 8 ],
      "id_str" : "7669962",
      "id" : 7669962
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/oobr\/status\/708291375893258240\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/DYGE3hPDSz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdRbPQzWIAAdEnn.jpg",
      "id_str" : "708291359170502656",
      "id" : 708291359170502656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdRbPQzWIAAdEnn.jpg",
      "sizes" : [ {
        "h" : 945,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 564
      } ],
      "display_url" : "pic.twitter.com\/DYGE3hPDSz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708700897585528833",
  "text" : "RT @oobr: The \u201Cgiant rat\u201D is two foot rather than the \u201Cfour foot\u201D claimed in the press. Perspective trick. Here\u2019s my working: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/oobr\/status\/708291375893258240\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DYGE3hPDSz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdRbPQzWIAAdEnn.jpg",
        "id_str" : "708291359170502656",
        "id" : 708291359170502656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdRbPQzWIAAdEnn.jpg",
        "sizes" : [ {
          "h" : 945,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 945,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 945,
          "resize" : "fit",
          "w" : 564
        } ],
        "display_url" : "pic.twitter.com\/DYGE3hPDSz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "708291375893258240",
    "text" : "The \u201Cgiant rat\u201D is two foot rather than the \u201Cfour foot\u201D claimed in the press. Perspective trick. Here\u2019s my working: https:\/\/t.co\/DYGE3hPDSz",
    "id" : 708291375893258240,
    "created_at" : "2016-03-11 13:59:58 +0000",
    "user" : {
      "name" : "Oliver O'Brien",
      "screen_name" : "oobr",
      "protected" : false,
      "id_str" : "7669962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573863717391069184\/fNP8Aazg_normal.png",
      "id" : 7669962,
      "verified" : false
    }
  },
  "id" : 708700897585528833,
  "created_at" : "2016-03-12 17:07:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courrier inter",
      "screen_name" : "courrierinter",
      "indices" : [ 115, 129 ],
      "id_str" : "83864876",
      "id" : 83864876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/I0tR6Rvg24",
      "expanded_url" : "http:\/\/www.courrierinternational.com\/article\/vu-dailleurs-sacres-francais-le-site-qui-explique-ce-qui-rend-notre-peuple-unique",
      "display_url" : "courrierinternational.com\/article\/vu-dai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708692672949710848",
  "text" : "Vu d\u2019ailleurs. \u201CSacr\u00E9s Fran\u00E7ais\u201D, le site qui explique ce qui rend notre peuple unique https:\/\/t.co\/I0tR6Rvg24 via @courrierinter",
  "id" : 708692672949710848,
  "created_at" : "2016-03-12 16:34:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708689465657663488",
  "geo" : { },
  "id_str" : "708691228238467072",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson clue: Francophiles possibly have an advantage here",
  "id" : 708691228238467072,
  "in_reply_to_status_id" : 708689465657663488,
  "created_at" : "2016-03-12 16:28:50 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708688763208208384",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson hi Glenys do u know this one? what's next in seq - n,x,s,e,q,x,...",
  "id" : 708688763208208384,
  "created_at" : "2016-03-12 16:19:02 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/2OGHgPKRXJ",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/mar\/12\/gaza-boy-dies-in-air-strike-after-rocket-attack-on-israel",
      "display_url" : "theguardian.com\/world\/2016\/mar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708666425351802881",
  "text" : "RT @pchallinor: Child dies; Graun headline deeply anxious to make clear precisely whose fault it really is https:\/\/t.co\/2OGHgPKRXJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/2OGHgPKRXJ",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/mar\/12\/gaza-boy-dies-in-air-strike-after-rocket-attack-on-israel",
        "display_url" : "theguardian.com\/world\/2016\/mar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708663983725789185",
    "text" : "Child dies; Graun headline deeply anxious to make clear precisely whose fault it really is https:\/\/t.co\/2OGHgPKRXJ",
    "id" : 708663983725789185,
    "created_at" : "2016-03-12 14:40:34 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 708666425351802881,
  "created_at" : "2016-03-12 14:50:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 51, 62 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/cegVrxXAj3",
      "expanded_url" : "http:\/\/infernalmachine.co.uk\/the-archbishops-fears\/",
      "display_url" : "infernalmachine.co.uk\/the-archbishop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708625875705720832",
  "text" : "The Archbishop's Fears https:\/\/t.co\/cegVrxXAj3 via @MattCarr55",
  "id" : 708625875705720832,
  "created_at" : "2016-03-12 12:09:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 71, 87 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/HWPXuBJhBT",
      "expanded_url" : "http:\/\/www.richmondshare.com.br\/10-top-tips-encourage-extensive-reading\/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=10-top-tips-encourage-extensive-reading",
      "display_url" : "richmondshare.com.br\/10-top-tips-en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708625428232204289",
  "text" : "10 Top Tips to Encourage Extensive\u00A0Reading https:\/\/t.co\/HWPXuBJhBT via @wordpressdotcom",
  "id" : 708625428232204289,
  "created_at" : "2016-03-12 12:07:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nakba",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/k5cJCF106M",
      "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/rania-khalek\/mcgraw-hill-destroys-textbook-placate-pro-israel-bloggers",
      "display_url" : "electronicintifada.net\/blogs\/rania-kh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708591378666749953",
  "text" : "RT @johnwhilley: Major publisher in shameful cave-in to pro-Israel bloggers over #Nakba\/Occupation maps https:\/\/t.co\/k5cJCF106M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nakba",
        "indices" : [ 64, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/k5cJCF106M",
        "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/rania-khalek\/mcgraw-hill-destroys-textbook-placate-pro-israel-bloggers",
        "display_url" : "electronicintifada.net\/blogs\/rania-kh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708574662335275008",
    "text" : "Major publisher in shameful cave-in to pro-Israel bloggers over #Nakba\/Occupation maps https:\/\/t.co\/k5cJCF106M",
    "id" : 708574662335275008,
    "created_at" : "2016-03-12 08:45:38 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 708591378666749953,
  "created_at" : "2016-03-12 09:52:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia Viggiano",
      "screen_name" : "thisiswater_",
      "indices" : [ 3, 16 ],
      "id_str" : "2688018631",
      "id" : 2688018631
    }, {
      "name" : "Tableau Software",
      "screen_name" : "tableau",
      "indices" : [ 116, 124 ],
      "id_str" : "14792516",
      "id" : 14792516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 62, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/hUdjHiUGsX",
      "expanded_url" : "https:\/\/public.tableau.com\/s\/gallery\/beatles-analysis",
      "display_url" : "public.tableau.com\/s\/gallery\/beat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708565896206360576",
  "text" : "RT @thisiswater_: Beatles' songs in one infographic. A lot of #corpuslinguistics there. https:\/\/t.co\/hUdjHiUGsX via @tableau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tableau Software",
        "screen_name" : "tableau",
        "indices" : [ 98, 106 ],
        "id_str" : "14792516",
        "id" : 14792516
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 44, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/hUdjHiUGsX",
        "expanded_url" : "https:\/\/public.tableau.com\/s\/gallery\/beatles-analysis",
        "display_url" : "public.tableau.com\/s\/gallery\/beat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707692366174560257",
    "text" : "Beatles' songs in one infographic. A lot of #corpuslinguistics there. https:\/\/t.co\/hUdjHiUGsX via @tableau",
    "id" : 707692366174560257,
    "created_at" : "2016-03-09 22:19:43 +0000",
    "user" : {
      "name" : "Claudia Viggiano",
      "screen_name" : "thisiswater_",
      "protected" : false,
      "id_str" : "2688018631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495317630748618753\/QJpOndR6_normal.jpeg",
      "id" : 2688018631,
      "verified" : false
    }
  },
  "id" : 708565896206360576,
  "created_at" : "2016-03-12 08:10:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 116, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kChHcet6pz",
      "expanded_url" : "http:\/\/lpn.lagoinst.info\/",
      "display_url" : "lpn.lagoinst.info"
    } ]
  },
  "geo" : { },
  "id_str" : "708564445404991489",
  "text" : "Lexical Word Profiler for a parallel news corpus of English and Japanese (LWP for ParaNews) https:\/\/t.co\/kChHcet6pz #corpusresources",
  "id" : 708564445404991489,
  "created_at" : "2016-03-12 08:05:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yhat, Inc.",
      "screen_name" : "YhatHQ",
      "indices" : [ 3, 10 ],
      "id_str" : "1081568149",
      "id" : 1081568149
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/YhatHQ\/status\/708385821137588224\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/r84imXmffW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdSma4DWwAECMjm.jpg",
      "id_str" : "708374022057279489",
      "id" : 708374022057279489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdSma4DWwAECMjm.jpg",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/r84imXmffW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/IJlV0a3lUN",
      "expanded_url" : "http:\/\/bit.ly\/1pkRvRi",
      "display_url" : "bit.ly\/1pkRvRi"
    } ]
  },
  "geo" : { },
  "id_str" : "708561498784792576",
  "text" : "RT @YhatHQ: Adversarial images for deep learning | https:\/\/t.co\/IJlV0a3lUN https:\/\/t.co\/r84imXmffW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/YhatHQ\/status\/708385821137588224\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/r84imXmffW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdSma4DWwAECMjm.jpg",
        "id_str" : "708374022057279489",
        "id" : 708374022057279489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdSma4DWwAECMjm.jpg",
        "sizes" : [ {
          "h" : 587,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/r84imXmffW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/IJlV0a3lUN",
        "expanded_url" : "http:\/\/bit.ly\/1pkRvRi",
        "display_url" : "bit.ly\/1pkRvRi"
      } ]
    },
    "geo" : { },
    "id_str" : "708385821137588224",
    "text" : "Adversarial images for deep learning | https:\/\/t.co\/IJlV0a3lUN https:\/\/t.co\/r84imXmffW",
    "id" : 708385821137588224,
    "created_at" : "2016-03-11 20:15:15 +0000",
    "user" : {
      "name" : "Yhat, Inc.",
      "screen_name" : "YhatHQ",
      "protected" : false,
      "id_str" : "1081568149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666365911889121280\/EHeM_Es1_normal.png",
      "id" : 1081568149,
      "verified" : false
    }
  },
  "id" : 708561498784792576,
  "created_at" : "2016-03-12 07:53:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 3, 16 ],
      "id_str" : "920491754",
      "id" : 920491754
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GretchenAMcC\/status\/708153494310559746\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ta8F7D5uS7",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdPc360UUAQxT4w.jpg",
      "id_str" : "708152419666907140",
      "id" : 708152419666907140,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdPc360UUAQxT4w.jpg",
      "sizes" : [ {
        "h" : 174,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 144,
        "resize" : "crop",
        "w" : 144
      } ],
      "display_url" : "pic.twitter.com\/ta8F7D5uS7"
    } ],
    "hashtags" : [ {
      "text" : "MemeHistory",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708360587596664832",
  "text" : "RT @GretchenAMcC: 18th century grammarians applying Latin rules to English like: \n#MemeHistory https:\/\/t.co\/ta8F7D5uS7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GretchenAMcC\/status\/708153494310559746\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/ta8F7D5uS7",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdPc360UUAQxT4w.jpg",
        "id_str" : "708152419666907140",
        "id" : 708152419666907140,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdPc360UUAQxT4w.jpg",
        "sizes" : [ {
          "h" : 174,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 144,
          "resize" : "crop",
          "w" : 144
        } ],
        "display_url" : "pic.twitter.com\/ta8F7D5uS7"
      } ],
      "hashtags" : [ {
        "text" : "MemeHistory",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "708153494310559746",
    "text" : "18th century grammarians applying Latin rules to English like: \n#MemeHistory https:\/\/t.co\/ta8F7D5uS7",
    "id" : 708153494310559746,
    "created_at" : "2016-03-11 04:52:04 +0000",
    "user" : {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "protected" : false,
      "id_str" : "920491754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2800002402\/fb810f2f606e0f1413ed5191e2eac190_normal.png",
      "id" : 920491754,
      "verified" : true
    }
  },
  "id" : 708360587596664832,
  "created_at" : "2016-03-11 18:34:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708336556059197445",
  "geo" : { },
  "id_str" : "708343043422887941",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei great : ) works well on bbc news article",
  "id" : 708343043422887941,
  "in_reply_to_status_id" : 708336556059197445,
  "created_at" : "2016-03-11 17:25:16 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/tTElaoCtMG",
      "expanded_url" : "http:\/\/www.staff.amu.edu.pl\/~sipkadan\/script.txt",
      "display_url" : "staff.amu.edu.pl\/~sipkadan\/scri\u2026"
    }, {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/digVVRI47h",
      "expanded_url" : "http:\/\/www.staff.amu.edu.pl\/~sipkadan\/lingo.htm",
      "display_url" : "staff.amu.edu.pl\/~sipkadan\/ling\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "708327892812320769",
  "geo" : { },
  "id_str" : "708328768671195140",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei there's this code https:\/\/t.co\/tTElaoCtMG from this website https:\/\/t.co\/digVVRI47h which does not seem to work : )",
  "id" : 708328768671195140,
  "in_reply_to_status_id" : 708327892812320769,
  "created_at" : "2016-03-11 16:28:33 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eltjam\/status\/708310280690917376\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/jQDMC9xoFO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdRscngWIAENvy3.jpg",
      "id_str" : "708310280300797953",
      "id" : 708310280300797953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdRscngWIAENvy3.jpg",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jQDMC9xoFO"
    } ],
    "hashtags" : [ {
      "text" : "SOLE",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "language",
      "indices" : [ 60, 69 ]
    }, {
      "text" : "ELT",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ikQvMnhUIy",
      "expanded_url" : "http:\/\/ow.ly\/Zlyh0",
      "display_url" : "ow.ly\/Zlyh0"
    } ]
  },
  "geo" : { },
  "id_str" : "708313396182130689",
  "text" : "RT @eltjam: NEW guest post: #SOLE \u2013 does it work with adult #language learners? by Varinder Unlu https:\/\/t.co\/ikQvMnhUIy #ELT https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eltjam\/status\/708310280690917376\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/jQDMC9xoFO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdRscngWIAENvy3.jpg",
        "id_str" : "708310280300797953",
        "id" : 708310280300797953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdRscngWIAENvy3.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jQDMC9xoFO"
      } ],
      "hashtags" : [ {
        "text" : "SOLE",
        "indices" : [ 16, 21 ]
      }, {
        "text" : "language",
        "indices" : [ 48, 57 ]
      }, {
        "text" : "ELT",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ikQvMnhUIy",
        "expanded_url" : "http:\/\/ow.ly\/Zlyh0",
        "display_url" : "ow.ly\/Zlyh0"
      } ]
    },
    "geo" : { },
    "id_str" : "708310280690917376",
    "text" : "NEW guest post: #SOLE \u2013 does it work with adult #language learners? by Varinder Unlu https:\/\/t.co\/ikQvMnhUIy #ELT https:\/\/t.co\/jQDMC9xoFO",
    "id" : 708310280690917376,
    "created_at" : "2016-03-11 15:15:05 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 708313396182130689,
  "created_at" : "2016-03-11 15:27:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/qQk7LHBQfz",
      "expanded_url" : "https:\/\/www.apps4efl.com\/views\/special\/error_spotter\/",
      "display_url" : "apps4efl.com\/views\/special\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708312062934568960",
  "text" : "RT @eilymurphy: Apps 4 EFL: Error Spotter https:\/\/t.co\/qQk7LHBQfz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/qQk7LHBQfz",
        "expanded_url" : "https:\/\/www.apps4efl.com\/views\/special\/error_spotter\/",
        "display_url" : "apps4efl.com\/views\/special\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708309712371097600",
    "text" : "Apps 4 EFL: Error Spotter https:\/\/t.co\/qQk7LHBQfz",
    "id" : 708309712371097600,
    "created_at" : "2016-03-11 15:12:49 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 708312062934568960,
  "created_at" : "2016-03-11 15:22:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705282277379481600",
  "geo" : { },
  "id_str" : "708304481390366720",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei hi Paul have u considered adding url analysis feature i.e. to put in a website link for analysis?",
  "id" : 708304481390366720,
  "in_reply_to_status_id" : 705282277379481600,
  "created_at" : "2016-03-11 14:52:02 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/708302498436653056\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/TcgIP0GdpT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdRlQMwXEAAcu0h.jpg",
      "id_str" : "708302370380386304",
      "id" : 708302370380386304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdRlQMwXEAAcu0h.jpg",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/TcgIP0GdpT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708302498436653056",
  "text" : "Teapots, so simple, so great : ) https:\/\/t.co\/TcgIP0GdpT",
  "id" : 708302498436653056,
  "created_at" : "2016-03-11 14:44:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/708299066623594497\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/oYHgyjqxIB",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdRiOrFXIAAO0JA.jpg",
      "id_str" : "708299045626912768",
      "id" : 708299045626912768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdRiOrFXIAAO0JA.jpg",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 352
      } ],
      "display_url" : "pic.twitter.com\/oYHgyjqxIB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708168461982113793",
  "geo" : { },
  "id_str" : "708299066623594497",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish https:\/\/t.co\/oYHgyjqxIB",
  "id" : 708299066623594497,
  "in_reply_to_status_id" : 708168461982113793,
  "created_at" : "2016-03-11 14:30:31 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/1u14GltdjJ",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/03\/the-lord-is-my-light-and-my-salvation.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/03\/the-lo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708296473423822848",
  "text" : "RT @pchallinor: New mudgeonry: The Lord is my light and my salvation; whom shall I fear but https:\/\/t.co\/1u14GltdjJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/1u14GltdjJ",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/03\/the-lord-is-my-light-and-my-salvation.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/03\/the-lo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708295878361096192",
    "text" : "New mudgeonry: The Lord is my light and my salvation; whom shall I fear but https:\/\/t.co\/1u14GltdjJ",
    "id" : 708295878361096192,
    "created_at" : "2016-03-11 14:17:51 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 708296473423822848,
  "created_at" : "2016-03-11 14:20:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Btkb2UpPVo",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/03\/immigration-concern-racist\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708280140917313536",
  "text" : "RT @CraigMurrayOrg: New post: Why Immigration Concern Is Racist https:\/\/t.co\/Btkb2UpPVo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/Btkb2UpPVo",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/03\/immigration-concern-racist\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708274981982097408",
    "text" : "New post: Why Immigration Concern Is Racist https:\/\/t.co\/Btkb2UpPVo",
    "id" : 708274981982097408,
    "created_at" : "2016-03-11 12:54:49 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 708280140917313536,
  "created_at" : "2016-03-11 13:15:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708130539174146048",
  "geo" : { },
  "id_str" : "708168259569254400",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish good job :)",
  "id" : 708168259569254400,
  "in_reply_to_status_id" : 708130539174146048,
  "created_at" : "2016-03-11 05:50:44 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708084883394940928",
  "geo" : { },
  "id_str" : "708153888231268352",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith students are not on an equal footing with educational institutions; no such thing as \"raw\" data.",
  "id" : 708153888231268352,
  "in_reply_to_status_id" : 708084883394940928,
  "created_at" : "2016-03-11 04:53:38 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Knowledge Intl",
      "screen_name" : "OKFN",
      "indices" : [ 0, 5 ],
      "id_str" : "16143105",
      "id" : 16143105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timemapper",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707952894373396480",
  "in_reply_to_user_id" : 16143105,
  "text" : "@okfn any ideas on downtime for #timemapper? thx",
  "id" : 707952894373396480,
  "created_at" : "2016-03-10 15:34:57 +0000",
  "in_reply_to_screen_name" : "OKFN",
  "in_reply_to_user_id_str" : "16143105",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "indices" : [ 0, 10 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707670648877879296",
  "geo" : { },
  "id_str" : "707952512813420545",
  "in_reply_to_user_id" : 3839,
  "text" : "@davewiner great! why not check out G+ Corpus Linguistics group where such software is shared https:\/\/t.co\/gnEFqIeLpA \u2026 : )",
  "id" : 707952512813420545,
  "in_reply_to_status_id" : 707670648877879296,
  "created_at" : "2016-03-10 15:33:26 +0000",
  "in_reply_to_screen_name" : "davewiner",
  "in_reply_to_user_id_str" : "3839",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Hill",
      "screen_name" : "englishblog",
      "indices" : [ 0, 12 ],
      "id_str" : "23807115",
      "id" : 23807115
    }, {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 13, 22 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707913870829076481",
  "geo" : { },
  "id_str" : "707940429103239168",
  "in_reply_to_user_id" : 23807115,
  "text" : "@englishblog @oyajimbo did anyone have a teacher who would admonish letter writers with \"of course you are writing to them!\" : )",
  "id" : 707940429103239168,
  "in_reply_to_status_id" : 707913870829076481,
  "created_at" : "2016-03-10 14:45:25 +0000",
  "in_reply_to_screen_name" : "englishblog",
  "in_reply_to_user_id_str" : "23807115",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 0, 13 ],
      "id_str" : "74177226",
      "id" : 74177226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707877744009453568",
  "geo" : { },
  "id_str" : "707881453678362624",
  "in_reply_to_user_id" : 18602422,
  "text" : "@OUPELTGlobal woah google version for Oxford Eng Vocab trainer is 250Mb and reviews are pretty bad",
  "id" : 707881453678362624,
  "in_reply_to_status_id" : 707877744009453568,
  "created_at" : "2016-03-10 10:51:05 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 78, 91 ],
      "id_str" : "74177226",
      "id" : 74177226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/vK9wWqQMNw",
      "expanded_url" : "http:\/\/wp.me\/pLaO9-2FZ",
      "display_url" : "wp.me\/pLaO9-2FZ"
    } ]
  },
  "geo" : { },
  "id_str" : "707877744009453568",
  "text" : "Vocabulary gap-fills: from testing _____ teaching https:\/\/t.co\/vK9wWqQMNw via @OUPELTGlobal",
  "id" : 707877744009453568,
  "created_at" : "2016-03-10 10:36:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 123, 133 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hillary",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/lBjT0oD8I9",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/814-death-in-honduras-the-coup-hillary-clinton-and-the-killing-of-berta-caceres.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707876510082998272",
  "text" : "RT @johnwhilley: Fixated on #Hillary, media ignore link between her backing of Honduran coup and killing of Berta C\u00E1ceres, @medialens https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 106, 116 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hillary",
        "indices" : [ 11, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/lBjT0oD8I9",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/814-death-in-honduras-the-coup-hillary-clinton-and-the-killing-of-berta-caceres.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707875077057089536",
    "text" : "Fixated on #Hillary, media ignore link between her backing of Honduran coup and killing of Berta C\u00E1ceres, @medialens https:\/\/t.co\/lBjT0oD8I9",
    "id" : 707875077057089536,
    "created_at" : "2016-03-10 10:25:44 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 707876510082998272,
  "created_at" : "2016-03-10 10:31:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707619107819155456",
  "geo" : { },
  "id_str" : "707853245436272640",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules nice : )",
  "id" : 707853245436272640,
  "in_reply_to_status_id" : 707619107819155456,
  "created_at" : "2016-03-10 08:58:59 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 3, 11 ],
      "id_str" : "374391424",
      "id" : 374391424
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 88, 99 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/gkJzO0q5bt",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2016\/03\/06\/over-the-wall-of-experience\/",
      "display_url" : "itdi.pro\/blog\/2016\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707588842434514944",
  "text" : "RT @iTDipro: \"the people in front of us are living their own stories in their own way\"  @kevchanwow on teaching teens https:\/\/t.co\/gkJzO0q5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 75, 86 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 129, 134 ]
      }, {
        "text" : "ELT",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/gkJzO0q5bt",
        "expanded_url" : "http:\/\/itdi.pro\/blog\/2016\/03\/06\/over-the-wall-of-experience\/",
        "display_url" : "itdi.pro\/blog\/2016\/03\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707585545937887232",
    "text" : "\"the people in front of us are living their own stories in their own way\"  @kevchanwow on teaching teens https:\/\/t.co\/gkJzO0q5bt #iTDi #ELT",
    "id" : 707585545937887232,
    "created_at" : "2016-03-09 15:15:15 +0000",
    "user" : {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "protected" : false,
      "id_str" : "374391424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1597476537\/iTDinstituteTwitter_normal.png",
      "id" : 374391424,
      "verified" : false
    }
  },
  "id" : 707588842434514944,
  "created_at" : "2016-03-09 15:28:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/ppJspJHttY",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/GZqtVvSeYmm",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707587277988483073",
  "text" : "looks like a nice set of corpus related talks at #iatefl 2016 https:\/\/t.co\/ppJspJHttY",
  "id" : 707587277988483073,
  "created_at" : "2016-03-09 15:22:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707544198950494208",
  "geo" : { },
  "id_str" : "707546692170735616",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl I like to beat my wife :)",
  "id" : 707546692170735616,
  "in_reply_to_status_id" : 707544198950494208,
  "created_at" : "2016-03-09 12:40:51 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 86, 96 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 97, 105 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeeCrisis",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/piwq3GtOk5",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2016\/03\/a-note-on-bbcs-orwellian-use-of-migrants.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2016\/03\/a-note\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707331365583331328",
  "text" : "RT @johnwhilley: A note on BBC's Orwellian use of 'migrants'  https:\/\/t.co\/piwq3GtOk5 @medialens @BBCNews #RefugeeCrisis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 69, 79 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 80, 88 ],
        "id_str" : "612473",
        "id" : 612473
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RefugeeCrisis",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/piwq3GtOk5",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2016\/03\/a-note-on-bbcs-orwellian-use-of-migrants.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2016\/03\/a-note\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707166297826729984",
    "text" : "A note on BBC's Orwellian use of 'migrants'  https:\/\/t.co\/piwq3GtOk5 @medialens @BBCNews #RefugeeCrisis",
    "id" : 707166297826729984,
    "created_at" : "2016-03-08 11:29:18 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 707331365583331328,
  "created_at" : "2016-03-08 22:25:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 121, 137 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/8FwdVBqgUB",
      "expanded_url" : "http:\/\/hapgood.us\/2016\/03\/08\/trump-universitys-online-materials-are-a-lot-better-than-your-universitys-online-materials\/",
      "display_url" : "hapgood.us\/2016\/03\/08\/tru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707308362724216834",
  "text" : "Trump University\u2019s Online Materials Are a Lot Better Than Your University\u2019s Online\u00A0Materials https:\/\/t.co\/8FwdVBqgUB via @wordpressdotcom",
  "id" : 707308362724216834,
  "created_at" : "2016-03-08 20:53:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 135, 141 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/L1DcGQgVny",
      "expanded_url" : "http:\/\/www.salon.com\/2016\/03\/07\/my_secret_debate_with_sam_harris_a_revealing_4_hour_dialogue_on_islam_racism_free_speech_hypocrisy\/",
      "display_url" : "salon.com\/2016\/03\/07\/my_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707238929276211200",
  "text" : "My secret debate with Sam Harris: A revealing 4-hour dialogue on Islam, racism &amp; free-speech hypocrisy https:\/\/t.co\/L1DcGQgVny via @Salon",
  "id" : 707238929276211200,
  "created_at" : "2016-03-08 16:17:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 46, 52 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InternationalWomensDay",
      "indices" : [ 22, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XJMrZgu1cg",
      "expanded_url" : "https:\/\/genderequalityelt.wordpress.com\/database-of-women\/",
      "display_url" : "genderequalityelt.wordpress.com\/database-of-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707201288405127169",
  "text" : "RT @NicolaPrentis: On #InternationalWomensDay @ebefl and I launch database of women speakers in ELT...very much a work in progress https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 27, 33 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InternationalWomensDay",
        "indices" : [ 3, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/XJMrZgu1cg",
        "expanded_url" : "https:\/\/genderequalityelt.wordpress.com\/database-of-women\/",
        "display_url" : "genderequalityelt.wordpress.com\/database-of-wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707170028265873409",
    "text" : "On #InternationalWomensDay @ebefl and I launch database of women speakers in ELT...very much a work in progress https:\/\/t.co\/XJMrZgu1cg",
    "id" : 707170028265873409,
    "created_at" : "2016-03-08 11:44:07 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 707201288405127169,
  "created_at" : "2016-03-08 13:48:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/YZZw15i2sa",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=68069",
      "display_url" : "tm.durusau.net\/?p=68069"
    } ]
  },
  "geo" : { },
  "id_str" : "707197470514810882",
  "text" : "Preserving Unobserved Spaces (Privacy) For American Teenagers - https:\/\/t.co\/YZZw15i2sa",
  "id" : 707197470514810882,
  "created_at" : "2016-03-08 13:33:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706991145390186496",
  "geo" : { },
  "id_str" : "707159204293951488",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish my pleasure, good resources; soon soon big baboon :)",
  "id" : 707159204293951488,
  "in_reply_to_status_id" : 706991145390186496,
  "created_at" : "2016-03-08 11:01:07 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 7, 18 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 19, 32 ],
      "id_str" : "495430242",
      "id" : 495430242
    }, {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 33, 49 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/I463SKa9i2",
      "expanded_url" : "https:\/\/github.com\/Coppersmith\/vennclouds",
      "display_url" : "github.com\/Coppersmith\/ve\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "706975502532284416",
  "geo" : { },
  "id_str" : "706976866071146496",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d @congabonga @IgorBrigadir @linguisticpulse a version that you can try yourself called dynamic wordclouds https:\/\/t.co\/I463SKa9i2",
  "id" : 706976866071146496,
  "in_reply_to_status_id" : 706975502532284416,
  "created_at" : "2016-03-07 22:56:34 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/LZZRg0fMNG",
      "expanded_url" : "http:\/\/er.educause.edu\/articles\/2016\/3\/personalized-learning-what-it-really-is-and-why-it-really-matters",
      "display_url" : "er.educause.edu\/articles\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706963405425483776",
  "text" : "Personalized Learning: What It Really Is and Why It Really Matters https:\/\/t.co\/LZZRg0fMNG",
  "id" : 706963405425483776,
  "created_at" : "2016-03-07 22:03:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 0, 18 ]
    }, {
      "text" : "corpusresources",
      "indices" : [ 19, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706928481129648128",
  "text" : "#corpuslinguistics #corpusresources anyone know if MCA multimodal corpus authoring system is available anywhere? thx",
  "id" : 706928481129648128,
  "created_at" : "2016-03-07 19:44:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    }, {
      "name" : "Emma NuclearTeeth",
      "screen_name" : "NuclearTeeth",
      "indices" : [ 30, 43 ],
      "id_str" : "436191594",
      "id" : 436191594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/J5jIbEwxXz",
      "expanded_url" : "http:\/\/agrippinilla.com\/2016\/03\/04\/david-cameron-a-pig-and-the-romans\/",
      "display_url" : "agrippinilla.com\/2016\/03\/04\/dav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706911217219182592",
  "text" : "RT @pchallinor: The brilliant @NuclearTeeth gets her Nazis in a twist https:\/\/t.co\/J5jIbEwxXz And \"Dave fucked a pig\" is good enough for me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emma NuclearTeeth",
        "screen_name" : "NuclearTeeth",
        "indices" : [ 14, 27 ],
        "id_str" : "436191594",
        "id" : 436191594
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/J5jIbEwxXz",
        "expanded_url" : "http:\/\/agrippinilla.com\/2016\/03\/04\/david-cameron-a-pig-and-the-romans\/",
        "display_url" : "agrippinilla.com\/2016\/03\/04\/dav\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "706904063519150080",
    "text" : "The brilliant @NuclearTeeth gets her Nazis in a twist https:\/\/t.co\/J5jIbEwxXz And \"Dave fucked a pig\" is good enough for me.",
    "id" : 706904063519150080,
    "created_at" : "2016-03-07 18:07:17 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 706911217219182592,
  "created_at" : "2016-03-07 18:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naldic",
      "screen_name" : "EAL_naldic",
      "indices" : [ 0, 11 ],
      "id_str" : "90146452",
      "id" : 90146452
    }, {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 12, 28 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wKCiCoqd1O",
      "expanded_url" : "http:\/\/www.zompist.com\/spell.html",
      "display_url" : "zompist.com\/spell.html"
    } ]
  },
  "in_reply_to_status_id_str" : "706878152509935617",
  "geo" : { },
  "id_str" : "706901432629379072",
  "in_reply_to_user_id" : 90146452,
  "text" : "@EAL_naldic @scottroydouglas testing ignorance Eng spelling is gd sys? e.g. initial gh can never  be pronounced f. https:\/\/t.co\/wKCiCoqd1O",
  "id" : 706901432629379072,
  "in_reply_to_status_id" : 706878152509935617,
  "created_at" : "2016-03-07 17:56:49 +0000",
  "in_reply_to_screen_name" : "EAL_naldic",
  "in_reply_to_user_id_str" : "90146452",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BNC2014",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/VQRW4yKMYN",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1936",
      "display_url" : "cass.lancs.ac.uk\/?p=1936"
    } ]
  },
  "geo" : { },
  "id_str" : "706876290863931395",
  "text" : "RT @CorpusSocialSci: Part 3 of our blog series revealing planned research using Spoken #BNC2014 early access data is now available! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BNC2014",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/VQRW4yKMYN",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1936",
        "display_url" : "cass.lancs.ac.uk\/?p=1936"
      } ]
    },
    "geo" : { },
    "id_str" : "706847925549330438",
    "text" : "Part 3 of our blog series revealing planned research using Spoken #BNC2014 early access data is now available! https:\/\/t.co\/VQRW4yKMYN",
    "id" : 706847925549330438,
    "created_at" : "2016-03-07 14:24:12 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 706876290863931395,
  "created_at" : "2016-03-07 16:16:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 42, 58 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/cLEYBnvxt2",
      "expanded_url" : "http:\/\/wp.me\/p5jLUa-7u",
      "display_url" : "wp.me\/p5jLUa-7u"
    } ]
  },
  "geo" : { },
  "id_str" : "706868119910924288",
  "text" : "DIY Materials https:\/\/t.co\/cLEYBnvxt2 via @getgreatenglish",
  "id" : 706868119910924288,
  "created_at" : "2016-03-07 15:44:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim-Sue Kreischer",
      "screen_name" : "kimsuekreischer",
      "indices" : [ 3, 19 ],
      "id_str" : "1620009770",
      "id" : 1620009770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KjYJaamGd5",
      "expanded_url" : "http:\/\/www.eurocoat.es\/",
      "display_url" : "eurocoat.es"
    } ]
  },
  "geo" : { },
  "id_str" : "706809844704137216",
  "text" : "RT @kimsuekreischer: European Corpus of Academic Talk (EuroCoAT) now online; 27 hours English as lingua franca; includes contextual info ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/KjYJaamGd5",
        "expanded_url" : "http:\/\/www.eurocoat.es\/",
        "display_url" : "eurocoat.es"
      } ]
    },
    "geo" : { },
    "id_str" : "706806645783961600",
    "text" : "European Corpus of Academic Talk (EuroCoAT) now online; 27 hours English as lingua franca; includes contextual info https:\/\/t.co\/KjYJaamGd5",
    "id" : 706806645783961600,
    "created_at" : "2016-03-07 11:40:10 +0000",
    "user" : {
      "name" : "Kim-Sue Kreischer",
      "screen_name" : "kimsuekreischer",
      "protected" : false,
      "id_str" : "1620009770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519145949096972288\/UC_RdK7A_normal.jpeg",
      "id" : 1620009770,
      "verified" : false
    }
  },
  "id" : 706809844704137216,
  "created_at" : "2016-03-07 11:52:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 13, 28 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706396742749724672",
  "geo" : { },
  "id_str" : "706603238339047426",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin @AnthonyTeacher thanks for sharing! : )",
  "id" : 706603238339047426,
  "in_reply_to_status_id" : 706396742749724672,
  "created_at" : "2016-03-06 22:11:54 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 119, 130 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Cde5KZH9ZT",
      "expanded_url" : "http:\/\/archive.bidoun.org\/magazine\/10-technology\/glory-by-binyavanga-wainaina\/",
      "display_url" : "archive.bidoun.org\/magazine\/10-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706601895117398016",
  "text" : "Biogas. A windup radio. A magic laptop. These pure products are meant to solve everything. https:\/\/t.co\/Cde5KZH9ZT h\/t @worrydream",
  "id" : 706601895117398016,
  "created_at" : "2016-03-06 22:06:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 10, 25 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 26, 37 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "706184117839335428",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @AnthonyTeacher @MattEllman thanks for RTs hope yr w\/e is going good",
  "id" : 706184117839335428,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-03-05 18:26:28 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "Spengler",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8TLBE3ioJ9",
      "expanded_url" : "http:\/\/bit.ly\/21JSpYG",
      "display_url" : "bit.ly\/21JSpYG"
    } ]
  },
  "geo" : { },
  "id_str" : "706183823663431681",
  "text" : "RT @tornhalves: The #edtech hype and the implacable Decline of the West. #Spengler flies to California.  https:\/\/t.co\/8TLBE3ioJ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "Spengler",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/8TLBE3ioJ9",
        "expanded_url" : "http:\/\/bit.ly\/21JSpYG",
        "display_url" : "bit.ly\/21JSpYG"
      } ]
    },
    "geo" : { },
    "id_str" : "705758596785635328",
    "text" : "The #edtech hype and the implacable Decline of the West. #Spengler flies to California.  https:\/\/t.co\/8TLBE3ioJ9",
    "id" : 705758596785635328,
    "created_at" : "2016-03-04 14:15:36 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 706183823663431681,
  "created_at" : "2016-03-05 18:25:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 3, 18 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ltineap",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "tleap",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "eap",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/csWxuO0yBd",
      "expanded_url" : "http:\/\/learningtechnologiesineap.org\/im-an-eap-teacher-and-i-hate-corpus-linguistics\/",
      "display_url" : "learningtechnologiesineap.org\/im-an-eap-teac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705330094697537536",
  "text" : "RT @dreadnought001: Our new blog post: I\u2019m an EAP teacher and I hate Corpus Linguistics https:\/\/t.co\/csWxuO0yBd #ltineap #tleap #eap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ltineap",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "tleap",
        "indices" : [ 101, 107 ]
      }, {
        "text" : "eap",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/csWxuO0yBd",
        "expanded_url" : "http:\/\/learningtechnologiesineap.org\/im-an-eap-teacher-and-i-hate-corpus-linguistics\/",
        "display_url" : "learningtechnologiesineap.org\/im-an-eap-teac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705070523001278464",
    "text" : "Our new blog post: I\u2019m an EAP teacher and I hate Corpus Linguistics https:\/\/t.co\/csWxuO0yBd #ltineap #tleap #eap",
    "id" : 705070523001278464,
    "created_at" : "2016-03-02 16:41:26 +0000",
    "user" : {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "protected" : false,
      "id_str" : "83207734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503606579573178370\/GqHxIpPe_normal.jpeg",
      "id" : 83207734,
      "verified" : false
    }
  },
  "id" : 705330094697537536,
  "created_at" : "2016-03-03 09:52:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "705325421789880320",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava thanks Tyson :)",
  "id" : 705325421789880320,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-03-03 09:34:19 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 10, 20 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "704774613184724992",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @TEFLclass Thanks Anne :)",
  "id" : 704774613184724992,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-03-01 21:05:36 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Finegan",
      "screen_name" : "kehfinegan",
      "indices" : [ 0, 11 ],
      "id_str" : "3236117203",
      "id" : 3236117203
    }, {
      "name" : "Katy Meren Fuchtman",
      "screen_name" : "kmerenf",
      "indices" : [ 12, 20 ],
      "id_str" : "1048351326",
      "id" : 1048351326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704694057881178112",
  "geo" : { },
  "id_str" : "704774348310183936",
  "in_reply_to_user_id" : 3236117203,
  "text" : "@kehfinegan @kmerenf Thanks for sharing :)",
  "id" : 704774348310183936,
  "in_reply_to_status_id" : 704694057881178112,
  "created_at" : "2016-03-01 21:04:33 +0000",
  "in_reply_to_screen_name" : "kehfinegan",
  "in_reply_to_user_id_str" : "3236117203",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 24, 35 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704409804404613121",
  "geo" : { },
  "id_str" : "704774086132703240",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @HadaLitim @teflerinha thanks for sharing folks :)",
  "id" : 704774086132703240,
  "in_reply_to_status_id" : 704409804404613121,
  "created_at" : "2016-03-01 21:03:30 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Finegan",
      "screen_name" : "kehfinegan",
      "indices" : [ 0, 11 ],
      "id_str" : "3236117203",
      "id" : 3236117203
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 67, 79 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704694057881178112",
  "geo" : { },
  "id_str" : "704773563371397123",
  "in_reply_to_user_id" : 3236117203,
  "text" : "@kehfinegan thanks! also imp to note great feedback on drafts from @ELTResearch",
  "id" : 704773563371397123,
  "in_reply_to_status_id" : 704694057881178112,
  "created_at" : "2016-03-01 21:01:26 +0000",
  "in_reply_to_screen_name" : "kehfinegan",
  "in_reply_to_user_id_str" : "3236117203",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/0cWK2bwR3R",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/703636962729656320",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704687518554451968",
  "text" : "RT @ELTResearch: Really useful (and free ) e-book on use of COCA corpus. Worth downloading. https:\/\/t.co\/0cWK2bwR3R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/0cWK2bwR3R",
        "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/703636962729656320",
        "display_url" : "twitter.com\/muranava\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704409804404613121",
    "text" : "Really useful (and free ) e-book on use of COCA corpus. Worth downloading. https:\/\/t.co\/0cWK2bwR3R",
    "id" : 704409804404613121,
    "created_at" : "2016-02-29 20:55:59 +0000",
    "user" : {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "protected" : false,
      "id_str" : "3308043417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720360015383654400\/Zq4CQgZv_normal.jpg",
      "id" : 3308043417,
      "verified" : false
    }
  },
  "id" : 704687518554451968,
  "created_at" : "2016-03-01 15:19:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]