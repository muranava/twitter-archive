Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciNews",
      "screen_name" : "SciNewsRo",
      "indices" : [ 3, 13 ],
      "id_str" : "2231585786",
      "id" : 2231585786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeapSecond",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "SecondeIntercalaire",
      "indices" : [ 73, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/p1QGY4MWRs",
      "expanded_url" : "https:\/\/youtu.be\/1LhWxHm-RqY",
      "display_url" : "youtu.be\/1LhWxHm-RqY"
    } ]
  },
  "geo" : { },
  "id_str" : "615986858326142976",
  "text" : "RT @SciNewsRo: Leap Second Explained https:\/\/t.co\/p1QGY4MWRs #LeapSecond #SecondeIntercalaire",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeapSecond",
        "indices" : [ 46, 57 ]
      }, {
        "text" : "SecondeIntercalaire",
        "indices" : [ 58, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/p1QGY4MWRs",
        "expanded_url" : "https:\/\/youtu.be\/1LhWxHm-RqY",
        "display_url" : "youtu.be\/1LhWxHm-RqY"
      } ]
    },
    "geo" : { },
    "id_str" : "615893127618936834",
    "text" : "Leap Second Explained https:\/\/t.co\/p1QGY4MWRs #LeapSecond #SecondeIntercalaire",
    "id" : 615893127618936834,
    "created_at" : "2015-06-30 14:42:19 +0000",
    "user" : {
      "name" : "SciNews",
      "screen_name" : "SciNewsRo",
      "protected" : false,
      "id_str" : "2231585786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000832771803\/e10b5686138b7826eb34179af62f2587_normal.jpeg",
      "id" : 2231585786,
      "verified" : false
    }
  },
  "id" : 615986858326142976,
  "created_at" : "2015-06-30 20:54:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/D3V2IGhcwc",
      "expanded_url" : "https:\/\/www.learntogether.org.uk\/Resources\/Documents\/Grammar_of_Talk.pdf",
      "display_url" : "learntogether.org.uk\/Resources\/Docu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615982499408293888",
  "text" : "RT @ELTResearch: For L1 users  but full of  good ideas which could be adapted for EFL learners https:\/\/t.co\/D3V2IGhcwc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/D3V2IGhcwc",
        "expanded_url" : "https:\/\/www.learntogether.org.uk\/Resources\/Documents\/Grammar_of_Talk.pdf",
        "display_url" : "learntogether.org.uk\/Resources\/Docu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615974490053455872",
    "text" : "For L1 users  but full of  good ideas which could be adapted for EFL learners https:\/\/t.co\/D3V2IGhcwc",
    "id" : 615974490053455872,
    "created_at" : "2015-06-30 20:05:37 +0000",
    "user" : {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "protected" : false,
      "id_str" : "3308043417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720360015383654400\/Zq4CQgZv_normal.jpg",
      "id" : 3308043417,
      "verified" : false
    }
  },
  "id" : 615982499408293888,
  "created_at" : "2015-06-30 20:37:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 56, 72 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/mL8xts7sJK",
      "expanded_url" : "http:\/\/wp.me\/p62XeB-24",
      "display_url" : "wp.me\/p62XeB-24"
    } ]
  },
  "geo" : { },
  "id_str" : "615954317267353600",
  "text" : "Reading Into Online Comments http:\/\/t.co\/mL8xts7sJK via @wordpressdotcom",
  "id" : 615954317267353600,
  "created_at" : "2015-06-30 18:45:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615824307613097984",
  "geo" : { },
  "id_str" : "615825711400656896",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp great :)",
  "id" : 615825711400656896,
  "in_reply_to_status_id" : 615824307613097984,
  "created_at" : "2015-06-30 10:14:25 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1BXSil5QAF",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "615824373337980928",
  "text" : "+freq meaning bring up? - to rear or educate a person OR mention &amp; start discussion of an issue, use http:\/\/t.co\/1BXSil5QAF  #eltchat",
  "id" : 615824373337980928,
  "created_at" : "2015-06-30 10:09:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/h6HUQOJfwv",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/antwordprofiler\/",
      "display_url" : "laurenceanthony.net\/software\/antwo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "615823173460725760",
  "geo" : { },
  "id_str" : "615823366407237632",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp http:\/\/t.co\/h6HUQOJfwv",
  "id" : 615823366407237632,
  "in_reply_to_status_id" : 615823173460725760,
  "created_at" : "2015-06-30 10:05:06 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/mk66Wcz8tA",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615821251043553281",
  "text" : "RT @TonyMcEnery: The #corpusMOOC is back! Starts 28th September 2015: https:\/\/t.co\/mk66Wcz8tA Watch out for tweets and news about the cours\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/mk66Wcz8tA",
        "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics",
        "display_url" : "futurelearn.com\/courses\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615820777011707904",
    "text" : "The #corpusMOOC is back! Starts 28th September 2015: https:\/\/t.co\/mk66Wcz8tA Watch out for tweets and news about the course.",
    "id" : 615820777011707904,
    "created_at" : "2015-06-30 09:54:49 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 615821251043553281,
  "created_at" : "2015-06-30 09:56:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Allen",
      "screen_name" : "williamlallen",
      "indices" : [ 0, 14 ],
      "id_str" : "282122947",
      "id" : 282122947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615626915374845952",
  "geo" : { },
  "id_str" : "615820572052860929",
  "in_reply_to_user_id" : 282122947,
  "text" : "@williamlallen would need closer analysis of lang examples to see if hedging\/polite uses of just is more common in women than men",
  "id" : 615820572052860929,
  "in_reply_to_status_id" : 615626915374845952,
  "created_at" : "2015-06-30 09:54:00 +0000",
  "in_reply_to_screen_name" : "williamlallen",
  "in_reply_to_user_id_str" : "282122947",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 112, 116 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/xbWHIBZZOc",
      "expanded_url" : "http:\/\/bit.ly\/1C48eNT",
      "display_url" : "bit.ly\/1C48eNT"
    } ]
  },
  "geo" : { },
  "id_str" : "615792764790292481",
  "text" : "RT @nathanghall: New post on a lesson I did last week --&gt; Shuffling | ELT Reflections http:\/\/t.co\/xbWHIBZZOc #elt #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 100, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/xbWHIBZZOc",
        "expanded_url" : "http:\/\/bit.ly\/1C48eNT",
        "display_url" : "bit.ly\/1C48eNT"
      } ]
    },
    "geo" : { },
    "id_str" : "615786648282927104",
    "text" : "New post on a lesson I did last week --&gt; Shuffling | ELT Reflections http:\/\/t.co\/xbWHIBZZOc #elt #eltchat",
    "id" : 615786648282927104,
    "created_at" : "2015-06-30 07:39:12 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 615792764790292481,
  "created_at" : "2015-06-30 08:03:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/4osMY6JIhV",
      "expanded_url" : "https:\/\/researchingelt.wordpress.com\/2014\/10\/09\/written-correction\/",
      "display_url" : "researchingelt.wordpress.com\/2014\/10\/09\/wri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615577835462373376",
  "text" : "RT @ELTResearch: Some evidence that direct forms of written corrective feedback are more effective than indirect ones. https:\/\/t.co\/4osMY6J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/4osMY6JIhV",
        "expanded_url" : "https:\/\/researchingelt.wordpress.com\/2014\/10\/09\/written-correction\/",
        "display_url" : "researchingelt.wordpress.com\/2014\/10\/09\/wri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615527928215019520",
    "text" : "Some evidence that direct forms of written corrective feedback are more effective than indirect ones. https:\/\/t.co\/4osMY6JIhV \u2026",
    "id" : 615527928215019520,
    "created_at" : "2015-06-29 14:31:08 +0000",
    "user" : {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "protected" : false,
      "id_str" : "3308043417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720360015383654400\/Zq4CQgZv_normal.jpg",
      "id" : 3308043417,
      "verified" : false
    }
  },
  "id" : 615577835462373376,
  "created_at" : "2015-06-29 17:49:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "edtech",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/YkXnkuvMYx",
      "expanded_url" : "http:\/\/ow.ly\/OVlhZ",
      "display_url" : "ow.ly\/OVlhZ"
    } ]
  },
  "geo" : { },
  "id_str" : "615577392120242176",
  "text" : "RT @eltjam: Finding useful #ELT journals - peer reviewed, partially free or free as recommended by @_FTaylor_ http:\/\/t.co\/YkXnkuvMYx #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "edtech",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/YkXnkuvMYx",
        "expanded_url" : "http:\/\/ow.ly\/OVlhZ",
        "display_url" : "ow.ly\/OVlhZ"
      } ]
    },
    "geo" : { },
    "id_str" : "615520942236790784",
    "text" : "Finding useful #ELT journals - peer reviewed, partially free or free as recommended by @_FTaylor_ http:\/\/t.co\/YkXnkuvMYx #edtech",
    "id" : 615520942236790784,
    "created_at" : "2015-06-29 14:03:23 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 615577392120242176,
  "created_at" : "2015-06-29 17:47:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Lancaster University",
      "screen_name" : "LancasterUni",
      "indices" : [ 100, 113 ],
      "id_str" : "25521930",
      "id" : 25521930
    }, {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 114, 126 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freeonlinecourse",
      "indices" : [ 36, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/3YToOhIsLL",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics?utm_campaign=Share+Links&utm_medium=futurelearn-run_details&utm_source=twitter",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615570965876076544",
  "text" : "RT @eilymurphy: Have a look at this #freeonlinecourse 'Corpus Linguistics: Method, Analysis,...' by @LancasterUni @futurelearn https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lancaster University",
        "screen_name" : "LancasterUni",
        "indices" : [ 84, 97 ],
        "id_str" : "25521930",
        "id" : 25521930
      }, {
        "name" : "FutureLearn",
        "screen_name" : "FutureLearn",
        "indices" : [ 98, 110 ],
        "id_str" : "999095640",
        "id" : 999095640
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freeonlinecourse",
        "indices" : [ 20, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/3YToOhIsLL",
        "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics?utm_campaign=Share+Links&utm_medium=futurelearn-run_details&utm_source=twitter",
        "display_url" : "futurelearn.com\/courses\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615556027291934720",
    "text" : "Have a look at this #freeonlinecourse 'Corpus Linguistics: Method, Analysis,...' by @LancasterUni @futurelearn https:\/\/t.co\/3YToOhIsLL",
    "id" : 615556027291934720,
    "created_at" : "2015-06-29 16:22:48 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 615570965876076544,
  "created_at" : "2015-06-29 17:22:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Allen",
      "screen_name" : "williamlallen",
      "indices" : [ 0, 14 ],
      "id_str" : "282122947",
      "id" : 282122947
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 15, 27 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 28, 44 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/615567479910309888\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/eKFDtaxpf8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrvXFPWcAAVR-9.png",
      "id_str" : "615567478912086016",
      "id" : 615567478912086016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrvXFPWcAAVR-9.png",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 1275
      } ],
      "display_url" : "pic.twitter.com\/eKFDtaxpf8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/l73f37xNzI",
      "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/bnc64\/",
      "display_url" : "corpora.lancs.ac.uk\/bnc64\/"
    } ]
  },
  "in_reply_to_status_id_str" : "615544816525557760",
  "geo" : { },
  "id_str" : "615567479910309888",
  "in_reply_to_user_id" : 282122947,
  "text" : "@williamlallen @TonyMcEnery @CorpusSocialSci bnc64 says gender diffs &amp; -ve age correlation http:\/\/t.co\/l73f37xNzI http:\/\/t.co\/eKFDtaxpf8",
  "id" : 615567479910309888,
  "in_reply_to_status_id" : 615544816525557760,
  "created_at" : "2015-06-29 17:08:18 +0000",
  "in_reply_to_screen_name" : "williamlallen",
  "in_reply_to_user_id_str" : "282122947",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Learning English",
      "screen_name" : "bbcle",
      "indices" : [ 0, 6 ],
      "id_str" : "2450291",
      "id" : 2450291
    }, {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 7, 22 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/oW095xTQGg",
      "expanded_url" : "http:\/\/static.decontextualize.com\/rhymingkb\/",
      "display_url" : "static.decontextualize.com\/rhymingkb\/"
    } ]
  },
  "in_reply_to_status_id_str" : "615505658516008960",
  "geo" : { },
  "id_str" : "615506933164965888",
  "in_reply_to_user_id" : 2450291,
  "text" : "@bbcle @linkstoenglish this rhyming keyboard may be helpful http:\/\/t.co\/oW095xTQGg",
  "id" : 615506933164965888,
  "in_reply_to_status_id" : 615505658516008960,
  "created_at" : "2015-06-29 13:07:43 +0000",
  "in_reply_to_screen_name" : "bbcle",
  "in_reply_to_user_id_str" : "2450291",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615487769373188096",
  "geo" : { },
  "id_str" : "615488359281094657",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap i for one welcome our new precognitive driving assistant overlords... :)",
  "id" : 615488359281094657,
  "in_reply_to_status_id" : 615487769373188096,
  "created_at" : "2015-06-29 11:53:54 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615484575322669056",
  "geo" : { },
  "id_str" : "615486328046776320",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap future grant hyping?",
  "id" : 615486328046776320,
  "in_reply_to_status_id" : 615484575322669056,
  "created_at" : "2015-06-29 11:45:50 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 58, 73 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/6nOKKSwvaG",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2015\/06\/imf-and-usa-set-to-ruin-ghana\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615289354982948865",
  "text" : "IMF and USA set to ruin Ghana https:\/\/t.co\/6nOKKSwvaG via @CraigMurrayOrg",
  "id" : 615289354982948865,
  "created_at" : "2015-06-28 22:43:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615287038225575936",
  "geo" : { },
  "id_str" : "615287306728140800",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl be interested in what you can find out",
  "id" : 615287306728140800,
  "in_reply_to_status_id" : 615287038225575936,
  "created_at" : "2015-06-28 22:35:00 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pok\u00E9amonn",
      "screen_name" : "EamoV1",
      "indices" : [ 0, 7 ],
      "id_str" : "21100385",
      "id" : 21100385
    }, {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 8, 20 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/jwlPEgplF0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=grYXuR8ODwY",
      "display_url" : "youtube.com\/watch?v=grYXuR\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "615279888669478913",
  "geo" : { },
  "id_str" : "615287049608949760",
  "in_reply_to_user_id" : 21100385,
  "text" : "@EamoV1 @onalifeglug pushing buttons is an artform man witness these failures https:\/\/t.co\/jwlPEgplF0 ; )",
  "id" : 615287049608949760,
  "in_reply_to_status_id" : 615279888669478913,
  "created_at" : "2015-06-28 22:33:58 +0000",
  "in_reply_to_screen_name" : "EamoV1",
  "in_reply_to_user_id_str" : "21100385",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615282394946498560",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach thx fr RT Clare :)",
  "id" : 615282394946498560,
  "created_at" : "2015-06-28 22:15:29 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615261794744016896",
  "geo" : { },
  "id_str" : "615282310188007424",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 neat :)",
  "id" : 615282310188007424,
  "in_reply_to_status_id" : 615261794744016896,
  "created_at" : "2015-06-28 22:15:08 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615029910441226240",
  "geo" : { },
  "id_str" : "615281783043715072",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl what did they cite to support this?",
  "id" : 615281783043715072,
  "in_reply_to_status_id" : 615029910441226240,
  "created_at" : "2015-06-28 22:13:03 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/c1AOVFjpIC",
      "expanded_url" : "https:\/\/github.com\/chriskiehl\/Gooey",
      "display_url" : "github.com\/chriskiehl\/Goo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "615270651448926209",
  "geo" : { },
  "id_str" : "615271348609372160",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne last time i was looking at it was trying to get this working with it https:\/\/t.co\/c1AOVFjpIC",
  "id" : 615271348609372160,
  "in_reply_to_status_id" : 615270651448926209,
  "created_at" : "2015-06-28 21:31:35 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615266997509713921",
  "geo" : { },
  "id_str" : "615269432760385536",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne neat thx, did u ever get time to look at doing a gui for it?",
  "id" : 615269432760385536,
  "in_reply_to_status_id" : 615266997509713921,
  "created_at" : "2015-06-28 21:23:58 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615243995975974912",
  "geo" : { },
  "id_str" : "615257292343263232",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall yr welcome :)",
  "id" : 615257292343263232,
  "in_reply_to_status_id" : 615243995975974912,
  "created_at" : "2015-06-28 20:35:44 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615257059328675840",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp hi the intro text to antwordprofiler uses descrp for antpconc on yr website",
  "id" : 615257059328675840,
  "created_at" : "2015-06-28 20:34:48 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 123, 139 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/oDM9WySBoZ",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-r9",
      "display_url" : "wp.me\/p4E5tZ-r9"
    } ]
  },
  "geo" : { },
  "id_str" : "615240805599592448",
  "text" : "Why do our L1-English learners of French\/Spanish find it hard to acquire agreement rules? What\u2026 http:\/\/t.co\/oDM9WySBoZ via @gianfrancocont9",
  "id" : 615240805599592448,
  "created_at" : "2015-06-28 19:30:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 93, 105 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/b9FB7MhJzr",
      "expanded_url" : "http:\/\/wp.me\/p3cig0-uG",
      "display_url" : "wp.me\/p3cig0-uG"
    } ]
  },
  "geo" : { },
  "id_str" : "615240737878360064",
  "text" : "Frequency Level Checker: Easily check the lexical level of a text http:\/\/t.co\/b9FB7MhJzr via @nathanghall",
  "id" : 615240737878360064,
  "created_at" : "2015-06-28 19:29:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 17, 28 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 29, 38 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614914535686713344",
  "geo" : { },
  "id_str" : "615232123159625728",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @eilymurphy @Ashowski thx for mention folks :)",
  "id" : 615232123159625728,
  "in_reply_to_status_id" : 614914535686713344,
  "created_at" : "2015-06-28 18:55:43 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 3, 19 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gianfrancocont9\/status\/614114590318694401\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/c0kRUC9Odj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXF9xCUwAA0zoX.jpg",
      "id_str" : "614114589131718656",
      "id" : 614114589131718656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXF9xCUwAA0zoX.jpg",
      "sizes" : [ {
        "h" : 143,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 143,
        "resize" : "crop",
        "w" : 143
      } ],
      "display_url" : "pic.twitter.com\/c0kRUC9Odj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/75iL15bQR3",
      "expanded_url" : "https:\/\/gianfrancoconti.wordpress.com\/2015\/06\/25\/six-useless-activities-foreign-language-teachers-do",
      "display_url" : "gianfrancoconti.wordpress.com\/2015\/06\/25\/six\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614116355764289536",
  "text" : "RT @gianfrancocont9: Six useless activities foreign language teachers do https:\/\/t.co\/75iL15bQR3 http:\/\/t.co\/c0kRUC9Odj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gianfrancocont9\/status\/614114590318694401\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/c0kRUC9Odj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXF9xCUwAA0zoX.jpg",
        "id_str" : "614114589131718656",
        "id" : 614114589131718656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXF9xCUwAA0zoX.jpg",
        "sizes" : [ {
          "h" : 143,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 143,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 143,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 143,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 143,
          "resize" : "crop",
          "w" : 143
        } ],
        "display_url" : "pic.twitter.com\/c0kRUC9Odj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/75iL15bQR3",
        "expanded_url" : "https:\/\/gianfrancoconti.wordpress.com\/2015\/06\/25\/six-useless-activities-foreign-language-teachers-do",
        "display_url" : "gianfrancoconti.wordpress.com\/2015\/06\/25\/six\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614114590318694401",
    "text" : "Six useless activities foreign language teachers do https:\/\/t.co\/75iL15bQR3 http:\/\/t.co\/c0kRUC9Odj",
    "id" : 614114590318694401,
    "created_at" : "2015-06-25 16:55:02 +0000",
    "user" : {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "protected" : false,
      "id_str" : "2347690794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658673835001012224\/nSm9388G_normal.jpg",
      "id" : 2347690794,
      "verified" : false
    }
  },
  "id" : 614116355764289536,
  "created_at" : "2015-06-25 17:02:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/KPaevDL9Xm",
      "expanded_url" : "https:\/\/twitter.com\/biellacoleman\/status\/613327706873294848",
      "display_url" : "twitter.com\/biellacoleman\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614093731583684609",
  "text" : "RT @audreywatters: Enjoy your Google Apps for Edu surveillance https:\/\/t.co\/KPaevDL9Xm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/KPaevDL9Xm",
        "expanded_url" : "https:\/\/twitter.com\/biellacoleman\/status\/613327706873294848",
        "display_url" : "twitter.com\/biellacoleman\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613502720352260097",
    "text" : "Enjoy your Google Apps for Edu surveillance https:\/\/t.co\/KPaevDL9Xm",
    "id" : 613502720352260097,
    "created_at" : "2015-06-24 00:23:41 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 614093731583684609,
  "created_at" : "2015-06-25 15:32:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/614087652699148288\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/t0JmumCqGG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWtdvhWsAAZBNN.jpg",
      "id_str" : "614087650690117632",
      "id" : 614087650690117632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWtdvhWsAAZBNN.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1359,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/t0JmumCqGG"
    } ],
    "hashtags" : [ {
      "text" : "BESIG",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "elt",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "tefl",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "efl",
      "indices" : [ 84, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/8OUBP6KNAf",
      "expanded_url" : "http:\/\/goo.gl\/qrEXQ9",
      "display_url" : "goo.gl\/qrEXQ9"
    } ]
  },
  "geo" : { },
  "id_str" : "614093327533740032",
  "text" : "RT @josipa74: Building Bridges in Budapest http:\/\/t.co\/8OUBP6KNAf #BESIG #elt #tefl #efl http:\/\/t.co\/t0JmumCqGG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/614087652699148288\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/t0JmumCqGG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWtdvhWsAAZBNN.jpg",
        "id_str" : "614087650690117632",
        "id" : 614087650690117632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWtdvhWsAAZBNN.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1359,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/t0JmumCqGG"
      } ],
      "hashtags" : [ {
        "text" : "BESIG",
        "indices" : [ 52, 58 ]
      }, {
        "text" : "elt",
        "indices" : [ 59, 63 ]
      }, {
        "text" : "tefl",
        "indices" : [ 64, 69 ]
      }, {
        "text" : "efl",
        "indices" : [ 70, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/8OUBP6KNAf",
        "expanded_url" : "http:\/\/goo.gl\/qrEXQ9",
        "display_url" : "goo.gl\/qrEXQ9"
      } ]
    },
    "geo" : { },
    "id_str" : "614087652699148288",
    "text" : "Building Bridges in Budapest http:\/\/t.co\/8OUBP6KNAf #BESIG #elt #tefl #efl http:\/\/t.co\/t0JmumCqGG",
    "id" : 614087652699148288,
    "created_at" : "2015-06-25 15:08:00 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 614093327533740032,
  "created_at" : "2015-06-25 15:30:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614093259573448704",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher cheers for RT :)",
  "id" : 614093259573448704,
  "created_at" : "2015-06-25 15:30:17 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 0, 13 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614031920150769664",
  "in_reply_to_user_id" : 624508480,
  "text" : "@ShetlandESOL thanks for RT :)",
  "id" : 614031920150769664,
  "created_at" : "2015-06-25 11:26:32 +0000",
  "in_reply_to_screen_name" : "ShetlandESOL",
  "in_reply_to_user_id_str" : "624508480",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614024899447947265",
  "geo" : { },
  "id_str" : "614031586628083712",
  "in_reply_to_user_id" : 3165901457,
  "text" : "@Liam_ELT good question one that has now definitive answer i guess",
  "id" : 614031586628083712,
  "in_reply_to_status_id" : 614024899447947265,
  "created_at" : "2015-06-25 11:25:13 +0000",
  "in_reply_to_screen_name" : "Liam_ELT",
  "in_reply_to_user_id_str" : "3165901457",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614022720716730368",
  "geo" : { },
  "id_str" : "614031424333709312",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 nice, not bad start looking fwd to more :)",
  "id" : 614031424333709312,
  "in_reply_to_status_id" : 614022720716730368,
  "created_at" : "2015-06-25 11:24:34 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Things that matter",
      "screen_name" : "Thingsthatmat",
      "indices" : [ 94, 108 ],
      "id_str" : "2285566819",
      "id" : 2285566819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/4KGoYEZHI6",
      "expanded_url" : "http:\/\/wp.me\/p3Z5F8-n6",
      "display_url" : "wp.me\/p3Z5F8-n6"
    } ]
  },
  "geo" : { },
  "id_str" : "614031325281026048",
  "text" : "Is joining ISIS any worse than joining the UK or US armed forces?: http:\/\/t.co\/4KGoYEZHI6 via @Thingsthatmat",
  "id" : 614031325281026048,
  "created_at" : "2015-06-25 11:24:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/diul6QmFI6",
      "expanded_url" : "http:\/\/corpus.mml.cam.ac.uk\/efcamdat\/",
      "display_url" : "corpus.mml.cam.ac.uk\/efcamdat\/"
    } ]
  },
  "in_reply_to_status_id_str" : "613996113629184000",
  "geo" : { },
  "id_str" : "614017290519093248",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock in efcamdat for FR sts of 14 instances of cope|coping, 1 = A1 level, 2 = B1, rest B2 http:\/\/t.co\/diul6QmFI6",
  "id" : 614017290519093248,
  "in_reply_to_status_id" : 613996113629184000,
  "created_at" : "2015-06-25 10:28:24 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faten Romdhani",
      "screen_name" : "Romdhanifaten",
      "indices" : [ 0, 14 ],
      "id_str" : "304559688",
      "id" : 304559688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613978891514978305",
  "in_reply_to_user_id" : 304559688,
  "text" : "@Romdhanifaten thanks for RT :)",
  "id" : 613978891514978305,
  "created_at" : "2015-06-25 07:55:49 +0000",
  "in_reply_to_screen_name" : "Romdhanifaten",
  "in_reply_to_user_id_str" : "304559688",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613852573599178752",
  "geo" : { },
  "id_str" : "613978742227124224",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt thanks Tyson :)",
  "id" : 613978742227124224,
  "in_reply_to_status_id" : 613852573599178752,
  "created_at" : "2015-06-25 07:55:13 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 16, 27 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613833793024225280",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach @kevchanwow thanks for Skylight share :)",
  "id" : 613833793024225280,
  "created_at" : "2015-06-24 22:19:15 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613833521635926016",
  "geo" : { },
  "id_str" : "613833649390256128",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava course could also have been my description was naff :\/",
  "id" : 613833649390256128,
  "in_reply_to_status_id" : 613833521635926016,
  "created_at" : "2015-06-24 22:18:41 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613833521635926016",
  "text" : "was trying to describe A Domain of One\u2019s Own to a comp sci prof of a certain generation &amp; he looked at me as if i was speaking alien :\/",
  "id" : 613833521635926016,
  "created_at" : "2015-06-24 22:18:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 0, 9 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/0uXSx5VMkO",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/06\/03\/skylighting-sub-query-searching\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/06\/03\/sky\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "613664442555990016",
  "geo" : { },
  "id_str" : "613826031229792256",
  "in_reply_to_user_id" : 305260555,
  "text" : "@teflgeek hi u may like to read about the sub-query searching in Skylight https:\/\/t.co\/0uXSx5VMkO",
  "id" : 613826031229792256,
  "in_reply_to_status_id" : 613664442555990016,
  "created_at" : "2015-06-24 21:48:24 +0000",
  "in_reply_to_screen_name" : "teflgeek",
  "in_reply_to_user_id_str" : "305260555",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 43, 55 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613818553758683136",
  "geo" : { },
  "id_str" : "613821811902554115",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thanks and many thanks to @ELTResearch for some great open access reading",
  "id" : 613821811902554115,
  "in_reply_to_status_id" : 613818553758683136,
  "created_at" : "2015-06-24 21:31:38 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613816015735160832",
  "geo" : { },
  "id_str" : "613816461707112449",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 oh hey Gemma thx for share :) how's Germany going?",
  "id" : 613816461707112449,
  "in_reply_to_status_id" : 613816015735160832,
  "created_at" : "2015-06-24 21:10:23 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 36, 52 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/MzAKBcPyL4",
      "expanded_url" : "http:\/\/wp.me\/s4vQib-practice",
      "display_url" : "wp.me\/s4vQib-practice"
    } ]
  },
  "geo" : { },
  "id_str" : "613815242594848768",
  "text" : "Practice http:\/\/t.co\/MzAKBcPyL4 via @wordpressdotcom",
  "id" : 613815242594848768,
  "created_at" : "2015-06-24 21:05:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 0, 9 ],
      "id_str" : "305260555",
      "id" : 305260555
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 10, 25 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613814813853118464",
  "in_reply_to_user_id" : 305260555,
  "text" : "@teflgeek @AnthonyTeacher thanks for sharing guys :)",
  "id" : 613814813853118464,
  "created_at" : "2015-06-24 21:03:50 +0000",
  "in_reply_to_screen_name" : "teflgeek",
  "in_reply_to_user_id_str" : "305260555",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613516928112418817",
  "geo" : { },
  "id_str" : "613814690356011012",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco thanks for G+ CL shout out :)",
  "id" : 613814690356011012,
  "in_reply_to_status_id" : 613516928112418817,
  "created_at" : "2015-06-24 21:03:20 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 3, 16 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 80, 90 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 91, 102 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 103, 112 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PD",
      "indices" : [ 113, 116 ]
    }, {
      "text" : "Grateful",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "Learning",
      "indices" : [ 127, 136 ]
    }, {
      "text" : "ELT",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "iTDi",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/QylAAN7izf",
      "expanded_url" : "http:\/\/bit.ly\/1QOUUng",
      "display_url" : "bit.ly\/1QOUUng"
    } ]
  },
  "geo" : { },
  "id_str" : "613814599037620225",
  "text" : "RT @LauraSoracco: Writing about connections and learning http:\/\/t.co\/QylAAN7izf @HanaTicha @leoselivan @muranava #PD #Grateful #Learning #E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hana Tich\u00E1",
        "screen_name" : "HanaTicha",
        "indices" : [ 62, 72 ],
        "id_str" : "512296705",
        "id" : 512296705
      }, {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 73, 84 ],
        "id_str" : "408365496",
        "id" : 408365496
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 85, 94 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PD",
        "indices" : [ 95, 98 ]
      }, {
        "text" : "Grateful",
        "indices" : [ 99, 108 ]
      }, {
        "text" : "Learning",
        "indices" : [ 109, 118 ]
      }, {
        "text" : "ELT",
        "indices" : [ 119, 123 ]
      }, {
        "text" : "iTDi",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/QylAAN7izf",
        "expanded_url" : "http:\/\/bit.ly\/1QOUUng",
        "display_url" : "bit.ly\/1QOUUng"
      } ]
    },
    "geo" : { },
    "id_str" : "613516928112418817",
    "text" : "Writing about connections and learning http:\/\/t.co\/QylAAN7izf @HanaTicha @leoselivan @muranava #PD #Grateful #Learning #ELT #iTDi",
    "id" : 613516928112418817,
    "created_at" : "2015-06-24 01:20:08 +0000",
    "user" : {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "protected" : false,
      "id_str" : "15663328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766919326427254785\/4J5Q1zgQ_normal.jpg",
      "id" : 15663328,
      "verified" : false
    }
  },
  "id" : 613814599037620225,
  "created_at" : "2015-06-24 21:02:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 17, 27 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 28, 43 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 44, 54 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 55, 68 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 69, 79 ],
      "id_str" : "444977554",
      "id" : 444977554
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 80, 95 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "indices" : [ 96, 108 ],
      "id_str" : "310919399",
      "id" : 310919399
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 109, 117 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613814508029648896",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @adi_rajan @LjiljanaHavran @TEFLclass @LauraSoracco @joannacre @DavidHarbinson @SpeechDudes @Ven_VVE thx fr sharing!",
  "id" : 613814508029648896,
  "created_at" : "2015-06-24 21:02:37 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 114, 123 ]
    }, {
      "text" : "auselt",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "brelt",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/0lBKtSzvH8",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/06\/23\/corpus-linguistics-for-grammar-christian-jones-daniel-waller-interview\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/06\/23\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613438622415630336",
  "text" : "Corpus Linguistics for Grammar - Christian Jones &amp; Daniel Waller https:\/\/t.co\/0lBKtSzvH8 #eltchat #eltchinwag #keltchat #auselt #brelt",
  "id" : 613438622415630336,
  "created_at" : "2015-06-23 20:08:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613303452081389569",
  "geo" : { },
  "id_str" : "613304904300498944",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @michaelegriffin true that &amp; nice opportunity to recycle useful lang in directions",
  "id" : 613304904300498944,
  "in_reply_to_status_id" : 613303452081389569,
  "created_at" : "2015-06-23 11:17:38 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 17, 28 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 77, 93 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613297616168726529",
  "geo" : { },
  "id_str" : "613302723199528960",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @kevchanwow a possible option are visual instructions a la  @tekhnologicblog",
  "id" : 613302723199528960,
  "in_reply_to_status_id" : 613297616168726529,
  "created_at" : "2015-06-23 11:08:58 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/0XYprlQU4C",
      "expanded_url" : "https:\/\/educationfuturism.com\/no-sesame-street-was-not-the-first-mooc-9c163858de79",
      "display_url" : "educationfuturism.com\/no-sesame-stre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613300778372100096",
  "text" : "RT @audreywatters: No, Sesame Street was not the first MOOC https:\/\/t.co\/0XYprlQU4C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/0XYprlQU4C",
        "expanded_url" : "https:\/\/educationfuturism.com\/no-sesame-street-was-not-the-first-mooc-9c163858de79",
        "display_url" : "educationfuturism.com\/no-sesame-stre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613015021275119616",
    "text" : "No, Sesame Street was not the first MOOC https:\/\/t.co\/0XYprlQU4C",
    "id" : 613015021275119616,
    "created_at" : "2015-06-22 16:05:44 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 613300778372100096,
  "created_at" : "2015-06-23 11:01:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wikileaks\/status\/612975733154152448\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/A8sAW3CnqF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIG6Lc0VAAAYKwu.png",
      "id_str" : "612975730176098304",
      "id" : 612975730176098304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIG6Lc0VAAAYKwu.png",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A8sAW3CnqF"
    } ],
    "hashtags" : [ {
      "text" : "GCHQ",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/VBbPYL9k4r",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/document\/2015\/06\/22\/behavioural-science-support-jtrig\/",
      "display_url" : "firstlook.org\/theintercept\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613255966839209984",
  "text" : "RT @wikileaks: Here's what UK spies do to you--in their own words #GCHQ https:\/\/t.co\/VBbPYL9k4r http:\/\/t.co\/A8sAW3CnqF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wikileaks\/status\/612975733154152448\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/A8sAW3CnqF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIG6Lc0VAAAYKwu.png",
        "id_str" : "612975730176098304",
        "id" : 612975730176098304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIG6Lc0VAAAYKwu.png",
        "sizes" : [ {
          "h" : 280,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/A8sAW3CnqF"
      } ],
      "hashtags" : [ {
        "text" : "GCHQ",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/VBbPYL9k4r",
        "expanded_url" : "https:\/\/firstlook.org\/theintercept\/document\/2015\/06\/22\/behavioural-science-support-jtrig\/",
        "display_url" : "firstlook.org\/theintercept\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612975733154152448",
    "text" : "Here's what UK spies do to you--in their own words #GCHQ https:\/\/t.co\/VBbPYL9k4r http:\/\/t.co\/A8sAW3CnqF",
    "id" : 612975733154152448,
    "created_at" : "2015-06-22 13:29:37 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 613255966839209984,
  "created_at" : "2015-06-23 08:03:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613222223495757824",
  "geo" : { },
  "id_str" : "613232732764815360",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin a pleasure :)",
  "id" : 613232732764815360,
  "in_reply_to_status_id" : 613222223495757824,
  "created_at" : "2015-06-23 06:30:51 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 0, 15 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Yxtv9bDYwq",
      "expanded_url" : "https:\/\/www.academia.edu\/6115630\/Academic_English_Spoken_and_Written_Usage",
      "display_url" : "academia.edu\/6115630\/Academ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "613215518032588801",
  "geo" : { },
  "id_str" : "613232677936832512",
  "in_reply_to_user_id" : 83207734,
  "text" : "@dreadnought001 hi u may like this list as well Academic English Spoken &amp; Written Usage https:\/\/t.co\/Yxtv9bDYwq",
  "id" : 613232677936832512,
  "in_reply_to_status_id" : 613215518032588801,
  "created_at" : "2015-06-23 06:30:38 +0000",
  "in_reply_to_screen_name" : "dreadnought001",
  "in_reply_to_user_id_str" : "83207734",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 62, 74 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/0e4nZTTTrb",
      "expanded_url" : "http:\/\/wp.me\/p18yiK-1hY",
      "display_url" : "wp.me\/p18yiK-1hY"
    } ]
  },
  "geo" : { },
  "id_str" : "613036956671451137",
  "text" : "What do I think about coursebooks? http:\/\/t.co\/0e4nZTTTrb via @sandymillin",
  "id" : 613036956671451137,
  "created_at" : "2015-06-22 17:32:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "UCU",
      "screen_name" : "ucu",
      "indices" : [ 134, 138 ],
      "id_str" : "17724276",
      "id" : 17724276
    }, {
      "name" : "UCU Left",
      "screen_name" : "UcuLeft",
      "indices" : [ 140, 144 ],
      "id_str" : "309194789",
      "id" : 309194789
    }, {
      "name" : "UNIS_N - the uni_n",
      "screen_name" : "unisontweets",
      "indices" : [ 143, 144 ],
      "id_str" : "15230159",
      "id" : 15230159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tories",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "nurses",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613036068204470272",
  "text" : "RT @TESOLacademic: 1st the #tories came for int. students &amp; now they're coming for #nurses We all loose with draconian visa regs. @ucu  @Uc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UCU",
        "screen_name" : "ucu",
        "indices" : [ 115, 119 ],
        "id_str" : "17724276",
        "id" : 17724276
      }, {
        "name" : "UCU Left",
        "screen_name" : "UcuLeft",
        "indices" : [ 121, 129 ],
        "id_str" : "309194789",
        "id" : 309194789
      }, {
        "name" : "UNIS_N - the uni_n",
        "screen_name" : "unisontweets",
        "indices" : [ 130, 143 ],
        "id_str" : "15230159",
        "id" : 15230159
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tories",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "nurses",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613035471938158592",
    "text" : "1st the #tories came for int. students &amp; now they're coming for #nurses We all loose with draconian visa regs. @ucu  @UcuLeft @unisontweets",
    "id" : 613035471938158592,
    "created_at" : "2015-06-22 17:27:00 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 613036068204470272,
  "created_at" : "2015-06-22 17:29:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 3, 15 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/JIZpl5I6L8",
      "expanded_url" : "http:\/\/bit.ly\/1LuGyBF",
      "display_url" : "bit.ly\/1LuGyBF"
    } ]
  },
  "geo" : { },
  "id_str" : "612984921934692352",
  "text" : "RT @LanguageLog: Grexicon: Today is another stage in the Grexit crisis\u00A0\u2014\u00A0the Greek banking system may\u00A0collapse, creating a Grac... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/JIZpl5I6L8",
        "expanded_url" : "http:\/\/bit.ly\/1LuGyBF",
        "display_url" : "bit.ly\/1LuGyBF"
      } ]
    },
    "geo" : { },
    "id_str" : "612860314657251328",
    "text" : "Grexicon: Today is another stage in the Grexit crisis\u00A0\u2014\u00A0the Greek banking system may\u00A0collapse, creating a Grac... http:\/\/t.co\/JIZpl5I6L8",
    "id" : 612860314657251328,
    "created_at" : "2015-06-22 05:51:00 +0000",
    "user" : {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "protected" : false,
      "id_str" : "20148973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011503265\/gerund2_normal.jpg",
      "id" : 20148973,
      "verified" : false
    }
  },
  "id" : 612984921934692352,
  "created_at" : "2015-06-22 14:06:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "indices" : [ 72, 85 ],
      "id_str" : "2820709207",
      "id" : 2820709207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/vuOrpkTd9N",
      "expanded_url" : "http:\/\/wp.me\/p6cBF3-1A",
      "display_url" : "wp.me\/p6cBF3-1A"
    } ]
  },
  "geo" : { },
  "id_str" : "612979785208328192",
  "text" : "RT @DavidHarbinson: Lost without translation http:\/\/t.co\/vuOrpkTd9N via @wordspinster",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Debbie Cameron",
        "screen_name" : "wordspinster",
        "indices" : [ 52, 65 ],
        "id_str" : "2820709207",
        "id" : 2820709207
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/vuOrpkTd9N",
        "expanded_url" : "http:\/\/wp.me\/p6cBF3-1A",
        "display_url" : "wp.me\/p6cBF3-1A"
      } ]
    },
    "geo" : { },
    "id_str" : "612978236880850944",
    "text" : "Lost without translation http:\/\/t.co\/vuOrpkTd9N via @wordspinster",
    "id" : 612978236880850944,
    "created_at" : "2015-06-22 13:39:34 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 612979785208328192,
  "created_at" : "2015-06-22 13:45:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academia Obscura",
      "screen_name" : "AcademiaObscura",
      "indices" : [ 0, 16 ],
      "id_str" : "2645602164",
      "id" : 2645602164
    }, {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 17, 26 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612742081166098432",
  "geo" : { },
  "id_str" : "612859725093433344",
  "in_reply_to_user_id" : 2645602164,
  "text" : "@AcademiaObscura @cainesap if u r going to talk out your * do it with style :)",
  "id" : 612859725093433344,
  "in_reply_to_status_id" : 612742081166098432,
  "created_at" : "2015-06-22 05:48:39 +0000",
  "in_reply_to_screen_name" : "AcademiaObscura",
  "in_reply_to_user_id_str" : "2645602164",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/wM4xBMXPDP",
      "expanded_url" : "http:\/\/stroppyeditor.wordpress.com\/2015\/06\/21\/michael-gove-on-however-and-contractions\/",
      "display_url" : "stroppyeditor.wordpress.com\/2015\/06\/21\/mic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "612727294319271936",
  "geo" : { },
  "id_str" : "612728796026904576",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch a great post on this - http:\/\/t.co\/wM4xBMXPDP",
  "id" : 612728796026904576,
  "in_reply_to_status_id" : 612727294319271936,
  "created_at" : "2015-06-21 21:08:23 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Alberto Bruzos",
      "screen_name" : "abruzos",
      "indices" : [ 9, 17 ],
      "id_str" : "150242940",
      "id" : 150242940
    }, {
      "name" : "John McWhorter",
      "screen_name" : "JohnHMcWhorter",
      "indices" : [ 18, 33 ],
      "id_str" : "1306199515",
      "id" : 1306199515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612464478186287105",
  "geo" : { },
  "id_str" : "612522528662286337",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @abruzos @JohnHMcWhorter apparently South Carolina has no Hate Crime Law?",
  "id" : 612522528662286337,
  "in_reply_to_status_id" : 612464478186287105,
  "created_at" : "2015-06-21 07:28:45 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612513374841106432",
  "geo" : { },
  "id_str" : "612518621638582273",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin hehe i am pleased to have fulfilled that hope :)",
  "id" : 612518621638582273,
  "in_reply_to_status_id" : 612513374841106432,
  "created_at" : "2015-06-21 07:13:14 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Greer",
      "screen_name" : "Bonn1eGreer",
      "indices" : [ 3, 15 ],
      "id_str" : "611585332",
      "id" : 611585332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pdjeliclark\/status\/611935268267016192\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/iuJUDlCsxL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH4H3OJUkAEnTBj.jpg",
      "id_str" : "611935244640358401",
      "id" : 611935244640358401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH4H3OJUkAEnTBj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 441
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 441
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 441
      } ],
      "display_url" : "pic.twitter.com\/iuJUDlCsxL"
    } ],
    "hashtags" : [ {
      "text" : "HarrietTubman",
      "indices" : [ 17, 31 ]
    }, {
      "text" : "Juneteenth",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612214813813547008",
  "text" : "RT @Bonn1eGreer: #HarrietTubman -self-liberated from slavery-\n\"I could have freed more-if they'd known they were slaves\".\n#Juneteenth\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pdjeliclark\/status\/611935268267016192\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iuJUDlCsxL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH4H3OJUkAEnTBj.jpg",
        "id_str" : "611935244640358401",
        "id" : 611935244640358401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH4H3OJUkAEnTBj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 441
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 441
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 441
        } ],
        "display_url" : "pic.twitter.com\/iuJUDlCsxL"
      } ],
      "hashtags" : [ {
        "text" : "HarrietTubman",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "Juneteenth",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611936813758947328",
    "text" : "#HarrietTubman -self-liberated from slavery-\n\"I could have freed more-if they'd known they were slaves\".\n#Juneteenth\nhttps:\/\/t.co\/iuJUDlCsxL",
    "id" : 611936813758947328,
    "created_at" : "2015-06-19 16:41:20 +0000",
    "user" : {
      "name" : "Bonnie Greer",
      "screen_name" : "Bonn1eGreer",
      "protected" : false,
      "id_str" : "611585332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2318931685\/Bonnie_Greer_Photo_normal.JPG",
      "id" : 611585332,
      "verified" : false
    }
  },
  "id" : 612214813813547008,
  "created_at" : "2015-06-20 11:06:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611923209932439552",
  "geo" : { },
  "id_str" : "611942778617131009",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet hi got a full sunday day already on am afraid, maybe could meetup later?",
  "id" : 611942778617131009,
  "in_reply_to_status_id" : 611923209932439552,
  "created_at" : "2015-06-19 17:05:02 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/HJJXIxypQA",
      "expanded_url" : "http:\/\/russia-insider.com\/en\/russian-non-invasion-causing-concern-european-capitals\/ri8139",
      "display_url" : "russia-insider.com\/en\/russian-non\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611939592590237696",
  "text" : "Russian Non-Invasion Causing Concern in European Capitals http:\/\/t.co\/HJJXIxypQA",
  "id" : 611939592590237696,
  "created_at" : "2015-06-19 16:52:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611934276163084288",
  "geo" : { },
  "id_str" : "611934481210056704",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark being flippant re creativity is for the decision makers, knowledge for the proles",
  "id" : 611934481210056704,
  "in_reply_to_status_id" : 611934276163084288,
  "created_at" : "2015-06-19 16:32:04 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611931776659931136",
  "geo" : { },
  "id_str" : "611933598120329218",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark and knowledge is the shop floor...makes corporate sense :\/",
  "id" : 611933598120329218,
  "in_reply_to_status_id" : 611931776659931136,
  "created_at" : "2015-06-19 16:28:33 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British Council",
      "screen_name" : "ngBritish",
      "indices" : [ 3, 13 ],
      "id_str" : "149067596",
      "id" : 149067596
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ngBritish\/status\/611829625963028480\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/khr7Bky42S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH2nzVnWcAA7iEq.png",
      "id_str" : "611829624809615360",
      "id" : 611829624809615360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH2nzVnWcAA7iEq.png",
      "sizes" : [ {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/khr7Bky42S"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/GwratN2UKG",
      "expanded_url" : "https:\/\/bit.ly\/FiveUnitedComic",
      "display_url" : "bit.ly\/FiveUnitedComic"
    } ]
  },
  "geo" : { },
  "id_str" : "611832202373017600",
  "text" : "RT @ngBritish: Practise your reading skills with this great new comic from Premier Skills - British Council! https:\/\/t.co\/GwratN2UKG http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ngBritish\/status\/611829625963028480\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/khr7Bky42S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH2nzVnWcAA7iEq.png",
        "id_str" : "611829624809615360",
        "id" : 611829624809615360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH2nzVnWcAA7iEq.png",
        "sizes" : [ {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/khr7Bky42S"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/GwratN2UKG",
        "expanded_url" : "https:\/\/bit.ly\/FiveUnitedComic",
        "display_url" : "bit.ly\/FiveUnitedComic"
      } ]
    },
    "geo" : { },
    "id_str" : "611829625963028480",
    "text" : "Practise your reading skills with this great new comic from Premier Skills - British Council! https:\/\/t.co\/GwratN2UKG http:\/\/t.co\/khr7Bky42S",
    "id" : 611829625963028480,
    "created_at" : "2015-06-19 09:35:24 +0000",
    "user" : {
      "name" : "British Council",
      "screen_name" : "ngBritish",
      "protected" : false,
      "id_str" : "149067596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3763242795\/f5998c796b6b98be05dd4f15025826ff_normal.jpeg",
      "id" : 149067596,
      "verified" : false
    }
  },
  "id" : 611832202373017600,
  "created_at" : "2015-06-19 09:45:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 79, 94 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Kd5GfqTTG9",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2015\/06\/nicola-corbyn-and-the-myth-of-the-unelectable-left\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611813363077750784",
  "text" : "Nicola Corbyn and The Myth of the Unelectable Left https:\/\/t.co\/Kd5GfqTTG9 via @CraigMurrayOrg",
  "id" : 611813363077750784,
  "created_at" : "2015-06-19 08:30:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "2879372766",
      "id" : 2879372766
    }, {
      "name" : "Vivien Slezak",
      "screen_name" : "New_Life_Abroad",
      "indices" : [ 99, 115 ],
      "id_str" : "3130539051",
      "id" : 3130539051
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eflmagazine\/status\/611808709413437440\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/jZodaPzF1L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH2UxzpUEAAjQFR.png",
      "id_str" : "611808707790245888",
      "id" : 611808707790245888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH2UxzpUEAAjQFR.png",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jZodaPzF1L"
    } ],
    "hashtags" : [ {
      "text" : "eflmag",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/yzRXCSmX52",
      "expanded_url" : "http:\/\/eflmagazine.com\/taking-chunk-vocabulary-using-collocations\/",
      "display_url" : "eflmagazine.com\/taking-chunk-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611812096582524928",
  "text" : "RT @eflmagazine: http:\/\/t.co\/yzRXCSmX52\n\nEFL Magazine:Teaching Collocations, Vivien Slezak\n#eflmag @New_Life_Abroad http:\/\/t.co\/jZodaPzF1L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vivien Slezak",
        "screen_name" : "New_Life_Abroad",
        "indices" : [ 82, 98 ],
        "id_str" : "3130539051",
        "id" : 3130539051
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eflmagazine\/status\/611808709413437440\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/jZodaPzF1L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH2UxzpUEAAjQFR.png",
        "id_str" : "611808707790245888",
        "id" : 611808707790245888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH2UxzpUEAAjQFR.png",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 2560
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jZodaPzF1L"
      } ],
      "hashtags" : [ {
        "text" : "eflmag",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/yzRXCSmX52",
        "expanded_url" : "http:\/\/eflmagazine.com\/taking-chunk-vocabulary-using-collocations\/",
        "display_url" : "eflmagazine.com\/taking-chunk-v\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611808709413437440",
    "text" : "http:\/\/t.co\/yzRXCSmX52\n\nEFL Magazine:Teaching Collocations, Vivien Slezak\n#eflmag @New_Life_Abroad http:\/\/t.co\/jZodaPzF1L",
    "id" : 611808709413437440,
    "created_at" : "2015-06-19 08:12:17 +0000",
    "user" : {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "protected" : false,
      "id_str" : "2879372766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566909861871366144\/YQt7EAWR_normal.jpeg",
      "id" : 2879372766,
      "verified" : false
    }
  },
  "id" : 611812096582524928,
  "created_at" : "2015-06-19 08:25:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 3, 12 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CL2015",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iMvYUJ3vNU",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/cl2015\/doc\/Anthony.pdf",
      "display_url" : "ucrel.lancs.ac.uk\/cl2015\/doc\/Ant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611801869577531393",
  "text" : "RT @perayson: Are you interested in brainstorming the next generation of corpus software? Then sign up for our workshop at #CL2015 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CL2015",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/iMvYUJ3vNU",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/cl2015\/doc\/Anthony.pdf",
        "display_url" : "ucrel.lancs.ac.uk\/cl2015\/doc\/Ant\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611800128907780096",
    "text" : "Are you interested in brainstorming the next generation of corpus software? Then sign up for our workshop at #CL2015 http:\/\/t.co\/iMvYUJ3vNU",
    "id" : 611800128907780096,
    "created_at" : "2015-06-19 07:38:12 +0000",
    "user" : {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "protected" : false,
      "id_str" : "263108959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490485533911445505\/BNOoOchF_normal.jpeg",
      "id" : 263108959,
      "verified" : false
    }
  },
  "id" : 611801869577531393,
  "created_at" : "2015-06-19 07:45:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 117, 128 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isgoogleusefulforlanglearn",
      "indices" : [ 24, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/DnEBSbb6jf",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/jun15\/idea.htm",
      "display_url" : "hltmag.co.uk\/jun15\/idea.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "611799219410731008",
  "text" : "and here is one for the #isgoogleusefulforlanglearn Developments in Google as a Corpus http:\/\/t.co\/DnEBSbb6jf thx to @hughdellar for connect",
  "id" : 611799219410731008,
  "created_at" : "2015-06-19 07:34:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isitreallyuseful",
      "indices" : [ 12, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/agCv3DAjsX",
      "expanded_url" : "https:\/\/twitter.com\/richcauld\/status\/608000900628680705",
      "display_url" : "twitter.com\/richcauld\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611797823533776896",
  "text" : "one for the #isitreallyuseful list https:\/\/t.co\/agCv3DAjsX",
  "id" : 611797823533776896,
  "created_at" : "2015-06-19 07:29:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611640349455286272",
  "geo" : { },
  "id_str" : "611640490124029954",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel cool look fwd to the book any release date?",
  "id" : 611640490124029954,
  "in_reply_to_status_id" : 611640349455286272,
  "created_at" : "2015-06-18 21:03:51 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611639831760756737",
  "geo" : { },
  "id_str" : "611640148904775681",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel neat, what other types of collocations can it identify?",
  "id" : 611640148904775681,
  "in_reply_to_status_id" : 611639831760756737,
  "created_at" : "2015-06-18 21:02:29 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611638642381950976",
  "geo" : { },
  "id_str" : "611639383658262528",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel neat thanks, is this from one text?",
  "id" : 611639383658262528,
  "in_reply_to_status_id" : 611638642381950976,
  "created_at" : "2015-06-18 20:59:27 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611636894519070720",
  "geo" : { },
  "id_str" : "611637418161270784",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel hi nice, do you have a higher resolution image?",
  "id" : 611637418161270784,
  "in_reply_to_status_id" : 611636894519070720,
  "created_at" : "2015-06-18 20:51:38 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611603502465458176",
  "geo" : { },
  "id_str" : "611627231660638208",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran a pleasure, a great post",
  "id" : 611627231660638208,
  "in_reply_to_status_id" : 611603502465458176,
  "created_at" : "2015-06-18 20:11:10 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/dzmOBkMDF1",
      "expanded_url" : "http:\/\/linkresearchlab.org\/PreparingDigitalUniversity.pdf",
      "display_url" : "linkresearchlab.org\/PreparingDigit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611518927823351808",
  "text" : "Preparing for the digital university: review of history &amp; \ncurrent state of distance blended and online learning(pdf) http:\/\/t.co\/dzmOBkMDF1",
  "id" : 611518927823351808,
  "created_at" : "2015-06-18 13:00:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 3, 9 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 58, 73 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/SIOgt8Fy7l",
      "expanded_url" : "http:\/\/wp.me\/p39fMp-wy",
      "display_url" : "wp.me\/p39fMp-wy"
    } ]
  },
  "geo" : { },
  "id_str" : "611516530619248641",
  "text" : "RT @GemL1: Misconceptions regarding learning\/teaching via @LjiljanaHavran  http:\/\/t.co\/SIOgt8Fy7l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ljiljana Havran",
        "screen_name" : "LjiljanaHavran",
        "indices" : [ 47, 62 ],
        "id_str" : "1395825290",
        "id" : 1395825290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/SIOgt8Fy7l",
        "expanded_url" : "http:\/\/wp.me\/p39fMp-wy",
        "display_url" : "wp.me\/p39fMp-wy"
      } ]
    },
    "geo" : { },
    "id_str" : "611495012078063616",
    "text" : "Misconceptions regarding learning\/teaching via @LjiljanaHavran  http:\/\/t.co\/SIOgt8Fy7l",
    "id" : 611495012078063616,
    "created_at" : "2015-06-18 11:25:46 +0000",
    "user" : {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "protected" : false,
      "id_str" : "486146568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652399796112740353\/sQhaCdI__normal.jpg",
      "id" : 486146568,
      "verified" : false
    }
  },
  "id" : 611516530619248641,
  "created_at" : "2015-06-18 12:51:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611453930401214464",
  "geo" : { },
  "id_str" : "611513643411349504",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish yr welcome :)",
  "id" : 611513643411349504,
  "in_reply_to_status_id" : 611453930401214464,
  "created_at" : "2015-06-18 12:39:48 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/eBSNISpGQB",
      "expanded_url" : "https:\/\/www.academia.edu\/10378562\/ELT_and_the_New_World_Order_Nation_Building_or_Neocolonial_Reconstruction",
      "display_url" : "academia.edu\/10378562\/ELT_a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611513541523316736",
  "text" : "RT @ElkySmith: ELT and the New World Order: Nation Building or Neocolonial Reconstruction? By Gregory Hadley https:\/\/t.co\/eBSNISpGQB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/eBSNISpGQB",
        "expanded_url" : "https:\/\/www.academia.edu\/10378562\/ELT_and_the_New_World_Order_Nation_Building_or_Neocolonial_Reconstruction",
        "display_url" : "academia.edu\/10378562\/ELT_a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611495535321722880",
    "text" : "ELT and the New World Order: Nation Building or Neocolonial Reconstruction? By Gregory Hadley https:\/\/t.co\/eBSNISpGQB",
    "id" : 611495535321722880,
    "created_at" : "2015-06-18 11:27:51 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 611513541523316736,
  "created_at" : "2015-06-18 12:39:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 50, 66 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/2YZbK7FOwk",
      "expanded_url" : "http:\/\/wp.me\/p5jLUa-10",
      "display_url" : "wp.me\/p5jLUa-10"
    } ]
  },
  "geo" : { },
  "id_str" : "611452249693376512",
  "text" : "Affective Teacher Talk http:\/\/t.co\/2YZbK7FOwk via @getgreatenglish",
  "id" : 611452249693376512,
  "created_at" : "2015-06-18 08:35:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Ta-Nehisi Coates",
      "screen_name" : "tanehisicoates",
      "indices" : [ 96, 111 ],
      "id_str" : "2517988075",
      "id" : 2517988075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/VzRnPOYku1",
      "expanded_url" : "http:\/\/www.theatlantic.com\/politics\/archive\/2015\/06\/kalief-browder\/395963\/",
      "display_url" : "theatlantic.com\/politics\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611266679260229633",
  "text" : "RT @audreywatters: It's Kalief Browder's story, not Rachel Dolezal's, that really matters, says @tanehisicoates http:\/\/t.co\/VzRnPOYku1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ta-Nehisi Coates",
        "screen_name" : "tanehisicoates",
        "indices" : [ 77, 92 ],
        "id_str" : "2517988075",
        "id" : 2517988075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/VzRnPOYku1",
        "expanded_url" : "http:\/\/www.theatlantic.com\/politics\/archive\/2015\/06\/kalief-browder\/395963\/",
        "display_url" : "theatlantic.com\/politics\/archi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611253711810105344",
    "text" : "It's Kalief Browder's story, not Rachel Dolezal's, that really matters, says @tanehisicoates http:\/\/t.co\/VzRnPOYku1",
    "id" : 611253711810105344,
    "created_at" : "2015-06-17 19:26:56 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 611266679260229633,
  "created_at" : "2015-06-17 20:18:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/UoGEgUorRQ",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/06\/13\/ed-tech\/",
      "display_url" : "hackeducation.com\/2015\/06\/13\/ed-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611263684753686529",
  "text" : "RT @audreywatters: \"Ed-Tech\": Not an Etymology http:\/\/t.co\/UoGEgUorRQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/UoGEgUorRQ",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/06\/13\/ed-tech\/",
        "display_url" : "hackeducation.com\/2015\/06\/13\/ed-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609942685353316352",
    "text" : "\"Ed-Tech\": Not an Etymology http:\/\/t.co\/UoGEgUorRQ",
    "id" : 609942685353316352,
    "created_at" : "2015-06-14 04:37:23 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 611263684753686529,
  "created_at" : "2015-06-17 20:06:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "The Sunday Times",
      "screen_name" : "thesundaytimes",
      "indices" : [ 92, 107 ],
      "id_str" : "102707504",
      "id" : 102707504
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/611103076573949952\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4tJWvVm1P9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHsTAnrWgAAaIJH.jpg",
      "id_str" : "611103075810574336",
      "id" : 611103075810574336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHsTAnrWgAAaIJH.jpg",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 711
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 711
      } ],
      "display_url" : "pic.twitter.com\/4tJWvVm1P9"
    } ],
    "hashtags" : [ {
      "text" : "Snowden",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/bJEE3JRMbP",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/794-we-just-publish-the-position-of-the-british-government-edward-snowden-the-sunday-times-and-the-death-of-journalism.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611240715172085760",
  "text" : "RT @medialens: New Alert: \u2018We Just Publish The Position Of The British Government\u2019 #Snowden @TheSundayTimes http:\/\/t.co\/bJEE3JRMbP http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Sunday Times",
        "screen_name" : "thesundaytimes",
        "indices" : [ 77, 92 ],
        "id_str" : "102707504",
        "id" : 102707504
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/611103076573949952\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/4tJWvVm1P9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHsTAnrWgAAaIJH.jpg",
        "id_str" : "611103075810574336",
        "id" : 611103075810574336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHsTAnrWgAAaIJH.jpg",
        "sizes" : [ {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 711
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 711
        } ],
        "display_url" : "pic.twitter.com\/4tJWvVm1P9"
      } ],
      "hashtags" : [ {
        "text" : "Snowden",
        "indices" : [ 68, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/bJEE3JRMbP",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/794-we-just-publish-the-position-of-the-british-government-edward-snowden-the-sunday-times-and-the-death-of-journalism.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611103076573949952",
    "text" : "New Alert: \u2018We Just Publish The Position Of The British Government\u2019 #Snowden @TheSundayTimes http:\/\/t.co\/bJEE3JRMbP http:\/\/t.co\/4tJWvVm1P9",
    "id" : 611103076573949952,
    "created_at" : "2015-06-17 09:28:21 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 611240715172085760,
  "created_at" : "2015-06-17 18:35:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 130, 140 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/OkhiRW4kAZ",
      "expanded_url" : "http:\/\/wp.me\/p4Gcmh-eZ",
      "display_url" : "wp.me\/p4Gcmh-eZ"
    } ]
  },
  "geo" : { },
  "id_str" : "611235959615700992",
  "text" : "RT @eilymurphy: 'The strengths of Non-Native English Speaking Teachers' an infographic by Adam Simpson http:\/\/t.co\/OkhiRW4kAZ via @TeflEqui\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEFL Equity",
        "screen_name" : "TeflEquity",
        "indices" : [ 114, 125 ],
        "id_str" : "3217729433",
        "id" : 3217729433
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/OkhiRW4kAZ",
        "expanded_url" : "http:\/\/wp.me\/p4Gcmh-eZ",
        "display_url" : "wp.me\/p4Gcmh-eZ"
      } ]
    },
    "geo" : { },
    "id_str" : "611234288286203904",
    "text" : "'The strengths of Non-Native English Speaking Teachers' an infographic by Adam Simpson http:\/\/t.co\/OkhiRW4kAZ via @TeflEquity",
    "id" : 611234288286203904,
    "created_at" : "2015-06-17 18:09:45 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 611235959615700992,
  "created_at" : "2015-06-17 18:16:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 21, 30 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 31, 42 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isitreallyuseful",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611113027027496960",
  "text" : "RT @getgreatenglish: @muranava @kevchanwow Maybe we need to think about being less patronizing. Display Qs and many (not all) CCQs. #isitre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 10, 21 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "isitreallyuseful",
        "indices" : [ 111, 128 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "611107230222413824",
    "geo" : { },
    "id_str" : "611112517494927360",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava @kevchanwow Maybe we need to think about being less patronizing. Display Qs and many (not all) CCQs. #isitreallyuseful",
    "id" : 611112517494927360,
    "in_reply_to_status_id" : 611107230222413824,
    "created_at" : "2015-06-17 10:05:52 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 611113027027496960,
  "created_at" : "2015-06-17 10:07:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611110795951370240",
  "geo" : { },
  "id_str" : "611111237355745280",
  "in_reply_to_user_id" : 18602422,
  "text" : "@kevchanwow and\/or a structured\/synthetic syllabus",
  "id" : 611111237355745280,
  "in_reply_to_status_id" : 611110795951370240,
  "created_at" : "2015-06-17 10:00:47 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611110019837243392",
  "geo" : { },
  "id_str" : "611110795951370240",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow definitely, a lot of it does come from coursebooks i think?",
  "id" : 611110795951370240,
  "in_reply_to_status_id" : 611110019837243392,
  "created_at" : "2015-06-17 09:59:02 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isitreallyuseful",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611107230222413824",
  "text" : "#isitreallyuseful classrooms should reduce complexity of messy real world so do these things reduce it effectively or not?",
  "id" : 611107230222413824,
  "created_at" : "2015-06-17 09:44:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611082571078733824",
  "geo" : { },
  "id_str" : "611083283460395008",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan in the marketplace culture it looks very sane :\/",
  "id" : 611083283460395008,
  "in_reply_to_status_id" : 611082571078733824,
  "created_at" : "2015-06-17 08:09:42 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/btdXSVpuNk",
      "expanded_url" : "https:\/\/docs.google.com\/viewer?url=https:\/\/wwwrefuteddotorgdotuk.files.wordpress.com\/2015\/04\/vedasmagic.pdf",
      "display_url" : "docs.google.com\/viewer?url=htt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611081960467890177",
  "text" : "omw read this &amp; tell me NuLP, Learning Styles, Brain Training and their ilk is harmless drivel https:\/\/t.co\/btdXSVpuNk",
  "id" : 611081960467890177,
  "created_at" : "2015-06-17 08:04:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/5J7HzkwJyO",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/education\/education-news\/some-pupils-too-unruly-for-school-says-governments-behaviour-tsar-charlie-taylor-7893049.html",
      "display_url" : "independent.co.uk\/news\/education\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611080820497977345",
  "text" : "i wonder what the old behavio(u)r tsar is up to? http:\/\/t.co\/5J7HzkwJyO",
  "id" : 611080820497977345,
  "created_at" : "2015-06-17 07:59:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 119, 134 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ZFWSSQ3Ans",
      "expanded_url" : "http:\/\/theconversation.com\/facing-psychological-coercion-and-manipulation-has-become-a-daily-part-of-claiming-benefits-42839",
      "display_url" : "theconversation.com\/facing-psychol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611078563253628929",
  "text" : "Facing psychological coercion and manipulation has become a daily part of claiming benefits http:\/\/t.co\/ZFWSSQ3Ans via @ConversationUK",
  "id" : 611078563253628929,
  "created_at" : "2015-06-17 07:50:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 23, 35 ],
      "id_str" : "70341872",
      "id" : 70341872
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 65, 73 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611065431118491648",
  "text" : "interesting results of @TESOLFrance work conditions survey &amp; @Ven_VVE motivating online learners in latest teaching times",
  "id" : 611065431118491648,
  "created_at" : "2015-06-17 06:58:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 103, 119 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/iicLipsFur",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-ln",
      "display_url" : "wp.me\/p4E5tZ-ln"
    } ]
  },
  "geo" : { },
  "id_str" : "611056787236757504",
  "text" : "Think-aloud techniques - How to understand MFL learners\u2019 thinking processes http:\/\/t.co\/iicLipsFur via @gianfrancocont9",
  "id" : 611056787236757504,
  "created_at" : "2015-06-17 06:24:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 0, 13 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610844828692295680",
  "geo" : { },
  "id_str" : "610923914219401216",
  "in_reply_to_user_id" : 3243120760,
  "text" : "@versatilepub intelligent to have language?",
  "id" : 610923914219401216,
  "in_reply_to_status_id" : 610844828692295680,
  "created_at" : "2015-06-16 21:36:26 +0000",
  "in_reply_to_screen_name" : "versatilepub",
  "in_reply_to_user_id_str" : "3243120760",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 8, 21 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610779940615757827",
  "geo" : { },
  "id_str" : "610837123210547200",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed @ShetlandESOL yep things like this should be a guide not prescriptive",
  "id" : 610837123210547200,
  "in_reply_to_status_id" : 610779940615757827,
  "created_at" : "2015-06-16 15:51:33 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610836634171506688",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard obrigado por RT Rose :)",
  "id" : 610836634171506688,
  "created_at" : "2015-06-16 15:49:37 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 0, 13 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610823687382695936",
  "geo" : { },
  "id_str" : "610832619710889984",
  "in_reply_to_user_id" : 3243120760,
  "text" : "@versatilepub Chomsky on memory dependency of chunking\/formulaic lang\/construction grammar - crows have much bigger memories :)",
  "id" : 610832619710889984,
  "in_reply_to_status_id" : 610823687382695936,
  "created_at" : "2015-06-16 15:33:39 +0000",
  "in_reply_to_screen_name" : "versatilepub",
  "in_reply_to_user_id_str" : "3243120760",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sOJK8fTwiO",
      "expanded_url" : "http:\/\/nergizkern.com\/blog\/2015\/06\/grammar-in-eap-pre-sessional-courses-what-to-teach\/",
      "display_url" : "nergizkern.com\/blog\/2015\/06\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610517525286285313",
  "text" : "http:\/\/t.co\/sOJK8fTwiO Grammar in EAP pre-sessional courses: What to teach? #tleap #eapchat",
  "id" : 610517525286285313,
  "created_at" : "2015-06-15 18:41:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 0, 16 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610436708769902592",
  "geo" : { },
  "id_str" : "610437930876801024",
  "in_reply_to_user_id" : 149239362,
  "text" : "@umasslinguistic \"Ben Nimo, psychological warfare specialist\" aka professional liar?",
  "id" : 610437930876801024,
  "in_reply_to_status_id" : 610436708769902592,
  "created_at" : "2015-06-15 13:25:18 +0000",
  "in_reply_to_screen_name" : "umasslinguistic",
  "in_reply_to_user_id_str" : "149239362",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 88, 99 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/R2jJvNp3bc",
      "expanded_url" : "http:\/\/wp.me\/p1wqwD-Io",
      "display_url" : "wp.me\/p1wqwD-Io"
    } ]
  },
  "geo" : { },
  "id_str" : "610436387070996480",
  "text" : "A Bill of Rights for professional educators in FE and Skills http:\/\/t.co\/R2jJvNp3bc via @IOE_London",
  "id" : 610436387070996480,
  "created_at" : "2015-06-15 13:19:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 11, 24 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 25, 35 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 36, 46 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 47, 63 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "grassrootsELT",
      "screen_name" : "roots2go",
      "indices" : [ 64, 73 ],
      "id_str" : "3177454779",
      "id" : 3177454779
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 74, 89 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "indices" : [ 90, 105 ],
      "id_str" : "570887893",
      "id" : 570887893
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 106, 121 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610422128366759936",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @GlenysHanson @TEFLclass @nakanotim @getgreatenglish @roots2go @AnthonyTeacher @dreamreadernet @LjiljanaHavran thx for RTs! :)",
  "id" : 610422128366759936,
  "created_at" : "2015-06-15 12:22:31 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 64, 79 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/XnCl6nfffc",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1kz",
      "display_url" : "wp.me\/p3qkCB-1kz"
    } ]
  },
  "geo" : { },
  "id_str" : "610144222906327040",
  "text" : "Chomsky's Critics 2: Elizabeth Bates http:\/\/t.co\/XnCl6nfffc via @GeoffreyJordan",
  "id" : 610144222906327040,
  "created_at" : "2015-06-14 17:58:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 72, 83 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "auselt",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/zeChGZez5H",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/06\/14\/discovering-english-with-sketchengine-james-thomas-interview",
      "display_url" : "eflnotes.wordpress.com\/2015\/06\/14\/dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610089823123013633",
  "text" : "Discovering English with SketchEngine - James Thomas interview #eltchat #eltchinwag #keltchat #auselt https:\/\/t.co\/zeChGZez5H",
  "id" : 610089823123013633,
  "created_at" : "2015-06-14 14:22:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 3, 11 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cooperative",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/omQGJcDAzh",
      "expanded_url" : "http:\/\/wp.me\/p4WoHi-7t",
      "display_url" : "wp.me\/p4WoHi-7t"
    } ]
  },
  "geo" : { },
  "id_str" : "610010073386086400",
  "text" : "RT @SLBCoop: Here\u2019s what the SLB #cooperative has been up to recently http:\/\/t.co\/omQGJcDAzh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cooperative",
        "indices" : [ 20, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/omQGJcDAzh",
        "expanded_url" : "http:\/\/wp.me\/p4WoHi-7t",
        "display_url" : "wp.me\/p4WoHi-7t"
      } ]
    },
    "geo" : { },
    "id_str" : "610008145163874304",
    "text" : "Here\u2019s what the SLB #cooperative has been up to recently http:\/\/t.co\/omQGJcDAzh",
    "id" : 610008145163874304,
    "created_at" : "2015-06-14 08:57:29 +0000",
    "user" : {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "protected" : false,
      "id_str" : "2365399801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705151471386546176\/ECVLcba-_normal.jpg",
      "id" : 2365399801,
      "verified" : false
    }
  },
  "id" : 610010073386086400,
  "created_at" : "2015-06-14 09:05:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Daniel Ginsberg",
      "screen_name" : "NemaVeze",
      "indices" : [ 102, 111 ],
      "id_str" : "15678875",
      "id" : 15678875
    }, {
      "name" : "Gene Demby",
      "screen_name" : "GeeDee215",
      "indices" : [ 112, 122 ],
      "id_str" : "87359651",
      "id" : 87359651
    }, {
      "name" : "NPR's Code Switch",
      "screen_name" : "NPRCodeSwitch",
      "indices" : [ 123, 137 ],
      "id_str" : "1117836660",
      "id" : 1117836660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ByKqJqmtAT",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2015\/06\/the-curious-incident-of-rachel-dolezals-accent\/",
      "display_url" : "grieve-smith.com\/blog\/2015\/06\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610002732821430272",
  "text" : "RT @grvsmth: New blog post: The curious incident of Rachel Dole\u017Eal\u2019s accent http:\/\/t.co\/ByKqJqmtAT cc @NemaVeze @GeeDee215 @NPRCodeSwitch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Ginsberg",
        "screen_name" : "NemaVeze",
        "indices" : [ 89, 98 ],
        "id_str" : "15678875",
        "id" : 15678875
      }, {
        "name" : "Gene Demby",
        "screen_name" : "GeeDee215",
        "indices" : [ 99, 109 ],
        "id_str" : "87359651",
        "id" : 87359651
      }, {
        "name" : "NPR's Code Switch",
        "screen_name" : "NPRCodeSwitch",
        "indices" : [ 110, 124 ],
        "id_str" : "1117836660",
        "id" : 1117836660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/ByKqJqmtAT",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2015\/06\/the-curious-incident-of-rachel-dolezals-accent\/",
        "display_url" : "grieve-smith.com\/blog\/2015\/06\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609960750438871040",
    "text" : "New blog post: The curious incident of Rachel Dole\u017Eal\u2019s accent http:\/\/t.co\/ByKqJqmtAT cc @NemaVeze @GeeDee215 @NPRCodeSwitch",
    "id" : 609960750438871040,
    "created_at" : "2015-06-14 05:49:10 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 610002732821430272,
  "created_at" : "2015-06-14 08:35:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609732865136414720",
  "geo" : { },
  "id_str" : "609799458214313985",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 neat, all the best for yr talk, lk fwd to writeup",
  "id" : 609799458214313985,
  "in_reply_to_status_id" : 609732865136414720,
  "created_at" : "2015-06-13 19:08:15 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Education Week",
      "screen_name" : "educationweek",
      "indices" : [ 78, 92 ],
      "id_str" : "15147042",
      "id" : 15147042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/TrBAe7srbi",
      "expanded_url" : "http:\/\/www.edweek.org\/ew\/articles\/2015\/06\/11\/why-ed-tech-is-not-transforming-how.html",
      "display_url" : "edweek.org\/ew\/articles\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609701490467438592",
  "text" : "Why Ed Tech Is Not Transforming How Teachers Teach http:\/\/t.co\/TrBAe7srbi via @educationweek",
  "id" : 609701490467438592,
  "created_at" : "2015-06-13 12:38:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/6lBt8f4PvU",
      "expanded_url" : "https:\/\/medium.com\/@samim\/ted-rnn-machine-generated-ted-talks-3dd682b894c0",
      "display_url" : "medium.com\/@samim\/ted-rnn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609697649038598144",
  "text" : "RT @evgenymorozov: Finding out which TED Talks are machine-generated and which ones are not is the new Turing Test https:\/\/t.co\/6lBt8f4PvU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/6lBt8f4PvU",
        "expanded_url" : "https:\/\/medium.com\/@samim\/ted-rnn-machine-generated-ted-talks-3dd682b894c0",
        "display_url" : "medium.com\/@samim\/ted-rnn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609671349712330752",
    "text" : "Finding out which TED Talks are machine-generated and which ones are not is the new Turing Test https:\/\/t.co\/6lBt8f4PvU",
    "id" : 609671349712330752,
    "created_at" : "2015-06-13 10:39:11 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 609697649038598144,
  "created_at" : "2015-06-13 12:23:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/eAH69HnizO",
      "expanded_url" : "http:\/\/ift.tt\/1I8Umyt",
      "display_url" : "ift.tt\/1I8Umyt"
    } ]
  },
  "geo" : { },
  "id_str" : "609404010915885056",
  "text" : "RT @AnthonyTeacher: Getting in Bed with TED (Some ideas for using TED Talks) http:\/\/t.co\/eAH69HnizO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/eAH69HnizO",
        "expanded_url" : "http:\/\/ift.tt\/1I8Umyt",
        "display_url" : "ift.tt\/1I8Umyt"
      } ]
    },
    "geo" : { },
    "id_str" : "609364759402688512",
    "text" : "Getting in Bed with TED (Some ideas for using TED Talks) http:\/\/t.co\/eAH69HnizO",
    "id" : 609364759402688512,
    "created_at" : "2015-06-12 14:20:54 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 609404010915885056,
  "created_at" : "2015-06-12 16:56:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GZOfGwuuBb",
      "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/current",
      "display_url" : "eltj.oxfordjournals.org\/content\/current"
    } ]
  },
  "geo" : { },
  "id_str" : "609311787985575936",
  "text" : "RT @ELTResearch: ELT J just published my opinion piece- In defence of teaching and acquiring formulaic sequences. ELT Journal 69 (3) http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/GZOfGwuuBb",
        "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/current",
        "display_url" : "eltj.oxfordjournals.org\/content\/current"
      } ]
    },
    "geo" : { },
    "id_str" : "609309563754577920",
    "text" : "ELT J just published my opinion piece- In defence of teaching and acquiring formulaic sequences. ELT Journal 69 (3) http:\/\/t.co\/GZOfGwuuBb",
    "id" : 609309563754577920,
    "created_at" : "2015-06-12 10:41:35 +0000",
    "user" : {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "protected" : false,
      "id_str" : "3308043417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720360015383654400\/Zq4CQgZv_normal.jpg",
      "id" : 3308043417,
      "verified" : false
    }
  },
  "id" : 609311787985575936,
  "created_at" : "2015-06-12 10:50:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 72, 88 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/vz0M3N0jtq",
      "expanded_url" : "http:\/\/wp.me\/p64z03-2U",
      "display_url" : "wp.me\/p64z03-2U"
    } ]
  },
  "geo" : { },
  "id_str" : "609309303539941376",
  "text" : "Corpus-based Dictionary Construction for ESP http:\/\/t.co\/vz0M3N0jtq via @wordpressdotcom",
  "id" : 609309303539941376,
  "created_at" : "2015-06-12 10:40:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609296279827558400",
  "geo" : { },
  "id_str" : "609299424154624000",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch thanks :)",
  "id" : 609299424154624000,
  "in_reply_to_status_id" : 609296279827558400,
  "created_at" : "2015-06-12 10:01:17 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 3, 14 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TeflEquity\/status\/609280328813772801\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ByZitJBuZZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHSZOuXUAAEAOiN.jpg",
      "id_str" : "609280327844888577",
      "id" : 609280327844888577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHSZOuXUAAEAOiN.jpg",
      "sizes" : [ {
        "h" : 853,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 853,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ByZitJBuZZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/up7trKLqgy",
      "expanded_url" : "http:\/\/teflequityadvocates.com\/2015\/06\/12\/passport-control-by-divya-madhavan",
      "display_url" : "teflequityadvocates.com\/2015\/06\/12\/pas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609297929308913664",
  "text" : "RT @TeflEquity: \u2018Passport control\u2019 by Divya\u00A0Madhavan http:\/\/t.co\/up7trKLqgy http:\/\/t.co\/ByZitJBuZZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TeflEquity\/status\/609280328813772801\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/ByZitJBuZZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHSZOuXUAAEAOiN.jpg",
        "id_str" : "609280327844888577",
        "id" : 609280327844888577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHSZOuXUAAEAOiN.jpg",
        "sizes" : [ {
          "h" : 853,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ByZitJBuZZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/up7trKLqgy",
        "expanded_url" : "http:\/\/teflequityadvocates.com\/2015\/06\/12\/passport-control-by-divya-madhavan",
        "display_url" : "teflequityadvocates.com\/2015\/06\/12\/pas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609280328813772801",
    "text" : "\u2018Passport control\u2019 by Divya\u00A0Madhavan http:\/\/t.co\/up7trKLqgy http:\/\/t.co\/ByZitJBuZZ",
    "id" : 609280328813772801,
    "created_at" : "2015-06-12 08:45:24 +0000",
    "user" : {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "protected" : false,
      "id_str" : "3217729433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593085461976977409\/wyDI3RRR_normal.png",
      "id" : 3217729433,
      "verified" : false
    }
  },
  "id" : 609297929308913664,
  "created_at" : "2015-06-12 09:55:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/31v1z2dBXJ",
      "expanded_url" : "http:\/\/techtv.mit.edu\/videos\/9dbb107580486df7fad25f7d2f22700df6eda01e\/private",
      "display_url" : "techtv.mit.edu\/videos\/9dbb107\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609132975188516864",
  "text" : "\"crows have much larger memories [than humans]\" Chomsky put down of construction grammar memories http:\/\/t.co\/31v1z2dBXJ",
  "id" : 609132975188516864,
  "created_at" : "2015-06-11 22:59:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 120, 134 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BROJWfMMZW",
      "expanded_url" : "http:\/\/facultyoflanguage.blogspot.fr\/2015\/05\/my-hopefully-last-ever-post-on-vyvyan.html",
      "display_url" : "facultyoflanguage.blogspot.fr\/2015\/05\/my-hop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609112496444731393",
  "text" : "My (HOPEFULLY) last ever post on Vyvyan Evans and his endless dodging of the central issues  http:\/\/t.co\/BROJWfMMZW h\/t @lousylinguist",
  "id" : 609112496444731393,
  "created_at" : "2015-06-11 21:38:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seach",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "OAI",
      "indices" : [ 67, 71 ]
    }, {
      "text" : "or2015",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/p0ktJUwov1",
      "expanded_url" : "http:\/\/ow.ly\/O92bo",
      "display_url" : "ow.ly\/O92bo"
    } ]
  },
  "geo" : { },
  "id_str" : "609092508329631744",
  "text" : "RT @patrickDurusau: BASE - Bielefeld Academic Search Engine #seach #OAI #or2015 http:\/\/t.co\/p0ktJUwov1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "seach",
        "indices" : [ 40, 46 ]
      }, {
        "text" : "OAI",
        "indices" : [ 47, 51 ]
      }, {
        "text" : "or2015",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/p0ktJUwov1",
        "expanded_url" : "http:\/\/ow.ly\/O92bo",
        "display_url" : "ow.ly\/O92bo"
      } ]
    },
    "geo" : { },
    "id_str" : "608936926457004033",
    "text" : "BASE - Bielefeld Academic Search Engine #seach #OAI #or2015 http:\/\/t.co\/p0ktJUwov1",
    "id" : 608936926457004033,
    "created_at" : "2015-06-11 10:00:51 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 609092508329631744,
  "created_at" : "2015-06-11 20:19:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 86, 99 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/RmPt4LYG2F",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-Bf",
      "display_url" : "wp.me\/pKFOt-Bf"
    } ]
  },
  "geo" : { },
  "id_str" : "609091437926432768",
  "text" : "My rollercoaster day: A tribute to those who work with me: http:\/\/t.co\/RmPt4LYG2F via @rosemerebard",
  "id" : 609091437926432768,
  "created_at" : "2015-06-11 20:14:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "indices" : [ 3, 15 ],
      "id_str" : "3112144043",
      "id" : 3112144043
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/608997282797760512\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/20I95fvhSb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOXzQ3WMAAxWet.png",
      "id_str" : "608997281581379584",
      "id" : 608997281581379584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOXzQ3WMAAxWet.png",
      "sizes" : [ {
        "h" : 857,
        "resize" : "fit",
        "w" : 1256
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/20I95fvhSb"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "ESL",
      "indices" : [ 24, 28 ]
    }, {
      "text" : "tefl",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Y83QVxEP2X",
      "expanded_url" : "http:\/\/teacher-stories.com\/",
      "display_url" : "teacher-stories.com"
    } ]
  },
  "geo" : { },
  "id_str" : "609059312422543360",
  "text" : "RT @bee_visible: #ELT \/ #ESL teachers - do you have a story to tell? #tefl http:\/\/t.co\/Y83QVxEP2X http:\/\/t.co\/20I95fvhSb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/608997282797760512\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/20I95fvhSb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOXzQ3WMAAxWet.png",
        "id_str" : "608997281581379584",
        "id" : 608997281581379584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOXzQ3WMAAxWet.png",
        "sizes" : [ {
          "h" : 857,
          "resize" : "fit",
          "w" : 1256
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/20I95fvhSb"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "tefl",
        "indices" : [ 52, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/Y83QVxEP2X",
        "expanded_url" : "http:\/\/teacher-stories.com\/",
        "display_url" : "teacher-stories.com"
      } ]
    },
    "geo" : { },
    "id_str" : "608997282797760512",
    "text" : "#ELT \/ #ESL teachers - do you have a story to tell? #tefl http:\/\/t.co\/Y83QVxEP2X http:\/\/t.co\/20I95fvhSb",
    "id" : 608997282797760512,
    "created_at" : "2015-06-11 14:00:41 +0000",
    "user" : {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "protected" : false,
      "id_str" : "3112144043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629055941850320901\/kumvict0_normal.png",
      "id" : 3112144043,
      "verified" : false
    }
  },
  "id" : 609059312422543360,
  "created_at" : "2015-06-11 18:07:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 37, 47 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/4sFmv0vtbL",
      "expanded_url" : "http:\/\/wp.me\/p6aVNf-ga",
      "display_url" : "wp.me\/p6aVNf-ga"
    } ]
  },
  "geo" : { },
  "id_str" : "609048181083615232",
  "text" : "Go light! http:\/\/t.co\/4sFmv0vtbL via @HanaTicha",
  "id" : 609048181083615232,
  "created_at" : "2015-06-11 17:22:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608998400210554880",
  "geo" : { },
  "id_str" : "609023015909752832",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish i hear east asia has been superfast for yonks",
  "id" : 609023015909752832,
  "in_reply_to_status_id" : 608998400210554880,
  "created_at" : "2015-06-11 15:42:56 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/yj6Ld8qzsI",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/tag\/skylight\/",
      "display_url" : "eflnotes.wordpress.com\/tag\/skylight\/"
    } ]
  },
  "in_reply_to_status_id_str" : "608935286891008000",
  "geo" : { },
  "id_str" : "609022862809251840",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch hi some related skylight posts here https:\/\/t.co\/yj6Ld8qzsI",
  "id" : 609022862809251840,
  "in_reply_to_status_id" : 608935286891008000,
  "created_at" : "2015-06-11 15:42:20 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 0, 13 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608993140285014016",
  "geo" : { },
  "id_str" : "608994445191704576",
  "in_reply_to_user_id" : 624508480,
  "text" : "@ShetlandESOL yr welcome, look fwd to other reviews :)",
  "id" : 608994445191704576,
  "in_reply_to_status_id" : 608993140285014016,
  "created_at" : "2015-06-11 13:49:24 +0000",
  "in_reply_to_screen_name" : "ShetlandESOL",
  "in_reply_to_user_id_str" : "624508480",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608992344197730304",
  "text" : "fibreoptic connection is truely wonderous :)",
  "id" : 608992344197730304,
  "created_at" : "2015-06-11 13:41:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 48, 61 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/EO9cvZYBV6",
      "expanded_url" : "http:\/\/wp.me\/p2iBRE-20",
      "display_url" : "wp.me\/p2iBRE-20"
    } ]
  },
  "geo" : { },
  "id_str" : "608945240699973632",
  "text" : "Navigate (B1) review http:\/\/t.co\/EO9cvZYBV6 via @ShetlandESOL",
  "id" : 608945240699973632,
  "created_at" : "2015-06-11 10:33:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 60, 72 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/tUUwubPP24",
      "expanded_url" : "https:\/\/medium.com\/insurge-intelligence\/iraq-body-count-undercounting-death-with-pro-war-cash-b8ec232551a8?source=tw-lo_dnt_7ef0d132b6ae-1434017968614",
      "display_url" : "medium.com\/insurge-intell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608941630532530176",
  "text" : "\u201CIraq Body Count: undercounting death with pro-war cash\u201D by @NafeezAhmed https:\/\/t.co\/tUUwubPP24",
  "id" : 608941630532530176,
  "created_at" : "2015-06-11 10:19:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/fui9m3GCph",
      "expanded_url" : "http:\/\/leps.isi.edu\/fst\/step-all.php",
      "display_url" : "leps.isi.edu\/fst\/step-all.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608935702793990144",
  "geo" : { },
  "id_str" : "608937155738632192",
  "in_reply_to_user_id" : 3042393513,
  "text" : "@Agora_CS how about pogy? http:\/\/t.co\/fui9m3GCph",
  "id" : 608937155738632192,
  "in_reply_to_status_id" : 608935702793990144,
  "created_at" : "2015-06-11 10:01:46 +0000",
  "in_reply_to_screen_name" : "Agora_UPSaclay",
  "in_reply_to_user_id_str" : "3042393513",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 50, 66 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/JQiCcEtWnv",
      "expanded_url" : "http:\/\/wp.me\/p5jLUa-U",
      "display_url" : "wp.me\/p5jLUa-U"
    } ]
  },
  "geo" : { },
  "id_str" : "608924268441796608",
  "text" : "Checking Vocab KWIC-ly http:\/\/t.co\/JQiCcEtWnv via @getgreatenglish",
  "id" : 608924268441796608,
  "created_at" : "2015-06-11 09:10:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 3, 15 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eflchat",
      "indices" : [ 125, 133 ]
    }, {
      "text" : "efl",
      "indices" : [ 134, 138 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "langchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Qh6Y1QF6F1",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/Fifty-Ways-Teach-Technology-Teachers-ebook\/dp\/B00ZE9WLE0?tag=smarturl-jp-22",
      "display_url" : "amazon.co.jp\/Fifty-Ways-Tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608908892265959425",
  "text" : "RT @paul_sensei: My new book, \"50 Ways to Teach English with Technology\", is available on Amazon now! http:\/\/t.co\/Qh6Y1QF6F1 #eflchat #efl \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eflchat",
        "indices" : [ 108, 116 ]
      }, {
        "text" : "efl",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "esl",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "langchat",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/Qh6Y1QF6F1",
        "expanded_url" : "http:\/\/www.amazon.co.jp\/Fifty-Ways-Teach-Technology-Teachers-ebook\/dp\/B00ZE9WLE0?tag=smarturl-jp-22",
        "display_url" : "amazon.co.jp\/Fifty-Ways-Tea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608905333348564992",
    "text" : "My new book, \"50 Ways to Teach English with Technology\", is available on Amazon now! http:\/\/t.co\/Qh6Y1QF6F1 #eflchat #efl #esl #langchat",
    "id" : 608905333348564992,
    "created_at" : "2015-06-11 07:55:19 +0000",
    "user" : {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "protected" : false,
      "id_str" : "176429301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666950419248259073\/T7XVTUac_normal.jpg",
      "id" : 176429301,
      "verified" : false
    }
  },
  "id" : 608908892265959425,
  "created_at" : "2015-06-11 08:09:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 74, 83 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HLBIm1hEG8",
      "expanded_url" : "http:\/\/www.easytweets.net\/",
      "display_url" : "easytweets.net"
    } ]
  },
  "in_reply_to_status_id_str" : "608740678378508288",
  "geo" : { },
  "id_str" : "608742154454843393",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish neat look fwd to post; using twitter is cool do you know @heyboyle easytweets thang? http:\/\/t.co\/HLBIm1hEG8",
  "id" : 608742154454843393,
  "in_reply_to_status_id" : 608740678378508288,
  "created_at" : "2015-06-10 21:06:54 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608740078282809345",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thanks for RTing the HLT article Marc :)",
  "id" : 608740078282809345,
  "created_at" : "2015-06-10 20:58:39 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 56, 71 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/PTyhpC4Jrp",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1kc",
      "display_url" : "wp.me\/p3qkCB-1kc"
    } ]
  },
  "geo" : { },
  "id_str" : "608739878063468545",
  "text" : "Chomsky's Critics 1. Sampson http:\/\/t.co\/PTyhpC4Jrp via @GeoffreyJordan",
  "id" : 608739878063468545,
  "created_at" : "2015-06-10 20:57:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608398854241832961",
  "geo" : { },
  "id_str" : "608399836765933568",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish this could get all Carry On ;)",
  "id" : 608399836765933568,
  "in_reply_to_status_id" : 608398854241832961,
  "created_at" : "2015-06-09 22:26:39 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608397670022017027",
  "geo" : { },
  "id_str" : "608398384488169472",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish no doubt though am sure there'll be a few \"pivots\" on the way (i  tend to read that as \"divots\" go figure)",
  "id" : 608398384488169472,
  "in_reply_to_status_id" : 608397670022017027,
  "created_at" : "2015-06-09 22:20:53 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608396789910224898",
  "geo" : { },
  "id_str" : "608397347949821953",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish noted though edtech trends are so fickle 1 year is like an eternity :\/",
  "id" : 608397347949821953,
  "in_reply_to_status_id" : 608396789910224898,
  "created_at" : "2015-06-09 22:16:45 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theELTKerfuffles2016",
      "indices" : [ 80, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608395843826262016",
  "text" : "2014 - Mitra, 2015 - coursebooks, what are the bets for ELT heated debate 2016? #theELTKerfuffles2016 :)",
  "id" : 608395843826262016,
  "created_at" : "2015-06-09 22:10:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608391624473870337",
  "geo" : { },
  "id_str" : "608392061243559936",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard no worries Rose :)",
  "id" : 608392061243559936,
  "in_reply_to_status_id" : 608391624473870337,
  "created_at" : "2015-06-09 21:55:45 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608389677842866176",
  "geo" : { },
  "id_str" : "608391182914363392",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard re mentions works when u get immediate response or &lt; 3 peeps, otherwise reading thru it after takes a bit of filling in!",
  "id" : 608391182914363392,
  "in_reply_to_status_id" : 608389677842866176,
  "created_at" : "2015-06-09 21:52:16 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608389325148065794",
  "geo" : { },
  "id_str" : "608390121713483782",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard @getgreatenglish always interested in convos, whether of a kerfuffle nature or not",
  "id" : 608390121713483782,
  "in_reply_to_status_id" : 608389325148065794,
  "created_at" : "2015-06-09 21:48:03 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608383246972387329",
  "geo" : { },
  "id_str" : "608385969553842176",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish sure that it isn't fewer kerfuffles than usual? :)",
  "id" : 608385969553842176,
  "in_reply_to_status_id" : 608383246972387329,
  "created_at" : "2015-06-09 21:31:33 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608382170839826432",
  "geo" : { },
  "id_str" : "608383084711538688",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard good to hear, some say twitter tears are easily shed &amp; forgotten? :)",
  "id" : 608383084711538688,
  "in_reply_to_status_id" : 608382170839826432,
  "created_at" : "2015-06-09 21:20:05 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HabitatUK Help",
      "screen_name" : "HabitatHelp",
      "indices" : [ 0, 12 ],
      "id_str" : "804185748",
      "id" : 804185748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608267876634640384",
  "geo" : { },
  "id_str" : "608381597579100160",
  "in_reply_to_user_id" : 804185748,
  "text" : "@HabitatHelp ok guess have to just wait :( thx for your effort :)",
  "id" : 608381597579100160,
  "in_reply_to_status_id" : 608267876634640384,
  "created_at" : "2015-06-09 21:14:10 +0000",
  "in_reply_to_screen_name" : "HabitatHelp",
  "in_reply_to_user_id_str" : "804185748",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 31, 46 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 47, 60 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608257023692697600",
  "geo" : { },
  "id_str" : "608370423508680704",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard @getgreatenglish @GeoffreyJordan @GlenysHanson i see some more twitter CB kerfuffle be going on :\/",
  "id" : 608370423508680704,
  "in_reply_to_status_id" : 608257023692697600,
  "created_at" : "2015-06-09 20:29:46 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608304018146906114",
  "geo" : { },
  "id_str" : "608368480375685121",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 yr welcome Gemma :)",
  "id" : 608368480375685121,
  "in_reply_to_status_id" : 608304018146906114,
  "created_at" : "2015-06-09 20:22:03 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HabitatUK Help",
      "screen_name" : "HabitatHelp",
      "indices" : [ 0, 12 ],
      "id_str" : "804185748",
      "id" : 804185748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608248556588285952",
  "geo" : { },
  "id_str" : "608254089475067904",
  "in_reply_to_user_id" : 804185748,
  "text" : "@HabitatHelp we did &amp; set in motion a process, do you know how long it takes to send missing piece of furnitiure? thx",
  "id" : 608254089475067904,
  "in_reply_to_status_id" : 608248556588285952,
  "created_at" : "2015-06-09 12:47:30 +0000",
  "in_reply_to_screen_name" : "HabitatHelp",
  "in_reply_to_user_id_str" : "804185748",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 54, 60 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/CZVWRG6PEC",
      "expanded_url" : "http:\/\/wp.me\/p2NUdz-92",
      "display_url" : "wp.me\/p2NUdz-92"
    } ]
  },
  "geo" : { },
  "id_str" : "608251720238526465",
  "text" : "Positive peer observations http:\/\/t.co\/CZVWRG6PEC via @GemL1",
  "id" : 608251720238526465,
  "created_at" : "2015-06-09 12:38:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 12, 23 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Bartosz Micha\u0142owski",
      "screen_name" : "BartoszELT",
      "indices" : [ 24, 35 ],
      "id_str" : "3241595530",
      "id" : 3241595530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/etyzwfsI7P",
      "expanded_url" : "http:\/\/ikkepedia.org\/wiki\/Petter_Solberg",
      "display_url" : "ikkepedia.org\/wiki\/Petter_So\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608231373036482561",
  "geo" : { },
  "id_str" : "608233277967724544",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @hughdellar @BartoszELT there's that Swedish rally driver who uses Swedish words when speaking English http:\/\/t.co\/etyzwfsI7P",
  "id" : 608233277967724544,
  "in_reply_to_status_id" : 608231373036482561,
  "created_at" : "2015-06-09 11:24:48 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    }, {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 43, 56 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/607932196352061441\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/9T94NT0L7m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG_PHFKUkAMoF_p.png",
      "id_str" : "607932195269808131",
      "id" : 607932195269808131,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG_PHFKUkAMoF_p.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9T94NT0L7m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/23yJT4wChh",
      "expanded_url" : "http:\/\/bit.ly\/DESkE",
      "display_url" : "bit.ly\/DESkE"
    } ]
  },
  "geo" : { },
  "id_str" : "608229717876043778",
  "text" : "RT @SketchEngine: Discovering English with @SketchEngine, book by James Thomas for English teachers &amp; learners http:\/\/t.co\/23yJT4wChh http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Sketch Engine",
        "screen_name" : "SketchEngine",
        "indices" : [ 25, 38 ],
        "id_str" : "841197134",
        "id" : 841197134
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/607932196352061441\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/9T94NT0L7m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG_PHFKUkAMoF_p.png",
        "id_str" : "607932195269808131",
        "id" : 607932195269808131,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG_PHFKUkAMoF_p.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9T94NT0L7m"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/23yJT4wChh",
        "expanded_url" : "http:\/\/bit.ly\/DESkE",
        "display_url" : "bit.ly\/DESkE"
      } ]
    },
    "geo" : { },
    "id_str" : "607932196352061441",
    "text" : "Discovering English with @SketchEngine, book by James Thomas for English teachers &amp; learners http:\/\/t.co\/23yJT4wChh http:\/\/t.co\/9T94NT0L7m",
    "id" : 607932196352061441,
    "created_at" : "2015-06-08 15:28:25 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 608229717876043778,
  "created_at" : "2015-06-09 11:10:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxane Harrison",
      "screen_name" : "roxaneharrison",
      "indices" : [ 3, 18 ],
      "id_str" : "267494842",
      "id" : 267494842
    }, {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 80, 91 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/NSkkHnAM08",
      "expanded_url" : "http:\/\/wp.me\/p5jIIo-2i",
      "display_url" : "wp.me\/p5jIIo-2i"
    } ]
  },
  "geo" : { },
  "id_str" : "608227387843723264",
  "text" : "RT @roxaneharrison: A poem about corpus linguistics! http:\/\/t.co\/NSkkHnAM08 via @esl_robert",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "natiserhost197",
        "screen_name" : "esl_robert",
        "indices" : [ 60, 71 ],
        "id_str" : "2982357761",
        "id" : 2982357761
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/NSkkHnAM08",
        "expanded_url" : "http:\/\/wp.me\/p5jIIo-2i",
        "display_url" : "wp.me\/p5jIIo-2i"
      } ]
    },
    "geo" : { },
    "id_str" : "608219439692050432",
    "text" : "A poem about corpus linguistics! http:\/\/t.co\/NSkkHnAM08 via @esl_robert",
    "id" : 608219439692050432,
    "created_at" : "2015-06-09 10:29:49 +0000",
    "user" : {
      "name" : "Roxane Harrison",
      "screen_name" : "roxaneharrison",
      "protected" : false,
      "id_str" : "267494842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681603406172045312\/MFdMhP46_normal.jpg",
      "id" : 267494842,
      "verified" : false
    }
  },
  "id" : 608227387843723264,
  "created_at" : "2015-06-09 11:01:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 14, 25 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nobiasatall",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608058719461638144",
  "geo" : { },
  "id_str" : "608137014093987840",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @kevchanwow thanks Kevin, Glenys. there's some int stuff in this issue #nobiasatall :)",
  "id" : 608137014093987840,
  "in_reply_to_status_id" : 608058719461638144,
  "created_at" : "2015-06-09 05:02:17 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HabitatUK",
      "screen_name" : "HabitatUK",
      "indices" : [ 0, 10 ],
      "id_str" : "31386479",
      "id" : 31386479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607976767551361024",
  "geo" : { },
  "id_str" : "607989240174100480",
  "in_reply_to_user_id" : 31386479,
  "text" : "@HabitatUK hi habitat france, do they have a twitter account?",
  "id" : 607989240174100480,
  "in_reply_to_status_id" : 607976767551361024,
  "created_at" : "2015-06-08 19:15:05 +0000",
  "in_reply_to_screen_name" : "HabitatUK",
  "in_reply_to_user_id_str" : "31386479",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HabitatUK",
      "screen_name" : "HabitatUK",
      "indices" : [ 0, 10 ],
      "id_str" : "31386479",
      "id" : 31386479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607950071653670912",
  "in_reply_to_user_id" : 31386479,
  "text" : "@HabitatUK amazing Habitat Fr packed wrong items &amp; now have to wait for don't know how long to get a response meanwhile our lounge is a mess",
  "id" : 607950071653670912,
  "created_at" : "2015-06-08 16:39:26 +0000",
  "in_reply_to_screen_name" : "HabitatUK",
  "in_reply_to_user_id_str" : "31386479",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DnEBSbb6jf",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/jun15\/idea.htm",
      "display_url" : "hltmag.co.uk\/jun15\/idea.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "607540448328978432",
  "geo" : { },
  "id_str" : "607872997760856064",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow a pleasure, i noted your use of google search with yr students u may be interested in this http:\/\/t.co\/DnEBSbb6jf",
  "id" : 607872997760856064,
  "in_reply_to_status_id" : 607540448328978432,
  "created_at" : "2015-06-08 11:33:11 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607665043229057024",
  "geo" : { },
  "id_str" : "607666812101238784",
  "in_reply_to_user_id" : 18602422,
  "text" : "@TEFLclass oops correction - 0.07, 0.02, 0.05, 0.03, 0.2, 0.008",
  "id" : 607666812101238784,
  "in_reply_to_status_id" : 607665043229057024,
  "created_at" : "2015-06-07 21:53:52 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/T30wUs2tKk",
      "expanded_url" : "http:\/\/www.skylight-to-english.co.uk",
      "display_url" : "skylight-to-english.co.uk"
    } ]
  },
  "in_reply_to_status_id_str" : "607660427913400321",
  "geo" : { },
  "id_str" : "607665043229057024",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass PMW - 0.3, 0.02, 0.05, 0.03, 0.2, 0.008 respectively from ukWaC via http:\/\/t.co\/T30wUs2tKk",
  "id" : 607665043229057024,
  "in_reply_to_status_id" : 607660427913400321,
  "created_at" : "2015-06-07 21:46:50 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 112, 121 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "python",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "elt",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "nlp",
      "indices" : [ 135, 139 ]
    }, {
      "text" : "code",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/EKaoSmKJxa",
      "expanded_url" : "http:\/\/tmblr.co\/ZeJTqu1mdFtTB",
      "display_url" : "tmblr.co\/ZeJTqu1mdFtTB"
    } ]
  },
  "geo" : { },
  "id_str" : "607648227605774336",
  "text" : "RT @heyboyle: Notes on Python NLTK Chapter 2: what the heck is a list comprehension? http:\/\/t.co\/EKaoSmKJxa via @heyboyle #python #elt #nlp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike S. Boyle",
        "screen_name" : "heyboyle",
        "indices" : [ 98, 107 ],
        "id_str" : "612840231",
        "id" : 612840231
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "python",
        "indices" : [ 108, 115 ]
      }, {
        "text" : "elt",
        "indices" : [ 116, 120 ]
      }, {
        "text" : "nlp",
        "indices" : [ 121, 125 ]
      }, {
        "text" : "code",
        "indices" : [ 126, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/EKaoSmKJxa",
        "expanded_url" : "http:\/\/tmblr.co\/ZeJTqu1mdFtTB",
        "display_url" : "tmblr.co\/ZeJTqu1mdFtTB"
      } ]
    },
    "geo" : { },
    "id_str" : "607443047140454400",
    "text" : "Notes on Python NLTK Chapter 2: what the heck is a list comprehension? http:\/\/t.co\/EKaoSmKJxa via @heyboyle #python #elt #nlp #code",
    "id" : 607443047140454400,
    "created_at" : "2015-06-07 07:04:42 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 607648227605774336,
  "created_at" : "2015-06-07 20:40:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 3, 13 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/76kNM8rAkT",
      "expanded_url" : "https:\/\/twitter.com\/Louiseguyett\/status\/606441284602068992",
      "display_url" : "twitter.com\/Louiseguyett\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607640977315086336",
  "text" : "RT @ELTMAKERS: This is ELT Makerific. https:\/\/t.co\/76kNM8rAkT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/76kNM8rAkT",
        "expanded_url" : "https:\/\/twitter.com\/Louiseguyett\/status\/606441284602068992",
        "display_url" : "twitter.com\/Louiseguyett\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607638665309888514",
    "text" : "This is ELT Makerific. https:\/\/t.co\/76kNM8rAkT",
    "id" : 607638665309888514,
    "created_at" : "2015-06-07 20:02:01 +0000",
    "user" : {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "protected" : false,
      "id_str" : "2894570578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537944364534611969\/BegFDTeR_normal.png",
      "id" : 2894570578,
      "verified" : false
    }
  },
  "id" : 607640977315086336,
  "created_at" : "2015-06-07 20:11:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LearnerCinELT",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/56S3NLJ1xz",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/113805406013306167836",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607635096657625088",
  "text" : "RT @rosemerebard: Defining Learner-centernedness, sharing practical examples, discussing #LearnerCinELT join the community here: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LearnerCinELT",
        "indices" : [ 71, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/56S3NLJ1xz",
        "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/113805406013306167836",
        "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607606217448517632",
    "text" : "Defining Learner-centernedness, sharing practical examples, discussing #LearnerCinELT join the community here: https:\/\/t.co\/56S3NLJ1xz",
    "id" : 607606217448517632,
    "created_at" : "2015-06-07 17:53:05 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 607635096657625088,
  "created_at" : "2015-06-07 19:47:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 48, 58 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/Vr9EIUU2Wl",
      "expanded_url" : "http:\/\/wp.me\/p4osBC-a8",
      "display_url" : "wp.me\/p4osBC-a8"
    } ]
  },
  "geo" : { },
  "id_str" : "607631501891674112",
  "text" : "You Can Do Anything! http:\/\/t.co\/Vr9EIUU2Wl via @JamesTheo",
  "id" : 607631501891674112,
  "created_at" : "2015-06-07 19:33:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Gavura",
      "screen_name" : "PharmacistScott",
      "indices" : [ 3, 19 ],
      "id_str" : "19347347",
      "id" : 19347347
    }, {
      "name" : "Dilbert",
      "screen_name" : "DailyDilbert",
      "indices" : [ 52, 65 ],
      "id_str" : "21823532",
      "id" : 21823532
    }, {
      "name" : "(((Alan Henness)))",
      "screen_name" : "zeno001",
      "indices" : [ 69, 77 ],
      "id_str" : "61177115",
      "id" : 61177115
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PharmacistScott\/status\/607498134902566912\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/4OE2pQKq0p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG5EOglVAAE03ll.jpg",
      "id_str" : "607498015796953089",
      "id" : 607498015796953089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG5EOglVAAE03ll.jpg",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4OE2pQKq0p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607595308252598272",
  "text" : "RT @PharmacistScott: \"I'm Dick, from the internet.\" @dailydilbert ht @zeno001 http:\/\/t.co\/4OE2pQKq0p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dilbert",
        "screen_name" : "DailyDilbert",
        "indices" : [ 31, 44 ],
        "id_str" : "21823532",
        "id" : 21823532
      }, {
        "name" : "(((Alan Henness)))",
        "screen_name" : "zeno001",
        "indices" : [ 48, 56 ],
        "id_str" : "61177115",
        "id" : 61177115
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PharmacistScott\/status\/607498134902566912\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/4OE2pQKq0p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG5EOglVAAE03ll.jpg",
        "id_str" : "607498015796953089",
        "id" : 607498015796953089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG5EOglVAAE03ll.jpg",
        "sizes" : [ {
          "h" : 439,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4OE2pQKq0p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607498134902566912",
    "text" : "\"I'm Dick, from the internet.\" @dailydilbert ht @zeno001 http:\/\/t.co\/4OE2pQKq0p",
    "id" : 607498134902566912,
    "created_at" : "2015-06-07 10:43:36 +0000",
    "user" : {
      "name" : "Scott Gavura",
      "screen_name" : "PharmacistScott",
      "protected" : false,
      "id_str" : "19347347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720443074523054080\/457CH8Uk_normal.jpg",
      "id" : 19347347,
      "verified" : false
    }
  },
  "id" : 607595308252598272,
  "created_at" : "2015-06-07 17:09:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 122, 138 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/o5xIo5UByW",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-e2",
      "display_url" : "wp.me\/p4E5tZ-e2"
    } ]
  },
  "geo" : { },
  "id_str" : "607534945347760128",
  "text" : "Parallel texts \u2013 How they can enhance learning and effectively scaffold reading proficiency d\u2026 http:\/\/t.co\/o5xIo5UByW via @gianfrancocont9",
  "id" : 607534945347760128,
  "created_at" : "2015-06-07 13:09:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 51, 62 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/7IwoMVNjke",
      "expanded_url" : "http:\/\/wp.me\/p4dmjk-dl",
      "display_url" : "wp.me\/p4dmjk-dl"
    } ]
  },
  "geo" : { },
  "id_str" : "607534671317069824",
  "text" : "In Place of Coursebooks http:\/\/t.co\/7IwoMVNjke via @kevchanwow",
  "id" : 607534671317069824,
  "created_at" : "2015-06-07 13:08:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walton Burns",
      "screen_name" : "EnglAdvantage",
      "indices" : [ 0, 14 ],
      "id_str" : "142161003",
      "id" : 142161003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607225716107788288",
  "in_reply_to_user_id" : 142161003,
  "text" : "@EnglAdvantage hi i left comment on yr corpus post, did it go to yr spam?",
  "id" : 607225716107788288,
  "created_at" : "2015-06-06 16:41:07 +0000",
  "in_reply_to_screen_name" : "EnglAdvantage",
  "in_reply_to_user_id_str" : "142161003",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606910796778586112",
  "geo" : { },
  "id_str" : "606943563885211650",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules thanks enjoy your visit :)",
  "id" : 606943563885211650,
  "in_reply_to_status_id" : 606910796778586112,
  "created_at" : "2015-06-05 21:59:56 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walton Burns",
      "screen_name" : "EnglAdvantage",
      "indices" : [ 3, 17 ],
      "id_str" : "142161003",
      "id" : 142161003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/kvJkK37rEG",
      "expanded_url" : "http:\/\/bit.ly\/1FZn46z",
      "display_url" : "bit.ly\/1FZn46z"
    } ]
  },
  "geo" : { },
  "id_str" : "606937632036265984",
  "text" : "RT @EnglAdvantage: I just wrote about All Things Corpus! http:\/\/t.co\/kvJkK37rEG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.englishadvantage.info\" rel=\"nofollow\"\u003EEABlogPosting\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/kvJkK37rEG",
        "expanded_url" : "http:\/\/bit.ly\/1FZn46z",
        "display_url" : "bit.ly\/1FZn46z"
      } ]
    },
    "geo" : { },
    "id_str" : "606803166970019841",
    "text" : "I just wrote about All Things Corpus! http:\/\/t.co\/kvJkK37rEG",
    "id" : 606803166970019841,
    "created_at" : "2015-06-05 12:42:03 +0000",
    "user" : {
      "name" : "Walton Burns",
      "screen_name" : "EnglAdvantage",
      "protected" : false,
      "id_str" : "142161003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510469715420921856\/QJKOSHWs_normal.png",
      "id" : 142161003,
      "verified" : false
    }
  },
  "id" : 606937632036265984,
  "created_at" : "2015-06-05 21:36:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606875245463633920",
  "geo" : { },
  "id_str" : "606884565181984768",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules hi possibly but we moved flat today so depends how much energy I have :)",
  "id" : 606884565181984768,
  "in_reply_to_status_id" : 606875245463633920,
  "created_at" : "2015-06-05 18:05:30 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606828769194606592",
  "geo" : { },
  "id_str" : "606837876840644608",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB thanks hope u will continue to find it useful",
  "id" : 606837876840644608,
  "in_reply_to_status_id" : 606828769194606592,
  "created_at" : "2015-06-05 14:59:58 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606825919685103617",
  "geo" : { },
  "id_str" : "606837646980214785",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB hi search voice or elf in G+ CL community , am travelling atm",
  "id" : 606837646980214785,
  "in_reply_to_status_id" : 606825919685103617,
  "created_at" : "2015-06-05 14:59:04 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/606825357329592321\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/uoQV3H8hkg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvgcklUIAE1_2i.jpg",
      "id_str" : "606825356272607233",
      "id" : 606825356272607233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvgcklUIAE1_2i.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2160
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uoQV3H8hkg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/stSkrBcAqV",
      "expanded_url" : "https:\/\/canlloparot.wordpress.com\/2015\/06\/05\/excuses",
      "display_url" : "canlloparot.wordpress.com\/2015\/06\/05\/exc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606836844911837184",
  "text" : "RT @GeoffreyJordan: Excuses https:\/\/t.co\/stSkrBcAqV http:\/\/t.co\/uoQV3H8hkg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/606825357329592321\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/uoQV3H8hkg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvgcklUIAE1_2i.jpg",
        "id_str" : "606825356272607233",
        "id" : 606825356272607233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvgcklUIAE1_2i.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2160
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/uoQV3H8hkg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/stSkrBcAqV",
        "expanded_url" : "https:\/\/canlloparot.wordpress.com\/2015\/06\/05\/excuses",
        "display_url" : "canlloparot.wordpress.com\/2015\/06\/05\/exc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606825357329592321",
    "text" : "Excuses https:\/\/t.co\/stSkrBcAqV http:\/\/t.co\/uoQV3H8hkg",
    "id" : 606825357329592321,
    "created_at" : "2015-06-05 14:10:14 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 606836844911837184,
  "created_at" : "2015-06-05 14:55:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606825290476580864",
  "geo" : { },
  "id_str" : "606825443711447040",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB check G+ CL community",
  "id" : 606825443711447040,
  "in_reply_to_status_id" : 606825290476580864,
  "created_at" : "2015-06-05 14:10:34 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606824489083543553",
  "geo" : { },
  "id_str" : "606825078328815616",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB ah, no actual use but have suggested some ideas for voice corpus",
  "id" : 606825078328815616,
  "in_reply_to_status_id" : 606824489083543553,
  "created_at" : "2015-06-05 14:09:07 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606823440847282177",
  "geo" : { },
  "id_str" : "606824165048524800",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB hi Josette what r u using these for?",
  "id" : 606824165048524800,
  "in_reply_to_status_id" : 606823440847282177,
  "created_at" : "2015-06-05 14:05:29 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/606822464853786625\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/JxjJEv9EqN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvd0KKWcAAiBfZ.jpg",
      "id_str" : "606822462962167808",
      "id" : 606822462962167808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvd0KKWcAAiBfZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JxjJEv9EqN"
    } ],
    "hashtags" : [ {
      "text" : "whoatethemarshmallows",
      "indices" : [ 25, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606822464853786625",
  "text" : "The paper ball challenge #whoatethemarshmallows? http:\/\/t.co\/JxjJEv9EqN",
  "id" : 606822464853786625,
  "created_at" : "2015-06-05 13:58:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "indices" : [ 0, 11 ],
      "id_str" : "1559079607",
      "id" : 1559079607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606408612869750784",
  "in_reply_to_user_id" : 1559079607,
  "text" : "@TesalKoksi thanks a lot for share Tesal :)",
  "id" : 606408612869750784,
  "created_at" : "2015-06-04 10:34:14 +0000",
  "in_reply_to_screen_name" : "TesalKoksi",
  "in_reply_to_user_id_str" : "1559079607",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/sdl72jE3hx",
      "expanded_url" : "https:\/\/photos.google.com\/share\/AF1QipO9W_jZX1OCcUaT15gOsaiRRJWGXdI2Z1S6EVTKGsCn1qvwqobyOtXE5X3hNcmrAA?key=ajdIX1F2TWpJU181clZGeGtaa3VHTXd6MWFhNktR",
      "display_url" : "photos.google.com\/share\/AF1QipO9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "606393918402355200",
  "geo" : { },
  "id_str" : "606407098134593536",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco a nice one that, btw forgot to send u this earlier re a historic\/an historic https:\/\/t.co\/sdl72jE3hx",
  "id" : 606407098134593536,
  "in_reply_to_status_id" : 606393918402355200,
  "created_at" : "2015-06-04 10:28:13 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606394819204812800",
  "geo" : { },
  "id_str" : "606401715940786178",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock thanks for sharing, annoying that they have still not corrected typos in last two subtitles :\/",
  "id" : 606401715940786178,
  "in_reply_to_status_id" : 606394819204812800,
  "created_at" : "2015-06-04 10:06:50 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/DnEBSbb6jf",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/jun15\/idea.htm",
      "display_url" : "hltmag.co.uk\/jun15\/idea.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "606392464782454784",
  "geo" : { },
  "id_str" : "606393047308468224",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu good luck! u may find this relevant http:\/\/t.co\/DnEBSbb6jf",
  "id" : 606393047308468224,
  "in_reply_to_status_id" : 606392464782454784,
  "created_at" : "2015-06-04 09:32:23 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606326928199409664",
  "geo" : { },
  "id_str" : "606391097754042368",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson thanks for share David :)",
  "id" : 606391097754042368,
  "in_reply_to_status_id" : 606326928199409664,
  "created_at" : "2015-06-04 09:24:38 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DnEBSbb6jf",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/jun15\/idea.htm",
      "display_url" : "hltmag.co.uk\/jun15\/idea.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "606388085207760896",
  "geo" : { },
  "id_str" : "606390747240230912",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock alsohttp:\/\/looglefight.com\/; btw google as corpus is debatable :) practically useful for lang learn e.g. http:\/\/t.co\/DnEBSbb6jf",
  "id" : 606390747240230912,
  "in_reply_to_status_id" : 606388085207760896,
  "created_at" : "2015-06-04 09:23:14 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606171481308065792",
  "geo" : { },
  "id_str" : "606172542982864897",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d walk the CRAN packages, ye SPSS lover!",
  "id" : 606172542982864897,
  "in_reply_to_status_id" : 606171481308065792,
  "created_at" : "2015-06-03 18:56:11 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606169414975766529",
  "geo" : { },
  "id_str" : "606171113689903104",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d all hands on data frame :)",
  "id" : 606171113689903104,
  "in_reply_to_status_id" : 606169414975766529,
  "created_at" : "2015-06-03 18:50:30 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verso Books",
      "screen_name" : "VersoBooks",
      "indices" : [ 96, 107 ],
      "id_str" : "23187207",
      "id" : 23187207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/OFISGuwaqc",
      "expanded_url" : "http:\/\/www.versobooks.com\/blogs\/2000-augment-yourself-or-die-will-davies-on-the-corruption-of-happiness",
      "display_url" : "versobooks.com\/blogs\/2000-aug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606170022864633857",
  "text" : "\"Augment yourself or die\"\u2014Will Davies on the corruption of happiness http:\/\/t.co\/OFISGuwaqc via @VersoBooks",
  "id" : 606170022864633857,
  "created_at" : "2015-06-03 18:46:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3u1oC36Pqs",
      "expanded_url" : "https:\/\/lindat.mff.cuni.cz\/repository\/xmlui\/handle\/11858\/00-097C-0000-0001-CCA1-0",
      "display_url" : "lindat.mff.cuni.cz\/repository\/xml\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606125269808775169",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran thanks for RT Ljiljana, have you seen this ATC audio corpus? https:\/\/t.co\/3u1oC36Pqs",
  "id" : 606125269808775169,
  "created_at" : "2015-06-03 15:48:20 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Priestley",
      "screen_name" : "annindk",
      "indices" : [ 3, 11 ],
      "id_str" : "127530996",
      "id" : 127530996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/429ZwStgZi",
      "expanded_url" : "https:\/\/myloscar.wordpress.com\/2014\/02\/10\/corpusmooc-practical-1-using-antconc",
      "display_url" : "myloscar.wordpress.com\/2014\/02\/10\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606003291298926592",
  "text" : "RT @annindk: #corpusmooc practical 1: using\u00A0AntConc https:\/\/t.co\/429ZwStgZi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/429ZwStgZi",
        "expanded_url" : "https:\/\/myloscar.wordpress.com\/2014\/02\/10\/corpusmooc-practical-1-using-antconc",
        "display_url" : "myloscar.wordpress.com\/2014\/02\/10\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603526107841724418",
    "text" : "#corpusmooc practical 1: using\u00A0AntConc https:\/\/t.co\/429ZwStgZi",
    "id" : 603526107841724418,
    "created_at" : "2015-05-27 11:40:11 +0000",
    "user" : {
      "name" : "Ann Priestley",
      "screen_name" : "annindk",
      "protected" : false,
      "id_str" : "127530996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562162496090304512\/gWTN9idr_normal.jpeg",
      "id" : 127530996,
      "verified" : false
    }
  },
  "id" : 606003291298926592,
  "created_at" : "2015-06-03 07:43:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ul6ezkkL0i",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/jun15\/mart05.htm#C5",
      "display_url" : "hltmag.co.uk\/jun15\/mart05.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605992830025252864",
  "text" : "int argument from Iran writers re curriculums that are local relev may not prepare students for diff contexts http:\/\/t.co\/ul6ezkkL0i",
  "id" : 605992830025252864,
  "created_at" : "2015-06-03 07:02:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605970456521375744",
  "geo" : { },
  "id_str" : "605982232382160896",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy cheers Eily :)",
  "id" : 605982232382160896,
  "in_reply_to_status_id" : 605970456521375744,
  "created_at" : "2015-06-03 06:19:57 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605883787537301506",
  "geo" : { },
  "id_str" : "605982154577833984",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson thanks Glenys glad you enjoyed it :)",
  "id" : 605982154577833984,
  "in_reply_to_status_id" : 605883787537301506,
  "created_at" : "2015-06-03 06:19:38 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605872112759226368",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thanks Marc :)",
  "id" : 605872112759226368,
  "created_at" : "2015-06-02 23:02:22 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 15, 28 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605871931183603712",
  "geo" : { },
  "id_str" : "605872007469629443",
  "in_reply_to_user_id" : 18602422,
  "text" : "@TESOLacademic @GlenysHanson oops *Huw",
  "id" : 605872007469629443,
  "in_reply_to_status_id" : 605871931183603712,
  "created_at" : "2015-06-02 23:01:57 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 15, 28 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/E56Lof9aLT",
      "expanded_url" : "http:\/\/kpcbweb2.s3.amazonaws.com\/files\/90\/Internet_Trends_2015.pdf?1432854058",
      "display_url" : "kpcbweb2.s3.amazonaws.com\/files\/90\/Inter\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "605867774355726336",
  "geo" : { },
  "id_str" : "605871931183603712",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic @GlenysHanson trends noted by Hugh reflected here http:\/\/t.co\/E56Lof9aLT",
  "id" : 605871931183603712,
  "in_reply_to_status_id" : 605867774355726336,
  "created_at" : "2015-06-02 23:01:39 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 56, 64 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "kelchat",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "auselt",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/s065OvubbL",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Xr",
      "display_url" : "wp.me\/pgHyE-Xr"
    } ]
  },
  "geo" : { },
  "id_str" : "605866754745573378",
  "text" : "Skylighting: sub-query searching http:\/\/t.co\/s065OvubbL #eltchat #eltchinwag #kelchat #auselt #corpusmooc",
  "id" : 605866754745573378,
  "created_at" : "2015-06-02 22:41:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/605682658149052416\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/HxxC6EtIP2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGfRKt5WQAEkr9H.png",
      "id_str" : "605682656953647105",
      "id" : 605682656953647105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGfRKt5WQAEkr9H.png",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 708
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 708
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HxxC6EtIP2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Gkun7GJqWv",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/793-testing-the-limits-paul-krugman-of-the-new-york-times-and-gary-younge-of-the-guardian.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605842060512354304",
  "text" : "RT @medialens: Testing The Limits - Paul Krugman Of The New York Times and Gary Younge of the Guardian http:\/\/t.co\/Gkun7GJqWv http:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/605682658149052416\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/HxxC6EtIP2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGfRKt5WQAEkr9H.png",
        "id_str" : "605682656953647105",
        "id" : 605682656953647105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGfRKt5WQAEkr9H.png",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 708
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 708
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HxxC6EtIP2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/Gkun7GJqWv",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/793-testing-the-limits-paul-krugman-of-the-new-york-times-and-gary-younge-of-the-guardian.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605682658149052416",
    "text" : "Testing The Limits - Paul Krugman Of The New York Times and Gary Younge of the Guardian http:\/\/t.co\/Gkun7GJqWv http:\/\/t.co\/HxxC6EtIP2",
    "id" : 605682658149052416,
    "created_at" : "2015-06-02 10:29:33 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 605842060512354304,
  "created_at" : "2015-06-02 21:02:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605736814763073536",
  "geo" : { },
  "id_str" : "605745780297748480",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson hehe a student the other week told me about a remarkable effect of a banana spider bite :\/",
  "id" : 605745780297748480,
  "in_reply_to_status_id" : 605736814763073536,
  "created_at" : "2015-06-02 14:40:22 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/SUah7WNC5Q",
      "expanded_url" : "https:\/\/twitter.com\/flowingdata\/status\/603969846225707008",
      "display_url" : "twitter.com\/flowingdata\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605700536491515904",
  "text" : "used this when reviewing trends language in TOEIC, worked very well; my class scored 80th percentile #eltchat https:\/\/t.co\/SUah7WNC5Q",
  "id" : 605700536491515904,
  "created_at" : "2015-06-02 11:40:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 107, 111 ]
    }, {
      "text" : "tefl",
      "indices" : [ 112, 117 ]
    }, {
      "text" : "elt",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/CQBabZCT4W",
      "expanded_url" : "https:\/\/www.etprofessional.com\/the_working_hours_of_a_teacher__part_1_25769823621.aspx",
      "display_url" : "etprofessional.com\/the_working_ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605693666842263552",
  "text" : "RT @chiasuan: Do you spend a lot of your time outside your teaching hours doing prep, admin, marking, etc? #efl #tefl #elt\n\nhttps:\/\/t.co\/CQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "tefl",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "elt",
        "indices" : [ 104, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/CQBabZCT4W",
        "expanded_url" : "https:\/\/www.etprofessional.com\/the_working_hours_of_a_teacher__part_1_25769823621.aspx",
        "display_url" : "etprofessional.com\/the_working_ho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605680127624634368",
    "text" : "Do you spend a lot of your time outside your teaching hours doing prep, admin, marking, etc? #efl #tefl #elt\n\nhttps:\/\/t.co\/CQBabZCT4W",
    "id" : 605680127624634368,
    "created_at" : "2015-06-02 10:19:30 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 605693666842263552,
  "created_at" : "2015-06-02 11:13:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605687979391221760",
  "geo" : { },
  "id_str" : "605691367558377473",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter playing with coca-byu throws up some interesting uses; french use of efficace not only effective but also efficient",
  "id" : 605691367558377473,
  "in_reply_to_status_id" : 605687979391221760,
  "created_at" : "2015-06-02 11:04:09 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605510624638951425",
  "geo" : { },
  "id_str" : "605670790231638017",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas  yr welcome was recalling yr search for mwttr",
  "id" : 605670790231638017,
  "in_reply_to_status_id" : 605510624638951425,
  "created_at" : "2015-06-02 09:42:23 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605390270146871297",
  "geo" : { },
  "id_str" : "605390634753662976",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish evening :) wonder if we'll get some good light out of the coursebook heat?",
  "id" : 605390634753662976,
  "in_reply_to_status_id" : 605390270146871297,
  "created_at" : "2015-06-01 15:09:09 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 80, 96 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/XGinssUKSm",
      "expanded_url" : "http:\/\/wp.me\/p5jLUa-H",
      "display_url" : "wp.me\/p5jLUa-H"
    } ]
  },
  "geo" : { },
  "id_str" : "605390099908595712",
  "text" : "Coursebooks: the Thick and the Thin End of the Wedge http:\/\/t.co\/XGinssUKSm via @getgreatenglish",
  "id" : 605390099908595712,
  "created_at" : "2015-06-01 15:07:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/9PxwGmlOT3",
      "expanded_url" : "http:\/\/ripley.psycho.hhu.de\/koRpus\/",
      "display_url" : "ripley.psycho.hhu.de\/koRpus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "605248058893463552",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas hi have u seen this? http:\/\/t.co\/9PxwGmlOT3",
  "id" : 605248058893463552,
  "created_at" : "2015-06-01 05:42:36 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverendingTextbookDebate",
      "indices" : [ 43, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0QbjGp8jEr",
      "expanded_url" : "http:\/\/www.mikesboyle.com\/post\/120417004999\/why-i-think-textbooks-are-great-and-not-evil-but",
      "display_url" : "mikesboyle.com\/post\/120417004\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605244302843867136",
  "text" : "RT @heyboyle: I wrote some thoughts on the #NeverendingTextbookDebate so I'll never have to share them on Twitter again. 1st of 2: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverendingTextbookDebate",
        "indices" : [ 29, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/0QbjGp8jEr",
        "expanded_url" : "http:\/\/www.mikesboyle.com\/post\/120417004999\/why-i-think-textbooks-are-great-and-not-evil-but",
        "display_url" : "mikesboyle.com\/post\/120417004\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605236422778482688",
    "text" : "I wrote some thoughts on the #NeverendingTextbookDebate so I'll never have to share them on Twitter again. 1st of 2: http:\/\/t.co\/0QbjGp8jEr",
    "id" : 605236422778482688,
    "created_at" : "2015-06-01 04:56:22 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 605244302843867136,
  "created_at" : "2015-06-01 05:27:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/e3l0Hy42vO",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/05\/28\/virtual-field-trips\/",
      "display_url" : "hackeducation.com\/2015\/05\/28\/vir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605153365912363008",
  "text" : "Virtual Field Trips and Education (Technology) Inequalities http:\/\/t.co\/e3l0Hy42vO",
  "id" : 605153365912363008,
  "created_at" : "2015-05-31 23:26:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]