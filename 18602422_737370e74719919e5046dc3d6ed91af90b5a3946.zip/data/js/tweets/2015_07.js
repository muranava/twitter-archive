Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/pBPDYY0BTf",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/07\/improving-lesser-breeds.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/07\/improv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627220073107824640",
  "text" : "RT @pchallinor: New mudgeonry: Improving the lesser breeds http:\/\/t.co\/pBPDYY0BTf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/pBPDYY0BTf",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/07\/improving-lesser-breeds.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/07\/improv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626832162201866240",
    "text" : "New mudgeonry: Improving the lesser breeds http:\/\/t.co\/pBPDYY0BTf",
    "id" : 626832162201866240,
    "created_at" : "2015-07-30 19:10:08 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 627220073107824640,
  "created_at" : "2015-07-31 20:51:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "Feel Train",
      "screen_name" : "feeltraincoop",
      "indices" : [ 17, 31 ],
      "id_str" : "3256880023",
      "id" : 3256880023
    }, {
      "name" : "Stay Woke Bot",
      "screen_name" : "StayWokeBot",
      "indices" : [ 32, 44 ],
      "id_str" : "3239418560",
      "id" : 3239418560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627142038543319040",
  "geo" : { },
  "id_str" : "627202512131649536",
  "in_reply_to_user_id" : 14475298,
  "text" : "@tinysubversions @feeltraincoop @StayWokeBot  very neat thx, twitter needs a triple star fav button :)",
  "id" : 627202512131649536,
  "in_reply_to_status_id" : 627142038543319040,
  "created_at" : "2015-07-31 19:41:46 +0000",
  "in_reply_to_screen_name" : "tinysubversions",
  "in_reply_to_user_id_str" : "14475298",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627129947706933250",
  "geo" : { },
  "id_str" : "627131128768561152",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei great tgx; on android 4.4.4 the audio file is not playing?",
  "id" : 627131128768561152,
  "in_reply_to_status_id" : 627129947706933250,
  "created_at" : "2015-07-31 14:58:07 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 93, 105 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/nc1DUU0HHZ",
      "expanded_url" : "http:\/\/wp.me\/p1ZDGy-kj",
      "display_url" : "wp.me\/p1ZDGy-kj"
    } ]
  },
  "geo" : { },
  "id_str" : "627123223239491584",
  "text" : "Sneering at adult learners - why do we let them get away with it? http:\/\/t.co\/nc1DUU0HHZ via @John__Field",
  "id" : 627123223239491584,
  "created_at" : "2015-07-31 14:26:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    }, {
      "name" : "TES",
      "screen_name" : "tes",
      "indices" : [ 13, 17 ],
      "id_str" : "78874095",
      "id" : 78874095
    }, {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 18, 26 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/glnyGKR0Dc",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/02\/20\/some-obvious-notes-on-mitra-and-crawley-2014\/?preview=true",
      "display_url" : "eflnotes.wordpress.com\/2015\/02\/20\/som\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "627104696264720384",
  "geo" : { },
  "id_str" : "627108861045022720",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark @tes @Sugatam wrote some comments about that paper here https:\/\/t.co\/glnyGKR0Dc",
  "id" : 627108861045022720,
  "in_reply_to_status_id" : 627104696264720384,
  "created_at" : "2015-07-31 13:29:38 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/QWZkZgh0aK",
      "expanded_url" : "http:\/\/www.richard-hall.org\/2013\/07\/11\/moocs-and-neoliberalism-for-a-critical-response\/",
      "display_url" : "richard-hall.org\/2013\/07\/11\/moo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627096658493460481",
  "text" : "RT @ElkySmith: MOOCs and neoliberalism: for a critical response | Richard Hall's Space http:\/\/t.co\/QWZkZgh0aK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/QWZkZgh0aK",
        "expanded_url" : "http:\/\/www.richard-hall.org\/2013\/07\/11\/moocs-and-neoliberalism-for-a-critical-response\/",
        "display_url" : "richard-hall.org\/2013\/07\/11\/moo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627090189316284416",
    "text" : "MOOCs and neoliberalism: for a critical response | Richard Hall's Space http:\/\/t.co\/QWZkZgh0aK",
    "id" : 627090189316284416,
    "created_at" : "2015-07-31 12:15:26 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 627096658493460481,
  "created_at" : "2015-07-31 12:41:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "indices" : [ 3, 10 ],
      "id_str" : "2937071",
      "id" : 2937071
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/judell\/status\/626964678233624576\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/vcGrqH804W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLNtDUrUEAAK34A.jpg",
      "id_str" : "626964676992045056",
      "id" : 626964676992045056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLNtDUrUEAAK34A.jpg",
      "sizes" : [ {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 582
      } ],
      "display_url" : "pic.twitter.com\/vcGrqH804W"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/yLtaxlLenE",
      "expanded_url" : "http:\/\/blog.jonudell.net\/2015\/07\/30\/it-is-always-quiet-enough-to-talk",
      "display_url" : "blog.jonudell.net\/2015\/07\/30\/it-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627038948204875776",
  "text" : "RT @judell: \"It is always quiet enough to talk\" http:\/\/t.co\/yLtaxlLenE http:\/\/t.co\/vcGrqH804W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/judell\/status\/626964678233624576\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/vcGrqH804W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLNtDUrUEAAK34A.jpg",
        "id_str" : "626964676992045056",
        "id" : 626964676992045056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLNtDUrUEAAK34A.jpg",
        "sizes" : [ {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 582
        } ],
        "display_url" : "pic.twitter.com\/vcGrqH804W"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/yLtaxlLenE",
        "expanded_url" : "http:\/\/blog.jonudell.net\/2015\/07\/30\/it-is-always-quiet-enough-to-talk",
        "display_url" : "blog.jonudell.net\/2015\/07\/30\/it-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626964678233624576",
    "text" : "\"It is always quiet enough to talk\" http:\/\/t.co\/yLtaxlLenE http:\/\/t.co\/vcGrqH804W",
    "id" : 626964678233624576,
    "created_at" : "2015-07-31 03:56:42 +0000",
    "user" : {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "protected" : false,
      "id_str" : "2937071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630462864403267584\/maaHx7Ta_normal.jpg",
      "id" : 2937071,
      "verified" : false
    }
  },
  "id" : 627038948204875776,
  "created_at" : "2015-07-31 08:51:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627010292287799296",
  "geo" : { },
  "id_str" : "627030402864128000",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith u need add memes or somesuch  :)",
  "id" : 627030402864128000,
  "in_reply_to_status_id" : 627010292287799296,
  "created_at" : "2015-07-31 08:17:52 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/82faWhEKNL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?t=44&v=7XQRduB6oTM",
      "display_url" : "youtube.com\/watch?t=44&v=7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625745819917025284",
  "text" : "RT @heatherfro: This is a fun little video about word frequencies, Zipf distributions, and function vs content words https:\/\/t.co\/82faWhEKNL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/82faWhEKNL",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?t=44&v=7XQRduB6oTM",
        "display_url" : "youtube.com\/watch?t=44&v=7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625596377624649728",
    "text" : "This is a fun little video about word frequencies, Zipf distributions, and function vs content words https:\/\/t.co\/82faWhEKNL",
    "id" : 625596377624649728,
    "created_at" : "2015-07-27 09:19:34 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 625745819917025284,
  "created_at" : "2015-07-27 19:13:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/h6nSKindPh",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=2922",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=2922"
    } ]
  },
  "geo" : { },
  "id_str" : "625741108010700800",
  "text" : "The passive in English - http:\/\/t.co\/h6nSKindPh",
  "id" : 625741108010700800,
  "created_at" : "2015-07-27 18:54:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 3, 12 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/rAnHWkkCAe",
      "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/P7XQNK5",
      "display_url" : "surveymonkey.com\/r\/P7XQNK5"
    } ]
  },
  "geo" : { },
  "id_str" : "625733785867452416",
  "text" : "RT @Ashowski: Please take this short multi-choice survey on using coursebooks in #ELT Please feel free to pass it on!\n\nhttps:\/\/t.co\/rAnHWkk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 67, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/rAnHWkkCAe",
        "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/P7XQNK5",
        "display_url" : "surveymonkey.com\/r\/P7XQNK5"
      } ]
    },
    "geo" : { },
    "id_str" : "624370872988618752",
    "text" : "Please take this short multi-choice survey on using coursebooks in #ELT Please feel free to pass it on!\n\nhttps:\/\/t.co\/rAnHWkkCAe",
    "id" : 624370872988618752,
    "created_at" : "2015-07-24 00:09:51 +0000",
    "user" : {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "protected" : false,
      "id_str" : "316596356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701193668896681984\/nWfDqOas_normal.jpg",
      "id" : 316596356,
      "verified" : false
    }
  },
  "id" : 625733785867452416,
  "created_at" : "2015-07-27 18:25:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 106, 118 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/iiJRst1FYx",
      "expanded_url" : "http:\/\/wp.me\/p633Ji-20U",
      "display_url" : "wp.me\/p633Ji-20U"
    } ]
  },
  "geo" : { },
  "id_str" : "625732029620068352",
  "text" : "Damned Lies and Statistics: The Guardian view on Putin's mysterious popularity http:\/\/t.co\/iiJRst1FYx via @OffGuardian",
  "id" : 625732029620068352,
  "created_at" : "2015-07-27 18:18:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/OuUgwMEGq3",
      "expanded_url" : "http:\/\/www.oxfordjournals.org\/our_journals\/lexico\/adam-kilgarriff.html",
      "display_url" : "oxfordjournals.org\/our_journals\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625590162374979584",
  "text" : "RT @lexicoloco: A tribute to Adam Kilgarriff http:\/\/t.co\/OuUgwMEGq3 via International Journal of Lexicography by Michael Rundell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/OuUgwMEGq3",
        "expanded_url" : "http:\/\/www.oxfordjournals.org\/our_journals\/lexico\/adam-kilgarriff.html",
        "display_url" : "oxfordjournals.org\/our_journals\/l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623499270394671104",
    "text" : "A tribute to Adam Kilgarriff http:\/\/t.co\/OuUgwMEGq3 via International Journal of Lexicography by Michael Rundell",
    "id" : 623499270394671104,
    "created_at" : "2015-07-21 14:26:24 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 625590162374979584,
  "created_at" : "2015-07-27 08:54:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/wiHCi0CwlZ",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/07\/25\/alphasmart\/",
      "display_url" : "hackeducation.com\/2015\/07\/25\/alp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625257511801782272",
  "text" : "RT @audreywatters: AlphaSmart: A History of One of Ed-Tech's Favorite (Drop-Kickable) Writing Tools http:\/\/t.co\/wiHCi0CwlZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/wiHCi0CwlZ",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/07\/25\/alphasmart\/",
        "display_url" : "hackeducation.com\/2015\/07\/25\/alp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625071481265897472",
    "text" : "AlphaSmart: A History of One of Ed-Tech's Favorite (Drop-Kickable) Writing Tools http:\/\/t.co\/wiHCi0CwlZ",
    "id" : 625071481265897472,
    "created_at" : "2015-07-25 22:33:49 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 625257511801782272,
  "created_at" : "2015-07-26 10:53:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "indices" : [ 3, 17 ],
      "id_str" : "23783700",
      "id" : 23783700
    }, {
      "name" : "Jack Grieve",
      "screen_name" : "JWGrieve",
      "indices" : [ 57, 66 ],
      "id_str" : "2950391813",
      "id" : 2950391813
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MacDictionary\/status\/624511803184259072\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DNhDRDkuRp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKq2LQVUMAAHa_r.png",
      "id_str" : "624511802823421952",
      "id" : 624511802823421952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKq2LQVUMAAHa_r.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/DNhDRDkuRp"
    } ],
    "hashtags" : [ {
      "text" : "Twitter",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/mjX4XX6gCp",
      "expanded_url" : "http:\/\/ow.ly\/Q1JKY",
      "display_url" : "ow.ly\/Q1JKY"
    } ]
  },
  "geo" : { },
  "id_str" : "624947739395231744",
  "text" : "RT @MacDictionary: We caught up with academic researcher @JWGrieve to discuss new words on #Twitter. Read here: http:\/\/t.co\/mjX4XX6gCp http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jack Grieve",
        "screen_name" : "JWGrieve",
        "indices" : [ 38, 47 ],
        "id_str" : "2950391813",
        "id" : 2950391813
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MacDictionary\/status\/624511803184259072\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/DNhDRDkuRp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKq2LQVUMAAHa_r.png",
        "id_str" : "624511802823421952",
        "id" : 624511802823421952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKq2LQVUMAAHa_r.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/DNhDRDkuRp"
      } ],
      "hashtags" : [ {
        "text" : "Twitter",
        "indices" : [ 72, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/mjX4XX6gCp",
        "expanded_url" : "http:\/\/ow.ly\/Q1JKY",
        "display_url" : "ow.ly\/Q1JKY"
      } ]
    },
    "geo" : { },
    "id_str" : "624511803184259072",
    "text" : "We caught up with academic researcher @JWGrieve to discuss new words on #Twitter. Read here: http:\/\/t.co\/mjX4XX6gCp http:\/\/t.co\/DNhDRDkuRp",
    "id" : 624511803184259072,
    "created_at" : "2015-07-24 09:29:51 +0000",
    "user" : {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "protected" : false,
      "id_str" : "23783700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628894099307921408\/Hq12HU_i_normal.jpg",
      "id" : 23783700,
      "verified" : false
    }
  },
  "id" : 624947739395231744,
  "created_at" : "2015-07-25 14:22:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 3, 13 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pronbites\/status\/624939711333826560\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/JchYBFkM2O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKw7WzVWgAA8YVL.jpg",
      "id_str" : "624939711220580352",
      "id" : 624939711220580352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKw7WzVWgAA8YVL.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1836
      } ],
      "display_url" : "pic.twitter.com\/JchYBFkM2O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624946566764363777",
  "text" : "RT @pronbites: Schwa elision(Pret commercial) http:\/\/t.co\/JchYBFkM2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pronbites\/status\/624939711333826560\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/JchYBFkM2O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKw7WzVWgAA8YVL.jpg",
        "id_str" : "624939711220580352",
        "id" : 624939711220580352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKw7WzVWgAA8YVL.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 1836
        } ],
        "display_url" : "pic.twitter.com\/JchYBFkM2O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624939711333826560",
    "text" : "Schwa elision(Pret commercial) http:\/\/t.co\/JchYBFkM2O",
    "id" : 624939711333826560,
    "created_at" : "2015-07-25 13:50:12 +0000",
    "user" : {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "protected" : false,
      "id_str" : "2451770871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744911290766868480\/VQAhoA7h_normal.jpg",
      "id" : 2451770871,
      "verified" : false
    }
  },
  "id" : 624946566764363777,
  "created_at" : "2015-07-25 14:17:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 123, 139 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/lp2iN2notH",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-o1",
      "display_url" : "wp.me\/p4E5tZ-o1"
    } ]
  },
  "geo" : { },
  "id_str" : "624945673708941312",
  "text" : "Narrow reading and narrow listening - enhancing receptive skills through focused and purposefu\u2026 http:\/\/t.co\/lp2iN2notH via @gianfrancocont9",
  "id" : 624945673708941312,
  "created_at" : "2015-07-25 14:13:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "indices" : [ 3, 19 ],
      "id_str" : "303429700",
      "id" : 303429700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624941036205408256",
  "text" : "RT @welshnotbritish: Remember Ed Milliband promisong to ban the bedroom if they were in power? Well Labour are in power in Wales and they a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624882985385525249",
    "text" : "Remember Ed Milliband promisong to ban the bedroom if they were in power? Well Labour are in power in Wales and they are still evicting",
    "id" : 624882985385525249,
    "created_at" : "2015-07-25 10:04:48 +0000",
    "user" : {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "protected" : false,
      "id_str" : "303429700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639477893924564992\/MZGR5nLW_normal.png",
      "id" : 303429700,
      "verified" : false
    }
  },
  "id" : 624941036205408256,
  "created_at" : "2015-07-25 13:55:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/6vyKoqhZ9D",
      "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/stats\/docs\/graphcoll_manual.pdf",
      "display_url" : "corpora.lancs.ac.uk\/stats\/docs\/gra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "624929116672802816",
  "geo" : { },
  "id_str" : "624937899302223873",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword have u seen this PDF? http:\/\/t.co\/6vyKoqhZ9D",
  "id" : 624937899302223873,
  "in_reply_to_status_id" : 624929116672802816,
  "created_at" : "2015-07-25 13:43:00 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 3, 14 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lynneguist\/status\/624147779682738176\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/jeVjvC8Ym3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKlrGP-WEAAnry2.jpg",
      "id_str" : "624147778478936064",
      "id" : 624147778478936064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKlrGP-WEAAnry2.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jeVjvC8Ym3"
    } ],
    "hashtags" : [ {
      "text" : "CL2015",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624936692315766784",
  "text" : "RT @lynneguist: Alan Partington looking at how quickly language changes in White House Press Briefings... #CL2015 http:\/\/t.co\/jeVjvC8Ym3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lynneguist\/status\/624147779682738176\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/jeVjvC8Ym3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKlrGP-WEAAnry2.jpg",
        "id_str" : "624147778478936064",
        "id" : 624147778478936064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKlrGP-WEAAnry2.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jeVjvC8Ym3"
      } ],
      "hashtags" : [ {
        "text" : "CL2015",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624147779682738176",
    "text" : "Alan Partington looking at how quickly language changes in White House Press Briefings... #CL2015 http:\/\/t.co\/jeVjvC8Ym3",
    "id" : 624147779682738176,
    "created_at" : "2015-07-23 09:23:21 +0000",
    "user" : {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "protected" : false,
      "id_str" : "16316886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632304665821081601\/BiPmyu1t_normal.jpg",
      "id" : 16316886,
      "verified" : false
    }
  },
  "id" : 624936692315766784,
  "created_at" : "2015-07-25 13:38:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    }, {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 16, 25 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 26, 37 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624932100509077504",
  "geo" : { },
  "id_str" : "624935216264663040",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword @perayson @congabonga surprised no audio\/vidso recording going on amongst a gathering of linguistic folk :?",
  "id" : 624935216264663040,
  "in_reply_to_status_id" : 624932100509077504,
  "created_at" : "2015-07-25 13:32:20 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 85, 95 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/nkwiBwQF1g",
      "expanded_url" : "http:\/\/wp.me\/p2n3Kv-3l",
      "display_url" : "wp.me\/p2n3Kv-3l"
    } ]
  },
  "geo" : { },
  "id_str" : "624922994515775488",
  "text" : "A Critical Lexicon of ELT in the \u2018Digital Age\u2019: Algorithm http:\/\/t.co\/nkwiBwQF1g via @ElkySmith",
  "id" : 624922994515775488,
  "created_at" : "2015-07-25 12:43:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Clare  Lavery",
      "screen_name" : "clerotto",
      "indices" : [ 11, 20 ],
      "id_str" : "1445778456",
      "id" : 1445778456
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 21, 32 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624868263823056896",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @clerotto @lexicoloco many thx for RTing the not-twitter interview with Ivor Timmis :)",
  "id" : 624868263823056896,
  "created_at" : "2015-07-25 09:06:18 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 48, 61 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/8c01x7jOB6",
      "expanded_url" : "http:\/\/wp.me\/p3YrWZ-9m",
      "display_url" : "wp.me\/p3YrWZ-9m"
    } ]
  },
  "geo" : { },
  "id_str" : "624866231124946944",
  "text" : "Is it really useful? http:\/\/t.co\/8c01x7jOB6 via @ZhenyaDnipro",
  "id" : 624866231124946944,
  "created_at" : "2015-07-25 08:58:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Hq6N26NdWd",
      "expanded_url" : "http:\/\/bit.ly\/1Kp9A6a",
      "display_url" : "bit.ly\/1Kp9A6a"
    } ]
  },
  "geo" : { },
  "id_str" : "624711389228220417",
  "text" : "RT @nathanghall: New post --&gt; Corpus and the Principles of Good Design http:\/\/t.co\/Hq6N26NdWd #elt #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/Hq6N26NdWd",
        "expanded_url" : "http:\/\/bit.ly\/1Kp9A6a",
        "display_url" : "bit.ly\/1Kp9A6a"
      } ]
    },
    "geo" : { },
    "id_str" : "624691735969447936",
    "text" : "New post --&gt; Corpus and the Principles of Good Design http:\/\/t.co\/Hq6N26NdWd #elt #eltchat",
    "id" : 624691735969447936,
    "created_at" : "2015-07-24 21:24:50 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 624711389228220417,
  "created_at" : "2015-07-24 22:42:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoutledgeLinguistics",
      "screen_name" : "RoutledgeLing",
      "indices" : [ 3, 17 ],
      "id_str" : "40210891",
      "id" : 40210891
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 19, 28 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/6lf26rze2X",
      "expanded_url" : "http:\/\/ow.ly\/PfHv6",
      "display_url" : "ow.ly\/PfHv6"
    } ]
  },
  "geo" : { },
  "id_str" : "624553894975291392",
  "text" : "RT @RoutledgeLing: @muranava interviews Ivor Timmis over Twitter about 'Corpus Linguistics for ELT' http:\/\/t.co\/6lf26rze2X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/6lf26rze2X",
        "expanded_url" : "http:\/\/ow.ly\/PfHv6",
        "display_url" : "ow.ly\/PfHv6"
      } ]
    },
    "geo" : { },
    "id_str" : "624218866948927488",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava interviews Ivor Timmis over Twitter about 'Corpus Linguistics for ELT' http:\/\/t.co\/6lf26rze2X",
    "id" : 624218866948927488,
    "created_at" : "2015-07-23 14:05:49 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "RoutledgeLinguistics",
      "screen_name" : "RoutledgeLing",
      "protected" : false,
      "id_str" : "40210891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000760575542\/cdae8e025001fd7a8a49e889917d4f92_normal.jpeg",
      "id" : 40210891,
      "verified" : false
    }
  },
  "id" : 624553894975291392,
  "created_at" : "2015-07-24 12:17:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/DWTg6gyEO1",
      "expanded_url" : "https:\/\/sites.google.com\/site\/casualconc\/Home",
      "display_url" : "sites.google.com\/site\/casualcon\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "624244880852787200",
  "geo" : { },
  "id_str" : "624358937039622144",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl if u have osx u could try https:\/\/t.co\/DWTg6gyEO1",
  "id" : 624358937039622144,
  "in_reply_to_status_id" : 624244880852787200,
  "created_at" : "2015-07-23 23:22:25 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 0, 8 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622507891023572992",
  "geo" : { },
  "id_str" : "622512087412133888",
  "in_reply_to_user_id" : 2176726134,
  "text" : "@olyaelt i think it depends on version of word?",
  "id" : 622512087412133888,
  "in_reply_to_status_id" : 622507891023572992,
  "created_at" : "2015-07-18 21:03:42 +0000",
  "in_reply_to_screen_name" : "olyaelt",
  "in_reply_to_user_id_str" : "2176726134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 0, 8 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/5qsqo71Dcy",
      "expanded_url" : "http:\/\/textmechanic.com\/Find-and-Replace-Text.html",
      "display_url" : "textmechanic.com\/Find-and-Repla\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "622498971332792320",
  "geo" : { },
  "id_str" : "622503022078377984",
  "in_reply_to_user_id" : 2176726134,
  "text" : "@olyaelt another option is this online find replace http:\/\/t.co\/5qsqo71Dcy",
  "id" : 622503022078377984,
  "in_reply_to_status_id" : 622498971332792320,
  "created_at" : "2015-07-18 20:27:40 +0000",
  "in_reply_to_screen_name" : "olyaelt",
  "in_reply_to_user_id_str" : "2176726134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 0, 8 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622498762527780868",
  "geo" : { },
  "id_str" : "622500464844738560",
  "in_reply_to_user_id" : 2176726134,
  "text" : "@olyaelt i think recent versions of word have the pipe command",
  "id" : 622500464844738560,
  "in_reply_to_status_id" : 622498762527780868,
  "created_at" : "2015-07-18 20:17:30 +0000",
  "in_reply_to_screen_name" : "olyaelt",
  "in_reply_to_user_id_str" : "2176726134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 0, 8 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622494795081097216",
  "geo" : { },
  "id_str" : "622495945759043584",
  "in_reply_to_user_id" : 2176726134,
  "text" : "@olyaelt sure a pleasure, i guess you can do regexs in Word no?",
  "id" : 622495945759043584,
  "in_reply_to_status_id" : 622494795081097216,
  "created_at" : "2015-07-18 19:59:33 +0000",
  "in_reply_to_screen_name" : "olyaelt",
  "in_reply_to_user_id_str" : "2176726134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 85, 101 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/IiaFCYOd7J",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-1g2",
      "display_url" : "wp.me\/p21lsm-1g2"
    } ]
  },
  "geo" : { },
  "id_str" : "622490178268045312",
  "text" : "Practicing the top priority lexis - a quick and dirty tip http:\/\/t.co\/IiaFCYOd7J via @wordpressdotcom",
  "id" : 622490178268045312,
  "created_at" : "2015-07-18 19:36:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/622427072431042560\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/8yjfc7LxVT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKNOH6WW8AAimeV.png",
      "id_str" : "622427071336345600",
      "id" : 622427071336345600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKNOH6WW8AAimeV.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8yjfc7LxVT"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "ESL",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "tefl",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/96rPHIBm07",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/100289506962281954100",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622434512883044352",
  "text" : "RT @taw_sig: #ELT \/ #ESL teachers - join the conversation on working conditions! https:\/\/t.co\/96rPHIBm07 #tefl http:\/\/t.co\/8yjfc7LxVT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/622427072431042560\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/8yjfc7LxVT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKNOH6WW8AAimeV.png",
        "id_str" : "622427071336345600",
        "id" : 622427071336345600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKNOH6WW8AAimeV.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8yjfc7LxVT"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "tefl",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/96rPHIBm07",
        "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/100289506962281954100",
        "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622427072431042560",
    "text" : "#ELT \/ #ESL teachers - join the conversation on working conditions! https:\/\/t.co\/96rPHIBm07 #tefl http:\/\/t.co\/8yjfc7LxVT",
    "id" : 622427072431042560,
    "created_at" : "2015-07-18 15:25:52 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 622434512883044352,
  "created_at" : "2015-07-18 15:55:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/cUeFW6G4vf",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/12\/12\/bncaudio-corpus-and-toeic-listening\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/12\/12\/bnc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "622412944228249600",
  "geo" : { },
  "id_str" : "622423801649852416",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish another listening source to consider is the BNCaudio corpus e.g. https:\/\/t.co\/cUeFW6G4vf",
  "id" : 622423801649852416,
  "in_reply_to_status_id" : 622412944228249600,
  "created_at" : "2015-07-18 15:12:53 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622411988421836800",
  "geo" : { },
  "id_str" : "622422645934542848",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish all the best &amp; thx for the mention in the slides :)",
  "id" : 622422645934542848,
  "in_reply_to_status_id" : 622411988421836800,
  "created_at" : "2015-07-18 15:08:17 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 30, 42 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622403430389297152",
  "geo" : { },
  "id_str" : "622422554632945664",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew nice, i thought @dalecoulter article was cracking",
  "id" : 622422554632945664,
  "in_reply_to_status_id" : 622403430389297152,
  "created_at" : "2015-07-18 15:07:55 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622400489586470912",
  "geo" : { },
  "id_str" : "622404950128238592",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish when is yr talk?",
  "id" : 622404950128238592,
  "in_reply_to_status_id" : 622400489586470912,
  "created_at" : "2015-07-18 13:57:58 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622397075720814592",
  "geo" : { },
  "id_str" : "622400025050677248",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish why is your PC closed? :)",
  "id" : 622400025050677248,
  "in_reply_to_status_id" : 622397075720814592,
  "created_at" : "2015-07-18 13:38:24 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 43, 49 ],
      "id_str" : "105883895",
      "id" : 105883895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622395200938377216",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @kevchanwow many thx for RTing @tdsig newsletter :) hope yr w\/e is going good",
  "id" : 622395200938377216,
  "created_at" : "2015-07-18 13:19:14 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federica Formato",
      "screen_name" : "federicalancs",
      "indices" : [ 3, 17 ],
      "id_str" : "39983021",
      "id" : 39983021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/mAb5EjY8nq",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622323986085638145",
  "text" : "RT @federicalancs: Are you enjoying the summer break? Then it's the right time to think about something very interesting to do next: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/mAb5EjY8nq",
        "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics",
        "display_url" : "futurelearn.com\/courses\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622320673340395520",
    "text" : "Are you enjoying the summer break? Then it's the right time to think about something very interesting to do next: https:\/\/t.co\/mAb5EjY8nq",
    "id" : 622320673340395520,
    "created_at" : "2015-07-18 08:23:05 +0000",
    "user" : {
      "name" : "Federica Formato",
      "screen_name" : "federicalancs",
      "protected" : false,
      "id_str" : "39983021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726421949161824256\/UbCtWzPQ_normal.jpg",
      "id" : 39983021,
      "verified" : false
    }
  },
  "id" : 622323986085638145,
  "created_at" : "2015-07-18 08:36:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/e0m3gzJIS2",
      "expanded_url" : "http:\/\/worldlex.lexique.org\/",
      "display_url" : "worldlex.lexique.org"
    } ]
  },
  "geo" : { },
  "id_str" : "622322973932953600",
  "text" : "RT @langstat: WorldLex: Blog, Twitter and Newspapers Word Frequencies for 64 languages http:\/\/t.co\/e0m3gzJIS2 descriptive statistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/e0m3gzJIS2",
        "expanded_url" : "http:\/\/worldlex.lexique.org\/",
        "display_url" : "worldlex.lexique.org"
      } ]
    },
    "geo" : { },
    "id_str" : "622186531298525185",
    "text" : "WorldLex: Blog, Twitter and Newspapers Word Frequencies for 64 languages http:\/\/t.co\/e0m3gzJIS2 descriptive statistics",
    "id" : 622186531298525185,
    "created_at" : "2015-07-17 23:30:03 +0000",
    "user" : {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "protected" : false,
      "id_str" : "108896452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111159202\/profile_normal.gif",
      "id" : 108896452,
      "verified" : false
    }
  },
  "id" : 622322973932953600,
  "created_at" : "2015-07-18 08:32:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622180190664441857",
  "geo" : { },
  "id_str" : "622310427784052736",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson thanks &amp; yr v welcome :)",
  "id" : 622310427784052736,
  "in_reply_to_status_id" : 622180190664441857,
  "created_at" : "2015-07-18 07:42:22 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622171017914363904",
  "geo" : { },
  "id_str" : "622310278928146432",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall thanks v glad u enjoyed it :)",
  "id" : 622310278928146432,
  "in_reply_to_status_id" : 622171017914363904,
  "created_at" : "2015-07-18 07:41:47 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 91, 107 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622161445078331392",
  "geo" : { },
  "id_str" : "622165464505053184",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hey wha i see it as more slightly roaming self promo :) thx for sharing chart by @HancockMcDonald",
  "id" : 622165464505053184,
  "in_reply_to_status_id" : 622161445078331392,
  "created_at" : "2015-07-17 22:06:20 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 130, 139 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/7zG88220oG",
      "expanded_url" : "https:\/\/www.academia.edu\/14150593\/Gabrielatos_C._1994_._Materials_evaluation_and_adaptation_A_case_study_of_pronunciation_teaching._The_treatment_of_pronunciation_in_New_Cambridge_English_Course_vol._1._Essay_Research_Centre_for_English_and_Applied_Linguistics_University_of_Cambridge?s=t",
      "display_url" : "academia.edu\/14150593\/Gabri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622144992371453954",
  "text" : "Gabrielatos, C. (1994). Materials evaluation and adaptation: A case study of pronunciation teaching.  https:\/\/t.co\/7zG88220oG via @academia",
  "id" : 622144992371453954,
  "created_at" : "2015-07-17 20:44:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Robert Munro",
      "screen_name" : "WWRob",
      "indices" : [ 21, 27 ],
      "id_str" : "116897811",
      "id" : 116897811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ashes",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oacn1fWImX",
      "expanded_url" : "http:\/\/idibon.com\/bias-in-reporting-cricket\/",
      "display_url" : "idibon.com\/bias-in-report\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622123124260270080",
  "text" : "RT @TSchnoebelen: RT @WWRob: Bias when covering the cricket? An analysis of the language of English and Australian commentators http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Munro",
        "screen_name" : "WWRob",
        "indices" : [ 3, 9 ],
        "id_str" : "116897811",
        "id" : 116897811
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ashes",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/oacn1fWImX",
        "expanded_url" : "http:\/\/idibon.com\/bias-in-reporting-cricket\/",
        "display_url" : "idibon.com\/bias-in-report\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "621903897494360064",
    "geo" : { },
    "id_str" : "622071026428588036",
    "in_reply_to_user_id" : 116897811,
    "text" : "RT @WWRob: Bias when covering the cricket? An analysis of the language of English and Australian commentators http:\/\/t.co\/oacn1fWImX #Ashes",
    "id" : 622071026428588036,
    "in_reply_to_status_id" : 621903897494360064,
    "created_at" : "2015-07-17 15:51:04 +0000",
    "in_reply_to_screen_name" : "WWRob",
    "in_reply_to_user_id_str" : "116897811",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 622123124260270080,
  "created_at" : "2015-07-17 19:18:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "indices" : [ 3, 19 ],
      "id_str" : "91870534",
      "id" : 91870534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622122074287513601",
  "text" : "RT @MichaelRosenYes: Parliament votes to not go to war in Syria. RAF bombs Syria. Fair enough.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622019274572460032",
    "text" : "Parliament votes to not go to war in Syria. RAF bombs Syria. Fair enough.",
    "id" : 622019274572460032,
    "created_at" : "2015-07-17 12:25:26 +0000",
    "user" : {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "protected" : false,
      "id_str" : "91870534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488029217104207874\/F0pxhrFu_normal.jpeg",
      "id" : 91870534,
      "verified" : false
    }
  },
  "id" : 622122074287513601,
  "created_at" : "2015-07-17 19:13:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/h5e8OSjdCV",
      "expanded_url" : "https:\/\/medium.com\/bright\/the-web-we-need-to-give-students-311d97713713",
      "display_url" : "medium.com\/bright\/the-web\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622094451251482624",
  "text" : "RT @audreywatters: The Web We Need to Give Students https:\/\/t.co\/h5e8OSjdCV \u2014 why students need a domain of their own",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/h5e8OSjdCV",
        "expanded_url" : "https:\/\/medium.com\/bright\/the-web-we-need-to-give-students-311d97713713",
        "display_url" : "medium.com\/bright\/the-web\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621462387904790528",
    "text" : "The Web We Need to Give Students https:\/\/t.co\/h5e8OSjdCV \u2014 why students need a domain of their own",
    "id" : 621462387904790528,
    "created_at" : "2015-07-15 23:32:34 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 622094451251482624,
  "created_at" : "2015-07-17 17:24:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ffH5JQm1TJ",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2015\/07\/17\/greece-surrendered-but-to-whom-exactly\/",
      "display_url" : "counterpunch.org\/2015\/07\/17\/gre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622068596844437506",
  "text" : "Greece Surrendered: But to Whom Exactly?: http:\/\/t.co\/ffH5JQm1TJ",
  "id" : 622068596844437506,
  "created_at" : "2015-07-17 15:41:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622064871887249408",
  "geo" : { },
  "id_str" : "622067440227381250",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler yr welcome, a cute from-the-mouth-of-babes encounter ,hope u get rested up",
  "id" : 622067440227381250,
  "in_reply_to_status_id" : 622064871887249408,
  "created_at" : "2015-07-17 15:36:49 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 59, 71 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/wn4OokUz68",
      "expanded_url" : "http:\/\/wp.me\/p2izcv-jL",
      "display_url" : "wp.me\/p2izcv-jL"
    } ]
  },
  "geo" : { },
  "id_str" : "622063272947228672",
  "text" : "Just a tidbit from school today http:\/\/t.co\/wn4OokUz68 via @annehendler",
  "id" : 622063272947228672,
  "created_at" : "2015-07-17 15:20:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 85, 101 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/rsoySgAkbi",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-A0",
      "display_url" : "wp.me\/p4E5tZ-A0"
    } ]
  },
  "geo" : { },
  "id_str" : "622048534284664832",
  "text" : "Redefining 'creativity' in the foreign language classroom http:\/\/t.co\/rsoySgAkbi via @gianfrancocont9",
  "id" : 622048534284664832,
  "created_at" : "2015-07-17 14:21:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/5lmB5w9hr2",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/7\/17\/83159\/4776",
      "display_url" : "eurotrib.com\/story\/2015\/7\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622043613216813056",
  "text" : "The Prague moment of the European Left http:\/\/t.co\/5lmB5w9hr2",
  "id" : 622043613216813056,
  "created_at" : "2015-07-17 14:02:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Tubman",
      "screen_name" : "philtubman",
      "indices" : [ 3, 14 ],
      "id_str" : "32418010",
      "id" : 32418010
    }, {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 139, 140 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOOC",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "learningexperience",
      "indices" : [ 108, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622041044260114432",
  "text" : "RT @philtubman: pls retweet: are you a #MOOC learner (any platform)? - would like to have informal chat re: #learningexperience. For my PhD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FutureLearn",
        "screen_name" : "FutureLearn",
        "indices" : [ 125, 137 ],
        "id_str" : "999095640",
        "id" : 999095640
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MOOC",
        "indices" : [ 23, 28 ]
      }, {
        "text" : "learningexperience",
        "indices" : [ 92, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622038263625330688",
    "text" : "pls retweet: are you a #MOOC learner (any platform)? - would like to have informal chat re: #learningexperience. For my PhD. @FutureLearn",
    "id" : 622038263625330688,
    "created_at" : "2015-07-17 13:40:53 +0000",
    "user" : {
      "name" : "Phil Tubman",
      "screen_name" : "philtubman",
      "protected" : false,
      "id_str" : "32418010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525023052329803777\/8EuJDIRO_normal.png",
      "id" : 32418010,
      "verified" : false
    }
  },
  "id" : 622041044260114432,
  "created_at" : "2015-07-17 13:51:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 74, 84 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/WkqHuUAdFf",
      "expanded_url" : "http:\/\/wp.me\/p2n3Kv-3j",
      "display_url" : "wp.me\/p2n3Kv-3j"
    } ]
  },
  "geo" : { },
  "id_str" : "622036421935792128",
  "text" : "A Critical Lexicon of ELT in the 'Digital Age' http:\/\/t.co\/WkqHuUAdFf via @ElkySmith",
  "id" : 622036421935792128,
  "created_at" : "2015-07-17 13:33:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Things that matter",
      "screen_name" : "Thingsthatmat",
      "indices" : [ 125, 139 ],
      "id_str" : "2285566819",
      "id" : 2285566819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/akhg41KEza",
      "expanded_url" : "http:\/\/wp.me\/p3Z5F8-oc",
      "display_url" : "wp.me\/p3Z5F8-oc"
    } ]
  },
  "geo" : { },
  "id_str" : "622031714068643840",
  "text" : "Coca-Cola's latest advertisement: It isn\u2019t just the drink that leaves a bad taste in your mouth.: http:\/\/t.co\/akhg41KEza via @Thingsthatmat",
  "id" : 622031714068643840,
  "created_at" : "2015-07-17 13:14:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 3, 14 ],
      "id_str" : "18880320",
      "id" : 18880320
    }, {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 20, 28 ],
      "id_str" : "374391424",
      "id" : 374391424
    }, {
      "name" : "Gallery Teachers",
      "screen_name" : "Gallery_Teacher",
      "indices" : [ 31, 47 ],
      "id_str" : "2578870356",
      "id" : 2578870356
    }, {
      "name" : "Juan Alberto L Uribe",
      "screen_name" : "jaluribe",
      "indices" : [ 68, 77 ],
      "id_str" : "60421949",
      "id" : 60421949
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 84, 99 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/622026913880498176\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/164B2YGOwr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKHiLmgUMAEq8zy.png",
      "id_str" : "622026912496365569",
      "id" : 622026912496365569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKHiLmgUMAEq8zy.png",
      "sizes" : [ {
        "h" : 316,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/164B2YGOwr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Zj1XjMMI5x",
      "expanded_url" : "http:\/\/itdi.pro\/itdihome\/summer2015.php",
      "display_url" : "itdi.pro\/itdihome\/summe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622027682801426433",
  "text" : "RT @chucksandy: The @iTDipro \/ @Gallery_Teacher Intensive starts w\/ @jaluribe &amp; @thornburyscott then 20+ more! http:\/\/t.co\/Zj1XjMMI5x http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "itdi.pro",
        "screen_name" : "iTDipro",
        "indices" : [ 4, 12 ],
        "id_str" : "374391424",
        "id" : 374391424
      }, {
        "name" : "Gallery Teachers",
        "screen_name" : "Gallery_Teacher",
        "indices" : [ 15, 31 ],
        "id_str" : "2578870356",
        "id" : 2578870356
      }, {
        "name" : "Juan Alberto L Uribe",
        "screen_name" : "jaluribe",
        "indices" : [ 52, 61 ],
        "id_str" : "60421949",
        "id" : 60421949
      }, {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 68, 83 ],
        "id_str" : "23090474",
        "id" : 23090474
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/622026913880498176\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/164B2YGOwr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKHiLmgUMAEq8zy.png",
        "id_str" : "622026912496365569",
        "id" : 622026912496365569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKHiLmgUMAEq8zy.png",
        "sizes" : [ {
          "h" : 316,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/164B2YGOwr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Zj1XjMMI5x",
        "expanded_url" : "http:\/\/itdi.pro\/itdihome\/summer2015.php",
        "display_url" : "itdi.pro\/itdihome\/summe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622026913880498176",
    "text" : "The @iTDipro \/ @Gallery_Teacher Intensive starts w\/ @jaluribe &amp; @thornburyscott then 20+ more! http:\/\/t.co\/Zj1XjMMI5x http:\/\/t.co\/164B2YGOwr",
    "id" : 622026913880498176,
    "created_at" : "2015-07-17 12:55:47 +0000",
    "user" : {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "protected" : false,
      "id_str" : "18880320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620217802465513472\/poN-d2nR_normal.jpg",
      "id" : 18880320,
      "verified" : false
    }
  },
  "id" : 622027682801426433,
  "created_at" : "2015-07-17 12:58:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "laptopenglish",
      "indices" : [ 0, 14 ],
      "id_str" : "88957865",
      "id" : 88957865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/8ylfh8B7E9",
      "expanded_url" : "http:\/\/htl.linguist.univ-paris-diderot.fr\/leon\/leon_hs.pdf",
      "display_url" : "htl.linguist.univ-paris-diderot.fr\/leon\/leon_hs.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610065942186455040",
  "geo" : { },
  "id_str" : "622021533649780736",
  "in_reply_to_user_id" : 88957865,
  "text" : "@laptopenglish lol doubt he wasted people's time, re corpus linguistics &amp; Chomsky have a read of this http:\/\/t.co\/8ylfh8B7E9",
  "id" : 622021533649780736,
  "in_reply_to_status_id" : 610065942186455040,
  "created_at" : "2015-07-17 12:34:24 +0000",
  "in_reply_to_screen_name" : "laptopenglish",
  "in_reply_to_user_id_str" : "88957865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reading EngLang",
      "screen_name" : "UniRdg_EngLang",
      "indices" : [ 0, 15 ],
      "id_str" : "205727060",
      "id" : 205727060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622010629126119424",
  "geo" : { },
  "id_str" : "622020012769984512",
  "in_reply_to_user_id" : 205727060,
  "text" : "@UniRdg_EngLang thanks a lot for sharing :)",
  "id" : 622020012769984512,
  "in_reply_to_status_id" : 622010629126119424,
  "created_at" : "2015-07-17 12:28:22 +0000",
  "in_reply_to_screen_name" : "UniRdg_EngLang",
  "in_reply_to_user_id_str" : "205727060",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 13, 26 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/wn6kxrGOpY",
      "expanded_url" : "http:\/\/www.lulu.com\/spotlight\/versatilepub",
      "display_url" : "lulu.com\/spotlight\/vers\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "622017498481885184",
  "geo" : { },
  "id_str" : "622019874940973056",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @versatilepub hi here is order link http:\/\/t.co\/wn6kxrGOpY",
  "id" : 622019874940973056,
  "in_reply_to_status_id" : 622017498481885184,
  "created_at" : "2015-07-17 12:27:49 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/C1HZy7mh3f",
      "expanded_url" : "http:\/\/saaaam.s3.amazonaws.com\/VideoGrep.app.zip",
      "display_url" : "saaaam.s3.amazonaws.com\/VideoGrep.app.\u2026"
    }, {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/HSMj7S8pey",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2014\/09\/26\/easy-micro-listenings\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/09\/26\/eas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "622011238000762880",
  "geo" : { },
  "id_str" : "622012400515088384",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy hi, if u have osx u cld test gui version here http:\/\/t.co\/C1HZy7mh3f &amp; a way to use it in class here - https:\/\/t.co\/HSMj7S8pey",
  "id" : 622012400515088384,
  "in_reply_to_status_id" : 622011238000762880,
  "created_at" : "2015-07-17 11:58:07 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joanna richardson",
      "screen_name" : "jomrichardson",
      "indices" : [ 3, 17 ],
      "id_str" : "494303683",
      "id" : 494303683
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "translation",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/zAiArwN322",
      "expanded_url" : "https:\/\/twitter.com\/EconCulture\/status\/621690955117236226",
      "display_url" : "twitter.com\/EconCulture\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621990653736652800",
  "text" : "RT @jomrichardson: #translation  https:\/\/t.co\/zAiArwN322",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "translation",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/zAiArwN322",
        "expanded_url" : "https:\/\/twitter.com\/EconCulture\/status\/621690955117236226",
        "display_url" : "twitter.com\/EconCulture\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621749387904073728",
    "text" : "#translation  https:\/\/t.co\/zAiArwN322",
    "id" : 621749387904073728,
    "created_at" : "2015-07-16 18:33:00 +0000",
    "user" : {
      "name" : "joanna richardson",
      "screen_name" : "jomrichardson",
      "protected" : false,
      "id_str" : "494303683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541222186422247426\/KhlLmhAx_normal.jpeg",
      "id" : 494303683,
      "verified" : false
    }
  },
  "id" : 621990653736652800,
  "created_at" : "2015-07-17 10:31:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/Ela1u8euin",
      "expanded_url" : "http:\/\/blog.edtechie.net\/asides\/steve-jobs-isnt-your-role-model\/",
      "display_url" : "blog.edtechie.net\/asides\/steve-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621987038804488192",
  "text" : "Steve Jobs isn't your role model http:\/\/t.co\/Ela1u8euin",
  "id" : 621987038804488192,
  "created_at" : "2015-07-17 10:17:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 6, 19 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621981065696165888",
  "text" : "James @versatilepub  maybe the pic of Donald Rumsfeld shaking hands with Saddam Hussein would have been fitting :p",
  "id" : 621981065696165888,
  "created_at" : "2015-07-17 09:53:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621973583728762881",
  "geo" : { },
  "id_str" : "621974490289995776",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith two pop videos &amp; link to a Giroux article, automatic share obvo :)",
  "id" : 621974490289995776,
  "in_reply_to_status_id" : 621973583728762881,
  "created_at" : "2015-07-17 09:27:28 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 80, 90 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/jwmz8lY7Dy",
      "expanded_url" : "http:\/\/wp.me\/p2n3Kv-3f",
      "display_url" : "wp.me\/p2n3Kv-3f"
    } ]
  },
  "geo" : { },
  "id_str" : "621973453848059904",
  "text" : "'I had a dream where the car is reduced to a fossil' http:\/\/t.co\/jwmz8lY7Dy via @ElkySmith",
  "id" : 621973453848059904,
  "created_at" : "2015-07-17 09:23:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 46, 59 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621963685678858240",
  "text" : "ha wordbotcher spoonerism of birdwatcher from @versatilepub's discovering english with sketchengine book :)",
  "id" : 621963685678858240,
  "created_at" : "2015-07-17 08:44:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 17, 23 ],
      "id_str" : "105883895",
      "id" : 105883895
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notbiased",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/40Aaj59gNK",
      "expanded_url" : "http:\/\/edition.pagesuite-professional.co.uk\/Launch.aspx?EID=2a97d852-eed9-488e-88e6-6c42dd62ffee",
      "display_url" : "edition.pagesuite-professional.co.uk\/Launch.aspx?EI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621960543100768256",
  "text" : "do check the new @tdsig newsletter http:\/\/t.co\/40Aaj59gNK #notbiased :)",
  "id" : 621960543100768256,
  "created_at" : "2015-07-17 08:32:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 31, 44 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/621959467664605184\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/Z7K8QBKyKx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKGk1lbWcAAZO8z.jpg",
      "id_str" : "621959464040689664",
      "id" : 621959464040689664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKGk1lbWcAAZO8z.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/Z7K8QBKyKx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621959467664605184",
  "text" : "happy to get this today thx to @versatilepub :) http:\/\/t.co\/Z7K8QBKyKx",
  "id" : 621959467664605184,
  "created_at" : "2015-07-17 08:27:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/621765890187612160\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rpjgp2u9BN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKD0yCPWcAAsYby.png",
      "id_str" : "621765889009020928",
      "id" : 621765889009020928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKD0yCPWcAAsYby.png",
      "sizes" : [ {
        "h" : 710,
        "resize" : "fit",
        "w" : 815
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 815
      } ],
      "display_url" : "pic.twitter.com\/rpjgp2u9BN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iROdHyVdmq",
      "expanded_url" : "http:\/\/www.dougengelbart.org\/pubs\/augment-3906.html",
      "display_url" : "dougengelbart.org\/pubs\/augment-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621811374591754240",
  "text" : "RT @worrydream: Just look at how that (breathtaking) last sentence relegates \"tech\" to four words at the end.  http:\/\/t.co\/iROdHyVdmq http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/621765890187612160\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rpjgp2u9BN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKD0yCPWcAAsYby.png",
        "id_str" : "621765889009020928",
        "id" : 621765889009020928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKD0yCPWcAAsYby.png",
        "sizes" : [ {
          "h" : 710,
          "resize" : "fit",
          "w" : 815
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 815
        } ],
        "display_url" : "pic.twitter.com\/rpjgp2u9BN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/iROdHyVdmq",
        "expanded_url" : "http:\/\/www.dougengelbart.org\/pubs\/augment-3906.html",
        "display_url" : "dougengelbart.org\/pubs\/augment-3\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "621762934079930368",
    "geo" : { },
    "id_str" : "621765890187612160",
    "in_reply_to_user_id" : 255617445,
    "text" : "Just look at how that (breathtaking) last sentence relegates \"tech\" to four words at the end.  http:\/\/t.co\/iROdHyVdmq http:\/\/t.co\/rpjgp2u9BN",
    "id" : 621765890187612160,
    "in_reply_to_status_id" : 621762934079930368,
    "created_at" : "2015-07-16 19:38:34 +0000",
    "in_reply_to_screen_name" : "worrydream",
    "in_reply_to_user_id_str" : "255617445",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 621811374591754240,
  "created_at" : "2015-07-16 22:39:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "[\u02C8d\u0292e\u026An \u02C8set\u0259 ]",
      "screen_name" : "JaneSetter",
      "indices" : [ 0, 11 ],
      "id_str" : "53649036",
      "id" : 53649036
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 12, 19 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "The Ling Space",
      "screen_name" : "TheLingSpace",
      "indices" : [ 20, 33 ],
      "id_str" : "2598450223",
      "id" : 2598450223
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 71, 83 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621805100206587905",
  "in_reply_to_user_id" : 53649036,
  "text" : "@JaneSetter @DiLeed @TheLingSpace many thks for sharing interview with @ELTResearch :)",
  "id" : 621805100206587905,
  "created_at" : "2015-07-16 22:14:23 +0000",
  "in_reply_to_screen_name" : "JaneSetter",
  "in_reply_to_user_id_str" : "53649036",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/621786736109166592\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/benggxwPDw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKEHvcEWoAA0Utr.png",
      "id_str" : "621786735123537920",
      "id" : 621786735123537920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKEHvcEWoAA0Utr.png",
      "sizes" : [ {
        "h" : 369,
        "resize" : "fit",
        "w" : 223
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 223
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 223
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 223
      } ],
      "display_url" : "pic.twitter.com\/benggxwPDw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621759867280302080",
  "geo" : { },
  "id_str" : "621786736109166592",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne hi nice 2-grams! needs tweaking e.g. for songs; some of hyperlinking to supercut preview don't work http:\/\/t.co\/benggxwPDw",
  "id" : 621786736109166592,
  "in_reply_to_status_id" : 621759867280302080,
  "created_at" : "2015-07-16 21:01:24 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KIBtguzeUo",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Intelligence_amplification",
      "display_url" : "en.wikipedia.org\/wiki\/Intellige\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621773699184787456",
  "text" : "RT @worrydream: A.I. (as a \"thing\", an Other) gets the headlines. I.A. (as a medium that patterns your thinking) is often invisible. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/KIBtguzeUo",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Intelligence_amplification",
        "display_url" : "en.wikipedia.org\/wiki\/Intellige\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "621757098955796480",
    "geo" : { },
    "id_str" : "621762934079930368",
    "in_reply_to_user_id" : 255617445,
    "text" : "A.I. (as a \"thing\", an Other) gets the headlines. I.A. (as a medium that patterns your thinking) is often invisible. https:\/\/t.co\/KIBtguzeUo",
    "id" : 621762934079930368,
    "in_reply_to_status_id" : 621757098955796480,
    "created_at" : "2015-07-16 19:26:49 +0000",
    "in_reply_to_screen_name" : "worrydream",
    "in_reply_to_user_id_str" : "255617445",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 621773699184787456,
  "created_at" : "2015-07-16 20:09:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 0, 11 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621761120773251072",
  "in_reply_to_user_id" : 281361233,
  "text" : "@i_narrator thx for RT summer collocates quiz",
  "id" : 621761120773251072,
  "created_at" : "2015-07-16 19:19:37 +0000",
  "in_reply_to_screen_name" : "i_narrator",
  "in_reply_to_user_id_str" : "281361233",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sam_lavigne\/status\/621759867280302080\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/baA7AgddcR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKDvTcVWcAAvD-9.png",
      "id_str" : "621759865879425024",
      "id" : 621759865879425024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKDvTcVWcAAvD-9.png",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/baA7AgddcR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/J1o4QGlcQ0",
      "expanded_url" : "http:\/\/saaaam.s3.amazonaws.com\/VideoGrep.app.zip",
      "display_url" : "saaaam.s3.amazonaws.com\/VideoGrep.app.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621760708204699648",
  "text" : "RT @sam_lavigne: Videogrep is now a Mac application. Still in alpha, but let me know what you think! http:\/\/t.co\/J1o4QGlcQ0 http:\/\/t.co\/baA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sam_lavigne\/status\/621759867280302080\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/baA7AgddcR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKDvTcVWcAAvD-9.png",
        "id_str" : "621759865879425024",
        "id" : 621759865879425024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKDvTcVWcAAvD-9.png",
        "sizes" : [ {
          "h" : 363,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/baA7AgddcR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/J1o4QGlcQ0",
        "expanded_url" : "http:\/\/saaaam.s3.amazonaws.com\/VideoGrep.app.zip",
        "display_url" : "saaaam.s3.amazonaws.com\/VideoGrep.app.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621759867280302080",
    "text" : "Videogrep is now a Mac application. Still in alpha, but let me know what you think! http:\/\/t.co\/J1o4QGlcQ0 http:\/\/t.co\/baA7AgddcR",
    "id" : 621759867280302080,
    "created_at" : "2015-07-16 19:14:38 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 621760708204699648,
  "created_at" : "2015-07-16 19:17:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 15, 21 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/EQn3cqV1VW",
      "expanded_url" : "https:\/\/gianfrancoconti.wordpress.com\/2015\/07\/02\/learner-training-learning-to-learn-in-the-mfl-classroom-does-it-really-work\/",
      "display_url" : "gianfrancoconti.wordpress.com\/2015\/07\/02\/lea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "621703474330365952",
  "geo" : { },
  "id_str" : "621742933822283776",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis @ebefl you may find something here https:\/\/t.co\/EQn3cqV1VW",
  "id" : 621742933822283776,
  "in_reply_to_status_id" : 621703474330365952,
  "created_at" : "2015-07-16 18:07:21 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 72, 83 ]
    }, {
      "text" : "elt",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "ESL",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/y6gBKqUXhg",
      "expanded_url" : "http:\/\/corpus-quiz.englishup.me\/",
      "display_url" : "corpus-quiz.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "621742031040327684",
  "text" : "Can you guess these summer collocates? How fast? http:\/\/t.co\/y6gBKqUXhg #corpusmooc #elt #ESL happy hols folks",
  "id" : 621742031040327684,
  "created_at" : "2015-07-16 18:03:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621601078442897408",
  "geo" : { },
  "id_str" : "621603341383114752",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona indeed and representations of gender are more interesting to look at than simple counts",
  "id" : 621603341383114752,
  "in_reply_to_status_id" : 621601078442897408,
  "created_at" : "2015-07-16 08:52:40 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 44, 60 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/t42fsyuRvr",
      "expanded_url" : "http:\/\/wp.me\/p6cBF3-22",
      "display_url" : "wp.me\/p6cBF3-22"
    } ]
  },
  "geo" : { },
  "id_str" : "621599998069862400",
  "text" : "Just don't do it http:\/\/t.co\/t42fsyuRvr via @wordpressdotcom",
  "id" : 621599998069862400,
  "created_at" : "2015-07-16 08:39:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621585276343730176",
  "geo" : { },
  "id_str" : "621585809158840320",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish yikes!",
  "id" : 621585809158840320,
  "in_reply_to_status_id" : 621585276343730176,
  "created_at" : "2015-07-16 07:43:00 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621492959314219008",
  "geo" : { },
  "id_str" : "621582959775207424",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish clash of the corpora a blog post in there am sure :)",
  "id" : 621582959775207424,
  "in_reply_to_status_id" : 621492959314219008,
  "created_at" : "2015-07-16 07:31:40 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621469374826856449",
  "geo" : { },
  "id_str" : "621470036671266816",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard enjoying time off late summer nights :)",
  "id" : 621470036671266816,
  "in_reply_to_status_id" : 621469374826856449,
  "created_at" : "2015-07-16 00:02:57 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621468593411198976",
  "geo" : { },
  "id_str" : "621468900287512576",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard hi Rose all the best for your studies :)",
  "id" : 621468900287512576,
  "in_reply_to_status_id" : 621468593411198976,
  "created_at" : "2015-07-15 23:58:26 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621468165340557312",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher hey Anthony, thx for RTing simpler corpus examples :)",
  "id" : 621468165340557312,
  "created_at" : "2015-07-15 23:55:31 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 48, 59 ]
    }, {
      "text" : "np",
      "indices" : [ 61, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/eZturfWQJB",
      "expanded_url" : "https:\/\/soundcloud.com\/montmartremusic\/summertape-2?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/montmartremusi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621467973379883008",
  "text" : "Have you heard \u2018Summertape #2\u2019 by MONTMARTRE on #SoundCloud? #np https:\/\/t.co\/eZturfWQJB",
  "id" : 621467973379883008,
  "created_at" : "2015-07-15 23:54:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "esl",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "learnenglish",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "621272570340503556",
  "text" : "work out is a top 30 phrasal verb, with 4 common meanings, check what they are at http:\/\/t.co\/feVV1F8lKr #elt  #esl #learnenglish",
  "id" : 621272570340503556,
  "created_at" : "2015-07-15 10:58:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 56, 72 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/x7scwgdD36",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-EX",
      "display_url" : "wp.me\/p25Kfd-EX"
    } ]
  },
  "geo" : { },
  "id_str" : "621246969030250496",
  "text" : "I am a used car [Guest Post] http:\/\/t.co\/x7scwgdD36 via @michaelegriffin",
  "id" : 621246969030250496,
  "created_at" : "2015-07-15 09:16:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 3, 14 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/745LFbO05B",
      "expanded_url" : "http:\/\/bit.ly\/1O5I7ag",
      "display_url" : "bit.ly\/1O5I7ag"
    } ]
  },
  "geo" : { },
  "id_str" : "621243867006926848",
  "text" : "RT @AchilleasK: Apparently Google outperforms Turnitin for plagiarism detection. Plus it's free. http:\/\/t.co\/745LFbO05B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/745LFbO05B",
        "expanded_url" : "http:\/\/bit.ly\/1O5I7ag",
        "display_url" : "bit.ly\/1O5I7ag"
      } ]
    },
    "geo" : { },
    "id_str" : "621238581202395136",
    "text" : "Apparently Google outperforms Turnitin for plagiarism detection. Plus it's free. http:\/\/t.co\/745LFbO05B",
    "id" : 621238581202395136,
    "created_at" : "2015-07-15 08:43:14 +0000",
    "user" : {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "protected" : false,
      "id_str" : "134191406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765621437826797569\/1o7CwbeK_normal.jpg",
      "id" : 134191406,
      "verified" : false
    }
  },
  "id" : 621243867006926848,
  "created_at" : "2015-07-15 09:04:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621237119537807360",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thx for COCA grammar search terms RT :)",
  "id" : 621237119537807360,
  "created_at" : "2015-07-15 08:37:25 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621117389627916290",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch thanks for RT :)",
  "id" : 621117389627916290,
  "created_at" : "2015-07-15 00:41:40 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/aNvhTvUdh5",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/EJVWCm8Dnkf",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621116761505665025",
  "text" : "some neat COCA gramma search terms https:\/\/t.co\/aNvhTvUdh5 #corpusmooc",
  "id" : 621116761505665025,
  "created_at" : "2015-07-15 00:39:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 3, 16 ],
      "id_str" : "20932918",
      "id" : 20932918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/fWgMwpjAiR",
      "expanded_url" : "http:\/\/gu.com\/p\/4ak44?CMP=Share_AndroidApp_Twitter",
      "display_url" : "gu.com\/p\/4ak44?CMP=Sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621004898541400064",
  "text" : "RT @blairteacher: SNP's Mhairi Black attacks housing benefit cuts in first Commons speech\n\nhttp:\/\/t.co\/fWgMwpjAiR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/fWgMwpjAiR",
        "expanded_url" : "http:\/\/gu.com\/p\/4ak44?CMP=Share_AndroidApp_Twitter",
        "display_url" : "gu.com\/p\/4ak44?CMP=Sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621003977635823616",
    "text" : "SNP's Mhairi Black attacks housing benefit cuts in first Commons speech\n\nhttp:\/\/t.co\/fWgMwpjAiR",
    "id" : 621003977635823616,
    "created_at" : "2015-07-14 17:11:00 +0000",
    "user" : {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "protected" : false,
      "id_str" : "20932918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473405104729493504\/mK908m7N_normal.jpeg",
      "id" : 20932918,
      "verified" : false
    }
  },
  "id" : 621004898541400064,
  "created_at" : "2015-07-14 17:14:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621002527958503424",
  "geo" : { },
  "id_str" : "621003342593064960",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock super merci :)",
  "id" : 621003342593064960,
  "in_reply_to_status_id" : 621002527958503424,
  "created_at" : "2015-07-14 17:08:29 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620997386333241344",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock merci pour le RT et bon 14 juillet :)",
  "id" : 620997386333241344,
  "created_at" : "2015-07-14 16:44:49 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 0, 16 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620976256843128832",
  "in_reply_to_user_id" : 149239362,
  "text" : "@umasslinguistic thanks for RT :)",
  "id" : 620976256843128832,
  "created_at" : "2015-07-14 15:20:51 +0000",
  "in_reply_to_screen_name" : "umasslinguistic",
  "in_reply_to_user_id_str" : "149239362",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620973713962475521",
  "geo" : { },
  "id_str" : "620974782046187520",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha my pleasure :)",
  "id" : 620974782046187520,
  "in_reply_to_status_id" : 620973713962475521,
  "created_at" : "2015-07-14 15:14:59 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620972772081143808",
  "geo" : { },
  "id_str" : "620973147240693760",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha would need to be vocabulary profiled, graded readers options safest in that case",
  "id" : 620973147240693760,
  "in_reply_to_status_id" : 620972772081143808,
  "created_at" : "2015-07-14 15:08:30 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/XBjCwXbGAw",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/CWQdHv7dzHm",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620971847400714240",
  "text" : "some options for finding \"simpler\" language examples from corpora https:\/\/t.co\/XBjCwXbGAw #corpusmooc",
  "id" : 620971847400714240,
  "created_at" : "2015-07-14 15:03:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 11, 18 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620904954014797824",
  "geo" : { },
  "id_str" : "620948339786387457",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @eltjam we do what we can :\/",
  "id" : 620948339786387457,
  "in_reply_to_status_id" : 620904954014797824,
  "created_at" : "2015-07-14 13:29:55 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 11, 18 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620892672773894144",
  "geo" : { },
  "id_str" : "620898481515954177",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @eltjam true, i wld argue dabbling with code is one way to wrestle authority from commercial concerns",
  "id" : 620898481515954177,
  "in_reply_to_status_id" : 620892672773894144,
  "created_at" : "2015-07-14 10:11:48 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 69, 78 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 83, 92 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningcoding",
      "indices" : [ 25, 40 ]
    }, {
      "text" : "ELT",
      "indices" : [ 45, 49 ]
    }, {
      "text" : "edtech",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/NdABWYtT4r",
      "expanded_url" : "http:\/\/ow.ly\/PzPnJ",
      "display_url" : "ow.ly\/PzPnJ"
    } ]
  },
  "geo" : { },
  "id_str" : "620888293597650944",
  "text" : "RT @eltjam: The value of #learningcoding for #ELT professionals from @muranava and @heyboyle http:\/\/t.co\/NdABWYtT4r #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 57, 66 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Mike S. Boyle",
        "screen_name" : "heyboyle",
        "indices" : [ 71, 80 ],
        "id_str" : "612840231",
        "id" : 612840231
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "learningcoding",
        "indices" : [ 13, 28 ]
      }, {
        "text" : "ELT",
        "indices" : [ 33, 37 ]
      }, {
        "text" : "edtech",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/NdABWYtT4r",
        "expanded_url" : "http:\/\/ow.ly\/PzPnJ",
        "display_url" : "ow.ly\/PzPnJ"
      } ]
    },
    "geo" : { },
    "id_str" : "620865426172588032",
    "text" : "The value of #learningcoding for #ELT professionals from @muranava and @heyboyle http:\/\/t.co\/NdABWYtT4r #edtech",
    "id" : 620865426172588032,
    "created_at" : "2015-07-14 08:00:27 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 620888293597650944,
  "created_at" : "2015-07-14 09:31:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "googletranslate",
      "indices" : [ 29, 45 ]
    }, {
      "text" : "translationfail",
      "indices" : [ 47, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/8C4ftNsrIL",
      "expanded_url" : "https:\/\/twitter.com\/iapti\/status\/620875937677242368",
      "display_url" : "twitter.com\/iapti\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620886865630130180",
  "text" : "RT @RudyLoock: The perils of #googletranslate. #translationfail https:\/\/t.co\/8C4ftNsrIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "googletranslate",
        "indices" : [ 14, 30 ]
      }, {
        "text" : "translationfail",
        "indices" : [ 32, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/8C4ftNsrIL",
        "expanded_url" : "https:\/\/twitter.com\/iapti\/status\/620875937677242368",
        "display_url" : "twitter.com\/iapti\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620884900061835264",
    "text" : "The perils of #googletranslate. #translationfail https:\/\/t.co\/8C4ftNsrIL",
    "id" : 620884900061835264,
    "created_at" : "2015-07-14 09:17:50 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 620886865630130180,
  "created_at" : "2015-07-14 09:25:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620885054869237760",
  "geo" : { },
  "id_str" : "620885867138297856",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey actually twitter kept http:\/\/ but issue with copy pasting and extra space was inserted thanks!",
  "id" : 620885867138297856,
  "in_reply_to_status_id" : 620885054869237760,
  "created_at" : "2015-07-14 09:21:40 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/nqzMVJoBLG",
      "expanded_url" : "http:\/\/twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "620883642831646721",
  "geo" : { },
  "id_str" : "620883995014905856",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey ah so it should be \"https:\/\/ + http:\/\/t.co\/nqzMVJoBLG\"?",
  "id" : 620883995014905856,
  "in_reply_to_status_id" : 620883642831646721,
  "created_at" : "2015-07-14 09:14:14 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620881763938664448",
  "geo" : { },
  "id_str" : "620883316435238912",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey great thanks last thing (i promise!) is there a way to make it a clickable url?",
  "id" : 620883316435238912,
  "in_reply_to_status_id" : 620881763938664448,
  "created_at" : "2015-07-14 09:11:32 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/BozDLWfAgY",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/twitter-elt-bookmarks\/",
      "display_url" : "eflnotes.wordpress.com\/twitter-elt-bo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "620878910331326464",
  "geo" : { },
  "id_str" : "620879263605129216",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey have a look here https:\/\/t.co\/BozDLWfAgY",
  "id" : 620879263605129216,
  "in_reply_to_status_id" : 620878910331326464,
  "created_at" : "2015-07-14 08:55:26 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620869310609645568",
  "geo" : { },
  "id_str" : "620878263691411456",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey hi the status-url (col Q) field has changed, anyway to select just the url in the updated field? thnks",
  "id" : 620878263691411456,
  "in_reply_to_status_id" : 620869310609645568,
  "created_at" : "2015-07-14 08:51:28 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 11, 18 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620868627802099712",
  "geo" : { },
  "id_str" : "620871792211664896",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @eltjam yes i agree the question for code in schools is very debateable",
  "id" : 620871792211664896,
  "in_reply_to_status_id" : 620868627802099712,
  "created_at" : "2015-07-14 08:25:45 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620869310609645568",
  "geo" : { },
  "id_str" : "620870884979515392",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey ah right thanks",
  "id" : 620870884979515392,
  "in_reply_to_status_id" : 620869310609645568,
  "created_at" : "2015-07-14 08:22:08 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/px7aP00U0K",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheet\/ccc?key=0AqGkLMU9sHmLdENLWUc1OW9iTnd3b251UUhOQk8wbHc#gid=36",
      "display_url" : "docs.google.com\/spreadsheet\/cc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620868940286328832",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey hi do u have a new version of https:\/\/t.co\/px7aP00U0K fav archive?",
  "id" : 620868940286328832,
  "created_at" : "2015-07-14 08:14:25 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/O6tK64xxUz",
      "expanded_url" : "https:\/\/youtu.be\/HeEDhw0HmNY",
      "display_url" : "youtu.be\/HeEDhw0HmNY"
    } ]
  },
  "geo" : { },
  "id_str" : "620715166733312000",
  "text" : "Channel 4 News - Greece Debt Crisis: \"Welcome to Austerity\" https:\/\/t.co\/O6tK64xxUz via @YouTube",
  "id" : 620715166733312000,
  "created_at" : "2015-07-13 22:03:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ITTC Bournemouth",
      "screen_name" : "ITTC_TEFL",
      "indices" : [ 0, 10 ],
      "id_str" : "1139785639",
      "id" : 1139785639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620714483539910656",
  "in_reply_to_user_id" : 1139785639,
  "text" : "@ITTC_TEFL hi thanks for RT :)",
  "id" : 620714483539910656,
  "created_at" : "2015-07-13 22:00:39 +0000",
  "in_reply_to_screen_name" : "ITTC_TEFL",
  "in_reply_to_user_id_str" : "1139785639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 8, 16 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 17, 32 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 33, 44 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/DcUbvIVLIt",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/wp-content\/uploads\/2013\/12\/CASS-Gloss-final1.pdf",
      "display_url" : "cass.lancs.ac.uk\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "620708112740274176",
  "geo" : { },
  "id_str" : "620711555865440256",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur @Ven_VVE @languageeteach @eilymurphy hi do check this glossary if not already http:\/\/t.co\/DcUbvIVLIt",
  "id" : 620711555865440256,
  "in_reply_to_status_id" : 620708112740274176,
  "created_at" : "2015-07-13 21:49:01 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 12, 25 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 26, 33 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620696762722947072",
  "geo" : { },
  "id_str" : "620705644744716289",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @rosemerebard @EdLaur great :)",
  "id" : 620705644744716289,
  "in_reply_to_status_id" : 620696762722947072,
  "created_at" : "2015-07-13 21:25:32 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eHQcvqlrFh",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/07\/terror-toys-and-nightmare-enemies.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/07\/terror\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620664286826889216",
  "text" : "RT @johnwhilley: Interested in building your child's character?  Drones, militarism and the selling of terror toys http:\/\/t.co\/eHQcvqlrFh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/eHQcvqlrFh",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/07\/terror-toys-and-nightmare-enemies.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/07\/terror\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620659052838842368",
    "text" : "Interested in building your child's character?  Drones, militarism and the selling of terror toys http:\/\/t.co\/eHQcvqlrFh",
    "id" : 620659052838842368,
    "created_at" : "2015-07-13 18:20:24 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 620664286826889216,
  "created_at" : "2015-07-13 18:41:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "indices" : [ 3, 18 ],
      "id_str" : "20098015",
      "id" : 20098015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620657842475958272",
  "text" : "RT @davidschneider: Tories: We plan to sacrifice poor children to the god Moloch and make the disabled fight to the death.\n\n[4 days later]\n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620282057285984257",
    "text" : "Tories: We plan to sacrifice poor children to the god Moloch and make the disabled fight to the death.\n\n[4 days later]\n\nLabour: Fine by us.",
    "id" : 620282057285984257,
    "created_at" : "2015-07-12 17:22:21 +0000",
    "user" : {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "protected" : false,
      "id_str" : "20098015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/85074940\/profilepic_normal.jpg",
      "id" : 20098015,
      "verified" : true
    }
  },
  "id" : 620657842475958272,
  "created_at" : "2015-07-13 18:15:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Routledge Languages",
      "screen_name" : "routledgelang",
      "indices" : [ 0, 14 ],
      "id_str" : "133289203",
      "id" : 133289203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620591267790065664",
  "geo" : { },
  "id_str" : "620621293755482112",
  "in_reply_to_user_id" : 133289203,
  "text" : "@routledgelang thanks for sharing :)",
  "id" : 620621293755482112,
  "in_reply_to_status_id" : 620591267790065664,
  "created_at" : "2015-07-13 15:50:21 +0000",
  "in_reply_to_screen_name" : "routledgelang",
  "in_reply_to_user_id_str" : "133289203",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 12, 25 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620621148137594880",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @rosemerebard many thanks for RTing the simple exercise, will you be doing the #corpusmooc?",
  "id" : 620621148137594880,
  "created_at" : "2015-07-13 15:49:46 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Routledge Languages",
      "screen_name" : "routledgelang",
      "indices" : [ 3, 17 ],
      "id_str" : "133289203",
      "id" : 133289203
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 93, 102 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 103, 115 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "language",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "teachers",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Ai7fhtvHiw",
      "expanded_url" : "http:\/\/ow.ly\/PfvQF",
      "display_url" : "ow.ly\/PfvQF"
    } ]
  },
  "geo" : { },
  "id_str" : "620620843295637504",
  "text" : "RT @routledgelang: What can #language #teachers get out of 'Corpus Linguistics for Grammar'? @muranava @ELTResearch http:\/\/t.co\/Ai7fhtvHiw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 74, 83 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Chris Jones",
        "screen_name" : "ELTResearch",
        "indices" : [ 84, 96 ],
        "id_str" : "3308043417",
        "id" : 3308043417
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "language",
        "indices" : [ 9, 18 ]
      }, {
        "text" : "teachers",
        "indices" : [ 19, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/Ai7fhtvHiw",
        "expanded_url" : "http:\/\/ow.ly\/PfvQF",
        "display_url" : "ow.ly\/PfvQF"
      } ]
    },
    "geo" : { },
    "id_str" : "620591267790065664",
    "text" : "What can #language #teachers get out of 'Corpus Linguistics for Grammar'? @muranava @ELTResearch http:\/\/t.co\/Ai7fhtvHiw",
    "id" : 620591267790065664,
    "created_at" : "2015-07-13 13:51:02 +0000",
    "user" : {
      "name" : "Routledge Languages",
      "screen_name" : "routledgelang",
      "protected" : false,
      "id_str" : "133289203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/959265680\/Routledge_cmyk-blue_normal.JPG",
      "id" : 133289203,
      "verified" : false
    }
  },
  "id" : 620620843295637504,
  "created_at" : "2015-07-13 15:48:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/gnTfZ4cueh",
      "expanded_url" : "http:\/\/www.mirror.co.uk\/news\/world-news\/iron-man-transformers-censored-military-6050507#ICID=sharebar_twitter",
      "display_url" : "mirror.co.uk\/news\/world-new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620515018505867264",
  "text" : "Iron Man and Terminators censored for being too close to the truth http:\/\/t.co\/gnTfZ4cueh",
  "id" : 620515018505867264,
  "created_at" : "2015-07-13 08:48:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620509080558379008",
  "geo" : { },
  "id_str" : "620510171001954305",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway c'est Le Figaro...",
  "id" : 620510171001954305,
  "in_reply_to_status_id" : 620509080558379008,
  "created_at" : "2015-07-13 08:28:47 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/7td3tgxhcI",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/WEkZ58hxZ9G",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620502803765702656",
  "text" : "a possible little exercise for people interested in round 3 of #corpusmooc https:\/\/t.co\/7td3tgxhcI",
  "id" : 620502803765702656,
  "created_at" : "2015-07-13 07:59:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619485579462471680",
  "geo" : { },
  "id_str" : "620257281184264192",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan i really like the role play with nonsense words to explain or decode",
  "id" : 620257281184264192,
  "in_reply_to_status_id" : 619485579462471680,
  "created_at" : "2015-07-12 15:43:54 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/620152193631457280\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ffxhbuGNdO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJs5IiLXAAABMPA.png",
      "id_str" : "620152192469762048",
      "id" : 620152192469762048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJs5IiLXAAABMPA.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ffxhbuGNdO"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "ESL",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ypg65YLM8y",
      "expanded_url" : "https:\/\/goo.gl\/3S6kIu",
      "display_url" : "goo.gl\/3S6kIu"
    } ]
  },
  "geo" : { },
  "id_str" : "620157041076776960",
  "text" : "RT @taw_sig: #ELT \/ #ESL teachers - fed up of crappy working conditions? So are we - join us. https:\/\/t.co\/ypg65YLM8y http:\/\/t.co\/ffxhbuGNdO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/620152193631457280\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ffxhbuGNdO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJs5IiLXAAABMPA.png",
        "id_str" : "620152192469762048",
        "id" : 620152192469762048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJs5IiLXAAABMPA.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ffxhbuGNdO"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ypg65YLM8y",
        "expanded_url" : "https:\/\/goo.gl\/3S6kIu",
        "display_url" : "goo.gl\/3S6kIu"
      } ]
    },
    "geo" : { },
    "id_str" : "620152193631457280",
    "text" : "#ELT \/ #ESL teachers - fed up of crappy working conditions? So are we - join us. https:\/\/t.co\/ypg65YLM8y http:\/\/t.co\/ffxhbuGNdO",
    "id" : 620152193631457280,
    "created_at" : "2015-07-12 08:46:19 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 620157041076776960,
  "created_at" : "2015-07-12 09:05:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Z4WJS0WP8l",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/jul\/12\/ttip-your-data-privacy-is-a-barrier-to-economic-growth",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620151383359143936",
  "text" : "RT @evgenymorozov: My new column on how the \"free flow of data\" has become one of the key neoliberal slogans http:\/\/t.co\/Z4WJS0WP8l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Z4WJS0WP8l",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/jul\/12\/ttip-your-data-privacy-is-a-barrier-to-economic-growth",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620138146228006912",
    "text" : "My new column on how the \"free flow of data\" has become one of the key neoliberal slogans http:\/\/t.co\/Z4WJS0WP8l",
    "id" : 620138146228006912,
    "created_at" : "2015-07-12 07:50:30 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 620151383359143936,
  "created_at" : "2015-07-12 08:43:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620146016763801600",
  "geo" : { },
  "id_str" : "620151321732231168",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga yr welcome, look fwd to more releases from the vault :)",
  "id" : 620151321732231168,
  "in_reply_to_status_id" : 620146016763801600,
  "created_at" : "2015-07-12 08:42:51 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/rrhx8Hv1pr",
      "expanded_url" : "http:\/\/tinyurl.com\/o2o59ew",
      "display_url" : "tinyurl.com\/o2o59ew"
    } ]
  },
  "geo" : { },
  "id_str" : "619869814392254465",
  "text" : "RT @TonyMcEnery: If you are thinking of joining the #corpusMOOC read a review of the course here: http:\/\/t.co\/rrhx8Hv1pr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 35, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/rrhx8Hv1pr",
        "expanded_url" : "http:\/\/tinyurl.com\/o2o59ew",
        "display_url" : "tinyurl.com\/o2o59ew"
      } ]
    },
    "geo" : { },
    "id_str" : "619867090510589952",
    "text" : "If you are thinking of joining the #corpusMOOC read a review of the course here: http:\/\/t.co\/rrhx8Hv1pr",
    "id" : 619867090510589952,
    "created_at" : "2015-07-11 13:53:25 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 619869814392254465,
  "created_at" : "2015-07-11 14:04:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619863841007140865",
  "geo" : { },
  "id_str" : "619867404491993089",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug wonder if the writer has kids ;)",
  "id" : 619867404491993089,
  "in_reply_to_status_id" : 619863841007140865,
  "created_at" : "2015-07-11 13:54:40 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 3, 15 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/lZpGpIkb30",
      "expanded_url" : "https:\/\/medium.com\/@akadoublecakes\/alienation-a-minion-dollar-industry-4b3523d7c6a2",
      "display_url" : "medium.com\/@akadoublecake\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619867220110385152",
  "text" : "RT @onalifeglug: Minions: raceless, genderless, ageless, aspirationless workforce... the platonic ideal of a capitalist service class https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/lZpGpIkb30",
        "expanded_url" : "https:\/\/medium.com\/@akadoublecakes\/alienation-a-minion-dollar-industry-4b3523d7c6a2",
        "display_url" : "medium.com\/@akadoublecake\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619863841007140865",
    "text" : "Minions: raceless, genderless, ageless, aspirationless workforce... the platonic ideal of a capitalist service class https:\/\/t.co\/lZpGpIkb30",
    "id" : 619863841007140865,
    "created_at" : "2015-07-11 13:40:30 +0000",
    "user" : {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "protected" : false,
      "id_str" : "19516039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586664577095622656\/NwBHdlk5_normal.jpg",
      "id" : 19516039,
      "verified" : false
    }
  },
  "id" : 619867220110385152,
  "created_at" : "2015-07-11 13:53:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blossom",
      "screen_name" : "justBlossom75",
      "indices" : [ 0, 14 ],
      "id_str" : "2726131801",
      "id" : 2726131801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619853923512225793",
  "geo" : { },
  "id_str" : "619863844056379392",
  "in_reply_to_user_id" : 2726131801,
  "text" : "@justBlossom75 my pleasure :)",
  "id" : 619863844056379392,
  "in_reply_to_status_id" : 619853923512225793,
  "created_at" : "2015-07-11 13:40:31 +0000",
  "in_reply_to_screen_name" : "justBlossom75",
  "in_reply_to_user_id_str" : "2726131801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 102, 111 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/go1BWpzWiM",
      "expanded_url" : "https:\/\/www.academia.edu\/13907872\/Gabrielatos_C._2002_._EFL_writing_Product_and_process._ERIC_ED476839?s=t",
      "display_url" : "academia.edu\/13907872\/Gabri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619863612660781058",
  "text" : "Gabrielatos, C. (2002). EFL writing: Product and process. ERIC, ED476839. https:\/\/t.co\/go1BWpzWiM via @academia",
  "id" : 619863612660781058,
  "created_at" : "2015-07-11 13:39:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mindhacks blog",
      "screen_name" : "mindhacksblog",
      "indices" : [ 83, 97 ],
      "id_str" : "22465084",
      "id" : 22465084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/DoMoTRQ9T4",
      "expanded_url" : "http:\/\/wp.me\/ptsTD-8nd",
      "display_url" : "wp.me\/ptsTD-8nd"
    } ]
  },
  "geo" : { },
  "id_str" : "619794899513286656",
  "text" : "APA facilitated CIA torture programme at highest levels http:\/\/t.co\/DoMoTRQ9T4 via @mindhacksblog",
  "id" : 619794899513286656,
  "created_at" : "2015-07-11 09:06:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Denby",
      "screen_name" : "CatDenby",
      "indices" : [ 3, 12 ],
      "id_str" : "2397562590",
      "id" : 2397562590
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CatDenby\/status\/618711591756910592\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/A6cwxfL2bS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJYa5UBWUAAhfqM.jpg",
      "id_str" : "618711570739253248",
      "id" : 618711570739253248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJYa5UBWUAAhfqM.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/A6cwxfL2bS"
    } ],
    "hashtags" : [ {
      "text" : "Balls2TheBudget",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619629385382010880",
  "text" : "RT @CatDenby: Look at this guy's amazing painting hahaha #Balls2TheBudget http:\/\/t.co\/A6cwxfL2bS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CatDenby\/status\/618711591756910592\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/A6cwxfL2bS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJYa5UBWUAAhfqM.jpg",
        "id_str" : "618711570739253248",
        "id" : 618711570739253248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJYa5UBWUAAhfqM.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/A6cwxfL2bS"
      } ],
      "hashtags" : [ {
        "text" : "Balls2TheBudget",
        "indices" : [ 43, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618711591756910592",
    "text" : "Look at this guy's amazing painting hahaha #Balls2TheBudget http:\/\/t.co\/A6cwxfL2bS",
    "id" : 618711591756910592,
    "created_at" : "2015-07-08 09:21:53 +0000",
    "user" : {
      "name" : "Cat Denby",
      "screen_name" : "CatDenby",
      "protected" : false,
      "id_str" : "2397562590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620678675026083840\/XbkUmNOg_normal.jpg",
      "id" : 2397562590,
      "verified" : false
    }
  },
  "id" : 619629385382010880,
  "created_at" : "2015-07-10 22:08:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 0, 10 ],
      "id_str" : "237842162",
      "id" : 237842162
    }, {
      "name" : "Marsha Dowie",
      "screen_name" : "Marsha_LD",
      "indices" : [ 11, 21 ],
      "id_str" : "128983075",
      "id" : 128983075
    }, {
      "name" : "Lancaster University",
      "screen_name" : "LancasterUni",
      "indices" : [ 22, 35 ],
      "id_str" : "25521930",
      "id" : 25521930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619624186106019840",
  "geo" : { },
  "id_str" : "619625905950998528",
  "in_reply_to_user_id" : 237842162,
  "text" : "@DrClaireH @Marsha_LD @LancasterUni thx it is notable BAE systems are not neutral parties",
  "id" : 619625905950998528,
  "in_reply_to_status_id" : 619624186106019840,
  "created_at" : "2015-07-10 21:55:02 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marsha Dowie",
      "screen_name" : "Marsha_LD",
      "indices" : [ 0, 10 ],
      "id_str" : "128983075",
      "id" : 128983075
    }, {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 11, 21 ],
      "id_str" : "237842162",
      "id" : 237842162
    }, {
      "name" : "Lancaster University",
      "screen_name" : "LancasterUni",
      "indices" : [ 22, 35 ],
      "id_str" : "25521930",
      "id" : 25521930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619584047803703296",
  "geo" : { },
  "id_str" : "619585706516738049",
  "in_reply_to_user_id" : 128983075,
  "text" : "@Marsha_LD @DrClaireH @LancasterUni maybe be wrong but would take that 27billion cybercrime estimate with a large pinch of cybersalt :)",
  "id" : 619585706516738049,
  "in_reply_to_status_id" : 619584047803703296,
  "created_at" : "2015-07-10 19:15:18 +0000",
  "in_reply_to_screen_name" : "Marsha_LD",
  "in_reply_to_user_id_str" : "128983075",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619511822849146881",
  "geo" : { },
  "id_str" : "619516648777715712",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson shame it wasn't true :(",
  "id" : 619516648777715712,
  "in_reply_to_status_id" : 619511822849146881,
  "created_at" : "2015-07-10 14:40:53 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 15, 30 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/8f7JT4DlD7",
      "expanded_url" : "https:\/\/twitter.com\/EveryNoise\/status\/619494179505201152",
      "display_url" : "twitter.com\/EveryNoise\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619499042679169025",
  "text" : "that's neat cc @4tunetellernet  https:\/\/t.co\/8f7JT4DlD7",
  "id" : 619499042679169025,
  "created_at" : "2015-07-10 13:30:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 13, 24 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/QUQcupIFc4",
      "expanded_url" : "http:\/\/candle.cs.nthu.edu.tw\/care\/",
      "display_url" : "candle.cs.nthu.edu.tw\/care\/"
    } ]
  },
  "in_reply_to_status_id_str" : "619479664688525312",
  "geo" : { },
  "id_str" : "619482274036322304",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @EAPstephen yes e.g. look at discourse whys such as move analysis this tool is useful for that - http:\/\/t.co\/QUQcupIFc4",
  "id" : 619482274036322304,
  "in_reply_to_status_id" : 619479664688525312,
  "created_at" : "2015-07-10 12:24:18 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 13, 19 ],
      "id_str" : "105883895",
      "id" : 105883895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619470542412886016",
  "geo" : { },
  "id_str" : "619473404916301825",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @tdsig it's a great read you could be the Edward Tufte of Language Teaching :)",
  "id" : 619473404916301825,
  "in_reply_to_status_id" : 619470542412886016,
  "created_at" : "2015-07-10 11:49:03 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 68, 80 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 91, 97 ],
      "id_str" : "105883895",
      "id" : 105883895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619470403262672897",
  "text" : "some funky &amp; useful visual artifacts for lesson observations by @dalecoulter in latest @tdsig newsletter",
  "id" : 619470403262672897,
  "created_at" : "2015-07-10 11:37:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619466351325876224",
  "geo" : { },
  "id_str" : "619469988458434560",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen hey yr welcome no not a tennis fan have a good one yrself :)",
  "id" : 619469988458434560,
  "in_reply_to_status_id" : 619466351325876224,
  "created_at" : "2015-07-10 11:35:29 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 3, 14 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4eKegPqYwU",
      "expanded_url" : "https:\/\/twitter.com\/difcireland\/status\/619461909981609984",
      "display_url" : "twitter.com\/difcireland\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619464582915080192",
  "text" : "RT @EAPstephen: Wrote this blogpost for students to try to explain concept of Academic Vocab. Not sure I understand too well myself. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/4eKegPqYwU",
        "expanded_url" : "https:\/\/twitter.com\/difcireland\/status\/619461909981609984",
        "display_url" : "twitter.com\/difcireland\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619462364581220352",
    "text" : "Wrote this blogpost for students to try to explain concept of Academic Vocab. Not sure I understand too well myself. https:\/\/t.co\/4eKegPqYwU",
    "id" : 619462364581220352,
    "created_at" : "2015-07-10 11:05:11 +0000",
    "user" : {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "protected" : false,
      "id_str" : "2717005711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541999119812681728\/dHDIC_gW_normal.jpeg",
      "id" : 2717005711,
      "verified" : false
    }
  },
  "id" : 619464582915080192,
  "created_at" : "2015-07-10 11:14:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 139, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "619461861533159424",
  "text" : "of the top 10 phrasal verbs only 1 has 4 meanings &amp; of top 150 only 6 have 4 meanings so memorising is possible http:\/\/t.co\/feVV1F8lKr #elt",
  "id" : 619461861533159424,
  "created_at" : "2015-07-10 11:03:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "lyse doucet",
      "screen_name" : "bbclysedoucet",
      "indices" : [ 111, 125 ],
      "id_str" : "108352527",
      "id" : 108352527
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 126, 136 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Ben White",
      "screen_name" : "benabyad",
      "indices" : [ 137, 140 ],
      "id_str" : "248670810",
      "id" : 248670810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "childrenofthegazawar",
      "indices" : [ 89, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/GdwplRyj1Q",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/07\/doucets-shameful-film-children-of-gaza.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/07\/doucet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619452176977514496",
  "text" : "RT @johnwhilley: Doucet's shameful film: Children of the Gaza war http:\/\/t.co\/GdwplRyj1Q #childrenofthegazawar @bbclysedoucet @medialens @b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "lyse doucet",
        "screen_name" : "bbclysedoucet",
        "indices" : [ 94, 108 ],
        "id_str" : "108352527",
        "id" : 108352527
      }, {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 109, 119 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "Ben White",
        "screen_name" : "benabyad",
        "indices" : [ 120, 129 ],
        "id_str" : "248670810",
        "id" : 248670810
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "childrenofthegazawar",
        "indices" : [ 72, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/GdwplRyj1Q",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/07\/doucets-shameful-film-children-of-gaza.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/07\/doucet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618985675409518592",
    "text" : "Doucet's shameful film: Children of the Gaza war http:\/\/t.co\/GdwplRyj1Q #childrenofthegazawar @bbclysedoucet @medialens @benabyad",
    "id" : 618985675409518592,
    "created_at" : "2015-07-09 03:30:59 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 619452176977514496,
  "created_at" : "2015-07-10 10:24:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/2Qw6OTh68I",
      "expanded_url" : "http:\/\/wp.me\/s6aVNf-200",
      "display_url" : "wp.me\/s6aVNf-200"
    } ]
  },
  "geo" : { },
  "id_str" : "619446149569740800",
  "text" : "RT @HanaTicha: A little anniversary today &gt; #200 http:\/\/t.co\/2Qw6OTh68I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/2Qw6OTh68I",
        "expanded_url" : "http:\/\/wp.me\/s6aVNf-200",
        "display_url" : "wp.me\/s6aVNf-200"
      } ]
    },
    "geo" : { },
    "id_str" : "619442612890697728",
    "text" : "A little anniversary today &gt; #200 http:\/\/t.co\/2Qw6OTh68I",
    "id" : 619442612890697728,
    "created_at" : "2015-07-10 09:46:42 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 619446149569740800,
  "created_at" : "2015-07-10 10:00:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619416260825079808",
  "geo" : { },
  "id_str" : "619439481712680960",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish cheers Marc enjoy yr w\/e :)",
  "id" : 619439481712680960,
  "in_reply_to_status_id" : 619416260825079808,
  "created_at" : "2015-07-10 09:34:15 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Finegan",
      "screen_name" : "kehfinegan",
      "indices" : [ 0, 11 ],
      "id_str" : "3236117203",
      "id" : 3236117203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619248238256783360",
  "geo" : { },
  "id_str" : "619275974845308928",
  "in_reply_to_user_id" : 3236117203,
  "text" : "@kehfinegan what's IRB?",
  "id" : 619275974845308928,
  "in_reply_to_status_id" : 619248238256783360,
  "created_at" : "2015-07-09 22:44:32 +0000",
  "in_reply_to_screen_name" : "kehfinegan",
  "in_reply_to_user_id_str" : "3236117203",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Ruiz Tinoco",
      "screen_name" : "aruiztinoco",
      "indices" : [ 3, 15 ],
      "id_str" : "26511350",
      "id" : 26511350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toolkit",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "corpora",
      "indices" : [ 56, 64 ]
    }, {
      "text" : "python",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0L5u131YLz",
      "expanded_url" : "https:\/\/pypi.python.org\/pypi\/corpkit\/1.1",
      "display_url" : "pypi.python.org\/pypi\/corpkit\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619270870893264896",
  "text" : "RT @aruiztinoco: A #toolkit for working with linguistic #corpora | corpkit 1.1 | #python | https:\/\/t.co\/0L5u131YLz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "toolkit",
        "indices" : [ 2, 10 ]
      }, {
        "text" : "corpora",
        "indices" : [ 39, 47 ]
      }, {
        "text" : "python",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/0L5u131YLz",
        "expanded_url" : "https:\/\/pypi.python.org\/pypi\/corpkit\/1.1",
        "display_url" : "pypi.python.org\/pypi\/corpkit\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619152100849614848",
    "text" : "A #toolkit for working with linguistic #corpora | corpkit 1.1 | #python | https:\/\/t.co\/0L5u131YLz",
    "id" : 619152100849614848,
    "created_at" : "2015-07-09 14:32:18 +0000",
    "user" : {
      "name" : "Antonio Ruiz Tinoco",
      "screen_name" : "aruiztinoco",
      "protected" : false,
      "id_str" : "26511350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643023538442498048\/wr85Umcp_normal.jpg",
      "id" : 26511350,
      "verified" : false
    }
  },
  "id" : 619270870893264896,
  "created_at" : "2015-07-09 22:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Finegan",
      "screen_name" : "kehfinegan",
      "indices" : [ 0, 11 ],
      "id_str" : "3236117203",
      "id" : 3236117203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619228521483870208",
  "geo" : { },
  "id_str" : "619230664949374976",
  "in_reply_to_user_id" : 3236117203,
  "text" : "@kehfinegan sounds like a post in the making :)",
  "id" : 619230664949374976,
  "in_reply_to_status_id" : 619228521483870208,
  "created_at" : "2015-07-09 19:44:29 +0000",
  "in_reply_to_screen_name" : "kehfinegan",
  "in_reply_to_user_id_str" : "3236117203",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 120, 136 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/fGOWZMDVvf",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-wy",
      "display_url" : "wp.me\/p4E5tZ-wy"
    } ]
  },
  "geo" : { },
  "id_str" : "619230163881099264",
  "text" : "The \u2018student-K\u2019 paradox: how ineffective classroom learning can enhance language proficiency http:\/\/t.co\/fGOWZMDVvf via @gianfrancocont9",
  "id" : 619230163881099264,
  "created_at" : "2015-07-09 19:42:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "619194928665624576",
  "geo" : { },
  "id_str" : "619195247973765120",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites be interested in what you find, maybe comment in G+ CL community? https:\/\/t.co\/gnEFqIeLpA",
  "id" : 619195247973765120,
  "in_reply_to_status_id" : 619194928665624576,
  "created_at" : "2015-07-09 17:23:45 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619192083782475776",
  "geo" : { },
  "id_str" : "619194642995748864",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites there's some conversation in the BNCaudio corpus; SwitchBoard telephone corpus though not seen any audio for that is free",
  "id" : 619194642995748864,
  "in_reply_to_status_id" : 619192083782475776,
  "created_at" : "2015-07-09 17:21:21 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/IkzcCXf4Ea",
      "expanded_url" : "https:\/\/lindat.mff.cuni.cz\/repository\/xmlui\/",
      "display_url" : "lindat.mff.cuni.cz\/repository\/xml\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "619192083782475776",
  "geo" : { },
  "id_str" : "619193104894197760",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites if u do a search for speech here https:\/\/t.co\/IkzcCXf4Ea u get dialect ones such as scottish &amp; newcastle if that is any use?",
  "id" : 619193104894197760,
  "in_reply_to_status_id" : 619192083782475776,
  "created_at" : "2015-07-09 17:15:14 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619145094386581506",
  "geo" : { },
  "id_str" : "619191073903132676",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites hmm bit tricky this i guess u r looking for the audio as well as transcriptions?",
  "id" : 619191073903132676,
  "in_reply_to_status_id" : 619145094386581506,
  "created_at" : "2015-07-09 17:07:10 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 17, 27 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619149088286576640",
  "geo" : { },
  "id_str" : "619190343070810113",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @pronbites hi thanks for mention Marc",
  "id" : 619190343070810113,
  "in_reply_to_status_id" : 619149088286576640,
  "created_at" : "2015-07-09 17:04:16 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherlock",
      "screen_name" : "Sherlock221B",
      "indices" : [ 17, 30 ],
      "id_str" : "2305049443",
      "id" : 2305049443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/wBcTIcXxTe",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/MpxcBQCs4BB",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ylyrN0rp4b",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/81SYnQNiPzE",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619114350897401856",
  "text" : "with the special @Sherlock221B episode upcoming a couple of language related posts - https:\/\/t.co\/wBcTIcXxTe; https:\/\/t.co\/ylyrN0rp4b",
  "id" : 619114350897401856,
  "created_at" : "2015-07-09 12:02:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/619077277159137280\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/D76BLkvzUt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJdngHbWUAAAEw9.png",
      "id_str" : "619077275233964032",
      "id" : 619077275233964032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJdngHbWUAAAEw9.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/D76BLkvzUt"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "ESL",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/ypg65Z3nx8",
      "expanded_url" : "https:\/\/goo.gl\/3S6kIu",
      "display_url" : "goo.gl\/3S6kIu"
    } ]
  },
  "geo" : { },
  "id_str" : "619081377653391360",
  "text" : "RT @taw_sig: #ELT \/ #ESL teachers - do you want to make our teaching community stronger? Join us! https:\/\/t.co\/ypg65Z3nx8 http:\/\/t.co\/D76BL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/619077277159137280\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/D76BLkvzUt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJdngHbWUAAAEw9.png",
        "id_str" : "619077275233964032",
        "id" : 619077275233964032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJdngHbWUAAAEw9.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/D76BLkvzUt"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ypg65Z3nx8",
        "expanded_url" : "https:\/\/goo.gl\/3S6kIu",
        "display_url" : "goo.gl\/3S6kIu"
      } ]
    },
    "geo" : { },
    "id_str" : "619077277159137280",
    "text" : "#ELT \/ #ESL teachers - do you want to make our teaching community stronger? Join us! https:\/\/t.co\/ypg65Z3nx8 http:\/\/t.co\/D76BLkvzUt",
    "id" : 619077277159137280,
    "created_at" : "2015-07-09 09:34:59 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 619081377653391360,
  "created_at" : "2015-07-09 09:51:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 49, 57 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/7YXDzmcPu1",
      "expanded_url" : "http:\/\/musicfordeckchairs.com\/blog\/2015\/07\/09\/what-would-stampy-do\/",
      "display_url" : "musicfordeckchairs.com\/blog\/2015\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619050179807719424",
  "text" : "What would Stampy do? http:\/\/t.co\/7YXDzmcPu1 via @KateMfD",
  "id" : 619050179807719424,
  "created_at" : "2015-07-09 07:47:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ky61EBM8iK",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2015\/07\/05\/be-to-others-what-you-want-others-to-be\/",
      "display_url" : "itdi.pro\/blog\/2015\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618840566172938240",
  "text" : "Be to others what you want others to be http:\/\/t.co\/ky61EBM8iK",
  "id" : 618840566172938240,
  "created_at" : "2015-07-08 17:54:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 27, 39 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 42, 60 ]
    }, {
      "text" : "ELT",
      "indices" : [ 126, 130 ]
    }, {
      "text" : "ESL",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/wBcTIcXxTe",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/MpxcBQCs4BB",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618832054231408640",
  "text" : "a live review or liview of @ELTResearch's #corpuslinguistics for grammar https:\/\/t.co\/wBcTIcXxTe, 1st of a series possibly... #ELT #ESL",
  "id" : 618832054231408640,
  "created_at" : "2015-07-08 17:20:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618820049634201600",
  "geo" : { },
  "id_str" : "618829906684809216",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet hey what a dood :) u flying back or flying out?",
  "id" : 618829906684809216,
  "in_reply_to_status_id" : 618820049634201600,
  "created_at" : "2015-07-08 17:12:01 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esp",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/o5SINk3ifV",
      "expanded_url" : "https:\/\/www.etprofessional.com\/ETp-Live-2015-Part-2-Once-upon-a-time-there-was-a-short-completed-action.aspx",
      "display_url" : "etprofessional.com\/ETp-Live-2015-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618809864614203392",
  "text" : "RT @chiasuan: In this blogpost, I look at Danny Norrington Davies's very useful workshop about teaching grammar. https:\/\/t.co\/o5SINk3ifV #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 123, 127 ]
      }, {
        "text" : "efl",
        "indices" : [ 128, 132 ]
      }, {
        "text" : "esp",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/o5SINk3ifV",
        "expanded_url" : "https:\/\/www.etprofessional.com\/ETp-Live-2015-Part-2-Once-upon-a-time-there-was-a-short-completed-action.aspx",
        "display_url" : "etprofessional.com\/ETp-Live-2015-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618790579242180608",
    "text" : "In this blogpost, I look at Danny Norrington Davies's very useful workshop about teaching grammar. https:\/\/t.co\/o5SINk3ifV #elt #efl #esp",
    "id" : 618790579242180608,
    "created_at" : "2015-07-08 14:35:45 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 618809864614203392,
  "created_at" : "2015-07-08 15:52:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 0, 11 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618787406121172992",
  "geo" : { },
  "id_str" : "618807444509167616",
  "in_reply_to_user_id" : 134191406,
  "text" : "@AchilleasK yr welcome, need to look more at indiv diffs",
  "id" : 618807444509167616,
  "in_reply_to_status_id" : 618787406121172992,
  "created_at" : "2015-07-08 15:42:46 +0000",
  "in_reply_to_screen_name" : "AchilleasK",
  "in_reply_to_user_id_str" : "134191406",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 27, 39 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "RoutledgeLinguistics",
      "screen_name" : "RoutledgeLing",
      "indices" : [ 46, 60 ],
      "id_str" : "40210891",
      "id" : 40210891
    }, {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 71, 83 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/618807214715850752\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/0HmfyXS60I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJZx4dlWUAAffMi.jpg",
      "id_str" : "618807213637914624",
      "id" : 618807213637914624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJZx4dlWUAAffMi.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0HmfyXS60I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618807214715850752",
  "text" : "this arrrived today thx to @ELTResearch &amp; @RoutledgeLing; mentions @racheldaw18 in acks http:\/\/t.co\/0HmfyXS60I",
  "id" : 618807214715850752,
  "created_at" : "2015-07-08 15:41:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Greece",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "Oxi",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "Terrorism",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/zOZqwTB8PT",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/07\/speaking-names-to-power-re-framing.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/07\/speaki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618775424966000640",
  "text" : "RT @johnwhilley: Speaking names to power - re-framing the language of 'terror' http:\/\/t.co\/zOZqwTB8PT #Greece #Oxi #Terrorism",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Greece",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "Oxi",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "Terrorism",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/zOZqwTB8PT",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/07\/speaking-names-to-power-re-framing.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/07\/speaki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618774336120483840",
    "text" : "Speaking names to power - re-framing the language of 'terror' http:\/\/t.co\/zOZqwTB8PT #Greece #Oxi #Terrorism",
    "id" : 618774336120483840,
    "created_at" : "2015-07-08 13:31:12 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 618775424966000640,
  "created_at" : "2015-07-08 13:35:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "indices" : [ 3, 18 ],
      "id_str" : "20098015",
      "id" : 20098015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget2015",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618763201115725824",
  "text" : "RT @davidschneider: Tweets to be cut to 120 characters by 2018 except for \"hard-working tweeters\" with +250K followers who'll get 160 chara\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget2015",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618724701930713088",
    "text" : "Tweets to be cut to 120 characters by 2018 except for \"hard-working tweeters\" with +250K followers who'll get 160 characters #budget2015",
    "id" : 618724701930713088,
    "created_at" : "2015-07-08 10:13:58 +0000",
    "user" : {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "protected" : false,
      "id_str" : "20098015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/85074940\/profilepic_normal.jpg",
      "id" : 20098015,
      "verified" : true
    }
  },
  "id" : 618763201115725824,
  "created_at" : "2015-07-08 12:46:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 3, 12 ],
      "id_str" : "6257282",
      "id" : 6257282
    }, {
      "name" : "Something",
      "screen_name" : "somethinggd",
      "indices" : [ 88, 100 ],
      "id_str" : "2352237964",
      "id" : 2352237964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Et1RPFp16H",
      "expanded_url" : "https:\/\/twitter.com\/rpicsivit\/status\/618749301410373632",
      "display_url" : "twitter.com\/rpicsivit\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618757844708499456",
  "text" : "RT @trieloff: Deep Learning Machine Beats Humans in IQ Test | MIT Technology Review via @somethinggd https:\/\/t.co\/Et1RPFp16H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Something",
        "screen_name" : "somethinggd",
        "indices" : [ 74, 86 ],
        "id_str" : "2352237964",
        "id" : 2352237964
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/Et1RPFp16H",
        "expanded_url" : "https:\/\/twitter.com\/rpicsivit\/status\/618749301410373632",
        "display_url" : "twitter.com\/rpicsivit\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618756661763829760",
    "text" : "Deep Learning Machine Beats Humans in IQ Test | MIT Technology Review via @somethinggd https:\/\/t.co\/Et1RPFp16H",
    "id" : 618756661763829760,
    "created_at" : "2015-07-08 12:20:58 +0000",
    "user" : {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "protected" : false,
      "id_str" : "6257282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708651245561585664\/6xwsfP4M_normal.jpg",
      "id" : 6257282,
      "verified" : false
    }
  },
  "id" : 618757844708499456,
  "created_at" : "2015-07-08 12:25:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7SCkJnOTPC",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/migration\/language-or-religion-which-is-the-greater-fault-line-in-diverse-societies",
      "display_url" : "languageonthemove.com\/migration\/lang\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618756241431633920",
  "text" : "Language or religion: which is the greater fault line in diverse societies?: http:\/\/t.co\/7SCkJnOTPC",
  "id" : 618756241431633920,
  "created_at" : "2015-07-08 12:19:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 68, 79 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/7BDsPDi8S2",
      "expanded_url" : "http:\/\/wp.me\/p2aFDK-18w",
      "display_url" : "wp.me\/p2aFDK-18w"
    } ]
  },
  "geo" : { },
  "id_str" : "618753808131342336",
  "text" : "Is there a talent for language learning? http:\/\/t.co\/7BDsPDi8S2 via @AchilleasK",
  "id" : 618753808131342336,
  "created_at" : "2015-07-08 12:09:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618694074401456129",
  "geo" : { },
  "id_str" : "618724077998612480",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar maybe i need to take heed of our algorithmic overlords &amp; accept my comments are spam :\/",
  "id" : 618724077998612480,
  "in_reply_to_status_id" : 618694074401456129,
  "created_at" : "2015-07-08 10:11:30 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618684370652631040",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar hi Hugh made another disqus comment on snowclones post but it has been marked as spam?",
  "id" : 618684370652631040,
  "created_at" : "2015-07-08 07:33:43 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EngConnectTeachers",
      "screen_name" : "eng_teachers",
      "indices" : [ 0, 13 ],
      "id_str" : "2861318566",
      "id" : 2861318566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618597161580691456",
  "geo" : { },
  "id_str" : "618683925163065344",
  "in_reply_to_user_id" : 2861318566,
  "text" : "@eng_teachers great, if they have any comments on it would love to hear",
  "id" : 618683925163065344,
  "in_reply_to_status_id" : 618597161580691456,
  "created_at" : "2015-07-08 07:31:57 +0000",
  "in_reply_to_screen_name" : "eng_teachers",
  "in_reply_to_user_id_str" : "2861318566",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618518817036042245",
  "geo" : { },
  "id_str" : "618520630590177281",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall having one slide is a great rule",
  "id" : 618520630590177281,
  "in_reply_to_status_id" : 618518817036042245,
  "created_at" : "2015-07-07 20:43:04 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HCLEMuseum",
      "screen_name" : "HCLEMuseum",
      "indices" : [ 0, 11 ],
      "id_str" : "1287422462",
      "id" : 1287422462
    }, {
      "name" : "Liza Loop",
      "screen_name" : "LizaLoopED",
      "indices" : [ 12, 23 ],
      "id_str" : "1287902682",
      "id" : 1287902682
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 103, 117 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618501651213611008",
  "geo" : { },
  "id_str" : "618513504870526977",
  "in_reply_to_user_id" : 1287422462,
  "text" : "@HCLEMuseum @LizaLoopED  sure though the use is embedded in a certain ideological system which i think @audreywatters article was arguing?",
  "id" : 618513504870526977,
  "in_reply_to_status_id" : 618501651213611008,
  "created_at" : "2015-07-07 20:14:45 +0000",
  "in_reply_to_screen_name" : "HCLEMuseum",
  "in_reply_to_user_id_str" : "1287422462",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liza Loop",
      "screen_name" : "LizaLoopED",
      "indices" : [ 0, 11 ],
      "id_str" : "1287902682",
      "id" : 1287902682
    }, {
      "name" : "HCLEMuseum",
      "screen_name" : "HCLEMuseum",
      "indices" : [ 12, 23 ],
      "id_str" : "1287422462",
      "id" : 1287422462
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 24, 38 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618462849107537921",
  "geo" : { },
  "id_str" : "618493241390931968",
  "in_reply_to_user_id" : 1287902682,
  "text" : "@LizaLoopED @HCLEMuseum @audreywatters the computer as \"unbiased and neutral\" is like saying something comes from nothing?",
  "id" : 618493241390931968,
  "in_reply_to_status_id" : 618462849107537921,
  "created_at" : "2015-07-07 18:54:14 +0000",
  "in_reply_to_screen_name" : "LizaLoopED",
  "in_reply_to_user_id_str" : "1287902682",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EngConnectTeachers",
      "screen_name" : "eng_teachers",
      "indices" : [ 3, 16 ],
      "id_str" : "2861318566",
      "id" : 2861318566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/bAH0qZpNaY",
      "expanded_url" : "http:\/\/fb.me\/6IxTuPYyR",
      "display_url" : "fb.me\/6IxTuPYyR"
    } ]
  },
  "geo" : { },
  "id_str" : "618474721416466432",
  "text" : "RT @eng_teachers: I've just come across the pHaVe dictionary and already have a couple of students working with it. http:\/\/t.co\/bAH0qZpNaY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/bAH0qZpNaY",
        "expanded_url" : "http:\/\/fb.me\/6IxTuPYyR",
        "display_url" : "fb.me\/6IxTuPYyR"
      } ]
    },
    "geo" : { },
    "id_str" : "618473849659785216",
    "text" : "I've just come across the pHaVe dictionary and already have a couple of students working with it. http:\/\/t.co\/bAH0qZpNaY",
    "id" : 618473849659785216,
    "created_at" : "2015-07-07 17:37:11 +0000",
    "user" : {
      "name" : "EngConnectTeachers",
      "screen_name" : "eng_teachers",
      "protected" : false,
      "id_str" : "2861318566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529726348697149440\/tlEzoi5S_normal.jpeg",
      "id" : 2861318566,
      "verified" : false
    }
  },
  "id" : 618474721416466432,
  "created_at" : "2015-07-07 17:40:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EngConnectTeachers",
      "screen_name" : "eng_teachers",
      "indices" : [ 0, 13 ],
      "id_str" : "2861318566",
      "id" : 2861318566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618473849659785216",
  "geo" : { },
  "id_str" : "618474170872164352",
  "in_reply_to_user_id" : 2861318566,
  "text" : "@eng_teachers hi that's neat how are they using it?",
  "id" : 618474170872164352,
  "in_reply_to_status_id" : 618473849659785216,
  "created_at" : "2015-07-07 17:38:27 +0000",
  "in_reply_to_screen_name" : "eng_teachers",
  "in_reply_to_user_id_str" : "2861318566",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blossom",
      "screen_name" : "justBlossom75",
      "indices" : [ 0, 14 ],
      "id_str" : "2726131801",
      "id" : 2726131801
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/618473408020541440\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Ex2eHzQKL4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJVCSX5WIAAOAbY.png",
      "id_str" : "618473407252930560",
      "id" : 618473407252930560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJVCSX5WIAAOAbY.png",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 364
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 364
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 364
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Ex2eHzQKL4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/GK7vzD36ah",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=40407115",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "618472201927299072",
  "geo" : { },
  "id_str" : "618473408020541440",
  "in_reply_to_user_id" : 2726131801,
  "text" : "@justBlossom75 here are some http:\/\/t.co\/GK7vzD36ah http:\/\/t.co\/Ex2eHzQKL4",
  "id" : 618473408020541440,
  "in_reply_to_status_id" : 618472201927299072,
  "created_at" : "2015-07-07 17:35:25 +0000",
  "in_reply_to_screen_name" : "justBlossom75",
  "in_reply_to_user_id_str" : "2726131801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/aRF58OYdya",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/07\/the-spiral-of-despair\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618470858168922112",
  "text" : "RT @CraigMurrayOrg: Post Edited: The Spiral of Despair http:\/\/t.co\/aRF58OYdya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/aRF58OYdya",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/07\/the-spiral-of-despair\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618384219656560640",
    "text" : "Post Edited: The Spiral of Despair http:\/\/t.co\/aRF58OYdya",
    "id" : 618384219656560640,
    "created_at" : "2015-07-07 11:41:01 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 618470858168922112,
  "created_at" : "2015-07-07 17:25:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoutledgeLinguistics",
      "screen_name" : "RoutledgeLing",
      "indices" : [ 0, 14 ],
      "id_str" : "40210891",
      "id" : 40210891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618420699426889728",
  "geo" : { },
  "id_str" : "618447793850576896",
  "in_reply_to_user_id" : 40210891,
  "text" : "@RoutledgeLing thanks for mention :)",
  "id" : 618447793850576896,
  "in_reply_to_status_id" : 618420699426889728,
  "created_at" : "2015-07-07 15:53:38 +0000",
  "in_reply_to_screen_name" : "RoutledgeLing",
  "in_reply_to_user_id_str" : "40210891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoutledgeLinguistics",
      "screen_name" : "RoutledgeLing",
      "indices" : [ 3, 17 ],
      "id_str" : "40210891",
      "id" : 40210891
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 117, 126 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 127, 139 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/W16paj4e0K",
      "expanded_url" : "http:\/\/ow.ly\/PfHcE",
      "display_url" : "ow.ly\/PfHcE"
    } ]
  },
  "geo" : { },
  "id_str" : "618447575583191040",
  "text" : "RT @RoutledgeLing: Excellent interview w\/ Daniel Waller &amp; Christian Jones about 'Corpus Linguistics for Grammar' @muranava @ELTResearch htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 98, 107 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Chris Jones",
        "screen_name" : "ELTResearch",
        "indices" : [ 108, 120 ],
        "id_str" : "3308043417",
        "id" : 3308043417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/W16paj4e0K",
        "expanded_url" : "http:\/\/ow.ly\/PfHcE",
        "display_url" : "ow.ly\/PfHcE"
      } ]
    },
    "geo" : { },
    "id_str" : "618420699426889728",
    "text" : "Excellent interview w\/ Daniel Waller &amp; Christian Jones about 'Corpus Linguistics for Grammar' @muranava @ELTResearch http:\/\/t.co\/W16paj4e0K",
    "id" : 618420699426889728,
    "created_at" : "2015-07-07 14:05:59 +0000",
    "user" : {
      "name" : "RoutledgeLinguistics",
      "screen_name" : "RoutledgeLing",
      "protected" : false,
      "id_str" : "40210891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000760575542\/cdae8e025001fd7a8a49e889917d4f92_normal.jpeg",
      "id" : 40210891,
      "verified" : false
    }
  },
  "id" : 618447575583191040,
  "created_at" : "2015-07-07 15:52:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 114, 130 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/M6HJONHjwW",
      "expanded_url" : "https:\/\/shar.es\/1qUHvW",
      "display_url" : "shar.es\/1qUHvW"
    } ]
  },
  "geo" : { },
  "id_str" : "618447540858568704",
  "text" : "RT @seburnt: Great reading strategies: \u2018List-Group-Label\u2019 for pre-teaching vocabulary https:\/\/t.co\/M6HJONHjwW via @yearinthelifeof",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Simpson",
        "screen_name" : "yearinthelifeof",
        "indices" : [ 101, 117 ],
        "id_str" : "78543378",
        "id" : 78543378
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/M6HJONHjwW",
        "expanded_url" : "https:\/\/shar.es\/1qUHvW",
        "display_url" : "shar.es\/1qUHvW"
      } ]
    },
    "geo" : { },
    "id_str" : "618444197394280448",
    "text" : "Great reading strategies: \u2018List-Group-Label\u2019 for pre-teaching vocabulary https:\/\/t.co\/M6HJONHjwW via @yearinthelifeof",
    "id" : 618444197394280448,
    "created_at" : "2015-07-07 15:39:21 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 618447540858568704,
  "created_at" : "2015-07-07 15:52:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 3, 16 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 71, 86 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/rXzFk7WTdi",
      "expanded_url" : "http:\/\/wp.me\/p39fMp-xc",
      "display_url" : "wp.me\/p39fMp-xc"
    } ]
  },
  "geo" : { },
  "id_str" : "618379377286479872",
  "text" : "RT @ZhenyaDnipro: The Beauty of the Unknown http:\/\/t.co\/rXzFk7WTdi via @LjiljanaHavran &gt; &gt; about library, antilibrary, and (C)PD &gt; &gt; great \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ljiljana Havran",
        "screen_name" : "LjiljanaHavran",
        "indices" : [ 53, 68 ],
        "id_str" : "1395825290",
        "id" : 1395825290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/rXzFk7WTdi",
        "expanded_url" : "http:\/\/wp.me\/p39fMp-xc",
        "display_url" : "wp.me\/p39fMp-xc"
      } ]
    },
    "geo" : { },
    "id_str" : "618375644632756224",
    "text" : "The Beauty of the Unknown http:\/\/t.co\/rXzFk7WTdi via @LjiljanaHavran &gt; &gt; about library, antilibrary, and (C)PD &gt; &gt; great read!",
    "id" : 618375644632756224,
    "created_at" : "2015-07-07 11:06:57 +0000",
    "user" : {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "protected" : false,
      "id_str" : "2248486418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766906932875714560\/KfDv1cK8_normal.jpg",
      "id" : 2248486418,
      "verified" : false
    }
  },
  "id" : 618379377286479872,
  "created_at" : "2015-07-07 11:21:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618372471771820032",
  "geo" : { },
  "id_str" : "618379304716632064",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson search feature thanks to Twitter code, yr welcome",
  "id" : 618379304716632064,
  "in_reply_to_status_id" : 618372471771820032,
  "created_at" : "2015-07-07 11:21:29 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618364716159602688",
  "geo" : { },
  "id_str" : "618365495625035776",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish sounds like you need to take off to sunnier climes :)",
  "id" : 618365495625035776,
  "in_reply_to_status_id" : 618364716159602688,
  "created_at" : "2015-07-07 10:26:37 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618363947893166080",
  "geo" : { },
  "id_str" : "618364258427006976",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hehe u must be lucky with the weather in Japan?",
  "id" : 618364258427006976,
  "in_reply_to_status_id" : 618363947893166080,
  "created_at" : "2015-07-07 10:21:42 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618363580807778305",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thanks for RTing the PHaVE dictionary Marc :)",
  "id" : 618363580807778305,
  "created_at" : "2015-07-07 10:19:00 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "618354331109183492",
  "text" : "at this time of year would you be taking off your top or taking off on a plane? have a look at http:\/\/t.co\/feVV1F8lKr #ELT",
  "id" : 618354331109183492,
  "created_at" : "2015-07-07 09:42:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618334130489688064",
  "geo" : { },
  "id_str" : "618335736002166784",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona yr welcome, thx will look out for more info on this",
  "id" : 618335736002166784,
  "in_reply_to_status_id" : 618334130489688064,
  "created_at" : "2015-07-07 08:28:22 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 67, 76 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/FInPZ7Qyq2",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-6N",
      "display_url" : "wp.me\/p28EmH-6N"
    } ]
  },
  "geo" : { },
  "id_str" : "618333203611394048",
  "text" : "Taking to task(s): Task design and CALL http:\/\/t.co\/FInPZ7Qyq2 via @whyshona",
  "id" : 618333203611394048,
  "created_at" : "2015-07-07 08:18:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 66, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/QUt2pBdaPK",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/2izew7aX82q",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618146908918448129",
  "text" : "GraphColl a collocational network graph tool attempts to push fwd #corpuslinguistics interfaces https:\/\/t.co\/QUt2pBdaPK",
  "id" : 618146908918448129,
  "created_at" : "2015-07-06 19:58:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 0, 10 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618000423564242944",
  "geo" : { },
  "id_str" : "618087711476449280",
  "in_reply_to_user_id" : 444977554,
  "text" : "@joannacre yr welcome :)",
  "id" : 618087711476449280,
  "in_reply_to_status_id" : 618000423564242944,
  "created_at" : "2015-07-06 16:02:48 +0000",
  "in_reply_to_screen_name" : "joannacre",
  "in_reply_to_user_id_str" : "444977554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Van Amelsvoort",
      "screen_name" : "Marcelva",
      "indices" : [ 3, 12 ],
      "id_str" : "21634927",
      "id" : 21634927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/URNPWneu36",
      "expanded_url" : "http:\/\/mozuku.edublogs.org\/2015\/07\/06\/what-can-data-do-for-efl\/",
      "display_url" : "mozuku.edublogs.org\/2015\/07\/06\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617993226297942016",
  "text" : "RT @Marcelva: What can data do for EFL? http:\/\/t.co\/URNPWneu36",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/URNPWneu36",
        "expanded_url" : "http:\/\/mozuku.edublogs.org\/2015\/07\/06\/what-can-data-do-for-efl\/",
        "display_url" : "mozuku.edublogs.org\/2015\/07\/06\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "617943733447725056",
    "text" : "What can data do for EFL? http:\/\/t.co\/URNPWneu36",
    "id" : 617943733447725056,
    "created_at" : "2015-07-06 06:30:41 +0000",
    "user" : {
      "name" : "M. Van Amelsvoort",
      "screen_name" : "Marcelva",
      "protected" : false,
      "id_str" : "21634927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/81656891\/mountaincherryOp_normal.jpg",
      "id" : 21634927,
      "verified" : false
    }
  },
  "id" : 617993226297942016,
  "created_at" : "2015-07-06 09:47:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 3, 13 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/L75xuRtuP7",
      "expanded_url" : "https:\/\/myeltrambles.wordpress.com\/2015\/07\/06\/vocabulary-lsa-helping-elementary-learners-with-restricted-collocations",
      "display_url" : "myeltrambles.wordpress.com\/2015\/07\/06\/voc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617991489566711808",
  "text" : "RT @joannacre: Vocabulary LSA: Helping elementary learners with restricted collocations https:\/\/t.co\/L75xuRtuP7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/L75xuRtuP7",
        "expanded_url" : "https:\/\/myeltrambles.wordpress.com\/2015\/07\/06\/vocabulary-lsa-helping-elementary-learners-with-restricted-collocations",
        "display_url" : "myeltrambles.wordpress.com\/2015\/07\/06\/voc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "617989664746573824",
    "text" : "Vocabulary LSA: Helping elementary learners with restricted collocations https:\/\/t.co\/L75xuRtuP7",
    "id" : 617989664746573824,
    "created_at" : "2015-07-06 09:33:12 +0000",
    "user" : {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "protected" : false,
      "id_str" : "444977554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3251727601\/179472a3feae34c6561a1dd313c450b9_normal.jpeg",
      "id" : 444977554,
      "verified" : false
    }
  },
  "id" : 617991489566711808,
  "created_at" : "2015-07-06 09:40:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617658759599521793",
  "geo" : { },
  "id_str" : "617659264253984768",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C when are the results due?",
  "id" : 617659264253984768,
  "in_reply_to_status_id" : 617658759599521793,
  "created_at" : "2015-07-05 11:40:18 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617650849997803520",
  "geo" : { },
  "id_str" : "617656736653164544",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C power to the people!",
  "id" : 617656736653164544,
  "in_reply_to_status_id" : 617650849997803520,
  "created_at" : "2015-07-05 11:30:16 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "indices" : [ 112, 126 ],
      "id_str" : "3187104424",
      "id" : 3187104424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/TekuUZdiTJ",
      "expanded_url" : "http:\/\/wp.me\/p66Mp6-4j",
      "display_url" : "wp.me\/p66Mp6-4j"
    } ]
  },
  "geo" : { },
  "id_str" : "617655796537626624",
  "text" : "\"Thankfully, the English language has not changed very much since the 15th century.\" http:\/\/t.co\/TekuUZdiTJ via @EngliciousUCL",
  "id" : 617655796537626624,
  "created_at" : "2015-07-05 11:26:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 98, 114 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/TYuZU3sAvr",
      "expanded_url" : "http:\/\/wp.me\/p354NQ-7t",
      "display_url" : "wp.me\/p354NQ-7t"
    } ]
  },
  "geo" : { },
  "id_str" : "617654692227776512",
  "text" : "\u201CI feel it in my fingers\u2026\u201D: Linguistic repetition really is all around http:\/\/t.co\/TYuZU3sAvr via @wordpressdotcom",
  "id" : 617654692227776512,
  "created_at" : "2015-07-05 11:22:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617602524858552320",
  "geo" : { },
  "id_str" : "617609159152934912",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish more than welcome and you too :)",
  "id" : 617609159152934912,
  "in_reply_to_status_id" : 617602524858552320,
  "created_at" : "2015-07-05 08:21:12 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ySKvrlydNK",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/07\/03\/youre-gonna-need-a-bigger-boat-pitching-material",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/07\/03\/you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617600861645209601",
  "text" : "RT @getgreatenglish: I put up a post about one of my worst recent lessons and pitching material that's difficult. https:\/\/t.co\/ySKvrlydNK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ySKvrlydNK",
        "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/07\/03\/youre-gonna-need-a-bigger-boat-pitching-material",
        "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/07\/03\/you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "617588299658440704",
    "text" : "I put up a post about one of my worst recent lessons and pitching material that's difficult. https:\/\/t.co\/ySKvrlydNK",
    "id" : 617588299658440704,
    "created_at" : "2015-07-05 06:58:19 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 617600861645209601,
  "created_at" : "2015-07-05 07:48:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 124, 133 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 134, 138 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/YUKFVndCMT",
      "expanded_url" : "http:\/\/bit.ly\/1HEyJfh",
      "display_url" : "bit.ly\/1HEyJfh"
    } ]
  },
  "geo" : { },
  "id_str" : "617600797426237440",
  "text" : "RT @nathanghall: New how-to post on useful online corpora and collocation tools | Nathan Hall http:\/\/t.co\/YUKFVndCMT h\/t to @muranava #elt \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 107, 116 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 122, 130 ]
      }, {
        "text" : "edtech",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/YUKFVndCMT",
        "expanded_url" : "http:\/\/bit.ly\/1HEyJfh",
        "display_url" : "bit.ly\/1HEyJfh"
      } ]
    },
    "geo" : { },
    "id_str" : "617498173293096961",
    "text" : "New how-to post on useful online corpora and collocation tools | Nathan Hall http:\/\/t.co\/YUKFVndCMT h\/t to @muranava #elt #eltchat #edtech",
    "id" : 617498173293096961,
    "created_at" : "2015-07-05 01:00:11 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 617600797426237440,
  "created_at" : "2015-07-05 07:47:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617498173293096961",
  "geo" : { },
  "id_str" : "617599468087734272",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall very nice to read such a post on a Sunday :)",
  "id" : 617599468087734272,
  "in_reply_to_status_id" : 617498173293096961,
  "created_at" : "2015-07-05 07:42:42 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 0, 13 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616969089345540096",
  "geo" : { },
  "id_str" : "616986451016814592",
  "in_reply_to_user_id" : 624508480,
  "text" : "@ShetlandESOL yr welcome and u too :)",
  "id" : 616986451016814592,
  "in_reply_to_status_id" : 616969089345540096,
  "created_at" : "2015-07-03 15:06:47 +0000",
  "in_reply_to_screen_name" : "ShetlandESOL",
  "in_reply_to_user_id_str" : "624508480",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 3, 16 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "esol",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "elt",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "materialswriting",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/N7cmRta576",
      "expanded_url" : "https:\/\/hotel3001.wordpress.com\/2015\/07\/03\/lessons-learned-from-the-great-elt-coursebook-trawl\/",
      "display_url" : "hotel3001.wordpress.com\/2015\/07\/03\/les\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616966713368838144",
  "text" : "RT @ShetlandESOL: What reviewing ELT course books taught me about materials writing: https:\/\/t.co\/N7cmRta576   #esl #esol #elt #materialswr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esl",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "esol",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "elt",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "materialswriting",
        "indices" : [ 109, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/N7cmRta576",
        "expanded_url" : "https:\/\/hotel3001.wordpress.com\/2015\/07\/03\/lessons-learned-from-the-great-elt-coursebook-trawl\/",
        "display_url" : "hotel3001.wordpress.com\/2015\/07\/03\/les\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616949892649496576",
    "text" : "What reviewing ELT course books taught me about materials writing: https:\/\/t.co\/N7cmRta576   #esl #esol #elt #materialswriting",
    "id" : 616949892649496576,
    "created_at" : "2015-07-03 12:41:31 +0000",
    "user" : {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "protected" : false,
      "id_str" : "624508480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701748823496990720\/Lv4r7Bie_normal.jpg",
      "id" : 624508480,
      "verified" : false
    }
  },
  "id" : 616966713368838144,
  "created_at" : "2015-07-03 13:48:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Radice",
      "screen_name" : "AnthonyRadice1",
      "indices" : [ 60, 75 ],
      "id_str" : "1051294292",
      "id" : 1051294292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/BDYMzAIN0w",
      "expanded_url" : "http:\/\/wp.me\/p62rZw-4E",
      "display_url" : "wp.me\/p62rZw-4E"
    } ]
  },
  "geo" : { },
  "id_str" : "616921404164964352",
  "text" : "Uprooting Bad Ideas in Education http:\/\/t.co\/BDYMzAIN0w via @AnthonyRadice1",
  "id" : 616921404164964352,
  "created_at" : "2015-07-03 10:48:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616907506770554880",
  "geo" : { },
  "id_str" : "616909292357177344",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis something for UK Ed minister Nicky Morgan to chew on :)",
  "id" : 616909292357177344,
  "in_reply_to_status_id" : 616907506770554880,
  "created_at" : "2015-07-03 10:00:11 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChinwag",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Gk2ucDM4io",
      "expanded_url" : "http:\/\/ow.ly\/P80vL",
      "display_url" : "ow.ly\/P80vL"
    } ]
  },
  "geo" : { },
  "id_str" : "616901719792963584",
  "text" : "RT @lexicojules: Are idioms taking over your newsfeed? Part 2 of my blog about idioms prompted by #ELTChinwag last week: http:\/\/t.co\/Gk2ucD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTChinwag",
        "indices" : [ 81, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Gk2ucDM4io",
        "expanded_url" : "http:\/\/ow.ly\/P80vL",
        "display_url" : "ow.ly\/P80vL"
      } ]
    },
    "geo" : { },
    "id_str" : "616899852606304256",
    "text" : "Are idioms taking over your newsfeed? Part 2 of my blog about idioms prompted by #ELTChinwag last week: http:\/\/t.co\/Gk2ucDM4io",
    "id" : 616899852606304256,
    "created_at" : "2015-07-03 09:22:40 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 616901719792963584,
  "created_at" : "2015-07-03 09:30:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 68, 82 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/wx1RruDido",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-lqd",
      "display_url" : "wp.me\/p1RJaO-lqd"
    } ]
  },
  "geo" : { },
  "id_str" : "616898121944199168",
  "text" : "Why you shouldn't be better than average http:\/\/t.co\/wx1RruDido via @NicolaPrentis",
  "id" : 616898121944199168,
  "created_at" : "2015-07-03 09:15:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Leys",
      "screen_name" : "BrunoLeys",
      "indices" : [ 0, 10 ],
      "id_str" : "19535265",
      "id" : 19535265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616871603272429568",
  "geo" : { },
  "id_str" : "616886646777192448",
  "in_reply_to_user_id" : 19535265,
  "text" : "@BrunoLeys interesting &amp; useful concept of glass floor",
  "id" : 616886646777192448,
  "in_reply_to_status_id" : 616871603272429568,
  "created_at" : "2015-07-03 08:30:12 +0000",
  "in_reply_to_screen_name" : "BrunoLeys",
  "in_reply_to_user_id_str" : "19535265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trop Noire",
      "screen_name" : "TropNoire",
      "indices" : [ 0, 10 ],
      "id_str" : "3175985015",
      "id" : 3175985015
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 11, 24 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616703710618464256",
  "geo" : { },
  "id_str" : "616873590831607808",
  "in_reply_to_user_id" : 3175985015,
  "text" : "@TropNoire @GlenysHanson \nFran\u00E7ais blanc: Tu viens d\u2019ou?\nFran\u00E7ais non-blanc: Je suis Fran\u00E7ais\nFran\u00E7ais blanc: Depuis combien de temps? \n:\/",
  "id" : 616873590831607808,
  "in_reply_to_status_id" : 616703710618464256,
  "created_at" : "2015-07-03 07:38:19 +0000",
  "in_reply_to_screen_name" : "TropNoire",
  "in_reply_to_user_id_str" : "3175985015",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "indices" : [ 3, 10 ],
      "id_str" : "749992082",
      "id" : 749992082
    }, {
      "name" : "Sonal",
      "screen_name" : "sonalsgupta",
      "indices" : [ 35, 47 ],
      "id_str" : "118470043",
      "id" : 118470043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WJHKeMCqv8",
      "expanded_url" : "http:\/\/ow.ly\/P3TGr",
      "display_url" : "ow.ly\/P3TGr"
    } ]
  },
  "geo" : { },
  "id_str" : "616663658505052160",
  "text" : "RT @idibon: Stanford PhD candidate @sonalsgupta describes how to get good at pattern-finding by starting with just a few examples.http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sonal",
        "screen_name" : "sonalsgupta",
        "indices" : [ 23, 35 ],
        "id_str" : "118470043",
        "id" : 118470043
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/WJHKeMCqv8",
        "expanded_url" : "http:\/\/ow.ly\/P3TGr",
        "display_url" : "ow.ly\/P3TGr"
      } ]
    },
    "geo" : { },
    "id_str" : "616640669147361281",
    "text" : "Stanford PhD candidate @sonalsgupta describes how to get good at pattern-finding by starting with just a few examples.http:\/\/t.co\/WJHKeMCqv8",
    "id" : 616640669147361281,
    "created_at" : "2015-07-02 16:12:46 +0000",
    "user" : {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "protected" : false,
      "id_str" : "749992082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577899744749481985\/ospcUqfV_normal.jpeg",
      "id" : 749992082,
      "verified" : false
    }
  },
  "id" : 616663658505052160,
  "created_at" : "2015-07-02 17:44:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "indices" : [ 3, 16 ],
      "id_str" : "1225932950",
      "id" : 1225932950
    }, {
      "name" : "Weebly",
      "screen_name" : "weebly",
      "indices" : [ 139, 140 ],
      "id_str" : "5733082",
      "id" : 5733082
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/eBcCXBmCx7",
      "expanded_url" : "http:\/\/www.billsenglish.com\/1\/post\/2015\/07\/were-not-in-kansas-anymore-teachers-like-it-or-not-students-use-new-approaches-to-writing-with-sources.html",
      "display_url" : "billsenglish.com\/1\/post\/2015\/07\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616659794783510528",
  "text" : "RT @BillsEnglish: New blog post: New student research strategies can lead to plagiarism, but this can be helped! #ESL... http:\/\/t.co\/eBcCXB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.weebly.com\/\" rel=\"nofollow\"\u003EWeebly App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Weebly",
        "screen_name" : "weebly",
        "indices" : [ 130, 137 ],
        "id_str" : "5733082",
        "id" : 5733082
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 95, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/eBcCXBmCx7",
        "expanded_url" : "http:\/\/www.billsenglish.com\/1\/post\/2015\/07\/were-not-in-kansas-anymore-teachers-like-it-or-not-students-use-new-approaches-to-writing-with-sources.html",
        "display_url" : "billsenglish.com\/1\/post\/2015\/07\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616657993422237696",
    "text" : "New blog post: New student research strategies can lead to plagiarism, but this can be helped! #ESL... http:\/\/t.co\/eBcCXBmCx7 via @weebly",
    "id" : 616657993422237696,
    "created_at" : "2015-07-02 17:21:37 +0000",
    "user" : {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "protected" : false,
      "id_str" : "1225932950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000178985604\/38c86f0ad86b16b49ddd21f7e3d0e4dd_normal.jpeg",
      "id" : 1225932950,
      "verified" : false
    }
  },
  "id" : 616659794783510528,
  "created_at" : "2015-07-02 17:28:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/tzdAD5RhXp",
      "expanded_url" : "http:\/\/bit.ly\/arc-smashwords",
      "display_url" : "bit.ly\/arc-smashwords"
    } ]
  },
  "geo" : { },
  "id_str" : "616371792052158464",
  "text" : "RT @seburnt: A few hours left! Canada Day Sale: Academic Reading Circles is only $4.99USD today! Promo code at checkout: BP32N http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/tzdAD5RhXp",
        "expanded_url" : "http:\/\/bit.ly\/arc-smashwords",
        "display_url" : "bit.ly\/arc-smashwords"
      } ]
    },
    "geo" : { },
    "id_str" : "616365958513340417",
    "text" : "A few hours left! Canada Day Sale: Academic Reading Circles is only $4.99USD today! Promo code at checkout: BP32N http:\/\/t.co\/tzdAD5RhXp",
    "id" : 616365958513340417,
    "created_at" : "2015-07-01 22:01:10 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 616371792052158464,
  "created_at" : "2015-07-01 22:24:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616364599814815744",
  "geo" : { },
  "id_str" : "616366841359953920",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras yr welcome some great music from oota there for sure :)",
  "id" : 616366841359953920,
  "in_reply_to_status_id" : 616364599814815744,
  "created_at" : "2015-07-01 22:04:41 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBC Music",
      "screen_name" : "CBCMusic",
      "indices" : [ 0, 9 ],
      "id_str" : "456354916",
      "id" : 456354916
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 10, 21 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/m4ErR3SxuI",
      "expanded_url" : "http:\/\/www.driveplayer.com\/#fileIds=0B7FW2BYaBgeiZWFybk1KQVF0OE0&userId=104940199413423400545",
      "display_url" : "driveplayer.com\/#fileIds=0B7FW\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "616297733473742848",
  "geo" : { },
  "id_str" : "616364407682134016",
  "in_reply_to_user_id" : 456354916,
  "text" : "@CBCMusic @vickyloras did this music medley for a Canadian friend some years ago http:\/\/t.co\/m4ErR3SxuI Happy Canada Day :)",
  "id" : 616364407682134016,
  "in_reply_to_status_id" : 616297733473742848,
  "created_at" : "2015-07-01 21:55:00 +0000",
  "in_reply_to_screen_name" : "CBCMusic",
  "in_reply_to_user_id_str" : "456354916",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyson Indrunas",
      "screen_name" : "AlysonIndrunas",
      "indices" : [ 3, 18 ],
      "id_str" : "1093690267",
      "id" : 1093690267
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoSmartSoLoveThisSoBrilliant",
      "indices" : [ 62, 91 ]
    }, {
      "text" : "UnemployedOLFilmTeachersReadThis",
      "indices" : [ 93, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DgVePC0BU4",
      "expanded_url" : "https:\/\/twitter.com\/hackeducation\/status\/616301261969698816",
      "display_url" : "twitter.com\/hackeducation\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616308856352821252",
  "text" : "RT @AlysonIndrunas: Fabulous use of \"MacGuffin\" in this post! #SoSmartSoLoveThisSoBrilliant \n#UnemployedOLFilmTeachersReadThis https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoSmartSoLoveThisSoBrilliant",
        "indices" : [ 42, 71 ]
      }, {
        "text" : "UnemployedOLFilmTeachersReadThis",
        "indices" : [ 73, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/DgVePC0BU4",
        "expanded_url" : "https:\/\/twitter.com\/hackeducation\/status\/616301261969698816",
        "display_url" : "twitter.com\/hackeducation\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616306886959173632",
    "text" : "Fabulous use of \"MacGuffin\" in this post! #SoSmartSoLoveThisSoBrilliant \n#UnemployedOLFilmTeachersReadThis https:\/\/t.co\/DgVePC0BU4",
    "id" : 616306886959173632,
    "created_at" : "2015-07-01 18:06:26 +0000",
    "user" : {
      "name" : "Alyson Indrunas",
      "screen_name" : "AlysonIndrunas",
      "protected" : false,
      "id_str" : "1093690267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545985553003335680\/ReQIGX6A_normal.jpeg",
      "id" : 1093690267,
      "verified" : false
    }
  },
  "id" : 616308856352821252,
  "created_at" : "2015-07-01 18:14:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 0, 10 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616146677041364992",
  "geo" : { },
  "id_str" : "616151375156785152",
  "in_reply_to_user_id" : 295968758,
  "text" : "@nakanotim get the same thing with eurostar train \"membership\" card, these companies really do treat us as right members",
  "id" : 616151375156785152,
  "in_reply_to_status_id" : 616146677041364992,
  "created_at" : "2015-07-01 07:48:30 +0000",
  "in_reply_to_screen_name" : "nakanotim",
  "in_reply_to_user_id_str" : "295968758",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616150392846581760",
  "in_reply_to_user_id" : 2595004134,
  "text" : "@stuartahaley hi thanks for RT :)",
  "id" : 616150392846581760,
  "created_at" : "2015-07-01 07:44:35 +0000",
  "in_reply_to_screen_name" : "teacherstuart",
  "in_reply_to_user_id_str" : "2595004134",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]