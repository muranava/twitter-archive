Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Truthdig",
      "screen_name" : "Truthdig",
      "indices" : [ 119, 128 ],
      "id_str" : "15950681",
      "id" : 15950681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/sc5vPepvt2",
      "expanded_url" : "http:\/\/www.truthdig.com\/avbooth\/item\/chris_hedges_interview_noam_chomsky_on_empire_liberal_class_20141231\/#.VKQsaUc8_X4.twitter",
      "display_url" : "truthdig.com\/avbooth\/item\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550336656096505857",
  "text" : "Chris Hedges\u2019 Interview with Noam Chomsky on Empire, the Liberal Class and More - Truthdig: http:\/\/t.co\/sc5vPepvt2 via @truthdig",
  "id" : 550336656096505857,
  "created_at" : "2014-12-31 17:04:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/abVDtlKpYd",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/12\/tragedy-avoidance-and-why.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/12\/traged\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550312400638201856",
  "text" : "RT @johnwhilley: Tragedy, avoidance and the 'why'  http:\/\/t.co\/abVDtlKpYd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/abVDtlKpYd",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/12\/tragedy-avoidance-and-why.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/12\/traged\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "550272829338710017",
    "text" : "Tragedy, avoidance and the 'why'  http:\/\/t.co\/abVDtlKpYd",
    "id" : 550272829338710017,
    "created_at" : "2014-12-31 12:50:40 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 550312400638201856,
  "created_at" : "2014-12-31 15:27:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 12, 19 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550291550463614976",
  "geo" : { },
  "id_str" : "550293086124113922",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @eltjam a large majority of hits were SOLEs answering a big question - What is a curmudgeon? :)",
  "id" : 550293086124113922,
  "in_reply_to_status_id" : 550291550463614976,
  "created_at" : "2014-12-31 14:11:10 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "indices" : [ 3, 18 ],
      "id_str" : "186543637",
      "id" : 186543637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/h0jAsNkXMK",
      "expanded_url" : "http:\/\/nastyageinrikh.blogspot.com\/2014\/12\/skype-lessons_30.html?spref=tw",
      "display_url" : "nastyageinrikh.blogspot.com\/2014\/12\/skype-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550189567564058624",
  "text" : "RT @nastyageinrikh: Blog update: some tips and tools for yor Skype lessons http:\/\/t.co\/h0jAsNkXMK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/h0jAsNkXMK",
        "expanded_url" : "http:\/\/nastyageinrikh.blogspot.com\/2014\/12\/skype-lessons_30.html?spref=tw",
        "display_url" : "nastyageinrikh.blogspot.com\/2014\/12\/skype-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549938374081925120",
    "text" : "Blog update: some tips and tools for yor Skype lessons http:\/\/t.co\/h0jAsNkXMK",
    "id" : 549938374081925120,
    "created_at" : "2014-12-30 14:41:40 +0000",
    "user" : {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "protected" : false,
      "id_str" : "186543637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512265956534415361\/h5IEpCPu_normal.jpeg",
      "id" : 186543637,
      "verified" : false
    }
  },
  "id" : 550189567564058624,
  "created_at" : "2014-12-31 07:19:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "indices" : [ 3, 10 ],
      "id_str" : "2937071",
      "id" : 2937071
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwikihappening",
      "indices" : [ 95, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/8gwU5WnLv2",
      "expanded_url" : "http:\/\/blog.jonudell.net\/2014\/12\/30\/federated-wiki-for-teaching-and-learning-basic-composition\/",
      "display_url" : "blog.jonudell.net\/2014\/12\/30\/fed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550167198300667904",
  "text" : "RT @judell: Federated Wiki for teaching and learning basic composition. http:\/\/t.co\/8gwU5WnLv2 #fedwikihappening",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fedwikihappening",
        "indices" : [ 83, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/8gwU5WnLv2",
        "expanded_url" : "http:\/\/blog.jonudell.net\/2014\/12\/30\/federated-wiki-for-teaching-and-learning-basic-composition\/",
        "display_url" : "blog.jonudell.net\/2014\/12\/30\/fed\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "550016571616149504",
    "text" : "Federated Wiki for teaching and learning basic composition. http:\/\/t.co\/8gwU5WnLv2 #fedwikihappening",
    "id" : 550016571616149504,
    "created_at" : "2014-12-30 19:52:24 +0000",
    "user" : {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "protected" : false,
      "id_str" : "2937071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630462864403267584\/maaHx7Ta_normal.jpg",
      "id" : 2937071,
      "verified" : false
    }
  },
  "id" : 550167198300667904,
  "created_at" : "2014-12-31 05:50:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550077359412752386",
  "geo" : { },
  "id_str" : "550079388637986816",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne great thanks :)",
  "id" : 550079388637986816,
  "in_reply_to_status_id" : 550077359412752386,
  "created_at" : "2014-12-31 00:02:00 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/c1AOVGad6O",
      "expanded_url" : "https:\/\/github.com\/chriskiehl\/Gooey",
      "display_url" : "github.com\/chriskiehl\/Goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550076423625781249",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne hi am looking to use this to GUI up videogrep any pointers on how to? https:\/\/t.co\/c1AOVGad6O thanks!",
  "id" : 550076423625781249,
  "created_at" : "2014-12-30 23:50:13 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ZFCL1EQkxv",
      "expanded_url" : "http:\/\/superlooper.universlabs.co.uk",
      "display_url" : "superlooper.universlabs.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "549952504721833985",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet http:\/\/t.co\/ZFCL1EQkxv",
  "id" : 549952504721833985,
  "created_at" : "2014-12-30 15:37:49 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CamillaMariannaBaran",
      "screen_name" : "baran_camilla",
      "indices" : [ 0, 14 ],
      "id_str" : "2365687700",
      "id" : 2365687700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549912466906710016",
  "geo" : { },
  "id_str" : "549924397310836737",
  "in_reply_to_user_id" : 2365687700,
  "text" : "@baran_camilla hehe all the best for 2015 to you as well :)",
  "id" : 549924397310836737,
  "in_reply_to_status_id" : 549912466906710016,
  "created_at" : "2014-12-30 13:46:08 +0000",
  "in_reply_to_screen_name" : "baran_camilla",
  "in_reply_to_user_id_str" : "2365687700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CamillaMariannaBaran",
      "screen_name" : "baran_camilla",
      "indices" : [ 0, 14 ],
      "id_str" : "2365687700",
      "id" : 2365687700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549915359953047552",
  "geo" : { },
  "id_str" : "549924248169762816",
  "in_reply_to_user_id" : 2365687700,
  "text" : "@baran_camilla yes the article is pointing out the non-Ukrainians in Ukraine government",
  "id" : 549924248169762816,
  "in_reply_to_status_id" : 549915359953047552,
  "created_at" : "2014-12-30 13:45:32 +0000",
  "in_reply_to_screen_name" : "baran_camilla",
  "in_reply_to_user_id_str" : "2365687700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isohunt.to",
      "screen_name" : "Isohuntto",
      "indices" : [ 3, 13 ],
      "id_str" : "2164844864",
      "id" : 2164844864
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeOpenBay",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/CBVQgBghRa",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FQTdgi9tOTA",
      "display_url" : "youtube.com\/watch?v=FQTdgi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549923851614691329",
  "text" : "RT @Isohuntto: Here is an awesome video instruction from one of our users on how to install Open Bay. Check it out!\n#CodeOpenBay\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CodeOpenBay",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/CBVQgBghRa",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FQTdgi9tOTA",
        "display_url" : "youtube.com\/watch?v=FQTdgi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549842547884183553",
    "text" : "Here is an awesome video instruction from one of our users on how to install Open Bay. Check it out!\n#CodeOpenBay\nhttps:\/\/t.co\/CBVQgBghRa",
    "id" : 549842547884183553,
    "created_at" : "2014-12-30 08:20:53 +0000",
    "user" : {
      "name" : "isohunt.to",
      "screen_name" : "Isohuntto",
      "protected" : false,
      "id_str" : "2164844864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000831366529\/37257d4ceb8bfef265c037e391cbdd9c_normal.png",
      "id" : 2164844864,
      "verified" : false
    }
  },
  "id" : 549923851614691329,
  "created_at" : "2014-12-30 13:43:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEAS",
      "screen_name" : "NEAS_Australia",
      "indices" : [ 0, 15 ],
      "id_str" : "927168978",
      "id" : 927168978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549899544709038081",
  "in_reply_to_user_id" : 927168978,
  "text" : "@NEAS_Australia hi thanks for sharing post :)",
  "id" : 549899544709038081,
  "created_at" : "2014-12-30 12:07:22 +0000",
  "in_reply_to_screen_name" : "NEAS_Australia",
  "in_reply_to_user_id_str" : "927168978",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CamillaMariannaBaran",
      "screen_name" : "baran_camilla",
      "indices" : [ 0, 14 ],
      "id_str" : "2365687700",
      "id" : 2365687700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549897751975456768",
  "geo" : { },
  "id_str" : "549899339255271424",
  "in_reply_to_user_id" : 2365687700,
  "text" : "@baran_camilla hi i think i meant the one everyone is born into, was trying a pretentious tweet during a night out :)",
  "id" : 549899339255271424,
  "in_reply_to_status_id" : 549897751975456768,
  "created_at" : "2014-12-30 12:06:33 +0000",
  "in_reply_to_screen_name" : "baran_camilla",
  "in_reply_to_user_id_str" : "2365687700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/TGVBs3nw3J",
      "expanded_url" : "http:\/\/russia-insider.com\/en\/politics_ukraine_opinion\/2014\/12\/05\/11-07-04pm\/ukrainian_governemnt_switches_russian_language",
      "display_url" : "russia-insider.com\/en\/politics_uk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549897623537082368",
  "text" : "Foreigners in Ukraine's Cabinet Means Meetings Have to be Held in Russian Language - Russia Insider http:\/\/t.co\/TGVBs3nw3J",
  "id" : 549897623537082368,
  "created_at" : "2014-12-30 11:59:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549723073096982529",
  "text" : "You are not wrong. The system is. Never forget that.",
  "id" : 549723073096982529,
  "created_at" : "2014-12-30 00:26:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 107, 123 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/gINhIXRG53",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-8Oz",
      "display_url" : "wp.me\/p1U04a-8Oz"
    } ]
  },
  "geo" : { },
  "id_str" : "549639160529571840",
  "text" : "Iain Duncan Smith's portrait made from photos of people who died for being poor http:\/\/t.co\/gINhIXRG53 via @wordpressdotcom",
  "id" : 549639160529571840,
  "created_at" : "2014-12-29 18:52:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549599584021127168",
  "geo" : { },
  "id_str" : "549615038928289792",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code ok thx is there any advantage to using a different server from PAW?",
  "id" : 549615038928289792,
  "in_reply_to_status_id" : 549599584021127168,
  "created_at" : "2014-12-29 17:16:51 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549235257514655745",
  "geo" : { },
  "id_str" : "549582844612575234",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code hi can u give examples of external server support? thx",
  "id" : 549582844612575234,
  "in_reply_to_status_id" : 549235257514655745,
  "created_at" : "2014-12-29 15:08:55 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Camoron",
      "screen_name" : "EtonOldBoys",
      "indices" : [ 3, 15 ],
      "id_str" : "204864531",
      "id" : 204864531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549567851892592641",
  "text" : "RT @EtonOldBoys: It was that cold this morning, I saw a Tory MP with his hands in his own pockets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "549508887607771137",
    "text" : "It was that cold this morning, I saw a Tory MP with his hands in his own pockets",
    "id" : 549508887607771137,
    "created_at" : "2014-12-29 10:15:02 +0000",
    "user" : {
      "name" : "Dave Camoron",
      "screen_name" : "EtonOldBoys",
      "protected" : false,
      "id_str" : "204864531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757319301846237184\/vTESTKg7_normal.jpg",
      "id" : 204864531,
      "verified" : false
    }
  },
  "id" : 549567851892592641,
  "created_at" : "2014-12-29 14:09:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Things that matter",
      "screen_name" : "Thingsthatmat",
      "indices" : [ 64, 78 ],
      "id_str" : "2285566819",
      "id" : 2285566819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/w22Gd75LcU",
      "expanded_url" : "http:\/\/wp.me\/p3Z5F8-fc",
      "display_url" : "wp.me\/p3Z5F8-fc"
    } ]
  },
  "geo" : { },
  "id_str" : "549566565729853441",
  "text" : "2014's \"Biggest Moron\" is revealed.: http:\/\/t.co\/w22Gd75LcU via @Thingsthatmat",
  "id" : 549566565729853441,
  "created_at" : "2014-12-29 14:04:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 112, 128 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/oIx8llaVUC",
      "expanded_url" : "http:\/\/wp.me\/p4gDtp-2y",
      "display_url" : "wp.me\/p4gDtp-2y"
    } ]
  },
  "geo" : { },
  "id_str" : "549557596294615042",
  "text" : "Bliu Bliu: \u2018the only company in the world that teaches languages we don\u2019t even know\u2019 http:\/\/t.co\/oIx8llaVUC via @wordpressdotcom",
  "id" : 549557596294615042,
  "created_at" : "2014-12-29 13:28:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/J6Kii5QL65",
      "expanded_url" : "http:\/\/vimeo.com\/72501076",
      "display_url" : "vimeo.com\/72501076"
    } ]
  },
  "in_reply_to_status_id_str" : "549520330910203904",
  "geo" : { },
  "id_str" : "549554085360578560",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson nice, have you seen hyperland http:\/\/t.co\/J6Kii5QL65?",
  "id" : 549554085360578560,
  "in_reply_to_status_id" : 549520330910203904,
  "created_at" : "2014-12-29 13:14:38 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 57, 68 ]
    }, {
      "text" : "auselt",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "edchat",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "tesol",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "esl",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "tefl",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/6Nb80JFUkt",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Sd",
      "display_url" : "wp.me\/pgHyE-Sd"
    } ]
  },
  "geo" : { },
  "id_str" : "549547155623391233",
  "text" : "Fav the PHaVE Pedagogical List for the New Year #eltchat #eltchinwag #auselt #keltchat #edchat #tesol #esl #tefl\u2026 http:\/\/t.co\/6Nb80JFUkt",
  "id" : 549547155623391233,
  "created_at" : "2014-12-29 12:47:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Made Hery Santosa",
      "screen_name" : "mhsantosa",
      "indices" : [ 0, 10 ],
      "id_str" : "213953940",
      "id" : 213953940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549031209930858497",
  "geo" : { },
  "id_str" : "549258639547305984",
  "in_reply_to_user_id" : 213953940,
  "text" : "@mhsantosa hi thx for sharing :)",
  "id" : 549258639547305984,
  "in_reply_to_status_id" : 549031209930858497,
  "created_at" : "2014-12-28 17:40:39 +0000",
  "in_reply_to_screen_name" : "mhsantosa",
  "in_reply_to_user_id_str" : "213953940",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/yAmgYp5vDD",
      "expanded_url" : "https:\/\/zcomm.org\/znetarticle\/selma-portrays-the-true-martin-luther-king-jr\/",
      "display_url" : "zcomm.org\/znetarticle\/se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549242831140028416",
  "text" : "\u2018Selma\u2019 Portrays the True Martin Luther King Jr https:\/\/t.co\/yAmgYp5vDD",
  "id" : 549242831140028416,
  "created_at" : "2014-12-28 16:37:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    }, {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 120, 135 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Gaj2y2xgtZ",
      "expanded_url" : "http:\/\/theconversation.com\/learning-to-speak-english-making-yourself-understood-isnt-all-about-the-accent-34515",
      "display_url" : "theconversation.com\/learning-to-sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "548880284524216322",
  "text" : "RT @i_narrator: Learning to speak English? Making yourself understood isn't all about the accent http:\/\/t.co\/Gaj2y2xgtZ @ConversationUK\u304B\u3089",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Conversation",
        "screen_name" : "ConversationUK",
        "indices" : [ 104, 119 ],
        "id_str" : "1241258612",
        "id" : 1241258612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Gaj2y2xgtZ",
        "expanded_url" : "http:\/\/theconversation.com\/learning-to-speak-english-making-yourself-understood-isnt-all-about-the-accent-34515",
        "display_url" : "theconversation.com\/learning-to-sp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "548836977106116612",
    "text" : "Learning to speak English? Making yourself understood isn't all about the accent http:\/\/t.co\/Gaj2y2xgtZ @ConversationUK\u304B\u3089",
    "id" : 548836977106116612,
    "created_at" : "2014-12-27 13:45:06 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 548880284524216322,
  "created_at" : "2014-12-27 16:37:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "fedwikihappening",
      "indices" : [ 76, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548874370509467648",
  "text" : "so anyone figured out how to get data plugin working with graphs? #fedwiki\n #fedwikihappening",
  "id" : 548874370509467648,
  "created_at" : "2014-12-27 16:13:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "548870945234907137",
  "geo" : { },
  "id_str" : "548872041181749248",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet hehe nice build on raspberry pi apparently",
  "id" : 548872041181749248,
  "in_reply_to_status_id" : 548870945234907137,
  "created_at" : "2014-12-27 16:04:26 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "548862239130664961",
  "geo" : { },
  "id_str" : "548866570618171392",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan dang well hope they are not working u too hard",
  "id" : 548866570618171392,
  "in_reply_to_status_id" : 548862239130664961,
  "created_at" : "2014-12-27 15:42:42 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548861730382942208",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan thanks for sharing Adi hope u r having a good break",
  "id" : 548861730382942208,
  "created_at" : "2014-12-27 15:23:28 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "esl",
      "indices" : [ 5, 9 ]
    }, {
      "text" : "tefl",
      "indices" : [ 10, 15 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/KHGeK274hH",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/phave-trainer.html",
      "display_url" : "phave-dictionary.englishup.me\/phave-trainer.\u2026"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/4pioGthQJn",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/index.html",
      "display_url" : "phave-dictionary.englishup.me\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "548851869498769408",
  "text" : "#efl #esl #tefl #eltchat Teachers try the PHaVE phrasal verb trainer http:\/\/t.co\/KHGeK274hH from PHaVE dictionary http:\/\/t.co\/4pioGthQJn",
  "id" : 548851869498769408,
  "created_at" : "2014-12-27 14:44:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "efl",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "tefl",
      "indices" : [ 75, 80 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "esl",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/h7CwAgQZ2b",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "548634506379661312",
  "text" : "PHaVE top 150 phrasal verb dictionary http:\/\/t.co\/h7CwAgQZ2b #eltchat #efl #tefl #corpusmooc #esl",
  "id" : 548634506379661312,
  "created_at" : "2014-12-27 00:20:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/gHcZoHCU0M",
      "expanded_url" : "http:\/\/songexploder.net\/",
      "display_url" : "songexploder.net"
    } ]
  },
  "geo" : { },
  "id_str" : "548455139024330752",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet Song Exploder http:\/\/t.co\/gHcZoHCU0M  Listen as musicians pull apart and put back together their songs",
  "id" : 548455139024330752,
  "created_at" : "2014-12-26 12:27:49 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/rdvmDnMVpU",
      "expanded_url" : "http:\/\/gawker.com\/a-lot-of-smart-people-think-north-korea-didnt-hack-sony-1672899940",
      "display_url" : "gawker.com\/a-lot-of-smart\u2026"
    }, {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/RkL4ZcRrz3",
      "expanded_url" : "http:\/\/fabiusmaximus.com\/2014\/12\/20\/rebuttal-holes-fbi-north-korea-sony-attack-74873\/",
      "display_url" : "fabiusmaximus.com\/2014\/12\/20\/reb\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/k58DruLey0",
      "expanded_url" : "http:\/\/blog.erratasec.com\/2014\/12\/the-fbis-north-korea-evidence-is.html#.VJoSE7AWE0",
      "display_url" : "blog.erratasec.com\/2014\/12\/the-fb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "548047934059999232",
  "text" : "RT @patrickDurusau: FBI story that North Korea hacked Sony is shit. Quick: http:\/\/t.co\/rdvmDnMVpU Thorough: http:\/\/t.co\/RkL4ZcRrz3 More: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/rdvmDnMVpU",
        "expanded_url" : "http:\/\/gawker.com\/a-lot-of-smart-people-think-north-korea-didnt-hack-sony-1672899940",
        "display_url" : "gawker.com\/a-lot-of-smart\u2026"
      }, {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/RkL4ZcRrz3",
        "expanded_url" : "http:\/\/fabiusmaximus.com\/2014\/12\/20\/rebuttal-holes-fbi-north-korea-sony-attack-74873\/",
        "display_url" : "fabiusmaximus.com\/2014\/12\/20\/reb\u2026"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/k58DruLey0",
        "expanded_url" : "http:\/\/blog.erratasec.com\/2014\/12\/the-fbis-north-korea-evidence-is.html#.VJoSE7AWE0",
        "display_url" : "blog.erratasec.com\/2014\/12\/the-fb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "547879869774704640",
    "text" : "FBI story that North Korea hacked Sony is shit. Quick: http:\/\/t.co\/rdvmDnMVpU Thorough: http:\/\/t.co\/RkL4ZcRrz3 More: http:\/\/t.co\/k58DruLey0",
    "id" : 547879869774704640,
    "created_at" : "2014-12-24 22:21:54 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 548047934059999232,
  "created_at" : "2014-12-25 09:29:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "547713695615168512",
  "geo" : { },
  "id_str" : "547718751719030786",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin pedantic alert i guess author means unfair discrimination as hiring anyone is discrimination by definition :)",
  "id" : 547718751719030786,
  "in_reply_to_status_id" : 547713695615168512,
  "created_at" : "2014-12-24 11:41:41 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwikihappening",
      "indices" : [ 71, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547486104254152704",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden any tips\/info on getting line\/bar graph data plugin working on #fedwikihappening ?",
  "id" : 547486104254152704,
  "created_at" : "2014-12-23 20:17:13 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/xQBjmw4k8h",
      "expanded_url" : "http:\/\/redd.it\/2po7ht",
      "display_url" : "redd.it\/2po7ht"
    } ]
  },
  "geo" : { },
  "id_str" : "547463893480919041",
  "text" : "3 Reasons Why Evans's Aeon Piece is Wrong and Largely Begs the Questions... http:\/\/t.co\/xQBjmw4k8h",
  "id" : 547463893480919041,
  "created_at" : "2014-12-23 18:48:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/l1O4tS2w7W",
      "expanded_url" : "http:\/\/www.psychologytoday.com\/blog\/language-in-the-mind\/201412\/is-language-instinct",
      "display_url" : "psychologytoday.com\/blog\/language-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547326101152731136",
  "text" : "Is Language an Instinct? | Psychology Today http:\/\/t.co\/l1O4tS2w7W",
  "id" : 547326101152731136,
  "created_at" : "2014-12-23 09:41:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GnRVcCQqbq",
      "expanded_url" : "http:\/\/vimeo.com\/115154289",
      "display_url" : "vimeo.com\/115154289"
    } ]
  },
  "geo" : { },
  "id_str" : "547134429819596800",
  "text" : "RT @worrydream: \u2605 The Humane Representation of Thought: a trail map for the 21st century.  (keynote at UIST and SPLASH, 1 hour)  http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/GnRVcCQqbq",
        "expanded_url" : "http:\/\/vimeo.com\/115154289",
        "display_url" : "vimeo.com\/115154289"
      } ]
    },
    "geo" : { },
    "id_str" : "547096038813609984",
    "text" : "\u2605 The Humane Representation of Thought: a trail map for the 21st century.  (keynote at UIST and SPLASH, 1 hour)  http:\/\/t.co\/GnRVcCQqbq",
    "id" : 547096038813609984,
    "created_at" : "2014-12-22 18:27:14 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 547134429819596800,
  "created_at" : "2014-12-22 20:59:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 101, 109 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/1apJhQFQAs",
      "expanded_url" : "http:\/\/youtu.be\/7SLV2yNhhgU",
      "display_url" : "youtu.be\/7SLV2yNhhgU"
    } ]
  },
  "geo" : { },
  "id_str" : "547107728527601664",
  "text" : "The Trews VS The Sainsbury's Xmas Advert: Russell Brand The Trews (E214): http:\/\/t.co\/1apJhQFQAs via @YouTube",
  "id" : 547107728527601664,
  "created_at" : "2014-12-22 19:13:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/R45WMLCUZ3",
      "expanded_url" : "http:\/\/youtu.be\/n_pS2oFG9lI",
      "display_url" : "youtu.be\/n_pS2oFG9lI"
    } ]
  },
  "geo" : { },
  "id_str" : "546979960745766913",
  "text" : "John Pilger: 'Real possibility of nuclear war' - Ukraine crisis could st...: http:\/\/t.co\/R45WMLCUZ3 via @YouTube",
  "id" : 546979960745766913,
  "created_at" : "2014-12-22 10:45:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546822820966060032",
  "geo" : { },
  "id_str" : "546967738179411968",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei nice look fwd to playing with this :)",
  "id" : 546967738179411968,
  "in_reply_to_status_id" : 546822820966060032,
  "created_at" : "2014-12-22 09:57:25 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 124, 131 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/tP10K8OfPW",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com?random",
      "display_url" : "eflnotes.wordpress.com\/?random"
    } ]
  },
  "geo" : { },
  "id_str" : "546452156640153601",
  "text" : "spice up yr eflnotes blog reading play blog roulette http:\/\/t.co\/tP10K8OfPW don't forget to try it on yr wordpress blog h\/t @cogdog",
  "id" : 546452156640153601,
  "created_at" : "2014-12-20 23:48:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/KjvOL4F005",
      "expanded_url" : "http:\/\/12mars.rsf.org\/2014-en\/#slide3",
      "display_url" : "12mars.rsf.org\/2014-en\/#slide3"
    } ]
  },
  "in_reply_to_status_id_str" : "546433752906612737",
  "geo" : { },
  "id_str" : "546435754181017600",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd this is an interesting map Enemies of the Internet http:\/\/t.co\/KjvOL4F005",
  "id" : 546435754181017600,
  "in_reply_to_status_id" : 546433752906612737,
  "created_at" : "2014-12-20 22:43:30 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 12, 21 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "Alexey Navalny",
      "screen_name" : "navalny",
      "indices" : [ 22, 30 ],
      "id_str" : "82299300",
      "id" : 82299300
    }, {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 76, 85 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsaying",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546431326359138304",
  "geo" : { },
  "id_str" : "546433139581931520",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd @facebook @navalny that first line in the article reads like an @TheOnion piece #justsaying",
  "id" : 546433139581931520,
  "in_reply_to_status_id" : 546431326359138304,
  "created_at" : "2014-12-20 22:33:07 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 8, 18 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    }, {
      "name" : "Frances Bell",
      "screen_name" : "francesbell",
      "indices" : [ 19, 31 ],
      "id_str" : "12438922",
      "id" : 12438922
    }, {
      "name" : "Alex North",
      "screen_name" : "alexnorth",
      "indices" : [ 32, 42 ],
      "id_str" : "17419212",
      "id" : 17419212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546416365637091328",
  "geo" : { },
  "id_str" : "546424581284958209",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden @Bali_Maha @francesbell @alexnorth hmm if it includes head size&lt;-&gt;edit number link :)",
  "id" : 546424581284958209,
  "in_reply_to_status_id" : 546416365637091328,
  "created_at" : "2014-12-20 21:59:06 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/5D5ILGpKu7",
      "expanded_url" : "https:\/\/vine.co\/v\/OmK5wldUIIm",
      "display_url" : "vine.co\/v\/OmK5wldUIIm"
    } ]
  },
  "geo" : { },
  "id_str" : "546300720933138433",
  "text" : "ma prof d'anglais https:\/\/t.co\/5D5ILGpKu7",
  "id" : 546300720933138433,
  "created_at" : "2014-12-20 13:46:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 50, 66 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Py98EMvgX5",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-hV",
      "display_url" : "wp.me\/p2CPYN-hV"
    } ]
  },
  "geo" : { },
  "id_str" : "546291348240736256",
  "text" : "Massacres that matter. http:\/\/t.co\/Py98EMvgX5 via @wordpressdotcom",
  "id" : 546291348240736256,
  "created_at" : "2014-12-20 13:09:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 77, 93 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/M1IK1dwRNJ",
      "expanded_url" : "http:\/\/wp.me\/p4Z8Gv-2N",
      "display_url" : "wp.me\/p4Z8Gv-2N"
    } ]
  },
  "geo" : { },
  "id_str" : "546263108964990977",
  "text" : "Was marching on 15 February 2003 a waste of time? http:\/\/t.co\/M1IK1dwRNJ via @wordpressdotcom",
  "id" : 546263108964990977,
  "created_at" : "2014-12-20 11:17:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 97, 105 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Pp6Gli4adL",
      "expanded_url" : "http:\/\/youtu.be\/6QRURAbAvWY",
      "display_url" : "youtu.be\/6QRURAbAvWY"
    } ]
  },
  "geo" : { },
  "id_str" : "546053158842036224",
  "text" : "How To Beat A Corporation By New Era: Russell Brand The Trews (E215): http:\/\/t.co\/Pp6Gli4adL via @YouTube",
  "id" : 546053158842036224,
  "created_at" : "2014-12-19 21:23:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/vsvBaIHUHt",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/blog-shoutouts\/",
      "display_url" : "eflnotes.wordpress.com\/blog-shoutouts\/"
    } ]
  },
  "geo" : { },
  "id_str" : "546044160537788416",
  "text" : "New page Blog shoutouts: We are not worthy https:\/\/t.co\/vsvBaIHUHt #eltchat",
  "id" : 546044160537788416,
  "created_at" : "2014-12-19 20:47:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chilcot",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/0KaBeS9K8P",
      "expanded_url" : "http:\/\/youtu.be\/9wEro_h1yBI",
      "display_url" : "youtu.be\/9wEro_h1yBI"
    } ]
  },
  "geo" : { },
  "id_str" : "546031663038611457",
  "text" : "RT @JuliuzBeezer: Tired of waiting for #Chilcot to report, Captain SKA bring you this danceable message: http:\/\/t.co\/0KaBeS9K8P &amp;Hoxton lau\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chilcot",
        "indices" : [ 21, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/0KaBeS9K8P",
        "expanded_url" : "http:\/\/youtu.be\/9wEro_h1yBI",
        "display_url" : "youtu.be\/9wEro_h1yBI"
      } ]
    },
    "geo" : { },
    "id_str" : "546028347407339520",
    "text" : "Tired of waiting for #Chilcot to report, Captain SKA bring you this danceable message: http:\/\/t.co\/0KaBeS9K8P &amp;Hoxton launch 20mn if U there",
    "id" : 546028347407339520,
    "created_at" : "2014-12-19 19:44:37 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 546031663038611457,
  "created_at" : "2014-12-19 19:57:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545725732203134976",
  "geo" : { },
  "id_str" : "545726793786081280",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden ok thx, how do i get rid of the empty space that trying to embed has caused in the hyperlands post?",
  "id" : 545726793786081280,
  "in_reply_to_status_id" : 545725732203134976,
  "created_at" : "2014-12-18 23:46:21 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545724917950324736",
  "geo" : { },
  "id_str" : "545725358080024576",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden the video plugin uses iframes no?",
  "id" : 545725358080024576,
  "in_reply_to_status_id" : 545724917950324736,
  "created_at" : "2014-12-18 23:40:39 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/dG1qXeXafM",
      "expanded_url" : "https:\/\/books.google.fr\/books?id=5zfC1wI0wzUC&lpg=PA95&ots=p3-fDuWSoX&dq=micons%20video%20mosaics&pg=PA95#v=onepage&q=micons%20video%20mosaics&f=false",
      "display_url" : "books.google.fr\/books?id=5zfC1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "545720686069547008",
  "geo" : { },
  "id_str" : "545724581303287808",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden it's an iframe embed though i think twitter has mucked it up here is normal link https:\/\/t.co\/dG1qXeXafM",
  "id" : 545724581303287808,
  "in_reply_to_status_id" : 545720686069547008,
  "created_at" : "2014-12-18 23:37:33 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/5763jDhU96",
      "expanded_url" : "https:\/\/books.google.fr\/books?id=5zfC1wI0wzUC&lpg=PA95&ots=p3-fDuWSoX&dq=micons%20video%20mosaics&pg=PA95&output=embed",
      "display_url" : "books.google.fr\/books?id=5zfC1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "545720686069547008",
  "geo" : { },
  "id_str" : "545724338482479104",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden &lt;iframe frameborder=\"0\" scrolling=\"no\" style=\"border:0px\" src=\"https:\/\/t.co\/5763jDhU96\" width=500 height=500&gt;&lt;\/iframe&gt;",
  "id" : 545724338482479104,
  "in_reply_to_status_id" : 545720686069547008,
  "created_at" : "2014-12-18 23:36:36 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 54, 70 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/e0rvAtINTV",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-4C7",
      "display_url" : "wp.me\/p2KE8s-4C7"
    } ]
  },
  "geo" : { },
  "id_str" : "545696520599662592",
  "text" : "More realistic lesson aims http:\/\/t.co\/e0rvAtINTV via @wordpressdotcom",
  "id" : 545696520599662592,
  "created_at" : "2014-12-18 21:46:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545693366542155776",
  "text" : "#fedwiki reading link words &amp; wondering if any synax for hat tipping\/via?",
  "id" : 545693366542155776,
  "created_at" : "2014-12-18 21:33:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/klus7MrJU9",
      "expanded_url" : "http:\/\/mura.uk.fedwikihappening.net\/view\/welcome-visitors\/view\/hyperland",
      "display_url" : "mura.uk.fedwikihappening.net\/view\/welcome-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545691501175767040",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden hi i tried to embed a google book link here but cant seem to? http:\/\/t.co\/klus7MrJU9",
  "id" : 545691501175767040,
  "created_at" : "2014-12-18 21:26:06 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/JZaAAr3s8J",
      "expanded_url" : "http:\/\/bit.ly\/1wCoJdQ",
      "display_url" : "bit.ly\/1wCoJdQ"
    } ]
  },
  "geo" : { },
  "id_str" : "545603811591462912",
  "text" : "Capitalism Must Die Or We Will | Opinion | teleSUR http:\/\/t.co\/JZaAAr3s8J",
  "id" : 545603811591462912,
  "created_at" : "2014-12-18 15:37:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/P5kunWdIyr",
      "expanded_url" : "http:\/\/www.cepr.net\/index.php\/blogs\/beat-the-press\/schumer-should-focus-on-keeping-government-from-redistributing-income-upward",
      "display_url" : "cepr.net\/index.php\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545565420728905729",
  "text" : "Technology is actually having less effect in recent years than in prior years because productivity growth has slowed http:\/\/t.co\/P5kunWdIyr",
  "id" : 545565420728905729,
  "created_at" : "2014-12-18 13:05:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Radical Independence",
      "screen_name" : "Radical_Indy",
      "indices" : [ 18, 31 ],
      "id_str" : "601852634",
      "id" : 601852634
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 54, 63 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 98, 114 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/LyixIUICYU",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-12-17\/queen-helped-stop-scots-ominous-yes-vote\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-12-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545510995540836354",
  "text" : "RT @johnwhilley: .@Radical_Indy Excellent analysis of @guardian's own coverage of this story from @Jonathan_K_Cook http:\/\/t.co\/LyixIUICYU P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Radical Independence",
        "screen_name" : "Radical_Indy",
        "indices" : [ 1, 14 ],
        "id_str" : "601852634",
        "id" : 601852634
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 37, 46 ],
        "id_str" : "87818409",
        "id" : 87818409
      }, {
        "name" : "Jonathan Cook",
        "screen_name" : "Jonathan_K_Cook",
        "indices" : [ 81, 97 ],
        "id_str" : "2459644405",
        "id" : 2459644405
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/LyixIUICYU",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-12-17\/queen-helped-stop-scots-ominous-yes-vote\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-12-1\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "544984129113423873",
    "geo" : { },
    "id_str" : "545333519246188544",
    "in_reply_to_user_id" : 601852634,
    "text" : ".@Radical_Indy Excellent analysis of @guardian's own coverage of this story from @Jonathan_K_Cook http:\/\/t.co\/LyixIUICYU Please could you RT",
    "id" : 545333519246188544,
    "in_reply_to_status_id" : 544984129113423873,
    "created_at" : "2014-12-17 21:43:37 +0000",
    "in_reply_to_screen_name" : "Radical_Indy",
    "in_reply_to_user_id_str" : "601852634",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 545510995540836354,
  "created_at" : "2014-12-18 09:28:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545482561779417088",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden hi tried embedding a google books link in #fedwiki no luck?",
  "id" : 545482561779417088,
  "created_at" : "2014-12-18 07:35:51 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "democracy",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/NVS7qxtE4c",
      "expanded_url" : "http:\/\/gu.com\/p\/449vq\/tw",
      "display_url" : "gu.com\/p\/449vq\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "545329808373481472",
  "text" : "RT @josipa74: You thought you lived in a #democracy ? Queen was asked to intervene in Scots referendum amid yes vote fears http:\/\/t.co\/NVS7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "democracy",
        "indices" : [ 27, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/NVS7qxtE4c",
        "expanded_url" : "http:\/\/gu.com\/p\/449vq\/tw",
        "display_url" : "gu.com\/p\/449vq\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "545160300983779328",
    "text" : "You thought you lived in a #democracy ? Queen was asked to intervene in Scots referendum amid yes vote fears http:\/\/t.co\/NVS7qxtE4c",
    "id" : 545160300983779328,
    "created_at" : "2014-12-17 10:15:19 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 545329808373481472,
  "created_at" : "2014-12-17 21:28:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545160300983779328",
  "geo" : { },
  "id_str" : "545329621185884161",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 something else to remember at Queen xmas speech time :\/",
  "id" : 545329621185884161,
  "in_reply_to_status_id" : 545160300983779328,
  "created_at" : "2014-12-17 21:28:08 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/HReAWn4GZs",
      "expanded_url" : "http:\/\/tinysubversions.com\/contentForever\/",
      "display_url" : "tinysubversions.com\/contentForever\/"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HQPADMuT9L",
      "expanded_url" : "http:\/\/i.puthtml.com\/content_forever\/php86bCO1",
      "display_url" : "i.puthtml.com\/content_foreve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545307939456950272",
  "text" : "RT @tinysubversions: Content Forever now lets you share generated essays with others. http:\/\/t.co\/HReAWn4GZs\n\nNicki Minaj to polynomials: h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/HReAWn4GZs",
        "expanded_url" : "http:\/\/tinysubversions.com\/contentForever\/",
        "display_url" : "tinysubversions.com\/contentForever\/"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/HQPADMuT9L",
        "expanded_url" : "http:\/\/i.puthtml.com\/content_forever\/php86bCO1",
        "display_url" : "i.puthtml.com\/content_foreve\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "545235793330315264",
    "text" : "Content Forever now lets you share generated essays with others. http:\/\/t.co\/HReAWn4GZs\n\nNicki Minaj to polynomials: http:\/\/t.co\/HQPADMuT9L",
    "id" : 545235793330315264,
    "created_at" : "2014-12-17 15:15:17 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 545307939456950272,
  "created_at" : "2014-12-17 20:01:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545289054187958272",
  "geo" : { },
  "id_str" : "545301818742681600",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha It is interesting worth exploring collaboratively on #fedwiki :)",
  "id" : 545301818742681600,
  "in_reply_to_status_id" : 545289054187958272,
  "created_at" : "2014-12-17 19:37:39 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shut up, mike",
      "screen_name" : "shutupmikeginn",
      "indices" : [ 3, 18 ],
      "id_str" : "246394886",
      "id" : 246394886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545300827351818240",
  "text" : "RT @shutupmikeginn: I fucking LOVE science.\n\n*is handed peer reviewed journal*\n\nHaha nonono I meant CGI pictures of space with misattribute\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545291261695897601",
    "text" : "I fucking LOVE science.\n\n*is handed peer reviewed journal*\n\nHaha nonono I meant CGI pictures of space with misattributed quotes as captions",
    "id" : 545291261695897601,
    "created_at" : "2014-12-17 18:55:42 +0000",
    "user" : {
      "name" : "shut up, mike",
      "screen_name" : "shutupmikeginn",
      "protected" : false,
      "id_str" : "246394886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523668808020422656\/szD5CZyb_normal.jpeg",
      "id" : 246394886,
      "verified" : true
    }
  },
  "id" : 545300827351818240,
  "created_at" : "2014-12-17 19:33:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545269578981339136",
  "geo" : { },
  "id_str" : "545300712578908160",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim have a good one I may be lurking",
  "id" : 545300712578908160,
  "in_reply_to_status_id" : 545269578981339136,
  "created_at" : "2014-12-17 19:33:15 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ITshlDe0aO",
      "expanded_url" : "http:\/\/mura.uk.fedwikihappening.net\/view\/welcome-visitors\/view\/december-journal\/view\/learner-emotions",
      "display_url" : "mura.uk.fedwikihappening.net\/view\/welcome-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545244538328330241",
  "text" : "#fedwiki comment on learner emotions http:\/\/t.co\/ITshlDe0aO",
  "id" : 545244538328330241,
  "created_at" : "2014-12-17 15:50:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545243733080694784",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden hi sorry i just owned martin weller #fedwiki to see what happens following jeff's burning question can martin re-own it?",
  "id" : 545243733080694784,
  "created_at" : "2014-12-17 15:46:50 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545175125298278400",
  "geo" : { },
  "id_str" : "545190292723630080",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd Plenty of things to criticise Google from rational thinking as well :)",
  "id" : 545190292723630080,
  "in_reply_to_status_id" : 545175125298278400,
  "created_at" : "2014-12-17 12:14:29 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 3, 15 ],
      "id_str" : "142598896",
      "id" : 142598896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/28co3V3PEC",
      "expanded_url" : "http:\/\/bit.ly\/1A39ih1",
      "display_url" : "bit.ly\/1A39ih1"
    } ]
  },
  "geo" : { },
  "id_str" : "545140441331818496",
  "text" : "RT @Neil_Selwyn: New article: 'Why #edtech is full of bullshit ... and what might be done about it' - http:\/\/t.co\/28co3V3PEC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/28co3V3PEC",
        "expanded_url" : "http:\/\/bit.ly\/1A39ih1",
        "display_url" : "bit.ly\/1A39ih1"
      } ]
    },
    "geo" : { },
    "id_str" : "544828836555128832",
    "text" : "New article: 'Why #edtech is full of bullshit ... and what might be done about it' - http:\/\/t.co\/28co3V3PEC",
    "id" : 544828836555128832,
    "created_at" : "2014-12-16 12:18:11 +0000",
    "user" : {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "protected" : false,
      "id_str" : "142598896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726948956538728448\/nzGgydvr_normal.jpg",
      "id" : 142598896,
      "verified" : false
    }
  },
  "id" : 545140441331818496,
  "created_at" : "2014-12-17 08:56:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wRK89xoUS6",
      "expanded_url" : "http:\/\/2014trends.hackeducation.com\/indie.html",
      "display_url" : "2014trends.hackeducation.com\/indie.html"
    } ]
  },
  "geo" : { },
  "id_str" : "545108314666061824",
  "text" : "RT @audreywatters: Top Ed-Tech Trends of 2014: The Indie Web http:\/\/t.co\/wRK89xoUS6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/wRK89xoUS6",
        "expanded_url" : "http:\/\/2014trends.hackeducation.com\/indie.html",
        "display_url" : "2014trends.hackeducation.com\/indie.html"
      } ]
    },
    "geo" : { },
    "id_str" : "545101586536468480",
    "text" : "Top Ed-Tech Trends of 2014: The Indie Web http:\/\/t.co\/wRK89xoUS6",
    "id" : 545101586536468480,
    "created_at" : "2014-12-17 06:22:00 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 545108314666061824,
  "created_at" : "2014-12-17 06:48:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544968380554694656",
  "text" : "writing up class notes, decided not to change \"student initiation into Antconc\" :)",
  "id" : 544968380554694656,
  "created_at" : "2014-12-16 21:32:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Myles White",
      "screen_name" : "johnmyleswhite",
      "indices" : [ 0, 15 ],
      "id_str" : "15379361",
      "id" : 15379361
    }, {
      "name" : "Trey Causey \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDE80",
      "screen_name" : "treycausey",
      "indices" : [ 16, 27 ],
      "id_str" : "237254045",
      "id" : 237254045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544879379776823296",
  "geo" : { },
  "id_str" : "544881973143949313",
  "in_reply_to_user_id" : 15379361,
  "text" : "@johnmyleswhite @treycausey The tyranny of specialisation?",
  "id" : 544881973143949313,
  "in_reply_to_status_id" : 544879379776823296,
  "created_at" : "2014-12-16 15:49:20 +0000",
  "in_reply_to_screen_name" : "johnmyleswhite",
  "in_reply_to_user_id_str" : "15379361",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EncodeAnt",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tdQR7yhZFK",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#encodeant",
      "display_url" : "laurenceanthony.net\/software.html#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544880864954712064",
  "text" : "RT @antlabjp: More software updates! Today #EncodeAnt (1.1.0), my character encoding detection\/conversion tool, has been released: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EncodeAnt",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tdQR7yhZFK",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#encodeant",
        "display_url" : "laurenceanthony.net\/software.html#\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "544864589100646401",
    "text" : "More software updates! Today #EncodeAnt (1.1.0), my character encoding detection\/conversion tool, has been released: http:\/\/t.co\/tdQR7yhZFK",
    "id" : 544864589100646401,
    "created_at" : "2014-12-16 14:40:15 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 544880864954712064,
  "created_at" : "2014-12-16 15:44:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Echo Chamber",
      "screen_name" : "TheEchoChamber2",
      "indices" : [ 0, 16 ],
      "id_str" : "1440515702",
      "id" : 1440515702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544854580182646784",
  "geo" : { },
  "id_str" : "544855181012111360",
  "in_reply_to_user_id" : 1440515702,
  "text" : "@TheEchoChamber2 oh yeah doh, thx",
  "id" : 544855181012111360,
  "in_reply_to_status_id" : 544854580182646784,
  "created_at" : "2014-12-16 14:02:52 +0000",
  "in_reply_to_screen_name" : "TheEchoChamber2",
  "in_reply_to_user_id_str" : "1440515702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Echo Chamber",
      "screen_name" : "TheEchoChamber2",
      "indices" : [ 0, 16 ],
      "id_str" : "1440515702",
      "id" : 1440515702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544851276119687169",
  "in_reply_to_user_id" : 1440515702,
  "text" : "@TheEchoChamber2 hi how can i add my blog to yr google sheet? thx",
  "id" : 544851276119687169,
  "created_at" : "2014-12-16 13:47:21 +0000",
  "in_reply_to_screen_name" : "TheEchoChamber2",
  "in_reply_to_user_id_str" : "1440515702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 3, 14 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "ELTIreland",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/mE1dKUNAGg",
      "expanded_url" : "http:\/\/eaping.blogspot.ie\/2014\/12\/nominalisation_16.html",
      "display_url" : "eaping.blogspot.ie\/2014\/12\/nomina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544847076304388097",
  "text" : "RT @EAPstephen: Did up a lesson on nominalisation that might be of interest #tleap #eapchat #ELTIreland http:\/\/t.co\/mE1dKUNAGg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tleap",
        "indices" : [ 60, 66 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "ELTIreland",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/mE1dKUNAGg",
        "expanded_url" : "http:\/\/eaping.blogspot.ie\/2014\/12\/nominalisation_16.html",
        "display_url" : "eaping.blogspot.ie\/2014\/12\/nomina\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "544792430575616000",
    "text" : "Did up a lesson on nominalisation that might be of interest #tleap #eapchat #ELTIreland http:\/\/t.co\/mE1dKUNAGg",
    "id" : 544792430575616000,
    "created_at" : "2014-12-16 09:53:31 +0000",
    "user" : {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "protected" : false,
      "id_str" : "2717005711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541999119812681728\/dHDIC_gW_normal.jpeg",
      "id" : 2717005711,
      "verified" : false
    }
  },
  "id" : 544847076304388097,
  "created_at" : "2014-12-16 13:30:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 16, 25 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544835235477585920",
  "geo" : { },
  "id_str" : "544837230523850753",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan @whyshona got em now thx. best not to run afoul of copyright issues Geoff :\/",
  "id" : 544837230523850753,
  "in_reply_to_status_id" : 544835235477585920,
  "created_at" : "2014-12-16 12:51:33 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544832169836048384",
  "geo" : { },
  "id_str" : "544832947980103680",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard Rose I shared 3 refs with Russ which discussed relevancy to ELT back in 70s which are worth checking",
  "id" : 544832947980103680,
  "in_reply_to_status_id" : 544832169836048384,
  "created_at" : "2014-12-16 12:34:31 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 105, 114 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544828291182784512",
  "geo" : { },
  "id_str" : "544831895906045953",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan  Geoff cld u share the UG peeps \"repositioning\" article &amp; the response to this I saw @whyshona tweet sometime today?",
  "id" : 544831895906045953,
  "in_reply_to_status_id" : 544828291182784512,
  "created_at" : "2014-12-16 12:30:21 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544827495410044929",
  "geo" : { },
  "id_str" : "544829850067140609",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard ERM dunno necessary simplifications for masters study?",
  "id" : 544829850067140609,
  "in_reply_to_status_id" : 544827495410044929,
  "created_at" : "2014-12-16 12:22:13 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 7, 18 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 19, 32 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544747421755244544",
  "geo" : { },
  "id_str" : "544826234585509888",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @leoselivan @rosemerebard Hmm there has been a long history of debate over that so not sure what is being got away :)",
  "id" : 544826234585509888,
  "in_reply_to_status_id" : 544747421755244544,
  "created_at" : "2014-12-16 12:07:51 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 135, 140 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KI5mlwSY9H",
      "expanded_url" : "http:\/\/dailym.ai\/137MJuF",
      "display_url" : "dailym.ai\/137MJuF"
    } ]
  },
  "geo" : { },
  "id_str" : "544805600463683584",
  "text" : "RT @lovermob: Spoken BNC2014: Champagne and gin replace sherry and brandy as our favourite Christmas drinks http:\/\/t.co\/KI5mlwSY9H via @Mai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Mail Online",
        "screen_name" : "MailOnline",
        "indices" : [ 121, 132 ],
        "id_str" : "15438913",
        "id" : 15438913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/KI5mlwSY9H",
        "expanded_url" : "http:\/\/dailym.ai\/137MJuF",
        "display_url" : "dailym.ai\/137MJuF"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.0487398, -2.8024475 ]
    },
    "id_str" : "544772939976306688",
    "text" : "Spoken BNC2014: Champagne and gin replace sherry and brandy as our favourite Christmas drinks http:\/\/t.co\/KI5mlwSY9H via @MailOnline",
    "id" : 544772939976306688,
    "created_at" : "2014-12-16 08:36:04 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 544805600463683584,
  "created_at" : "2014-12-16 10:45:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/OvtuaeS5Jp",
      "expanded_url" : "http:\/\/2014trends.hackeducation.com\/data.html",
      "display_url" : "2014trends.hackeducation.com\/data.html"
    } ]
  },
  "geo" : { },
  "id_str" : "544742552885534720",
  "text" : "RT @audreywatters: Top Ed-Tech Trends of 2014: Data and Privacy http:\/\/t.co\/OvtuaeS5Jp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/OvtuaeS5Jp",
        "expanded_url" : "http:\/\/2014trends.hackeducation.com\/data.html",
        "display_url" : "2014trends.hackeducation.com\/data.html"
      } ]
    },
    "geo" : { },
    "id_str" : "544674228771901441",
    "text" : "Top Ed-Tech Trends of 2014: Data and Privacy http:\/\/t.co\/OvtuaeS5Jp",
    "id" : 544674228771901441,
    "created_at" : "2014-12-16 02:03:50 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 544742552885534720,
  "created_at" : "2014-12-16 06:35:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 7, 18 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 19, 32 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Stefania Spina",
      "screen_name" : "sspina",
      "indices" : [ 33, 40 ],
      "id_str" : "10975952",
      "id" : 10975952
    }, {
      "name" : "Aeon",
      "screen_name" : "aeonmag",
      "indices" : [ 41, 49 ],
      "id_str" : "481943972",
      "id" : 481943972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544608633255124992",
  "geo" : { },
  "id_str" : "544741948310171648",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @leoselivan @rosemerebard @sspina @aeonmag get away with what exactly?",
  "id" : 544741948310171648,
  "in_reply_to_status_id" : 544608633255124992,
  "created_at" : "2014-12-16 06:32:55 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linguistic Society",
      "screen_name" : "LingSocAm",
      "indices" : [ 3, 13 ],
      "id_str" : "103490228",
      "id" : 103490228
    }, {
      "name" : "Strong Language",
      "screen_name" : "stronglang",
      "indices" : [ 27, 38 ],
      "id_str" : "2918426355",
      "id" : 2918426355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/4K5flh5SDl",
      "expanded_url" : "http:\/\/stronglang.wordpress.com\/2014\/12\/13\/phonology-of-cusswords-some-initial-observations\/",
      "display_url" : "stronglang.wordpress.com\/2014\/12\/13\/pho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544598927228829696",
  "text" : "RT @LingSocAm: A new blog (@stronglang) is exploring the linguistics of swearing. Warning--strong language: http:\/\/t.co\/4K5flh5SDl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Strong Language",
        "screen_name" : "stronglang",
        "indices" : [ 12, 23 ],
        "id_str" : "2918426355",
        "id" : 2918426355
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/4K5flh5SDl",
        "expanded_url" : "http:\/\/stronglang.wordpress.com\/2014\/12\/13\/phonology-of-cusswords-some-initial-observations\/",
        "display_url" : "stronglang.wordpress.com\/2014\/12\/13\/pho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "544557660277059584",
    "text" : "A new blog (@stronglang) is exploring the linguistics of swearing. Warning--strong language: http:\/\/t.co\/4K5flh5SDl",
    "id" : 544557660277059584,
    "created_at" : "2014-12-15 18:20:38 +0000",
    "user" : {
      "name" : "Linguistic Society",
      "screen_name" : "LingSocAm",
      "protected" : false,
      "id_str" : "103490228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483990217745915904\/EY8gfWIC_normal.png",
      "id" : 103490228,
      "verified" : false
    }
  },
  "id" : 544598927228829696,
  "created_at" : "2014-12-15 21:04:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AntPConc",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0nAoMUWQMy",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "544597347939127296",
  "text" : "RT @antlabjp: #AntPConc, my freeware parallel corpus tool, has now been upgraded to version 1.1.0. Get it here: http:\/\/t.co\/0nAoMUWQMy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AntPConc",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/0nAoMUWQMy",
        "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
        "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "544595123703926786",
    "text" : "#AntPConc, my freeware parallel corpus tool, has now been upgraded to version 1.1.0. Get it here: http:\/\/t.co\/0nAoMUWQMy",
    "id" : 544595123703926786,
    "created_at" : "2014-12-15 20:49:30 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 544597347939127296,
  "created_at" : "2014-12-15 20:58:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544542689229045761",
  "text" : "ek @twitter still unfollowing people ramdomly",
  "id" : 544542689229045761,
  "created_at" : "2014-12-15 17:21:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/vL3FYpcC0w",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-121",
      "display_url" : "wp.me\/p3qkCB-121"
    } ]
  },
  "geo" : { },
  "id_str" : "544429981561278464",
  "text" : "RT @GeoffreyJordan: A Christmas Carol (with aplogies to C.\u00A0Dickens) http:\/\/t.co\/vL3FYpcC0w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/vL3FYpcC0w",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-121",
        "display_url" : "wp.me\/p3qkCB-121"
      } ]
    },
    "geo" : { },
    "id_str" : "544405109459783680",
    "text" : "A Christmas Carol (with aplogies to C.\u00A0Dickens) http:\/\/t.co\/vL3FYpcC0w",
    "id" : 544405109459783680,
    "created_at" : "2014-12-15 08:14:27 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 544429981561278464,
  "created_at" : "2014-12-15 09:53:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/g1LwmyvKnh",
      "expanded_url" : "https:\/\/m.repository.library.georgetown.edu\/bitstream\/handle\/10822\/555462\/GURT_1969.pdf?sequence=1#page=159",
      "display_url" : "m.repository.library.georgetown.edu\/bitstream\/hand\u2026"
    }, {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/GoJGlrPf28",
      "expanded_url" : "http:\/\/deepblue.lib.umich.edu\/bitstream\/handle\/2027.42\/98351\/j.1467-1770.1970.tb00048.x.pdf?sequence=1&isAllowed=y",
      "display_url" : "deepblue.lib.umich.edu\/bitstream\/hand\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RBVZKUb9Ef",
      "expanded_url" : "http:\/\/deepblue.lib.umich.edu\/bitstream\/handle\/2027.42\/98173\/j.1467-1770.1969.tb00467.x.pdf?sequence=1",
      "display_url" : "deepblue.lib.umich.edu\/bitstream\/hand\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "544396819292516352",
  "geo" : { },
  "id_str" : "544429857766375425",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl these refs may help Spolsky(1970) https:\/\/t.co\/g1LwmyvKnh Krohn (1970)http:\/\/t.co\/GoJGlrPf28 Lamendella(1969)http:\/\/t.co\/RBVZKUb9Ef",
  "id" : 544429857766375425,
  "in_reply_to_status_id" : 544396819292516352,
  "created_at" : "2014-12-15 09:52:47 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/K72Dl7qbg5",
      "expanded_url" : "http:\/\/stager.tv\/blog\/?p=3429",
      "display_url" : "stager.tv\/blog\/?p=3429"
    } ]
  },
  "geo" : { },
  "id_str" : "544254211320320000",
  "text" : "The Troubling Optics Behind the President Learning to Code http:\/\/t.co\/K72Dl7qbg5",
  "id" : 544254211320320000,
  "created_at" : "2014-12-14 22:14:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "indices" : [ 0, 10 ],
      "id_str" : "533509442",
      "id" : 533509442
    }, {
      "name" : "Metro",
      "screen_name" : "MetroUK",
      "indices" : [ 11, 19 ],
      "id_str" : "138749160",
      "id" : 138749160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/0nimXJlrnC",
      "expanded_url" : "https:\/\/plus.google.com\/106046905226018860662\/posts\/WRePb79fpJX",
      "display_url" : "plus.google.com\/10604690522601\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "543530937263595520",
  "geo" : { },
  "id_str" : "543791629300408320",
  "in_reply_to_user_id" : 533509442,
  "text" : "@JessFrye1 @MetroUK yougov have the crappest polls https:\/\/t.co\/0nimXJlrnC",
  "id" : 543791629300408320,
  "in_reply_to_status_id" : 543530937263595520,
  "created_at" : "2014-12-13 15:36:42 +0000",
  "in_reply_to_screen_name" : "JessFrye1",
  "in_reply_to_user_id_str" : "533509442",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543467586097131520",
  "geo" : { },
  "id_str" : "543495408815972352",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS yep and nope :) unless u count parks, libraries and general kids activities :\/",
  "id" : 543495408815972352,
  "in_reply_to_status_id" : 543467586097131520,
  "created_at" : "2014-12-12 19:59:37 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543465788527894528",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS cheers for RT have a good w\/e :)",
  "id" : 543465788527894528,
  "created_at" : "2014-12-12 18:01:55 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 3, 12 ],
      "id_str" : "6257282",
      "id" : 6257282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/fHOwx1Zn9d",
      "expanded_url" : "http:\/\/j.mp\/1sdv3Kd",
      "display_url" : "j.mp\/1sdv3Kd"
    } ]
  },
  "geo" : { },
  "id_str" : "543465690712506368",
  "text" : "RT @trieloff: Innovation: The Government Was Crucial After All by Jeff Madrick http:\/\/t.co\/fHOwx1Zn9d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/fHOwx1Zn9d",
        "expanded_url" : "http:\/\/j.mp\/1sdv3Kd",
        "display_url" : "j.mp\/1sdv3Kd"
      } ]
    },
    "geo" : { },
    "id_str" : "543435318742224896",
    "text" : "Innovation: The Government Was Crucial After All by Jeff Madrick http:\/\/t.co\/fHOwx1Zn9d",
    "id" : 543435318742224896,
    "created_at" : "2014-12-12 16:00:51 +0000",
    "user" : {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "protected" : false,
      "id_str" : "6257282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708651245561585664\/6xwsfP4M_normal.jpg",
      "id" : 6257282,
      "verified" : false
    }
  },
  "id" : 543465690712506368,
  "created_at" : "2014-12-12 18:01:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loic Le Meur",
      "screen_name" : "loic",
      "indices" : [ 0, 5 ],
      "id_str" : "740983",
      "id" : 740983
    }, {
      "name" : "Emmanuel Macron",
      "screen_name" : "EmmanuelMacron",
      "indices" : [ 6, 21 ],
      "id_str" : "1976143068",
      "id" : 1976143068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/mda7FRm5yD",
      "expanded_url" : "http:\/\/www.nybooks.com\/articles\/archives\/2014\/apr\/24\/innovation-government-was-crucial-after-all\/",
      "display_url" : "nybooks.com\/articles\/archi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "543088089691070464",
  "geo" : { },
  "id_str" : "543441559317123073",
  "in_reply_to_user_id" : 18602422,
  "text" : "@loic @EmmanuelMacron .claims..entrepreneurs &amp; venture capitalists...more averse to risks than government researchers http:\/\/t.co\/mda7FRm5yD",
  "id" : 543441559317123073,
  "in_reply_to_status_id" : 543088089691070464,
  "created_at" : "2014-12-12 16:25:39 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/vm7yKXLd5m",
      "expanded_url" : "http:\/\/bsnews.info\/russell-brand-snide-channel-4-news\/",
      "display_url" : "bsnews.info\/russell-brand-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543402699153088512",
  "text" : "Russell Brand and the \u2018Snide\u2019 from Channel 4 News: http:\/\/t.co\/vm7yKXLd5m",
  "id" : 543402699153088512,
  "created_at" : "2014-12-12 13:51:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 94, 98 ]
    }, {
      "text" : "tefl",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/iHc1jq3SSV",
      "expanded_url" : "http:\/\/goo.gl\/OpVNQu",
      "display_url" : "goo.gl\/OpVNQu"
    } ]
  },
  "geo" : { },
  "id_str" : "543379682742525953",
  "text" : "RT @josipa74: Are we just expected to read Shakespeare and Milton while our teeth fall out\u2026.? #elt #tefl #IATEFL http:\/\/t.co\/iHc1jq3SSV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "tefl",
        "indices" : [ 85, 90 ]
      }, {
        "text" : "IATEFL",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/iHc1jq3SSV",
        "expanded_url" : "http:\/\/goo.gl\/OpVNQu",
        "display_url" : "goo.gl\/OpVNQu"
      } ]
    },
    "geo" : { },
    "id_str" : "543209308100755456",
    "text" : "Are we just expected to read Shakespeare and Milton while our teeth fall out\u2026.? #elt #tefl #IATEFL http:\/\/t.co\/iHc1jq3SSV",
    "id" : 543209308100755456,
    "created_at" : "2014-12-12 01:02:46 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 543379682742525953,
  "created_at" : "2014-12-12 12:19:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giulio Sica",
      "screen_name" : "SicaGiulio",
      "indices" : [ 84, 95 ],
      "id_str" : "380588731",
      "id" : 380588731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/PFn0LmpSuD",
      "expanded_url" : "http:\/\/wp.me\/p1SCx0-8v",
      "display_url" : "wp.me\/p1SCx0-8v"
    } ]
  },
  "geo" : { },
  "id_str" : "543373247908020225",
  "text" : "Russell Brand battles through a rigged BBC Question Time http:\/\/t.co\/PFn0LmpSuD via @SicaGiulio",
  "id" : 543373247908020225,
  "created_at" : "2014-12-12 11:54:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Greaves",
      "screen_name" : "PhilGreaves01",
      "indices" : [ 3, 17 ],
      "id_str" : "852483272",
      "id" : 852483272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543167600130539521",
  "text" : "RT @PhilGreaves01: Has a single pundit or commentator, let alone a \"humanitarian NGO\", called for US regime change, prosecution, following \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542610178802475008",
    "text" : "Has a single pundit or commentator, let alone a \"humanitarian NGO\", called for US regime change, prosecution, following this torture report?",
    "id" : 542610178802475008,
    "created_at" : "2014-12-10 09:22:02 +0000",
    "user" : {
      "name" : "Phil Greaves",
      "screen_name" : "PhilGreaves01",
      "protected" : false,
      "id_str" : "852483272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434044970274545664\/qp8Dfa4w_normal.jpeg",
      "id" : 852483272,
      "verified" : false
    }
  },
  "id" : 543167600130539521,
  "created_at" : "2014-12-11 22:17:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loic Le Meur",
      "screen_name" : "loic",
      "indices" : [ 0, 5 ],
      "id_str" : "740983",
      "id" : 740983
    }, {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "indices" : [ 6, 14 ],
      "id_str" : "236921161",
      "id" : 236921161
    }, {
      "name" : "Emmanuel Macron",
      "screen_name" : "EmmanuelMacron",
      "indices" : [ 15, 30 ],
      "id_str" : "1976143068",
      "id" : 1976143068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543030969461002243",
  "geo" : { },
  "id_str" : "543088089691070464",
  "in_reply_to_user_id" : 740983,
  "text" : "@loic @wordtov @EmmanuelMacron hope is he using efficient like efficace when talking about education...",
  "id" : 543088089691070464,
  "in_reply_to_status_id" : 543030969461002243,
  "created_at" : "2014-12-11 17:01:05 +0000",
  "in_reply_to_screen_name" : "loic",
  "in_reply_to_user_id_str" : "740983",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "23cose in biblioteca",
      "screen_name" : "23cose",
      "indices" : [ 0, 7 ],
      "id_str" : "873567180",
      "id" : 873567180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543076916849565696",
  "in_reply_to_user_id" : 873567180,
  "text" : "@23cose thanks for RT :)",
  "id" : 543076916849565696,
  "created_at" : "2014-12-11 16:16:41 +0000",
  "in_reply_to_screen_name" : "23cose",
  "in_reply_to_user_id_str" : "873567180",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nilocram",
      "screen_name" : "nilocram",
      "indices" : [ 0, 9 ],
      "id_str" : "40545323",
      "id" : 40545323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543074512410247169",
  "in_reply_to_user_id" : 40545323,
  "text" : "@nilocram grazie per RT :)",
  "id" : 543074512410247169,
  "created_at" : "2014-12-11 16:07:08 +0000",
  "in_reply_to_screen_name" : "nilocram",
  "in_reply_to_user_id_str" : "40545323",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliott",
      "screen_name" : "elliotthoey",
      "indices" : [ 3, 15 ],
      "id_str" : "68114505",
      "id" : 68114505
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 71, 79 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/njkrEUO16s",
      "expanded_url" : "http:\/\/xkcd.com\/1458\/",
      "display_url" : "xkcd.com\/1458\/"
    } ]
  },
  "geo" : { },
  "id_str" : "543021834145632256",
  "text" : "RT @elliotthoey: Category Wars: Episode VIII http:\/\/t.co\/njkrEUO16s cc @grvsmth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angus B Grieve-Smith",
        "screen_name" : "grvsmth",
        "indices" : [ 54, 62 ],
        "id_str" : "22381639",
        "id" : 22381639
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/njkrEUO16s",
        "expanded_url" : "http:\/\/xkcd.com\/1458\/",
        "display_url" : "xkcd.com\/1458\/"
      } ]
    },
    "geo" : { },
    "id_str" : "542601801917538305",
    "text" : "Category Wars: Episode VIII http:\/\/t.co\/njkrEUO16s cc @grvsmth",
    "id" : 542601801917538305,
    "created_at" : "2014-12-10 08:48:45 +0000",
    "user" : {
      "name" : "Elliott",
      "screen_name" : "elliotthoey",
      "protected" : false,
      "id_str" : "68114505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464491275014520832\/ZVKw2en8_normal.jpeg",
      "id" : 68114505,
      "verified" : false
    }
  },
  "id" : 543021834145632256,
  "created_at" : "2014-12-11 12:37:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Lang Brigade",
      "screen_name" : "AngryLang",
      "indices" : [ 3, 13 ],
      "id_str" : "2884842179",
      "id" : 2884842179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEFL",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "Dublin",
      "indices" : [ 45, 52 ]
    }, {
      "text" : "Union",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QSVdJXH8WN",
      "expanded_url" : "http:\/\/libcom.org\/blog\/%E2%80%9Cevery-action-was-done-collectively%E2%80%9D-interview-newly-unionised-tefl-workers-01122014",
      "display_url" : "libcom.org\/blog\/%E2%80%9C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543018858391818241",
  "text" : "RT @AngryLang: Interview with #TEFL staff in #Dublin who formed a #Union, threatened strike action and successfully beat a pay cut! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEFL",
        "indices" : [ 15, 20 ]
      }, {
        "text" : "Dublin",
        "indices" : [ 30, 37 ]
      }, {
        "text" : "Union",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/QSVdJXH8WN",
        "expanded_url" : "http:\/\/libcom.org\/blog\/%E2%80%9Cevery-action-was-done-collectively%E2%80%9D-interview-newly-unionised-tefl-workers-01122014",
        "display_url" : "libcom.org\/blog\/%E2%80%9C\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542022189617516544",
    "text" : "Interview with #TEFL staff in #Dublin who formed a #Union, threatened strike action and successfully beat a pay cut! http:\/\/t.co\/QSVdJXH8WN",
    "id" : 542022189617516544,
    "created_at" : "2014-12-08 18:25:34 +0000",
    "user" : {
      "name" : "Angry Lang Brigade",
      "screen_name" : "AngryLang",
      "protected" : false,
      "id_str" : "2884842179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535189951030128640\/twZwKnDQ_normal.jpeg",
      "id" : 2884842179,
      "verified" : false
    }
  },
  "id" : 543018858391818241,
  "created_at" : "2014-12-11 12:25:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542967100806270976",
  "geo" : { },
  "id_str" : "542969211392647168",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo Nice :) congratulations!",
  "id" : 542969211392647168,
  "in_reply_to_status_id" : 542967100806270976,
  "created_at" : "2014-12-11 09:08:42 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/RfrbrVXysJ",
      "expanded_url" : "http:\/\/youtu.be\/JduqBw2jIbo",
      "display_url" : "youtu.be\/JduqBw2jIbo"
    } ]
  },
  "geo" : { },
  "id_str" : "542966894718750720",
  "text" : "Russell Brand's Revolution: Interview with Owen Jones - Full Length | Gu...: http:\/\/t.co\/RfrbrVXysJ via @YouTube",
  "id" : 542966894718750720,
  "created_at" : "2014-12-11 08:59:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 3, 14 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 99, 105 ]
    }, {
      "text" : "EAPChat",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/UltEb09H5Y",
      "expanded_url" : "http:\/\/jenmacdonald.wordpress.com\/2014\/12\/11\/teaching-essay-writing-in-pyongyang\/",
      "display_url" : "jenmacdonald.wordpress.com\/2014\/12\/11\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542959895977680896",
  "text" : "RT @JenMac_ESL: Teaching essays in Pyongyang--not that big of a deal, IMHO. http:\/\/t.co\/UltEb09H5Y #tleap #EAPChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tleap",
        "indices" : [ 83, 89 ]
      }, {
        "text" : "EAPChat",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/UltEb09H5Y",
        "expanded_url" : "http:\/\/jenmacdonald.wordpress.com\/2014\/12\/11\/teaching-essay-writing-in-pyongyang\/",
        "display_url" : "jenmacdonald.wordpress.com\/2014\/12\/11\/tea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542856824127762434",
    "text" : "Teaching essays in Pyongyang--not that big of a deal, IMHO. http:\/\/t.co\/UltEb09H5Y #tleap #EAPChat",
    "id" : 542856824127762434,
    "created_at" : "2014-12-11 01:42:07 +0000",
    "user" : {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "protected" : false,
      "id_str" : "608800026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450682476781129728\/SBKeLuvN_normal.jpeg",
      "id" : 608800026,
      "verified" : false
    }
  },
  "id" : 542959895977680896,
  "created_at" : "2014-12-11 08:31:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542804822639251459",
  "geo" : { },
  "id_str" : "542805856577159168",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech um i dont think so, sounds odd without where no?",
  "id" : 542805856577159168,
  "in_reply_to_status_id" : 542804822639251459,
  "created_at" : "2014-12-10 22:19:35 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 105, 115 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hourofcode",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "bandwagon",
      "indices" : [ 71, 81 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "piratebox",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/fh2K7q6X1J",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Rq",
      "display_url" : "wp.me\/pgHyE-Rq"
    } ]
  },
  "geo" : { },
  "id_str" : "542799747203887105",
  "text" : "The browser rulez or another reason why PirateBox is boss. #hourofcode #bandwagon #eltchat #piratebox cc @ELTMAKERS http:\/\/t.co\/fh2K7q6X1J",
  "id" : 542799747203887105,
  "created_at" : "2014-12-10 21:55:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 11, 24 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542765949892689922",
  "text" : "@_FTaylor_ @RobertASzabo  Atlantic heavily funded by Gates foundation apparently...",
  "id" : 542765949892689922,
  "created_at" : "2014-12-10 19:41:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/s8NUy7VLq8",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1418154892.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542452244675702785",
  "text" : "Snowmail: US torture \"Just how bad was it?\"...short email to Six Pilgers...http:\/\/t.co\/s8NUy7VLq8",
  "id" : 542452244675702785,
  "created_at" : "2014-12-09 22:54:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/5fB94GXbaQ",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/2014\/12\/09\/live-coverage-release-senate-torture-report#Psychologists",
      "display_url" : "firstlook.org\/theintercept\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542383788161265664",
  "text" : "RT @ggreenwald: Psychologists played a crucial role in helping CIA torture, then profited from $81 million in contracts  https:\/\/t.co\/5fB94\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/5fB94GXbaQ",
        "expanded_url" : "https:\/\/firstlook.org\/theintercept\/2014\/12\/09\/live-coverage-release-senate-torture-report#Psychologists",
        "display_url" : "firstlook.org\/theintercept\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542369501858496512",
    "text" : "Psychologists played a crucial role in helping CIA torture, then profited from $81 million in contracts  https:\/\/t.co\/5fB94GXbaQ",
    "id" : 542369501858496512,
    "created_at" : "2014-12-09 17:25:40 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 542383788161265664,
  "created_at" : "2014-12-09 18:22:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonna L.",
      "screen_name" : "ediTransla",
      "indices" : [ 0, 11 ],
      "id_str" : "2375548591",
      "id" : 2375548591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542303429650300928",
  "in_reply_to_user_id" : 2375548591,
  "text" : "@ediTransla hi thx for RT :)",
  "id" : 542303429650300928,
  "created_at" : "2014-12-09 13:03:07 +0000",
  "in_reply_to_screen_name" : "ediTransla",
  "in_reply_to_user_id_str" : "2375548591",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 3, 12 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/ndCydj5T5a",
      "expanded_url" : "http:\/\/universiteenruines.tumblr.com\/",
      "display_url" : "universiteenruines.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "542239523934322688",
  "text" : "RT @whyshona: Ruines d'Universit\u00E9 http:\/\/t.co\/ndCydj5T5a Come study in France ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/ndCydj5T5a",
        "expanded_url" : "http:\/\/universiteenruines.tumblr.com\/",
        "display_url" : "universiteenruines.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "542238077880508416",
    "text" : "Ruines d'Universit\u00E9 http:\/\/t.co\/ndCydj5T5a Come study in France ...",
    "id" : 542238077880508416,
    "created_at" : "2014-12-09 08:43:26 +0000",
    "user" : {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "protected" : false,
      "id_str" : "121063600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459074158974889984\/nMzMr6_1_normal.jpeg",
      "id" : 121063600,
      "verified" : false
    }
  },
  "id" : 542239523934322688,
  "created_at" : "2014-12-09 08:49:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aral\/status\/542070346200154112\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/wdgmyDgkvb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XSGmbIAAIWnyJ.jpg",
      "id_str" : "542070341003378690",
      "id" : 542070341003378690,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XSGmbIAAIWnyJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/wdgmyDgkvb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/2WBfjdRXAy",
      "expanded_url" : "http:\/\/www.independent.co.uk\/life-style\/gadgets-and-tech\/news\/fears-for-children-as-google-targets-under13s-9907313.html",
      "display_url" : "independent.co.uk\/life-style\/gad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542206098133233664",
  "text" : "RT @aral: Google targets children\u2026  or \u201Cadorable innocent little bundles of data\u201D as they call them.\n\nhttp:\/\/t.co\/2WBfjdRXAy http:\/\/t.co\/wd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aral\/status\/542070346200154112\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/wdgmyDgkvb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XSGmbIAAIWnyJ.jpg",
        "id_str" : "542070341003378690",
        "id" : 542070341003378690,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XSGmbIAAIWnyJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/wdgmyDgkvb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/2WBfjdRXAy",
        "expanded_url" : "http:\/\/www.independent.co.uk\/life-style\/gadgets-and-tech\/news\/fears-for-children-as-google-targets-under13s-9907313.html",
        "display_url" : "independent.co.uk\/life-style\/gad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542070346200154112",
    "text" : "Google targets children\u2026  or \u201Cadorable innocent little bundles of data\u201D as they call them.\n\nhttp:\/\/t.co\/2WBfjdRXAy http:\/\/t.co\/wdgmyDgkvb",
    "id" : 542070346200154112,
    "created_at" : "2014-12-08 21:36:56 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 542206098133233664,
  "created_at" : "2014-12-09 06:36:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "culturematters",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/IE7glqQ26y",
      "expanded_url" : "http:\/\/ielanguages.com\/blog\/wp-content\/uploads\/2014\/12\/20141204_115300.jpg",
      "display_url" : "ielanguages.com\/blog\/wp-conten\u2026"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/nfIy3fajCY",
      "expanded_url" : "http:\/\/ielanguages.com\/blog\/asfs-2014\/",
      "display_url" : "ielanguages.com\/blog\/asfs-2014\/"
    } ]
  },
  "geo" : { },
  "id_str" : "542192427231375364",
  "text" : "interesting analysis of French learners debate style conversations http:\/\/t.co\/IE7glqQ26y h\/t http:\/\/t.co\/nfIy3fajCY #culturematters",
  "id" : 542192427231375364,
  "created_at" : "2014-12-09 05:42:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    }, {
      "name" : "GeorgeMonbiot",
      "screen_name" : "GeorgeMonbiot",
      "indices" : [ 25, 39 ],
      "id_str" : "198584761",
      "id" : 198584761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/HknWomxQTL",
      "expanded_url" : "http:\/\/shar.es\/13pwLs",
      "display_url" : "shar.es\/13pwLs"
    } ]
  },
  "geo" : { },
  "id_str" : "542085928328892417",
  "text" : "RT @Jonathan_K_Cook: Why @GeorgeMonbiot is a fatally compromised critic of power | Jonathan Cook's Blog http:\/\/t.co\/HknWomxQTL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeorgeMonbiot",
        "screen_name" : "GeorgeMonbiot",
        "indices" : [ 4, 18 ],
        "id_str" : "198584761",
        "id" : 198584761
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/HknWomxQTL",
        "expanded_url" : "http:\/\/shar.es\/13pwLs",
        "display_url" : "shar.es\/13pwLs"
      } ]
    },
    "geo" : { },
    "id_str" : "541886412174262272",
    "text" : "Why @GeorgeMonbiot is a fatally compromised critic of power | Jonathan Cook's Blog http:\/\/t.co\/HknWomxQTL",
    "id" : 541886412174262272,
    "created_at" : "2014-12-08 09:26:03 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 542085928328892417,
  "created_at" : "2014-12-08 22:38:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 3, 13 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ELTMAKERS\/status\/542058802062041088\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/x8Bq92PSn7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XHm5eIUAA83Hp.png",
      "id_str" : "542058801244164096",
      "id" : 542058801244164096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XHm5eIUAA83Hp.png",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x8Bq92PSn7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/EcaReNh42W",
      "expanded_url" : "http:\/\/eltmakespace.blogspot.ie\/2014\/12\/a-positive-pronunciation-resource.html",
      "display_url" : "eltmakespace.blogspot.ie\/2014\/12\/a-posi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542060631894282241",
  "text" : "RT @ELTMAKERS: Made a phonemic chart http:\/\/t.co\/EcaReNh42W http:\/\/t.co\/x8Bq92PSn7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ELTMAKERS\/status\/542058802062041088\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/x8Bq92PSn7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XHm5eIUAA83Hp.png",
        "id_str" : "542058801244164096",
        "id" : 542058801244164096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XHm5eIUAA83Hp.png",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x8Bq92PSn7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/EcaReNh42W",
        "expanded_url" : "http:\/\/eltmakespace.blogspot.ie\/2014\/12\/a-positive-pronunciation-resource.html",
        "display_url" : "eltmakespace.blogspot.ie\/2014\/12\/a-posi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542058802062041088",
    "text" : "Made a phonemic chart http:\/\/t.co\/EcaReNh42W http:\/\/t.co\/x8Bq92PSn7",
    "id" : 542058802062041088,
    "created_at" : "2014-12-08 20:51:04 +0000",
    "user" : {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "protected" : false,
      "id_str" : "2894570578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537944364534611969\/BegFDTeR_normal.png",
      "id" : 2894570578,
      "verified" : false
    }
  },
  "id" : 542060631894282241,
  "created_at" : "2014-12-08 20:58:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 29, 38 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 69, 81 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Israel",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "Gaza",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/pbpBiiR3l9",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/782-grievous-censorship-by-the-guardian-israel-gaza-and-the-termination-of-nafeez-ahmed-s-blog.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542044232849301504",
  "text" : "RT @medialens: What explains @guardian's sudden decision to kill off @NafeezAhmed's blog? 'This far, and no further.' #Israel #Gaza http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 14, 23 ],
        "id_str" : "87818409",
        "id" : 87818409
      }, {
        "name" : "Dr Nafeez Ahmed",
        "screen_name" : "NafeezAhmed",
        "indices" : [ 54, 66 ],
        "id_str" : "110692399",
        "id" : 110692399
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Israel",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "Gaza",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/pbpBiiR3l9",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/782-grievous-censorship-by-the-guardian-israel-gaza-and-the-termination-of-nafeez-ahmed-s-blog.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541977611862540289",
    "text" : "What explains @guardian's sudden decision to kill off @NafeezAhmed's blog? 'This far, and no further.' #Israel #Gaza http:\/\/t.co\/pbpBiiR3l9",
    "id" : 541977611862540289,
    "created_at" : "2014-12-08 15:28:26 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 542044232849301504,
  "created_at" : "2014-12-08 19:53:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "indices" : [ 3, 14 ],
      "id_str" : "13498092",
      "id" : 13498092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/6kVrH18e6d",
      "expanded_url" : "http:\/\/tefl.posthaven.com\/such-a-good-video-on-our-health-and-computers",
      "display_url" : "tefl.posthaven.com\/such-a-good-vi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541995975574044674",
  "text" : "RT @rogerdupuy: Such a good video on our health and computers http:\/\/t.co\/6kVrH18e6d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/posthaven.com\" rel=\"nofollow\"\u003EPosthaven\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/6kVrH18e6d",
        "expanded_url" : "http:\/\/tefl.posthaven.com\/such-a-good-video-on-our-health-and-computers",
        "display_url" : "tefl.posthaven.com\/such-a-good-vi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541994896832610304",
    "text" : "Such a good video on our health and computers http:\/\/t.co\/6kVrH18e6d",
    "id" : 541994896832610304,
    "created_at" : "2014-12-08 16:37:07 +0000",
    "user" : {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "protected" : false,
      "id_str" : "13498092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708559032143912960\/gINmiTzD_normal.jpg",
      "id" : 13498092,
      "verified" : false
    }
  },
  "id" : 541995975574044674,
  "created_at" : "2014-12-08 16:41:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 3, 15 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    }, {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 139, 140 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2JF9Rfg6M1",
      "expanded_url" : "http:\/\/theconversation.com\/dewani-case-was-catnip-to-a-homophobic-section-of-media-still-obsessed-with-gay-sex-35225",
      "display_url" : "theconversation.com\/dewani-case-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541995941600186369",
  "text" : "RT @_paulbaker_: Little piece in The Conversation by me on media reporting around homosexuality in the Dewani case http:\/\/t.co\/2JF9Rfg6M1 v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Conversation",
        "screen_name" : "ConversationUK",
        "indices" : [ 125, 140 ],
        "id_str" : "1241258612",
        "id" : 1241258612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/2JF9Rfg6M1",
        "expanded_url" : "http:\/\/theconversation.com\/dewani-case-was-catnip-to-a-homophobic-section-of-media-still-obsessed-with-gay-sex-35225",
        "display_url" : "theconversation.com\/dewani-case-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541989301374824448",
    "text" : "Little piece in The Conversation by me on media reporting around homosexuality in the Dewani case http:\/\/t.co\/2JF9Rfg6M1 via @ConversationUK",
    "id" : 541989301374824448,
    "created_at" : "2014-12-08 16:14:53 +0000",
    "user" : {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "protected" : false,
      "id_str" : "1026683874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497037570787004416\/6ehsw-Ol_normal.jpeg",
      "id" : 1026683874,
      "verified" : false
    }
  },
  "id" : 541995941600186369,
  "created_at" : "2014-12-08 16:41:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/kFO8zXh5I5",
      "expanded_url" : "https:\/\/aralbalkan.com\/notes\/the-camera-panopticon\/",
      "display_url" : "aralbalkan.com\/notes\/the-came\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541931277117820928",
  "text" : "RT @aral: What do mirrors, Mayans, and quantum computers have to do with the future of humanity?\n\nThe Camera Panopticon\n\nhttps:\/\/t.co\/kFO8z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/kFO8zXh5I5",
        "expanded_url" : "https:\/\/aralbalkan.com\/notes\/the-camera-panopticon\/",
        "display_url" : "aralbalkan.com\/notes\/the-came\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541689647412551681",
    "text" : "What do mirrors, Mayans, and quantum computers have to do with the future of humanity?\n\nThe Camera Panopticon\n\nhttps:\/\/t.co\/kFO8zXh5I5",
    "id" : 541689647412551681,
    "created_at" : "2014-12-07 20:24:10 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 541931277117820928,
  "created_at" : "2014-12-08 12:24:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CELTA",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "CertTESOL",
      "indices" : [ 78, 88 ]
    }, {
      "text" : "elt",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "FutureofELT",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541913852884291585",
  "text" : "RT @josipa74: What 1 thing would you change about our qualifications #CELTA + #CertTESOL?  #elt #FutureofELT Comment and RT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CELTA",
        "indices" : [ 55, 61 ]
      }, {
        "text" : "CertTESOL",
        "indices" : [ 64, 74 ]
      }, {
        "text" : "elt",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "FutureofELT",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "541913399148675072",
    "text" : "What 1 thing would you change about our qualifications #CELTA + #CertTESOL?  #elt #FutureofELT Comment and RT!",
    "id" : 541913399148675072,
    "created_at" : "2014-12-08 11:13:17 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 541913852884291585,
  "created_at" : "2014-12-08 11:15:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 3, 16 ],
      "id_str" : "20932918",
      "id" : 20932918
    }, {
      "name" : "Socialist Worker",
      "screen_name" : "SocialistViews",
      "indices" : [ 42, 57 ],
      "id_str" : "35787985",
      "id" : 35787985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ejg9K6JlqV",
      "expanded_url" : "http:\/\/socwrk.org\/25888",
      "display_url" : "socwrk.org\/25888"
    } ]
  },
  "geo" : { },
  "id_str" : "541911691702071296",
  "text" : "RT @blairteacher: How Kaplan teachers won @SocialistViews http:\/\/t.co\/ejg9K6JlqV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Socialist Worker",
        "screen_name" : "SocialistViews",
        "indices" : [ 24, 39 ],
        "id_str" : "35787985",
        "id" : 35787985
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/ejg9K6JlqV",
        "expanded_url" : "http:\/\/socwrk.org\/25888",
        "display_url" : "socwrk.org\/25888"
      } ]
    },
    "geo" : { },
    "id_str" : "541910982235131904",
    "text" : "How Kaplan teachers won @SocialistViews http:\/\/t.co\/ejg9K6JlqV",
    "id" : 541910982235131904,
    "created_at" : "2014-12-08 11:03:41 +0000",
    "user" : {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "protected" : false,
      "id_str" : "20932918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473405104729493504\/mK908m7N_normal.jpeg",
      "id" : 20932918,
      "verified" : false
    }
  },
  "id" : 541911691702071296,
  "created_at" : "2014-12-08 11:06:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/S7Sdp7FA2k",
      "expanded_url" : "http:\/\/youtu.be\/YhcPX1wVp38",
      "display_url" : "youtu.be\/YhcPX1wVp38"
    } ]
  },
  "geo" : { },
  "id_str" : "541907507090706432",
  "text" : "A revolutionary Bio-Optically Organised Knowledge centre http:\/\/t.co\/S7Sdp7FA2k via @YouTube :)",
  "id" : 541907507090706432,
  "created_at" : "2014-12-08 10:49:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Hamilton",
      "screen_name" : "hamilton_wm",
      "indices" : [ 3, 15 ],
      "id_str" : "2765103707",
      "id" : 2765103707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/fsjkw26fjE",
      "expanded_url" : "http:\/\/www.partyofwales.org\/the-slate\/2014\/12\/04\/leanne-wood-speech-on-the-far-right\/?force=1",
      "display_url" : "partyofwales.org\/the-slate\/2014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541712093708578816",
  "text" : "RT @hamilton_wm: Leanne Wood speech on the far right ie WM and others. Leanne in great form articulating vision for Wales and UK http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/fsjkw26fjE",
        "expanded_url" : "http:\/\/www.partyofwales.org\/the-slate\/2014\/12\/04\/leanne-wood-speech-on-the-far-right\/?force=1",
        "display_url" : "partyofwales.org\/the-slate\/2014\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541639222642606080",
    "text" : "Leanne Wood speech on the far right ie WM and others. Leanne in great form articulating vision for Wales and UK http:\/\/t.co\/fsjkw26fjE",
    "id" : 541639222642606080,
    "created_at" : "2014-12-07 17:03:48 +0000",
    "user" : {
      "name" : "William Hamilton",
      "screen_name" : "hamilton_wm",
      "protected" : false,
      "id_str" : "2765103707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512364398091182081\/YHd5BcTZ_normal.jpeg",
      "id" : 2765103707,
      "verified" : false
    }
  },
  "id" : 541712093708578816,
  "created_at" : "2014-12-07 21:53:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/rUmqUwdI1R",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2014\/12\/we-three-kings.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2014\/12\/we-thr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541606824743813120",
  "text" : "RT @pchallinor: New mudgeonry: We three kings http:\/\/t.co\/rUmqUwdI1R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/rUmqUwdI1R",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2014\/12\/we-three-kings.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2014\/12\/we-thr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541596583943745536",
    "text" : "New mudgeonry: We three kings http:\/\/t.co\/rUmqUwdI1R",
    "id" : 541596583943745536,
    "created_at" : "2014-12-07 14:14:22 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 541606824743813120,
  "created_at" : "2014-12-07 14:55:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/w6fmANInpD",
      "expanded_url" : "http:\/\/www.beltabelgium.com\/webinars\/",
      "display_url" : "beltabelgium.com\/webinars\/"
    } ]
  },
  "geo" : { },
  "id_str" : "541598540280389632",
  "text" : "RT @rosemerebard: Belta webinar will start in 50 minutes. The link to the room here: http:\/\/t.co\/w6fmANInpD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/w6fmANInpD",
        "expanded_url" : "http:\/\/www.beltabelgium.com\/webinars\/",
        "display_url" : "beltabelgium.com\/webinars\/"
      } ]
    },
    "geo" : { },
    "id_str" : "541595952193474563",
    "text" : "Belta webinar will start in 50 minutes. The link to the room here: http:\/\/t.co\/w6fmANInpD",
    "id" : 541595952193474563,
    "created_at" : "2014-12-07 14:11:52 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 541598540280389632,
  "created_at" : "2014-12-07 14:22:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "lou Burnard",
      "screen_name" : "louBurnard",
      "indices" : [ 13, 24 ],
      "id_str" : "20203594",
      "id" : 20203594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541598125849575424",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @louBurnard thx for RT :)",
  "id" : 541598125849575424,
  "created_at" : "2014-12-07 14:20:30 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/s7BPg3zFdq",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-11a",
      "display_url" : "wp.me\/p21lsm-11a"
    } ]
  },
  "geo" : { },
  "id_str" : "541597996446543872",
  "text" : "Teaching listening: an American accent http:\/\/t.co\/s7BPg3zFdq via @wordpressdotcom",
  "id" : 541597996446543872,
  "created_at" : "2014-12-07 14:19:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tokyo Reporter",
      "screen_name" : "tokyoreporter",
      "indices" : [ 3, 17 ],
      "id_str" : "19386949",
      "id" : 19386949
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tokyoreporter\/status\/541436002238083072\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xCJZ9ENFZO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ORK1HCUAAdR7X.jpg",
      "id_str" : "541435995455901696",
      "id" : 541435995455901696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ORK1HCUAAdR7X.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 884
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 884
      } ],
      "display_url" : "pic.twitter.com\/xCJZ9ENFZO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/r6WnWP69lZ",
      "expanded_url" : "http:\/\/www.japantimes.co.jp\/life\/2014\/12\/05\/lifestyle\/bilingirl-has-plenty-to-teach-you\/#.VIPKcJ1darU",
      "display_url" : "japantimes.co.jp\/life\/2014\/12\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541530100718915584",
  "text" : "RT @tokyoreporter: Bilingirl has plenty to teach http:\/\/t.co\/r6WnWP69lZ\nChika Yoshida is Japanese-English bilingual YouTube celebrity http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tokyoreporter\/status\/541436002238083072\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xCJZ9ENFZO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ORK1HCUAAdR7X.jpg",
        "id_str" : "541435995455901696",
        "id" : 541435995455901696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ORK1HCUAAdR7X.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 884
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 884
        } ],
        "display_url" : "pic.twitter.com\/xCJZ9ENFZO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/r6WnWP69lZ",
        "expanded_url" : "http:\/\/www.japantimes.co.jp\/life\/2014\/12\/05\/lifestyle\/bilingirl-has-plenty-to-teach-you\/#.VIPKcJ1darU",
        "display_url" : "japantimes.co.jp\/life\/2014\/12\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541436002238083072",
    "text" : "Bilingirl has plenty to teach http:\/\/t.co\/r6WnWP69lZ\nChika Yoshida is Japanese-English bilingual YouTube celebrity http:\/\/t.co\/xCJZ9ENFZO",
    "id" : 541436002238083072,
    "created_at" : "2014-12-07 03:36:16 +0000",
    "user" : {
      "name" : "Tokyo Reporter",
      "screen_name" : "tokyoreporter",
      "protected" : false,
      "id_str" : "19386949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737606299270029314\/QwwpRPmN_normal.jpg",
      "id" : 19386949,
      "verified" : false
    }
  },
  "id" : 541530100718915584,
  "created_at" : "2014-12-07 09:50:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOCUS Project",
      "screen_name" : "FOCUS_projectDU",
      "indices" : [ 0, 16 ],
      "id_str" : "835675381",
      "id" : 835675381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541328569671356416",
  "in_reply_to_user_id" : 835675381,
  "text" : "@FOCUS_projectDU hi there wondering if i could talk to you about the FOCUS project? thx",
  "id" : 541328569671356416,
  "created_at" : "2014-12-06 20:29:23 +0000",
  "in_reply_to_screen_name" : "FOCUS_projectDU",
  "in_reply_to_user_id_str" : "835675381",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuliana Bagan",
      "screen_name" : "BaganYuliana",
      "indices" : [ 29, 42 ],
      "id_str" : "2239942027",
      "id" : 2239942027
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/541284998339633153\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/CKLMBznLtY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4MH1kCCEAEs_du.png",
      "id_str" : "541284997001252865",
      "id" : 541284997001252865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4MH1kCCEAEs_du.png",
      "sizes" : [ {
        "h" : 541,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/CKLMBznLtY"
    } ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541284998339633153",
  "text" : "#corpora for pragmatics from @BaganYuliana  webinar http:\/\/t.co\/CKLMBznLtY",
  "id" : 541284998339633153,
  "created_at" : "2014-12-06 17:36:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuliana Bagan",
      "screen_name" : "BaganYuliana",
      "indices" : [ 26, 39 ],
      "id_str" : "2239942027",
      "id" : 2239942027
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/541282937917161473\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/vDbG2bxLKT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4MF9n4IcAEU1HV.png",
      "id_str" : "541282936449167361",
      "id" : 541282936449167361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4MF9n4IcAEU1HV.png",
      "sizes" : [ {
        "h" : 539,
        "resize" : "fit",
        "w" : 724
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 724
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vDbG2bxLKT"
    } ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "Webinars",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/LYvmULvO9e",
      "expanded_url" : "http:\/\/www.myenglishonline.ca\/for-teachers\/continuous-professional-development\/test-page\/",
      "display_url" : "myenglishonline.ca\/for-teachers\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541282937917161473",
  "text" : "dough can be forgiving as @BaganYuliana's student found using corpora http:\/\/t.co\/LYvmULvO9e #corpusmooc #Webinars http:\/\/t.co\/vDbG2bxLKT",
  "id" : 541282937917161473,
  "created_at" : "2014-12-06 17:28:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 3, 14 ],
      "id_str" : "90695737",
      "id" : 90695737
    }, {
      "name" : "Yuliana Bagan",
      "screen_name" : "BaganYuliana",
      "indices" : [ 24, 37 ],
      "id_str" : "2239942027",
      "id" : 2239942027
    }, {
      "name" : "English Online Inc.",
      "screen_name" : "EnglishOnlineMB",
      "indices" : [ 38, 54 ],
      "id_str" : "108414494",
      "id" : 108414494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "cdnelt",
      "indices" : [ 131, 138 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "eltcpd",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/XSiXuu01xw",
      "expanded_url" : "http:\/\/www.myenglishonline.ca\/2014\/11\/english-online-december-6-webinar-exploring-language\/",
      "display_url" : "myenglishonline.ca\/2014\/11\/englis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541270694370476032",
  "text" : "RT @yvetteinmb: In 1 hr @BaganYuliana @EnglishOnlineMB Webinar Dec 6 Exploring language in context #corpora http:\/\/t.co\/XSiXuu01xw #cdnelt \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yuliana Bagan",
        "screen_name" : "BaganYuliana",
        "indices" : [ 8, 21 ],
        "id_str" : "2239942027",
        "id" : 2239942027
      }, {
        "name" : "English Online Inc.",
        "screen_name" : "EnglishOnlineMB",
        "indices" : [ 22, 38 ],
        "id_str" : "108414494",
        "id" : 108414494
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpora",
        "indices" : [ 83, 91 ]
      }, {
        "text" : "cdnelt",
        "indices" : [ 115, 122 ]
      }, {
        "text" : "elt",
        "indices" : [ 123, 127 ]
      }, {
        "text" : "eltcpd",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/XSiXuu01xw",
        "expanded_url" : "http:\/\/www.myenglishonline.ca\/2014\/11\/english-online-december-6-webinar-exploring-language\/",
        "display_url" : "myenglishonline.ca\/2014\/11\/englis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "541245381762232320",
    "text" : "In 1 hr @BaganYuliana @EnglishOnlineMB Webinar Dec 6 Exploring language in context #corpora http:\/\/t.co\/XSiXuu01xw #cdnelt #elt #eltcpd",
    "id" : 541245381762232320,
    "created_at" : "2014-12-06 14:58:49 +0000",
    "user" : {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "protected" : false,
      "id_str" : "90695737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557709684782542848\/F-hkOiI5_normal.jpeg",
      "id" : 90695737,
      "verified" : false
    }
  },
  "id" : 541270694370476032,
  "created_at" : "2014-12-06 16:39:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541270127137030144",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran cheers for RT Ljiljana :) have a great Saturday",
  "id" : 541270127137030144,
  "created_at" : "2014-12-06 16:37:09 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541225091661828097",
  "geo" : { },
  "id_str" : "541269945607544832",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard ah right nice :)",
  "id" : 541269945607544832,
  "in_reply_to_status_id" : 541225091661828097,
  "created_at" : "2014-12-06 16:36:25 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 3, 19 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541217267774918656",
  "text" : "RT @SwiftOnSecurity: What if selfies are a social fad secretly promoted by the FBI to populate their facial recognition database.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516014916440825856",
    "text" : "What if selfies are a social fad secretly promoted by the FBI to populate their facial recognition database.",
    "id" : 516014916440825856,
    "created_at" : "2014-09-28 00:01:57 +0000",
    "user" : {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "protected" : false,
      "id_str" : "2436389418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760698616612872192\/kX7MZg2n_normal.jpg",
      "id" : 2436389418,
      "verified" : false
    }
  },
  "id" : 541217267774918656,
  "created_at" : "2014-12-06 13:07:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Riley-Jones",
      "screen_name" : "GoldLinguist",
      "indices" : [ 0, 13 ],
      "id_str" : "603879138",
      "id" : 603879138
    }, {
      "name" : "\u827E\u672A\u672A  Ai Weiwei",
      "screen_name" : "aiww",
      "indices" : [ 14, 19 ],
      "id_str" : "43654274",
      "id" : 43654274
    }, {
      "name" : "Blenheim Palace",
      "screen_name" : "BlenheimPalace",
      "indices" : [ 20, 35 ],
      "id_str" : "113114399",
      "id" : 113114399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541193826384490496",
  "geo" : { },
  "id_str" : "541195596200423424",
  "in_reply_to_user_id" : 603879138,
  "text" : "@GoldLinguist @aiww @BlenheimPalace he should do a colloboration with Julien Assange :)",
  "id" : 541195596200423424,
  "in_reply_to_status_id" : 541193826384490496,
  "created_at" : "2014-12-06 11:40:59 +0000",
  "in_reply_to_screen_name" : "GoldLinguist",
  "in_reply_to_user_id_str" : "603879138",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541194649868967936",
  "geo" : { },
  "id_str" : "541195161595023360",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec cool did not know that :)",
  "id" : 541195161595023360,
  "in_reply_to_status_id" : 541194649868967936,
  "created_at" : "2014-12-06 11:39:16 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 0, 14 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541180140186001408",
  "geo" : { },
  "id_str" : "541193603243343872",
  "in_reply_to_user_id" : 48839094,
  "text" : "@duygucandarli nice look fwd to any possible write-up :)",
  "id" : 541193603243343872,
  "in_reply_to_status_id" : 541180140186001408,
  "created_at" : "2014-12-06 11:33:04 +0000",
  "in_reply_to_screen_name" : "duygucandarli",
  "in_reply_to_user_id_str" : "48839094",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541191107347243008",
  "geo" : { },
  "id_str" : "541192129738182656",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec sure but don't quote me on that :)",
  "id" : 541192129738182656,
  "in_reply_to_status_id" : 541191107347243008,
  "created_at" : "2014-12-06 11:27:13 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540916340396412928",
  "geo" : { },
  "id_str" : "541190033156620288",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec i think you can use contingency tables no?",
  "id" : 541190033156620288,
  "in_reply_to_status_id" : 540916340396412928,
  "created_at" : "2014-12-06 11:18:53 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roseli Serra",
      "screen_name" : "SerraRoseli",
      "indices" : [ 0, 12 ],
      "id_str" : "387102854",
      "id" : 387102854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541180804697976832",
  "geo" : { },
  "id_str" : "541186133603143681",
  "in_reply_to_user_id" : 387102854,
  "text" : "@SerraRoseli hmm dunno site looks dodgy plus dead link anyway",
  "id" : 541186133603143681,
  "in_reply_to_status_id" : 541180804697976832,
  "created_at" : "2014-12-06 11:03:23 +0000",
  "in_reply_to_screen_name" : "SerraRoseli",
  "in_reply_to_user_id_str" : "387102854",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roseli Serra",
      "screen_name" : "SerraRoseli",
      "indices" : [ 0, 12 ],
      "id_str" : "387102854",
      "id" : 387102854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541177548512952320",
  "geo" : { },
  "id_str" : "541178748213952512",
  "in_reply_to_user_id" : 387102854,
  "text" : "@SerraRoseli um is that kosher Roseli?",
  "id" : 541178748213952512,
  "in_reply_to_status_id" : 541177548512952320,
  "created_at" : "2014-12-06 10:34:02 +0000",
  "in_reply_to_screen_name" : "SerraRoseli",
  "in_reply_to_user_id_str" : "387102854",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 0, 12 ],
      "id_str" : "237402639",
      "id" : 237402639
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 13, 26 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541175351091941376",
  "in_reply_to_user_id" : 237402639,
  "text" : "@bunyanchris @rosemerebard thanks for RT Chris &amp; Rose, have a restful w\/e, goodluck on yr webinar Rose :)",
  "id" : 541175351091941376,
  "created_at" : "2014-12-06 10:20:32 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/gpBWyFXgy6",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-R0",
      "display_url" : "wp.me\/pgHyE-R0"
    } ]
  },
  "geo" : { },
  "id_str" : "541021601261551617",
  "text" : "Guy Aston talks speech corpora http:\/\/t.co\/gpBWyFXgy6 #corpusmooc",
  "id" : 541021601261551617,
  "created_at" : "2014-12-06 00:09:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/KyjF5pfWhq",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-11v",
      "display_url" : "wp.me\/p3qkCB-11v"
    } ]
  },
  "geo" : { },
  "id_str" : "540923469673033730",
  "text" : "RT @GeoffreyJordan: Principles and practice http:\/\/t.co\/KyjF5pfWhq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/KyjF5pfWhq",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-11v",
        "display_url" : "wp.me\/p3qkCB-11v"
      } ]
    },
    "geo" : { },
    "id_str" : "540906152003780608",
    "text" : "Principles and practice http:\/\/t.co\/KyjF5pfWhq",
    "id" : 540906152003780608,
    "created_at" : "2014-12-05 16:30:50 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 540923469673033730,
  "created_at" : "2014-12-05 17:39:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Hurst",
      "screen_name" : "altaineducation",
      "indices" : [ 3, 19 ],
      "id_str" : "517334705",
      "id" : 517334705
    }, {
      "name" : "Cambridge Assessment",
      "screen_name" : "Cam_Assessment",
      "indices" : [ 131, 140 ],
      "id_str" : "95455461",
      "id" : 95455461
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BETTChat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/VZEWTc4SL5",
      "expanded_url" : "http:\/\/bit.ly\/1w29HAJ",
      "display_url" : "bit.ly\/1w29HAJ"
    } ]
  },
  "geo" : { },
  "id_str" : "540851357507665921",
  "text" : "RT @altaineducation: Why#textbookscount http:\/\/t.co\/VZEWTc4SL5 counter intuitive paper in face of digital advance needs to be read @Cam_Ass\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Assessment",
        "screen_name" : "Cam_Assessment",
        "indices" : [ 110, 125 ],
        "id_str" : "95455461",
        "id" : 95455461
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BETTChat",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/VZEWTc4SL5",
        "expanded_url" : "http:\/\/bit.ly\/1w29HAJ",
        "display_url" : "bit.ly\/1w29HAJ"
      } ]
    },
    "geo" : { },
    "id_str" : "540839943464292353",
    "text" : "Why#textbookscount http:\/\/t.co\/VZEWTc4SL5 counter intuitive paper in face of digital advance needs to be read @Cam_Assessment #BETTChat",
    "id" : 540839943464292353,
    "created_at" : "2014-12-05 12:07:45 +0000",
    "user" : {
      "name" : "Geoff Hurst",
      "screen_name" : "altaineducation",
      "protected" : false,
      "id_str" : "517334705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3650457507\/6ac01e5ce54397521fb3418e549dd348_normal.jpeg",
      "id" : 517334705,
      "verified" : false
    }
  },
  "id" : 540851357507665921,
  "created_at" : "2014-12-05 12:53:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/dOZKtLlbY9",
      "expanded_url" : "http:\/\/www.coerll.utexas.edu\/spintx\/",
      "display_url" : "coerll.utexas.edu\/spintx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "540648628738457600",
  "text" : "SpinTX multimedia Spanish #corpus http:\/\/t.co\/dOZKtLlbY9 #corpusmooc",
  "id" : 540648628738457600,
  "created_at" : "2014-12-04 23:27:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    }, {
      "name" : "David M. Brear",
      "screen_name" : "davidbrear",
      "indices" : [ 127, 138 ],
      "id_str" : "23218742",
      "id" : 23218742
    }, {
      "name" : "Christopher Hoover",
      "screen_name" : "cahoover",
      "indices" : [ 139, 140 ],
      "id_str" : "1337421",
      "id" : 1337421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metacognition",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/auLJHOgFoT",
      "expanded_url" : "http:\/\/www.psmag.com\/navigation\/health-and-behavior\/confident-idiots-92793\/",
      "display_url" : "psmag.com\/navigation\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540610755054559233",
  "text" : "RT @aral: We Are All Confident idiots\u2014David Dunning\n\nhttp:\/\/t.co\/auLJHOgFoT\n\nGreat article on fallacies of #metacognition\n\nVia @davidbrear \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David M. Brear",
        "screen_name" : "davidbrear",
        "indices" : [ 117, 128 ],
        "id_str" : "23218742",
        "id" : 23218742
      }, {
        "name" : "Christopher Hoover",
        "screen_name" : "cahoover",
        "indices" : [ 129, 138 ],
        "id_str" : "1337421",
        "id" : 1337421
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "metacognition",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/auLJHOgFoT",
        "expanded_url" : "http:\/\/www.psmag.com\/navigation\/health-and-behavior\/confident-idiots-92793\/",
        "display_url" : "psmag.com\/navigation\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "540543237480775680",
    "text" : "We Are All Confident idiots\u2014David Dunning\n\nhttp:\/\/t.co\/auLJHOgFoT\n\nGreat article on fallacies of #metacognition\n\nVia @davidbrear @cahoover",
    "id" : 540543237480775680,
    "created_at" : "2014-12-04 16:28:45 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 540610755054559233,
  "created_at" : "2014-12-04 20:57:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Ensor",
      "screen_name" : "sensor63",
      "indices" : [ 3, 12 ],
      "id_str" : "84562932",
      "id" : 84562932
    }, {
      "name" : "Marcin Kleban",
      "screen_name" : "makle1",
      "indices" : [ 94, 101 ],
      "id_str" : "90346874",
      "id" : 90346874
    }, {
      "name" : "Teresa MacKinnon",
      "screen_name" : "WarwickLanguage",
      "indices" : [ 102, 118 ],
      "id_str" : "81817497",
      "id" : 81817497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mfl",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "clavier",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "ccourses",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/KTfsv03O8a",
      "expanded_url" : "http:\/\/zite.to\/1tJTFFl",
      "display_url" : "zite.to\/1tJTFFl"
    } ]
  },
  "geo" : { },
  "id_str" : "540600447716036608",
  "text" : "RT @sensor63: There is no language instinct \u2013 Vyvyan Evans \u2013 Aeon http:\/\/t.co\/KTfsv03O8a #mfl @makle1 @warwicklanguage #clavier #ccourses",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcin Kleban",
        "screen_name" : "makle1",
        "indices" : [ 80, 87 ],
        "id_str" : "90346874",
        "id" : 90346874
      }, {
        "name" : "Teresa MacKinnon",
        "screen_name" : "WarwickLanguage",
        "indices" : [ 88, 104 ],
        "id_str" : "81817497",
        "id" : 81817497
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mfl",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "clavier",
        "indices" : [ 105, 113 ]
      }, {
        "text" : "ccourses",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/KTfsv03O8a",
        "expanded_url" : "http:\/\/zite.to\/1tJTFFl",
        "display_url" : "zite.to\/1tJTFFl"
      } ]
    },
    "geo" : { },
    "id_str" : "540544650810228738",
    "text" : "There is no language instinct \u2013 Vyvyan Evans \u2013 Aeon http:\/\/t.co\/KTfsv03O8a #mfl @makle1 @warwicklanguage #clavier #ccourses",
    "id" : 540544650810228738,
    "created_at" : "2014-12-04 16:34:22 +0000",
    "user" : {
      "name" : "Simon Ensor",
      "screen_name" : "sensor63",
      "protected" : false,
      "id_str" : "84562932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764067062952161284\/J4_MGkND_normal.jpg",
      "id" : 84562932,
      "verified" : false
    }
  },
  "id" : 540600447716036608,
  "created_at" : "2014-12-04 20:16:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540526684207067137",
  "geo" : { },
  "id_str" : "540530567914471424",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco glad to help, assume u will soon be twitter quiet for a week or so now :)",
  "id" : 540530567914471424,
  "in_reply_to_status_id" : 540526684207067137,
  "created_at" : "2014-12-04 15:38:24 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Skinner",
      "screen_name" : "EditorSkinner",
      "indices" : [ 3, 17 ],
      "id_str" : "52188182",
      "id" : 52188182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0aXdloSErC",
      "expanded_url" : "http:\/\/wapo.st\/1pUAPPw",
      "display_url" : "wapo.st\/1pUAPPw"
    } ]
  },
  "geo" : { },
  "id_str" : "540528244655915008",
  "text" : "RT @EditorSkinner: Small corpus study of which federal agencies are cursed at the most during comments phase for proposed regulations. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/0aXdloSErC",
        "expanded_url" : "http:\/\/wapo.st\/1pUAPPw",
        "display_url" : "wapo.st\/1pUAPPw"
      } ]
    },
    "geo" : { },
    "id_str" : "540524529672413184",
    "text" : "Small corpus study of which federal agencies are cursed at the most during comments phase for proposed regulations. http:\/\/t.co\/0aXdloSErC",
    "id" : 540524529672413184,
    "created_at" : "2014-12-04 15:14:24 +0000",
    "user" : {
      "name" : "David Skinner",
      "screen_name" : "EditorSkinner",
      "protected" : false,
      "id_str" : "52188182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411587550\/fdf9d50e3e2fe9192cae65d5618d597f_normal.jpeg",
      "id" : 52188182,
      "verified" : false
    }
  },
  "id" : 540528244655915008,
  "created_at" : "2014-12-04 15:29:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540522567745175553",
  "geo" : { },
  "id_str" : "540526413892575232",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco yep I can't think of an author yet who has said no though not requested that many.",
  "id" : 540526413892575232,
  "in_reply_to_status_id" : 540522567745175553,
  "created_at" : "2014-12-04 15:21:54 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540505295324450816",
  "geo" : { },
  "id_str" : "540522059919794176",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco have tried emailing author?",
  "id" : 540522059919794176,
  "in_reply_to_status_id" : 540505295324450816,
  "created_at" : "2014-12-04 15:04:36 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 32, 46 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/2ZX2NG5ihK",
      "expanded_url" : "http:\/\/bit.ly\/1pX6GPp",
      "display_url" : "bit.ly\/1pX6GPp"
    } ]
  },
  "geo" : { },
  "id_str" : "540452812459876352",
  "text" : "RT @tornhalves: Our footnote to @audreywatters nice post about edtech and the technocentric culture of control in education:  \nhttp:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 16, 30 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/2ZX2NG5ihK",
        "expanded_url" : "http:\/\/bit.ly\/1pX6GPp",
        "display_url" : "bit.ly\/1pX6GPp"
      } ]
    },
    "geo" : { },
    "id_str" : "540450006931886080",
    "text" : "Our footnote to @audreywatters nice post about edtech and the technocentric culture of control in education:  \nhttp:\/\/t.co\/2ZX2NG5ihK",
    "id" : 540450006931886080,
    "created_at" : "2014-12-04 10:18:17 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 540452812459876352,
  "created_at" : "2014-12-04 10:29:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/hUO4F950pe",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-4zW",
      "display_url" : "wp.me\/p2KE8s-4zW"
    } ]
  },
  "geo" : { },
  "id_str" : "540269685342629888",
  "text" : "Personalised corpora for your students http:\/\/t.co\/hUO4F950pe via @wordpressdotcom",
  "id" : 540269685342629888,
  "created_at" : "2014-12-03 22:21:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540269280722681856",
  "text" : "#eltchat thanks everyone :)",
  "id" : 540269280722681856,
  "created_at" : "2014-12-03 22:20:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/IHNjRgNPxX",
      "expanded_url" : "http:\/\/weaeducation.typepad.co.uk\/wea_education_blog\/files\/frank_coffield_on_teach_and_learning.pdf",
      "display_url" : "weaeducation.typepad.co.uk\/wea_education_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540261827461263360",
  "text" : "previous screenshot from http:\/\/t.co\/IHNjRgNPxX #eltchat",
  "id" : 540261827461263360,
  "created_at" : "2014-12-03 21:50:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/540260509287993344\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/pmMig5TvzF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B39kEWfCUAAaCg-.png",
      "id_str" : "540260506225758208",
      "id" : 540260506225758208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B39kEWfCUAAaCg-.png",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 635
      } ],
      "display_url" : "pic.twitter.com\/pmMig5TvzF"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540260509287993344",
  "text" : "found this amusing :) #eltchat http:\/\/t.co\/pmMig5TvzF",
  "id" : 540260509287993344,
  "created_at" : "2014-12-03 21:45:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marjorie Rosenberg",
      "screen_name" : "MarjorieRosenbe",
      "indices" : [ 3, 19 ],
      "id_str" : "328052618",
      "id" : 328052618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540257352633827330",
  "text" : "RT @MarjorieRosenbe: Do we actually have a definition of teaching styles? #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 53, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540256872784482304",
    "text" : "Do we actually have a definition of teaching styles? #eltchat",
    "id" : 540256872784482304,
    "created_at" : "2014-12-03 21:30:50 +0000",
    "user" : {
      "name" : "Marjorie Rosenberg",
      "screen_name" : "MarjorieRosenbe",
      "protected" : false,
      "id_str" : "328052618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1423546568\/Margie_portrait__blue__cropped_1_3mb_normal.jpg",
      "id" : 328052618,
      "verified" : false
    }
  },
  "id" : 540257352633827330,
  "created_at" : "2014-12-03 21:32:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540250163164753920",
  "text" : "#eltchat hi am lurking, quick thought some loaded notions - style, outcomes",
  "id" : 540250163164753920,
  "created_at" : "2014-12-03 21:04:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Urs Kalberer",
      "screen_name" : "ELTmethods",
      "indices" : [ 3, 14 ],
      "id_str" : "248360304",
      "id" : 248360304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Seasonsgreetings",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Z4tG0OLLT8",
      "expanded_url" : "http:\/\/seasonsgreetings.cambridge.org",
      "display_url" : "seasonsgreetings.cambridge.org"
    } ]
  },
  "geo" : { },
  "id_str" : "540244404586684416",
  "text" : "RT @ELTmethods: I\u2019ve described my festive season in 3 words for the Christmas Corpus. Add yours! http:\/\/t.co\/Z4tG0OLLT8 #Seasonsgreetings f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Seasonsgreetings",
        "indices" : [ 104, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Z4tG0OLLT8",
        "expanded_url" : "http:\/\/seasonsgreetings.cambridge.org",
        "display_url" : "seasonsgreetings.cambridge.org"
      } ]
    },
    "geo" : { },
    "id_str" : "539820350477844481",
    "text" : "I\u2019ve described my festive season in 3 words for the Christmas Corpus. Add yours! http:\/\/t.co\/Z4tG0OLLT8 #Seasonsgreetings from Cambridge",
    "id" : 539820350477844481,
    "created_at" : "2014-12-02 16:36:15 +0000",
    "user" : {
      "name" : "Urs Kalberer",
      "screen_name" : "ELTmethods",
      "protected" : false,
      "id_str" : "248360304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436965811907862530\/tTCMspIx_normal.jpeg",
      "id" : 248360304,
      "verified" : false
    }
  },
  "id" : 540244404586684416,
  "created_at" : "2014-12-03 20:41:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    }, {
      "name" : "Stupid Hackathon",
      "screen_name" : "stupidhackathon",
      "indices" : [ 36, 52 ],
      "id_str" : "2429320687",
      "id" : 2429320687
    }, {
      "name" : "Sam Tarakajian",
      "screen_name" : "starakaj",
      "indices" : [ 65, 74 ],
      "id_str" : "201850306",
      "id" : 201850306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/p3yymBDoxH",
      "expanded_url" : "http:\/\/youtu.be\/l0u-swKYIxw",
      "display_url" : "youtu.be\/l0u-swKYIxw"
    } ]
  },
  "geo" : { },
  "id_str" : "540209650042687489",
  "text" : "RT @sam_lavigne: one of my favorite @stupidhackathon projects by @starakaj - an app that tells you if you're holding your phone or not http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stupid Hackathon",
        "screen_name" : "stupidhackathon",
        "indices" : [ 19, 35 ],
        "id_str" : "2429320687",
        "id" : 2429320687
      }, {
        "name" : "Sam Tarakajian",
        "screen_name" : "starakaj",
        "indices" : [ 48, 57 ],
        "id_str" : "201850306",
        "id" : 201850306
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/p3yymBDoxH",
        "expanded_url" : "http:\/\/youtu.be\/l0u-swKYIxw",
        "display_url" : "youtu.be\/l0u-swKYIxw"
      } ]
    },
    "geo" : { },
    "id_str" : "539541723220017153",
    "text" : "one of my favorite @stupidhackathon projects by @starakaj - an app that tells you if you're holding your phone or not http:\/\/t.co\/p3yymBDoxH",
    "id" : 539541723220017153,
    "created_at" : "2014-12-01 22:09:05 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 540209650042687489,
  "created_at" : "2014-12-03 18:23:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 3, 14 ],
      "id_str" : "90695737",
      "id" : 90695737
    }, {
      "name" : "Yuliana Bagan",
      "screen_name" : "BaganYuliana",
      "indices" : [ 19, 32 ],
      "id_str" : "2239942027",
      "id" : 2239942027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 80, 98 ]
    }, {
      "text" : "cdnelt",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "elt",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 135, 140 ]
    }, {
      "text" : "tleap",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/XSiXuu01xw",
      "expanded_url" : "http:\/\/www.myenglishonline.ca\/2014\/11\/english-online-december-6-webinar-exploring-language\/",
      "display_url" : "myenglishonline.ca\/2014\/11\/englis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540185993710931969",
  "text" : "RT @yvetteinmb: RT @BaganYuliana EO Webinar Dec 6 Exploring language in context #corpuslinguistics http:\/\/t.co\/XSiXuu01xw #cdnelt #elt #elt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yuliana Bagan",
        "screen_name" : "BaganYuliana",
        "indices" : [ 3, 16 ],
        "id_str" : "2239942027",
        "id" : 2239942027
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 64, 82 ]
      }, {
        "text" : "cdnelt",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "elt",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "tleap",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/XSiXuu01xw",
        "expanded_url" : "http:\/\/www.myenglishonline.ca\/2014\/11\/english-online-december-6-webinar-exploring-language\/",
        "display_url" : "myenglishonline.ca\/2014\/11\/englis\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "539865921037561856",
    "geo" : { },
    "id_str" : "540184338688520192",
    "in_reply_to_user_id" : 2239942027,
    "text" : "RT @BaganYuliana EO Webinar Dec 6 Exploring language in context #corpuslinguistics http:\/\/t.co\/XSiXuu01xw #cdnelt #elt #eltchat #tleap",
    "id" : 540184338688520192,
    "in_reply_to_status_id" : 539865921037561856,
    "created_at" : "2014-12-03 16:42:37 +0000",
    "in_reply_to_screen_name" : "BaganYuliana",
    "in_reply_to_user_id_str" : "2239942027",
    "user" : {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "protected" : false,
      "id_str" : "90695737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557709684782542848\/F-hkOiI5_normal.jpeg",
      "id" : 90695737,
      "verified" : false
    }
  },
  "id" : 540185993710931969,
  "created_at" : "2014-12-03 16:49:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 23, 33 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "We Are e3",
      "screen_name" : "WereE3",
      "indices" : [ 109, 116 ],
      "id_str" : "2351621334",
      "id" : 2351621334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 56, 60 ]
    }, {
      "text" : "edtech",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/tp4UbWSzpp",
      "expanded_url" : "http:\/\/ow.ly\/Fh98u",
      "display_url" : "ow.ly\/Fh98u"
    } ]
  },
  "geo" : { },
  "id_str" : "540134983680024576",
  "text" : "RT @eltjam: Just up by @jo_sayers: Social Enterprise in #ELT \u2013 The E3 Project http:\/\/t.co\/tp4UbWSzpp #edtech @WereE3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jo Sayers",
        "screen_name" : "jo_sayers",
        "indices" : [ 11, 21 ],
        "id_str" : "87176766",
        "id" : 87176766
      }, {
        "name" : "We Are e3",
        "screen_name" : "WereE3",
        "indices" : [ 97, 104 ],
        "id_str" : "2351621334",
        "id" : 2351621334
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 44, 48 ]
      }, {
        "text" : "edtech",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/tp4UbWSzpp",
        "expanded_url" : "http:\/\/ow.ly\/Fh98u",
        "display_url" : "ow.ly\/Fh98u"
      } ]
    },
    "geo" : { },
    "id_str" : "540081763243270144",
    "text" : "Just up by @jo_sayers: Social Enterprise in #ELT \u2013 The E3 Project http:\/\/t.co\/tp4UbWSzpp #edtech @WereE3",
    "id" : 540081763243270144,
    "created_at" : "2014-12-03 09:55:01 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 540134983680024576,
  "created_at" : "2014-12-03 13:26:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/eJbXJJtPe8",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1EgE_y0TK8KM-K9X-GxbpV9UrhDJkrfL6txaRuAKwqYs\/edit",
      "display_url" : "docs.google.com\/document\/d\/1Eg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540115365360308224",
  "text" : "RT @michaelegriffin: A new crowdsourced doc where people complete the sentence \"When I first started teaching I...\" \nhttps:\/\/t.co\/eJbXJJtPe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 120, 128 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/eJbXJJtPe8",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1EgE_y0TK8KM-K9X-GxbpV9UrhDJkrfL6txaRuAKwqYs\/edit",
        "display_url" : "docs.google.com\/document\/d\/1Eg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "540062995506675712",
    "text" : "A new crowdsourced doc where people complete the sentence \"When I first started teaching I...\" \nhttps:\/\/t.co\/eJbXJJtPe8\n#ELTchat #keltchat",
    "id" : 540062995506675712,
    "created_at" : "2014-12-03 08:40:26 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 540115365360308224,
  "created_at" : "2014-12-03 12:08:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 100, 108 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/sflxFj57Yr",
      "expanded_url" : "http:\/\/youtu.be\/HMjBqrWQ_5g",
      "display_url" : "youtu.be\/HMjBqrWQ_5g"
    } ]
  },
  "geo" : { },
  "id_str" : "540020250272493568",
  "text" : "New Era Reporter Row: What's The Agenda? Russell Brand The Trews (E202): http:\/\/t.co\/sflxFj57Yr via @YouTube",
  "id" : 540020250272493568,
  "created_at" : "2014-12-03 05:50:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9k1G2VNT0Y",
      "expanded_url" : "http:\/\/www.routledge.com\/linguistics\/articles\/author_of_the_month_jennifer_jenkins\/",
      "display_url" : "routledge.com\/linguistics\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540017630997118976",
  "text" : "RT @duygucandarli: 'Native speakers are NOT excluded from definitions of English as a lingua franca.' An interview with Prof Jenkins: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/9k1G2VNT0Y",
        "expanded_url" : "http:\/\/www.routledge.com\/linguistics\/articles\/author_of_the_month_jennifer_jenkins\/",
        "display_url" : "routledge.com\/linguistics\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "539932134501130240",
    "text" : "'Native speakers are NOT excluded from definitions of English as a lingua franca.' An interview with Prof Jenkins: http:\/\/t.co\/9k1G2VNT0Y",
    "id" : 539932134501130240,
    "created_at" : "2014-12-03 00:00:26 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 540017630997118976,
  "created_at" : "2014-12-03 05:40:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/sFcqGSPDgS",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3731871-muliti-word-expressions",
      "display_url" : "magic.piktochart.com\/output\/3731871\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539921812973711360",
  "text" : "multi-word expressions MWEs a visual aid - https:\/\/t.co\/sFcqGSPDgS #corpusmooc",
  "id" : 539921812973711360,
  "created_at" : "2014-12-02 23:19:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 0, 12 ],
      "id_str" : "533125583",
      "id" : 533125583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539895641007460352",
  "geo" : { },
  "id_str" : "539898137947942912",
  "in_reply_to_user_id" : 533125583,
  "text" : "@teahorvatic ok, good luck! do post any thoughts on G+ CL site if you feel like it :)",
  "id" : 539898137947942912,
  "in_reply_to_status_id" : 539895641007460352,
  "created_at" : "2014-12-02 21:45:21 +0000",
  "in_reply_to_screen_name" : "teahorvatic",
  "in_reply_to_user_id_str" : "533125583",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 3, 19 ],
      "id_str" : "13435662",
      "id" : 13435662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/8GoZY1c8Ov",
      "expanded_url" : "https:\/\/plus.google.com\/100559601798599091706\/posts\/S6vbXn9JVzw",
      "display_url" : "plus.google.com\/10055960179859\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539895799229214720",
  "text" : "RT @TheConsultantsE: Gavin's recent 'Big Data' plenary at Digital ELT in Dublin is now available on our YouTube channel: https:\/\/t.co\/8GoZY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/8GoZY1c8Ov",
        "expanded_url" : "https:\/\/plus.google.com\/100559601798599091706\/posts\/S6vbXn9JVzw",
        "display_url" : "plus.google.com\/10055960179859\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538759212315467776",
    "text" : "Gavin's recent 'Big Data' plenary at Digital ELT in Dublin is now available on our YouTube channel: https:\/\/t.co\/8GoZY1c8Ov",
    "id" : 538759212315467776,
    "created_at" : "2014-11-29 18:19:40 +0000",
    "user" : {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "protected" : false,
      "id_str" : "13435662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741978194044162048\/-uFGjiTN_normal.jpg",
      "id" : 13435662,
      "verified" : false
    }
  },
  "id" : 539895799229214720,
  "created_at" : "2014-12-02 21:36:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 0, 12 ],
      "id_str" : "533125583",
      "id" : 533125583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539016358340874240",
  "geo" : { },
  "id_str" : "539881374862548992",
  "in_reply_to_user_id" : 533125583,
  "text" : "@teahorvatic great! how is it going?",
  "id" : 539881374862548992,
  "in_reply_to_status_id" : 539016358340874240,
  "created_at" : "2014-12-02 20:38:44 +0000",
  "in_reply_to_screen_name" : "teahorvatic",
  "in_reply_to_user_id_str" : "533125583",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "indices" : [ 70, 86 ],
      "id_str" : "117051544",
      "id" : 117051544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/GwTLpCq5NO",
      "expanded_url" : "http:\/\/cup.linguistlist.org\/uncategorized\/the-dangling-participle-a-language-myth\/#.VH29qh3HQjY.twitter",
      "display_url" : "cup.linguistlist.org\/uncategorized\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539772234210889729",
  "text" : "The dangling participle \u2013 a language myth? http:\/\/t.co\/GwTLpCq5NO via @cambUP_langling",
  "id" : 539772234210889729,
  "created_at" : "2014-12-02 13:25:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NSA",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "security",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "drone",
      "indices" : [ 50, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/iSKp6b5D9Q",
      "expanded_url" : "http:\/\/ow.ly\/Fc75b",
      "display_url" : "ow.ly\/Fc75b"
    } ]
  },
  "geo" : { },
  "id_str" : "539651606481219584",
  "text" : "RT @patrickDurusau: New NSA Drone! #NSA #security #drone http:\/\/t.co\/iSKp6b5D9Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NSA",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "security",
        "indices" : [ 20, 29 ]
      }, {
        "text" : "drone",
        "indices" : [ 30, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/iSKp6b5D9Q",
        "expanded_url" : "http:\/\/ow.ly\/Fc75b",
        "display_url" : "ow.ly\/Fc75b"
      } ]
    },
    "geo" : { },
    "id_str" : "539630076393193472",
    "text" : "New NSA Drone! #NSA #security #drone http:\/\/t.co\/iSKp6b5D9Q",
    "id" : 539630076393193472,
    "created_at" : "2014-12-02 04:00:10 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 539651606481219584,
  "created_at" : "2014-12-02 05:25:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 84, 94 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/CcauvkNRB5",
      "expanded_url" : "http:\/\/shar.es\/1XBJxL",
      "display_url" : "shar.es\/1XBJxL"
    } ]
  },
  "geo" : { },
  "id_str" : "539536633335279616",
  "text" : "The shift in English - connecting with ASEAN Australians http:\/\/t.co\/CcauvkNRB5 via @sharethis #corpusmooc",
  "id" : 539536633335279616,
  "created_at" : "2014-12-01 21:48:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Tn7H9R18aj",
      "expanded_url" : "http:\/\/skell.sketchengine.co.uk",
      "display_url" : "skell.sketchengine.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "539528406598447106",
  "text" : "RT @TonyMcEnery: A nice new resource: Sketch Engine for Language Learning! See http:\/\/t.co\/Tn7H9R18aj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/Tn7H9R18aj",
        "expanded_url" : "http:\/\/skell.sketchengine.co.uk",
        "display_url" : "skell.sketchengine.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "539526332062109696",
    "text" : "A nice new resource: Sketch Engine for Language Learning! See http:\/\/t.co\/Tn7H9R18aj",
    "id" : 539526332062109696,
    "created_at" : "2014-12-01 21:07:56 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 539528406598447106,
  "created_at" : "2014-12-01 21:16:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "Chris Rock",
      "screen_name" : "chrisrock",
      "indices" : [ 36, 46 ],
      "id_str" : "238319766",
      "id" : 238319766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/eHxdY1YLqq",
      "expanded_url" : "http:\/\/wapo.st\/1vcjS3H",
      "display_url" : "wapo.st\/1vcjS3H"
    } ]
  },
  "geo" : { },
  "id_str" : "539501397210058752",
  "text" : "RT @linguisticpulse: you gotta read @chrisrock's genius reframing of \"black progress\" as white progress http:\/\/t.co\/eHxdY1YLqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Rock",
        "screen_name" : "chrisrock",
        "indices" : [ 15, 25 ],
        "id_str" : "238319766",
        "id" : 238319766
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/eHxdY1YLqq",
        "expanded_url" : "http:\/\/wapo.st\/1vcjS3H",
        "display_url" : "wapo.st\/1vcjS3H"
      } ]
    },
    "geo" : { },
    "id_str" : "539491989692358656",
    "text" : "you gotta read @chrisrock's genius reframing of \"black progress\" as white progress http:\/\/t.co\/eHxdY1YLqq",
    "id" : 539491989692358656,
    "created_at" : "2014-12-01 18:51:28 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 539501397210058752,
  "created_at" : "2014-12-01 19:28:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539177314190249985",
  "geo" : { },
  "id_str" : "539305515655135232",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan sure :) added a comment",
  "id" : 539305515655135232,
  "in_reply_to_status_id" : 539177314190249985,
  "created_at" : "2014-12-01 06:30:29 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]