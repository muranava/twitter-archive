Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris stolz",
      "screen_name" : "srstolz",
      "indices" : [ 0, 8 ],
      "id_str" : "27029718",
      "id" : 27029718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737313818787729409",
  "geo" : { },
  "id_str" : "737744057531834368",
  "in_reply_to_user_id" : 27029718,
  "text" : "@srstolz quote by Ellis is contradictory? - learner control contrasts with \"conditions\" of learning in the subsequent passage",
  "id" : 737744057531834368,
  "in_reply_to_status_id" : 737313818787729409,
  "created_at" : "2016-05-31 20:34:24 +0000",
  "in_reply_to_screen_name" : "srstolz",
  "in_reply_to_user_id_str" : "27029718",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris stolz",
      "screen_name" : "srstolz",
      "indices" : [ 0, 8 ],
      "id_str" : "27029718",
      "id" : 27029718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737313818787729409",
  "geo" : { },
  "id_str" : "737739947201925120",
  "in_reply_to_user_id" : 27029718,
  "text" : "@srstolz there seems to be an \"ultimately\" missing in quote",
  "id" : 737739947201925120,
  "in_reply_to_status_id" : 737313818787729409,
  "created_at" : "2016-05-31 20:18:04 +0000",
  "in_reply_to_screen_name" : "srstolz",
  "in_reply_to_user_id_str" : "27029718",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Gue8xpqRXX",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=24276",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=24276"
    } ]
  },
  "in_reply_to_status_id_str" : "737728082249912320",
  "geo" : { },
  "id_str" : "737735127711764480",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin another curious effect cld be dangers of pop science writing \uD83D\uDE06 https:\/\/t.co\/Gue8xpqRXX",
  "id" : 737735127711764480,
  "in_reply_to_status_id" : 737728082249912320,
  "created_at" : "2016-05-31 19:58:55 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Toast",
      "screen_name" : "TheToast",
      "indices" : [ 3, 12 ],
      "id_str" : "1400466500",
      "id" : 1400466500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/KJ8NH05Ccl",
      "expanded_url" : "http:\/\/the-toast.net\/2016\/05\/31\/language-learning-decolonisation\/",
      "display_url" : "the-toast.net\/2016\/05\/31\/lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737725740377116673",
  "text" : "RT @TheToast: \"A'ghailleann\": On Language-Learning and the Decolonisation of the Mind | https:\/\/t.co\/KJ8NH05Ccl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/KJ8NH05Ccl",
        "expanded_url" : "http:\/\/the-toast.net\/2016\/05\/31\/language-learning-decolonisation\/",
        "display_url" : "the-toast.net\/2016\/05\/31\/lan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737661239673925632",
    "text" : "\"A'ghailleann\": On Language-Learning and the Decolonisation of the Mind | https:\/\/t.co\/KJ8NH05Ccl",
    "id" : 737661239673925632,
    "created_at" : "2016-05-31 15:05:19 +0000",
    "user" : {
      "name" : "The Toast",
      "screen_name" : "TheToast",
      "protected" : false,
      "id_str" : "1400466500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3751127000\/d1f186cd881d05128af9543cb4b1fe9d_normal.jpeg",
      "id" : 1400466500,
      "verified" : false
    }
  },
  "id" : 737725740377116673,
  "created_at" : "2016-05-31 19:21:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felicity Morse",
      "screen_name" : "FelicityMorse",
      "indices" : [ 3, 17 ],
      "id_str" : "347959437",
      "id" : 347959437
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FelicityMorse\/status\/737671953637638145\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/PkxicDABXC",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cjy8mDPXAAApydg.jpg",
      "id_str" : "737671800872697856",
      "id" : 737671800872697856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cjy8mDPXAAApydg.jpg",
      "sizes" : [ {
        "h" : 144,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 144,
        "resize" : "crop",
        "w" : 144
      } ],
      "display_url" : "pic.twitter.com\/PkxicDABXC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737712173624004609",
  "text" : "RT @FelicityMorse: Man tries to burn EU flag, can't burn it because of EU directive on flammable materials https:\/\/t.co\/PkxicDABXC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FelicityMorse\/status\/737671953637638145\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/PkxicDABXC",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cjy8mDPXAAApydg.jpg",
        "id_str" : "737671800872697856",
        "id" : 737671800872697856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cjy8mDPXAAApydg.jpg",
        "sizes" : [ {
          "h" : 144,
          "resize" : "fit",
          "w" : 260
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 260
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 260
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 260
        }, {
          "h" : 144,
          "resize" : "crop",
          "w" : 144
        } ],
        "display_url" : "pic.twitter.com\/PkxicDABXC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737671953637638145",
    "text" : "Man tries to burn EU flag, can't burn it because of EU directive on flammable materials https:\/\/t.co\/PkxicDABXC",
    "id" : 737671953637638145,
    "created_at" : "2016-05-31 15:47:53 +0000",
    "user" : {
      "name" : "Felicity Morse",
      "screen_name" : "FelicityMorse",
      "protected" : false,
      "id_str" : "347959437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696718723680493568\/In-Dl7uf_normal.jpg",
      "id" : 347959437,
      "verified" : true
    }
  },
  "id" : 737712173624004609,
  "created_at" : "2016-05-31 18:27:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rania Khalek",
      "screen_name" : "RaniaKhalek",
      "indices" : [ 3, 15 ],
      "id_str" : "37501003",
      "id" : 37501003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/dh0tzWMOYT",
      "expanded_url" : "https:\/\/www.middleeastmonitor.com\/20160530-british-palestinian-schoolgirl-expelled-from-public-speaking-competition\/#.V0w9VVSFGno.twitter",
      "display_url" : "middleeastmonitor.com\/20160530-briti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737366044843593728",
  "text" : "RT @RaniaKhalek: British-Palestinian schoolgirl expelled from speaking competition bc her message offended a rightwing bigot https:\/\/t.co\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/dh0tzWMOYT",
        "expanded_url" : "https:\/\/www.middleeastmonitor.com\/20160530-british-palestinian-schoolgirl-expelled-from-public-speaking-competition\/#.V0w9VVSFGno.twitter",
        "display_url" : "middleeastmonitor.com\/20160530-briti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737342044734132224",
    "text" : "British-Palestinian schoolgirl expelled from speaking competition bc her message offended a rightwing bigot https:\/\/t.co\/dh0tzWMOYT",
    "id" : 737342044734132224,
    "created_at" : "2016-05-30 17:56:57 +0000",
    "user" : {
      "name" : "Rania Khalek",
      "screen_name" : "RaniaKhalek",
      "protected" : false,
      "id_str" : "37501003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759900197388423168\/r0OzSEtV_normal.jpg",
      "id" : 37501003,
      "verified" : true
    }
  },
  "id" : 737366044843593728,
  "created_at" : "2016-05-30 19:32:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737203885232824320",
  "geo" : { },
  "id_str" : "737236003128279040",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson thx \uD83D\uDE03",
  "id" : 737236003128279040,
  "in_reply_to_status_id" : 737203885232824320,
  "created_at" : "2016-05-30 10:55:34 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 16, 29 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737169466958741504",
  "geo" : { },
  "id_str" : "737195081036406784",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott @rosemerebard great thanks",
  "id" : 737195081036406784,
  "in_reply_to_status_id" : 737169466958741504,
  "created_at" : "2016-05-30 08:12:58 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/Sv1h5JbF6X",
      "expanded_url" : "https:\/\/youtu.be\/keWpfCrnaUg",
      "display_url" : "youtu.be\/keWpfCrnaUg"
    } ]
  },
  "geo" : { },
  "id_str" : "736990291094310912",
  "text" : "I gave my iPhone arms || SHITTY ROBOTS https:\/\/t.co\/Sv1h5JbF6X via @YouTube",
  "id" : 736990291094310912,
  "created_at" : "2016-05-29 18:39:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Palma",
      "screen_name" : "JulioCPalmaM",
      "indices" : [ 3, 16 ],
      "id_str" : "202293835",
      "id" : 202293835
    }, {
      "name" : "VenTESOL",
      "screen_name" : "VenTESOL",
      "indices" : [ 26, 35 ],
      "id_str" : "91569202",
      "id" : 91569202
    }, {
      "name" : "Dudley Reynolds",
      "screen_name" : "drdeadly",
      "indices" : [ 62, 71 ],
      "id_str" : "255079634",
      "id" : 255079634
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 72, 81 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JulioCPalmaM\/status\/736871128908632064\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/2rPuQRWmrv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjnkWpBUkAAqSzP.jpg",
      "id_str" : "736871091671437312",
      "id" : 736871091671437312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjnkWpBUkAAqSzP.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/2rPuQRWmrv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736981421949124608",
  "text" : "RT @JulioCPalmaM: My talk @VenTESOL 2016. Spreading knowledge @drdeadly @muranava https:\/\/t.co\/2rPuQRWmrv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VenTESOL",
        "screen_name" : "VenTESOL",
        "indices" : [ 8, 17 ],
        "id_str" : "91569202",
        "id" : 91569202
      }, {
        "name" : "Dudley Reynolds",
        "screen_name" : "drdeadly",
        "indices" : [ 44, 53 ],
        "id_str" : "255079634",
        "id" : 255079634
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 54, 63 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JulioCPalmaM\/status\/736871128908632064\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/2rPuQRWmrv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjnkWpBUkAAqSzP.jpg",
        "id_str" : "736871091671437312",
        "id" : 736871091671437312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjnkWpBUkAAqSzP.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/2rPuQRWmrv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736871128908632064",
    "text" : "My talk @VenTESOL 2016. Spreading knowledge @drdeadly @muranava https:\/\/t.co\/2rPuQRWmrv",
    "id" : 736871128908632064,
    "created_at" : "2016-05-29 10:45:42 +0000",
    "user" : {
      "name" : "Julio Palma",
      "screen_name" : "JulioCPalmaM",
      "protected" : false,
      "id_str" : "202293835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768206046431154177\/dxdw78mt_normal.jpg",
      "id" : 202293835,
      "verified" : false
    }
  },
  "id" : 736981421949124608,
  "created_at" : "2016-05-29 18:03:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Palma",
      "screen_name" : "JulioCPalmaM",
      "indices" : [ 0, 13 ],
      "id_str" : "202293835",
      "id" : 202293835
    }, {
      "name" : "VenTESOL",
      "screen_name" : "VenTESOL",
      "indices" : [ 14, 23 ],
      "id_str" : "91569202",
      "id" : 91569202
    }, {
      "name" : "Dudley Reynolds",
      "screen_name" : "drdeadly",
      "indices" : [ 24, 33 ],
      "id_str" : "255079634",
      "id" : 255079634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736871128908632064",
  "geo" : { },
  "id_str" : "736981383575445509",
  "in_reply_to_user_id" : 202293835,
  "text" : "@JulioCPalmaM @VenTESOL @drdeadly nice hope it went well : )",
  "id" : 736981383575445509,
  "in_reply_to_status_id" : 736871128908632064,
  "created_at" : "2016-05-29 18:03:48 +0000",
  "in_reply_to_screen_name" : "JulioCPalmaM",
  "in_reply_to_user_id_str" : "202293835",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bsnews",
      "screen_name" : "bsnews1",
      "indices" : [ 3, 11 ],
      "id_str" : "349141375",
      "id" : 349141375
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 13, 23 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/7bsK97rvRG",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=flfZwQh1vIc",
      "display_url" : "youtube.com\/watch?v=flfZwQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736292201869807616",
  "text" : "RT @bsnews1: @medialens @johnsmowc4 Great interview with Ken Loach on his new Palm D'Or winning film, i, Daniel:Blake https:\/\/t.co\/7bsK97rv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 0, 10 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/7bsK97rvRG",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=flfZwQh1vIc",
        "display_url" : "youtube.com\/watch?v=flfZwQ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736247068830924801",
    "in_reply_to_user_id" : 6531902,
    "text" : "@medialens @johnsmowc4 Great interview with Ken Loach on his new Palm D'Or winning film, i, Daniel:Blake https:\/\/t.co\/7bsK97rvRG",
    "id" : 736247068830924801,
    "created_at" : "2016-05-27 17:25:54 +0000",
    "in_reply_to_screen_name" : "medialens",
    "in_reply_to_user_id_str" : "6531902",
    "user" : {
      "name" : "bsnews",
      "screen_name" : "bsnews1",
      "protected" : false,
      "id_str" : "349141375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3464564215\/f4c299d770161acb90e44f8a58dc7bbb_normal.png",
      "id" : 349141375,
      "verified" : false
    }
  },
  "id" : 736292201869807616,
  "created_at" : "2016-05-27 20:25:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 3, 15 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/zBjdFVEh7E",
      "expanded_url" : "http:\/\/conferences.unite.un.org\/UNCorpus",
      "display_url" : "conferences.unite.un.org\/UNCorpus"
    } ]
  },
  "geo" : { },
  "id_str" : "736277851863941121",
  "text" : "RT @usage_based: United Nations Parallel Corpus has been released : \u591A\u8A00\u8A9E\u30D1\u30E9\u30EC\u30EB\u30B3\u30FC\u30D1\u30B9\n&lt;https:\/\/t.co\/zBjdFVEh7E&gt;",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/zBjdFVEh7E",
        "expanded_url" : "http:\/\/conferences.unite.un.org\/UNCorpus",
        "display_url" : "conferences.unite.un.org\/UNCorpus"
      } ]
    },
    "geo" : { },
    "id_str" : "736239517951090688",
    "text" : "United Nations Parallel Corpus has been released : \u591A\u8A00\u8A9E\u30D1\u30E9\u30EC\u30EB\u30B3\u30FC\u30D1\u30B9\n&lt;https:\/\/t.co\/zBjdFVEh7E&gt;",
    "id" : 736239517951090688,
    "created_at" : "2016-05-27 16:55:54 +0000",
    "user" : {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "protected" : false,
      "id_str" : "1479290418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663653015962845184\/KI-fL-mX_normal.jpg",
      "id" : 1479290418,
      "verified" : false
    }
  },
  "id" : 736277851863941121,
  "created_at" : "2016-05-27 19:28:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/5PQ5zg2eUK",
      "expanded_url" : "https:\/\/twitter.com\/medialens\/status\/736200929385586692",
      "display_url" : "twitter.com\/medialens\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736271656319102977",
  "text" : "RT @johnwhilley: Absorbing and deeply informative. Just imagine the effect of this on 'mainstream' TV - that's why it's not there. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/5PQ5zg2eUK",
        "expanded_url" : "https:\/\/twitter.com\/medialens\/status\/736200929385586692",
        "display_url" : "twitter.com\/medialens\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736266117426122752",
    "text" : "Absorbing and deeply informative. Just imagine the effect of this on 'mainstream' TV - that's why it's not there. https:\/\/t.co\/5PQ5zg2eUK",
    "id" : 736266117426122752,
    "created_at" : "2016-05-27 18:41:36 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 736271656319102977,
  "created_at" : "2016-05-27 19:03:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736200682269642758",
  "geo" : { },
  "id_str" : "736262482789076992",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc it's good to see : )",
  "id" : 736262482789076992,
  "in_reply_to_status_id" : 736200682269642758,
  "created_at" : "2016-05-27 18:27:09 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Cauldwell",
      "screen_name" : "richcauld",
      "indices" : [ 3, 13 ],
      "id_str" : "21668722",
      "id" : 21668722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/Lc75nrWC9z",
      "expanded_url" : "https:\/\/textploitationtefl.com\/2015\/10\/21\/creating-your-own-listening-texts-one-sided-phone-conversations\/",
      "display_url" : "textploitationtefl.com\/2015\/10\/21\/cre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736251506584915968",
  "text" : "RT @richcauld: You find wonderful things when you delve into a recording, as David Byrne and Mark Heffernan found out.\n\nhttps:\/\/t.co\/Lc75nr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Lc75nrWC9z",
        "expanded_url" : "https:\/\/textploitationtefl.com\/2015\/10\/21\/creating-your-own-listening-texts-one-sided-phone-conversations\/",
        "display_url" : "textploitationtefl.com\/2015\/10\/21\/cre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729676824578494464",
    "text" : "You find wonderful things when you delve into a recording, as David Byrne and Mark Heffernan found out.\n\nhttps:\/\/t.co\/Lc75nrWC9z",
    "id" : 729676824578494464,
    "created_at" : "2016-05-09 14:18:06 +0000",
    "user" : {
      "name" : "Richard Cauldwell",
      "screen_name" : "richcauld",
      "protected" : false,
      "id_str" : "21668722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591795\/richcauld_portrait_normal.jpg",
      "id" : 21668722,
      "verified" : false
    }
  },
  "id" : 736251506584915968,
  "created_at" : "2016-05-27 17:43:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736134450849845248",
  "geo" : { },
  "id_str" : "736161245053739008",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc wordcount, ok understood",
  "id" : 736161245053739008,
  "in_reply_to_status_id" : 736134450849845248,
  "created_at" : "2016-05-27 11:44:52 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 59, 69 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/ACVNNZCDkt",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/05\/26\/in-defence-of-personal-attacks\/",
      "display_url" : "samkriss.wordpress.com\/2016\/05\/26\/in-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736125911444164608",
  "text" : "In defence of personal attacks https:\/\/t.co\/ACVNNZCDkt via @sam_kriss",
  "id" : 736125911444164608,
  "created_at" : "2016-05-27 09:24:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 81, 97 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/F8myKIcnri",
      "expanded_url" : "https:\/\/jamiesternweiner.wordpress.com\/2016\/05\/27\/jonathan-freedland-keeps-digging-how-low-will-he-go\/",
      "display_url" : "jamiesternweiner.wordpress.com\/2016\/05\/27\/jon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736125367547744256",
  "text" : "JONATHAN FREEDLAND KEEPS DIGGING\u2014HOW LOW WILL HE GO? https:\/\/t.co\/F8myKIcnri via @wordpressdotcom",
  "id" : 736125367547744256,
  "created_at" : "2016-05-27 09:22:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 109, 120 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/T6qqwWKT9I",
      "expanded_url" : "https:\/\/ioelondonblog.wordpress.com\/2016\/05\/27\/jolies-appointment-does-not-change-fundamental-gender-relations-in-universities\/",
      "display_url" : "ioelondonblog.wordpress.com\/2016\/05\/27\/jol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736124650040786944",
  "text" : "Jolie\u2019s appointment does not change fundamental gender relations in universities https:\/\/t.co\/T6qqwWKT9I via @IOE_London",
  "id" : 736124650040786944,
  "created_at" : "2016-05-27 09:19:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736116229165846528",
  "geo" : { },
  "id_str" : "736120763292475392",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc loaded xml file, create corpus, then tried to do word count",
  "id" : 736120763292475392,
  "in_reply_to_status_id" : 736116229165846528,
  "created_at" : "2016-05-27 09:04:01 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/2P04pMPLc6",
      "expanded_url" : "http:\/\/pastebin.com\/YyahDreK",
      "display_url" : "pastebin.com\/YyahDreK"
    }, {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/BjpJCK8XIe",
      "expanded_url" : "http:\/\/pastebin.com\/U0L71u8V",
      "display_url" : "pastebin.com\/U0L71u8V"
    } ]
  },
  "in_reply_to_status_id_str" : "736112202386571267",
  "geo" : { },
  "id_str" : "736113590441218048",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc startup crash - https:\/\/t.co\/2P04pMPLc6; load xml file crash - https:\/\/t.co\/BjpJCK8XIe",
  "id" : 736113590441218048,
  "in_reply_to_status_id" : 736112202386571267,
  "created_at" : "2016-05-27 08:35:30 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736111853521141760",
  "geo" : { },
  "id_str" : "736112165472604160",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc starting; also just got a crash when trying to load an xml file",
  "id" : 736112165472604160,
  "in_reply_to_status_id" : 736111853521141760,
  "created_at" : "2016-05-27 08:29:51 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736108828169637888",
  "geo" : { },
  "id_str" : "736110962093199360",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc CC crashes if trying to install new packages for R",
  "id" : 736110962093199360,
  "in_reply_to_status_id" : 736108828169637888,
  "created_at" : "2016-05-27 08:25:04 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736106067415826433",
  "geo" : { },
  "id_str" : "736108066471567360",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc like the new logo  \uD83D\uDC4D",
  "id" : 736108066471567360,
  "in_reply_to_status_id" : 736106067415826433,
  "created_at" : "2016-05-27 08:13:33 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "SimonWood11",
      "indices" : [ 3, 15 ],
      "id_str" : "489327561",
      "id" : 489327561
    }, {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 86, 98 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Mark Hilley",
      "screen_name" : "marcohilley",
      "indices" : [ 99, 111 ],
      "id_str" : "27631507",
      "id" : 27631507
    }, {
      "name" : "Daniel Margrain",
      "screen_name" : "hairymarx1",
      "indices" : [ 112, 123 ],
      "id_str" : "93871532",
      "id" : 93871532
    }, {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 124, 136 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "Torben Betts",
      "screen_name" : "TorbenBetts",
      "indices" : [ 137, 140 ],
      "id_str" : "2419986010",
      "id" : 2419986010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hiroshima",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/ZkZMem5MO0",
      "expanded_url" : "http:\/\/99998271.blogspot.jp\/2016\/05\/obama-does-hiroshima.html",
      "display_url" : "99998271.blogspot.jp\/2016\/05\/obama-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736091785731018752",
  "text" : "RT @SimonWood11: New from 99.99998271%: Obama Does #Hiroshima https:\/\/t.co\/ZkZMem5MO0 @johnwhilley @marcohilley @hairymarx1 @NeilClark66 @T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Hilley",
        "screen_name" : "johnwhilley",
        "indices" : [ 69, 81 ],
        "id_str" : "223771625",
        "id" : 223771625
      }, {
        "name" : "Mark Hilley",
        "screen_name" : "marcohilley",
        "indices" : [ 82, 94 ],
        "id_str" : "27631507",
        "id" : 27631507
      }, {
        "name" : "Daniel Margrain",
        "screen_name" : "hairymarx1",
        "indices" : [ 95, 106 ],
        "id_str" : "93871532",
        "id" : 93871532
      }, {
        "name" : "Neil Clark",
        "screen_name" : "NeilClark66",
        "indices" : [ 107, 119 ],
        "id_str" : "728039605",
        "id" : 728039605
      }, {
        "name" : "Torben Betts",
        "screen_name" : "TorbenBetts",
        "indices" : [ 120, 132 ],
        "id_str" : "2419986010",
        "id" : 2419986010
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hiroshima",
        "indices" : [ 34, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/ZkZMem5MO0",
        "expanded_url" : "http:\/\/99998271.blogspot.jp\/2016\/05\/obama-does-hiroshima.html",
        "display_url" : "99998271.blogspot.jp\/2016\/05\/obama-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735883865735061505",
    "text" : "New from 99.99998271%: Obama Does #Hiroshima https:\/\/t.co\/ZkZMem5MO0 @johnwhilley @marcohilley @hairymarx1 @NeilClark66 @TorbenBetts",
    "id" : 735883865735061505,
    "created_at" : "2016-05-26 17:22:40 +0000",
    "user" : {
      "name" : "Simon Wood",
      "screen_name" : "SimonWood11",
      "protected" : false,
      "id_str" : "489327561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447558650257604609\/S4X-OjkW_normal.jpeg",
      "id" : 489327561,
      "verified" : false
    }
  },
  "id" : 736091785731018752,
  "created_at" : "2016-05-27 07:08:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/sGYzWl0pFZ",
      "expanded_url" : "https:\/\/twitter.com\/michaelegriffin\/status\/736087111728697345",
      "display_url" : "twitter.com\/michaelegriffi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736089221081923584",
  "text" : "oldie but a goldie : ) https:\/\/t.co\/sGYzWl0pFZ",
  "id" : 736089221081923584,
  "created_at" : "2016-05-27 06:58:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/OQB3ysOtJP",
      "expanded_url" : "https:\/\/www.apps4efl.com\/",
      "display_url" : "apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "735932273602777089",
  "text" : "RT @eilymurphy: Apps 4 EFL: Engaging online study for learners of EFL\/ESL https:\/\/t.co\/OQB3ysOtJP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/OQB3ysOtJP",
        "expanded_url" : "https:\/\/www.apps4efl.com\/",
        "display_url" : "apps4efl.com"
      } ]
    },
    "geo" : { },
    "id_str" : "735922789912317952",
    "text" : "Apps 4 EFL: Engaging online study for learners of EFL\/ESL https:\/\/t.co\/OQB3ysOtJP",
    "id" : 735922789912317952,
    "created_at" : "2016-05-26 19:57:20 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 735932273602777089,
  "created_at" : "2016-05-26 20:35:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735930432043155456",
  "geo" : { },
  "id_str" : "735930649438257152",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap sweet : )",
  "id" : 735930649438257152,
  "in_reply_to_status_id" : 735930432043155456,
  "created_at" : "2016-05-26 20:28:34 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735929752436019200",
  "geo" : { },
  "id_str" : "735930016115130373",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap that would be neat : )",
  "id" : 735930016115130373,
  "in_reply_to_status_id" : 735929752436019200,
  "created_at" : "2016-05-26 20:26:03 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735929651692965892",
  "geo" : { },
  "id_str" : "735929949413052416",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap great &amp; would you consider making your scripts available?",
  "id" : 735929949413052416,
  "in_reply_to_status_id" : 735929651692965892,
  "created_at" : "2016-05-26 20:25:47 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735928710772195328",
  "geo" : { },
  "id_str" : "735929286553698306",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap antconc mostly but it's not so good with xml; is it available as an open corpus in SkE?",
  "id" : 735929286553698306,
  "in_reply_to_status_id" : 735928710772195328,
  "created_at" : "2016-05-26 20:23:09 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735927233055985664",
  "geo" : { },
  "id_str" : "735928268558376960",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap btw what tool do you use to interrogate corpus?",
  "id" : 735928268558376960,
  "in_reply_to_status_id" : 735927233055985664,
  "created_at" : "2016-05-26 20:19:06 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735927233055985664",
  "geo" : { },
  "id_str" : "735928195606843392",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap no necessarily it's just the ortolang interface was a bit confusing for me! thanks a lot for making this publically available : )",
  "id" : 735928195606843392,
  "in_reply_to_status_id" : 735927233055985664,
  "created_at" : "2016-05-26 20:18:49 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735926344111017984",
  "geo" : { },
  "id_str" : "735926863508430848",
  "in_reply_to_user_id" : 18602422,
  "text" : "@cainesap nevermind seems you can download individual files but not the main single file?",
  "id" : 735926863508430848,
  "in_reply_to_status_id" : 735926344111017984,
  "created_at" : "2016-05-26 20:13:31 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735828500247150592",
  "geo" : { },
  "id_str" : "735926344111017984",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap hi are files still being uploaded to ortolang?",
  "id" : 735926344111017984,
  "in_reply_to_status_id" : 735828500247150592,
  "created_at" : "2016-05-26 20:11:27 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 3, 12 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cainesap\/status\/735828500247150592\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/bqNT6MW1Yk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjYwHwWWkAAvJXW.jpg",
      "id_str" : "735828498917527552",
      "id" : 735828498917527552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjYwHwWWkAAvJXW.jpg",
      "sizes" : [ {
        "h" : 193,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bqNT6MW1Yk"
    } ],
    "hashtags" : [ {
      "text" : "LREC2016",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Qsjlovz0xl",
      "expanded_url" : "http:\/\/apc38.user.srcf.net\/resources\/#crowded",
      "display_url" : "apc38.user.srcf.net\/resources\/#cro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735873756908949504",
  "text" : "RT @cainesap: We crowdsourced a speech corpus and now it's available for your research use https:\/\/t.co\/Qsjlovz0xl #LREC2016 https:\/\/t.co\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cainesap\/status\/735828500247150592\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/bqNT6MW1Yk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjYwHwWWkAAvJXW.jpg",
        "id_str" : "735828498917527552",
        "id" : 735828498917527552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjYwHwWWkAAvJXW.jpg",
        "sizes" : [ {
          "h" : 193,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/bqNT6MW1Yk"
      } ],
      "hashtags" : [ {
        "text" : "LREC2016",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Qsjlovz0xl",
        "expanded_url" : "http:\/\/apc38.user.srcf.net\/resources\/#crowded",
        "display_url" : "apc38.user.srcf.net\/resources\/#cro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735828500247150592",
    "text" : "We crowdsourced a speech corpus and now it's available for your research use https:\/\/t.co\/Qsjlovz0xl #LREC2016 https:\/\/t.co\/bqNT6MW1Yk",
    "id" : 735828500247150592,
    "created_at" : "2016-05-26 13:42:40 +0000",
    "user" : {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "protected" : false,
      "id_str" : "578898729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495910926545993729\/p2W-KQVG_normal.jpeg",
      "id" : 578898729,
      "verified" : false
    }
  },
  "id" : 735873756908949504,
  "created_at" : "2016-05-26 16:42:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American TESOL Inst.",
      "screen_name" : "americantesol",
      "indices" : [ 0, 14 ],
      "id_str" : "62443169",
      "id" : 62443169
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 15, 30 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735793865362264064",
  "geo" : { },
  "id_str" : "735856136683986944",
  "in_reply_to_user_id" : 62443169,
  "text" : "@americantesol @AnthonyTeacher thanks for sharing \uD83D\uDE00\uD83D\uDC4D",
  "id" : 735856136683986944,
  "in_reply_to_status_id" : 735793865362264064,
  "created_at" : "2016-05-26 15:32:29 +0000",
  "in_reply_to_screen_name" : "americantesol",
  "in_reply_to_user_id_str" : "62443169",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/s7yVSlDC43",
      "expanded_url" : "https:\/\/twitter.com\/NicolaPrentis\/status\/735854542659715072",
      "display_url" : "twitter.com\/NicolaPrentis\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735855771599163393",
  "text" : "#languagetrivia https:\/\/t.co\/s7yVSlDC43",
  "id" : 735855771599163393,
  "created_at" : "2016-05-26 15:31:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/teflerinha\/status\/735760280597069825\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/R0KC7lmI15",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjXyE5XUgAAcs8P.jpg",
      "id_str" : "735760280076976128",
      "id" : 735760280076976128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjXyE5XUgAAcs8P.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/R0KC7lmI15"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/N9e8Jah7fQ",
      "expanded_url" : "http:\/\/elt-resourceful.com\/2016\/05\/26\/tips-and-techniques-for-correcting-spoken-errors",
      "display_url" : "elt-resourceful.com\/2016\/05\/26\/tip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735778360412905472",
  "text" : "RT @teflerinha: Tips and techniques for correcting spoken\u00A0errors https:\/\/t.co\/N9e8Jah7fQ https:\/\/t.co\/R0KC7lmI15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/teflerinha\/status\/735760280597069825\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/R0KC7lmI15",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjXyE5XUgAAcs8P.jpg",
        "id_str" : "735760280076976128",
        "id" : 735760280076976128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjXyE5XUgAAcs8P.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/R0KC7lmI15"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/N9e8Jah7fQ",
        "expanded_url" : "http:\/\/elt-resourceful.com\/2016\/05\/26\/tips-and-techniques-for-correcting-spoken-errors",
        "display_url" : "elt-resourceful.com\/2016\/05\/26\/tip\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735760280597069825",
    "text" : "Tips and techniques for correcting spoken\u00A0errors https:\/\/t.co\/N9e8Jah7fQ https:\/\/t.co\/R0KC7lmI15",
    "id" : 735760280597069825,
    "created_at" : "2016-05-26 09:11:35 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 735778360412905472,
  "created_at" : "2016-05-26 10:23:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 3, 18 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/IVCqXApUDd",
      "expanded_url" : "https:\/\/ljiljanahavran.wordpress.com\/2016\/05\/25\/some-thoughts-on-blogging-and-using-twitter-for-pd\/",
      "display_url" : "ljiljanahavran.wordpress.com\/2016\/05\/25\/som\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735777545497415681",
  "text" : "RT @LjiljanaHavran: New on my blog: Some thoughts on blogging and using Twitter for PD https:\/\/t.co\/IVCqXApUDd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/IVCqXApUDd",
        "expanded_url" : "https:\/\/ljiljanahavran.wordpress.com\/2016\/05\/25\/some-thoughts-on-blogging-and-using-twitter-for-pd\/",
        "display_url" : "ljiljanahavran.wordpress.com\/2016\/05\/25\/som\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735616658560167936",
    "text" : "New on my blog: Some thoughts on blogging and using Twitter for PD https:\/\/t.co\/IVCqXApUDd",
    "id" : 735616658560167936,
    "created_at" : "2016-05-25 23:40:53 +0000",
    "user" : {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "protected" : false,
      "id_str" : "1395825290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729054439496159232\/58roonKM_normal.jpg",
      "id" : 1395825290,
      "verified" : false
    }
  },
  "id" : 735777545497415681,
  "created_at" : "2016-05-26 10:20:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/O5vHBIkyo4",
      "expanded_url" : "https:\/\/twitter.com\/Chris_Rebuffet\/status\/735568188663025664",
      "display_url" : "twitter.com\/Chris_Rebuffet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735584362486497280",
  "text" : "#languagetrivia https:\/\/t.co\/O5vHBIkyo4",
  "id" : 735584362486497280,
  "created_at" : "2016-05-25 21:32:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pringle",
      "screen_name" : "johnrpringle",
      "indices" : [ 3, 16 ],
      "id_str" : "2204127846",
      "id" : 2204127846
    }, {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "indices" : [ 110, 122 ],
      "id_str" : "2879372766",
      "id" : 2879372766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "LINC",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fSbjv14bIb",
      "expanded_url" : "http:\/\/eflmagazine.com\/activities-for-the-questions-in-students-heads\/",
      "display_url" : "eflmagazine.com\/activities-for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735580679090647041",
  "text" : "RT @johnrpringle: Some useful tips for creating task-based materials. #ELT #LINC  https:\/\/t.co\/fSbjv14bIb via @eflmagazine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFL Magazine",
        "screen_name" : "eflmagazine",
        "indices" : [ 92, 104 ],
        "id_str" : "2879372766",
        "id" : 2879372766
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 52, 56 ]
      }, {
        "text" : "LINC",
        "indices" : [ 57, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/fSbjv14bIb",
        "expanded_url" : "http:\/\/eflmagazine.com\/activities-for-the-questions-in-students-heads\/",
        "display_url" : "eflmagazine.com\/activities-for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735578389407399936",
    "text" : "Some useful tips for creating task-based materials. #ELT #LINC  https:\/\/t.co\/fSbjv14bIb via @eflmagazine",
    "id" : 735578389407399936,
    "created_at" : "2016-05-25 21:08:49 +0000",
    "user" : {
      "name" : "John Pringle",
      "screen_name" : "johnrpringle",
      "protected" : false,
      "id_str" : "2204127846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634415784995897344\/5iRmZwGS_normal.jpg",
      "id" : 2204127846,
      "verified" : false
    }
  },
  "id" : 735580679090647041,
  "created_at" : "2016-05-25 21:17:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/3hVmixEc2f",
      "expanded_url" : "https:\/\/twitter.com\/jeffthompson_\/status\/734926899399561216",
      "display_url" : "twitter.com\/jeffthompson_\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735578511226834944",
  "text" : "RT @grvsmth: Hero of the day! https:\/\/t.co\/3hVmixEc2f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/3hVmixEc2f",
        "expanded_url" : "https:\/\/twitter.com\/jeffthompson_\/status\/734926899399561216",
        "display_url" : "twitter.com\/jeffthompson_\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735572056960585729",
    "text" : "Hero of the day! https:\/\/t.co\/3hVmixEc2f",
    "id" : 735572056960585729,
    "created_at" : "2016-05-25 20:43:39 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 735578511226834944,
  "created_at" : "2016-05-25 21:09:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 0, 15 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735572988070875138",
  "geo" : { },
  "id_str" : "735574353467826176",
  "in_reply_to_user_id" : 1327355143,
  "text" : "@EvilJoeMcVeigh the snazzy way he describes those missing numbers is also peculiar... : )",
  "id" : 735574353467826176,
  "in_reply_to_status_id" : 735572988070875138,
  "created_at" : "2016-05-25 20:52:46 +0000",
  "in_reply_to_screen_name" : "EvilJoeMcVeigh",
  "in_reply_to_user_id_str" : "1327355143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/C91S303BlS",
      "expanded_url" : "https:\/\/youtu.be\/VWtlVPOkVKg",
      "display_url" : "youtu.be\/VWtlVPOkVKg"
    } ]
  },
  "geo" : { },
  "id_str" : "735570649914220552",
  "text" : "Real Vocabulary: What does momentarily mean? https:\/\/t.co\/C91S303BlS via @YouTube",
  "id" : 735570649914220552,
  "created_at" : "2016-05-25 20:38:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/WZJBDWRWAE",
      "expanded_url" : "https:\/\/hapgood.us\/2016\/05\/25\/grit-and-personalization\/",
      "display_url" : "hapgood.us\/2016\/05\/25\/gri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735568829380722693",
  "text" : "RT @holden: \"Grit\" and Personalization https:\/\/t.co\/WZJBDWRWAE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/WZJBDWRWAE",
        "expanded_url" : "https:\/\/hapgood.us\/2016\/05\/25\/grit-and-personalization\/",
        "display_url" : "hapgood.us\/2016\/05\/25\/gri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735568176180695041",
    "text" : "\"Grit\" and Personalization https:\/\/t.co\/WZJBDWRWAE",
    "id" : 735568176180695041,
    "created_at" : "2016-05-25 20:28:14 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 735568829380722693,
  "created_at" : "2016-05-25 20:30:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Watson",
      "screen_name" : "SteveWatson10",
      "indices" : [ 65, 79 ],
      "id_str" : "135269213",
      "id" : 135269213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/kL30hq4vzr",
      "expanded_url" : "https:\/\/sw10014.wordpress.com\/2016\/05\/25\/the-cambridge-campaign-for-education\/",
      "display_url" : "sw10014.wordpress.com\/2016\/05\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735557472149241856",
  "text" : "The Cambridge Campaign for Education https:\/\/t.co\/kL30hq4vzr via @SteveWatson10",
  "id" : 735557472149241856,
  "created_at" : "2016-05-25 19:45:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/b0SlZ99Xi8",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/going-off-message.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/going-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735553252880699392",
  "text" : "RT @pchallinor: New mudgeonry: Going off message https:\/\/t.co\/b0SlZ99Xi8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/b0SlZ99Xi8",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/going-off-message.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/going-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735552130778583041",
    "text" : "New mudgeonry: Going off message https:\/\/t.co\/b0SlZ99Xi8",
    "id" : 735552130778583041,
    "created_at" : "2016-05-25 19:24:28 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 735553252880699392,
  "created_at" : "2016-05-25 19:28:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735531762751803396",
  "geo" : { },
  "id_str" : "735545067994255360",
  "in_reply_to_user_id" : 44631065,
  "text" : "@Hada_ELT hi hope u had a good chat : )",
  "id" : 735545067994255360,
  "in_reply_to_status_id" : 735531762751803396,
  "created_at" : "2016-05-25 18:56:24 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/387w3Mio5v",
      "expanded_url" : "http:\/\/www.slb.coop\/international-membership-of-the-cooperative-slb\/",
      "display_url" : "slb.coop\/international-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735543955534827521",
  "text" : "International membership of the cooperative SLB! https:\/\/t.co\/387w3Mio5v",
  "id" : 735543955534827521,
  "created_at" : "2016-05-25 18:51:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Before Zod",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/cgHrmJxQ0r",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/ryanmac\/2016\/05\/24\/this-silicon-valley-billionaire-has-been-secretly-funding-hulk-hogans-lawsuits-against-gawker\/",
      "display_url" : "forbes.com\/sites\/ryanmac\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735543227919519747",
  "text" : "RT @anildash: When the backlash starts in earnest &amp; everyone in tech is hated, it'll be because of bond villain shit like this: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/cgHrmJxQ0r",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/ryanmac\/2016\/05\/24\/this-silicon-valley-billionaire-has-been-secretly-funding-hulk-hogans-lawsuits-against-gawker\/",
        "display_url" : "forbes.com\/sites\/ryanmac\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735263220999421952",
    "text" : "When the backlash starts in earnest &amp; everyone in tech is hated, it'll be because of bond villain shit like this: https:\/\/t.co\/cgHrmJxQ0r",
    "id" : 735263220999421952,
    "created_at" : "2016-05-25 00:16:27 +0000",
    "user" : {
      "name" : "Anil Before Zod",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725706637248368641\/YoilUS58_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 735543227919519747,
  "created_at" : "2016-05-25 18:49:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735447564485591040",
  "geo" : { },
  "id_str" : "735449472793088000",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock  \uD83D\uDC4D \uD83D\uDC4F  \uD83C\uDF7E",
  "id" : 735449472793088000,
  "in_reply_to_status_id" : 735447564485591040,
  "created_at" : "2016-05-25 12:36:32 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Ceri Jones",
      "screen_name" : "cerirhiannon",
      "indices" : [ 33, 46 ],
      "id_str" : "125619029",
      "id" : 125619029
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LXDforELT",
      "indices" : [ 99, 109 ]
    }, {
      "text" : "UX",
      "indices" : [ 110, 113 ]
    }, {
      "text" : "Bot",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "ELT",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/mnkg7btje9",
      "expanded_url" : "http:\/\/ow.ly\/KUe4300z7rH",
      "display_url" : "ow.ly\/KUe4300z7rH"
    } ]
  },
  "geo" : { },
  "id_str" : "735432709510684673",
  "text" : "RT @eltjam: NEW POST: Ceri Jones @cerirhiannon on why we need a \u2018CoachBot\u2019 https:\/\/t.co\/mnkg7btje9 #LXDforELT #UX #Bot #ELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ceri Jones",
        "screen_name" : "cerirhiannon",
        "indices" : [ 21, 34 ],
        "id_str" : "125619029",
        "id" : 125619029
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LXDforELT",
        "indices" : [ 87, 97 ]
      }, {
        "text" : "UX",
        "indices" : [ 98, 101 ]
      }, {
        "text" : "Bot",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "ELT",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/mnkg7btje9",
        "expanded_url" : "http:\/\/ow.ly\/KUe4300z7rH",
        "display_url" : "ow.ly\/KUe4300z7rH"
      } ]
    },
    "geo" : { },
    "id_str" : "735430981994303488",
    "text" : "NEW POST: Ceri Jones @cerirhiannon on why we need a \u2018CoachBot\u2019 https:\/\/t.co\/mnkg7btje9 #LXDforELT #UX #Bot #ELT",
    "id" : 735430981994303488,
    "created_at" : "2016-05-25 11:23:04 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 735432709510684673,
  "created_at" : "2016-05-25 11:29:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 0, 16 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735212598635945984",
  "geo" : { },
  "id_str" : "735221001504600065",
  "in_reply_to_user_id" : 149239362,
  "text" : "@umasslinguistic hmm interesting article in that author tries to unsuccesfully imo concretize an abstraction like language :\/",
  "id" : 735221001504600065,
  "in_reply_to_status_id" : 735212598635945984,
  "created_at" : "2016-05-24 21:28:41 +0000",
  "in_reply_to_screen_name" : "umasslinguistic",
  "in_reply_to_user_id_str" : "149239362",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734878565485924353",
  "geo" : { },
  "id_str" : "734994621810507776",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth dang",
  "id" : 734994621810507776,
  "in_reply_to_status_id" : 734878565485924353,
  "created_at" : "2016-05-24 06:29:08 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "indices" : [ 79, 90 ],
      "id_str" : "14606079",
      "id" : 14606079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bias",
      "indices" : [ 91, 96 ]
    }, {
      "text" : "discrimination",
      "indices" : [ 97, 112 ]
    }, {
      "text" : "sentencing",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/oOjuCkK0oL",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-i4c",
      "display_url" : "wp.me\/pSoaD-i4c"
    } ]
  },
  "geo" : { },
  "id_str" : "734994517808558081",
  "text" : "RT @patrickDurusau: Bias? What Bias? We're Scientific! https:\/\/t.co\/oOjuCkK0oL @ProPublica #bias #discrimination #sentencing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ProPublica",
        "screen_name" : "ProPublica",
        "indices" : [ 59, 70 ],
        "id_str" : "14606079",
        "id" : 14606079
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bias",
        "indices" : [ 71, 76 ]
      }, {
        "text" : "discrimination",
        "indices" : [ 77, 92 ]
      }, {
        "text" : "sentencing",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/oOjuCkK0oL",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-i4c",
        "display_url" : "wp.me\/pSoaD-i4c"
      } ]
    },
    "geo" : { },
    "id_str" : "734921522884710400",
    "text" : "Bias? What Bias? We're Scientific! https:\/\/t.co\/oOjuCkK0oL @ProPublica #bias #discrimination #sentencing",
    "id" : 734921522884710400,
    "created_at" : "2016-05-24 01:38:39 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 734994517808558081,
  "created_at" : "2016-05-24 06:28:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "'(dave yarwood)",
      "screen_name" : "dave_yarwood",
      "indices" : [ 85, 98 ],
      "id_str" : "2940297688",
      "id" : 2940297688
    }, {
      "name" : "Planet Clojure",
      "screen_name" : "planetclojure",
      "indices" : [ 99, 113 ],
      "id_str" : "146070339",
      "id" : 146070339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "music",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "clojure",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/6Najv5UYsw",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-i43",
      "display_url" : "wp.me\/pSoaD-i43"
    } ]
  },
  "geo" : { },
  "id_str" : "734988521346347008",
  "text" : "RT @patrickDurusau: Alda (Music Programming Language) Update https:\/\/t.co\/6Najv5UYsw @dave_yarwood @planetclojure #music #clojure",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "'(dave yarwood)",
        "screen_name" : "dave_yarwood",
        "indices" : [ 65, 78 ],
        "id_str" : "2940297688",
        "id" : 2940297688
      }, {
        "name" : "Planet Clojure",
        "screen_name" : "planetclojure",
        "indices" : [ 79, 93 ],
        "id_str" : "146070339",
        "id" : 146070339
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "music",
        "indices" : [ 94, 100 ]
      }, {
        "text" : "clojure",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/6Najv5UYsw",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-i43",
        "display_url" : "wp.me\/pSoaD-i43"
      } ]
    },
    "geo" : { },
    "id_str" : "734860337548283905",
    "text" : "Alda (Music Programming Language) Update https:\/\/t.co\/6Najv5UYsw @dave_yarwood @planetclojure #music #clojure",
    "id" : 734860337548283905,
    "created_at" : "2016-05-23 21:35:32 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 734988521346347008,
  "created_at" : "2016-05-24 06:04:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 56, 66 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/RBRn2AlkGh",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/05\/23\/nick-cohen-is-in-your-house\/",
      "display_url" : "samkriss.wordpress.com\/2016\/05\/23\/nic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734985773695545345",
  "text" : "Nick Cohen is in your house https:\/\/t.co\/RBRn2AlkGh via @sam_kriss",
  "id" : 734985773695545345,
  "created_at" : "2016-05-24 05:53:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thaisa Ferreira",
      "screen_name" : "thaisachristine",
      "indices" : [ 0, 16 ],
      "id_str" : "38752043",
      "id" : 38752043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716378780248322048",
  "geo" : { },
  "id_str" : "734985247473991681",
  "in_reply_to_user_id" : 18602422,
  "text" : "@thaisachristine thanks for sharing : )",
  "id" : 734985247473991681,
  "in_reply_to_status_id" : 716378780248322048,
  "created_at" : "2016-05-24 05:51:53 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/y1x9ahvRwH",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.com\/2016\/05\/the-future-ready-pledge.html?spref=tw",
      "display_url" : "curmudgucation.blogspot.com\/2016\/05\/the-fu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734867918085861376",
  "text" : "CURMUDGUCATION: The Future Ready Pledge https:\/\/t.co\/y1x9ahvRwH",
  "id" : 734867918085861376,
  "created_at" : "2016-05-23 22:05:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/EXxfuE2aj5",
      "expanded_url" : "http:\/\/nxhx.org\/maximizing\/",
      "display_url" : "nxhx.org\/maximizing\/"
    } ]
  },
  "geo" : { },
  "id_str" : "734864770793406464",
  "text" : "RT @worrydream: the unintentional irony of peeking at the view count for https:\/\/t.co\/EXxfuE2aj5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/EXxfuE2aj5",
        "expanded_url" : "http:\/\/nxhx.org\/maximizing\/",
        "display_url" : "nxhx.org\/maximizing\/"
      } ]
    },
    "geo" : { },
    "id_str" : "718275987126009856",
    "text" : "the unintentional irony of peeking at the view count for https:\/\/t.co\/EXxfuE2aj5",
    "id" : 718275987126009856,
    "created_at" : "2016-04-08 03:15:14 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 734864770793406464,
  "created_at" : "2016-05-23 21:53:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Marco Bonardo",
      "screen_name" : "mak77",
      "indices" : [ 115, 121 ],
      "id_str" : "6807742",
      "id" : 6807742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/gDCqKWtswD",
      "expanded_url" : "https:\/\/bugzilla.mozilla.org\/show_bug.cgi?id=606655",
      "display_url" : "bugzilla.mozilla.org\/show_bug.cgi?i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734855496788742144",
  "text" : "RT @grvsmth: I'm really kind of pissed that Firefox has been automatically accepting tracking cookies on my behalf @mak77 https:\/\/t.co\/gDCq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marco Bonardo",
        "screen_name" : "mak77",
        "indices" : [ 102, 108 ],
        "id_str" : "6807742",
        "id" : 6807742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/gDCqKWtswD",
        "expanded_url" : "https:\/\/bugzilla.mozilla.org\/show_bug.cgi?id=606655",
        "display_url" : "bugzilla.mozilla.org\/show_bug.cgi?i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734847732775411713",
    "text" : "I'm really kind of pissed that Firefox has been automatically accepting tracking cookies on my behalf @mak77 https:\/\/t.co\/gDCqKWtswD",
    "id" : 734847732775411713,
    "created_at" : "2016-05-23 20:45:26 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 734855496788742144,
  "created_at" : "2016-05-23 21:16:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734853556566687744",
  "geo" : { },
  "id_str" : "734855469014126592",
  "in_reply_to_user_id" : 18602422,
  "text" : "@grvsmth yep looks like it, hmm is Firefox turning into Chrome 2?",
  "id" : 734855469014126592,
  "in_reply_to_status_id" : 734853556566687744,
  "created_at" : "2016-05-23 21:16:11 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Marco Bonardo",
      "screen_name" : "mak77",
      "indices" : [ 9, 15 ],
      "id_str" : "6807742",
      "id" : 6807742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734847732775411713",
  "geo" : { },
  "id_str" : "734853556566687744",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @mak77 just noticed do not track is opt in, is that what this is about?",
  "id" : 734853556566687744,
  "in_reply_to_status_id" : 734847732775411713,
  "created_at" : "2016-05-23 21:08:35 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734822860695457793",
  "geo" : { },
  "id_str" : "734840638898900993",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 yr welcome \uD83D\uDE00 interesting info about pragmatic philosophy",
  "id" : 734840638898900993,
  "in_reply_to_status_id" : 734822860695457793,
  "created_at" : "2016-05-23 20:17:15 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/734727094530363392\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/dEXh1TfgSt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJGZejXIAEYCMl.jpg",
      "id_str" : "734727092726865921",
      "id" : 734727092726865921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJGZejXIAEYCMl.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/dEXh1TfgSt"
    } ],
    "hashtags" : [ {
      "text" : "TEFL",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/hCM9c3DOl1",
      "expanded_url" : "http:\/\/goo.gl\/MghsMw",
      "display_url" : "goo.gl\/MghsMw"
    } ]
  },
  "geo" : { },
  "id_str" : "734818924253089792",
  "text" : "RT @josipa74: From Protest to Policy. Proposal: A grassroots policy platform for change in #TEFL https:\/\/t.co\/hCM9c3DOl1 https:\/\/t.co\/dEXh1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/734727094530363392\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/dEXh1TfgSt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJGZejXIAEYCMl.jpg",
        "id_str" : "734727092726865921",
        "id" : 734727092726865921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJGZejXIAEYCMl.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/dEXh1TfgSt"
      } ],
      "hashtags" : [ {
        "text" : "TEFL",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/hCM9c3DOl1",
        "expanded_url" : "http:\/\/goo.gl\/MghsMw",
        "display_url" : "goo.gl\/MghsMw"
      } ]
    },
    "geo" : { },
    "id_str" : "734727094530363392",
    "text" : "From Protest to Policy. Proposal: A grassroots policy platform for change in #TEFL https:\/\/t.co\/hCM9c3DOl1 https:\/\/t.co\/dEXh1TfgSt",
    "id" : 734727094530363392,
    "created_at" : "2016-05-23 12:46:04 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 734818924253089792,
  "created_at" : "2016-05-23 18:50:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/734792405682147329\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/lN4pdo9IvF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjKByjGWsAAzMyr.jpg",
      "id_str" : "734792394630148096",
      "id" : 734792394630148096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjKByjGWsAAzMyr.jpg",
      "sizes" : [ {
        "h" : 1824,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 1069,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lN4pdo9IvF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734792405682147329",
  "text" : "Le conjugaison francais moderne \uD83D\uDE03 https:\/\/t.co\/lN4pdo9IvF",
  "id" : 734792405682147329,
  "created_at" : "2016-05-23 17:05:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FrancoBritishChamber",
      "screen_name" : "fbcci",
      "indices" : [ 3, 9 ],
      "id_str" : "393944041",
      "id" : 393944041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cannes2016",
      "indices" : [ 103, 114 ]
    }, {
      "text" : "PalmedOr",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/wHl9wT6vxr",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/entertainment-arts-36355313",
      "display_url" : "bbc.com\/news\/entertain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734485559167574016",
  "text" : "RT @fbcci: Breaking : Cannes 2016: Ken Loach's I, Daniel Blake wins Palme d'Or https:\/\/t.co\/wHl9wT6vxr #Cannes2016 #PalmedOr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cannes2016",
        "indices" : [ 92, 103 ]
      }, {
        "text" : "PalmedOr",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/wHl9wT6vxr",
        "expanded_url" : "http:\/\/www.bbc.com\/news\/entertainment-arts-36355313",
        "display_url" : "bbc.com\/news\/entertain\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734479567805677568",
    "text" : "Breaking : Cannes 2016: Ken Loach's I, Daniel Blake wins Palme d'Or https:\/\/t.co\/wHl9wT6vxr #Cannes2016 #PalmedOr",
    "id" : 734479567805677568,
    "created_at" : "2016-05-22 20:22:29 +0000",
    "user" : {
      "name" : "FrancoBritishChamber",
      "screen_name" : "fbcci",
      "protected" : false,
      "id_str" : "393944041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757512843327598592\/GsBGvf_H_normal.jpg",
      "id" : 393944041,
      "verified" : false
    }
  },
  "id" : 734485559167574016,
  "created_at" : "2016-05-22 20:46:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olcay Sert",
      "screen_name" : "SertOlcay",
      "indices" : [ 3, 13 ],
      "id_str" : "1490695945",
      "id" : 1490695945
    }, {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "indices" : [ 30, 45 ],
      "id_str" : "2340183050",
      "id" : 2340183050
    }, {
      "name" : "Edinburgh UniPress",
      "screen_name" : "EdinburghUP",
      "indices" : [ 61, 73 ],
      "id_str" : "118666101",
      "id" : 118666101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 100, 118 ]
    }, {
      "text" : "corpora",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 128, 140 ]
    }, {
      "text" : "free",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "access",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/RaqpgKsSu4",
      "expanded_url" : "http:\/\/www.euppublishing.com\/loi\/cor",
      "display_url" : "euppublishing.com\/loi\/cor"
    } ]
  },
  "geo" : { },
  "id_str" : "734475858287722496",
  "text" : "RT @SertOlcay: Free access to @CorporaJournal in May! Thanks @EdinburghUP ! https:\/\/t.co\/RaqpgKsSu4 #corpuslinguistics #corpora #linguistic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Corpora Journal",
        "screen_name" : "CorporaJournal",
        "indices" : [ 15, 30 ],
        "id_str" : "2340183050",
        "id" : 2340183050
      }, {
        "name" : "Edinburgh UniPress",
        "screen_name" : "EdinburghUP",
        "indices" : [ 46, 58 ],
        "id_str" : "118666101",
        "id" : 118666101
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 85, 103 ]
      }, {
        "text" : "corpora",
        "indices" : [ 104, 112 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 113, 125 ]
      }, {
        "text" : "free",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "access",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/RaqpgKsSu4",
        "expanded_url" : "http:\/\/www.euppublishing.com\/loi\/cor",
        "display_url" : "euppublishing.com\/loi\/cor"
      } ]
    },
    "geo" : { },
    "id_str" : "734461842899279872",
    "text" : "Free access to @CorporaJournal in May! Thanks @EdinburghUP ! https:\/\/t.co\/RaqpgKsSu4 #corpuslinguistics #corpora #linguistics #free #access",
    "id" : 734461842899279872,
    "created_at" : "2016-05-22 19:12:03 +0000",
    "user" : {
      "name" : "Olcay Sert",
      "screen_name" : "SertOlcay",
      "protected" : false,
      "id_str" : "1490695945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663233856309432320\/PwF2jYKq_normal.jpg",
      "id" : 1490695945,
      "verified" : false
    }
  },
  "id" : 734475858287722496,
  "created_at" : "2016-05-22 20:07:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Podant",
      "screen_name" : "ThePodant",
      "indices" : [ 53, 63 ],
      "id_str" : "2439828074",
      "id" : 2439828074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/SDcySA9oDy",
      "expanded_url" : "https:\/\/sayspod.wordpress.com\/2016\/05\/22\/usage-and-efl-publishing\/",
      "display_url" : "sayspod.wordpress.com\/2016\/05\/22\/usa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734356074183151616",
  "text" : "Usage and EFL publishing https:\/\/t.co\/SDcySA9oDy via @ThePodant",
  "id" : 734356074183151616,
  "created_at" : "2016-05-22 12:11:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/NtP7ZiSkvE",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/our-boys-our-values-our-chums.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/our-bo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734188739149344768",
  "text" : "RT @pchallinor: New mudgeonry: Our boys, our values, our chums https:\/\/t.co\/NtP7ZiSkvE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/NtP7ZiSkvE",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/our-boys-our-values-our-chums.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/our-bo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734187710370451456",
    "text" : "New mudgeonry: Our boys, our values, our chums https:\/\/t.co\/NtP7ZiSkvE",
    "id" : 734187710370451456,
    "created_at" : "2016-05-22 01:02:45 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 734188739149344768,
  "created_at" : "2016-05-22 01:06:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/pgAYZmefA0",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv26n-XvC",
      "display_url" : "tmblr.co\/ZuWOEv26n-XvC"
    } ]
  },
  "geo" : { },
  "id_str" : "734177793764950016",
  "text" : "RT @AllThingsLing: A nice interview with the author of Itchy Feet Comic in Babel (click to enlarge text)... https:\/\/t.co\/pgAYZmefA0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/pgAYZmefA0",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv26n-XvC",
        "display_url" : "tmblr.co\/ZuWOEv26n-XvC"
      } ]
    },
    "geo" : { },
    "id_str" : "734141903881572352",
    "text" : "A nice interview with the author of Itchy Feet Comic in Babel (click to enlarge text)... https:\/\/t.co\/pgAYZmefA0",
    "id" : 734141903881572352,
    "created_at" : "2016-05-21 22:00:44 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 734177793764950016,
  "created_at" : "2016-05-22 00:23:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/n1SNjWEPY7",
      "expanded_url" : "http:\/\/fab-efl.com\/page7\/index.html",
      "display_url" : "fab-efl.com\/page7\/index.ht\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "734167770372419585",
  "geo" : { },
  "id_str" : "734174746116542464",
  "in_reply_to_user_id" : 18602422,
  "text" : "@Hada_ELT https:\/\/t.co\/n1SNjWEPY7 the Maxim Forum section shows they seem well read but the slides Download section looks dodgy application",
  "id" : 734174746116542464,
  "in_reply_to_status_id" : 734167770372419585,
  "created_at" : "2016-05-22 00:11:14 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 10, 23 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 24, 40 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 41, 50 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 51, 66 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734082328482447360",
  "geo" : { },
  "id_str" : "734167770372419585",
  "in_reply_to_user_id" : 44631065,
  "text" : "@Hada_ELT @GlenysHanson @getgreatenglish @GemmaELT @thornburyscott application to teaching prob dodgy not neurolinguistics work itself imo",
  "id" : 734167770372419585,
  "in_reply_to_status_id" : 734082328482447360,
  "created_at" : "2016-05-21 23:43:31 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734060785782116352",
  "geo" : { },
  "id_str" : "734078141359128580",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt interesting program esp the Friday",
  "id" : 734078141359128580,
  "in_reply_to_status_id" : 734060785782116352,
  "created_at" : "2016-05-21 17:47:22 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 70, 80 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Fd1SlqU9uH",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/05\/21\/how-do-you-eat-the-worlds-biggest-pizza\/",
      "display_url" : "samkriss.wordpress.com\/2016\/05\/21\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734065156360175620",
  "text" : "How do you eat the world's biggest pizza? https:\/\/t.co\/Fd1SlqU9uH via @sam_kriss",
  "id" : 734065156360175620,
  "created_at" : "2016-05-21 16:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 31, 40 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 41, 50 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734045429583740928",
  "geo" : { },
  "id_str" : "734051402142613504",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish @GemmaELT @Hada_ELT dunno wld need to chase down relevant refs",
  "id" : 734051402142613504,
  "in_reply_to_status_id" : 734045429583740928,
  "created_at" : "2016-05-21 16:01:06 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 0, 11 ],
      "id_str" : "18880320",
      "id" : 18880320
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 12, 20 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 21, 30 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 31, 44 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 45, 54 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 55, 71 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/734042501447856128\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/NHpQXKu61l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci_XvVpWkAAUoQw.jpg",
      "id_str" : "734042472549093376",
      "id" : 734042472549093376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci_XvVpWkAAUoQw.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/NHpQXKu61l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734035552475828224",
  "geo" : { },
  "id_str" : "734042501447856128",
  "in_reply_to_user_id" : 18880320,
  "text" : "@chucksandy @ITLegge @Hada_ELT @GlenysHanson @GemmaELT @getgreatenglish ya gat my grittyside Pilgrim? \uD83D\uDE02 https:\/\/t.co\/NHpQXKu61l",
  "id" : 734042501447856128,
  "in_reply_to_status_id" : 734035552475828224,
  "created_at" : "2016-05-21 15:25:44 +0000",
  "in_reply_to_screen_name" : "chucksandy",
  "in_reply_to_user_id_str" : "18880320",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Guild",
      "screen_name" : "teflguild",
      "indices" : [ 3, 13 ],
      "id_str" : "732157129818316802",
      "id" : 732157129818316802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/ITNO91Dk4S",
      "expanded_url" : "http:\/\/newsguild.org\/node\/3561",
      "display_url" : "newsguild.org\/node\/3561"
    } ]
  },
  "geo" : { },
  "id_str" : "734028425808248832",
  "text" : "RT @teflguild: Chicago ESL teachers vote to unionise https:\/\/t.co\/ITNO91Dk4S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/ITNO91Dk4S",
        "expanded_url" : "http:\/\/newsguild.org\/node\/3561",
        "display_url" : "newsguild.org\/node\/3561"
      } ]
    },
    "geo" : { },
    "id_str" : "734025629943894016",
    "text" : "Chicago ESL teachers vote to unionise https:\/\/t.co\/ITNO91Dk4S",
    "id" : 734025629943894016,
    "created_at" : "2016-05-21 14:18:42 +0000",
    "user" : {
      "name" : "TEFL Guild",
      "screen_name" : "teflguild",
      "protected" : false,
      "id_str" : "732157129818316802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738337519469744128\/m5UrSeot_normal.jpg",
      "id" : 732157129818316802,
      "verified" : false
    }
  },
  "id" : 734028425808248832,
  "created_at" : "2016-05-21 14:29:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 31, 40 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 41, 50 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734027484212039680",
  "geo" : { },
  "id_str" : "734028066662559744",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish @GemmaELT @Hada_ELT no I guess it is more EEG &amp; other neurolinguistic work  supports it",
  "id" : 734028066662559744,
  "in_reply_to_status_id" : 734027484212039680,
  "created_at" : "2016-05-21 14:28:23 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734020315832025088",
  "geo" : { },
  "id_str" : "734021542577852416",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott for certain things under certain circumstances not a blanket 'do not process information ' or 'knowledge is not sym rep'",
  "id" : 734021542577852416,
  "in_reply_to_status_id" : 734020315832025088,
  "created_at" : "2016-05-21 14:02:27 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vander Viana",
      "screen_name" : "vanderviana",
      "indices" : [ 0, 12 ],
      "id_str" : "89592989",
      "id" : 89592989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734001817256873984",
  "geo" : { },
  "id_str" : "734004409101914114",
  "in_reply_to_user_id" : 89592989,
  "text" : "@vanderviana ok thx",
  "id" : 734004409101914114,
  "in_reply_to_status_id" : 734001817256873984,
  "created_at" : "2016-05-21 12:54:22 +0000",
  "in_reply_to_screen_name" : "vanderviana",
  "in_reply_to_user_id_str" : "89592989",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 31, 40 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 41, 50 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734001337151688704",
  "geo" : { },
  "id_str" : "734001759488724992",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish @GemmaELT @Hada_ELT u will have to have a quick look-see \uD83D\uDE03",
  "id" : 734001759488724992,
  "in_reply_to_status_id" : 734001337151688704,
  "created_at" : "2016-05-21 12:43:51 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 17, 30 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 31, 40 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 41, 50 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/EVUtJvoIs3",
      "expanded_url" : "https:\/\/drive.google.com\/file\/d\/0B7FW2BYaBgeiVDc1cTdVVEFua2c\/view?usp=drivesdk",
      "display_url" : "drive.google.com\/file\/d\/0B7FW2B\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "733994041868587009",
  "geo" : { },
  "id_str" : "733994733341663233",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @GlenysHanson @GemmaELT @Hada_ELT here is PDF https:\/\/t.co\/EVUtJvoIs3",
  "id" : 733994733341663233,
  "in_reply_to_status_id" : 733994041868587009,
  "created_at" : "2016-05-21 12:15:56 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 31, 40 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 41, 50 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733991822800871424",
  "geo" : { },
  "id_str" : "733993552506695680",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish @GemmaELT @Hada_ELT I have a PDF will upload somewhere",
  "id" : 733993552506695680,
  "in_reply_to_status_id" : 733991822800871424,
  "created_at" : "2016-05-21 12:11:14 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 0, 16 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733992586826907648",
  "geo" : { },
  "id_str" : "733993313443938304",
  "in_reply_to_user_id" : 726889545883639808,
  "text" : "@LinguistsCorner um it's a joke site",
  "id" : 733993313443938304,
  "in_reply_to_status_id" : 733992586826907648,
  "created_at" : "2016-05-21 12:10:17 +0000",
  "in_reply_to_screen_name" : "LinguistsCorner",
  "in_reply_to_user_id_str" : "726889545883639808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vander Viana",
      "screen_name" : "vanderviana",
      "indices" : [ 3, 15 ],
      "id_str" : "89592989",
      "id" : 89592989
    }, {
      "name" : "British Academy",
      "screen_name" : "britac_news",
      "indices" : [ 50, 62 ],
      "id_str" : "361302333",
      "id" : 361302333
    }, {
      "name" : "Stirling University",
      "screen_name" : "StirUni",
      "indices" : [ 71, 79 ],
      "id_str" : "63072063",
      "id" : 63072063
    }, {
      "name" : "Stirling Research",
      "screen_name" : "Stir_Research",
      "indices" : [ 139, 140 ],
      "id_str" : "2838167147",
      "id" : 2838167147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusEducStir",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/rnv2hyYpvq",
      "expanded_url" : "http:\/\/www.stir.ac.uk\/corpus-linguistics-in-education\/",
      "display_url" : "stir.ac.uk\/corpus-linguis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733993237678043137",
  "text" : "RT @vanderviana: Corpus Linguistics in Education, @britac_news project @StirUni. Free registration at https:\/\/t.co\/rnv2hyYpvq #CorpusEducSt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "British Academy",
        "screen_name" : "britac_news",
        "indices" : [ 33, 45 ],
        "id_str" : "361302333",
        "id" : 361302333
      }, {
        "name" : "Stirling University",
        "screen_name" : "StirUni",
        "indices" : [ 54, 62 ],
        "id_str" : "63072063",
        "id" : 63072063
      }, {
        "name" : "Stirling Research",
        "screen_name" : "Stir_Research",
        "indices" : [ 125, 139 ],
        "id_str" : "2838167147",
        "id" : 2838167147
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusEducStir",
        "indices" : [ 109, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/rnv2hyYpvq",
        "expanded_url" : "http:\/\/www.stir.ac.uk\/corpus-linguistics-in-education\/",
        "display_url" : "stir.ac.uk\/corpus-linguis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733990808194584576",
    "text" : "Corpus Linguistics in Education, @britac_news project @StirUni. Free registration at https:\/\/t.co\/rnv2hyYpvq #CorpusEducStir @Stir_Research",
    "id" : 733990808194584576,
    "created_at" : "2016-05-21 12:00:20 +0000",
    "user" : {
      "name" : "Vander Viana",
      "screen_name" : "vanderviana",
      "protected" : false,
      "id_str" : "89592989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873729143\/Vander_Viana_normal.jpg",
      "id" : 89592989,
      "verified" : false
    }
  },
  "id" : 733993237678043137,
  "created_at" : "2016-05-21 12:09:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vander Viana",
      "screen_name" : "vanderviana",
      "indices" : [ 0, 12 ],
      "id_str" : "89592989",
      "id" : 89592989
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 13, 21 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "British Academy",
      "screen_name" : "britac_news",
      "indices" : [ 22, 34 ],
      "id_str" : "361302333",
      "id" : 361302333
    }, {
      "name" : "Stirling University",
      "screen_name" : "StirUni",
      "indices" : [ 35, 43 ],
      "id_str" : "63072063",
      "id" : 63072063
    }, {
      "name" : "Stirling Research",
      "screen_name" : "Stir_Research",
      "indices" : [ 44, 58 ],
      "id_str" : "2838167147",
      "id" : 2838167147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733990808194584576",
  "geo" : { },
  "id_str" : "733993221093756928",
  "in_reply_to_user_id" : 89592989,
  "text" : "@vanderviana @cgoodey @britac_news @StirUni @Stir_Research hi any chance non-attending event folk can register for blog?",
  "id" : 733993221093756928,
  "in_reply_to_status_id" : 733990808194584576,
  "created_at" : "2016-05-21 12:09:55 +0000",
  "in_reply_to_screen_name" : "vanderviana",
  "in_reply_to_user_id_str" : "89592989",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "indices" : [ 3, 14 ],
      "id_str" : "14800270",
      "id" : 14800270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/GS34LRnYLq",
      "expanded_url" : "http:\/\/s.hbr.org\/27ItzZI",
      "display_url" : "s.hbr.org\/27ItzZI"
    } ]
  },
  "geo" : { },
  "id_str" : "733989453526601730",
  "text" : "RT @HarvardBiz: The notion that you can generalize about a country's work culture is wrong https:\/\/t.co\/GS34LRnYLq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/GS34LRnYLq",
        "expanded_url" : "http:\/\/s.hbr.org\/27ItzZI",
        "display_url" : "s.hbr.org\/27ItzZI"
      } ]
    },
    "geo" : { },
    "id_str" : "733946362874712064",
    "text" : "The notion that you can generalize about a country's work culture is wrong https:\/\/t.co\/GS34LRnYLq",
    "id" : 733946362874712064,
    "created_at" : "2016-05-21 09:03:43 +0000",
    "user" : {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "protected" : false,
      "id_str" : "14800270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600303920125214721\/uy-506Vm_normal.jpg",
      "id" : 14800270,
      "verified" : true
    }
  },
  "id" : 733989453526601730,
  "created_at" : "2016-05-21 11:54:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 17, 26 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 27, 36 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733982448690728961",
  "geo" : { },
  "id_str" : "733988329167945728",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @GemmaELT @Hada_ELT is that about neurolinguistics?",
  "id" : 733988329167945728,
  "in_reply_to_status_id" : 733982448690728961,
  "created_at" : "2016-05-21 11:50:29 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 0, 16 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733984894121091073",
  "geo" : { },
  "id_str" : "733988096715427840",
  "in_reply_to_user_id" : 726889545883639808,
  "text" : "@LinguistsCorner ?",
  "id" : 733988096715427840,
  "in_reply_to_status_id" : 733984894121091073,
  "created_at" : "2016-05-21 11:49:33 +0000",
  "in_reply_to_screen_name" : "LinguistsCorner",
  "in_reply_to_user_id_str" : "726889545883639808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 0, 16 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733983082915737600",
  "geo" : { },
  "id_str" : "733984415823605760",
  "in_reply_to_user_id" : 726889545883639808,
  "text" : "@LinguistsCorner \uD83D\uDE02\uD83D\uDE03\uD83D\uDE09",
  "id" : 733984415823605760,
  "in_reply_to_status_id" : 733983082915737600,
  "created_at" : "2016-05-21 11:34:56 +0000",
  "in_reply_to_screen_name" : "LinguistsCorner",
  "in_reply_to_user_id_str" : "726889545883639808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733962618558382080",
  "geo" : { },
  "id_str" : "733982043944693761",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl dunno he's on Twitter though",
  "id" : 733982043944693761,
  "in_reply_to_status_id" : 733962618558382080,
  "created_at" : "2016-05-21 11:25:30 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733956464532983808",
  "geo" : { },
  "id_str" : "733958195622891523",
  "in_reply_to_user_id" : 44631065,
  "text" : "@Hada_ELT yes they had a meeting we were not invited \uD83D\uDE02",
  "id" : 733958195622891523,
  "in_reply_to_status_id" : 733956464532983808,
  "created_at" : "2016-05-21 09:50:44 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733956745945591808",
  "geo" : { },
  "id_str" : "733957303372816386",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ebefl he is known for \"studying\" Chomsky that led to theories of input",
  "id" : 733957303372816386,
  "in_reply_to_status_id" : 733956745945591808,
  "created_at" : "2016-05-21 09:47:12 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 22, 37 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733945425783336963",
  "geo" : { },
  "id_str" : "733956745945591808",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl have a look at @GeoffreyJordan posts? 'link' is there is sense of underlying assumption I think",
  "id" : 733956745945591808,
  "in_reply_to_status_id" : 733945425783336963,
  "created_at" : "2016-05-21 09:44:59 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 6, 21 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "Federica Formato",
      "screen_name" : "federicalancs",
      "indices" : [ 25, 39 ],
      "id_str" : "39983021",
      "id" : 39983021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/wjtRXRS4uB",
      "expanded_url" : "https:\/\/twitter.com\/LinguistsCorner\/status\/733730370366132226",
      "display_url" : "twitter.com\/LinguistsCorne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733755626388639744",
  "text" : "Maybe @ProfessMoravec or @federicalancs can help? https:\/\/t.co\/wjtRXRS4uB",
  "id" : 733755626388639744,
  "created_at" : "2016-05-20 20:25:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 3, 12 ],
      "id_str" : "6257282",
      "id" : 6257282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/muM9kjHkwX",
      "expanded_url" : "http:\/\/j.mp\/1TrnE3I",
      "display_url" : "j.mp\/1TrnE3I"
    } ]
  },
  "geo" : { },
  "id_str" : "733746749760778241",
  "text" : "RT @trieloff: Bots won't replace apps. Better apps will replace apps. https:\/\/t.co\/muM9kjHkwX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/muM9kjHkwX",
        "expanded_url" : "http:\/\/j.mp\/1TrnE3I",
        "display_url" : "j.mp\/1TrnE3I"
      } ]
    },
    "geo" : { },
    "id_str" : "733685720645292033",
    "text" : "Bots won't replace apps. Better apps will replace apps. https:\/\/t.co\/muM9kjHkwX",
    "id" : 733685720645292033,
    "created_at" : "2016-05-20 15:48:01 +0000",
    "user" : {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "protected" : false,
      "id_str" : "6257282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708651245561585664\/6xwsfP4M_normal.jpg",
      "id" : 6257282,
      "verified" : false
    }
  },
  "id" : 733746749760778241,
  "created_at" : "2016-05-20 19:50:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733740701012353024",
  "geo" : { },
  "id_str" : "733742821925126144",
  "in_reply_to_user_id" : 18602422,
  "text" : "@Glenn_Hadikin in COCA grim-faced, grunt, bark, gruff are top-heavy in fiction section : )",
  "id" : 733742821925126144,
  "in_reply_to_status_id" : 733740701012353024,
  "created_at" : "2016-05-20 19:34:55 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733733370979569664",
  "geo" : { },
  "id_str" : "733740701012353024",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin translation error seems the NK official understood words?",
  "id" : 733740701012353024,
  "in_reply_to_status_id" : 733733370979569664,
  "created_at" : "2016-05-20 19:26:30 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 0, 11 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/iykV6gB7eL",
      "expanded_url" : "https:\/\/twitter.com\/umasslinguistic\/status\/733715270892695552",
      "display_url" : "twitter.com\/umasslinguisti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733727121911250944",
  "in_reply_to_user_id" : 3217729433,
  "text" : "@TeflEquity https:\/\/t.co\/iykV6gB7eL",
  "id" : 733727121911250944,
  "created_at" : "2016-05-20 18:32:32 +0000",
  "in_reply_to_screen_name" : "TeflEquity",
  "in_reply_to_user_id_str" : "3217729433",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 10, 22 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "Asya Ageyska",
      "screen_name" : "cqd_de_mgy",
      "indices" : [ 23, 34 ],
      "id_str" : "2397441097",
      "id" : 2397441097
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 35, 51 ],
      "id_str" : "149239362",
      "id" : 149239362
    }, {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "indices" : [ 52, 66 ],
      "id_str" : "394987109",
      "id" : 394987109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733084847359545344",
  "geo" : { },
  "id_str" : "733650645044056064",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @ELTAdvocacy @cqd_de_mgy @umasslinguistic @MatthewEllman thanks for appreciating my humour folks have a relaxing w\/e : )",
  "id" : 733650645044056064,
  "in_reply_to_status_id" : 733084847359545344,
  "created_at" : "2016-05-20 13:28:39 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Ef69MbauWZ",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/punching-above-our-weight-on.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/punchi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733623032720334848",
  "text" : "RT @pchallinor: New mudgeonry: Punching above our weight on the international stage https:\/\/t.co\/Ef69MbauWZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/Ef69MbauWZ",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/punching-above-our-weight-on.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/punchi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733607709346500608",
    "text" : "New mudgeonry: Punching above our weight on the international stage https:\/\/t.co\/Ef69MbauWZ",
    "id" : 733607709346500608,
    "created_at" : "2016-05-20 10:38:02 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 733623032720334848,
  "created_at" : "2016-05-20 11:38:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 3, 12 ],
      "id_str" : "6257282",
      "id" : 6257282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/DTb25M7ZeX",
      "expanded_url" : "http:\/\/j.mp\/1XCZtCH",
      "display_url" : "j.mp\/1XCZtCH"
    } ]
  },
  "geo" : { },
  "id_str" : "733602892377161728",
  "text" : "RT @trieloff: Sunspring by 32 Tesla K80 GPUs Short film experiment by EndCue... https:\/\/t.co\/DTb25M7ZeX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/DTb25M7ZeX",
        "expanded_url" : "http:\/\/j.mp\/1XCZtCH",
        "display_url" : "j.mp\/1XCZtCH"
      } ]
    },
    "geo" : { },
    "id_str" : "733430807340154881",
    "text" : "Sunspring by 32 Tesla K80 GPUs Short film experiment by EndCue... https:\/\/t.co\/DTb25M7ZeX",
    "id" : 733430807340154881,
    "created_at" : "2016-05-19 22:55:05 +0000",
    "user" : {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "protected" : false,
      "id_str" : "6257282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708651245561585664\/6xwsfP4M_normal.jpg",
      "id" : 6257282,
      "verified" : false
    }
  },
  "id" : 733602892377161728,
  "created_at" : "2016-05-20 10:18:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/EQjzKBkngo",
      "expanded_url" : "https:\/\/twitter.com\/Hada_ELT\/status\/733419638223212544",
      "display_url" : "twitter.com\/Hada_ELT\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733421148017319940",
  "text" : "#languagetrivia  https:\/\/t.co\/EQjzKBkngo",
  "id" : 733421148017319940,
  "created_at" : "2016-05-19 22:16:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 77, 86 ],
      "id_str" : "2729061",
      "id" : 2729061
    }, {
      "name" : "switched",
      "screen_name" : "switch_d",
      "indices" : [ 87, 96 ],
      "id_str" : "263917895",
      "id" : 263917895
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 97, 110 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/iHn9yIDMhl",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-i3f",
      "display_url" : "wp.me\/pSoaD-i3f"
    } ]
  },
  "geo" : { },
  "id_str" : "733419275214422016",
  "text" : "RT @patrickDurusau: FindFace - Party Likes It's 2001 https:\/\/t.co\/iHn9yIDMhl @doctorow @switch_d @YourAnonNews #privacy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 57, 66 ],
        "id_str" : "2729061",
        "id" : 2729061
      }, {
        "name" : "switched",
        "screen_name" : "switch_d",
        "indices" : [ 67, 76 ],
        "id_str" : "263917895",
        "id" : 263917895
      }, {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 77, 90 ],
        "id_str" : "279390084",
        "id" : 279390084
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/iHn9yIDMhl",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-i3f",
        "display_url" : "wp.me\/pSoaD-i3f"
      } ]
    },
    "geo" : { },
    "id_str" : "733402570518110208",
    "text" : "FindFace - Party Likes It's 2001 https:\/\/t.co\/iHn9yIDMhl @doctorow @switch_d @YourAnonNews #privacy",
    "id" : 733402570518110208,
    "created_at" : "2016-05-19 21:02:53 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 733419275214422016,
  "created_at" : "2016-05-19 22:09:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 0, 10 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "The Register",
      "screen_name" : "ElReg",
      "indices" : [ 11, 17 ],
      "id_str" : "35850390",
      "id" : 35850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/cgjQlmhGMl",
      "expanded_url" : "http:\/\/www.ntk.net\/",
      "display_url" : "ntk.net"
    } ]
  },
  "in_reply_to_status_id_str" : "733313309055823872",
  "geo" : { },
  "id_str" : "733417366252453888",
  "in_reply_to_user_id" : 12219232,
  "text" : "@dkernohan @ElReg i wonder where the ntk folk went on to? https:\/\/t.co\/cgjQlmhGMl",
  "id" : 733417366252453888,
  "in_reply_to_status_id" : 733313309055823872,
  "created_at" : "2016-05-19 22:01:41 +0000",
  "in_reply_to_screen_name" : "dkernohan",
  "in_reply_to_user_id_str" : "12219232",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Subasub",
      "screen_name" : "subasubcom",
      "indices" : [ 0, 11 ],
      "id_str" : "4210018815",
      "id" : 4210018815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733332146593632256",
  "geo" : { },
  "id_str" : "733403363501608960",
  "in_reply_to_user_id" : 4210018815,
  "text" : "@subasubcom text difficulty great option : )",
  "id" : 733403363501608960,
  "in_reply_to_status_id" : 733332146593632256,
  "created_at" : "2016-05-19 21:06:02 +0000",
  "in_reply_to_screen_name" : "subasubcom",
  "in_reply_to_user_id_str" : "4210018815",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "The Register",
      "screen_name" : "ElReg",
      "indices" : [ 122, 128 ],
      "id_str" : "35850390",
      "id" : 35850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/cfhBeo2lfZ",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2016\/05\/19\/you_wanted_innovation_we_gave_you_clippy\/",
      "display_url" : "theregister.co.uk\/2016\/05\/19\/you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733397033776762880",
  "text" : "RT @dkernohan: Some refreshing snark on AI and chat-bots from the not-as-good-as-it-used-to-be-but-still-better-than-most @ElReg https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Register",
        "screen_name" : "ElReg",
        "indices" : [ 107, 113 ],
        "id_str" : "35850390",
        "id" : 35850390
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/cfhBeo2lfZ",
        "expanded_url" : "http:\/\/www.theregister.co.uk\/2016\/05\/19\/you_wanted_innovation_we_gave_you_clippy\/",
        "display_url" : "theregister.co.uk\/2016\/05\/19\/you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733313309055823872",
    "text" : "Some refreshing snark on AI and chat-bots from the not-as-good-as-it-used-to-be-but-still-better-than-most @ElReg https:\/\/t.co\/cfhBeo2lfZ",
    "id" : 733313309055823872,
    "created_at" : "2016-05-19 15:08:11 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 733397033776762880,
  "created_at" : "2016-05-19 20:40:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/iCX3U5sdpz",
      "expanded_url" : "http:\/\/twistedsifter.com\/2016\/05\/just-another-brick-in-the-wall-illusion\/",
      "display_url" : "twistedsifter.com\/2016\/05\/just-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733395594367127553",
  "text" : "RT @gsiemens: This enraged me: https:\/\/t.co\/iCX3U5sdpz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/iCX3U5sdpz",
        "expanded_url" : "http:\/\/twistedsifter.com\/2016\/05\/just-another-brick-in-the-wall-illusion\/",
        "display_url" : "twistedsifter.com\/2016\/05\/just-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733341415598514177",
    "text" : "This enraged me: https:\/\/t.co\/iCX3U5sdpz",
    "id" : 733341415598514177,
    "created_at" : "2016-05-19 16:59:52 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 733395594367127553,
  "created_at" : "2016-05-19 20:35:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/733342955604484096\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/GMIzV1Ckgd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1bh4hWYAQhGsu.jpg",
      "id_str" : "733342951997333508",
      "id" : 733342951997333508,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1bh4hWYAQhGsu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GMIzV1Ckgd"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "ESL",
      "indices" : [ 45, 49 ]
    }, {
      "text" : "EFL",
      "indices" : [ 50, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733381646284623874",
  "text" : "RT @josipa74: Darth Vader speaks. #ELT #TEFL #ESL #EFL https:\/\/t.co\/GMIzV1Ckgd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/733342955604484096\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/GMIzV1Ckgd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1bh4hWYAQhGsu.jpg",
        "id_str" : "733342951997333508",
        "id" : 733342951997333508,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1bh4hWYAQhGsu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GMIzV1Ckgd"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 20, 24 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 25, 30 ]
      }, {
        "text" : "ESL",
        "indices" : [ 31, 35 ]
      }, {
        "text" : "EFL",
        "indices" : [ 36, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733342955604484096",
    "text" : "Darth Vader speaks. #ELT #TEFL #ESL #EFL https:\/\/t.co\/GMIzV1Ckgd",
    "id" : 733342955604484096,
    "created_at" : "2016-05-19 17:06:00 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 733381646284623874,
  "created_at" : "2016-05-19 19:39:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/gvSghoBjrP",
      "expanded_url" : "http:\/\/wp.me\/prpcD-29s",
      "display_url" : "wp.me\/prpcD-29s"
    } ]
  },
  "geo" : { },
  "id_str" : "733359418302205956",
  "text" : "De-Legitimization - https:\/\/t.co\/gvSghoBjrP",
  "id" : 733359418302205956,
  "created_at" : "2016-05-19 18:11:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 0, 12 ],
      "id_str" : "31179355",
      "id" : 31179355
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 13, 24 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733269698335367169",
  "geo" : { },
  "id_str" : "733271941948276736",
  "in_reply_to_user_id" : 31179355,
  "text" : "@mattledding @hughdellar i can't unsee that now",
  "id" : 733271941948276736,
  "in_reply_to_status_id" : 733269698335367169,
  "created_at" : "2016-05-19 12:23:49 +0000",
  "in_reply_to_screen_name" : "mattledding",
  "in_reply_to_user_id_str" : "31179355",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Subasub",
      "screen_name" : "subasubcom",
      "indices" : [ 0, 11 ],
      "id_str" : "4210018815",
      "id" : 4210018815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733233676004302849",
  "geo" : { },
  "id_str" : "733243701368131584",
  "in_reply_to_user_id" : 18602422,
  "text" : "@subasubcom another feature suggestion - option to list results say alphabetically or new to old films etc",
  "id" : 733243701368131584,
  "in_reply_to_status_id" : 733233676004302849,
  "created_at" : "2016-05-19 10:31:36 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Subasub",
      "screen_name" : "subasubcom",
      "indices" : [ 0, 11 ],
      "id_str" : "4210018815",
      "id" : 4210018815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733242083964792832",
  "geo" : { },
  "id_str" : "733242491156221952",
  "in_reply_to_user_id" : 4210018815,
  "text" : "@subasubcom great : )",
  "id" : 733242491156221952,
  "in_reply_to_status_id" : 733242083964792832,
  "created_at" : "2016-05-19 10:26:47 +0000",
  "in_reply_to_screen_name" : "subasubcom",
  "in_reply_to_user_id_str" : "4210018815",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Subasub",
      "screen_name" : "subasubcom",
      "indices" : [ 0, 11 ],
      "id_str" : "4210018815",
      "id" : 4210018815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733240362316255232",
  "geo" : { },
  "id_str" : "733240823316353024",
  "in_reply_to_user_id" : 4210018815,
  "text" : "@subasubcom save results to flashcard? have option to display just one line so can see more examples without scrolling?",
  "id" : 733240823316353024,
  "in_reply_to_status_id" : 733240362316255232,
  "created_at" : "2016-05-19 10:20:09 +0000",
  "in_reply_to_screen_name" : "subasubcom",
  "in_reply_to_user_id_str" : "4210018815",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin",
      "screen_name" : "y2kshack",
      "indices" : [ 3, 12 ],
      "id_str" : "16866659",
      "id" : 16866659
    }, {
      "name" : "The Canary",
      "screen_name" : "TheCanarySays",
      "indices" : [ 129, 140 ],
      "id_str" : "3314289248",
      "id" : 3314289248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/3l2KjcvVQM",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/05\/18\/everyone-watches-queens-speech-tory-electoral-fraud-scandal-growing\/",
      "display_url" : "thecanary.co\/2016\/05\/18\/eve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733234335592153088",
  "text" : "RT @y2kshack: While everyone watches the Queen\u2019s speech, the Tory electoral fraud scandal is growing https:\/\/t.co\/3l2KjcvVQM via @thecanary\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Canary",
        "screen_name" : "TheCanarySays",
        "indices" : [ 115, 129 ],
        "id_str" : "3314289248",
        "id" : 3314289248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/3l2KjcvVQM",
        "expanded_url" : "http:\/\/www.thecanary.co\/2016\/05\/18\/everyone-watches-queens-speech-tory-electoral-fraud-scandal-growing\/",
        "display_url" : "thecanary.co\/2016\/05\/18\/eve\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733032946932781057",
    "text" : "While everyone watches the Queen\u2019s speech, the Tory electoral fraud scandal is growing https:\/\/t.co\/3l2KjcvVQM via @thecanarysays",
    "id" : 733032946932781057,
    "created_at" : "2016-05-18 20:34:08 +0000",
    "user" : {
      "name" : "Colin",
      "screen_name" : "y2kshack",
      "protected" : false,
      "id_str" : "16866659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768376949840326656\/72wyiktY_normal.jpg",
      "id" : 16866659,
      "verified" : false
    }
  },
  "id" : 733234335592153088,
  "created_at" : "2016-05-19 09:54:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Subasub",
      "screen_name" : "subasubcom",
      "indices" : [ 0, 11 ],
      "id_str" : "4210018815",
      "id" : 4210018815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733233676004302849",
  "in_reply_to_user_id" : 4210018815,
  "text" : "@subasubcom hi neat site any future features planned for it?",
  "id" : 733233676004302849,
  "created_at" : "2016-05-19 09:51:45 +0000",
  "in_reply_to_screen_name" : "subasubcom",
  "in_reply_to_user_id_str" : "4210018815",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 0, 10 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "Mark Buckland",
      "screen_name" : "carbunclebuck",
      "indices" : [ 11, 25 ],
      "id_str" : "2288554922",
      "id" : 2288554922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733216274042355712",
  "geo" : { },
  "id_str" : "733229380009365504",
  "in_reply_to_user_id" : 295968758,
  "text" : "@nakanotim @carbunclebuck i just had a look in replies i see what u mean :\/",
  "id" : 733229380009365504,
  "in_reply_to_status_id" : 733216274042355712,
  "created_at" : "2016-05-19 09:34:41 +0000",
  "in_reply_to_screen_name" : "nakanotim",
  "in_reply_to_user_id_str" : "295968758",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben nazer",
      "screen_name" : "BenCanTeach",
      "indices" : [ 0, 12 ],
      "id_str" : "729405603873951745",
      "id" : 729405603873951745
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 13, 24 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733215673120378880",
  "geo" : { },
  "id_str" : "733228292355063808",
  "in_reply_to_user_id" : 729405603873951745,
  "text" : "@BenCanTeach @leoselivan it'll be interesting to see how many continue to use original interface :)",
  "id" : 733228292355063808,
  "in_reply_to_status_id" : 733215673120378880,
  "created_at" : "2016-05-19 09:30:22 +0000",
  "in_reply_to_screen_name" : "BenCanTeach",
  "in_reply_to_user_id_str" : "729405603873951745",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 0, 16 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733218366354272256",
  "geo" : { },
  "id_str" : "733227250078863364",
  "in_reply_to_user_id" : 726889545883639808,
  "text" : "@LinguistsCorner thanks for positive feedback v much appreciate it : )",
  "id" : 733227250078863364,
  "in_reply_to_status_id" : 733218366354272256,
  "created_at" : "2016-05-19 09:26:13 +0000",
  "in_reply_to_screen_name" : "LinguistsCorner",
  "in_reply_to_user_id_str" : "726889545883639808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Buckland",
      "screen_name" : "carbunclebuck",
      "indices" : [ 3, 17 ],
      "id_str" : "2288554922",
      "id" : 2288554922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733211163744436224",
  "text" : "RT @carbunclebuck: First they came for the disabled and I did not speak out. Then teachers, doctors. Then they came for online pasta recipe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732501721151234048",
    "text" : "First they came for the disabled and I did not speak out. Then teachers, doctors. Then they came for online pasta recipes and I was furious.",
    "id" : 732501721151234048,
    "created_at" : "2016-05-17 09:23:14 +0000",
    "user" : {
      "name" : "Mark Buckland",
      "screen_name" : "carbunclebuck",
      "protected" : false,
      "id_str" : "2288554922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687567178233737216\/MJmL_KP__normal.jpg",
      "id" : 2288554922,
      "verified" : false
    }
  },
  "id" : 733211163744436224,
  "created_at" : "2016-05-19 08:22:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 12, 19 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733199817313296384",
  "geo" : { },
  "id_str" : "733209030211084288",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @WordLo very neat thx : )",
  "id" : 733209030211084288,
  "in_reply_to_status_id" : 733199817313296384,
  "created_at" : "2016-05-19 08:13:49 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/733084847359545344\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/xYNAlkQAJX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CixwyHDWkAAAJWI.jpg",
      "id_str" : "733084845543428096",
      "id" : 733084845543428096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CixwyHDWkAAAJWI.jpg",
      "sizes" : [ {
        "h" : 690,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1344,
        "resize" : "fit",
        "w" : 1994
      } ],
      "display_url" : "pic.twitter.com\/xYNAlkQAJX"
    } ],
    "hashtags" : [ {
      "text" : "SiliconValley",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "ParksandRec",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733084847359545344",
  "text" : "#SiliconValley geometric shape meets #ParksandRec geometric shape, look away now! https:\/\/t.co\/xYNAlkQAJX",
  "id" : 733084847359545344,
  "created_at" : "2016-05-19 00:00:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "44631065",
      "id" : 44631065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733063956374376452",
  "geo" : { },
  "id_str" : "733065501061058560",
  "in_reply_to_user_id" : 44631065,
  "text" : "@Hada_ELT i guess it can join the queue of worries :\/",
  "id" : 733065501061058560,
  "in_reply_to_status_id" : 733063956374376452,
  "created_at" : "2016-05-18 22:43:29 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/El2ktOGWr8",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv26f9dhF",
      "display_url" : "tmblr.co\/ZuWOEv26f9dhF"
    } ]
  },
  "geo" : { },
  "id_str" : "733065202208542721",
  "text" : "RT @AllThingsLing: \uD83D\uDCF9 John Barrowman talks about Scottish accents, American accents, and codeswitching in this video from... https:\/\/t.co\/El\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/El2ktOGWr8",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv26f9dhF",
        "display_url" : "tmblr.co\/ZuWOEv26f9dhF"
      } ]
    },
    "geo" : { },
    "id_str" : "733054816214212608",
    "text" : "\uD83D\uDCF9 John Barrowman talks about Scottish accents, American accents, and codeswitching in this video from... https:\/\/t.co\/El2ktOGWr8",
    "id" : 733054816214212608,
    "created_at" : "2016-05-18 22:01:02 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 733065202208542721,
  "created_at" : "2016-05-18 22:42:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 10, 26 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729052385666945024",
  "geo" : { },
  "id_str" : "733063852867366913",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @LinguistsCorner thanks for RT : )",
  "id" : 733063852867366913,
  "in_reply_to_status_id" : 729052385666945024,
  "created_at" : "2016-05-18 22:36:56 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "indices" : [ 3, 19 ],
      "id_str" : "2381084346",
      "id" : 2381084346
    }, {
      "name" : "HoLLT.net",
      "screen_name" : "HoLLTnet",
      "indices" : [ 127, 136 ],
      "id_str" : "3012902321",
      "id" : 3012902321
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 137, 140 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELThistory",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/sFJaMjOVCw",
      "expanded_url" : "http:\/\/bit.ly\/22ICg3V",
      "display_url" : "bit.ly\/22ICg3V"
    } ]
  },
  "geo" : { },
  "id_str" : "733057675890581504",
  "text" : "RT @RichardSmithELT: About A.S. Hornby (1898-1978): 'The Man Who Made Dictionaries' (OUP) https:\/\/t.co\/sFJaMjOVCw  #ELThistory @holltnet @T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HoLLT.net",
        "screen_name" : "HoLLTnet",
        "indices" : [ 106, 115 ],
        "id_str" : "3012902321",
        "id" : 3012902321
      }, {
        "name" : "TEFLology Podcast",
        "screen_name" : "TEFLology",
        "indices" : [ 116, 126 ],
        "id_str" : "2882870444",
        "id" : 2882870444
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELThistory",
        "indices" : [ 94, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/sFJaMjOVCw",
        "expanded_url" : "http:\/\/bit.ly\/22ICg3V",
        "display_url" : "bit.ly\/22ICg3V"
      } ]
    },
    "geo" : { },
    "id_str" : "727881130897231873",
    "text" : "About A.S. Hornby (1898-1978): 'The Man Who Made Dictionaries' (OUP) https:\/\/t.co\/sFJaMjOVCw  #ELThistory @holltnet @TEFLology",
    "id" : 727881130897231873,
    "created_at" : "2016-05-04 15:22:39 +0000",
    "user" : {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "protected" : false,
      "id_str" : "2381084346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442784228007112704\/0oKivCvx_normal.jpeg",
      "id" : 2381084346,
      "verified" : false
    }
  },
  "id" : 733057675890581504,
  "created_at" : "2016-05-18 22:12:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Coaching",
      "screen_name" : "EfficientLangua",
      "indices" : [ 0, 16 ],
      "id_str" : "371868707",
      "id" : 371868707
    }, {
      "name" : "Jane",
      "screen_name" : "Mentorjane4u",
      "indices" : [ 17, 30 ],
      "id_str" : "706959324963282944",
      "id" : 706959324963282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732644486019305472",
  "geo" : { },
  "id_str" : "733042687910252544",
  "in_reply_to_user_id" : 371868707,
  "text" : "@EfficientLangua @Mentorjane4u interesting tweet...",
  "id" : 733042687910252544,
  "in_reply_to_status_id" : 732644486019305472,
  "created_at" : "2016-05-18 21:12:50 +0000",
  "in_reply_to_screen_name" : "EfficientLangua",
  "in_reply_to_user_id_str" : "371868707",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Shaffer",
      "screen_name" : "krisshaffer",
      "indices" : [ 0, 12 ],
      "id_str" : "136476512",
      "id" : 136476512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733034499420758016",
  "geo" : { },
  "id_str" : "733035343604256768",
  "in_reply_to_user_id" : 136476512,
  "text" : "@krisshaffer great thx",
  "id" : 733035343604256768,
  "in_reply_to_status_id" : 733034499420758016,
  "created_at" : "2016-05-18 20:43:39 +0000",
  "in_reply_to_screen_name" : "krisshaffer",
  "in_reply_to_user_id_str" : "136476512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    }, {
      "name" : "Kris Shaffer",
      "screen_name" : "krisshaffer",
      "indices" : [ 78, 90 ],
      "id_str" : "136476512",
      "id" : 136476512
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/732937957124907008\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/kRM54TYwru",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CivrL-5UUAEc78E.jpg",
      "id_str" : "732937955472330753",
      "id" : 732937955472330753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CivrL-5UUAEc78E.jpg",
      "sizes" : [ {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kRM54TYwru"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/pHh0OaclEB",
      "expanded_url" : "http:\/\/bit.ly\/1YC1tJB",
      "display_url" : "bit.ly\/1YC1tJB"
    } ]
  },
  "geo" : { },
  "id_str" : "733031948331933697",
  "text" : "RT @wiobyrne: Dr. Seuss, statistics, and the science of learning to read - by @krisshaffer https:\/\/t.co\/pHh0OaclEB https:\/\/t.co\/kRM54TYwru",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kris Shaffer",
        "screen_name" : "krisshaffer",
        "indices" : [ 64, 76 ],
        "id_str" : "136476512",
        "id" : 136476512
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/732937957124907008\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/kRM54TYwru",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CivrL-5UUAEc78E.jpg",
        "id_str" : "732937955472330753",
        "id" : 732937955472330753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CivrL-5UUAEc78E.jpg",
        "sizes" : [ {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kRM54TYwru"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/pHh0OaclEB",
        "expanded_url" : "http:\/\/bit.ly\/1YC1tJB",
        "display_url" : "bit.ly\/1YC1tJB"
      } ]
    },
    "geo" : { },
    "id_str" : "732937957124907008",
    "text" : "Dr. Seuss, statistics, and the science of learning to read - by @krisshaffer https:\/\/t.co\/pHh0OaclEB https:\/\/t.co\/kRM54TYwru",
    "id" : 732937957124907008,
    "created_at" : "2016-05-18 14:16:40 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 733031948331933697,
  "created_at" : "2016-05-18 20:30:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Shaffer",
      "screen_name" : "krisshaffer",
      "indices" : [ 0, 12 ],
      "id_str" : "136476512",
      "id" : 136476512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733027019018129408",
  "in_reply_to_user_id" : 136476512,
  "text" : "@krisshaffer cool post about Seuss and forgetting curve, how did you plot the csv files in R? thx!",
  "id" : 733027019018129408,
  "created_at" : "2016-05-18 20:10:34 +0000",
  "in_reply_to_screen_name" : "krisshaffer",
  "in_reply_to_user_id_str" : "136476512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733006191543095296",
  "geo" : { },
  "id_str" : "733006588739485696",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C h sorry forgot to put note, the graphic of not drowning in social media is linked to your chat i believe",
  "id" : 733006588739485696,
  "in_reply_to_status_id" : 733006191543095296,
  "created_at" : "2016-05-18 18:49:24 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/LjUdOTGlSz",
      "expanded_url" : "https:\/\/twitter.com\/Tom_IHBCN\/status\/733003893844660225",
      "display_url" : "twitter.com\/Tom_IHBCN\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733005928757395456",
  "text" : "#ELTchat  https:\/\/t.co\/LjUdOTGlSz",
  "id" : 733005928757395456,
  "created_at" : "2016-05-18 18:46:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annabelle Lukin",
      "screen_name" : "annabellelukin",
      "indices" : [ 3, 18 ],
      "id_str" : "86030794",
      "id" : 86030794
    }, {
      "name" : "Macquarie University",
      "screen_name" : "Macquarie_Uni",
      "indices" : [ 34, 48 ],
      "id_str" : "34464407",
      "id" : 34464407
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/annabellelukin\/status\/732378656404705280\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/A2WjELe3ad",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CinugXIUUAAn9_f.jpg",
      "id_str" : "732378654156541952",
      "id" : 732378654156541952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CinugXIUUAAn9_f.jpg",
      "sizes" : [ {
        "h" : 844,
        "resize" : "fit",
        "w" : 1756
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/A2WjELe3ad"
    } ],
    "hashtags" : [ {
      "text" : "digitalhumanities",
      "indices" : [ 52, 70 ]
    }, {
      "text" : "ideology",
      "indices" : [ 71, 80 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 81, 99 ]
    }, {
      "text" : "sysfunc",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yZlV8EP6zN",
      "expanded_url" : "http:\/\/prezi.com\/bfmwd9ih-zkv\/?utm_campaign=share&utm_medium=copy&rc=ex0share",
      "display_url" : "prezi.com\/bfmwd9ih-zkv\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732966919385567232",
  "text" : "RT @annabellelukin: My talk today @Macquarie_Uni on #digitalhumanities #ideology #corpuslinguistics #sysfunc https:\/\/t.co\/yZlV8EP6zN https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Macquarie University",
        "screen_name" : "Macquarie_Uni",
        "indices" : [ 14, 28 ],
        "id_str" : "34464407",
        "id" : 34464407
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/annabellelukin\/status\/732378656404705280\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/A2WjELe3ad",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CinugXIUUAAn9_f.jpg",
        "id_str" : "732378654156541952",
        "id" : 732378654156541952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CinugXIUUAAn9_f.jpg",
        "sizes" : [ {
          "h" : 844,
          "resize" : "fit",
          "w" : 1756
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 492,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/A2WjELe3ad"
      } ],
      "hashtags" : [ {
        "text" : "digitalhumanities",
        "indices" : [ 32, 50 ]
      }, {
        "text" : "ideology",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 61, 79 ]
      }, {
        "text" : "sysfunc",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/yZlV8EP6zN",
        "expanded_url" : "http:\/\/prezi.com\/bfmwd9ih-zkv\/?utm_campaign=share&utm_medium=copy&rc=ex0share",
        "display_url" : "prezi.com\/bfmwd9ih-zkv\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732378656404705280",
    "text" : "My talk today @Macquarie_Uni on #digitalhumanities #ideology #corpuslinguistics #sysfunc https:\/\/t.co\/yZlV8EP6zN https:\/\/t.co\/A2WjELe3ad",
    "id" : 732378656404705280,
    "created_at" : "2016-05-17 01:14:13 +0000",
    "user" : {
      "name" : "Annabelle Lukin",
      "screen_name" : "annabellelukin",
      "protected" : false,
      "id_str" : "86030794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468614248264773632\/SxVE4QWx_normal.jpeg",
      "id" : 86030794,
      "verified" : false
    }
  },
  "id" : 732966919385567232,
  "created_at" : "2016-05-18 16:11:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 13, 24 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732961972241719296",
  "geo" : { },
  "id_str" : "732963943560417280",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @leoselivan Mark Davies does rapid resolutions if you spot anything awry; that nagware though...",
  "id" : 732963943560417280,
  "in_reply_to_status_id" : 732961972241719296,
  "created_at" : "2016-05-18 15:59:56 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/AAPrpGTaFw",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/changemyview",
      "display_url" : "reddit.com\/r\/changemyview"
    } ]
  },
  "geo" : { },
  "id_str" : "732926487523811328",
  "text" : "ChangeMyView sub-reddit https:\/\/t.co\/AAPrpGTaFw potential for debate classes",
  "id" : 732926487523811328,
  "created_at" : "2016-05-18 13:31:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 34, 47 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/RCbpngI6yS",
      "expanded_url" : "https:\/\/shar.es\/1d2NAV",
      "display_url" : "shar.es\/1d2NAV"
    } ]
  },
  "geo" : { },
  "id_str" : "732915881035063297",
  "text" : "RT @NicolaPrentis: My article for @mental_floss 5 Things That Make English Difficult for Foreigners to Learn https:\/\/t.co\/RCbpngI6yS #ELT i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mental Floss",
        "screen_name" : "mental_floss",
        "indices" : [ 15, 28 ],
        "id_str" : "20065936",
        "id" : 20065936
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 114, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/RCbpngI6yS",
        "expanded_url" : "https:\/\/shar.es\/1d2NAV",
        "display_url" : "shar.es\/1d2NAV"
      } ]
    },
    "geo" : { },
    "id_str" : "732914110652907520",
    "text" : "My article for @mental_floss 5 Things That Make English Difficult for Foreigners to Learn https:\/\/t.co\/RCbpngI6yS #ELT in the wider world :)",
    "id" : 732914110652907520,
    "created_at" : "2016-05-18 12:41:55 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 732915881035063297,
  "created_at" : "2016-05-18 12:48:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732896718325485568",
  "geo" : { },
  "id_str" : "732909775726518272",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT thanks seems some new features need some settling down period",
  "id" : 732909775726518272,
  "in_reply_to_status_id" : 732896718325485568,
  "created_at" : "2016-05-18 12:24:41 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digped",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "edtech",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "rhizo16",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "resilience16",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/YcyzLJkq08",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2016\/knowledge-abundance-and-digital-pedagogy\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2016\/knowledge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732890102867857408",
  "text" : "RT @tornhalves: Is knowledge more abundant than ignorance? Hectoring thoughts on #digped #edtech and #rhizo16 but not #resilience16 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "digped",
        "indices" : [ 65, 72 ]
      }, {
        "text" : "edtech",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "rhizo16",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "resilience16",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/YcyzLJkq08",
        "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2016\/knowledge-abundance-and-digital-pedagogy\/",
        "display_url" : "digitalcounterrevolution.co.uk\/2016\/knowledge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732540391254331392",
    "text" : "Is knowledge more abundant than ignorance? Hectoring thoughts on #digped #edtech and #rhizo16 but not #resilience16 https:\/\/t.co\/YcyzLJkq08",
    "id" : 732540391254331392,
    "created_at" : "2016-05-17 11:56:53 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 732890102867857408,
  "created_at" : "2016-05-18 11:06:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 93, 108 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/RrENMvl1St",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/05\/conservatives-will-protected-election-fraud\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732880146273849345",
  "text" : "The Conservatives Will Be Protected From Their Election Fraud: https:\/\/t.co\/RrENMvl1St - via:@CraigMurrayOrg",
  "id" : 732880146273849345,
  "created_at" : "2016-05-18 10:26:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 3, 12 ],
      "id_str" : "6257282",
      "id" : 6257282
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 136, 140 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/TFbfl7aCfM",
      "expanded_url" : "http:\/\/j.mp\/1TkSYBf",
      "display_url" : "j.mp\/1TkSYBf"
    } ]
  },
  "geo" : { },
  "id_str" : "732708072813174786",
  "text" : "RT @trieloff: A guy just transcribed 30 years of for-rent ads. Here\u2019s what it taught us about housing prices https:\/\/t.co\/TFbfl7aCfM on @Me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 122, 129 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/TFbfl7aCfM",
        "expanded_url" : "http:\/\/j.mp\/1TkSYBf",
        "display_url" : "j.mp\/1TkSYBf"
      } ]
    },
    "geo" : { },
    "id_str" : "732706011614711808",
    "text" : "A guy just transcribed 30 years of for-rent ads. Here\u2019s what it taught us about housing prices https:\/\/t.co\/TFbfl7aCfM on @Medium",
    "id" : 732706011614711808,
    "created_at" : "2016-05-17 22:55:00 +0000",
    "user" : {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "protected" : false,
      "id_str" : "6257282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708651245561585664\/6xwsfP4M_normal.jpg",
      "id" : 6257282,
      "verified" : false
    }
  },
  "id" : 732708072813174786,
  "created_at" : "2016-05-17 23:03:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732560630209781760",
  "geo" : { },
  "id_str" : "732687411101237248",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code ok thanks, any chance of including a media server in future version of PB for android? i recall u did some experiments once?",
  "id" : 732687411101237248,
  "in_reply_to_status_id" : 732560630209781760,
  "created_at" : "2016-05-17 21:41:06 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/3J84VsXbzt",
      "expanded_url" : "http:\/\/blog.press.umich.edu\/elt\/2016\/05\/17\/listening-myths-five-years-on\/",
      "display_url" : "blog.press.umich.edu\/elt\/2016\/05\/17\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732685642350616576",
  "text" : "LISTENING MYTHS Five Years On\nhttps:\/\/t.co\/3J84VsXbzt",
  "id" : 732685642350616576,
  "created_at" : "2016-05-17 21:34:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EncodeAnt",
      "indices" : [ 70, 80 ]
    }, {
      "text" : "ProtAnt",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "TagAnt",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "FireAnt",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/kkZErZt7sq",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html",
      "display_url" : "laurenceanthony.net\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "732637049942093824",
  "text" : "RT @antlabjp: For those interested, I've now released new versions of #EncodeAnt, #ProtAnt, #TagAnt, and #FireAnt for Mac OS X. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EncodeAnt",
        "indices" : [ 56, 66 ]
      }, {
        "text" : "ProtAnt",
        "indices" : [ 68, 76 ]
      }, {
        "text" : "TagAnt",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "FireAnt",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/kkZErZt7sq",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html",
        "display_url" : "laurenceanthony.net\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "732633641767964673",
    "text" : "For those interested, I've now released new versions of #EncodeAnt, #ProtAnt, #TagAnt, and #FireAnt for Mac OS X. https:\/\/t.co\/kkZErZt7sq",
    "id" : 732633641767964673,
    "created_at" : "2016-05-17 18:07:26 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 732637049942093824,
  "created_at" : "2016-05-17 18:20:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/uBeUH7el7v",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/may\/17\/farage-accuses-mandelson-and-labour-of-rubbing-our-noses-in-diversity",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732636952470663168",
  "text" : "RT @pchallinor: However racist the racist yap of a racist may be, s\/he never means to cause offence and is always the injured party https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/uBeUH7el7v",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/may\/17\/farage-accuses-mandelson-and-labour-of-rubbing-our-noses-in-diversity",
        "display_url" : "theguardian.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732635965060206592",
    "text" : "However racist the racist yap of a racist may be, s\/he never means to cause offence and is always the injured party https:\/\/t.co\/uBeUH7el7v",
    "id" : 732635965060206592,
    "created_at" : "2016-05-17 18:16:40 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 732636952470663168,
  "created_at" : "2016-05-17 18:20:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 105, 121 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/U5iNuMuJfp",
      "expanded_url" : "https:\/\/codeactsineducation.wordpress.com\/2016\/05\/17\/ai-cognitive-systems-education\/",
      "display_url" : "codeactsineducation.wordpress.com\/2016\/05\/17\/ai-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732603045981392896",
  "text" : "Artificial intelligence, cognitive systems and biosocial spaces of education https:\/\/t.co\/U5iNuMuJfp via @wordpressdotcom",
  "id" : 732603045981392896,
  "created_at" : "2016-05-17 16:05:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Caren",
      "screen_name" : "HaphazardSoc",
      "indices" : [ 3, 16 ],
      "id_str" : "594565064",
      "id" : 594565064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/zqHeG1KtnL",
      "expanded_url" : "https:\/\/www.insidehighered.com\/quicktakes\/2016\/05\/17\/elsevier-acquires-social-science-repository-ssrn",
      "display_url" : "insidehighered.com\/quicktakes\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732533924941959168",
  "text" : "RT @HaphazardSoc: Elsevier bought SSRN. https:\/\/t.co\/zqHeG1KtnL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/zqHeG1KtnL",
        "expanded_url" : "https:\/\/www.insidehighered.com\/quicktakes\/2016\/05\/17\/elsevier-acquires-social-science-repository-ssrn",
        "display_url" : "insidehighered.com\/quicktakes\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732519896106536960",
    "text" : "Elsevier bought SSRN. https:\/\/t.co\/zqHeG1KtnL",
    "id" : 732519896106536960,
    "created_at" : "2016-05-17 10:35:27 +0000",
    "user" : {
      "name" : "Neal Caren",
      "screen_name" : "HaphazardSoc",
      "protected" : false,
      "id_str" : "594565064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3162996313\/37c1a44ac3ecf2e435e3a8d3c959bfa7_normal.png",
      "id" : 594565064,
      "verified" : false
    }
  },
  "id" : 732533924941959168,
  "created_at" : "2016-05-17 11:31:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/pk2WkeOczz",
      "expanded_url" : "https:\/\/forum.piratebox.cc\/read.php?15,16401",
      "display_url" : "forum.piratebox.cc\/read.php?15,16\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732506722741432320",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code hi any further tips to getting media server onto piratebox for android? https:\/\/t.co\/pk2WkeOczz tried yaacc no luck",
  "id" : 732506722741432320,
  "created_at" : "2016-05-17 09:43:06 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 3, 15 ],
      "id_str" : "31179355",
      "id" : 31179355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732494016042799104",
  "text" : "RT @mattledding: If anyone with upper intermediate English or higher wants to Beta Test a one minute daily listening task, let me know. DM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732483283959746564",
    "text" : "If anyone with upper intermediate English or higher wants to Beta Test a one minute daily listening task, let me know. DM me.",
    "id" : 732483283959746564,
    "created_at" : "2016-05-17 08:09:58 +0000",
    "user" : {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "protected" : false,
      "id_str" : "31179355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1126573271\/mattagotchi_normal.png",
      "id" : 31179355,
      "verified" : false
    }
  },
  "id" : 732494016042799104,
  "created_at" : "2016-05-17 08:52:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 3, 14 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/XqUYys6pIr",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/16CDTVt4BQycDMHEsr4ed5WiN-TPmr_JBUhhdw1_AdzI\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/16CDTV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732493035980775425",
  "text" : "RT @bethcagnol: 13 of my EFL stds are researching subjects. Please fill out Sabrine's survey on \"keeping traditions\". https:\/\/t.co\/XqUYys6p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/XqUYys6pIr",
        "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/16CDTVt4BQycDMHEsr4ed5WiN-TPmr_JBUhhdw1_AdzI\/viewform",
        "display_url" : "docs.google.com\/forms\/d\/16CDTV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732492707923255296",
    "text" : "13 of my EFL stds are researching subjects. Please fill out Sabrine's survey on \"keeping traditions\". https:\/\/t.co\/XqUYys6pIr",
    "id" : 732492707923255296,
    "created_at" : "2016-05-17 08:47:25 +0000",
    "user" : {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "protected" : false,
      "id_str" : "27641720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425969412265373696\/jdqAse11_normal.jpeg",
      "id" : 27641720,
      "verified" : false
    }
  },
  "id" : 732493035980775425,
  "created_at" : "2016-05-17 08:48:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 3, 14 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/3pQ0G8C9if",
      "expanded_url" : "http:\/\/goo.gl\/U7tHtv",
      "display_url" : "goo.gl\/U7tHtv"
    } ]
  },
  "geo" : { },
  "id_str" : "732492214488567808",
  "text" : "RT @evanfrendo: New blog post about last 30 yrs in business English research. Have I left anyone important out?https:\/\/t.co\/3pQ0G8C9if #bes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 119, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/3pQ0G8C9if",
        "expanded_url" : "http:\/\/goo.gl\/U7tHtv",
        "display_url" : "goo.gl\/U7tHtv"
      } ]
    },
    "geo" : { },
    "id_str" : "732459539707006982",
    "text" : "New blog post about last 30 yrs in business English research. Have I left anyone important out?https:\/\/t.co\/3pQ0G8C9if #besig",
    "id" : 732459539707006982,
    "created_at" : "2016-05-17 06:35:37 +0000",
    "user" : {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "protected" : false,
      "id_str" : "17589664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267172323\/Evan_Frendo_normal.jpg",
      "id" : 17589664,
      "verified" : false
    }
  },
  "id" : 732492214488567808,
  "created_at" : "2016-05-17 08:45:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 45, 55 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/zwD7awv8hs",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/819-anatomy-of-a-propaganda-blitz-part-2-hitlergate.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732489681737158656",
  "text" : "RT @johnwhilley: Vital (part 2) reading from @medialens, taking apart the 'Hitlergate' propaganda blitz. https:\/\/t.co\/zwD7awv8hs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 28, 38 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/zwD7awv8hs",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/819-anatomy-of-a-propaganda-blitz-part-2-hitlergate.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732487605011406849",
    "text" : "Vital (part 2) reading from @medialens, taking apart the 'Hitlergate' propaganda blitz. https:\/\/t.co\/zwD7awv8hs",
    "id" : 732487605011406849,
    "created_at" : "2016-05-17 08:27:08 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 732489681737158656,
  "created_at" : "2016-05-17 08:35:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 83, 99 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/GzeG33TU1N",
      "expanded_url" : "https:\/\/educationbookcast.com\/2016\/05\/16\/19a-seven-myths-about-education-by-daisy-chrisodoulou\/",
      "display_url" : "educationbookcast.com\/2016\/05\/16\/19a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732486828830298113",
  "text" : "19a. Seven Myths about Education by Daisy Chrisodoulou https:\/\/t.co\/GzeG33TU1N via @wordpressdotcom",
  "id" : 732486828830298113,
  "created_at" : "2016-05-17 08:24:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732306028952494080",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir hi Steve great lesson on those brawling beetles : ) a Q - how did you decide on those sentences using fight?",
  "id" : 732306028952494080,
  "created_at" : "2016-05-16 20:25:37 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/mJhGRmagvn",
      "expanded_url" : "https:\/\/twitter.com\/consciousstyles\/status\/732288452947890176",
      "display_url" : "twitter.com\/consciousstyle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732297395862700033",
  "text" : "RT @grvsmth: Category fight! (incoherent respectability taboo) https:\/\/t.co\/mJhGRmagvn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/mJhGRmagvn",
        "expanded_url" : "https:\/\/twitter.com\/consciousstyles\/status\/732288452947890176",
        "display_url" : "twitter.com\/consciousstyle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732294296423018497",
    "text" : "Category fight! (incoherent respectability taboo) https:\/\/t.co\/mJhGRmagvn",
    "id" : 732294296423018497,
    "created_at" : "2016-05-16 19:39:00 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 732297395862700033,
  "created_at" : "2016-05-16 19:51:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "indices" : [ 0, 16 ],
      "id_str" : "91870534",
      "id" : 91870534
    }, {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "indices" : [ 17, 31 ],
      "id_str" : "3187104424",
      "id" : 3187104424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/wNYqIbIFne",
      "expanded_url" : "https:\/\/openvisconf.com\/#videos",
      "display_url" : "openvisconf.com\/#videos"
    } ]
  },
  "in_reply_to_status_id_str" : "731736328501665792",
  "geo" : { },
  "id_str" : "732287495698849792",
  "in_reply_to_user_id" : 91870534,
  "text" : "@MichaelRosenYes @EngliciousUCL would you be able to index them in some way? \u00E0 la https:\/\/t.co\/wNYqIbIFne",
  "id" : 732287495698849792,
  "in_reply_to_status_id" : 731736328501665792,
  "created_at" : "2016-05-16 19:11:58 +0000",
  "in_reply_to_screen_name" : "MichaelRosenYes",
  "in_reply_to_user_id_str" : "91870534",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KenLoach",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "IDanielBlake",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/XJoI4s0p5d",
      "expanded_url" : "http:\/\/nr.news-republic.com\/Web\/ArticleWeb.aspx?regionid=4&articleid=64344845",
      "display_url" : "nr.news-republic.com\/Web\/ArticleWeb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732286810437603329",
  "text" : "RT @johnwhilley: Looks like another fine indictment from #KenLoach on the state's wicked treatment of the poor. https:\/\/t.co\/XJoI4s0p5d #ID\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KenLoach",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "IDanielBlake",
        "indices" : [ 119, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/XJoI4s0p5d",
        "expanded_url" : "http:\/\/nr.news-republic.com\/Web\/ArticleWeb.aspx?regionid=4&articleid=64344845",
        "display_url" : "nr.news-republic.com\/Web\/ArticleWeb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731980197113778177",
    "text" : "Looks like another fine indictment from #KenLoach on the state's wicked treatment of the poor. https:\/\/t.co\/XJoI4s0p5d #IDanielBlake",
    "id" : 731980197113778177,
    "created_at" : "2016-05-15 22:50:53 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 732286810437603329,
  "created_at" : "2016-05-16 19:09:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 93, 108 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/BQfVdfzM3w",
      "expanded_url" : "http:\/\/abcdelt.com\/5-lessons-from-5-years-of-teaching-english-as-a-foreign-language\/?utm_source=twitter&utm_medium=social&utm_campaign=SocialWarfare",
      "display_url" : "abcdelt.com\/5-lessons-from\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732282760866451456",
  "text" : "5 Lessons from 5 Years of Teaching English as a Foreign Language https:\/\/t.co\/BQfVdfzM3w via @MrChrisJWilson",
  "id" : 732282760866451456,
  "created_at" : "2016-05-16 18:53:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 12, 24 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/732229235323113472\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/HDyw7fibYB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cilmm7fWgAA4nRp.jpg",
      "id_str" : "732229233414668288",
      "id" : 732229233414668288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cilmm7fWgAA4nRp.jpg",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 691,
        "resize" : "fit",
        "w" : 536
      }, {
        "h" : 691,
        "resize" : "fit",
        "w" : 536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 691,
        "resize" : "fit",
        "w" : 536
      } ],
      "display_url" : "pic.twitter.com\/HDyw7fibYB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732151983512096768",
  "geo" : { },
  "id_str" : "732229235323113472",
  "in_reply_to_user_id" : 18602422,
  "text" : "@lexicoloco @ELTResearch apparently not all search terms replaced https:\/\/t.co\/HDyw7fibYB",
  "id" : 732229235323113472,
  "in_reply_to_status_id" : 732151983512096768,
  "created_at" : "2016-05-16 15:20:28 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 3, 19 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732215100799619072",
  "text" : "RT @LinguistsCorner: Looking for a line of code (any programme) to delete quoted texts from a single long text or a corpus of long texts; a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731820237742583808",
    "text" : "Looking for a line of code (any programme) to delete quoted texts from a single long text or a corpus of long texts; any help or suggestion?",
    "id" : 731820237742583808,
    "created_at" : "2016-05-15 12:15:15 +0000",
    "user" : {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "protected" : false,
      "id_str" : "726889545883639808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726890560817090562\/goWLk4yD_normal.jpg",
      "id" : 726889545883639808,
      "verified" : false
    }
  },
  "id" : 732215100799619072,
  "created_at" : "2016-05-16 14:24:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 0, 16 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732214078844882945",
  "geo" : { },
  "id_str" : "732215016657715200",
  "in_reply_to_user_id" : 149239362,
  "text" : "@umasslinguistic i think maybe a better phrase is \"delivering a taxpayer funded tool\"? : )",
  "id" : 732215016657715200,
  "in_reply_to_status_id" : 732214078844882945,
  "created_at" : "2016-05-16 14:23:58 +0000",
  "in_reply_to_screen_name" : "umasslinguistic",
  "in_reply_to_user_id_str" : "149239362",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 0, 16 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/i8llcDmVMn",
      "expanded_url" : "https:\/\/plus.google.com\/111396823575843060001\/posts\/1jtqa22oS3H",
      "display_url" : "plus.google.com\/11139682357584\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "732187389569978368",
  "geo" : { },
  "id_str" : "732187639584051200",
  "in_reply_to_user_id" : 726889545883639808,
  "text" : "@LinguistsCorner hi just saw question on G+, a response there https:\/\/t.co\/i8llcDmVMn",
  "id" : 732187639584051200,
  "in_reply_to_status_id" : 732187389569978368,
  "created_at" : "2016-05-16 12:35:11 +0000",
  "in_reply_to_screen_name" : "LinguistsCorner",
  "in_reply_to_user_id_str" : "726889545883639808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732186926434881536",
  "text" : "another level of social media hell, a twitter link to a facebook link to a twitter link; plus die linkis die",
  "id" : 732186926434881536,
  "created_at" : "2016-05-16 12:32:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Spacey",
      "screen_name" : "Jason_Spacey",
      "indices" : [ 3, 16 ],
      "id_str" : "2876330866",
      "id" : 2876330866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Jason_Spacey\/status\/606148185883602944\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Wt3sNo6rud",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGl4kAGWwAAqLyX.png",
      "id_str" : "606148184755322880",
      "id" : 606148184755322880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGl4kAGWwAAqLyX.png",
      "sizes" : [ {
        "h" : 586,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wt3sNo6rud"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732174348832919552",
  "text" : "RT @Jason_Spacey: Dulux have introduced a new 'David Cameron's Face' range to their colour chart http:\/\/t.co\/Wt3sNo6rud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Jason_Spacey\/status\/606148185883602944\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Wt3sNo6rud",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGl4kAGWwAAqLyX.png",
        "id_str" : "606148184755322880",
        "id" : 606148184755322880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGl4kAGWwAAqLyX.png",
        "sizes" : [ {
          "h" : 586,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Wt3sNo6rud"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606148185883602944",
    "text" : "Dulux have introduced a new 'David Cameron's Face' range to their colour chart http:\/\/t.co\/Wt3sNo6rud",
    "id" : 606148185883602944,
    "created_at" : "2015-06-03 17:19:23 +0000",
    "user" : {
      "name" : "Jason Spacey",
      "screen_name" : "Jason_Spacey",
      "protected" : false,
      "id_str" : "2876330866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547682489485889537\/inxvk4fN_normal.jpeg",
      "id" : 2876330866,
      "verified" : false
    }
  },
  "id" : 732174348832919552,
  "created_at" : "2016-05-16 11:42:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/I0JXEOIwpT",
      "expanded_url" : "https:\/\/twitter.com\/pronbites\/status\/732032562118426624",
      "display_url" : "twitter.com\/pronbites\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732166120451538944",
  "text" : "RT @AnthonyTeacher: Very nice post https:\/\/t.co\/I0JXEOIwpT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/I0JXEOIwpT",
        "expanded_url" : "https:\/\/twitter.com\/pronbites\/status\/732032562118426624",
        "display_url" : "twitter.com\/pronbites\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732163050925658112",
    "text" : "Very nice post https:\/\/t.co\/I0JXEOIwpT",
    "id" : 732163050925658112,
    "created_at" : "2016-05-16 10:57:28 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 732166120451538944,
  "created_at" : "2016-05-16 11:09:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "efl",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "esl",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "tesol",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/tXU2gu7sVu",
      "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/jobs\/volunteer-english-teachers-needed-in-france\/",
      "display_url" : "tesoltraining.co.uk\/blog\/jobs\/volu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732163747423354880",
  "text" : "RT @lauraahaha: Volunteer English &amp; French teachers needed in Dunkirk https:\/\/t.co\/tXU2gu7sVu #elt #efl #esl #tesol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "efl",
        "indices" : [ 87, 91 ]
      }, {
        "text" : "esl",
        "indices" : [ 92, 96 ]
      }, {
        "text" : "tesol",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/tXU2gu7sVu",
        "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/jobs\/volunteer-english-teachers-needed-in-france\/",
        "display_url" : "tesoltraining.co.uk\/blog\/jobs\/volu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732157989931614208",
    "text" : "Volunteer English &amp; French teachers needed in Dunkirk https:\/\/t.co\/tXU2gu7sVu #elt #efl #esl #tesol",
    "id" : 732157989931614208,
    "created_at" : "2016-05-16 10:37:22 +0000",
    "user" : {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "protected" : false,
      "id_str" : "97957137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659005852477714432\/xfuJsW6q_normal.jpg",
      "id" : 97957137,
      "verified" : false
    }
  },
  "id" : 732163747423354880,
  "created_at" : "2016-05-16 11:00:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul W Bennett",
      "screen_name" : "Educhatter",
      "indices" : [ 0, 11 ],
      "id_str" : "68967864",
      "id" : 68967864
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 12, 23 ],
      "id_str" : "87902543",
      "id" : 87902543
    }, {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 24, 37 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731963389619146752",
  "geo" : { },
  "id_str" : "732162234315616256",
  "in_reply_to_user_id" : 68967864,
  "text" : "@Educhatter @tornhalves @DTWillingham \"readers were ready to quit a text\" interesting spin on Nation vocab studies?",
  "id" : 732162234315616256,
  "in_reply_to_status_id" : 731963389619146752,
  "created_at" : "2016-05-16 10:54:14 +0000",
  "in_reply_to_screen_name" : "Educhatter",
  "in_reply_to_user_id_str" : "68967864",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul W Bennett",
      "screen_name" : "Educhatter",
      "indices" : [ 3, 14 ],
      "id_str" : "68967864",
      "id" : 68967864
    }, {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 71, 84 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Edtech",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "edreform",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "AERA",
      "indices" : [ 127, 132 ]
    }, {
      "text" : "researchED",
      "indices" : [ 133, 140 ]
    }, {
      "text" : "CDNed",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/q9NyACj7yg",
      "expanded_url" : "http:\/\/nydn.us\/1qj1J4o",
      "display_url" : "nydn.us\/1qj1J4o"
    } ]
  },
  "geo" : { },
  "id_str" : "732161227158372352",
  "text" : "RT @Educhatter: E-Learning Watch: The false promise of tech in schools @DTWillingham https:\/\/t.co\/q9NyACj7yg #Edtech #edreform #AERA #resea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Willingham",
        "screen_name" : "DTWillingham",
        "indices" : [ 55, 68 ],
        "id_str" : "84619537",
        "id" : 84619537
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Edtech",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "edreform",
        "indices" : [ 101, 110 ]
      }, {
        "text" : "AERA",
        "indices" : [ 111, 116 ]
      }, {
        "text" : "researchED",
        "indices" : [ 117, 128 ]
      }, {
        "text" : "CDNed",
        "indices" : [ 129, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/q9NyACj7yg",
        "expanded_url" : "http:\/\/nydn.us\/1qj1J4o",
        "display_url" : "nydn.us\/1qj1J4o"
      } ]
    },
    "geo" : { },
    "id_str" : "731963389619146752",
    "text" : "E-Learning Watch: The false promise of tech in schools @DTWillingham https:\/\/t.co\/q9NyACj7yg #Edtech #edreform #AERA #researchED #CDNed",
    "id" : 731963389619146752,
    "created_at" : "2016-05-15 21:44:05 +0000",
    "user" : {
      "name" : "Paul W Bennett",
      "screen_name" : "Educhatter",
      "protected" : false,
      "id_str" : "68967864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653304580344705028\/OtaJyD9A_normal.jpg",
      "id" : 68967864,
      "verified" : false
    }
  },
  "id" : 732161227158372352,
  "created_at" : "2016-05-16 10:50:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 41, 57 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/kutVk0CNHH",
      "expanded_url" : "https:\/\/allatc.wordpress.com\/2016\/05\/16\/beetle-brawl\/",
      "display_url" : "allatc.wordpress.com\/2016\/05\/16\/bee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732160392689033217",
  "text" : "Beetle Brawl https:\/\/t.co\/kutVk0CNHH via @wordpressdotcom",
  "id" : 732160392689033217,
  "created_at" : "2016-05-16 10:46:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COCA",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/a9MicpQkIv",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/",
      "display_url" : "corpus.byu.edu\/coca\/"
    } ]
  },
  "geo" : { },
  "id_str" : "732152126688899072",
  "text" : "RT @AnneHendler: I like #COCA's new look. Very easy to use. https:\/\/t.co\/a9MicpQkIv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COCA",
        "indices" : [ 7, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/a9MicpQkIv",
        "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/",
        "display_url" : "corpus.byu.edu\/coca\/"
      } ]
    },
    "geo" : { },
    "id_str" : "732035176511856641",
    "text" : "I like #COCA's new look. Very easy to use. https:\/\/t.co\/a9MicpQkIv",
    "id" : 732035176511856641,
    "created_at" : "2016-05-16 02:29:21 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 732152126688899072,
  "created_at" : "2016-05-16 10:14:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 12, 24 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732121001065103360",
  "geo" : { },
  "id_str" : "732151983512096768",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @ELTResearch anyone seen help list with full replacement search terms?",
  "id" : 732151983512096768,
  "in_reply_to_status_id" : 732121001065103360,
  "created_at" : "2016-05-16 10:13:30 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAL Academy",
      "screen_name" : "LinguistsCorner",
      "indices" : [ 0, 16 ],
      "id_str" : "726889545883639808",
      "id" : 726889545883639808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731820237742583808",
  "geo" : { },
  "id_str" : "731820980000174081",
  "in_reply_to_user_id" : 726889545883639808,
  "text" : "@LinguistsCorner hi, it has to be code?",
  "id" : 731820980000174081,
  "in_reply_to_status_id" : 731820237742583808,
  "created_at" : "2016-05-15 12:18:12 +0000",
  "in_reply_to_screen_name" : "LinguistsCorner",
  "in_reply_to_user_id_str" : "726889545883639808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 0, 12 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731806448645210112",
  "geo" : { },
  "id_str" : "731812900147478528",
  "in_reply_to_user_id" : 3996937557,
  "text" : "@TheTeflShow sure : )",
  "id" : 731812900147478528,
  "in_reply_to_status_id" : 731806448645210112,
  "created_at" : "2016-05-15 11:46:06 +0000",
  "in_reply_to_screen_name" : "TheTeflShow",
  "in_reply_to_user_id_str" : "3996937557",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 109, 121 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/AEkdQD7Qmo",
      "expanded_url" : "https:\/\/theteflshow.com\/2016\/05\/11\/teaching-lexically-materials-writing-and-the-celta-interview-with-hugh-dellar\/",
      "display_url" : "theteflshow.com\/2016\/05\/11\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731791256263786496",
  "text" : "Teaching lexically, materials writing and the CELTA - interview with Hugh Dellar https:\/\/t.co\/AEkdQD7Qmo via @theteflshow",
  "id" : 731791256263786496,
  "created_at" : "2016-05-15 10:20:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "YLT SIG",
      "screen_name" : "iatefl_yltsig",
      "indices" : [ 26, 40 ],
      "id_str" : "268852257",
      "id" : 268852257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/OKH5CsmjXA",
      "expanded_url" : "http:\/\/www.iatefl.org\/web-events\/sig-webinars",
      "display_url" : "iatefl.org\/web-events\/sig\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KdGggwlzKk",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/p\/workshops.html",
      "display_url" : "leoxicon.blogspot.com\/p\/workshops.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731788651965845504",
  "text" : "RT @leoselivan: Join FREE @iatefl_yltsig webinar today 'Horizontal alternatives to vertical lists' 4pm GMT https:\/\/t.co\/OKH5CsmjXA\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YLT SIG",
        "screen_name" : "iatefl_yltsig",
        "indices" : [ 10, 24 ],
        "id_str" : "268852257",
        "id" : 268852257
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/OKH5CsmjXA",
        "expanded_url" : "http:\/\/www.iatefl.org\/web-events\/sig-webinars",
        "display_url" : "iatefl.org\/web-events\/sig\u2026"
      }, {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/KdGggwlzKk",
        "expanded_url" : "http:\/\/leoxicon.blogspot.com\/p\/workshops.html",
        "display_url" : "leoxicon.blogspot.com\/p\/workshops.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731783441533046785",
    "text" : "Join FREE @iatefl_yltsig webinar today 'Horizontal alternatives to vertical lists' 4pm GMT https:\/\/t.co\/OKH5CsmjXA\nhttps:\/\/t.co\/KdGggwlzKk",
    "id" : 731783441533046785,
    "created_at" : "2016-05-15 09:49:02 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 731788651965845504,
  "created_at" : "2016-05-15 10:09:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 124, 139 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/54wGHDxTQK",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/i-told-my-students-to-choose-the-final-assessment-and-then-left-the-room-you-wont-believe-what-happened-next",
      "display_url" : "anthonyteacher.com\/blog\/i-told-my\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731766066188259328",
  "text" : "I told my students to choose the final assessment and then left the room. You won't believe wh\u2026 https:\/\/t.co\/54wGHDxTQK via @AnthonyTeacher",
  "id" : 731766066188259328,
  "created_at" : "2016-05-15 08:40:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Tim Hampson",
      "screen_name" : "timhampson",
      "indices" : [ 17, 28 ],
      "id_str" : "19422628",
      "id" : 19422628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/731549358244675584\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/grs7PV5jHa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cib8Q5mXIAEsXQE.jpg",
      "id_str" : "731549356764110849",
      "id" : 731549356764110849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cib8Q5mXIAEsXQE.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 1415
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/grs7PV5jHa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731514484087382017",
  "geo" : { },
  "id_str" : "731549358244675584",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @timhampson commas preferred in this corpus http:\/\/111.200.194.212\/cqp\/business u\/n test p\/w test https:\/\/t.co\/grs7PV5jHa",
  "id" : 731549358244675584,
  "in_reply_to_status_id" : 731514484087382017,
  "created_at" : "2016-05-14 18:18:53 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 3, 12 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 93, 108 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 115, 128 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/uzXPk1qSG5",
      "expanded_url" : "https:\/\/iatefl.adobeconnect.com\/divyabrochier\/event\/login.html?campaign-id=Divya%20Brochier&login=hadalitim%40gmail.com",
      "display_url" : "iatefl.adobeconnect.com\/divyabrochier\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731477214814961664",
  "text" : "RT @Hada_ELT: This  ''Ten truths (and a lie) about EMI'', is starting in 20 mins courtesy of @_divyamadhavan &amp; @iateflonline here https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Divya Madhavan",
        "screen_name" : "_divyamadhavan",
        "indices" : [ 79, 94 ],
        "id_str" : "408492806",
        "id" : 408492806
      }, {
        "name" : "IATEFL Online",
        "screen_name" : "iateflonline",
        "indices" : [ 101, 114 ],
        "id_str" : "17447359",
        "id" : 17447359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/uzXPk1qSG5",
        "expanded_url" : "https:\/\/iatefl.adobeconnect.com\/divyabrochier\/event\/login.html?campaign-id=Divya%20Brochier&login=hadalitim%40gmail.com",
        "display_url" : "iatefl.adobeconnect.com\/divyabrochier\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731475934096830465",
    "text" : "This  ''Ten truths (and a lie) about EMI'', is starting in 20 mins courtesy of @_divyamadhavan &amp; @iateflonline here https:\/\/t.co\/uzXPk1qSG5",
    "id" : 731475934096830465,
    "created_at" : "2016-05-14 13:27:07 +0000",
    "user" : {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "protected" : false,
      "id_str" : "44631065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729282562783326209\/2tQuUs5L_normal.jpg",
      "id" : 44631065,
      "verified" : false
    }
  },
  "id" : 731477214814961664,
  "created_at" : "2016-05-14 13:32:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/l16mHGGWzi",
      "expanded_url" : "https:\/\/frinkiac.com\/meme\/S13E14\/857899\/m\/SmVyZW15IENvcmJ5biBsYWNrZXksIHlvdSBhcmUKIGFjY3VzZWQgb2YgaW5kZXBlbmRlbnQgdGhvdWdodCwKIHR3aXR0ZXJjcmFmdCBhbmQgdGhhdCBtYW4KIHRvbGQgbWUgeW91IG1lbWVkIGhpbS4=",
      "display_url" : "frinkiac.com\/meme\/S13E14\/85\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731473220063383552",
  "text" : "Jeremy Corbyn lackey, you are\n accused of independent thought,\n twittercraft and that man\n told me you memed him. https:\/\/t.co\/l16mHGGWzi",
  "id" : 731473220063383552,
  "created_at" : "2016-05-14 13:16:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly J. Cunningham",
      "screen_name" : "ESLCunningham",
      "indices" : [ 3, 17 ],
      "id_str" : "242909458",
      "id" : 242909458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CALICO2016",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/PiArzEUA5m",
      "expanded_url" : "https:\/\/sites.google.com\/site\/itbecunningham\/home\/teacher-student-perspectives-on-screencast-text-feedback-in-esl-writing-calico-2016",
      "display_url" : "sites.google.com\/site\/itbecunni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731459382861565954",
  "text" : "RT @ESLCunningham: Slides for my #CALICO2016 presentation on T &amp; S perspectives on Text &amp; Screencast FdBk available: https:\/\/t.co\/PiArzEUA5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CALICO2016",
        "indices" : [ 14, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/PiArzEUA5m",
        "expanded_url" : "https:\/\/sites.google.com\/site\/itbecunningham\/home\/teacher-student-perspectives-on-screencast-text-feedback-in-esl-writing-calico-2016",
        "display_url" : "sites.google.com\/site\/itbecunni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731269118175924226",
    "text" : "Slides for my #CALICO2016 presentation on T &amp; S perspectives on Text &amp; Screencast FdBk available: https:\/\/t.co\/PiArzEUA5m \nRecruiting Ts too",
    "id" : 731269118175924226,
    "created_at" : "2016-05-13 23:45:18 +0000",
    "user" : {
      "name" : "Kelly J. Cunningham",
      "screen_name" : "ESLCunningham",
      "protected" : false,
      "id_str" : "242909458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512974337444290560\/cCnaIPL9_normal.jpeg",
      "id" : 242909458,
      "verified" : false
    }
  },
  "id" : 731459382861565954,
  "created_at" : "2016-05-14 12:21:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pchallinor\/status\/731438560847536128\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/LFD5UE0YoQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiaXfqJW0AAMHLK.jpg",
      "id_str" : "731438559639556096",
      "id" : 731438559639556096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiaXfqJW0AAMHLK.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1236,
        "resize" : "fit",
        "w" : 2060
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LFD5UE0YoQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/JUn3E44XuQ",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/drinking-from-same-labour-mug.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/drinki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731441339607453696",
  "text" : "RT @pchallinor: New mudgeonry: Drinking from the same Labour mug https:\/\/t.co\/JUn3E44XuQ https:\/\/t.co\/LFD5UE0YoQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pchallinor\/status\/731438560847536128\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/LFD5UE0YoQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiaXfqJW0AAMHLK.jpg",
        "id_str" : "731438559639556096",
        "id" : 731438559639556096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiaXfqJW0AAMHLK.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1236,
          "resize" : "fit",
          "w" : 2060
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LFD5UE0YoQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/JUn3E44XuQ",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/05\/drinking-from-same-labour-mug.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/05\/drinki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731438560847536128",
    "text" : "New mudgeonry: Drinking from the same Labour mug https:\/\/t.co\/JUn3E44XuQ https:\/\/t.co\/LFD5UE0YoQ",
    "id" : 731438560847536128,
    "created_at" : "2016-05-14 10:58:37 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 731441339607453696,
  "created_at" : "2016-05-14 11:09:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731440090451460096",
  "text" : "Parsey McParseface successfully continuing the brandwashing of TaxAvoidance McTaxAvoidanceface",
  "id" : 731440090451460096,
  "created_at" : "2016-05-14 11:04:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 10, 23 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731395602043506688",
  "geo" : { },
  "id_str" : "731414687892578305",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @perezparedes bizarely interesting? : )",
  "id" : 731414687892578305,
  "in_reply_to_status_id" : 731395602043506688,
  "created_at" : "2016-05-14 09:23:45 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Abunimah",
      "screen_name" : "AliAbunimah",
      "indices" : [ 3, 15 ],
      "id_str" : "16799023",
      "id" : 16799023
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AliAbunimah\/status\/731205870500057088\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/WHmbwaXgSo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiXD3ToWwAEpWyw.jpg",
      "id_str" : "731205869447331841",
      "id" : 731205869447331841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiXD3ToWwAEpWyw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1055,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WHmbwaXgSo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/0Dc5fl45bV",
      "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/ali-abunimah\/israel-lobby-pushing-ban-palestinian-film-cannes",
      "display_url" : "electronicintifada.net\/blogs\/ali-abun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731414273524703232",
  "text" : "RT @AliAbunimah: Exclusive: Israel lobby pushing to ban Palestinian film at Cannes https:\/\/t.co\/0Dc5fl45bV https:\/\/t.co\/WHmbwaXgSo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AliAbunimah\/status\/731205870500057088\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/WHmbwaXgSo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiXD3ToWwAEpWyw.jpg",
        "id_str" : "731205869447331841",
        "id" : 731205869447331841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiXD3ToWwAEpWyw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1055,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WHmbwaXgSo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/0Dc5fl45bV",
        "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/ali-abunimah\/israel-lobby-pushing-ban-palestinian-film-cannes",
        "display_url" : "electronicintifada.net\/blogs\/ali-abun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731205870500057088",
    "text" : "Exclusive: Israel lobby pushing to ban Palestinian film at Cannes https:\/\/t.co\/0Dc5fl45bV https:\/\/t.co\/WHmbwaXgSo",
    "id" : 731205870500057088,
    "created_at" : "2016-05-13 19:33:59 +0000",
    "user" : {
      "name" : "Ali Abunimah",
      "screen_name" : "AliAbunimah",
      "protected" : false,
      "id_str" : "16799023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720233204544712705\/1zP1g9sh_normal.jpg",
      "id" : 16799023,
      "verified" : true
    }
  },
  "id" : 731414273524703232,
  "created_at" : "2016-05-14 09:22:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Husler",
      "screen_name" : "HuslerGary",
      "indices" : [ 0, 11 ],
      "id_str" : "3621925274",
      "id" : 3621925274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/4TjB027Xam",
      "expanded_url" : "https:\/\/educationbookcast.com\/",
      "display_url" : "educationbookcast.com"
    } ]
  },
  "in_reply_to_status_id_str" : "731147629376102400",
  "geo" : { },
  "id_str" : "731148421982224384",
  "in_reply_to_user_id" : 3621925274,
  "text" : "@HuslerGary yes definitely check https:\/\/t.co\/4TjB027Xam",
  "id" : 731148421982224384,
  "in_reply_to_status_id" : 731147629376102400,
  "created_at" : "2016-05-13 15:45:42 +0000",
  "in_reply_to_screen_name" : "HuslerGary",
  "in_reply_to_user_id_str" : "3621925274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 3, 16 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tesolmatthew\/status\/731012756334219264\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/78sNzBfxGD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiUUOmEUUAA53-_.jpg",
      "id_str" : "731012755486953472",
      "id" : 731012755486953472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiUUOmEUUAA53-_.jpg",
      "sizes" : [ {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/78sNzBfxGD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/95RsqqK0N3",
      "expanded_url" : "http:\/\/bit.ly\/1VVmUHJ",
      "display_url" : "bit.ly\/1VVmUHJ"
    } ]
  },
  "geo" : { },
  "id_str" : "731122471408177152",
  "text" : "RT @tesolmatthew: Thx to the first 7 teachers who already responded &amp; shared gr8 thoughts! :) Add yours here: https:\/\/t.co\/95RsqqK0N3 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tesolmatthew\/status\/731012756334219264\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/78sNzBfxGD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiUUOmEUUAA53-_.jpg",
        "id_str" : "731012755486953472",
        "id" : 731012755486953472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiUUOmEUUAA53-_.jpg",
        "sizes" : [ {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        } ],
        "display_url" : "pic.twitter.com\/78sNzBfxGD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/95RsqqK0N3",
        "expanded_url" : "http:\/\/bit.ly\/1VVmUHJ",
        "display_url" : "bit.ly\/1VVmUHJ"
      } ]
    },
    "geo" : { },
    "id_str" : "731012756334219264",
    "text" : "Thx to the first 7 teachers who already responded &amp; shared gr8 thoughts! :) Add yours here: https:\/\/t.co\/95RsqqK0N3 https:\/\/t.co\/78sNzBfxGD",
    "id" : 731012756334219264,
    "created_at" : "2016-05-13 06:46:37 +0000",
    "user" : {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "protected" : false,
      "id_str" : "1519875330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763982969358786561\/DY-VaJBi_normal.jpg",
      "id" : 1519875330,
      "verified" : false
    }
  },
  "id" : 731122471408177152,
  "created_at" : "2016-05-13 14:02:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American TESOL Inst.",
      "screen_name" : "americantesol",
      "indices" : [ 3, 17 ],
      "id_str" : "62443169",
      "id" : 62443169
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 90, 102 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "ellchat",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "duallang",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/8b5fxUQIku",
      "expanded_url" : "https:\/\/nathanghall.wordpress.com\/2015\/07\/04\/corpora-and-collocations\/",
      "display_url" : "nathanghall.wordpress.com\/2015\/07\/04\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731115182286639106",
  "text" : "RT @americantesol: Corpora &amp; Collocation Online Resources https:\/\/t.co\/8b5fxUQIku via @nathanghall  #esl #eltchat #ellchat #duallang",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan Hall",
        "screen_name" : "nathanghall",
        "indices" : [ 71, 83 ],
        "id_str" : "192437743",
        "id" : 192437743
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esl",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "ellchat",
        "indices" : [ 99, 107 ]
      }, {
        "text" : "duallang",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/8b5fxUQIku",
        "expanded_url" : "https:\/\/nathanghall.wordpress.com\/2015\/07\/04\/corpora-and-collocations\/",
        "display_url" : "nathanghall.wordpress.com\/2015\/07\/04\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731096685225500673",
    "text" : "Corpora &amp; Collocation Online Resources https:\/\/t.co\/8b5fxUQIku via @nathanghall  #esl #eltchat #ellchat #duallang",
    "id" : 731096685225500673,
    "created_at" : "2016-05-13 12:20:07 +0000",
    "user" : {
      "name" : "American TESOL Inst.",
      "screen_name" : "americantesol",
      "protected" : false,
      "id_str" : "62443169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536527472821415936\/2rQXAQLG_normal.jpeg",
      "id" : 62443169,
      "verified" : false
    }
  },
  "id" : 731115182286639106,
  "created_at" : "2016-05-13 13:33:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 10, 23 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731064898973773824",
  "geo" : { },
  "id_str" : "731065508645220352",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @perezparedes the linked euro pdf is interesting",
  "id" : 731065508645220352,
  "in_reply_to_status_id" : 731064898973773824,
  "created_at" : "2016-05-13 10:16:14 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly J. Cunningham",
      "screen_name" : "ESLCunningham",
      "indices" : [ 0, 14 ],
      "id_str" : "242909458",
      "id" : 242909458
    }, {
      "name" : "Botty McBotface",
      "screen_name" : "botty_mcbotface",
      "indices" : [ 39, 55 ],
      "id_str" : "712407201147707392",
      "id" : 712407201147707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730942385212010496",
  "geo" : { },
  "id_str" : "731031974639472640",
  "in_reply_to_user_id" : 242909458,
  "text" : "@ESLCunningham don't know buy there is @botty_mcbotface : )",
  "id" : 731031974639472640,
  "in_reply_to_status_id" : 730942385212010496,
  "created_at" : "2016-05-13 08:02:59 +0000",
  "in_reply_to_screen_name" : "ESLCunningham",
  "in_reply_to_user_id_str" : "242909458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Slagoski",
      "screen_name" : "jdslagoski",
      "indices" : [ 3, 14 ],
      "id_str" : "22298696",
      "id" : 22298696
    }, {
      "name" : "CESL at SIUC",
      "screen_name" : "CESL_SIUC",
      "indices" : [ 74, 84 ],
      "id_str" : "389615750",
      "id" : 389615750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flippedlearning",
      "indices" : [ 32, 48 ]
    }, {
      "text" : "grammar",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "ESL",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "EFL",
      "indices" : [ 133, 137 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/S6DIhGciW7",
      "expanded_url" : "http:\/\/jesl1.blogspot.com\/2016\/05\/flip-that-grammar.html",
      "display_url" : "jesl1.blogspot.com\/2016\/05\/flip-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730893230485561346",
  "text" : "RT @jdslagoski: I finally got a #flippedlearning opportunity! I flipped a @CESL_SIUC #grammar lesson at https:\/\/t.co\/S6DIhGciW7 #ESL #EFL #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CESL at SIUC",
        "screen_name" : "CESL_SIUC",
        "indices" : [ 58, 68 ],
        "id_str" : "389615750",
        "id" : 389615750
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "flippedlearning",
        "indices" : [ 16, 32 ]
      }, {
        "text" : "grammar",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "ESL",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "EFL",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 122, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/S6DIhGciW7",
        "expanded_url" : "http:\/\/jesl1.blogspot.com\/2016\/05\/flip-that-grammar.html",
        "display_url" : "jesl1.blogspot.com\/2016\/05\/flip-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730776663823417344",
    "text" : "I finally got a #flippedlearning opportunity! I flipped a @CESL_SIUC #grammar lesson at https:\/\/t.co\/S6DIhGciW7 #ESL #EFL #TESOL",
    "id" : 730776663823417344,
    "created_at" : "2016-05-12 15:08:28 +0000",
    "user" : {
      "name" : "Jeremy Slagoski",
      "screen_name" : "jdslagoski",
      "protected" : false,
      "id_str" : "22298696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684183931646693376\/PQyDitmm_normal.jpg",
      "id" : 22298696,
      "verified" : false
    }
  },
  "id" : 730893230485561346,
  "created_at" : "2016-05-12 22:51:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/xHCROZyhAi",
      "expanded_url" : "https:\/\/goo.gl\/JlEW5m",
      "display_url" : "goo.gl\/JlEW5m"
    } ]
  },
  "geo" : { },
  "id_str" : "730873664904806400",
  "text" : "going on a witch hunt https:\/\/t.co\/xHCROZyhAi",
  "id" : 730873664904806400,
  "created_at" : "2016-05-12 21:33:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 61, 70 ],
      "id_str" : "13533482",
      "id" : 13533482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ZgRk9NlHIb",
      "expanded_url" : "https:\/\/youtu.be\/aKucPh9xHtM",
      "display_url" : "youtu.be\/aKucPh9xHtM"
    } ]
  },
  "geo" : { },
  "id_str" : "730859066520698888",
  "text" : "practising her voiceless bilabial stop and teaching life h\/t @whippler https:\/\/t.co\/ZgRk9NlHIb",
  "id" : 730859066520698888,
  "created_at" : "2016-05-12 20:35:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/4csNw2vQVo",
      "expanded_url" : "https:\/\/twitter.com\/paulmaglione\/status\/730695887303917570",
      "display_url" : "twitter.com\/paulmaglione\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730850332343992320",
  "text" : "neat! though sample size is 16 not 19 as in media report https:\/\/t.co\/4csNw2vQVo",
  "id" : 730850332343992320,
  "created_at" : "2016-05-12 20:01:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730846536951844864",
  "geo" : { },
  "id_str" : "730847494834360320",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist lol : )",
  "id" : 730847494834360320,
  "in_reply_to_status_id" : 730846536951844864,
  "created_at" : "2016-05-12 19:49:55 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sociolinguistics",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/iqsDH1Qc4a",
      "expanded_url" : "https:\/\/twitter.com\/Multi_Ling_Mat\/status\/730822462770958338",
      "display_url" : "twitter.com\/Multi_Ling_Mat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730837607077318657",
  "text" : "RT @linguisticpulse: it's almost as if the distinction between dialect and language is not a cognitive distinction. hm. #sociolinguistics h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sociolinguistics",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iqsDH1Qc4a",
        "expanded_url" : "https:\/\/twitter.com\/Multi_Ling_Mat\/status\/730822462770958338",
        "display_url" : "twitter.com\/Multi_Ling_Mat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730824694325084160",
    "text" : "it's almost as if the distinction between dialect and language is not a cognitive distinction. hm. #sociolinguistics https:\/\/t.co\/iqsDH1Qc4a",
    "id" : 730824694325084160,
    "created_at" : "2016-05-12 18:19:19 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 730837607077318657,
  "created_at" : "2016-05-12 19:10:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Zimmer",
      "screen_name" : "bgzimmer",
      "indices" : [ 0, 9 ],
      "id_str" : "15104164",
      "id" : 15104164
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 10, 14 ],
      "id_str" : "3108351",
      "id" : 3108351
    }, {
      "name" : "Silicon Valley Speak",
      "screen_name" : "SVSpeak",
      "indices" : [ 15, 23 ],
      "id_str" : "4329075260",
      "id" : 4329075260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/h8W9ViwtNI",
      "expanded_url" : "http:\/\/svdictionary.com\/",
      "display_url" : "svdictionary.com"
    } ]
  },
  "in_reply_to_status_id_str" : "730807991071440896",
  "geo" : { },
  "id_str" : "730819318380941314",
  "in_reply_to_user_id" : 15104164,
  "text" : "@bgzimmer @WSJ @SVSpeak surprised this was not linked in article https:\/\/t.co\/h8W9ViwtNI",
  "id" : 730819318380941314,
  "in_reply_to_status_id" : 730807991071440896,
  "created_at" : "2016-05-12 17:57:58 +0000",
  "in_reply_to_screen_name" : "bgzimmer",
  "in_reply_to_user_id_str" : "15104164",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 0, 16 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730799252931289088",
  "geo" : { },
  "id_str" : "730803120587067393",
  "in_reply_to_user_id" : 1400748798,
  "text" : "@linguisticpulse is this a rare case? So not symptomatic?",
  "id" : 730803120587067393,
  "in_reply_to_status_id" : 730799252931289088,
  "created_at" : "2016-05-12 16:53:36 +0000",
  "in_reply_to_screen_name" : "linguisticpulse",
  "in_reply_to_user_id_str" : "1400748798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730802503680438274",
  "text" : "RT @pchallinor: Whiff of Lab antisemitism-&gt;apologies, suspensions-&gt;NOT GOOD ENOUGH\nWhiff of Con election fraud-&gt;sneers, whines-&gt;business as\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730802060787077121",
    "text" : "Whiff of Lab antisemitism-&gt;apologies, suspensions-&gt;NOT GOOD ENOUGH\nWhiff of Con election fraud-&gt;sneers, whines-&gt;business as usual",
    "id" : 730802060787077121,
    "created_at" : "2016-05-12 16:49:23 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 730802503680438274,
  "created_at" : "2016-05-12 16:51:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 0, 16 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730790763261505536",
  "geo" : { },
  "id_str" : "730794712001576960",
  "in_reply_to_user_id" : 1400748798,
  "text" : "@linguisticpulse I wld think there can be a \"fundamentalist\" stream of thinking like in other areas",
  "id" : 730794712001576960,
  "in_reply_to_status_id" : 730790763261505536,
  "created_at" : "2016-05-12 16:20:11 +0000",
  "in_reply_to_screen_name" : "linguisticpulse",
  "in_reply_to_user_id_str" : "1400748798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 0, 16 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 21, 33 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730784730371739648",
  "geo" : { },
  "id_str" : "730786862378418176",
  "in_reply_to_user_id" : 1400748798,
  "text" : "@linguisticpulse the @TheRegister used to denigrate \"freetard\" peeps, this is the first example where i wld agree with them :\/",
  "id" : 730786862378418176,
  "in_reply_to_status_id" : 730784730371739648,
  "created_at" : "2016-05-12 15:49:00 +0000",
  "in_reply_to_screen_name" : "linguisticpulse",
  "in_reply_to_user_id_str" : "1400748798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730780006373310464\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/BjvaC53wmO",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiRAhBdWEAAATP7.jpg",
      "id_str" : "730779975612239872",
      "id" : 730779975612239872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiRAhBdWEAAATP7.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 420
      } ],
      "display_url" : "pic.twitter.com\/BjvaC53wmO"
    } ],
    "hashtags" : [ {
      "text" : "RemoveALetterSpoilABook",
      "indices" : [ 16, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730780006373310464",
  "text" : "Assage to India #RemoveALetterSpoilABook https:\/\/t.co\/BjvaC53wmO",
  "id" : 730780006373310464,
  "created_at" : "2016-05-12 15:21:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730773282895613957",
  "geo" : { },
  "id_str" : "730773543043137538",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor oh him right lol",
  "id" : 730773543043137538,
  "in_reply_to_status_id" : 730773282895613957,
  "created_at" : "2016-05-12 14:56:04 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The World at One",
      "screen_name" : "BBCWorldatOne",
      "indices" : [ 3, 17 ],
      "id_str" : "1390045662",
      "id" : 1390045662
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BBCWorldatOne\/status\/730731793360523264\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/N9bVieDHRb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiQUsZ2WkAAWt-v.jpg",
      "id_str" : "730731792626520064",
      "id" : 730731792626520064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiQUsZ2WkAAWt-v.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/N9bVieDHRb"
    } ],
    "hashtags" : [ {
      "text" : "wato",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730772782955569152",
  "text" : "RT @BBCWorldatOne: Sir Michael Lyons: Understands why people worried if senior BBC editorial voices have lost their impartiality #wato http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BBCWorldatOne\/status\/730731793360523264\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/N9bVieDHRb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiQUsZ2WkAAWt-v.jpg",
        "id_str" : "730731792626520064",
        "id" : 730731792626520064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiQUsZ2WkAAWt-v.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/N9bVieDHRb"
      } ],
      "hashtags" : [ {
        "text" : "wato",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730731793360523264",
    "text" : "Sir Michael Lyons: Understands why people worried if senior BBC editorial voices have lost their impartiality #wato https:\/\/t.co\/N9bVieDHRb",
    "id" : 730731793360523264,
    "created_at" : "2016-05-12 12:10:10 +0000",
    "user" : {
      "name" : "The World at One",
      "screen_name" : "BBCWorldatOne",
      "protected" : false,
      "id_str" : "1390045662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570235743386079232\/TcVW5CJb_normal.jpeg",
      "id" : 1390045662,
      "verified" : true
    }
  },
  "id" : 730772782955569152,
  "created_at" : "2016-05-12 14:53:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 12, 20 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730468927990550528",
  "geo" : { },
  "id_str" : "730772165520437251",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @olyaelt thanks hope you are doing good Olya : )",
  "id" : 730772165520437251,
  "in_reply_to_status_id" : 730468927990550528,
  "created_at" : "2016-05-12 14:50:36 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730771383098216448",
  "geo" : { },
  "id_str" : "730771969348644868",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor point is not well made if cobbled together support : ) Peter Snow?",
  "id" : 730771969348644868,
  "in_reply_to_status_id" : 730771383098216448,
  "created_at" : "2016-05-12 14:49:49 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrien Barbaresi",
      "screen_name" : "adbarbaresi",
      "indices" : [ 3, 15 ],
      "id_str" : "222584301",
      "id" : 222584301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DH2016",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/2H8DdwA1LP",
      "expanded_url" : "http:\/\/adrien.barbaresi.eu\/blog\/distant-reading-text-visualization.html",
      "display_url" : "adrien.barbaresi.eu\/blog\/distant-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730761333067677696",
  "text" : "RT @adbarbaresi: Distant reading and text visualization [blog]\nhttps:\/\/t.co\/2H8DdwA1LP\n#DH2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DH2016",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/2H8DdwA1LP",
        "expanded_url" : "http:\/\/adrien.barbaresi.eu\/blog\/distant-reading-text-visualization.html",
        "display_url" : "adrien.barbaresi.eu\/blog\/distant-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730756266801434626",
    "text" : "Distant reading and text visualization [blog]\nhttps:\/\/t.co\/2H8DdwA1LP\n#DH2016",
    "id" : 730756266801434626,
    "created_at" : "2016-05-12 13:47:25 +0000",
    "user" : {
      "name" : "Adrien Barbaresi",
      "screen_name" : "adbarbaresi",
      "protected" : false,
      "id_str" : "222584301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731494811858014208\/NmvcMdyD_normal.jpg",
      "id" : 222584301,
      "verified" : false
    }
  },
  "id" : 730761333067677696,
  "created_at" : "2016-05-12 14:07:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730756308572471296",
  "geo" : { },
  "id_str" : "730756487732203520",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura it is a great book one of my favs too : )",
  "id" : 730756487732203520,
  "in_reply_to_status_id" : 730756308572471296,
  "created_at" : "2016-05-12 13:48:18 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 1, 16 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730755493078175744\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/nRNyne4cpx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiQqP4FWwAASWIo.jpg",
      "id_str" : "730755491782115328",
      "id" : 730755491782115328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiQqP4FWwAASWIo.jpg",
      "sizes" : [ {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 740
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 740
      } ],
      "display_url" : "pic.twitter.com\/nRNyne4cpx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730719763090051076",
  "geo" : { },
  "id_str" : "730755493078175744",
  "in_reply_to_user_id" : 27716419,
  "text" : ".@CraigMurrayOrg nice to see word freq :) but danger here need to look at text e.g. \"this woman\" use sexist? https:\/\/t.co\/nRNyne4cpx",
  "id" : 730755493078175744,
  "in_reply_to_status_id" : 730719763090051076,
  "created_at" : "2016-05-12 13:44:20 +0000",
  "in_reply_to_screen_name" : "CraigMurrayOrg",
  "in_reply_to_user_id_str" : "27716419",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Husler",
      "screen_name" : "HuslerGary",
      "indices" : [ 0, 11 ],
      "id_str" : "3621925274",
      "id" : 3621925274
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 12, 27 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730743373305274369",
  "geo" : { },
  "id_str" : "730744097653309440",
  "in_reply_to_user_id" : 3621925274,
  "text" : "@HuslerGary @GeoffreyJordan : ) use sci-hub",
  "id" : 730744097653309440,
  "in_reply_to_status_id" : 730743373305274369,
  "created_at" : "2016-05-12 12:59:04 +0000",
  "in_reply_to_screen_name" : "HuslerGary",
  "in_reply_to_user_id_str" : "3621925274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BN0iVgG4LP",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/05\/laura-kuenssberg-meet-barbara-streisand\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730743183517323265",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga this might be a good CL \"misuse\" example for your students? : ) https:\/\/t.co\/BN0iVgG4LP",
  "id" : 730743183517323265,
  "created_at" : "2016-05-12 12:55:26 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/JPaye9i2x9",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Petrie_Multiplier",
      "display_url" : "en.wikipedia.org\/wiki\/Petrie_Mu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "730740954047582212",
  "geo" : { },
  "id_str" : "730742726145265666",
  "in_reply_to_user_id" : 18602422,
  "text" : "@pchallinor also he should not be discounting sexist play by right e.g. petrie multiplier https:\/\/t.co\/JPaye9i2x9",
  "id" : 730742726145265666,
  "in_reply_to_status_id" : 730740954047582212,
  "created_at" : "2016-05-12 12:53:37 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730738090168438784",
  "geo" : { },
  "id_str" : "730740954047582212",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor nice to c word frequencies but Craig graphic seems wrong e.g, no \"witch\" count? and why put words in graphic not seen in cmmts?",
  "id" : 730740954047582212,
  "in_reply_to_status_id" : 730738090168438784,
  "created_at" : "2016-05-12 12:46:34 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730725376528424965",
  "geo" : { },
  "id_str" : "730727942003826688",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist direction influence on metaphors? load onto, pour into?",
  "id" : 730727942003826688,
  "in_reply_to_status_id" : 730725376528424965,
  "created_at" : "2016-05-12 11:54:52 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 68, 80 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/JvQ9Olvpbe",
      "expanded_url" : "https:\/\/off-guardian.org\/2016\/05\/12\/the-art-of-storytelling-in-times-of-war\/",
      "display_url" : "off-guardian.org\/2016\/05\/12\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730718926049529856",
  "text" : "The art of storytelling in times of war https:\/\/t.co\/JvQ9Olvpbe via @OffGuardian",
  "id" : 730718926049529856,
  "created_at" : "2016-05-12 11:19:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 0, 15 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/JPaye9i2x9",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Petrie_Multiplier",
      "display_url" : "en.wikipedia.org\/wiki\/Petrie_Mu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "730696056007217153",
  "geo" : { },
  "id_str" : "730708825137905664",
  "in_reply_to_user_id" : 27716419,
  "text" : "@CraigMurrayOrg maybe though i would not play down the sexist play by the right e.g. petrie multiplier https:\/\/t.co\/JPaye9i2x9",
  "id" : 730708825137905664,
  "in_reply_to_status_id" : 730696056007217153,
  "created_at" : "2016-05-12 10:38:54 +0000",
  "in_reply_to_screen_name" : "CraigMurrayOrg",
  "in_reply_to_user_id_str" : "27716419",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730557552933654528\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/rlYmOGGeoz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiN2MQHWsAAJBbT.jpg",
      "id_str" : "730557517420474368",
      "id" : 730557517420474368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiN2MQHWsAAJBbT.jpg",
      "sizes" : [ {
        "h" : 154,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/rlYmOGGeoz"
    } ],
    "hashtags" : [ {
      "text" : "RemoveALetterSpoilABook",
      "indices" : [ 10, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730557552933654528",
  "text" : "Now White #RemoveALetterSpoilABook https:\/\/t.co\/rlYmOGGeoz",
  "id" : 730557552933654528,
  "created_at" : "2016-05-12 00:37:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RemoveALetterSpoilABook",
      "indices" : [ 39, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730555580499169282",
  "geo" : { },
  "id_str" : "730556837091790848",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava doh autocorrect did me wrong #RemoveALetterSpoilABook",
  "id" : 730556837091790848,
  "in_reply_to_status_id" : 730555580499169282,
  "created_at" : "2016-05-12 00:34:57 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730555580499169282\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Su0qciS8JP",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiN0XkPWEAEg907.jpg",
      "id_str" : "730555512778002433",
      "id" : 730555512778002433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiN0XkPWEAEg907.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Su0qciS8JP"
    } ],
    "hashtags" : [ {
      "text" : "RemoveALetterSpoilAFilm",
      "indices" : [ 4, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730555580499169282",
  "text" : "984 #RemoveALetterSpoilAFilm https:\/\/t.co\/Su0qciS8JP",
  "id" : 730555580499169282,
  "created_at" : "2016-05-12 00:29:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730552339527049216",
  "geo" : { },
  "id_str" : "730552859998060544",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt close but no cigar : 0",
  "id" : 730552859998060544,
  "in_reply_to_status_id" : 730552339527049216,
  "created_at" : "2016-05-12 00:19:09 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730550471518195712",
  "geo" : { },
  "id_str" : "730550631690199040",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt with shades?",
  "id" : 730550631690199040,
  "in_reply_to_status_id" : 730550471518195712,
  "created_at" : "2016-05-12 00:10:18 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rockin' Rita",
      "screen_name" : "RockinRita03",
      "indices" : [ 0, 13 ],
      "id_str" : "17221890",
      "id" : 17221890
    }, {
      "name" : "J.C. Lillis",
      "screen_name" : "jclillis",
      "indices" : [ 14, 23 ],
      "id_str" : "208302411",
      "id" : 208302411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730550329180340224",
  "geo" : { },
  "id_str" : "730550497267073024",
  "in_reply_to_user_id" : 17221890,
  "text" : "@RockinRita03 @jclillis i agree : )",
  "id" : 730550497267073024,
  "in_reply_to_status_id" : 730550329180340224,
  "created_at" : "2016-05-12 00:09:46 +0000",
  "in_reply_to_screen_name" : "RockinRita03",
  "in_reply_to_user_id_str" : "17221890",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730549910618050561",
  "geo" : { },
  "id_str" : "730550281356881920",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt possibly also for me depends on what gifs available on twitter : )",
  "id" : 730550281356881920,
  "in_reply_to_status_id" : 730549910618050561,
  "created_at" : "2016-05-12 00:08:54 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.C. Lillis",
      "screen_name" : "jclillis",
      "indices" : [ 0, 9 ],
      "id_str" : "208302411",
      "id" : 208302411
    }, {
      "name" : "Rockin' Rita",
      "screen_name" : "RockinRita03",
      "indices" : [ 10, 23 ],
      "id_str" : "17221890",
      "id" : 17221890
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730550044605059072\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/n2QfSXoxr5",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNvQ6iXEAANCbx.jpg",
      "id_str" : "730549900946116608",
      "id" : 730549900946116608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNvQ6iXEAANCbx.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n2QfSXoxr5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730549108054867969",
  "geo" : { },
  "id_str" : "730550044605059072",
  "in_reply_to_user_id" : 208302411,
  "text" : "@jclillis @RockinRita03 thanks though was pointed put that spelling was Grey not Gray, so maybe Lana Del Rey? https:\/\/t.co\/n2QfSXoxr5",
  "id" : 730550044605059072,
  "in_reply_to_status_id" : 730549108054867969,
  "created_at" : "2016-05-12 00:07:58 +0000",
  "in_reply_to_screen_name" : "jclillis",
  "in_reply_to_user_id_str" : "208302411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730548363234447361\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/k2nVnaFBiy",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNtrSIWkAEWYVZ.jpg",
      "id_str" : "730548154932826113",
      "id" : 730548154932826113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNtrSIWkAEWYVZ.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/k2nVnaFBiy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730545977384415232",
  "geo" : { },
  "id_str" : "730548363234447361",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt could work also Lana Del Rey : ) https:\/\/t.co\/k2nVnaFBiy",
  "id" : 730548363234447361,
  "in_reply_to_status_id" : 730545977384415232,
  "created_at" : "2016-05-12 00:01:17 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730545759276412928",
  "geo" : { },
  "id_str" : "730545843158298624",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt doh!",
  "id" : 730545843158298624,
  "in_reply_to_status_id" : 730545759276412928,
  "created_at" : "2016-05-11 23:51:16 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730545526597365764\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/JsCyduUUKh",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNrFjLWUAQqfVL.jpg",
      "id_str" : "730545307650510852",
      "id" : 730545307650510852,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNrFjLWUAQqfVL.jpg",
      "sizes" : [ {
        "h" : 140,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 140,
        "resize" : "crop",
        "w" : 140
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/JsCyduUUKh"
    } ],
    "hashtags" : [ {
      "text" : "RemoveALetterSpoilABook",
      "indices" : [ 20, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730545526597365764",
  "text" : "Fifty shades of Ray #RemoveALetterSpoilABook https:\/\/t.co\/JsCyduUUKh",
  "id" : 730545526597365764,
  "created_at" : "2016-05-11 23:50:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 0, 13 ],
      "id_str" : "920491754",
      "id" : 920491754
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730544510757806080\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/vN75fdhnLf",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNqOtuWsAASk1W.jpg",
      "id_str" : "730544365588885504",
      "id" : 730544365588885504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNqOtuWsAASk1W.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/vN75fdhnLf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730543662866812929",
  "geo" : { },
  "id_str" : "730544510757806080",
  "in_reply_to_user_id" : 920491754,
  "text" : "@GretchenAMcC : ) https:\/\/t.co\/vN75fdhnLf",
  "id" : 730544510757806080,
  "in_reply_to_status_id" : 730543662866812929,
  "created_at" : "2016-05-11 23:45:58 +0000",
  "in_reply_to_screen_name" : "GretchenAMcC",
  "in_reply_to_user_id_str" : "920491754",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730542094557839360\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/Hmg2vRIa9v",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNoBAQWUAAVFGL.jpg",
      "id_str" : "730541931021881344",
      "id" : 730541931021881344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiNoBAQWUAAVFGL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Hmg2vRIa9v"
    } ],
    "hashtags" : [ {
      "text" : "RemoveALetterSpoilABook",
      "indices" : [ 23, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730542094557839360",
  "text" : "The Go of Small Things #RemoveALetterSpoilABook https:\/\/t.co\/Hmg2vRIa9v",
  "id" : 730542094557839360,
  "created_at" : "2016-05-11 23:36:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/mSBoFpxdOG",
      "expanded_url" : "http:\/\/ec.europa.eu\/translation\/english\/guidelines\/documents\/misused_english_terminology_eu_publications_en.pdf",
      "display_url" : "ec.europa.eu\/translation\/en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730537908575346688",
  "text" : "useful pdf on \"misused\" language in EU docs https:\/\/t.co\/mSBoFpxdOG",
  "id" : 730537908575346688,
  "created_at" : "2016-05-11 23:19:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Nguyen \u0F3C\u3046\u273F_\u273F\u0F3D\u3065",
      "screen_name" : "dancow",
      "indices" : [ 3, 10 ],
      "id_str" : "14335332",
      "id" : 14335332
    }, {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 41, 53 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dancow\/status\/730528992650887168\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/tJm4eL0VwZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiNcP2yUUAAVQc-.jpg",
      "id_str" : "730528992038506496",
      "id" : 730528992038506496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiNcP2yUUAAVQc-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1246,
        "resize" : "fit",
        "w" : 2414
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tJm4eL0VwZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/77g0nwOscA",
      "expanded_url" : "http:\/\/antiboredom.github.io\/streetviews\/",
      "display_url" : "antiboredom.github.io\/streetviews\/"
    } ]
  },
  "geo" : { },
  "id_str" : "730532201411006468",
  "text" : "RT @dancow: Love this hypnotic mashup by @sam_lavigne: Street Views of Real Estate Owned by Congress \nhttps:\/\/t.co\/77g0nwOscA https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Lavigne",
        "screen_name" : "sam_lavigne",
        "indices" : [ 29, 41 ],
        "id_str" : "6428702",
        "id" : 6428702
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dancow\/status\/730528992650887168\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/tJm4eL0VwZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiNcP2yUUAAVQc-.jpg",
        "id_str" : "730528992038506496",
        "id" : 730528992038506496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiNcP2yUUAAVQc-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1246,
          "resize" : "fit",
          "w" : 2414
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tJm4eL0VwZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/77g0nwOscA",
        "expanded_url" : "http:\/\/antiboredom.github.io\/streetviews\/",
        "display_url" : "antiboredom.github.io\/streetviews\/"
      } ]
    },
    "geo" : { },
    "id_str" : "730528992650887168",
    "text" : "Love this hypnotic mashup by @sam_lavigne: Street Views of Real Estate Owned by Congress \nhttps:\/\/t.co\/77g0nwOscA https:\/\/t.co\/tJm4eL0VwZ",
    "id" : 730528992650887168,
    "created_at" : "2016-05-11 22:44:19 +0000",
    "user" : {
      "name" : "Dan Nguyen \u0F3C\u3046\u273F_\u273F\u0F3D\u3065",
      "screen_name" : "dancow",
      "protected" : false,
      "id_str" : "14335332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3134267999\/54b1603856efb494c0fb6095089b769a_normal.jpeg",
      "id" : 14335332,
      "verified" : false
    }
  },
  "id" : 730532201411006468,
  "created_at" : "2016-05-11 22:57:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTmyths",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "shame",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730522253515960320",
  "text" : "RT @thornburyscott: Pearson demolishes myths in order to infiltrate a new one: that granular descriptors (i.e. GSE) promote learning. #ELTm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTmyths",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "shame",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729911675462258688",
    "text" : "Pearson demolishes myths in order to infiltrate a new one: that granular descriptors (i.e. GSE) promote learning. #ELTmyths #shame",
    "id" : 729911675462258688,
    "created_at" : "2016-05-10 05:51:19 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 730522253515960320,
  "created_at" : "2016-05-11 22:17:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/38gZIy2GRZ",
      "expanded_url" : "https:\/\/twitter.com\/ellensclass\/status\/730508406717448192",
      "display_url" : "twitter.com\/ellensclass\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730516938737258496",
  "text" : "neat idea audio eng lessons via the phone https:\/\/t.co\/38gZIy2GRZ",
  "id" : 730516938737258496,
  "created_at" : "2016-05-11 21:56:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 12, 20 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 21, 28 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730468927990550528",
  "geo" : { },
  "id_str" : "730516602320465920",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @Ven_VVE @EdLaur thx for sharing y'all : )",
  "id" : 730516602320465920,
  "in_reply_to_status_id" : 730468927990550528,
  "created_at" : "2016-05-11 21:55:04 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730468927990550528",
  "geo" : { },
  "id_str" : "730494214560174080",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy hi Eily thx for sharing : )",
  "id" : 730494214560174080,
  "in_reply_to_status_id" : 730468927990550528,
  "created_at" : "2016-05-11 20:26:07 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730450558096674816",
  "geo" : { },
  "id_str" : "730458573424185346",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran thanks for yr kind words : )",
  "id" : 730458573424185346,
  "in_reply_to_status_id" : 730450558096674816,
  "created_at" : "2016-05-11 18:04:29 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 68, 74 ],
      "id_str" : "105883895",
      "id" : 105883895
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 75, 82 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/730422270355755008\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/kYcwYuIT4j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiL7LqPWsAI0aAr.jpg",
      "id_str" : "730422267323265026",
      "id" : 730422267323265026,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiL7LqPWsAI0aAr.jpg",
      "sizes" : [ {
        "h" : 1140,
        "resize" : "fit",
        "w" : 1518
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 769,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kYcwYuIT4j"
    } ],
    "hashtags" : [ {
      "text" : "webinar",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "EMI",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "ELT",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "highered",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730444211183599617",
  "text" : "RT @_divyamadhavan: Very excited to be doing a #webinar on #EMI for @tdsig @iatefl this Saturday 3pm BST #ELT #highered https:\/\/t.co\/kYcwYu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TDSIG",
        "screen_name" : "tdsig",
        "indices" : [ 48, 54 ],
        "id_str" : "105883895",
        "id" : 105883895
      }, {
        "name" : "IATEFL Head Office",
        "screen_name" : "iatefl",
        "indices" : [ 55, 62 ],
        "id_str" : "85042286",
        "id" : 85042286
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/730422270355755008\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/kYcwYuIT4j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiL7LqPWsAI0aAr.jpg",
        "id_str" : "730422267323265026",
        "id" : 730422267323265026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiL7LqPWsAI0aAr.jpg",
        "sizes" : [ {
          "h" : 1140,
          "resize" : "fit",
          "w" : 1518
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 769,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kYcwYuIT4j"
      } ],
      "hashtags" : [ {
        "text" : "webinar",
        "indices" : [ 27, 35 ]
      }, {
        "text" : "EMI",
        "indices" : [ 39, 43 ]
      }, {
        "text" : "ELT",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "highered",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730422270355755008",
    "text" : "Very excited to be doing a #webinar on #EMI for @tdsig @iatefl this Saturday 3pm BST #ELT #highered https:\/\/t.co\/kYcwYuIT4j",
    "id" : 730422270355755008,
    "created_at" : "2016-05-11 15:40:14 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 730444211183599617,
  "created_at" : "2016-05-11 17:07:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ibrahim",
      "screen_name" : "Sirinne",
      "indices" : [ 0, 8 ],
      "id_str" : "61337075",
      "id" : 61337075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730400045695119360",
  "geo" : { },
  "id_str" : "730403934280503296",
  "in_reply_to_user_id" : 61337075,
  "text" : "@Sirinne this is can be seen as a prototype for mainstream media interview where some clueless pundit is asked for their clueless opinion :\/",
  "id" : 730403934280503296,
  "in_reply_to_status_id" : 730400045695119360,
  "created_at" : "2016-05-11 14:27:22 +0000",
  "in_reply_to_screen_name" : "Sirinne",
  "in_reply_to_user_id_str" : "61337075",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Neil Sensei",
      "screen_name" : "pocketclassroom",
      "indices" : [ 17, 33 ],
      "id_str" : "2316433934",
      "id" : 2316433934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730383934370906112",
  "geo" : { },
  "id_str" : "730402778150014976",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @pocketclassroom hey welcome to the twitterdome : )",
  "id" : 730402778150014976,
  "in_reply_to_status_id" : 730383934370906112,
  "created_at" : "2016-05-11 14:22:47 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 55, 71 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/OuzoiYt3BY",
      "expanded_url" : "https:\/\/educationbookcast.com\/2016\/05\/11\/18-bounce-by-matthew-syed\/",
      "display_url" : "educationbookcast.com\/2016\/05\/11\/18-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730356056463912960",
  "text" : "18. Bounce by Matthew Syed https:\/\/t.co\/OuzoiYt3BY via @wordpressdotcom",
  "id" : 730356056463912960,
  "created_at" : "2016-05-11 11:17:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/75mNJf8dML",
      "expanded_url" : "https:\/\/whispersystems.org",
      "display_url" : "whispersystems.org"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/qUmme5XpLZ",
      "expanded_url" : "https:\/\/twitter.com\/VincentFletcher\/status\/730295468052353024",
      "display_url" : "twitter.com\/VincentFletche\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730351923925270530",
  "text" : "RT @aral: Signal \u2013\u00A0https:\/\/t.co\/75mNJf8dML \u2013 a free and open, private messaging app for iPhone and Android. https:\/\/t.co\/qUmme5XpLZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/75mNJf8dML",
        "expanded_url" : "https:\/\/whispersystems.org",
        "display_url" : "whispersystems.org"
      }, {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/qUmme5XpLZ",
        "expanded_url" : "https:\/\/twitter.com\/VincentFletcher\/status\/730295468052353024",
        "display_url" : "twitter.com\/VincentFletche\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730316850689675264",
    "text" : "Signal \u2013\u00A0https:\/\/t.co\/75mNJf8dML \u2013 a free and open, private messaging app for iPhone and Android. https:\/\/t.co\/qUmme5XpLZ",
    "id" : 730316850689675264,
    "created_at" : "2016-05-11 08:41:20 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 730351923925270530,
  "created_at" : "2016-05-11 11:00:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 3, 14 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/j41Q45mtUT",
      "expanded_url" : "http:\/\/bit.ly\/1T4k80f",
      "display_url" : "bit.ly\/1T4k80f"
    } ]
  },
  "geo" : { },
  "id_str" : "730346592285429761",
  "text" : "RT @lynneguist: Do monolingual teachers produce a Golem effect in multilingual students? | Language on the Move https:\/\/t.co\/j41Q45mtUT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/j41Q45mtUT",
        "expanded_url" : "http:\/\/bit.ly\/1T4k80f",
        "display_url" : "bit.ly\/1T4k80f"
      } ]
    },
    "geo" : { },
    "id_str" : "730342579959631872",
    "text" : "Do monolingual teachers produce a Golem effect in multilingual students? | Language on the Move https:\/\/t.co\/j41Q45mtUT",
    "id" : 730342579959631872,
    "created_at" : "2016-05-11 10:23:34 +0000",
    "user" : {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "protected" : false,
      "id_str" : "16316886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632304665821081601\/BiPmyu1t_normal.jpg",
      "id" : 16316886,
      "verified" : false
    }
  },
  "id" : 730346592285429761,
  "created_at" : "2016-05-11 10:39:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "hippoedtech",
      "screen_name" : "hippoedtech",
      "indices" : [ 17, 29 ],
      "id_str" : "713345621650980864",
      "id" : 713345621650980864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729306024981626882",
  "geo" : { },
  "id_str" : "730345743614128128",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @hippoedtech thanks for the like!",
  "id" : 730345743614128128,
  "in_reply_to_status_id" : 729306024981626882,
  "created_at" : "2016-05-11 10:36:09 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730290499798577152",
  "geo" : { },
  "id_str" : "730345584348016640",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran thanks a lot! Ljiljana : )",
  "id" : 730345584348016640,
  "in_reply_to_status_id" : 730290499798577152,
  "created_at" : "2016-05-11 10:35:31 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 13, 29 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 30, 43 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729853264880013312",
  "geo" : { },
  "id_str" : "730345425090260992",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @MichaelChesnut2 @carol_goodey thx, appreciate the likes folks : )",
  "id" : 730345425090260992,
  "in_reply_to_status_id" : 729853264880013312,
  "created_at" : "2016-05-11 10:34:53 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730182116164534272",
  "geo" : { },
  "id_str" : "730345028309139457",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks and lol : )",
  "id" : 730345028309139457,
  "in_reply_to_status_id" : 730182116164534272,
  "created_at" : "2016-05-11 10:33:18 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 12, 21 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 22, 33 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 34, 45 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/730142262768832513\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/GcKtDCDX92",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiH8hLXWwAA6TJY.jpg",
      "id_str" : "730142261527363584",
      "id" : 730142261527363584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiH8hLXWwAA6TJY.jpg",
      "sizes" : [ {
        "h" : 755,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 755,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 755,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GcKtDCDX92"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/uCv7pF1Pq7",
      "expanded_url" : "http:\/\/bit.ly\/Franco1_2gig",
      "display_url" : "bit.ly\/Franco1_2gig"
    } ]
  },
  "in_reply_to_status_id_str" : "729731650502983680",
  "geo" : { },
  "id_str" : "730142262768832513",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @Hada_ELT @eilymurphy @hughdellar some interesting collocations for anglaise  https:\/\/t.co\/uCv7pF1Pq7 https:\/\/t.co\/GcKtDCDX92",
  "id" : 730142262768832513,
  "in_reply_to_status_id" : 729731650502983680,
  "created_at" : "2016-05-10 21:07:35 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 13, 29 ],
      "id_str" : "21313816",
      "id" : 21313816
    }, {
      "name" : "without names",
      "screen_name" : "Mylove19549273",
      "indices" : [ 30, 45 ],
      "id_str" : "722248345188741120",
      "id" : 722248345188741120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729853264880013312",
  "geo" : { },
  "id_str" : "730054519393009664",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @TeachingEnglish @Mylove19549273 thanks for the RT and like :)",
  "id" : 730054519393009664,
  "in_reply_to_status_id" : 729853264880013312,
  "created_at" : "2016-05-10 15:18:55 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/H1pfp37KGC",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/may\/02\/inside-ricu-the-shadowy-propaganda-unit-inspired-by-the-cold-war",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729976164626894848",
  "text" : "strategic communication, a new(?) euphemism for propaganda https:\/\/t.co\/H1pfp37KGC",
  "id" : 729976164626894848,
  "created_at" : "2016-05-10 10:07:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729916992103321600",
  "geo" : { },
  "id_str" : "729959012389761024",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott hi Scott what's the full ref for this? thanks",
  "id" : 729959012389761024,
  "in_reply_to_status_id" : 729916992103321600,
  "created_at" : "2016-05-10 08:59:25 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729853264880013312",
  "geo" : { },
  "id_str" : "729955459193540608",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers Anne : )",
  "id" : 729955459193540608,
  "in_reply_to_status_id" : 729853264880013312,
  "created_at" : "2016-05-10 08:45:18 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729817221275516928",
  "geo" : { },
  "id_str" : "729955383775789056",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hehe had to look that preach up not down with my slang : )",
  "id" : 729955383775789056,
  "in_reply_to_status_id" : 729817221275516928,
  "created_at" : "2016-05-10 08:45:00 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bellhooksinstitute",
      "screen_name" : "bellhooksinst",
      "indices" : [ 3, 17 ],
      "id_str" : "4329998356",
      "id" : 4329998356
    }, {
      "name" : "The Real bell hooks",
      "screen_name" : "bellhooks",
      "indices" : [ 46, 56 ],
      "id_str" : "125181345",
      "id" : 125181345
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bellhooksinst\/status\/729771450798907393\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/x8jvVYP5xH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCrRAvXAAA4yd1.jpg",
      "id_str" : "729771448378785792",
      "id" : 729771448378785792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCrRAvXAAA4yd1.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/x8jvVYP5xH"
    } ],
    "hashtags" : [ {
      "text" : "LEMONADE",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/IyTA5Ps1rH",
      "expanded_url" : "http:\/\/bit.ly\/1TAuG3k",
      "display_url" : "bit.ly\/1TAuG3k"
    } ]
  },
  "geo" : { },
  "id_str" : "729816246473113600",
  "text" : "RT @bellhooksinst: Thoughts on #LEMONADE from @bellhooks. https:\/\/t.co\/IyTA5Ps1rH https:\/\/t.co\/x8jvVYP5xH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Real bell hooks",
        "screen_name" : "bellhooks",
        "indices" : [ 27, 37 ],
        "id_str" : "125181345",
        "id" : 125181345
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bellhooksinst\/status\/729771450798907393\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/x8jvVYP5xH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCrRAvXAAA4yd1.jpg",
        "id_str" : "729771448378785792",
        "id" : 729771448378785792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCrRAvXAAA4yd1.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/x8jvVYP5xH"
      } ],
      "hashtags" : [ {
        "text" : "LEMONADE",
        "indices" : [ 12, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/IyTA5Ps1rH",
        "expanded_url" : "http:\/\/bit.ly\/1TAuG3k",
        "display_url" : "bit.ly\/1TAuG3k"
      } ]
    },
    "geo" : { },
    "id_str" : "729771450798907393",
    "text" : "Thoughts on #LEMONADE from @bellhooks. https:\/\/t.co\/IyTA5Ps1rH https:\/\/t.co\/x8jvVYP5xH",
    "id" : 729771450798907393,
    "created_at" : "2016-05-09 20:34:07 +0000",
    "user" : {
      "name" : "bellhooksinstitute",
      "screen_name" : "bellhooksinst",
      "protected" : false,
      "id_str" : "4329998356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671342926299959296\/gajmQCLU_normal.png",
      "id" : 4329998356,
      "verified" : false
    }
  },
  "id" : 729816246473113600,
  "created_at" : "2016-05-09 23:32:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729813083233914884",
  "geo" : { },
  "id_str" : "729813477959831552",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 hehe there is also the phenomenon of sock puppetry that today's social media systems are vulnerable to",
  "id" : 729813477959831552,
  "in_reply_to_status_id" : 729813083233914884,
  "created_at" : "2016-05-09 23:21:07 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729812862676381696",
  "text" : "hell must feel like going from a scoopit link to a linkis link to article you wanted :\/",
  "id" : 729812862676381696,
  "created_at" : "2016-05-09 23:18:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/12kXMnIZUy",
      "expanded_url" : "https:\/\/opendemocracy.net\/uk\/jamie-stern-weiner-norman-finkelstein\/american-jewish-scholar-behind-labour-s-antisemitism-scanda",
      "display_url" : "opendemocracy.net\/uk\/jamie-stern\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "729809269521002496",
  "geo" : { },
  "id_str" : "729811232136544256",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 Norman Finkelstein recent tweak on Godwin's law is worth mentioning https:\/\/t.co\/12kXMnIZUy",
  "id" : 729811232136544256,
  "in_reply_to_status_id" : 729809269521002496,
  "created_at" : "2016-05-09 23:12:11 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/729802759877349376\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/NKv2obDP5r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiDHvfmXEAAdZUE.jpg",
      "id_str" : "729802758384193536",
      "id" : 729802758384193536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiDHvfmXEAAdZUE.jpg",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/NKv2obDP5r"
    } ],
    "hashtags" : [ {
      "text" : "Facebook",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Mharez35k5",
      "expanded_url" : "https:\/\/goo.gl\/LL9n8v",
      "display_url" : "goo.gl\/LL9n8v"
    } ]
  },
  "geo" : { },
  "id_str" : "729810335755055104",
  "text" : "RT @josipa74: Does #Facebook cause people to have irrational bunfights? https:\/\/t.co\/Mharez35k5 https:\/\/t.co\/NKv2obDP5r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/729802759877349376\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/NKv2obDP5r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiDHvfmXEAAdZUE.jpg",
        "id_str" : "729802758384193536",
        "id" : 729802758384193536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiDHvfmXEAAdZUE.jpg",
        "sizes" : [ {
          "h" : 474,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/NKv2obDP5r"
      } ],
      "hashtags" : [ {
        "text" : "Facebook",
        "indices" : [ 5, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Mharez35k5",
        "expanded_url" : "https:\/\/goo.gl\/LL9n8v",
        "display_url" : "goo.gl\/LL9n8v"
      } ]
    },
    "geo" : { },
    "id_str" : "729802759877349376",
    "text" : "Does #Facebook cause people to have irrational bunfights? https:\/\/t.co\/Mharez35k5 https:\/\/t.co\/NKv2obDP5r",
    "id" : 729802759877349376,
    "created_at" : "2016-05-09 22:38:31 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 729810335755055104,
  "created_at" : "2016-05-09 23:08:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729690304387911680",
  "geo" : { },
  "id_str" : "729690628343406592",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT feck : ( it is possible to recover but long process",
  "id" : 729690628343406592,
  "in_reply_to_status_id" : 729690304387911680,
  "created_at" : "2016-05-09 15:12:57 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 17, 28 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 29, 40 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729306024981626882",
  "geo" : { },
  "id_str" : "729620125318516736",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @eilymurphy @EAPstephen thx ya sexy mfs : )",
  "id" : 729620125318516736,
  "in_reply_to_status_id" : 729306024981626882,
  "created_at" : "2016-05-09 10:32:48 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FireAnt",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/itrQmWqlZn",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/fireant\/",
      "display_url" : "laurenceanthony.net\/software\/firea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729395675474055170",
  "text" : "RT @antlabjp: Just released #FireAnt (version 1.0.2) for Windows and now Macintosh OS X. Get it here: https:\/\/t.co\/itrQmWqlZn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FireAnt",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/itrQmWqlZn",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/fireant\/",
        "display_url" : "laurenceanthony.net\/software\/firea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729351233916444674",
    "text" : "Just released #FireAnt (version 1.0.2) for Windows and now Macintosh OS X. Get it here: https:\/\/t.co\/itrQmWqlZn",
    "id" : 729351233916444674,
    "created_at" : "2016-05-08 16:44:19 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 729395675474055170,
  "created_at" : "2016-05-08 19:40:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 18, 34 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    }, {
      "name" : "Seumas Milne",
      "screen_name" : "SeumasMilne",
      "indices" : [ 103, 115 ],
      "id_str" : "319675272",
      "id" : 319675272
    }, {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "indices" : [ 117, 133 ],
      "id_str" : "3307929149",
      "id" : 3307929149
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/729393648194949120\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/b4PvAFzu8y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch9TqE9VIAEuhA1.jpg",
      "id_str" : "729393647007899649",
      "id" : 729393647007899649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch9TqE9VIAEuhA1.jpg",
      "sizes" : [ {
        "h" : 198,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 552
      } ],
      "display_url" : "pic.twitter.com\/b4PvAFzu8y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/wHri8xjntK",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2016-05-06\/labour-is-one-step-away-from-book-burning\/",
      "display_url" : "jonathan-cook.net\/blog\/2016-05-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729394148718092292",
  "text" : "RT @rosendo_joe: .@Jonathan_K_Cook:\"Labour is one step away from book-burning\"\nhttps:\/\/t.co\/wHri8xjntK\n@SeumasMilne \n@JeremyCorbyn4PM https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Cook",
        "screen_name" : "Jonathan_K_Cook",
        "indices" : [ 1, 17 ],
        "id_str" : "2459644405",
        "id" : 2459644405
      }, {
        "name" : "Seumas Milne",
        "screen_name" : "SeumasMilne",
        "indices" : [ 86, 98 ],
        "id_str" : "319675272",
        "id" : 319675272
      }, {
        "name" : "Jeremy Corbyn for PM",
        "screen_name" : "JeremyCorbyn4PM",
        "indices" : [ 100, 116 ],
        "id_str" : "3307929149",
        "id" : 3307929149
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/729393648194949120\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/b4PvAFzu8y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch9TqE9VIAEuhA1.jpg",
        "id_str" : "729393647007899649",
        "id" : 729393647007899649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch9TqE9VIAEuhA1.jpg",
        "sizes" : [ {
          "h" : 198,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 122,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 552
        } ],
        "display_url" : "pic.twitter.com\/b4PvAFzu8y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/wHri8xjntK",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2016-05-06\/labour-is-one-step-away-from-book-burning\/",
        "display_url" : "jonathan-cook.net\/blog\/2016-05-0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729393648194949120",
    "text" : ".@Jonathan_K_Cook:\"Labour is one step away from book-burning\"\nhttps:\/\/t.co\/wHri8xjntK\n@SeumasMilne \n@JeremyCorbyn4PM https:\/\/t.co\/b4PvAFzu8y",
    "id" : 729393648194949120,
    "created_at" : "2016-05-08 19:32:51 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 729394148718092292,
  "created_at" : "2016-05-08 19:34:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 0, 11 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729381030285737984",
  "geo" : { },
  "id_str" : "729381278907256832",
  "in_reply_to_user_id" : 3217729433,
  "text" : "@TeflEquity maybe storm in a teacup about standards?",
  "id" : 729381278907256832,
  "in_reply_to_status_id" : 729381030285737984,
  "created_at" : "2016-05-08 18:43:42 +0000",
  "in_reply_to_screen_name" : "TeflEquity",
  "in_reply_to_user_id_str" : "3217729433",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 60, 70 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/a5p4FGM12l",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/05\/08\/on-the-stupidity-of-nate-silver\/",
      "display_url" : "samkriss.wordpress.com\/2016\/05\/08\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729379718361927680",
  "text" : "On the stupidity of Nate Silver https:\/\/t.co\/a5p4FGM12l via @sam_kriss",
  "id" : 729379718361927680,
  "created_at" : "2016-05-08 18:37:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kCWQKYguqz",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.com\/2016\/05\/instructional-googling.html?spref=tw",
      "display_url" : "curmudgucation.blogspot.com\/2016\/05\/instru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729376149902659584",
  "text" : "CURMUDGUCATION: Instructional Googling https:\/\/t.co\/kCWQKYguqz",
  "id" : 729376149902659584,
  "created_at" : "2016-05-08 18:23:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxime Drouet",
      "screen_name" : "MrDrouet",
      "indices" : [ 0, 9 ],
      "id_str" : "3041329737",
      "id" : 3041329737
    }, {
      "name" : "helenebraund",
      "screen_name" : "helenebraund",
      "indices" : [ 10, 23 ],
      "id_str" : "2691088429",
      "id" : 2691088429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729344370768523267",
  "geo" : { },
  "id_str" : "729346091079090176",
  "in_reply_to_user_id" : 3041329737,
  "text" : "@MrDrouet @helenebraund oui c'est vrai et pour moi j'ai toujours mon portable :)",
  "id" : 729346091079090176,
  "in_reply_to_status_id" : 729344370768523267,
  "created_at" : "2016-05-08 16:23:53 +0000",
  "in_reply_to_screen_name" : "MrDrouet",
  "in_reply_to_user_id_str" : "3041329737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxime Drouet",
      "screen_name" : "MrDrouet",
      "indices" : [ 0, 9 ],
      "id_str" : "3041329737",
      "id" : 3041329737
    }, {
      "name" : "helenebraund",
      "screen_name" : "helenebraund",
      "indices" : [ 10, 23 ],
      "id_str" : "2691088429",
      "id" : 2691088429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719635906370646017",
  "geo" : { },
  "id_str" : "729344032002977792",
  "in_reply_to_user_id" : 3041329737,
  "text" : "@MrDrouet @helenebraund c'est aussi super simple avec #piratebox pour android",
  "id" : 729344032002977792,
  "in_reply_to_status_id" : 719635906370646017,
  "created_at" : "2016-05-08 16:15:42 +0000",
  "in_reply_to_screen_name" : "MrDrouet",
  "in_reply_to_user_id_str" : "3041329737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Mrozek",
      "screen_name" : "EvilDragon1717",
      "indices" : [ 3, 18 ],
      "id_str" : "108433145",
      "id" : 108433145
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/HWQDqnBmIY",
      "expanded_url" : "http:\/\/youtu.be\/rZDfTVX8Nb8?a",
      "display_url" : "youtu.be\/rZDfTVX8Nb8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "729339013816061952",
  "text" : "RT @EvilDragon1717: DragonBox Pyra - Quick overview: https:\/\/t.co\/HWQDqnBmIY via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 61, 69 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/HWQDqnBmIY",
        "expanded_url" : "http:\/\/youtu.be\/rZDfTVX8Nb8?a",
        "display_url" : "youtu.be\/rZDfTVX8Nb8?a"
      } ]
    },
    "geo" : { },
    "id_str" : "728789810987601920",
    "text" : "DragonBox Pyra - Quick overview: https:\/\/t.co\/HWQDqnBmIY via @YouTube",
    "id" : 728789810987601920,
    "created_at" : "2016-05-07 03:33:25 +0000",
    "user" : {
      "name" : "Michael Mrozek",
      "screen_name" : "EvilDragon1717",
      "protected" : false,
      "id_str" : "108433145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657029458\/EDSprite_normal.gif",
      "id" : 108433145,
      "verified" : false
    }
  },
  "id" : 729339013816061952,
  "created_at" : "2016-05-08 15:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/729318333150040064\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/7G6VsIJhax",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ch8PIaHXEAE_PIr.jpg",
      "id_str" : "729318301780873217",
      "id" : 729318301780873217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ch8PIaHXEAE_PIr.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7G6VsIJhax"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729306024981626882",
  "geo" : { },
  "id_str" : "729318333150040064",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish https:\/\/t.co\/7G6VsIJhax",
  "id" : 729318333150040064,
  "in_reply_to_status_id" : 729306024981626882,
  "created_at" : "2016-05-08 14:33:35 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/729292516625944576\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/Lz5X5ul2Oa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch73qlVWwAA_Lu0.jpg",
      "id_str" : "729292500628848640",
      "id" : 729292500628848640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch73qlVWwAA_Lu0.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Lz5X5ul2Oa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729292516625944576",
  "text" : "Magnetic fields https:\/\/t.co\/Lz5X5ul2Oa",
  "id" : 729292516625944576,
  "created_at" : "2016-05-08 12:51:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/729292163822039041\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/baeJhhtB4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch73V9RWMAEdrvs.jpg",
      "id_str" : "729292146277232641",
      "id" : 729292146277232641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch73V9RWMAEdrvs.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/baeJhhtB4h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729292163822039041",
  "text" : "Wifi light painting https:\/\/t.co\/baeJhhtB4h",
  "id" : 729292163822039041,
  "created_at" : "2016-05-08 12:49:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 12, 21 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 22, 33 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729284847529766912",
  "geo" : { },
  "id_str" : "729289186252066822",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @Hada_ELT @hughdellar possibly",
  "id" : 729289186252066822,
  "in_reply_to_status_id" : 729284847529766912,
  "created_at" : "2016-05-08 12:37:46 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 0, 11 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729230670359232512",
  "geo" : { },
  "id_str" : "729280793680461824",
  "in_reply_to_user_id" : 3217729433,
  "text" : "@TeflEquity Swan: proficient enough to \"maximise their chances of producing good enough learners with good enough English\"?",
  "id" : 729280793680461824,
  "in_reply_to_status_id" : 729230670359232512,
  "created_at" : "2016-05-08 12:04:25 +0000",
  "in_reply_to_screen_name" : "TeflEquity",
  "in_reply_to_user_id_str" : "3217729433",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 14, 25 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729277320461209601",
  "geo" : { },
  "id_str" : "729278864795553794",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @TeflEquity yr experience with teaching English as content (in add to as pedagog) wld have helped here?",
  "id" : 729278864795553794,
  "in_reply_to_status_id" : 729277320461209601,
  "created_at" : "2016-05-08 11:56:45 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 14, 25 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729274161219174402",
  "geo" : { },
  "id_str" : "729275885963087872",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @TeflEquity you were teaching someone with 20yrs dance experience, with a beginner dancer wd have same results?",
  "id" : 729275885963087872,
  "in_reply_to_status_id" : 729274161219174402,
  "created_at" : "2016-05-08 11:44:55 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Chris Bourg",
      "screen_name" : "mchris4duke",
      "indices" : [ 11, 23 ],
      "id_str" : "14093339",
      "id" : 14093339
    }, {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 24, 39 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729242458647867392",
  "geo" : { },
  "id_str" : "729274681094774784",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @mchris4duke @kamilaofprague thanks y'all : )",
  "id" : 729274681094774784,
  "in_reply_to_status_id" : 729242458647867392,
  "created_at" : "2016-05-08 11:40:07 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729242458647867392",
  "geo" : { },
  "id_str" : "729273668786921472",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha thanks Hana : )",
  "id" : 729273668786921472,
  "in_reply_to_status_id" : 729242458647867392,
  "created_at" : "2016-05-08 11:36:06 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729221673006682112",
  "geo" : { },
  "id_str" : "729227815992856576",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish great! look fwd to your thoughts : )",
  "id" : 729227815992856576,
  "in_reply_to_status_id" : 729221673006682112,
  "created_at" : "2016-05-08 08:33:54 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Jones",
      "screen_name" : "rlj1981",
      "indices" : [ 3, 11 ],
      "id_str" : "20262258",
      "id" : 20262258
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rlj1981\/status\/729211775011463168\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/vdHyk10emF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch6uPkcWwAANPxE.jpg",
      "id_str" : "729211772184477696",
      "id" : 729211772184477696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch6uPkcWwAANPxE.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/vdHyk10emF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729226390684438528",
  "text" : "RT @rlj1981: Morning all. This made me proper laugh https:\/\/t.co\/vdHyk10emF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rlj1981\/status\/729211775011463168\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/vdHyk10emF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch6uPkcWwAANPxE.jpg",
        "id_str" : "729211772184477696",
        "id" : 729211772184477696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch6uPkcWwAANPxE.jpg",
        "sizes" : [ {
          "h" : 483,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/vdHyk10emF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729211775011463168",
    "text" : "Morning all. This made me proper laugh https:\/\/t.co\/vdHyk10emF",
    "id" : 729211775011463168,
    "created_at" : "2016-05-08 07:30:09 +0000",
    "user" : {
      "name" : "Rachel Jones",
      "screen_name" : "rlj1981",
      "protected" : false,
      "id_str" : "20262258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600645932334604288\/eZOqqVeb_normal.jpg",
      "id" : 20262258,
      "verified" : false
    }
  },
  "id" : 729226390684438528,
  "created_at" : "2016-05-08 08:28:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa MacKinnon",
      "screen_name" : "WarwickLanguage",
      "indices" : [ 3, 19 ],
      "id_str" : "81817497",
      "id" : 81817497
    }, {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 54, 65 ],
      "id_str" : "14387055",
      "id" : 14387055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729225012943671297",
  "text" : "RT @WarwickLanguage: What's lovely about working with @heikephilp is her wonderful passion for learning. Thanks for another great #vrtwebcon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heike Philp",
        "screen_name" : "heikephilp",
        "indices" : [ 33, 44 ],
        "id_str" : "14387055",
        "id" : 14387055
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vrtwebcon",
        "indices" : [ 109, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729055150774603777",
    "text" : "What's lovely about working with @heikephilp is her wonderful passion for learning. Thanks for another great #vrtwebcon",
    "id" : 729055150774603777,
    "created_at" : "2016-05-07 21:07:47 +0000",
    "user" : {
      "name" : "Teresa MacKinnon",
      "screen_name" : "WarwickLanguage",
      "protected" : false,
      "id_str" : "81817497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754956635450200064\/iN-luRsi_normal.jpg",
      "id" : 81817497,
      "verified" : false
    }
  },
  "id" : 729225012943671297,
  "created_at" : "2016-05-08 08:22:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729052385666945024",
  "geo" : { },
  "id_str" : "729221239055716352",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish thanks Marc; just noticed yr addition to google docs thought i would be notified automatically seems not!",
  "id" : 729221239055716352,
  "in_reply_to_status_id" : 729052385666945024,
  "created_at" : "2016-05-08 08:07:46 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729059933849845760",
  "geo" : { },
  "id_str" : "729218023865880576",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle my pleasure Sharon : )",
  "id" : 729218023865880576,
  "in_reply_to_status_id" : 729059933849845760,
  "created_at" : "2016-05-08 07:54:59 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 10, 19 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 20, 30 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729052385666945024",
  "geo" : { },
  "id_str" : "729217912150593538",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @Marisa_C @curvedway thanks for RT folks : )",
  "id" : 729217912150593538,
  "in_reply_to_status_id" : 729052385666945024,
  "created_at" : "2016-05-08 07:54:33 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/729052385666945024\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/FXW8ioQ0bL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4dR_NUkAAqE07.jpg",
      "id_str" : "729052384542887936",
      "id" : 729052384542887936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4dR_NUkAAqE07.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 661
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 661
      } ],
      "display_url" : "pic.twitter.com\/FXW8ioQ0bL"
    } ],
    "hashtags" : [ {
      "text" : "VRTwebcon",
      "indices" : [ 40, 50 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "tesol",
      "indices" : [ 62, 68 ]
    }, {
      "text" : "tefl",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "esl",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/BrcHwc2Exp",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/05\/07\/alphabet-street-aka-corpus-symposium-at-vrtwebcon-8",
      "display_url" : "eflnotes.wordpress.com\/2016\/05\/07\/alp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729052385666945024",
  "text" : "Alphabet Street aka Corpus Symposium at #VRTwebcon 8 #eltchat #tesol #tefl #esl https:\/\/t.co\/BrcHwc2Exp https:\/\/t.co\/FXW8ioQ0bL",
  "id" : 729052385666945024,
  "created_at" : "2016-05-07 20:56:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 97, 104 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/XeaKEOd2Jv",
      "expanded_url" : "https:\/\/hartlelearning.wordpress.com\/2016\/05\/07\/the-online-corpus-symposium-at-the-virtual-round-table-6th-may-2016\/",
      "display_url" : "hartlelearning.wordpress.com\/2016\/05\/07\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729051219193438213",
  "text" : "The Online Corpus Symposium, at the Virtual Round Table 6th May 2016 https:\/\/t.co\/XeaKEOd2Jv via @hartle",
  "id" : 729051219193438213,
  "created_at" : "2016-05-07 20:52:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The man with the #'s",
      "screen_name" : "ArturoGalletti",
      "indices" : [ 3, 18 ],
      "id_str" : "160998794",
      "id" : 160998794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/JmWc1aMEZf",
      "expanded_url" : "https:\/\/twitter.com\/mhess4\/status\/728956808338014208",
      "display_url" : "twitter.com\/mhess4\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728971549542322178",
  "text" : "RT @ArturoGalletti: How dare he look Italian and do math on a plane! He must be a terrorist!\nI may be in trouble when I fly.. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/JmWc1aMEZf",
        "expanded_url" : "https:\/\/twitter.com\/mhess4\/status\/728956808338014208",
        "display_url" : "twitter.com\/mhess4\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728967172559622146",
    "text" : "How dare he look Italian and do math on a plane! He must be a terrorist!\nI may be in trouble when I fly.. https:\/\/t.co\/JmWc1aMEZf",
    "id" : 728967172559622146,
    "created_at" : "2016-05-07 15:18:12 +0000",
    "user" : {
      "name" : "The man with the #'s",
      "screen_name" : "ArturoGalletti",
      "protected" : false,
      "id_str" : "160998794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730945175074144256\/s-r_sxr6_normal.jpg",
      "id" : 160998794,
      "verified" : false
    }
  },
  "id" : 728971549542322178,
  "created_at" : "2016-05-07 15:35:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rohan",
      "screen_name" : "Chops8592",
      "indices" : [ 3, 13 ],
      "id_str" : "1892283186",
      "id" : 1892283186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Chops8592\/status\/728912015876603905\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/O7GH0890Mf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch2dnNCWkAEhSyb.jpg",
      "id_str" : "728912011543875585",
      "id" : 728912011543875585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch2dnNCWkAEhSyb.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 593
      } ],
      "display_url" : "pic.twitter.com\/O7GH0890Mf"
    } ],
    "hashtags" : [ {
      "text" : "LondonHasFallen",
      "indices" : [ 79, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728941782839508992",
  "text" : "RT @Chops8592: It's barely been a day and already the Queen is wearing a hijab #LondonHasFallen https:\/\/t.co\/O7GH0890Mf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Chops8592\/status\/728912015876603905\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/O7GH0890Mf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch2dnNCWkAEhSyb.jpg",
        "id_str" : "728912011543875585",
        "id" : 728912011543875585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch2dnNCWkAEhSyb.jpg",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 593
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 593
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 593
        } ],
        "display_url" : "pic.twitter.com\/O7GH0890Mf"
      } ],
      "hashtags" : [ {
        "text" : "LondonHasFallen",
        "indices" : [ 64, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728912015876603905",
    "text" : "It's barely been a day and already the Queen is wearing a hijab #LondonHasFallen https:\/\/t.co\/O7GH0890Mf",
    "id" : 728912015876603905,
    "created_at" : "2016-05-07 11:39:01 +0000",
    "user" : {
      "name" : "Rohan",
      "screen_name" : "Chops8592",
      "protected" : false,
      "id_str" : "1892283186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000717332842\/fe0986be1c63c08d571dc85cb4276cf3_normal.jpeg",
      "id" : 1892283186,
      "verified" : false
    }
  },
  "id" : 728941782839508992,
  "created_at" : "2016-05-07 13:37:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "indices" : [ 0, 14 ],
      "id_str" : "3187104424",
      "id" : 3187104424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728932881985355776",
  "geo" : { },
  "id_str" : "728934728531906561",
  "in_reply_to_user_id" : 3187104424,
  "text" : "@EngliciousUCL paywall",
  "id" : 728934728531906561,
  "in_reply_to_status_id" : 728932881985355776,
  "created_at" : "2016-05-07 13:09:16 +0000",
  "in_reply_to_screen_name" : "EngliciousUCL",
  "in_reply_to_user_id_str" : "3187104424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 0, 13 ],
      "id_str" : "495430242",
      "id" : 495430242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nlp",
      "indices" : [ 24, 28 ]
    }, {
      "text" : "nulp",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "pulp",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728930936600055808",
  "geo" : { },
  "id_str" : "728931860441661440",
  "in_reply_to_user_id" : 495430242,
  "text" : "@IgorBrigadir the other #nlp can have #nulp : ) rhymes with #pulp",
  "id" : 728931860441661440,
  "in_reply_to_status_id" : 728930936600055808,
  "created_at" : "2016-05-07 12:57:53 +0000",
  "in_reply_to_screen_name" : "IgorBrigadir",
  "in_reply_to_user_id_str" : "495430242",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NLP",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/t215QozHPL",
      "expanded_url" : "https:\/\/twitter.com\/lowlandscph\/status\/728905195229487105",
      "display_url" : "twitter.com\/lowlandscph\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728931356303106050",
  "text" : "RT @IgorBrigadir: Make #NLP Great Again! :D https:\/\/t.co\/t215QozHPL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NLP",
        "indices" : [ 5, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/t215QozHPL",
        "expanded_url" : "https:\/\/twitter.com\/lowlandscph\/status\/728905195229487105",
        "display_url" : "twitter.com\/lowlandscph\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728914741087834113",
    "text" : "Make #NLP Great Again! :D https:\/\/t.co\/t215QozHPL",
    "id" : 728914741087834113,
    "created_at" : "2016-05-07 11:49:51 +0000",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 728931356303106050,
  "created_at" : "2016-05-07 12:55:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/1RC8sA4GIz",
      "expanded_url" : "https:\/\/twitter.com\/standardnews\/status\/728737669291839488",
      "display_url" : "twitter.com\/standardnews\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728930629711171584",
  "text" : "RT @pchallinor: Scary Muslim in Hamas-style coup horror https:\/\/t.co\/1RC8sA4GIz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/1RC8sA4GIz",
        "expanded_url" : "https:\/\/twitter.com\/standardnews\/status\/728737669291839488",
        "display_url" : "twitter.com\/standardnews\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728928631133773824",
    "text" : "Scary Muslim in Hamas-style coup horror https:\/\/t.co\/1RC8sA4GIz",
    "id" : 728928631133773824,
    "created_at" : "2016-05-07 12:45:03 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 728930629711171584,
  "created_at" : "2016-05-07 12:52:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 47, 63 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/NVSbInIZTD",
      "expanded_url" : "https:\/\/handsupproject.org\/2016\/05\/07\/send-in-the-clowns\/",
      "display_url" : "handsupproject.org\/2016\/05\/07\/sen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728927799453597697",
  "text" : "Send in the clowns https:\/\/t.co\/NVSbInIZTD via @wordpressdotcom",
  "id" : 728927799453597697,
  "created_at" : "2016-05-07 12:41:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogme",
      "indices" : [ 120, 126 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 127, 136 ]
    }, {
      "text" : "asiaelt",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/s7uxe2a463",
      "expanded_url" : "https:\/\/timedingtable.wordpress.com\/2016\/05\/07\/using-student-output-a-personal-story-and-restructuring\/",
      "display_url" : "timedingtable.wordpress.com\/2016\/05\/07\/usi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728924621244932096",
  "text" : "RT @michaelegriffin: Using student output: a personal story and restructuring https:\/\/t.co\/s7uxe2a463 Interesting post! #dogme #KELTchat #a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dogme",
        "indices" : [ 99, 105 ]
      }, {
        "text" : "KELTchat",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "asiaelt",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/s7uxe2a463",
        "expanded_url" : "https:\/\/timedingtable.wordpress.com\/2016\/05\/07\/using-student-output-a-personal-story-and-restructuring\/",
        "display_url" : "timedingtable.wordpress.com\/2016\/05\/07\/usi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728922264607985665",
    "text" : "Using student output: a personal story and restructuring https:\/\/t.co\/s7uxe2a463 Interesting post! #dogme #KELTchat #asiaelt #eltchat",
    "id" : 728922264607985665,
    "created_at" : "2016-05-07 12:19:45 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 728924621244932096,
  "created_at" : "2016-05-07 12:29:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 7, 15 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728902228539478017",
  "geo" : { },
  "id_str" : "728920003102314496",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @Sugatam maybe search for research on webquests?",
  "id" : 728920003102314496,
  "in_reply_to_status_id" : 728902228539478017,
  "created_at" : "2016-05-07 12:10:46 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 3, 16 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl2016",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "CorporaJournal",
      "indices" : [ 30, 45 ]
    }, {
      "text" : "SketchEngine",
      "indices" : [ 46, 59 ]
    }, {
      "text" : "corpusbaalsig",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/mYZoNtxoLU",
      "expanded_url" : "http:\/\/bit.ly\/lang_questions_corpora",
      "display_url" : "bit.ly\/lang_questions\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728919544228655104",
  "text" : "RT @versatilepub: #iatefl2016 #CorporaJournal #SketchEngine #corpusbaalsig My IATELF 16 ppt Answering Language Questions from Corpora\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl2016",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "CorporaJournal",
        "indices" : [ 12, 27 ]
      }, {
        "text" : "SketchEngine",
        "indices" : [ 28, 41 ]
      }, {
        "text" : "corpusbaalsig",
        "indices" : [ 42, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/mYZoNtxoLU",
        "expanded_url" : "http:\/\/bit.ly\/lang_questions_corpora",
        "display_url" : "bit.ly\/lang_questions\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728883691200630784",
    "text" : "#iatefl2016 #CorporaJournal #SketchEngine #corpusbaalsig My IATELF 16 ppt Answering Language Questions from Corpora\nhttps:\/\/t.co\/mYZoNtxoLU",
    "id" : 728883691200630784,
    "created_at" : "2016-05-07 09:46:28 +0000",
    "user" : {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "protected" : false,
      "id_str" : "3243120760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596936187534704640\/HR5PkkoP_normal.jpg",
      "id" : 3243120760,
      "verified" : false
    }
  },
  "id" : 728919544228655104,
  "created_at" : "2016-05-07 12:08:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 12, 23 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728700483284697089",
  "geo" : { },
  "id_str" : "728703202439344128",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @hughdellar this is probably very close generally though after bad language i have often heard excusez-moi hein : )",
  "id" : 728703202439344128,
  "in_reply_to_status_id" : 728700483284697089,
  "created_at" : "2016-05-06 21:49:16 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Reddin",
      "screen_name" : "ReddinGavin",
      "indices" : [ 0, 12 ],
      "id_str" : "2723204205",
      "id" : 2723204205
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 13, 24 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728699823562620928",
  "geo" : { },
  "id_str" : "728700494617686016",
  "in_reply_to_user_id" : 2723204205,
  "text" : "@ReddinGavin @hughdellar closest maybe pardonnez-moi l'expression but doesn't quite captcha after swear words i think",
  "id" : 728700494617686016,
  "in_reply_to_status_id" : 728699823562620928,
  "created_at" : "2016-05-06 21:38:31 +0000",
  "in_reply_to_screen_name" : "ReddinGavin",
  "in_reply_to_user_id_str" : "2723204205",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/mUjFGJxBlT",
      "expanded_url" : "https:\/\/sites.google.com\/a\/isp.cz\/isp-corpus\/home",
      "display_url" : "sites.google.com\/a\/isp.cz\/isp-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728695693058125826",
  "text" : "who says corpora are only for uni level learners? here are 14-15 yr olds doing the corpus thang https:\/\/t.co\/mUjFGJxBlT h\/t CorpusCALL",
  "id" : 728695693058125826,
  "created_at" : "2016-05-06 21:19:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 10, 21 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 22, 29 ],
      "id_str" : "20324125",
      "id" : 20324125
    }, {
      "name" : "Jennie Wright",
      "screen_name" : "teflhelper",
      "indices" : [ 30, 41 ],
      "id_str" : "1728294235",
      "id" : 1728294235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728655075728576512",
  "geo" : { },
  "id_str" : "728655398664863745",
  "in_reply_to_user_id" : 44631065,
  "text" : "@Hada_ELT @leoselivan @hartle @teflhelper thanks for your support Hada : )",
  "id" : 728655398664863745,
  "in_reply_to_status_id" : 728655075728576512,
  "created_at" : "2016-05-06 18:39:19 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728634352830156800",
  "geo" : { },
  "id_str" : "728636716848971776",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco hi Diane look at Paul's timeline tweet before this",
  "id" : 728636716848971776,
  "in_reply_to_status_id" : 728634352830156800,
  "created_at" : "2016-05-06 17:25:05 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728631585768132608",
  "geo" : { },
  "id_str" : "728632548943929344",
  "in_reply_to_user_id" : 18602422,
  "text" : "@perayson ah just saw your slides cool!",
  "id" : 728632548943929344,
  "in_reply_to_status_id" : 728631585768132608,
  "created_at" : "2016-05-06 17:08:31 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 3, 12 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baal",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/APvKwEEIrk",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/paul\/BAAL_CL_SIG_PR_May2016.pdf",
      "display_url" : "ucrel.lancs.ac.uk\/paul\/BAAL_CL_S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728631985846034436",
  "text" : "RT @perayson: Slides from my #baal corpus linguistics SIG talk at Aston Uni today are available at: https:\/\/t.co\/APvKwEEIrk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "baal",
        "indices" : [ 15, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/APvKwEEIrk",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/paul\/BAAL_CL_SIG_PR_May2016.pdf",
        "display_url" : "ucrel.lancs.ac.uk\/paul\/BAAL_CL_S\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728600471909339136",
    "text" : "Slides from my #baal corpus linguistics SIG talk at Aston Uni today are available at: https:\/\/t.co\/APvKwEEIrk",
    "id" : 728600471909339136,
    "created_at" : "2016-05-06 15:01:03 +0000",
    "user" : {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "protected" : false,
      "id_str" : "263108959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490485533911445505\/BNOoOchF_normal.jpeg",
      "id" : 263108959,
      "verified" : false
    }
  },
  "id" : 728631985846034436,
  "created_at" : "2016-05-06 17:06:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 10, 25 ],
      "id_str" : "9280142",
      "id" : 9280142
    }, {
      "name" : "Danny McDonald",
      "screen_name" : "interro_gator",
      "indices" : [ 26, 40 ],
      "id_str" : "2896075806",
      "id" : 2896075806
    }, {
      "name" : "CorCenCC",
      "screen_name" : "CorCenCC",
      "indices" : [ 41, 50 ],
      "id_str" : "3945092685",
      "id" : 3945092685
    }, {
      "name" : "ProgrammingHistorian",
      "screen_name" : "ProgHist",
      "indices" : [ 51, 60 ],
      "id_str" : "607602141",
      "id" : 607602141
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 61, 70 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728600870405996544",
  "geo" : { },
  "id_str" : "728631585768132608",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson @williamjturkel @interro_gator @CorCenCC @ProgHist @antlabjp oh what's that about?",
  "id" : 728631585768132608,
  "in_reply_to_status_id" : 728600870405996544,
  "created_at" : "2016-05-06 17:04:42 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 36, 45 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 46, 53 ],
      "id_str" : "20324125",
      "id" : 20324125
    }, {
      "name" : "Jennie Wright",
      "screen_name" : "teflhelper",
      "indices" : [ 54, 65 ],
      "id_str" : "1728294235",
      "id" : 1728294235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/T918aYLPhN",
      "expanded_url" : "http:\/\/www.virtual-round-table.com\/page\/program-overview",
      "display_url" : "virtual-round-table.com\/page\/program-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728631459049820160",
  "text" : "RT @leoselivan: Corpus symposium w\/ @muranava @hartle @teflhelper TODAY 5pm GMT\/ 7pm CET\/ 1pm EST 8th Virtual Round Table #vrtwebcon https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 20, 29 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Sharon Hartle",
        "screen_name" : "hartle",
        "indices" : [ 30, 37 ],
        "id_str" : "20324125",
        "id" : 20324125
      }, {
        "name" : "Jennie Wright",
        "screen_name" : "teflhelper",
        "indices" : [ 38, 49 ],
        "id_str" : "1728294235",
        "id" : 1728294235
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vrtwebcon",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/T918aYLPhN",
        "expanded_url" : "http:\/\/www.virtual-round-table.com\/page\/program-overview",
        "display_url" : "virtual-round-table.com\/page\/program-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728518218076295168",
    "text" : "Corpus symposium w\/ @muranava @hartle @teflhelper TODAY 5pm GMT\/ 7pm CET\/ 1pm EST 8th Virtual Round Table #vrtwebcon https:\/\/t.co\/T918aYLPhN",
    "id" : 728518218076295168,
    "created_at" : "2016-05-06 09:34:13 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 728631459049820160,
  "created_at" : "2016-05-06 17:04:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "indices" : [ 0, 14 ],
      "id_str" : "394987109",
      "id" : 394987109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728609953699618816",
  "geo" : { },
  "id_str" : "728626797747818496",
  "in_reply_to_user_id" : 394987109,
  "text" : "@MatthewEllman hi i think so",
  "id" : 728626797747818496,
  "in_reply_to_status_id" : 728609953699618816,
  "created_at" : "2016-05-06 16:45:40 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/QppMTch6eL",
      "expanded_url" : "https:\/\/adaptivelearninginelt.wordpress.com\/2016\/05\/06\/apps-to-forget-about-1-vocabulist\/comment-page-1\/#comment-812",
      "display_url" : "adaptivelearninginelt.wordpress.com\/2016\/05\/06\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728554360721031168",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei hi Paul comment here on text2flash https:\/\/t.co\/QppMTch6eL",
  "id" : 728554360721031168,
  "created_at" : "2016-05-06 11:57:50 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Kunter",
      "screen_name" : "GeroKunter",
      "indices" : [ 0, 11 ],
      "id_str" : "3200846967",
      "id" : 3200846967
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/728551021715329024\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/QfPrUMNmeq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChxVSxVWEAIMJ1x.jpg",
      "id_str" : "728551020696047618",
      "id" : 728551020696047618,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChxVSxVWEAIMJ1x.jpg",
      "sizes" : [ {
        "h" : 697,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 522
      } ],
      "display_url" : "pic.twitter.com\/QfPrUMNmeq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728475921288548354",
  "geo" : { },
  "id_str" : "728551021715329024",
  "in_reply_to_user_id" : 3200846967,
  "text" : "@GeroKunter hi tried various pdfs i get error as attached image https:\/\/t.co\/QfPrUMNmeq",
  "id" : 728551021715329024,
  "in_reply_to_status_id" : 728475921288548354,
  "created_at" : "2016-05-06 11:44:34 +0000",
  "in_reply_to_screen_name" : "GeroKunter",
  "in_reply_to_user_id_str" : "3200846967",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Norman Finkelstein",
      "screen_name" : "normfinkelstein",
      "indices" : [ 11, 27 ],
      "id_str" : "32250446",
      "id" : 32250446
    }, {
      "name" : "JamieSW",
      "screen_name" : "jsternweiner",
      "indices" : [ 28, 41 ],
      "id_str" : "3028885138",
      "id" : 3028885138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728124502786248709",
  "geo" : { },
  "id_str" : "728323675871678464",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @normfinkelstein @jsternweiner though as Finkelstein notes the commentariat have no shame",
  "id" : 728323675871678464,
  "in_reply_to_status_id" : 728124502786248709,
  "created_at" : "2016-05-05 20:41:10 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poetry Translation",
      "screen_name" : "PoetryTranslate",
      "indices" : [ 3, 19 ],
      "id_str" : "58425213",
      "id" : 58425213
    }, {
      "name" : "warsan shire",
      "screen_name" : "warsan_shire",
      "indices" : [ 72, 85 ],
      "id_str" : "231663232",
      "id" : 231663232
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PoetryTranslate\/status\/725665436159844352\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/hMeCGQA7EW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChIU3nDWMAAa5KE.jpg",
      "id_str" : "725665435568451584",
      "id" : 725665435568451584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChIU3nDWMAAa5KE.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/hMeCGQA7EW"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/PoetryTranslate\/status\/725665436159844352\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/hMeCGQA7EW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChIU3jVUUAIcUkB.jpg",
      "id_str" : "725665434570084354",
      "id" : 725665434570084354,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChIU3jVUUAIcUkB.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/hMeCGQA7EW"
    } ],
    "hashtags" : [ {
      "text" : "Lemonade",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/0rqLrYPT2f",
      "expanded_url" : "http:\/\/buff.ly\/1N17ZbS",
      "display_url" : "buff.ly\/1N17ZbS"
    } ]
  },
  "geo" : { },
  "id_str" : "728319706558566402",
  "text" : "RT @PoetryTranslate: Loving the big excitment about Somali-British poet @warsan_shire's turn on #Lemonade.  https:\/\/t.co\/0rqLrYPT2f https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "warsan shire",
        "screen_name" : "warsan_shire",
        "indices" : [ 51, 64 ],
        "id_str" : "231663232",
        "id" : 231663232
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PoetryTranslate\/status\/725665436159844352\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/hMeCGQA7EW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChIU3nDWMAAa5KE.jpg",
        "id_str" : "725665435568451584",
        "id" : 725665435568451584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChIU3nDWMAAa5KE.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/hMeCGQA7EW"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/PoetryTranslate\/status\/725665436159844352\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/hMeCGQA7EW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChIU3jVUUAIcUkB.jpg",
        "id_str" : "725665434570084354",
        "id" : 725665434570084354,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChIU3jVUUAIcUkB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/hMeCGQA7EW"
      } ],
      "hashtags" : [ {
        "text" : "Lemonade",
        "indices" : [ 75, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/0rqLrYPT2f",
        "expanded_url" : "http:\/\/buff.ly\/1N17ZbS",
        "display_url" : "buff.ly\/1N17ZbS"
      } ]
    },
    "geo" : { },
    "id_str" : "725665436159844352",
    "text" : "Loving the big excitment about Somali-British poet @warsan_shire's turn on #Lemonade.  https:\/\/t.co\/0rqLrYPT2f https:\/\/t.co\/hMeCGQA7EW",
    "id" : 725665436159844352,
    "created_at" : "2016-04-28 12:38:16 +0000",
    "user" : {
      "name" : "Poetry Translation",
      "screen_name" : "PoetryTranslate",
      "protected" : false,
      "id_str" : "58425213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464795203\/ptc_logo_facebook_normal.gif",
      "id" : 58425213,
      "verified" : false
    }
  },
  "id" : 728319706558566402,
  "created_at" : "2016-05-05 20:25:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Norman Finkelstein",
      "screen_name" : "normfinkelstein",
      "indices" : [ 53, 69 ],
      "id_str" : "32250446",
      "id" : 32250446
    }, {
      "name" : "JamieSW",
      "screen_name" : "jsternweiner",
      "indices" : [ 74, 87 ],
      "id_str" : "3028885138",
      "id" : 3028885138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/yaXyhjijRG",
      "expanded_url" : "https:\/\/jamiesternweiner.wordpress.com\/2016\/05\/04\/norman-finkelstein-on-david-camerons-dodgy-friends\/",
      "display_url" : "jamiesternweiner.wordpress.com\/2016\/05\/04\/nor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728314129283465219",
  "text" : "RT @medialens: Once again, in just a few paragraphs, @normfinkelstein and @jsternweiner shame the entire corporate commentariat https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Norman Finkelstein",
        "screen_name" : "normfinkelstein",
        "indices" : [ 38, 54 ],
        "id_str" : "32250446",
        "id" : 32250446
      }, {
        "name" : "JamieSW",
        "screen_name" : "jsternweiner",
        "indices" : [ 59, 72 ],
        "id_str" : "3028885138",
        "id" : 3028885138
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/yaXyhjijRG",
        "expanded_url" : "https:\/\/jamiesternweiner.wordpress.com\/2016\/05\/04\/norman-finkelstein-on-david-camerons-dodgy-friends\/",
        "display_url" : "jamiesternweiner.wordpress.com\/2016\/05\/04\/nor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728124502786248709",
    "text" : "Once again, in just a few paragraphs, @normfinkelstein and @jsternweiner shame the entire corporate commentariat https:\/\/t.co\/yaXyhjijRG",
    "id" : 728124502786248709,
    "created_at" : "2016-05-05 07:29:44 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 728314129283465219,
  "created_at" : "2016-05-05 20:03:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728304652115120129",
  "geo" : { },
  "id_str" : "728306038689140738",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway : (",
  "id" : 728306038689140738,
  "in_reply_to_status_id" : 728304652115120129,
  "created_at" : "2016-05-05 19:31:05 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 12, 23 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "indices" : [ 24, 38 ],
      "id_str" : "394987109",
      "id" : 394987109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728176277967020032",
  "geo" : { },
  "id_str" : "728304438528577536",
  "in_reply_to_user_id" : 18602422,
  "text" : "@leoselivan @lexicoloco @MatthewEllman thks for like\/RT Diane &amp; Matt, maybe see you there? : )",
  "id" : 728304438528577536,
  "in_reply_to_status_id" : 728176277967020032,
  "created_at" : "2016-05-05 19:24:44 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/sTy2HPolBV",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/may\/05\/apple-taxes-cupertino-mayor-infrastructure-plan",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728283726413746176",
  "text" : "RT @pchallinor: California town mayor fundamentally misunderstands the point of wealth creation https:\/\/t.co\/sTy2HPolBV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/sTy2HPolBV",
        "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/may\/05\/apple-taxes-cupertino-mayor-infrastructure-plan",
        "display_url" : "theguardian.com\/technology\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728282299494699008",
    "text" : "California town mayor fundamentally misunderstands the point of wealth creation https:\/\/t.co\/sTy2HPolBV",
    "id" : 728282299494699008,
    "created_at" : "2016-05-05 17:56:45 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 728283726413746176,
  "created_at" : "2016-05-05 18:02:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728261816292388865",
  "geo" : { },
  "id_str" : "728265617212514304",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn have a good one, look fwd to any padlet notes : )",
  "id" : 728265617212514304,
  "in_reply_to_status_id" : 728261816292388865,
  "created_at" : "2016-05-05 16:50:28 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/728241971739906048\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/NZz4TlITwA",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Chs8BG1XEAAMbPd.jpg",
      "id_str" : "728241754462425088",
      "id" : 728241754462425088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Chs8BG1XEAAMbPd.jpg",
      "sizes" : [ {
        "h" : 344,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/NZz4TlITwA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728240703831158784",
  "geo" : { },
  "id_str" : "728241971739906048",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor we peasants should not doubt their sincerity https:\/\/t.co\/NZz4TlITwA",
  "id" : 728241971739906048,
  "in_reply_to_status_id" : 728240703831158784,
  "created_at" : "2016-05-05 15:16:30 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeutschTraining",
      "screen_name" : "DeutschTraining",
      "indices" : [ 3, 19 ],
      "id_str" : "1215586825",
      "id" : 1215586825
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DeutschTraining\/status\/728208635923472389\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/9na7NFzkWR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chsd5V1XEAETT-Z.jpg",
      "id_str" : "728208635701170177",
      "id" : 728208635701170177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chsd5V1XEAETT-Z.jpg",
      "sizes" : [ {
        "h" : 293,
        "resize" : "fit",
        "w" : 390
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 390
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 390
      } ],
      "display_url" : "pic.twitter.com\/9na7NFzkWR"
    } ],
    "hashtags" : [ {
      "text" : "learngerman",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/mmt6Se1K2P",
      "expanded_url" : "http:\/\/buff.ly\/1pPtNft",
      "display_url" : "buff.ly\/1pPtNft"
    } ]
  },
  "geo" : { },
  "id_str" : "728240784697380864",
  "text" : "RT @DeutschTraining: \"If a bird shits on your shirt, don't be mad.\nBe happy that cows can't fly.\"\n\nhttps:\/\/t.co\/mmt6Se1K2P\n\n#learngerman ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DeutschTraining\/status\/728208635923472389\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/9na7NFzkWR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Chsd5V1XEAETT-Z.jpg",
        "id_str" : "728208635701170177",
        "id" : 728208635701170177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chsd5V1XEAETT-Z.jpg",
        "sizes" : [ {
          "h" : 293,
          "resize" : "fit",
          "w" : 390
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 390
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 390
        } ],
        "display_url" : "pic.twitter.com\/9na7NFzkWR"
      } ],
      "hashtags" : [ {
        "text" : "learngerman",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/mmt6Se1K2P",
        "expanded_url" : "http:\/\/buff.ly\/1pPtNft",
        "display_url" : "buff.ly\/1pPtNft"
      } ]
    },
    "geo" : { },
    "id_str" : "728208635923472389",
    "text" : "\"If a bird shits on your shirt, don't be mad.\nBe happy that cows can't fly.\"\n\nhttps:\/\/t.co\/mmt6Se1K2P\n\n#learngerman https:\/\/t.co\/9na7NFzkWR",
    "id" : 728208635923472389,
    "created_at" : "2016-05-05 13:04:02 +0000",
    "user" : {
      "name" : "DeutschTraining",
      "screen_name" : "DeutschTraining",
      "protected" : false,
      "id_str" : "1215586825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3302422691\/d837e0a3b6084e9eee30446de71279a3_normal.jpeg",
      "id" : 1215586825,
      "verified" : false
    }
  },
  "id" : 728240784697380864,
  "created_at" : "2016-05-05 15:11:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoodWorld",
      "screen_name" : "GoodWorld",
      "indices" : [ 3, 13 ],
      "id_str" : "146540113",
      "id" : 146540113
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GoodWorld\/status\/727964474804604929\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/PwPnBBNIQX",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cho_y_gVEAAprUH.jpg",
      "id_str" : "727964435046797312",
      "id" : 727964435046797312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cho_y_gVEAAprUH.jpg",
      "sizes" : [ {
        "h" : 196,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/PwPnBBNIQX"
    } ],
    "hashtags" : [ {
      "text" : "MayThe4thBeWithYou",
      "indices" : [ 56, 75 ]
    }, {
      "text" : "StarWarsDay",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728210713001496576",
  "text" : "RT @GoodWorld: best use of a S\u0336e\u0336g\u0336w\u0336a\u0336y\u0336 anything ever #MayThe4thBeWithYou #StarWarsDay https:\/\/t.co\/PwPnBBNIQX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GoodWorld\/status\/727964474804604929\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/PwPnBBNIQX",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cho_y_gVEAAprUH.jpg",
        "id_str" : "727964435046797312",
        "id" : 727964435046797312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cho_y_gVEAAprUH.jpg",
        "sizes" : [ {
          "h" : 196,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/PwPnBBNIQX"
      } ],
      "hashtags" : [ {
        "text" : "MayThe4thBeWithYou",
        "indices" : [ 41, 60 ]
      }, {
        "text" : "StarWarsDay",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "726445539726753792",
    "geo" : { },
    "id_str" : "727964474804604929",
    "in_reply_to_user_id" : 146540113,
    "text" : "best use of a S\u0336e\u0336g\u0336w\u0336a\u0336y\u0336 anything ever #MayThe4thBeWithYou #StarWarsDay https:\/\/t.co\/PwPnBBNIQX",
    "id" : 727964474804604929,
    "in_reply_to_status_id" : 726445539726753792,
    "created_at" : "2016-05-04 20:53:50 +0000",
    "in_reply_to_screen_name" : "GoodWorld",
    "in_reply_to_user_id_str" : "146540113",
    "user" : {
      "name" : "GoodWorld",
      "screen_name" : "GoodWorld",
      "protected" : false,
      "id_str" : "146540113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738018843180728321\/vGoJnASw_normal.jpg",
      "id" : 146540113,
      "verified" : false
    }
  },
  "id" : 728210713001496576,
  "created_at" : "2016-05-05 13:12:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Kunter",
      "screen_name" : "GeroKunter",
      "indices" : [ 0, 11 ],
      "id_str" : "3200846967",
      "id" : 3200846967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coquery",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728204109027794944",
  "in_reply_to_user_id" : 3200846967,
  "text" : "@GeroKunter hi not having luck building corpus from pdfs, any tips? thx #coquery",
  "id" : 728204109027794944,
  "created_at" : "2016-05-05 12:46:03 +0000",
  "in_reply_to_screen_name" : "GeroKunter",
  "in_reply_to_user_id_str" : "3200846967",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Kunter",
      "screen_name" : "GeroKunter",
      "indices" : [ 109, 120 ],
      "id_str" : "3200846967",
      "id" : 3200846967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coquery",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/y5y1PzYoem",
      "expanded_url" : "http:\/\/www.coquery.org\/doc\/userguide\/syntax.html#coca-byu-syntax-compatibility",
      "display_url" : "coquery.org\/doc\/userguide\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728202593533571073",
  "text" : "#coquery though the interface takes some learning features are nifty e.g. byu syntax https:\/\/t.co\/y5y1PzYoem @GeroKunter #corpuslinguistics",
  "id" : 728202593533571073,
  "created_at" : "2016-05-05 12:40:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Kraft",
      "screen_name" : "RobbyKraft",
      "indices" : [ 3, 14 ],
      "id_str" : "56188333",
      "id" : 56188333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728197267396689920",
  "text" : "RT @RobbyKraft: scientist: \"does everyone here know what Watson and Crick discovered?\"\nme from back of room: \"Rosalind Franklin's notes\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727352740825944064",
    "text" : "scientist: \"does everyone here know what Watson and Crick discovered?\"\nme from back of room: \"Rosalind Franklin's notes\"",
    "id" : 727352740825944064,
    "created_at" : "2016-05-03 04:23:01 +0000",
    "user" : {
      "name" : "Robby Kraft",
      "screen_name" : "RobbyKraft",
      "protected" : false,
      "id_str" : "56188333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1154921447\/Photo_on_2010-10-18_at_01.50__2_normal.jpg",
      "id" : 56188333,
      "verified" : false
    }
  },
  "id" : 728197267396689920,
  "created_at" : "2016-05-05 12:18:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728188860920934400",
  "geo" : { },
  "id_str" : "728191398231613444",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco : )",
  "id" : 728191398231613444,
  "in_reply_to_status_id" : 728188860920934400,
  "created_at" : "2016-05-05 11:55:33 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TTTJournal.",
      "screen_name" : "TTT_Journal",
      "indices" : [ 3, 15 ],
      "id_str" : "710551825787830272",
      "id" : 710551825787830272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/NruYGGAAD9",
      "expanded_url" : "http:\/\/www.tttjournal.co.uk\/uploads\/File\/back_articles\/In_Language_Teaching.pdf",
      "display_url" : "tttjournal.co.uk\/uploads\/File\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728188759502655489",
  "text" : "RT @TTT_Journal: TTJ Back Articles available on our website:  Penny Ur from way back in Volume 4.\nhttps:\/\/t.co\/NruYGGAAD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/NruYGGAAD9",
        "expanded_url" : "http:\/\/www.tttjournal.co.uk\/uploads\/File\/back_articles\/In_Language_Teaching.pdf",
        "display_url" : "tttjournal.co.uk\/uploads\/File\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728177772791775232",
    "text" : "TTJ Back Articles available on our website:  Penny Ur from way back in Volume 4.\nhttps:\/\/t.co\/NruYGGAAD9",
    "id" : 728177772791775232,
    "created_at" : "2016-05-05 11:01:24 +0000",
    "user" : {
      "name" : "TTTJournal.",
      "screen_name" : "TTT_Journal",
      "protected" : false,
      "id_str" : "710551825787830272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710555751622823936\/tN_GV7my_normal.jpg",
      "id" : 710551825787830272,
      "verified" : false
    }
  },
  "id" : 728188759502655489,
  "created_at" : "2016-05-05 11:45:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728186229955645440",
  "geo" : { },
  "id_str" : "728186957705187329",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco that's cool how did you measure the rate?",
  "id" : 728186957705187329,
  "in_reply_to_status_id" : 728186229955645440,
  "created_at" : "2016-05-05 11:37:54 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 16, 29 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728178293028102146",
  "geo" : { },
  "id_str" : "728180705952452608",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @tesolmatthew looks good have you read it?",
  "id" : 728180705952452608,
  "in_reply_to_status_id" : 728178293028102146,
  "created_at" : "2016-05-05 11:13:03 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 125, 136 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 43, 61 ]
    }, {
      "text" : "vrtwebcon",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/fRV5249zcy",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/ZjTua4B6DCq",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728176277967020032",
  "text" : "at a loose end Friday May 6? why not check #corpuslinguistics symposium at 8th #vrtwebcon? https:\/\/t.co\/fRV5249zcy hosted by @leoselivan",
  "id" : 728176277967020032,
  "created_at" : "2016-05-05 10:55:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/YsHoXol8Zu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Dd7FixvoKBw",
      "display_url" : "youtube.com\/watch?v=Dd7Fix\u2026"
    }, {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4bVbYlgMHQ",
      "expanded_url" : "https:\/\/twitter.com\/tesolmatthew\/status\/728042334646996992",
      "display_url" : "twitter.com\/tesolmatthew\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728170680018153472",
  "text" : "lol, reminds me of that sketch where teacher mispronounces sts names https:\/\/t.co\/YsHoXol8Zu https:\/\/t.co\/4bVbYlgMHQ",
  "id" : 728170680018153472,
  "created_at" : "2016-05-05 10:33:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Peter Ackerly",
      "screen_name" : "iiBenkyo",
      "indices" : [ 13, 22 ],
      "id_str" : "2162883444",
      "id" : 2162883444
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 23, 36 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728153715757096961",
  "geo" : { },
  "id_str" : "728159240079036416",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @iiBenkyo @tesolmatthew fr learners cld point out choice cld depend on emphasis e.g pick some apples up after work not oranges?",
  "id" : 728159240079036416,
  "in_reply_to_status_id" : 728153715757096961,
  "created_at" : "2016-05-05 09:47:46 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 12, 23 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/1mNpdHBjHF",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=47454541",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727908592884551680",
  "geo" : { },
  "id_str" : "727910194353717248",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @hughdellar GLOWBE shows some preference by UK https:\/\/t.co\/1mNpdHBjHF",
  "id" : 727910194353717248,
  "in_reply_to_status_id" : 727908592884551680,
  "created_at" : "2016-05-04 17:18:08 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727797547520000000",
  "geo" : { },
  "id_str" : "727799429042966533",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew yeah hence question about its usefulness",
  "id" : 727799429042966533,
  "in_reply_to_status_id" : 727797547520000000,
  "created_at" : "2016-05-04 09:58:00 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727788793391026176",
  "geo" : { },
  "id_str" : "727795370047246336",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew direct reported speech &amp; indirect reported speech are very different so are transformations that useful?",
  "id" : 727795370047246336,
  "in_reply_to_status_id" : 727788793391026176,
  "created_at" : "2016-05-04 09:41:52 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusotaku",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/HxxHTiefvA",
      "expanded_url" : "https:\/\/twitter.com\/Za_Maikeru\/status\/727749257340592131",
      "display_url" : "twitter.com\/Za_Maikeru\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727756550576717825",
  "text" : "#corpusotaku : ) https:\/\/t.co\/HxxHTiefvA",
  "id" : 727756550576717825,
  "created_at" : "2016-05-04 07:07:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Snowden\/status\/727473928713691136\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/o4iTzKxicC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChiBrmmW0AAiyYK.jpg",
      "id_str" : "727473925916119040",
      "id" : 727473925916119040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChiBrmmW0AAiyYK.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/o4iTzKxicC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/lMdMFVyjuI",
      "expanded_url" : "https:\/\/theintercept.com\/2016\/05\/03\/edward-snowden-whistleblowing-is-not-just-leaking-its-an-act-of-political-resistance\/",
      "display_url" : "theintercept.com\/2016\/05\/03\/edw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727741905589645312",
  "text" : "RT @Snowden: My first long form essay, On Resistance: https:\/\/t.co\/lMdMFVyjuI https:\/\/t.co\/o4iTzKxicC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Snowden\/status\/727473928713691136\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/o4iTzKxicC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChiBrmmW0AAiyYK.jpg",
        "id_str" : "727473925916119040",
        "id" : 727473925916119040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChiBrmmW0AAiyYK.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/o4iTzKxicC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/lMdMFVyjuI",
        "expanded_url" : "https:\/\/theintercept.com\/2016\/05\/03\/edward-snowden-whistleblowing-is-not-just-leaking-its-an-act-of-political-resistance\/",
        "display_url" : "theintercept.com\/2016\/05\/03\/edw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727473928713691136",
    "text" : "My first long form essay, On Resistance: https:\/\/t.co\/lMdMFVyjuI https:\/\/t.co\/o4iTzKxicC",
    "id" : 727473928713691136,
    "created_at" : "2016-05-03 12:24:35 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 727741905589645312,
  "created_at" : "2016-05-04 06:09:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/57pobzbIhv",
      "expanded_url" : "http:\/\/ow.ly\/4nn2Wr",
      "display_url" : "ow.ly\/4nn2Wr"
    } ]
  },
  "geo" : { },
  "id_str" : "727520567612563456",
  "text" : "RT @umasslinguistic: Language study reveals best words to use when selling products https:\/\/t.co\/57pobzbIhv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/57pobzbIhv",
        "expanded_url" : "http:\/\/ow.ly\/4nn2Wr",
        "display_url" : "ow.ly\/4nn2Wr"
      } ]
    },
    "geo" : { },
    "id_str" : "727506789642723328",
    "text" : "Language study reveals best words to use when selling products https:\/\/t.co\/57pobzbIhv",
    "id" : 727506789642723328,
    "created_at" : "2016-05-03 14:35:09 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 727520567612563456,
  "created_at" : "2016-05-03 15:29:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Scott",
      "screen_name" : "mike_lexically",
      "indices" : [ 0, 15 ],
      "id_str" : "3347309967",
      "id" : 3347309967
    }, {
      "name" : "Sonja Eisenbeiss",
      "screen_name" : "SonjaEisenbeiss",
      "indices" : [ 16, 32 ],
      "id_str" : "2184577892",
      "id" : 2184577892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725782707473682433",
  "geo" : { },
  "id_str" : "727512028227723264",
  "in_reply_to_user_id" : 18602422,
  "text" : "@mike_lexically @SonjaEisenbeiss thks for RT : )",
  "id" : 727512028227723264,
  "in_reply_to_status_id" : 725782707473682433,
  "created_at" : "2016-05-03 14:55:58 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/asgDItYneB",
      "expanded_url" : "https:\/\/opendemocracy.net\/uk\/jamie-stern-weiner-norman-finkelstein\/american-jewish-scholar-behind-labour-s-antisemitism-scanda",
      "display_url" : "opendemocracy.net\/uk\/jamie-stern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727504771494584320",
  "text" : "RT @medialens: If you only read one piece on Labour's supposed 'antisemitism' crisis, make it this from Norman Finkelstein https:\/\/t.co\/asg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/asgDItYneB",
        "expanded_url" : "https:\/\/opendemocracy.net\/uk\/jamie-stern-weiner-norman-finkelstein\/american-jewish-scholar-behind-labour-s-antisemitism-scanda",
        "display_url" : "opendemocracy.net\/uk\/jamie-stern\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727473419672031233",
    "text" : "If you only read one piece on Labour's supposed 'antisemitism' crisis, make it this from Norman Finkelstein https:\/\/t.co\/asgDItYneB",
    "id" : 727473419672031233,
    "created_at" : "2016-05-03 12:22:33 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 727504771494584320,
  "created_at" : "2016-05-03 14:27:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "indices" : [ 3, 16 ],
      "id_str" : "2820709207",
      "id" : 2820709207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/pSS5E4xUhj",
      "expanded_url" : "https:\/\/debuk.wordpress.com\/2016\/05\/03\/a-matter-of-opinion\/",
      "display_url" : "debuk.wordpress.com\/2016\/05\/03\/a-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727400988580130816",
  "text" : "RT @wordspinster: New on Language: a feminist guide: newspapers, stop publishing op-ed pieces telling people to stop saying things. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/pSS5E4xUhj",
        "expanded_url" : "https:\/\/debuk.wordpress.com\/2016\/05\/03\/a-matter-of-opinion\/",
        "display_url" : "debuk.wordpress.com\/2016\/05\/03\/a-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727324875233345537",
    "text" : "New on Language: a feminist guide: newspapers, stop publishing op-ed pieces telling people to stop saying things. https:\/\/t.co\/pSS5E4xUhj",
    "id" : 727324875233345537,
    "created_at" : "2016-05-03 02:32:17 +0000",
    "user" : {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "protected" : false,
      "id_str" : "2820709207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671103881812799488\/n6CtqOqq_normal.jpg",
      "id" : 2820709207,
      "verified" : false
    }
  },
  "id" : 727400988580130816,
  "created_at" : "2016-05-03 07:34:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Scott",
      "screen_name" : "mike_lexically",
      "indices" : [ 0, 15 ],
      "id_str" : "3347309967",
      "id" : 3347309967
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 16, 29 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725782707473682433",
  "geo" : { },
  "id_str" : "727376255746740224",
  "in_reply_to_user_id" : 18602422,
  "text" : "@mike_lexically @rosemerebard thanks for sharing Rose : )",
  "id" : 727376255746740224,
  "in_reply_to_status_id" : 725782707473682433,
  "created_at" : "2016-05-03 05:56:28 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Kunter",
      "screen_name" : "GeroKunter",
      "indices" : [ 3, 14 ],
      "id_str" : "3200846967",
      "id" : 3200846967
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeroKunter\/status\/726856729795895300\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/guVmsqKuRq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChZQGvyWMAAMPEx.png",
      "id_str" : "726856466703986688",
      "id" : 726856466703986688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChZQGvyWMAAMPEx.png",
      "sizes" : [ {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/guVmsqKuRq"
    } ],
    "hashtags" : [ {
      "text" : "Coquery",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/hEjhTShuAz",
      "expanded_url" : "http:\/\/www.coquery.org",
      "display_url" : "coquery.org"
    } ]
  },
  "geo" : { },
  "id_str" : "727373312502976513",
  "text" : "RT @GeroKunter: #Coquery 0.9.2 now reads PDF, HTML, DOCX, and ODF, and writes TextGrids: https:\/\/t.co\/hEjhTShuAz #corpuslinguistics https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeroKunter\/status\/726856729795895300\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/guVmsqKuRq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChZQGvyWMAAMPEx.png",
        "id_str" : "726856466703986688",
        "id" : 726856466703986688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChZQGvyWMAAMPEx.png",
        "sizes" : [ {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/guVmsqKuRq"
      } ],
      "hashtags" : [ {
        "text" : "Coquery",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 97, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/hEjhTShuAz",
        "expanded_url" : "http:\/\/www.coquery.org",
        "display_url" : "coquery.org"
      } ]
    },
    "geo" : { },
    "id_str" : "726856729795895300",
    "text" : "#Coquery 0.9.2 now reads PDF, HTML, DOCX, and ODF, and writes TextGrids: https:\/\/t.co\/hEjhTShuAz #corpuslinguistics https:\/\/t.co\/guVmsqKuRq",
    "id" : 726856729795895300,
    "created_at" : "2016-05-01 19:32:03 +0000",
    "user" : {
      "name" : "Gero Kunter",
      "screen_name" : "GeroKunter",
      "protected" : false,
      "id_str" : "3200846967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591573358959026177\/K9MGb-8z_normal.png",
      "id" : 3200846967,
      "verified" : false
    }
  },
  "id" : 727373312502976513,
  "created_at" : "2016-05-03 05:44:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 13, 24 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727238518511177729",
  "geo" : { },
  "id_str" : "727240019115692033",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy @ELTIreland 73% training buyers Fr rate teacher \"dynamism\" &amp; \"competence\" as 2nd key after learner motivation #eltchinwag",
  "id" : 727240019115692033,
  "in_reply_to_status_id" : 727238518511177729,
  "created_at" : "2016-05-02 20:55:06 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727238941364117504",
  "text" : "#eltchinwag thanks all : )",
  "id" : 727238941364117504,
  "created_at" : "2016-05-02 20:50:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 13, 24 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727237681420353537",
  "geo" : { },
  "id_str" : "727238014439710720",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ELTAdvocacy @ELTIreland apparently in France 70% is still face to face #eltchinwag",
  "id" : 727238014439710720,
  "in_reply_to_status_id" : 727237681420353537,
  "created_at" : "2016-05-02 20:47:08 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 13, 24 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727237467984809988",
  "geo" : { },
  "id_str" : "727237681420353537",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy @ELTIreland what he says : ) #eltchinwag not a transcription",
  "id" : 727237681420353537,
  "in_reply_to_status_id" : 727237467984809988,
  "created_at" : "2016-05-02 20:45:49 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 13, 24 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BTyVdzh5Dz",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2016\/session\/elt-conversation",
      "display_url" : "iatefl.britishcouncil.org\/2016\/session\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727236731238551552",
  "geo" : { },
  "id_str" : "727237255962714112",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy @ELTIreland it's what Andrew Wickam reports on the #IATEFL vid https:\/\/t.co\/BTyVdzh5Dz about 22mins in #eltchinwag",
  "id" : 727237255962714112,
  "in_reply_to_status_id" : 727236731238551552,
  "created_at" : "2016-05-02 20:44:07 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 12, 23 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/BTyVdzh5Dz",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2016\/session\/elt-conversation",
      "display_url" : "iatefl.britishcouncil.org\/2016\/session\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727236290983415810",
  "geo" : { },
  "id_str" : "727236749974450178",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @ELTIreland hi yeah it's from the vid about 22mins in https:\/\/t.co\/BTyVdzh5Dz",
  "id" : 727236749974450178,
  "in_reply_to_status_id" : 727236290983415810,
  "created_at" : "2016-05-02 20:42:07 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/BTyVdzh5Dz",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2016\/session\/elt-conversation",
      "display_url" : "iatefl.britishcouncil.org\/2016\/session\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727234831696953344",
  "geo" : { },
  "id_str" : "727235073666355200",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ELTIreland figures from https:\/\/t.co\/BTyVdzh5Dz #eltchinwag",
  "id" : 727235073666355200,
  "in_reply_to_status_id" : 727234831696953344,
  "created_at" : "2016-05-02 20:35:27 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727233421764874240",
  "geo" : { },
  "id_str" : "727234831696953344",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland in France nNESTs used in distance learning ~12% in markt value &amp; 25% in volume nNESTs paid a fraction of usual cost #eltchinwag",
  "id" : 727234831696953344,
  "in_reply_to_status_id" : 727233421764874240,
  "created_at" : "2016-05-02 20:34:29 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 3, 15 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ELTAdvocacy\/status\/727228299789885441\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/HRzN1RfGxl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CheiSMdWwAAD3EJ.jpg",
      "id_str" : "727228298309320704",
      "id" : 727228298309320704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CheiSMdWwAAD3EJ.jpg",
      "sizes" : [ {
        "h" : 408,
        "resize" : "fit",
        "w" : 649
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 649
      } ],
      "display_url" : "pic.twitter.com\/HRzN1RfGxl"
    } ],
    "hashtags" : [ {
      "text" : "ELTChinwag",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727232773661052928",
  "text" : "RT @ELTAdvocacy: 2\/2 #ELTChinwag This was v. important for people who work in ELT see conditions and opportunities narrow: NS or not https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ELTAdvocacy\/status\/727228299789885441\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/HRzN1RfGxl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CheiSMdWwAAD3EJ.jpg",
        "id_str" : "727228298309320704",
        "id" : 727228298309320704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CheiSMdWwAAD3EJ.jpg",
        "sizes" : [ {
          "h" : 408,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 649
        } ],
        "display_url" : "pic.twitter.com\/HRzN1RfGxl"
      } ],
      "hashtags" : [ {
        "text" : "ELTChinwag",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727228299789885441",
    "text" : "2\/2 #ELTChinwag This was v. important for people who work in ELT see conditions and opportunities narrow: NS or not https:\/\/t.co\/HRzN1RfGxl",
    "id" : 727228299789885441,
    "created_at" : "2016-05-02 20:08:32 +0000",
    "user" : {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "protected" : false,
      "id_str" : "712775553821048832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747525513472774144\/x_EPorOI_normal.jpg",
      "id" : 712775553821048832,
      "verified" : false
    }
  },
  "id" : 727232773661052928,
  "created_at" : "2016-05-02 20:26:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 3, 15 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 29, 38 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChinwag",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "UnionUp",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727232209460027392",
  "text" : "RT @ELTAdvocacy: #ELTChinwag @muranava For some who like to see it as a creative occupation or a 'calling' it may be. But for me\/us it was\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 12, 21 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTChinwag",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "UnionUp",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "727226818676281344",
    "geo" : { },
    "id_str" : "727230305036279812",
    "in_reply_to_user_id" : 18602422,
    "text" : "#ELTChinwag @muranava For some who like to see it as a creative occupation or a 'calling' it may be. But for me\/us it was that #UnionUp call",
    "id" : 727230305036279812,
    "in_reply_to_status_id" : 727226818676281344,
    "created_at" : "2016-05-02 20:16:30 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "protected" : false,
      "id_str" : "712775553821048832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747525513472774144\/x_EPorOI_normal.jpg",
      "id" : 712775553821048832,
      "verified" : false
    }
  },
  "id" : 727232209460027392,
  "created_at" : "2016-05-02 20:24:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727230305036279812",
  "geo" : { },
  "id_str" : "727231342635802625",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy ah i see thanks #eltchinwag",
  "id" : 727231342635802625,
  "in_reply_to_status_id" : 727230305036279812,
  "created_at" : "2016-05-02 20:20:38 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/727230956264902658\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/2WSn27nq1M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cheks1yWIAMmfIz.jpg",
      "id_str" : "727230955103068163",
      "id" : 727230955103068163,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cheks1yWIAMmfIz.jpg",
      "sizes" : [ {
        "h" : 54,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 94,
        "resize" : "crop",
        "w" : 94
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 597
      } ],
      "display_url" : "pic.twitter.com\/2WSn27nq1M"
    } ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727230213655027712",
  "geo" : { },
  "id_str" : "727230956264902658",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ELTIreland oops here's screenshot without typo : ) #eltchinwag https:\/\/t.co\/2WSn27nq1M",
  "id" : 727230956264902658,
  "in_reply_to_status_id" : 727230213655027712,
  "created_at" : "2016-05-02 20:19:05 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/727230213655027712\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/FXWIPfB7AR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChekBlnWwAAK3LP.jpg",
      "id_str" : "727230212027629568",
      "id" : 727230212027629568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChekBlnWwAAK3LP.jpg",
      "sizes" : [ {
        "h" : 55,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 603
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 603
      }, {
        "h" : 98,
        "resize" : "crop",
        "w" : 98
      } ],
      "display_url" : "pic.twitter.com\/FXWIPfB7AR"
    } ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727227894158741504",
  "geo" : { },
  "id_str" : "727230213655027712",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland the larger picture of industry may throw more light #eltchinwag https:\/\/t.co\/FXWIPfB7AR",
  "id" : 727230213655027712,
  "in_reply_to_status_id" : 727227894158741504,
  "created_at" : "2016-05-02 20:16:08 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChinwag",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727225735073652738",
  "geo" : { },
  "id_str" : "727226818676281344",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy the talk was elt as an industry no? #ELTChinwag was that the taboo?",
  "id" : 727226818676281344,
  "in_reply_to_status_id" : 727225735073652738,
  "created_at" : "2016-05-02 20:02:39 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pronunciation Club",
      "screen_name" : "pronunciationcl",
      "indices" : [ 0, 16 ],
      "id_str" : "4180157234",
      "id" : 4180157234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727224327498768385",
  "geo" : { },
  "id_str" : "727224764616577025",
  "in_reply_to_user_id" : 4180157234,
  "text" : "@pronunciationcl great : )",
  "id" : 727224764616577025,
  "in_reply_to_status_id" : 727224327498768385,
  "created_at" : "2016-05-02 19:54:29 +0000",
  "in_reply_to_screen_name" : "pronunciationcl",
  "in_reply_to_user_id_str" : "4180157234",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 29, 37 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727223615616389121",
  "geo" : { },
  "id_str" : "727224502158020608",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy hatip to you and @taw_sig : ) the context described highlights what nnest advocates have to face",
  "id" : 727224502158020608,
  "in_reply_to_status_id" : 727223615616389121,
  "created_at" : "2016-05-02 19:53:27 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/BTyVdzh5Dz",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2016\/session\/elt-conversation",
      "display_url" : "iatefl.britishcouncil.org\/2016\/session\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727223454278230016",
  "text" : "ELT as an Industry vid is worth checking https:\/\/t.co\/BTyVdzh5Dz #eltchinwag",
  "id" : 727223454278230016,
  "created_at" : "2016-05-02 19:49:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 0, 14 ],
      "id_str" : "273391079",
      "id" : 273391079
    }, {
      "name" : "Cassetteboy",
      "screen_name" : "Cassetteboy",
      "indices" : [ 40, 52 ],
      "id_str" : "41780094",
      "id" : 41780094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727216501149863936",
  "geo" : { },
  "id_str" : "727218444651925505",
  "in_reply_to_user_id" : 273391079,
  "text" : "@nickbilbrough i wonder if someone like @Cassetteboy would be interested in mashing a vid to your chant?",
  "id" : 727218444651925505,
  "in_reply_to_status_id" : 727216501149863936,
  "created_at" : "2016-05-02 19:29:22 +0000",
  "in_reply_to_screen_name" : "nickbilbrough",
  "in_reply_to_user_id_str" : "273391079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 0, 14 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727216232915734528",
  "geo" : { },
  "id_str" : "727217069717098497",
  "in_reply_to_user_id" : 273391079,
  "text" : "@nickbilbrough ah okay maybe a diff account for such vids? i showed it to some teachers at work today they really enjoyed it",
  "id" : 727217069717098497,
  "in_reply_to_status_id" : 727216232915734528,
  "created_at" : "2016-05-02 19:23:55 +0000",
  "in_reply_to_screen_name" : "nickbilbrough",
  "in_reply_to_user_id_str" : "273391079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 0, 14 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727216501149863936",
  "geo" : { },
  "id_str" : "727216899407380481",
  "in_reply_to_user_id" : 273391079,
  "text" : "@nickbilbrough lol never done chants before maybe worth a shot : )",
  "id" : 727216899407380481,
  "in_reply_to_status_id" : 727216501149863936,
  "created_at" : "2016-05-02 19:23:14 +0000",
  "in_reply_to_screen_name" : "nickbilbrough",
  "in_reply_to_user_id_str" : "273391079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 0, 14 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727211694133510144",
  "in_reply_to_user_id" : 273391079,
  "text" : "@nickbilbrough hi Nick what happened to your witch hunt video and tweets?",
  "id" : 727211694133510144,
  "created_at" : "2016-05-02 19:02:33 +0000",
  "in_reply_to_screen_name" : "nickbilbrough",
  "in_reply_to_user_id_str" : "273391079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 3, 14 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/rlN2McC5iz",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/05\/02\/score-user-guide-in-english",
      "display_url" : "corpling4efl.wordpress.com\/2016\/05\/02\/sco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727141704529248256",
  "text" : "RT @Za_Maikeru: SCoRE user guide available, good for DDL in EFL https:\/\/t.co\/rlN2McC5iz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/rlN2McC5iz",
        "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/05\/02\/score-user-guide-in-english",
        "display_url" : "corpling4efl.wordpress.com\/2016\/05\/02\/sco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727106934608789505",
    "text" : "SCoRE user guide available, good for DDL in EFL https:\/\/t.co\/rlN2McC5iz",
    "id" : 727106934608789505,
    "created_at" : "2016-05-02 12:06:16 +0000",
    "user" : {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "protected" : false,
      "id_str" : "703598479944208384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714776497257578496\/rmJMMadQ_normal.jpg",
      "id" : 703598479944208384,
      "verified" : false
    }
  },
  "id" : 727141704529248256,
  "created_at" : "2016-05-02 14:24:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 0, 14 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726907881715544068",
  "geo" : { },
  "id_str" : "727014060374499328",
  "in_reply_to_user_id" : 273391079,
  "text" : "@nickbilbrough there is for sure :\/",
  "id" : 727014060374499328,
  "in_reply_to_status_id" : 726907881715544068,
  "created_at" : "2016-05-02 05:57:13 +0000",
  "in_reply_to_screen_name" : "nickbilbrough",
  "in_reply_to_user_id_str" : "273391079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Livingstone",
      "indices" : [ 67, 79 ]
    }, {
      "text" : "Corbyn",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "Khan",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/y1q54BIqce",
      "expanded_url" : "https:\/\/twitter.com\/nickbilbrough\/status\/726899104324931584",
      "display_url" : "twitter.com\/nickbilbrough\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726902178208702464",
  "text" : "this is great Nick can we expect a series of political chants? : ) #Livingstone #Corbyn #Khan https:\/\/t.co\/y1q54BIqce",
  "id" : 726902178208702464,
  "created_at" : "2016-05-01 22:32:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Economic Forum",
      "screen_name" : "wef",
      "indices" : [ 0, 4 ],
      "id_str" : "5120691",
      "id" : 5120691
    }, {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 5, 18 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726845899457060864",
  "geo" : { },
  "id_str" : "726897448636014592",
  "in_reply_to_user_id" : 5120691,
  "text" : "@wef @RobertASzabo wonder how much Ivory Coast stats to do with French backed currency?",
  "id" : 726897448636014592,
  "in_reply_to_status_id" : 726845899457060864,
  "created_at" : "2016-05-01 22:13:51 +0000",
  "in_reply_to_screen_name" : "wef",
  "in_reply_to_user_id_str" : "5120691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger C. Schonfeld",
      "screen_name" : "rschon",
      "indices" : [ 3, 10 ],
      "id_str" : "27685957",
      "id" : 27685957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/FoluTH7RBu",
      "expanded_url" : "https:\/\/twitter.com\/scott_bot\/status\/726856557665882112",
      "display_url" : "twitter.com\/scott_bot\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726887971270565890",
  "text" : "RT @rschon: Interesting claim here, and worth reading the full thread preceding this tweet. https:\/\/t.co\/FoluTH7RBu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/FoluTH7RBu",
        "expanded_url" : "https:\/\/twitter.com\/scott_bot\/status\/726856557665882112",
        "display_url" : "twitter.com\/scott_bot\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726866049954648064",
    "text" : "Interesting claim here, and worth reading the full thread preceding this tweet. https:\/\/t.co\/FoluTH7RBu",
    "id" : 726866049954648064,
    "created_at" : "2016-05-01 20:09:05 +0000",
    "user" : {
      "name" : "Roger C. Schonfeld",
      "screen_name" : "rschon",
      "protected" : false,
      "id_str" : "27685957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1716127607\/0617_normal.JPG",
      "id" : 27685957,
      "verified" : false
    }
  },
  "id" : 726887971270565890,
  "created_at" : "2016-05-01 21:36:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]