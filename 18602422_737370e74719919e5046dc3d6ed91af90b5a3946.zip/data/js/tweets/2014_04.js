Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 98, 113 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/tMV9kiBQmG",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-a-metacognitive-listening-approach",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461592598940233728",
  "text" : "RT @DavidHarbinson: Research Bites: A Metacognitive Listening Approach http:\/\/t.co\/tMV9kiBQmG via @anthonyteacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AnthonyTeacher",
        "screen_name" : "AnthonyTeacher",
        "indices" : [ 78, 93 ],
        "id_str" : "285614027",
        "id" : 285614027
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/tMV9kiBQmG",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-a-metacognitive-listening-approach",
        "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461581641358376960",
    "text" : "Research Bites: A Metacognitive Listening Approach http:\/\/t.co\/tMV9kiBQmG via @anthonyteacher",
    "id" : 461581641358376960,
    "created_at" : "2014-04-30 19:03:33 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 461592598940233728,
  "created_at" : "2014-04-30 19:47:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 135, 143 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461587645618192384",
  "text" : "RT @HadaLitim: Tonight's chat's on 'How important is group cohesion in th ELT class &amp; how can we best achieve it?' Join at 9PM BST #eltchat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 120, 128 ]
      }, {
        "text" : "eltchinwag",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461583905502412800",
    "text" : "Tonight's chat's on 'How important is group cohesion in th ELT class &amp; how can we best achieve it?' Join at 9PM BST #eltchat #eltchinwag",
    "id" : 461583905502412800,
    "created_at" : "2014-04-30 19:12:33 +0000",
    "user" : {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "protected" : false,
      "id_str" : "44631065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729282562783326209\/2tQuUs5L_normal.jpg",
      "id" : 44631065,
      "verified" : false
    }
  },
  "id" : 461587645618192384,
  "created_at" : "2014-04-30 19:27:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 85, 101 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/wkB7SwOtTX",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-IM",
      "display_url" : "wp.me\/pbMLY-IM"
    } ]
  },
  "geo" : { },
  "id_str" : "461583771796373504",
  "text" : "Historical TEFL Research: Toward a Data-Informed Approach http:\/\/t.co\/wkB7SwOtTX via @wordpressdotcom #corpusmooc",
  "id" : 461583771796373504,
  "created_at" : "2014-04-30 19:12:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 0, 7 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Mozilla Webmaker",
      "screen_name" : "Webmaker",
      "indices" : [ 8, 17 ],
      "id_str" : "1242429835",
      "id" : 1242429835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461578793816449024",
  "geo" : { },
  "id_str" : "461582927714086912",
  "in_reply_to_user_id" : 740343,
  "text" : "@cogdog @webmaker cheers, your make is mad stylish :)",
  "id" : 461582927714086912,
  "in_reply_to_status_id" : 461578793816449024,
  "created_at" : "2014-04-30 19:08:40 +0000",
  "in_reply_to_screen_name" : "cogdog",
  "in_reply_to_user_id_str" : "740343",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 11, 18 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/fBLF8wJfLP",
      "expanded_url" : "https:\/\/elt.makes.org\/thimble\/LTEzOTYxNzg5NDQ=\/image-seek-with-stringnet",
      "display_url" : "elt.makes.org\/thimble\/LTEzOT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461575055106134016",
  "text" : "image seek @cogdog modded for StringNet https:\/\/t.co\/fBLF8wJfLP #teachtheweb",
  "id" : 461575055106134016,
  "created_at" : "2014-04-30 18:37:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 3, 15 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/zgXw7aVJvi",
      "expanded_url" : "https:\/\/hu.tt",
      "display_url" : "hu.tt"
    } ]
  },
  "geo" : { },
  "id_str" : "461100045975445504",
  "text" : "RT @smashingmag: Brilliant: If you are looking for a replacement for Skype or Hangouts, Hutt is a free alternative that uses WebRTC. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zgXw7aVJvi",
        "expanded_url" : "https:\/\/hu.tt",
        "display_url" : "hu.tt"
      } ]
    },
    "geo" : { },
    "id_str" : "460451137062469634",
    "text" : "Brilliant: If you are looking for a replacement for Skype or Hangouts, Hutt is a free alternative that uses WebRTC. https:\/\/t.co\/zgXw7aVJvi",
    "id" : 460451137062469634,
    "created_at" : "2014-04-27 16:11:20 +0000",
    "user" : {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "protected" : false,
      "id_str" : "15736190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477218012194304000\/ytI5hY2H_normal.png",
      "id" : 15736190,
      "verified" : true
    }
  },
  "id" : 461100045975445504,
  "created_at" : "2014-04-29 11:09:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Nix",
      "screen_name" : "adamnix1812",
      "indices" : [ 3, 15 ],
      "id_str" : "133206329",
      "id" : 133206329
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/adamnix1812\/status\/460343155288592384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5eCrPGLTRe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmN3qSYCUAA1QO4.jpg",
      "id_str" : "460343155292786688",
      "id" : 460343155292786688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmN3qSYCUAA1QO4.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5eCrPGLTRe"
    } ],
    "hashtags" : [ {
      "text" : "StaffordTower",
      "indices" : [ 32, 46 ]
    }, {
      "text" : "F15R16",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460888405082406912",
  "text" : "RT @adamnix1812: My old flat at #StaffordTower raised to the ground, the Brum skyline has changed from today #F15R16 http:\/\/t.co\/5eCrPGLTRe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/adamnix1812\/status\/460343155288592384\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/5eCrPGLTRe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmN3qSYCUAA1QO4.jpg",
        "id_str" : "460343155292786688",
        "id" : 460343155292786688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmN3qSYCUAA1QO4.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5eCrPGLTRe"
      } ],
      "hashtags" : [ {
        "text" : "StaffordTower",
        "indices" : [ 15, 29 ]
      }, {
        "text" : "F15R16",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460343155288592384",
    "text" : "My old flat at #StaffordTower raised to the ground, the Brum skyline has changed from today #F15R16 http:\/\/t.co\/5eCrPGLTRe",
    "id" : 460343155288592384,
    "created_at" : "2014-04-27 09:02:15 +0000",
    "user" : {
      "name" : "Adam Nix",
      "screen_name" : "adamnix1812",
      "protected" : false,
      "id_str" : "133206329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574969435544408065\/Y-gHaPy4_normal.jpeg",
      "id" : 133206329,
      "verified" : false
    }
  },
  "id" : 460888405082406912,
  "created_at" : "2014-04-28 21:08:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 3, 18 ],
      "id_str" : "95419070",
      "id" : 95419070
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 21, 36 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CQPweb",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Di0roZQfKK",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1133",
      "display_url" : "cass.lancs.ac.uk\/?p=1133"
    } ]
  },
  "geo" : { },
  "id_str" : "460797345140330496",
  "text" : "RT @corpusloanword: \u201C@HardieResearch: I wrote this thing. \n\"Log Ratio \u2013 an informal introduction\" http:\/\/t.co\/Di0roZQfKK #CQPweb\u201D. Really c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Hardie",
        "screen_name" : "HardieResearch",
        "indices" : [ 1, 16 ],
        "id_str" : "970452764",
        "id" : 970452764
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CQPweb",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/Di0roZQfKK",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1133",
        "display_url" : "cass.lancs.ac.uk\/?p=1133"
      } ]
    },
    "in_reply_to_status_id_str" : "460693305328926720",
    "geo" : { },
    "id_str" : "460782607181963265",
    "in_reply_to_user_id" : 970452764,
    "text" : "\u201C@HardieResearch: I wrote this thing. \n\"Log Ratio \u2013 an informal introduction\" http:\/\/t.co\/Di0roZQfKK #CQPweb\u201D. Really clear &amp; Simple.",
    "id" : 460782607181963265,
    "in_reply_to_status_id" : 460693305328926720,
    "created_at" : "2014-04-28 14:08:29 +0000",
    "in_reply_to_screen_name" : "HardieResearch",
    "in_reply_to_user_id_str" : "970452764",
    "user" : {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "protected" : false,
      "id_str" : "95419070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3194937799\/f5a7b3c729837992c82ce94d0db82774_normal.jpeg",
      "id" : 95419070,
      "verified" : false
    }
  },
  "id" : 460797345140330496,
  "created_at" : "2014-04-28 15:07:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDS",
      "screen_name" : "CritDiscStuds",
      "indices" : [ 0, 14 ],
      "id_str" : "2195704844",
      "id" : 2195704844
    }, {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 15, 28 ],
      "id_str" : "702925903",
      "id" : 702925903
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 29, 41 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460721506109362176",
  "geo" : { },
  "id_str" : "460777334959013888",
  "in_reply_to_user_id" : 2195704844,
  "text" : "@CritDiscStuds @WatchedPotts @_paulbaker_ \/thumbs up\/ thanks :)",
  "id" : 460777334959013888,
  "in_reply_to_status_id" : 460721506109362176,
  "created_at" : "2014-04-28 13:47:32 +0000",
  "in_reply_to_screen_name" : "CritDiscStuds",
  "in_reply_to_user_id_str" : "2195704844",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 2, 12 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 14, 26 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 100, 110 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/agrbZIJTTY",
      "expanded_url" : "http:\/\/skell.sketchengine.co.uk\/run.cgi\/skell",
      "display_url" : "skell.sketchengine.co.uk\/run.cgi\/skell"
    }, {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/3vPucbw2Fb",
      "expanded_url" : "https:\/\/sites.google.com\/site\/sketchengineforeslteachers\/",
      "display_url" : "sites.google.com\/site\/sketcheng\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "460652951598407680",
  "geo" : { },
  "id_str" : "460665362343030784",
  "in_reply_to_user_id" : 33503694,
  "text" : ". @JosetteLB  @AnneHendler do also check out http:\/\/t.co\/agrbZIJTTY and https:\/\/t.co\/3vPucbw2Fb (by @HanaTicha)",
  "id" : 460665362343030784,
  "in_reply_to_status_id" : 460652951598407680,
  "created_at" : "2014-04-28 06:22:35 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/SGDkPsE4Op",
      "expanded_url" : "http:\/\/www.virtual-round-table.com\/events\/keynote-graham-stanley-gamifying-the-language-classroom",
      "display_url" : "virtual-round-table.com\/events\/keynote\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460531388090171392",
  "text" : "KEYNOTE Graham Stanley: Gamifying the Language Classroom http:\/\/t.co\/SGDkPsE4Op #vrtwebcon in 1hr",
  "id" : 460531388090171392,
  "created_at" : "2014-04-27 21:30:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Carlson",
      "screen_name" : "sloopie72",
      "indices" : [ 0, 10 ],
      "id_str" : "20377590",
      "id" : 20377590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/6vfDQawGxl",
      "expanded_url" : "http:\/\/youtu.be\/nDjdJCbteKA",
      "display_url" : "youtu.be\/nDjdJCbteKA"
    } ]
  },
  "in_reply_to_status_id_str" : "459721582165127168",
  "geo" : { },
  "id_str" : "460483272263630848",
  "in_reply_to_user_id" : 20377590,
  "text" : "@sloopie72 fyi there's a bit of the view from mentors here http:\/\/t.co\/6vfDQawGxl",
  "id" : 460483272263630848,
  "in_reply_to_status_id" : 459721582165127168,
  "created_at" : "2014-04-27 18:19:02 +0000",
  "in_reply_to_screen_name" : "sloopie72",
  "in_reply_to_user_id_str" : "20377590",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ymN5ognubI",
      "expanded_url" : "http:\/\/blog.stringnet.org\/?p=114",
      "display_url" : "blog.stringnet.org\/?p=114"
    } ]
  },
  "geo" : { },
  "id_str" : "460482199356063744",
  "text" : "new feature in StringNet - find similar words http:\/\/t.co\/ymN5ognubI #corpusmooc",
  "id" : 460482199356063744,
  "created_at" : "2014-04-27 18:14:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Ravitch",
      "screen_name" : "DianeRavitch",
      "indices" : [ 108, 121 ],
      "id_str" : "59010637",
      "id" : 59010637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/tpFwRvDuFs",
      "expanded_url" : "http:\/\/wp.me\/p2odLa-7c3",
      "display_url" : "wp.me\/p2odLa-7c3"
    } ]
  },
  "geo" : { },
  "id_str" : "460462405802135552",
  "text" : "Robert Shepherd on Apathy about the Death of Competition for Education Materials http:\/\/t.co\/tpFwRvDuFs via @DianeRavitch",
  "id" : 460462405802135552,
  "created_at" : "2014-04-27 16:56:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459840201062633472",
  "geo" : { },
  "id_str" : "460358038361493504",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames was that one of your questions? :\/",
  "id" : 460358038361493504,
  "in_reply_to_status_id" : 459840201062633472,
  "created_at" : "2014-04-27 10:01:24 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayne Whistance",
      "screen_name" : "JayneWhistance",
      "indices" : [ 3, 18 ],
      "id_str" : "539398225",
      "id" : 539398225
    }, {
      "name" : "Collins Dictionary",
      "screen_name" : "collinsdict",
      "indices" : [ 92, 104 ],
      "id_str" : "204767871",
      "id" : 204767871
    }, {
      "name" : "CollinsELT",
      "screen_name" : "CollinsELT",
      "indices" : [ 105, 116 ],
      "id_str" : "389406441",
      "id" : 389406441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/YyocVuzGrj",
      "expanded_url" : "http:\/\/www.collinsdictionary.com\/cobuild",
      "display_url" : "collinsdictionary.com\/cobuild"
    } ]
  },
  "geo" : { },
  "id_str" : "460353304334446592",
  "text" : "RT @JayneWhistance: COBUILD Advanced Learner's English Dictionary is now available for FREE @collinsdict @CollinsELT - http:\/\/t.co\/YyocVuzG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Collins Dictionary",
        "screen_name" : "collinsdict",
        "indices" : [ 72, 84 ],
        "id_str" : "204767871",
        "id" : 204767871
      }, {
        "name" : "CollinsELT",
        "screen_name" : "CollinsELT",
        "indices" : [ 85, 96 ],
        "id_str" : "389406441",
        "id" : 389406441
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/YyocVuzGrj",
        "expanded_url" : "http:\/\/www.collinsdictionary.com\/cobuild",
        "display_url" : "collinsdictionary.com\/cobuild"
      } ]
    },
    "geo" : { },
    "id_str" : "460180206888968192",
    "text" : "COBUILD Advanced Learner's English Dictionary is now available for FREE @collinsdict @CollinsELT - http:\/\/t.co\/YyocVuzGrj",
    "id" : 460180206888968192,
    "created_at" : "2014-04-26 22:14:45 +0000",
    "user" : {
      "name" : "Jayne Whistance",
      "screen_name" : "JayneWhistance",
      "protected" : false,
      "id_str" : "539398225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623838449716600832\/Yt0y0Eaj_normal.jpg",
      "id" : 539398225,
      "verified" : false
    }
  },
  "id" : 460353304334446592,
  "created_at" : "2014-04-27 09:42:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/P1bOGbvQqc",
      "expanded_url" : "http:\/\/bit.ly\/1fh7UA4",
      "display_url" : "bit.ly\/1fh7UA4"
    } ]
  },
  "geo" : { },
  "id_str" : "460351765532397568",
  "text" : "RT @tornhalves: Astra Taylor on the digital non-rev'n: \"The problem is the underlying economic conditions haven\u2019t changed.\" http:\/\/t.co\/P1b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/P1bOGbvQqc",
        "expanded_url" : "http:\/\/bit.ly\/1fh7UA4",
        "display_url" : "bit.ly\/1fh7UA4"
      } ]
    },
    "geo" : { },
    "id_str" : "460347695476269056",
    "text" : "Astra Taylor on the digital non-rev'n: \"The problem is the underlying economic conditions haven\u2019t changed.\" http:\/\/t.co\/P1bOGbvQqc",
    "id" : 460347695476269056,
    "created_at" : "2014-04-27 09:20:18 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 460351765532397568,
  "created_at" : "2014-04-27 09:36:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 3, 18 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    }, {
      "name" : "Dan Zarrella",
      "screen_name" : "danzarrella",
      "indices" : [ 64, 76 ],
      "id_str" : "3611041",
      "id" : 3611041
    }, {
      "name" : "Buffer",
      "screen_name" : "buffer",
      "indices" : [ 131, 138 ],
      "id_str" : "197962366",
      "id" : 197962366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/PzqDExIEbe",
      "expanded_url" : "http:\/\/andreadallover.com\/2014\/04\/27\/analyzing-language-youre-doing-it-wrong\/",
      "display_url" : "andreadallover.com\/2014\/04\/27\/ana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460339884067389440",
  "text" : "RT @EvilJoeMcVeigh: New post looks at language analysis done by @danzarrella. Check it: http:\/\/t.co\/PzqDExIEbe I found him from an @buffer \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Zarrella",
        "screen_name" : "danzarrella",
        "indices" : [ 44, 56 ],
        "id_str" : "3611041",
        "id" : 3611041
      }, {
        "name" : "Buffer",
        "screen_name" : "buffer",
        "indices" : [ 111, 118 ],
        "id_str" : "197962366",
        "id" : 197962366
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/PzqDExIEbe",
        "expanded_url" : "http:\/\/andreadallover.com\/2014\/04\/27\/analyzing-language-youre-doing-it-wrong\/",
        "display_url" : "andreadallover.com\/2014\/04\/27\/ana\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "460337602361827328",
    "text" : "New post looks at language analysis done by @danzarrella. Check it: http:\/\/t.co\/PzqDExIEbe I found him from an @buffer blog post.",
    "id" : 460337602361827328,
    "created_at" : "2014-04-27 08:40:11 +0000",
    "user" : {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "protected" : false,
      "id_str" : "1327355143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633574005530693632\/omOKH3tm_normal.png",
      "id" : 1327355143,
      "verified" : false
    }
  },
  "id" : 460339884067389440,
  "created_at" : "2014-04-27 08:49:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 83, 98 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/iTvSXbDsju",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-OU",
      "display_url" : "wp.me\/p3qkCB-OU"
    } ]
  },
  "geo" : { },
  "id_str" : "460335746558083074",
  "text" : "Embodied Cognition: What it is and how we deal with it  http:\/\/t.co\/iTvSXbDsju via @GeoffreyJordan",
  "id" : 460335746558083074,
  "created_at" : "2014-04-27 08:32:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 3, 18 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Qv8U9ISOxu",
      "expanded_url" : "http:\/\/fb.me\/6u5u7z8ZG",
      "display_url" : "fb.me\/6u5u7z8ZG"
    } ]
  },
  "geo" : { },
  "id_str" : "460095264028917762",
  "text" : "RT @4tunetellernet: Took awhile but here it is.  The official 4Tune Teller press release. In English and fran\u00E7ais. Thanks to my... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Qv8U9ISOxu",
        "expanded_url" : "http:\/\/fb.me\/6u5u7z8ZG",
        "display_url" : "fb.me\/6u5u7z8ZG"
      } ]
    },
    "geo" : { },
    "id_str" : "460091999857942528",
    "text" : "Took awhile but here it is.  The official 4Tune Teller press release. In English and fran\u00E7ais. Thanks to my... http:\/\/t.co\/Qv8U9ISOxu",
    "id" : 460091999857942528,
    "created_at" : "2014-04-26 16:24:15 +0000",
    "user" : {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "protected" : false,
      "id_str" : "467634146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638018712629592065\/i8nHx3y0_normal.png",
      "id" : 467634146,
      "verified" : false
    }
  },
  "id" : 460095264028917762,
  "created_at" : "2014-04-26 16:37:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 97, 113 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/LoyOdiPw8z",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-Is",
      "display_url" : "wp.me\/pbMLY-Is"
    } ]
  },
  "geo" : { },
  "id_str" : "460085637358432256",
  "text" : "Issues and Options in Textbook Development, Selection and Consumption http:\/\/t.co\/LoyOdiPw8z via @wordpressdotcom",
  "id" : 460085637358432256,
  "created_at" : "2014-04-26 15:58:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Michael B Smith",
      "screen_name" : "mbransons",
      "indices" : [ 35, 45 ],
      "id_str" : "259908125",
      "id" : 259908125
    }, {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 47, 56 ],
      "id_str" : "3362981",
      "id" : 3362981
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 57, 71 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/jB6pJQNG5y",
      "expanded_url" : "http:\/\/www.michaelbransonsmith.net\/blog\/wp-content\/uploads\/2014\/04\/wreckthecyborg.gif",
      "display_url" : "michaelbransonsmith.net\/blog\/wp-conten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459982153804431361",
  "text" : "RT @cogdog: Seriously brilliant RT @mbransons: @jimgroom @audreywatters keep nudging the cyborg. http:\/\/t.co\/jB6pJQNG5y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael B Smith",
        "screen_name" : "mbransons",
        "indices" : [ 23, 33 ],
        "id_str" : "259908125",
        "id" : 259908125
      }, {
        "name" : "Jim Groom",
        "screen_name" : "jimgroom",
        "indices" : [ 35, 44 ],
        "id_str" : "3362981",
        "id" : 3362981
      }, {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 45, 59 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/jB6pJQNG5y",
        "expanded_url" : "http:\/\/www.michaelbransonsmith.net\/blog\/wp-content\/uploads\/2014\/04\/wreckthecyborg.gif",
        "display_url" : "michaelbransonsmith.net\/blog\/wp-conten\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459981316512292864",
    "text" : "Seriously brilliant RT @mbransons: @jimgroom @audreywatters keep nudging the cyborg. http:\/\/t.co\/jB6pJQNG5y",
    "id" : 459981316512292864,
    "created_at" : "2014-04-26 09:04:26 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 459982153804431361,
  "created_at" : "2014-04-26 09:07:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 32, 46 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Colin Salter",
      "screen_name" : "colinsalter",
      "indices" : [ 123, 135 ],
      "id_str" : "22000305",
      "id" : 22000305
    }, {
      "name" : "Christopher Moore",
      "screen_name" : "CL_Moore",
      "indices" : [ 136, 140 ],
      "id_str" : "22074720",
      "id" : 22074720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/34mIHd2T0X",
      "expanded_url" : "http:\/\/hackeducation.com\/2014\/04\/25\/domain-of-ones-own-incubator-emory",
      "display_url" : "hackeducation.com\/2014\/04\/25\/dom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459978887230156802",
  "text" : "RT @KateMfD: This, all of this: @audreywatters: \"Beneath the Cobblestones... A Domain of One's Own\" http:\/\/t.co\/34mIHd2T0X @colinsalter @CL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 19, 33 ],
        "id_str" : "25388528",
        "id" : 25388528
      }, {
        "name" : "Colin Salter",
        "screen_name" : "colinsalter",
        "indices" : [ 110, 122 ],
        "id_str" : "22000305",
        "id" : 22000305
      }, {
        "name" : "Christopher Moore",
        "screen_name" : "CL_Moore",
        "indices" : [ 123, 132 ],
        "id_str" : "22074720",
        "id" : 22074720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/34mIHd2T0X",
        "expanded_url" : "http:\/\/hackeducation.com\/2014\/04\/25\/domain-of-ones-own-incubator-emory",
        "display_url" : "hackeducation.com\/2014\/04\/25\/dom\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "459818013395804160",
    "geo" : { },
    "id_str" : "459823147605581824",
    "in_reply_to_user_id" : 25388528,
    "text" : "This, all of this: @audreywatters: \"Beneath the Cobblestones... A Domain of One's Own\" http:\/\/t.co\/34mIHd2T0X @colinsalter @CL_Moore",
    "id" : 459823147605581824,
    "in_reply_to_status_id" : 459818013395804160,
    "created_at" : "2014-04-25 22:35:56 +0000",
    "in_reply_to_screen_name" : "audreywatters",
    "in_reply_to_user_id_str" : "25388528",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 459978887230156802,
  "created_at" : "2014-04-26 08:54:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Read",
      "screen_name" : "carolread",
      "indices" : [ 3, 13 ],
      "id_str" : "98188554",
      "id" : 98188554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/0X2bv2FtGz",
      "expanded_url" : "http:\/\/www.iatefl.org\/webinars",
      "display_url" : "iatefl.org\/webinars"
    } ]
  },
  "geo" : { },
  "id_str" : "459972197608861696",
  "text" : "RT @carolread: Don't miss #IATEFL Webinar with Ron Carter on 'Internet English' 3pm BST Saturday 26 April. http:\/\/t.co\/0X2bv2FtGz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/0X2bv2FtGz",
        "expanded_url" : "http:\/\/www.iatefl.org\/webinars",
        "display_url" : "iatefl.org\/webinars"
      } ]
    },
    "geo" : { },
    "id_str" : "459582726455451649",
    "text" : "Don't miss #IATEFL Webinar with Ron Carter on 'Internet English' 3pm BST Saturday 26 April. http:\/\/t.co\/0X2bv2FtGz",
    "id" : 459582726455451649,
    "created_at" : "2014-04-25 06:40:35 +0000",
    "user" : {
      "name" : "Carol Read",
      "screen_name" : "carolread",
      "protected" : false,
      "id_str" : "98188554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584157665\/DSCN0846_2_normal.JPG",
      "id" : 98188554,
      "verified" : false
    }
  },
  "id" : 459972197608861696,
  "created_at" : "2014-04-26 08:28:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vrtwebcon",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/v74m76Z1zT",
      "expanded_url" : "http:\/\/www.virtual-round-table.com\/events\/belmacoding",
      "display_url" : "virtual-round-table.com\/events\/belmaco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459789019023691776",
  "text" : "Belma Gaukrodger If you can read, you can create an app: Coding for English Language Learners (ELL) http:\/\/t.co\/v74m76Z1zT #vrtwebcon in 1hr",
  "id" : 459789019023691776,
  "created_at" : "2014-04-25 20:20:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "indices" : [ 95, 109 ],
      "id_str" : "23783700",
      "id" : 23783700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/zYxjARJuD0",
      "expanded_url" : "http:\/\/www.macmillandictionaryblog.com\/schwa-syllables-and-words-in-different-guises-part-1",
      "display_url" : "macmillandictionaryblog.com\/schwa-syllable\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459699990063886337",
  "text" : "Schwa, syllables and words in different guises \u2013 Part 1 | Macmillan http:\/\/t.co\/zYxjARJuD0 via @MacDictionary",
  "id" : 459699990063886337,
  "created_at" : "2014-04-25 14:26:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SiliconValleyHBO",
      "indices" : [ 51, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459669789892698112",
  "text" : "john lennon's imagine &gt; john wayne in a mansion #SiliconValleyHBO",
  "id" : 459669789892698112,
  "created_at" : "2014-04-25 12:26:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SiliconValleyHBO",
      "indices" : [ 34, 51 ]
    }, {
      "text" : "groanworthybutstillfunny",
      "indices" : [ 52, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459656202704936960",
  "text" : "i know html  (how to meet ladies) #SiliconValleyHBO #groanworthybutstillfunny",
  "id" : 459656202704936960,
  "created_at" : "2014-04-25 11:32:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "siliconvalley",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459653578362458112",
  "text" : "uh oh just found a new tv series by mike judge about #siliconvalley, there goes fri afternoon productivity out the window",
  "id" : 459653578362458112,
  "created_at" : "2014-04-25 11:22:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Causey \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDE80",
      "screen_name" : "treycausey",
      "indices" : [ 3, 14 ],
      "id_str" : "237254045",
      "id" : 237254045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/AwnntrWp8L",
      "expanded_url" : "http:\/\/arstechnica.com\/gadgets\/2014\/04\/report-google-to-end-forced-g-integration-drastically-cut-division-resources\/",
      "display_url" : "arstechnica.com\/gadgets\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459608187575205888",
  "text" : "RT @treycausey: Looks like the beginning of the end for Google+. http:\/\/t.co\/AwnntrWp8L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/AwnntrWp8L",
        "expanded_url" : "http:\/\/arstechnica.com\/gadgets\/2014\/04\/report-google-to-end-forced-g-integration-drastically-cut-division-resources\/",
        "display_url" : "arstechnica.com\/gadgets\/2014\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459490121654353920",
    "text" : "Looks like the beginning of the end for Google+. http:\/\/t.co\/AwnntrWp8L",
    "id" : 459490121654353920,
    "created_at" : "2014-04-25 00:32:36 +0000",
    "user" : {
      "name" : "Trey Causey \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDE80",
      "screen_name" : "treycausey",
      "protected" : false,
      "id_str" : "237254045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765551721548361728\/PXzxVxij_normal.jpg",
      "id" : 237254045,
      "verified" : false
    }
  },
  "id" : 459608187575205888,
  "created_at" : "2014-04-25 08:21:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 12, 18 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/lOM8eyVjN5",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=neurolinguistic+programming%2C+neuro-linguistic+programming%2Cnatural+language+processing&case_insensitive=on&year_start=1800&year_end=2000&corpus=15&smoothing=3&share=&direct_url=t4%3B%2Cneurolinguistic%20programming%3B%2Cc0%3B%2Cs0%3B%3Bneurolinguistic%20programming%3B%2Cc0%3B%3BNeurolinguistic%20Programming%3B%2Cc0%3B%3BNeurolinguistic%20programming%3B%2Cc0%3B%3BNeuroLinguistic%20Programming%3B%2Cc0%3B%3BNEUROLINGUISTIC%20PROGRAMMING%3B%2Cc0%3B.t4%3B%2Cneuro%20-%20linguistic%20programming%3B%2Cc0%3B%2Cs0%3B%3BNeuro%20-%20Linguistic%20Programming%3B%2Cc0%3B%3Bneuro%20-%20linguistic%20programming%3B%2Cc0%3B%3BNeuro%20-%20linguistic%20programming%3B%2Cc0%3B%3BNeuro%20-%20linguistic%20Programming%3B%2Cc0%3B%3BNEURO%20-%20LINGUISTIC%20PROGRAMMING%3B%2Cc0%3B.t4%3B%2Cnatural%20language%20processing%3B%2Cc0%3B%2Cs0%3B%3Bnatural%20language%20processing%3B%2Cc0%3B%3BNatural%20Language%20Processing%3B%2Cc0%3B%3BNatural%20language%20processing%3B%2Cc0%3B%3BNATURAL%20LANGUAGE%20PROCESSING%3B%2Cc0",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459379589102727168",
  "geo" : { },
  "id_str" : "459380498486538241",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @ebefl https:\/\/t.co\/lOM8eyVjN5 :)",
  "id" : 459380498486538241,
  "in_reply_to_status_id" : 459379589102727168,
  "created_at" : "2014-04-24 17:17:00 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 88, 101 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 102, 108 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Elio Di Dio",
      "screen_name" : "ItDi",
      "indices" : [ 109, 114 ],
      "id_str" : "575410586",
      "id" : 575410586
    }, {
      "name" : "John F. Fanselow",
      "screen_name" : "JFanselow",
      "indices" : [ 115, 125 ],
      "id_str" : "942914360",
      "id" : 942914360
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 126, 134 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 135, 140 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5HkjFknkZ5",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-tB",
      "display_url" : "wp.me\/pKFOt-tB"
    } ]
  },
  "geo" : { },
  "id_str" : "459358507134124032",
  "text" : "RT @rosemerebard: Challenging Learners to listen with both ears! http:\/\/t.co\/5HkjFknkZ5 @thesecretdos @ebefl @itdi @JFanselow @cgoodey @mur\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
        "screen_name" : "TheSecretDoS",
        "indices" : [ 70, 83 ],
        "id_str" : "440292980",
        "id" : 440292980
      }, {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 84, 90 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      }, {
        "name" : "Elio Di Dio",
        "screen_name" : "ItDi",
        "indices" : [ 91, 96 ],
        "id_str" : "575410586",
        "id" : 575410586
      }, {
        "name" : "John F. Fanselow",
        "screen_name" : "JFanselow",
        "indices" : [ 97, 107 ],
        "id_str" : "942914360",
        "id" : 942914360
      }, {
        "name" : "Carol Goodey",
        "screen_name" : "cgoodey",
        "indices" : [ 108, 116 ],
        "id_str" : "26606833",
        "id" : 26606833
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 117, 126 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/5HkjFknkZ5",
        "expanded_url" : "http:\/\/wp.me\/pKFOt-tB",
        "display_url" : "wp.me\/pKFOt-tB"
      } ]
    },
    "geo" : { },
    "id_str" : "459320600196964354",
    "text" : "Challenging Learners to listen with both ears! http:\/\/t.co\/5HkjFknkZ5 @thesecretdos @ebefl @itdi @JFanselow @cgoodey @muranava @BC_LETeens",
    "id" : 459320600196964354,
    "created_at" : "2014-04-24 13:18:59 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 459358507134124032,
  "created_at" : "2014-04-24 15:49:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 3, 19 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 41, 54 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 68, 84 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 121, 129 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/a0EbgPd9dP",
      "expanded_url" : "http:\/\/ow.ly\/w7CWE",
      "display_url" : "ow.ly\/w7CWE"
    } ]
  },
  "geo" : { },
  "id_str" : "459358267089883136",
  "text" : "RT @theteacherjames: Don't miss our next @BELTABelgium webinar with @michaelegriffin on May 11th: http:\/\/t.co\/a0EbgPd9dP #eltchat #iatefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 20, 33 ],
        "id_str" : "884934438",
        "id" : 884934438
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 47, 63 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 100, 108 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/a0EbgPd9dP",
        "expanded_url" : "http:\/\/ow.ly\/w7CWE",
        "display_url" : "ow.ly\/w7CWE"
      } ]
    },
    "geo" : { },
    "id_str" : "459352787038789632",
    "text" : "Don't miss our next @BELTABelgium webinar with @michaelegriffin on May 11th: http:\/\/t.co\/a0EbgPd9dP #eltchat #iatefl",
    "id" : 459352787038789632,
    "created_at" : "2014-04-24 15:26:53 +0000",
    "user" : {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "protected" : false,
      "id_str" : "71746265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595367704090939392\/nJCWaI_Z_normal.jpg",
      "id" : 71746265,
      "verified" : false
    }
  },
  "id" : 459358267089883136,
  "created_at" : "2014-04-24 15:48:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/459089622534860800\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/daVHdkrXK3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl8DlE-CMAA653g.png",
      "id_str" : "459089622539055104",
      "id" : 459089622539055104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl8DlE-CMAA653g.png",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 649
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 649
      } ],
      "display_url" : "pic.twitter.com\/daVHdkrXK3"
    } ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 16, 21 ]
    }, {
      "text" : "techindustry",
      "indices" : [ 22, 35 ]
    }, {
      "text" : "wearables",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459110087190396928",
  "text" : "RT @worrydream: #tech #techindustry #wearables http:\/\/t.co\/daVHdkrXK3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/459089622534860800\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/daVHdkrXK3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl8DlE-CMAA653g.png",
        "id_str" : "459089622539055104",
        "id" : 459089622539055104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl8DlE-CMAA653g.png",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 649
        } ],
        "display_url" : "pic.twitter.com\/daVHdkrXK3"
      } ],
      "hashtags" : [ {
        "text" : "tech",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "techindustry",
        "indices" : [ 6, 19 ]
      }, {
        "text" : "wearables",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459089622534860800",
    "text" : "#tech #techindustry #wearables http:\/\/t.co\/daVHdkrXK3",
    "id" : 459089622534860800,
    "created_at" : "2014-04-23 22:01:10 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 459110087190396928,
  "created_at" : "2014-04-23 23:22:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazon",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/a3jdYYo4i6",
      "expanded_url" : "http:\/\/topincomes.g-mond.parisschoolofeconomics.eu\/",
      "display_url" : "\u2026omes.g-mond.parisschoolofeconomics.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "458944530298208256",
  "text" : "play with data behind #amazon's no1 book The World Top Incomes Database http:\/\/t.co\/a3jdYYo4i6",
  "id" : 458944530298208256,
  "created_at" : "2014-04-23 12:24:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 0, 13 ],
      "id_str" : "702925903",
      "id" : 702925903
    }, {
      "name" : "CDS",
      "screen_name" : "CritDiscStuds",
      "indices" : [ 14, 28 ],
      "id_str" : "2195704844",
      "id" : 2195704844
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 29, 41 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458941675138977792",
  "geo" : { },
  "id_str" : "458943705517658112",
  "in_reply_to_user_id" : 702925903,
  "text" : "@WatchedPotts @CritDiscStuds @_paulbaker_ thks but um no open access?",
  "id" : 458943705517658112,
  "in_reply_to_status_id" : 458941675138977792,
  "created_at" : "2014-04-23 12:21:20 +0000",
  "in_reply_to_screen_name" : "WatchedPotts",
  "in_reply_to_user_id_str" : "702925903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 0, 13 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458901624795443200",
  "geo" : { },
  "id_str" : "458937544571633664",
  "in_reply_to_user_id" : 702925903,
  "text" : "@WatchedPotts thkx cld u tweet link, seems to have lost it in feed?",
  "id" : 458937544571633664,
  "in_reply_to_status_id" : 458901624795443200,
  "created_at" : "2014-04-23 11:56:51 +0000",
  "in_reply_to_screen_name" : "WatchedPotts",
  "in_reply_to_user_id_str" : "702925903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/78iHihcDM6",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/glowbe\/?c=glowbe&q=30156758",
      "display_url" : "corpus2.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458904656287002624",
  "geo" : { },
  "id_str" : "458934773100998656",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson Glowbe forget ranked 13 http:\/\/t.co\/78iHihcDM6 favoured by nigerians, jaimacans, and canadians",
  "id" : 458934773100998656,
  "in_reply_to_status_id" : 458904656287002624,
  "created_at" : "2014-04-23 11:45:51 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 114, 125 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/axAUPfQRqX",
      "expanded_url" : "http:\/\/bit.ly\/1f0zK3c",
      "display_url" : "bit.ly\/1f0zK3c"
    } ]
  },
  "geo" : { },
  "id_str" : "458880781415624704",
  "text" : "RT @tornhalves: Does Sugata Mitra rock the neoliberal boat or is he recruiting new galley slaves? Our support for @hughdellar http:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 98, 109 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/axAUPfQRqX",
        "expanded_url" : "http:\/\/bit.ly\/1f0zK3c",
        "display_url" : "bit.ly\/1f0zK3c"
      } ]
    },
    "geo" : { },
    "id_str" : "458607430617038848",
    "text" : "Does Sugata Mitra rock the neoliberal boat or is he recruiting new galley slaves? Our support for @hughdellar http:\/\/t.co\/axAUPfQRqX",
    "id" : 458607430617038848,
    "created_at" : "2014-04-22 14:05:06 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 458880781415624704,
  "created_at" : "2014-04-23 08:11:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/WN6XOlOGry",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/summerschool\/",
      "display_url" : "ucrel.lancs.ac.uk\/summerschool\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458880394734342144",
  "text" : "RT @HardieResearch: UCREL Summer School in Corpus Linguistics: http:\/\/t.co\/WN6XOlOGry  15-18 July. Free to attend, aimed at non-beginners, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/WN6XOlOGry",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/summerschool\/",
        "display_url" : "ucrel.lancs.ac.uk\/summerschool\/"
      } ]
    },
    "geo" : { },
    "id_str" : "458812669290905601",
    "text" : "UCREL Summer School in Corpus Linguistics: http:\/\/t.co\/WN6XOlOGry  15-18 July. Free to attend, aimed at non-beginners, see site for more.",
    "id" : 458812669290905601,
    "created_at" : "2014-04-23 03:40:39 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 458880394734342144,
  "created_at" : "2014-04-23 08:09:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/sfeQj6Zgq3",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-Om",
      "display_url" : "wp.me\/p3qkCB-Om"
    } ]
  },
  "geo" : { },
  "id_str" : "458389663586459648",
  "text" : "RT @GeoffreyJordan: Bullshit and its\u00A0critics http:\/\/t.co\/sfeQj6Zgq3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/sfeQj6Zgq3",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-Om",
        "display_url" : "wp.me\/p3qkCB-Om"
      } ]
    },
    "geo" : { },
    "id_str" : "458369986826756096",
    "text" : "Bullshit and its\u00A0critics http:\/\/t.co\/sfeQj6Zgq3",
    "id" : 458369986826756096,
    "created_at" : "2014-04-21 22:21:35 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 458389663586459648,
  "created_at" : "2014-04-21 23:39:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Ravitch",
      "screen_name" : "DianeRavitch",
      "indices" : [ 101, 114 ],
      "id_str" : "59010637",
      "id" : 59010637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/gCMnF0FSgx",
      "expanded_url" : "http:\/\/wp.me\/p2odLa-7Jm",
      "display_url" : "wp.me\/p2odLa-7Jm"
    } ]
  },
  "geo" : { },
  "id_str" : "458344189197959170",
  "text" : "inBloom Closes Down Due to Parental Objections to Data Mining of Students http:\/\/t.co\/gCMnF0FSgx via @DianeRavitch",
  "id" : 458344189197959170,
  "created_at" : "2014-04-21 20:39:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/6eEJDDveKv",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1frwHCDDuGBPE6DP7nzsApXzNz0lxecdlH53IRUb723o\/edit",
      "display_url" : "docs.google.com\/forms\/d\/1frwHC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458153805021216768",
  "text" : "RT @TESOLFrance: DEADLINE TESOL France Fall Colloq  MAY 31st. Exciting and stimulating  with Mr Stephen Krashen and Ms. Carol Read.https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/6eEJDDveKv",
        "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1frwHCDDuGBPE6DP7nzsApXzNz0lxecdlH53IRUb723o\/edit",
        "display_url" : "docs.google.com\/forms\/d\/1frwHC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "458125064387702784",
    "text" : "DEADLINE TESOL France Fall Colloq  MAY 31st. Exciting and stimulating  with Mr Stephen Krashen and Ms. Carol Read.https:\/\/t.co\/6eEJDDveKv",
    "id" : 458125064387702784,
    "created_at" : "2014-04-21 06:08:21 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 458153805021216768,
  "created_at" : "2014-04-21 08:02:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 3, 18 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/YAJFZgiIQx",
      "expanded_url" : "http:\/\/chronicle.com\/blogs\/profhacker\/five-lessons-for-online-teaching-from-a-mooc\/56655",
      "display_url" : "chronicle.com\/blogs\/profhack\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458011501270675456",
  "text" : "RT @ProfessMoravec: what I learned about teaching online from #corpusmooc http:\/\/t.co\/YAJFZgiIQx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/YAJFZgiIQx",
        "expanded_url" : "http:\/\/chronicle.com\/blogs\/profhacker\/five-lessons-for-online-teaching-from-a-mooc\/56655",
        "display_url" : "chronicle.com\/blogs\/profhack\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456402890962137089",
    "text" : "what I learned about teaching online from #corpusmooc http:\/\/t.co\/YAJFZgiIQx",
    "id" : 456402890962137089,
    "created_at" : "2014-04-16 12:05:03 +0000",
    "user" : {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "protected" : false,
      "id_str" : "369529173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751214483113013248\/qxxQX7mg_normal.jpg",
      "id" : 369529173,
      "verified" : false
    }
  },
  "id" : 458011501270675456,
  "created_at" : "2014-04-20 22:37:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beforemitra",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/dgMzy58adR",
      "expanded_url" : "http:\/\/wrd.cm\/1nj5jru",
      "display_url" : "wrd.cm\/1nj5jru"
    } ]
  },
  "geo" : { },
  "id_str" : "458011149045624832",
  "text" : "the shut-down&amp;replacement of education is the greatest business opportunity since Rockefeller found oil #beforemitra http:\/\/t.co\/dgMzy58adR",
  "id" : 458011149045624832,
  "created_at" : "2014-04-20 22:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "CGP Grey",
      "screen_name" : "cgpgrey",
      "indices" : [ 7, 15 ],
      "id_str" : "176774540",
      "id" : 176774540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457970892078063617",
  "geo" : { },
  "id_str" : "457982781579362304",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @cgpgrey addresses the engineering problem not the arguably more important metaphysical problem of schooling cf Neil Postman",
  "id" : 457982781579362304,
  "in_reply_to_status_id" : 457970892078063617,
  "created_at" : "2014-04-20 20:42:58 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAT",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/2eoAx2pgId",
      "expanded_url" : "http:\/\/bit.ly\/1jdCNAY",
      "display_url" : "bit.ly\/1jdCNAY"
    } ]
  },
  "geo" : { },
  "id_str" : "457216542045122561",
  "text" : "RT @linguisticpulse: A new look AND a new post. http:\/\/t.co\/2eoAx2pgId Shibboleths of social class: On the obscurity of #SAT vocabulary #li\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAT",
        "indices" : [ 99, 103 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 115, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/2eoAx2pgId",
        "expanded_url" : "http:\/\/bit.ly\/1jdCNAY",
        "display_url" : "bit.ly\/1jdCNAY"
      } ]
    },
    "geo" : { },
    "id_str" : "457194178284617729",
    "text" : "A new look AND a new post. http:\/\/t.co\/2eoAx2pgId Shibboleths of social class: On the obscurity of #SAT vocabulary #linguistics",
    "id" : 457194178284617729,
    "created_at" : "2014-04-18 16:29:21 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 457216542045122561,
  "created_at" : "2014-04-18 17:58:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 3, 16 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 19, 35 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "David Graddol",
      "screen_name" : "graddol",
      "indices" : [ 49, 57 ],
      "id_str" : "17836114",
      "id" : 17836114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ud3BwQnBbF",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-v5",
      "display_url" : "wp.me\/p25Kfd-v5"
    } ]
  },
  "geo" : { },
  "id_str" : "456876437295734784",
  "text" : "RT @LauraSoracco: .@michaelegriffin writes about @graddol highlighting the need to reinvent ourselves in ELT http:\/\/t.co\/ud3BwQnBbF check i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 1, 17 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "David Graddol",
        "screen_name" : "graddol",
        "indices" : [ 31, 39 ],
        "id_str" : "17836114",
        "id" : 17836114
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 131, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/ud3BwQnBbF",
        "expanded_url" : "http:\/\/wp.me\/p25Kfd-v5",
        "display_url" : "wp.me\/p25Kfd-v5"
      } ]
    },
    "geo" : { },
    "id_str" : "456872526585409536",
    "text" : ".@michaelegriffin writes about @graddol highlighting the need to reinvent ourselves in ELT http:\/\/t.co\/ud3BwQnBbF check interview! #ELT",
    "id" : 456872526585409536,
    "created_at" : "2014-04-17 19:11:13 +0000",
    "user" : {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "protected" : false,
      "id_str" : "15663328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766919326427254785\/4J5Q1zgQ_normal.jpg",
      "id" : 15663328,
      "verified" : false
    }
  },
  "id" : 456876437295734784,
  "created_at" : "2014-04-17 19:26:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 3, 18 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ExLUSUG73t",
      "expanded_url" : "http:\/\/www.verbalidentity.com\/corpus-linguistics-justify-hunches-faced-ceo\/",
      "display_url" : "verbalidentity.com\/corpus-linguis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456700706037043200",
  "text" : "RT @corpusloanword: Nice succinct overview of semantic preference and prosody revealed through corpus analyses: http:\/\/t.co\/ExLUSUG73t #cor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/ExLUSUG73t",
        "expanded_url" : "http:\/\/www.verbalidentity.com\/corpus-linguistics-justify-hunches-faced-ceo\/",
        "display_url" : "verbalidentity.com\/corpus-linguis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456693869497679873",
    "text" : "Nice succinct overview of semantic preference and prosody revealed through corpus analyses: http:\/\/t.co\/ExLUSUG73t #corpusMOOC",
    "id" : 456693869497679873,
    "created_at" : "2014-04-17 07:21:18 +0000",
    "user" : {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "protected" : false,
      "id_str" : "95419070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3194937799\/f5a7b3c729837992c82ce94d0db82774_normal.jpeg",
      "id" : 95419070,
      "verified" : false
    }
  },
  "id" : 456700706037043200,
  "created_at" : "2014-04-17 07:48:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "rousseau",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "pedagogy",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/3qMK4KPqa9",
      "expanded_url" : "http:\/\/bit.ly\/1m7h04k",
      "display_url" : "bit.ly\/1m7h04k"
    } ]
  },
  "geo" : { },
  "id_str" : "456471752122449920",
  "text" : "RT @tornhalves: Sugata Mitra and the parody of educational Romanticism #edtech #rousseau #pedagogy http:\/\/t.co\/3qMK4KPqa9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "rousseau",
        "indices" : [ 63, 72 ]
      }, {
        "text" : "pedagogy",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/3qMK4KPqa9",
        "expanded_url" : "http:\/\/bit.ly\/1m7h04k",
        "display_url" : "bit.ly\/1m7h04k"
      } ]
    },
    "geo" : { },
    "id_str" : "456404628549013504",
    "text" : "Sugata Mitra and the parody of educational Romanticism #edtech #rousseau #pedagogy http:\/\/t.co\/3qMK4KPqa9",
    "id" : 456404628549013504,
    "created_at" : "2014-04-16 12:11:57 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 456471752122449920,
  "created_at" : "2014-04-16 16:38:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456118297885683712",
  "geo" : { },
  "id_str" : "456122588113428480",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes cheers :)",
  "id" : 456122588113428480,
  "in_reply_to_status_id" : 456118297885683712,
  "created_at" : "2014-04-15 17:31:14 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Kii3jrdXyh",
      "expanded_url" : "http:\/\/wac.colostate.edu\/books\/genre\/genre.pdf",
      "display_url" : "wac.colostate.edu\/books\/genre\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456118688702545920",
  "text" : "RT @lousylinguist: Free book: Genre in a Changing World edited by Charles Bazerman (PDF): http:\/\/t.co\/Kii3jrdXyh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/Kii3jrdXyh",
        "expanded_url" : "http:\/\/wac.colostate.edu\/books\/genre\/genre.pdf",
        "display_url" : "wac.colostate.edu\/books\/genre\/ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456090138003927041",
    "text" : "Free book: Genre in a Changing World edited by Charles Bazerman (PDF): http:\/\/t.co\/Kii3jrdXyh",
    "id" : 456090138003927041,
    "created_at" : "2014-04-15 15:22:17 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 456118688702545920,
  "created_at" : "2014-04-15 17:15:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 44, 55 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/C8w1XZnqmf",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Technology_during_World_War_I",
      "display_url" : "en.wikipedia.org\/wiki\/Technolog\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "456069580084215808",
  "geo" : { },
  "id_str" : "456070422287880192",
  "in_reply_to_user_id" : 408365496,
  "text" : "compare and contrast http:\/\/t.co\/C8w1XZnqmf @leoselivan",
  "id" : 456070422287880192,
  "in_reply_to_status_id" : 456069580084215808,
  "created_at" : "2014-04-15 14:03:56 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456032940003430400",
  "geo" : { },
  "id_str" : "456033616511123456",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug as \"mad dog\" nativists are wont :)",
  "id" : 456033616511123456,
  "in_reply_to_status_id" : 456032940003430400,
  "created_at" : "2014-04-15 11:37:41 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ICAL TEFL",
      "screen_name" : "ICALTEFL",
      "indices" : [ 3, 12 ],
      "id_str" : "61521432",
      "id" : 61521432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tefl",
      "indices" : [ 130, 135 ]
    }, {
      "text" : "tesol",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "language",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/KEtninlBxx",
      "expanded_url" : "http:\/\/ow.ly\/vMgh3",
      "display_url" : "ow.ly\/vMgh3"
    } ]
  },
  "geo" : { },
  "id_str" : "456018778535768064",
  "text" : "RT @ICALTEFL: How to use n-grams in your TEFL class - a hugely underused but incredibly powerful resource. http:\/\/t.co\/KEtninlBxx #tefl #te\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tefl",
        "indices" : [ 116, 121 ]
      }, {
        "text" : "tesol",
        "indices" : [ 122, 128 ]
      }, {
        "text" : "language",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/KEtninlBxx",
        "expanded_url" : "http:\/\/ow.ly\/vMgh3",
        "display_url" : "ow.ly\/vMgh3"
      } ]
    },
    "geo" : { },
    "id_str" : "456007821180829697",
    "text" : "How to use n-grams in your TEFL class - a hugely underused but incredibly powerful resource. http:\/\/t.co\/KEtninlBxx #tefl #tesol #language",
    "id" : 456007821180829697,
    "created_at" : "2014-04-15 09:55:11 +0000",
    "user" : {
      "name" : "ICAL TEFL",
      "screen_name" : "ICALTEFL",
      "protected" : false,
      "id_str" : "61521432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692751348631277568\/g92s6Cug_normal.jpg",
      "id" : 61521432,
      "verified" : false
    }
  },
  "id" : 456018778535768064,
  "created_at" : "2014-04-15 10:38:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 139, 140 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 120, 130 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/CEZXNX3zwU",
      "expanded_url" : "http:\/\/www.eltjam.com\/tales-of-the-undead\/",
      "display_url" : "eltjam.com\/tales-of-the-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455981868090163200",
  "text" : "RT @eltjam: Russ Mayne on the tenacity of learning myths vs actual evidence: Tales of the undead http:\/\/t.co\/CEZXNX3zwU #education #iatefl \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 127, 133 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 108, 118 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/CEZXNX3zwU",
        "expanded_url" : "http:\/\/www.eltjam.com\/tales-of-the-undead\/",
        "display_url" : "eltjam.com\/tales-of-the-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "455961104263704576",
    "text" : "Russ Mayne on the tenacity of learning myths vs actual evidence: Tales of the undead http:\/\/t.co\/CEZXNX3zwU #education #iatefl @ebefl",
    "id" : 455961104263704576,
    "created_at" : "2014-04-15 06:49:33 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 455981868090163200,
  "created_at" : "2014-04-15 08:12:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455966522545291264",
  "geo" : { },
  "id_str" : "455979891637637120",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes file not available?",
  "id" : 455979891637637120,
  "in_reply_to_status_id" : 455966522545291264,
  "created_at" : "2014-04-15 08:04:12 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    }, {
      "name" : "Hasib N",
      "screen_name" : "ahasnoor",
      "indices" : [ 16, 25 ],
      "id_str" : "321395723",
      "id" : 321395723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455826480367284224",
  "geo" : { },
  "id_str" : "455827206468816896",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword @ahasnoor they are working now for me :)",
  "id" : 455827206468816896,
  "in_reply_to_status_id" : 455826480367284224,
  "created_at" : "2014-04-14 21:57:29 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/LpfOJdK4r5",
      "expanded_url" : "http:\/\/davidharbinson.com\/english-and-economic-development-my-learners-in-korea\/",
      "display_url" : "davidharbinson.com\/english-and-ec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455782166648344577",
  "text" : "RT @DavidHarbinson: English and economic development - my learners in Korea http:\/\/t.co\/LpfOJdK4r5 #IATEFL #KELTchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 79, 86 ]
      }, {
        "text" : "KELTchat",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/LpfOJdK4r5",
        "expanded_url" : "http:\/\/davidharbinson.com\/english-and-economic-development-my-learners-in-korea\/",
        "display_url" : "davidharbinson.com\/english-and-ec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "455765100146614272",
    "text" : "English and economic development - my learners in Korea http:\/\/t.co\/LpfOJdK4r5 #IATEFL #KELTchat",
    "id" : 455765100146614272,
    "created_at" : "2014-04-14 17:50:42 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 455782166648344577,
  "created_at" : "2014-04-14 18:58:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 0, 16 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 17, 28 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 29, 41 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    }, {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 42, 55 ],
      "id_str" : "702925903",
      "id" : 702925903
    }, {
      "name" : "CDS",
      "screen_name" : "CritDiscStuds",
      "indices" : [ 56, 70 ],
      "id_str" : "2195704844",
      "id" : 2195704844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455738475141402624",
  "geo" : { },
  "id_str" : "455754891441766402",
  "in_reply_to_user_id" : 1326508478,
  "text" : "@CorpusSocialSci @esl_robert @_paulbaker_ @WatchedPotts @CritDiscStuds is this right link for open access?",
  "id" : 455754891441766402,
  "in_reply_to_status_id" : 455738475141402624,
  "created_at" : "2014-04-14 17:10:08 +0000",
  "in_reply_to_screen_name" : "CorpusSocialSci",
  "in_reply_to_user_id_str" : "1326508478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 21, 30 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KELTchat",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ArAcvwQYSK",
      "expanded_url" : "http:\/\/keltchat.wordpress.com\/2014\/04\/14\/keltchat-slowburn-elt-megatrends-in-korea-tuesday-april-15th-10-am-10-pm\/",
      "display_url" : "keltchat.wordpress.com\/2014\/04\/14\/kel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455740018850816000",
  "text" : "RT @michaelegriffin: @muranava I thought the #KELTchat topic for tomorrow might interest you http:\/\/t.co\/ArAcvwQYSK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KELTchat",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ArAcvwQYSK",
        "expanded_url" : "http:\/\/keltchat.wordpress.com\/2014\/04\/14\/keltchat-slowburn-elt-megatrends-in-korea-tuesday-april-15th-10-am-10-pm\/",
        "display_url" : "keltchat.wordpress.com\/2014\/04\/14\/kel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "455724773213863936",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava I thought the #KELTchat topic for tomorrow might interest you http:\/\/t.co\/ArAcvwQYSK",
    "id" : 455724773213863936,
    "created_at" : "2014-04-14 15:10:27 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 455740018850816000,
  "created_at" : "2014-04-14 16:11:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455724773213863936",
  "geo" : { },
  "id_str" : "455739900693065728",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin nice,  thanks for mention :) am reading his china text at the moment v interesting, will try to chip in when i can",
  "id" : 455739900693065728,
  "in_reply_to_status_id" : 455724773213863936,
  "created_at" : "2014-04-14 16:10:34 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455694861510115328",
  "geo" : { },
  "id_str" : "455718771760836608",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab hi cool you can still post on community, and thanks nice to hear hope you get to make use of space :)",
  "id" : 455718771760836608,
  "in_reply_to_status_id" : 455694861510115328,
  "created_at" : "2014-04-14 14:46:36 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hasib N",
      "screen_name" : "ahasnoor",
      "indices" : [ 0, 9 ],
      "id_str" : "321395723",
      "id" : 321395723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455395495159296000",
  "geo" : { },
  "id_str" : "455711832616235008",
  "in_reply_to_user_id" : 321395723,
  "text" : "@ahasnoor has anyone manged to login to any of these resources? i cant seem to?",
  "id" : 455711832616235008,
  "in_reply_to_status_id" : 455395495159296000,
  "created_at" : "2014-04-14 14:19:02 +0000",
  "in_reply_to_screen_name" : "ahasnoor",
  "in_reply_to_user_id_str" : "321395723",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 116, 134 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455690103927885824",
  "text" : "RT @amyaishab: Does a reference corpus have to be larger than the study corpus if both are huge and same text type? #corpuslinguistics #cor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 101, 119 ]
      }, {
        "text" : "corpusmooc",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "455622525351763968",
    "text" : "Does a reference corpus have to be larger than the study corpus if both are huge and same text type? #corpuslinguistics #corpusmooc",
    "id" : 455622525351763968,
    "created_at" : "2014-04-14 08:24:09 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 455690103927885824,
  "created_at" : "2014-04-14 12:52:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hasib N",
      "screen_name" : "ahasnoor",
      "indices" : [ 3, 12 ],
      "id_str" : "321395723",
      "id" : 321395723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/F2n5MDdzrP",
      "expanded_url" : "http:\/\/global.oup.com\/academic\/librarians\/national-library-week\/?cc=sa&lang=en&",
      "display_url" : "global.oup.com\/academic\/libra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455689674955427840",
  "text" : "RT @ahasnoor: Oxford University opened its library to download books for free for a week\nUser: libraryweek\nPassword: libraryweek\n\nhttp:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/F2n5MDdzrP",
        "expanded_url" : "http:\/\/global.oup.com\/academic\/librarians\/national-library-week\/?cc=sa&lang=en&",
        "display_url" : "global.oup.com\/academic\/libra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "455395495159296000",
    "text" : "Oxford University opened its library to download books for free for a week\nUser: libraryweek\nPassword: libraryweek\n\nhttp:\/\/t.co\/F2n5MDdzrP",
    "id" : 455395495159296000,
    "created_at" : "2014-04-13 17:22:01 +0000",
    "user" : {
      "name" : "Hasib N",
      "screen_name" : "ahasnoor",
      "protected" : false,
      "id_str" : "321395723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559073892329738242\/9tXC-8kL_normal.jpeg",
      "id" : 321395723,
      "verified" : false
    }
  },
  "id" : 455689674955427840,
  "created_at" : "2014-04-14 12:50:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 3, 15 ],
      "id_str" : "412094121",
      "id" : 412094121
    }, {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 17, 27 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 28, 37 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/n00rbaizura\/status\/455523734162399232\/photo\/1",
      "indices" : [ 129, 143 ],
      "url" : "http:\/\/t.co\/xi8cVIpBpm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlJYbDnCYAEgXBE.png",
      "id_str" : "455523734166593537",
      "id" : 455523734166593537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlJYbDnCYAEgXBE.png",
      "sizes" : [ {
        "h" : 625,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xi8cVIpBpm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455596373564743680",
  "text" : "RT @n00rbaizura: @amyaishab @muranava I think you're on the right track. My comments (Thanks twitter for 140 characters!) --&gt; http:\/\/t.co\/x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy Aisha Brown",
        "screen_name" : "amyaishab",
        "indices" : [ 0, 10 ],
        "id_str" : "900029641",
        "id" : 900029641
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 11, 20 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/n00rbaizura\/status\/455523734162399232\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/xi8cVIpBpm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlJYbDnCYAEgXBE.png",
        "id_str" : "455523734166593537",
        "id" : 455523734166593537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlJYbDnCYAEgXBE.png",
        "sizes" : [ {
          "h" : 625,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xi8cVIpBpm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "455468372944515072",
    "geo" : { },
    "id_str" : "455523734162399232",
    "in_reply_to_user_id" : 900029641,
    "text" : "@amyaishab @muranava I think you're on the right track. My comments (Thanks twitter for 140 characters!) --&gt; http:\/\/t.co\/xi8cVIpBpm",
    "id" : 455523734162399232,
    "in_reply_to_status_id" : 455468372944515072,
    "created_at" : "2014-04-14 01:51:36 +0000",
    "in_reply_to_screen_name" : "amyaishab",
    "in_reply_to_user_id_str" : "900029641",
    "user" : {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "protected" : false,
      "id_str" : "412094121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760806110941024256\/uizQtOL1_normal.jpg",
      "id" : 412094121,
      "verified" : false
    }
  },
  "id" : 455596373564743680,
  "created_at" : "2014-04-14 06:40:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455591648295395328",
  "geo" : { },
  "id_str" : "455592269018832896",
  "in_reply_to_user_id" : 18602422,
  "text" : "@n00rbaizura be interested to read about how you extracted metaphors :)",
  "id" : 455592269018832896,
  "in_reply_to_status_id" : 455591648295395328,
  "created_at" : "2014-04-14 06:23:56 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    }, {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 13, 23 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455523734162399232",
  "geo" : { },
  "id_str" : "455591648295395328",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura @amyaishab hi this is great thank u so much you must join G+ CL comm :)",
  "id" : 455591648295395328,
  "in_reply_to_status_id" : 455523734162399232,
  "created_at" : "2014-04-14 06:21:28 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455475781222031360",
  "geo" : { },
  "id_str" : "455477250365087744",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons great :)",
  "id" : 455477250365087744,
  "in_reply_to_status_id" : 455475781222031360,
  "created_at" : "2014-04-13 22:46:53 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/27OFhECBzk",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455475101274996736",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons cheers for #corpusmooc rt george , do consider joining G+ comm https:\/\/t.co\/27OFhECBzk",
  "id" : 455475101274996736,
  "created_at" : "2014-04-13 22:38:21 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 14, 24 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455466187821170688",
  "text" : "thanks for RT @amyaishab any thoughts?",
  "id" : 455466187821170688,
  "created_at" : "2014-04-13 22:02:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JirdZgxwZ2",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/EDFcVKVnktY",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455461550451863552",
  "text" : "#corpusmooc folks is looking at semantically tagged data like this sensible? https:\/\/t.co\/JirdZgxwZ2",
  "id" : 455461550451863552,
  "created_at" : "2014-04-13 21:44:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/nI093EUp3D",
      "expanded_url" : "http:\/\/adaptivelearninginelt.wordpress.com\/2014\/04\/06\/edtech-and-neo-liberalism-fragment-of-a-network\/comment-page-1\/#comment-132",
      "display_url" : "adaptivelearninginelt.wordpress.com\/2014\/04\/06\/edt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455357557725732864",
  "text" : "Philip Kerr finds a paper on Learning styles co-authored by Sugata Mitra http:\/\/t.co\/nI093EUp3D",
  "id" : 455357557725732864,
  "created_at" : "2014-04-13 14:51:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 7, 22 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455340768614707201",
  "geo" : { },
  "id_str" : "455346865589190656",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @DavidHarbinson you'll have to start offering a prize like randi :)",
  "id" : 455346865589190656,
  "in_reply_to_status_id" : 455340768614707201,
  "created_at" : "2014-04-13 14:08:47 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/6HHdtULaLP",
      "expanded_url" : "http:\/\/www.nybooks.com\/articles\/archives\/2014\/may\/08\/thomas-piketty-new-gilded-age\/",
      "display_url" : "nybooks.com\/articles\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455088030022664192",
  "text" : "Why We\u2019re in a New Gilded Age Paul Krugman http:\/\/t.co\/6HHdtULaLP",
  "id" : 455088030022664192,
  "created_at" : "2014-04-12 21:00:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 11, 26 ],
      "id_str" : "501629829",
      "id" : 501629829
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 27, 33 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/dv2XpxSRGa",
      "expanded_url" : "http:\/\/www.etprofessional.com\/The_best_IATEFL_ever_25769809899.aspx?y=RPuGfkk5A7xlDWD0hee%252bOpWKibsWXSMV&z=Brxyg41Z3FJIt0BcWJCCdQ%253d%253d&e=DPEQ57DNRRMM7HBWB68RZAKCMW&utm_source=http%3a%2f%2fnews.pavpub.com%2folmgroup_prolz%2f&utm_medium=email&utm_campaign=ETp+Members+110414&utm_term=A+blog+on+the+obsolescence+of+teaching+and+other+IATEFL+highlights&utm_content=220184",
      "display_url" : "etprofessional.com\/The_best_IATEF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "454907298087833600",
  "geo" : { },
  "id_str" : "454907597016297472",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @ETprofessional @ebefl http:\/\/t.co\/dv2XpxSRGa",
  "id" : 454907597016297472,
  "in_reply_to_status_id" : 454907298087833600,
  "created_at" : "2014-04-12 09:03:17 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Johnny Unger",
      "screen_name" : "johnnyunger",
      "indices" : [ 26, 38 ],
      "id_str" : "84687412",
      "id" : 84687412
    }, {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 57, 70 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/JLSwy6XScc",
      "expanded_url" : "http:\/\/idibon.com\/readability-social-media-literature\/",
      "display_url" : "idibon.com\/readability-so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454906053684396032",
  "text" : "RT @TSchnoebelen: Thanks! @johnnyunger: Great article by @TSchnoebelen on readability in twitter vs great literature http:\/\/t.co\/JLSwy6XScc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Johnny Unger",
        "screen_name" : "johnnyunger",
        "indices" : [ 8, 20 ],
        "id_str" : "84687412",
        "id" : 84687412
      }, {
        "name" : "Tyler Schnoebelen",
        "screen_name" : "TSchnoebelen",
        "indices" : [ 39, 52 ],
        "id_str" : "14969147",
        "id" : 14969147
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/JLSwy6XScc",
        "expanded_url" : "http:\/\/idibon.com\/readability-social-media-literature\/",
        "display_url" : "idibon.com\/readability-so\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "454751858964582400",
    "geo" : { },
    "id_str" : "454759215190388736",
    "in_reply_to_user_id" : 84687412,
    "text" : "Thanks! @johnnyunger: Great article by @TSchnoebelen on readability in twitter vs great literature http:\/\/t.co\/JLSwy6XScc",
    "id" : 454759215190388736,
    "in_reply_to_status_id" : 454751858964582400,
    "created_at" : "2014-04-11 23:13:40 +0000",
    "in_reply_to_screen_name" : "johnnyunger",
    "in_reply_to_user_id_str" : "84687412",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 454906053684396032,
  "created_at" : "2014-04-12 08:57:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 22, 37 ],
      "id_str" : "501629829",
      "id" : 501629829
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 63, 69 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454901922060054528",
  "text" : "unsurprisingly or not @ETprofessional newsletter does not list @ebefl #iatefl talk as a highlight :\/",
  "id" : 454901922060054528,
  "created_at" : "2014-04-12 08:40:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/0hSLEaPfvZ",
      "expanded_url" : "https:\/\/xkcd.com\/1353\/",
      "display_url" : "xkcd.com\/1353\/"
    } ]
  },
  "geo" : { },
  "id_str" : "454900169692430336",
  "text" : "Heartbleed https:\/\/t.co\/0hSLEaPfvZ",
  "id" : 454900169692430336,
  "created_at" : "2014-04-12 08:33:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 15, 26 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454889323197124608",
  "geo" : { },
  "id_str" : "454893877825372160",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble @vickyloras slu :)",
  "id" : 454893877825372160,
  "in_reply_to_status_id" : 454889323197124608,
  "created_at" : "2014-04-12 08:08:46 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 101, 116 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogme",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/w3SreRP1hs",
      "expanded_url" : "http:\/\/AnthonyTeacher.com",
      "display_url" : "AnthonyTeacher.com"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/mww5dd5UMy",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/puppysteps-to-dogme#.U0jlTKXHpwU.twitter",
      "display_url" : "anthonyteacher.com\/blog\/puppystep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454887225646661632",
  "text" : "RT @michaelegriffin: http:\/\/t.co\/w3SreRP1hs \u00BB Puppysteps to Dogme: http:\/\/t.co\/mww5dd5UMy #dogme via @AnthonyTeacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AnthonyTeacher",
        "screen_name" : "AnthonyTeacher",
        "indices" : [ 80, 95 ],
        "id_str" : "285614027",
        "id" : 285614027
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dogme",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/w3SreRP1hs",
        "expanded_url" : "http:\/\/AnthonyTeacher.com",
        "display_url" : "AnthonyTeacher.com"
      }, {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/mww5dd5UMy",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/puppysteps-to-dogme#.U0jlTKXHpwU.twitter",
        "display_url" : "anthonyteacher.com\/blog\/puppystep\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "454878544573648896",
    "text" : "http:\/\/t.co\/w3SreRP1hs \u00BB Puppysteps to Dogme: http:\/\/t.co\/mww5dd5UMy #dogme via @AnthonyTeacher",
    "id" : 454878544573648896,
    "created_at" : "2014-04-12 07:07:50 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 454887225646661632,
  "created_at" : "2014-04-12 07:42:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 122, 138 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/1qyOS7gZGA",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-R5",
      "display_url" : "wp.me\/p21lsm-R5"
    } ]
  },
  "geo" : { },
  "id_str" : "454673831215374336",
  "text" : "A few tweaks to the 4-3-2 technique: mining texts for lexis + mind-mapping to increase fluenc\u2026 http:\/\/t.co\/1qyOS7gZGA via @wordpressdotcom",
  "id" : 454673831215374336,
  "created_at" : "2014-04-11 17:34:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL Direct",
      "screen_name" : "TESOLDirect",
      "indices" : [ 84, 96 ],
      "id_str" : "1171415774",
      "id" : 1171415774
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 97, 106 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454536902419308544",
  "geo" : { },
  "id_str" : "454542194083635200",
  "in_reply_to_user_id" : 1171415774,
  "text" : "example of  context that mitra supporters seem to downplay in #iatefl mitra debates @TESOLDirect @guardian",
  "id" : 454542194083635200,
  "in_reply_to_status_id" : 454536902419308544,
  "created_at" : "2014-04-11 08:51:18 +0000",
  "in_reply_to_screen_name" : "TESOLDirect",
  "in_reply_to_user_id_str" : "1171415774",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/2sA6Hy471r",
      "expanded_url" : "http:\/\/www.npr.org\/2014\/04\/09\/299178029\/debate-in-an-online-world-are-brick-and-mortar-colleges-obsolete",
      "display_url" : "npr.org\/2014\/04\/09\/299\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "454483825607716864",
  "geo" : { },
  "id_str" : "454485232193138688",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith similarish debate on npr recently http:\/\/t.co\/2sA6Hy471r",
  "id" : 454485232193138688,
  "in_reply_to_status_id" : 454483825607716864,
  "created_at" : "2014-04-11 05:04:57 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454406685528829952",
  "geo" : { },
  "id_str" : "454484803816263680",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith no cause the plug was from the computer :\/",
  "id" : 454484803816263680,
  "in_reply_to_status_id" : 454406685528829952,
  "created_at" : "2014-04-11 05:03:15 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/VcYgCwhl6C",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2012\/06\/01\/piratebox-a-way-to-share-files-in-class\/",
      "display_url" : "eflnotes.wordpress.com\/2012\/06\/01\/pir\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "454363421014646784",
  "geo" : { },
  "id_str" : "454368055930675201",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur nice, like your selection of activities, #piratebox is another option e.g. c http:\/\/t.co\/VcYgCwhl6C",
  "id" : 454368055930675201,
  "in_reply_to_status_id" : 454363421014646784,
  "created_at" : "2014-04-10 21:19:20 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 21, 32 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Ben Zimmer",
      "screen_name" : "bgzimmer",
      "indices" : [ 53, 62 ],
      "id_str" : "15104164",
      "id" : 15104164
    }, {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 116, 129 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Jacob Eisenstein",
      "screen_name" : "jacobeisenstein",
      "indices" : [ 130, 140 ],
      "id_str" : "102708234",
      "id" : 102708234
    }, {
      "name" : "David Bamman",
      "screen_name" : "dbamman",
      "indices" : [ 139, 140 ],
      "id_str" : "82859989",
      "id" : 82859989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/JerlVO62Bw",
      "expanded_url" : "http:\/\/b.globe.com\/U2xPtQ",
      "display_url" : "b.globe.com\/U2xPtQ"
    } ]
  },
  "geo" : { },
  "id_str" : "454355577381351425",
  "text" : "RT @TSchnoebelen: RT @heatherfro: and after you read @bgzimmer's article (http:\/\/t.co\/JerlVO62Bw) you should follow @TSchnoebelen @jacobeis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "heather froehlich",
        "screen_name" : "heatherfro",
        "indices" : [ 3, 14 ],
        "id_str" : "152051625",
        "id" : 152051625
      }, {
        "name" : "Ben Zimmer",
        "screen_name" : "bgzimmer",
        "indices" : [ 35, 44 ],
        "id_str" : "15104164",
        "id" : 15104164
      }, {
        "name" : "Tyler Schnoebelen",
        "screen_name" : "TSchnoebelen",
        "indices" : [ 98, 111 ],
        "id_str" : "14969147",
        "id" : 14969147
      }, {
        "name" : "Jacob Eisenstein",
        "screen_name" : "jacobeisenstein",
        "indices" : [ 112, 128 ],
        "id_str" : "102708234",
        "id" : 102708234
      }, {
        "name" : "David Bamman",
        "screen_name" : "dbamman",
        "indices" : [ 129, 137 ],
        "id_str" : "82859989",
        "id" : 82859989
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/JerlVO62Bw",
        "expanded_url" : "http:\/\/b.globe.com\/U2xPtQ",
        "display_url" : "b.globe.com\/U2xPtQ"
      } ]
    },
    "in_reply_to_status_id_str" : "454231217869979648",
    "geo" : { },
    "id_str" : "454288637468114944",
    "in_reply_to_user_id" : 152051625,
    "text" : "RT @heatherfro: and after you read @bgzimmer's article (http:\/\/t.co\/JerlVO62Bw) you should follow @TSchnoebelen @jacobeisenstein @dbamman",
    "id" : 454288637468114944,
    "in_reply_to_status_id" : 454231217869979648,
    "created_at" : "2014-04-10 16:03:46 +0000",
    "in_reply_to_screen_name" : "heatherfro",
    "in_reply_to_user_id_str" : "152051625",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 454355577381351425,
  "created_at" : "2014-04-10 20:29:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454342159886733312",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson cheers for rt :)",
  "id" : 454342159886733312,
  "created_at" : "2014-04-10 19:36:26 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 10, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/TecyaYQ7hQ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Mf",
      "display_url" : "wp.me\/pgHyE-Mf"
    } ]
  },
  "geo" : { },
  "id_str" : "454337802797604864",
  "text" : "update to #iatefl chain reaction bloggers by @FeyzanBedenli  http:\/\/t.co\/TecyaYQ7hQ",
  "id" : 454337802797604864,
  "created_at" : "2014-04-10 19:19:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454263525678907392",
  "geo" : { },
  "id_str" : "454290202811711488",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith ahhhhhhhh I think he was in my dreams the other night asking me how to change a plug fuse :\/",
  "id" : 454290202811711488,
  "in_reply_to_status_id" : 454263525678907392,
  "created_at" : "2014-04-10 16:09:59 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/LRl6AWgTm2",
      "expanded_url" : "http:\/\/pedagogablog.wordpress.com\/",
      "display_url" : "pedagogablog.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "454289847763873792",
  "text" : "RT @ElkySmith: Because what we all need now is another blog post about Sugata Mitra at #IATEFL: http:\/\/t.co\/LRl6AWgTm2 #AusELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "AusELT",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/LRl6AWgTm2",
        "expanded_url" : "http:\/\/pedagogablog.wordpress.com\/",
        "display_url" : "pedagogablog.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "454263525678907392",
    "text" : "Because what we all need now is another blog post about Sugata Mitra at #IATEFL: http:\/\/t.co\/LRl6AWgTm2 #AusELT",
    "id" : 454263525678907392,
    "created_at" : "2014-04-10 14:23:58 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 454289847763873792,
  "created_at" : "2014-04-10 16:08:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 74, 90 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/qeBpUE8heL",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-bB",
      "display_url" : "wp.me\/p2CPYN-bB"
    } ]
  },
  "geo" : { },
  "id_str" : "454214785639276544",
  "text" : "NATO\/ISAF's 'parting gift' to Afghan children. http:\/\/t.co\/qeBpUE8heL via @wordpressdotcom",
  "id" : 454214785639276544,
  "created_at" : "2014-04-10 11:10:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Edtech",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "EFL",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/VVECPC7bkr",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-eX",
      "display_url" : "wp.me\/p1RJaO-eX"
    } ]
  },
  "geo" : { },
  "id_str" : "454193092036681728",
  "text" : "RT @NicolaPrentis: What #Edtech says vs What we hear #EFL Two industries separated by a common language? http:\/\/t.co\/VVECPC7bkr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Edtech",
        "indices" : [ 5, 12 ]
      }, {
        "text" : "EFL",
        "indices" : [ 34, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/VVECPC7bkr",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-eX",
        "display_url" : "wp.me\/p1RJaO-eX"
      } ]
    },
    "geo" : { },
    "id_str" : "454183879499210754",
    "text" : "What #Edtech says vs What we hear #EFL Two industries separated by a common language? http:\/\/t.co\/VVECPC7bkr",
    "id" : 454183879499210754,
    "created_at" : "2014-04-10 09:07:29 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 454193092036681728,
  "created_at" : "2014-04-10 09:44:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 31, 45 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Bonnie Stewart",
      "screen_name" : "bonstewart",
      "indices" : [ 118, 129 ],
      "id_str" : "6532522",
      "id" : 6532522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcdl2014",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "edtech",
      "indices" : [ 131, 138 ]
    }, {
      "text" : "HigherEd",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/3o4RvEsmjL",
      "expanded_url" : "http:\/\/hackeducation.com\/2014\/04\/09\/bc-digital-learning-conference-2014\/",
      "display_url" : "hackeducation.com\/2014\/04\/09\/bc-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454186074123010048",
  "text" : "RT @KateMfD: Truly outstanding @audreywatters keynote at #bcdl2014: http:\/\/t.co\/3o4RvEsmjL. Read this one thing. (via @bonstewart) #edtech \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 18, 32 ],
        "id_str" : "25388528",
        "id" : 25388528
      }, {
        "name" : "Bonnie Stewart",
        "screen_name" : "bonstewart",
        "indices" : [ 105, 116 ],
        "id_str" : "6532522",
        "id" : 6532522
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcdl2014",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "edtech",
        "indices" : [ 118, 125 ]
      }, {
        "text" : "HigherEd",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/3o4RvEsmjL",
        "expanded_url" : "http:\/\/hackeducation.com\/2014\/04\/09\/bc-digital-learning-conference-2014\/",
        "display_url" : "hackeducation.com\/2014\/04\/09\/bc-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "454049124547977217",
    "text" : "Truly outstanding @audreywatters keynote at #bcdl2014: http:\/\/t.co\/3o4RvEsmjL. Read this one thing. (via @bonstewart) #edtech #HigherEd",
    "id" : 454049124547977217,
    "created_at" : "2014-04-10 00:12:01 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 454186074123010048,
  "created_at" : "2014-04-10 09:16:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Dita Phillips",
      "screen_name" : "ditaphillips",
      "indices" : [ 15, 28 ],
      "id_str" : "2371787384",
      "id" : 2371787384
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 29, 45 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454021106308235265",
  "text" : "RT @ElkySmith: @ditaphillips @theteacherjames there isn't enough money to fund public education properly so we'll let private interests 'di\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dita Phillips",
        "screen_name" : "ditaphillips",
        "indices" : [ 0, 13 ],
        "id_str" : "2371787384",
        "id" : 2371787384
      }, {
        "name" : "James Taylor",
        "screen_name" : "theteacherjames",
        "indices" : [ 14, 30 ],
        "id_str" : "71746265",
        "id" : 71746265
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "454001745665212417",
    "geo" : { },
    "id_str" : "454020505641578496",
    "in_reply_to_user_id" : 2371787384,
    "text" : "@ditaphillips @theteacherjames there isn't enough money to fund public education properly so we'll let private interests 'disrupt' it.",
    "id" : 454020505641578496,
    "in_reply_to_status_id" : 454001745665212417,
    "created_at" : "2014-04-09 22:18:18 +0000",
    "in_reply_to_screen_name" : "ditaphillips",
    "in_reply_to_user_id_str" : "2371787384",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 454021106308235265,
  "created_at" : "2014-04-09 22:20:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454014166702235648",
  "geo" : { },
  "id_str" : "454014228052320257",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch ok thanks",
  "id" : 454014228052320257,
  "in_reply_to_status_id" : 454014166702235648,
  "created_at" : "2014-04-09 21:53:21 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454013183288958978",
  "geo" : { },
  "id_str" : "454013758885859328",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch no to filming or no to made public?",
  "id" : 454013758885859328,
  "in_reply_to_status_id" : 454013183288958978,
  "created_at" : "2014-04-09 21:51:29 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "talc2014",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453980539763310593",
  "geo" : { },
  "id_str" : "454013043408928768",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch hi, will any of the sessions for #talc2014 be filmed and made public?",
  "id" : 454013043408928768,
  "in_reply_to_status_id" : 453980539763310593,
  "created_at" : "2014-04-09 21:48:39 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454003718212841472",
  "text" : "thanks for chat all :) #eltchat",
  "id" : 454003718212841472,
  "created_at" : "2014-04-09 21:11:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 17, 26 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454002706815143936",
  "geo" : { },
  "id_str" : "454002886234882049",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @Marisa_C ahhhh not another one ;) #eltchat",
  "id" : 454002886234882049,
  "in_reply_to_status_id" : 454002706815143936,
  "created_at" : "2014-04-09 21:08:17 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Sobocan",
      "screen_name" : "LeaSobocan",
      "indices" : [ 0, 11 ],
      "id_str" : "391891207",
      "id" : 391891207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454002091124871168",
  "geo" : { },
  "id_str" : "454002513474498560",
  "in_reply_to_user_id" : 391891207,
  "text" : "@LeaSobocan @NinaEnglishBrno he says a lot of things that is hard to substantiate #eltchat",
  "id" : 454002513474498560,
  "in_reply_to_status_id" : 454002091124871168,
  "created_at" : "2014-04-09 21:06:48 +0000",
  "in_reply_to_screen_name" : "LeaSobocan",
  "in_reply_to_user_id_str" : "391891207",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Lea Sobocan",
      "screen_name" : "LeaSobocan",
      "indices" : [ 11, 22 ],
      "id_str" : "391891207",
      "id" : 391891207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454001203475935233",
  "geo" : { },
  "id_str" : "454001715743039488",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @LeaSobocan @HadaLitim have mentioned outof school factors account for about 60 percent of variance in kids achievement #eltchat",
  "id" : 454001715743039488,
  "in_reply_to_status_id" : 454001203475935233,
  "created_at" : "2014-04-09 21:03:38 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Sobocan",
      "screen_name" : "LeaSobocan",
      "indices" : [ 0, 11 ],
      "id_str" : "391891207",
      "id" : 391891207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454000099656757248",
  "geo" : { },
  "id_str" : "454000634375966721",
  "in_reply_to_user_id" : 391891207,
  "text" : "@LeaSobocan @NinaEnglishBrno are not a lot of these \"grannies\" retired teachers? wonder where they learnt their stuff from? #eltchat",
  "id" : 454000634375966721,
  "in_reply_to_status_id" : 454000099656757248,
  "created_at" : "2014-04-09 20:59:20 +0000",
  "in_reply_to_screen_name" : "LeaSobocan",
  "in_reply_to_user_id_str" : "391891207",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marjorie Rosenberg",
      "screen_name" : "MarjorieRosenbe",
      "indices" : [ 0, 16 ],
      "id_str" : "328052618",
      "id" : 328052618
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 17, 33 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 34, 44 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453999453775872000",
  "geo" : { },
  "id_str" : "453999933004476416",
  "in_reply_to_user_id" : 328052618,
  "text" : "@MarjorieRosenbe @theteacherjames @HanaTicha all from wealthy families #eltchat",
  "id" : 453999933004476416,
  "in_reply_to_status_id" : 453999453775872000,
  "created_at" : "2014-04-09 20:56:33 +0000",
  "in_reply_to_screen_name" : "MarjorieRosenbe",
  "in_reply_to_user_id_str" : "328052618",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elcthat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453998243408777217",
  "geo" : { },
  "id_str" : "453999152444485632",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl don't know about should but people have been making that point #elcthat",
  "id" : 453999152444485632,
  "in_reply_to_status_id" : 453998243408777217,
  "created_at" : "2014-04-09 20:53:27 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453998778564231169",
  "text" : "why are people taking chaos theory of learning as plausible when even mitra says it speculative? #eltchat",
  "id" : 453998778564231169,
  "created_at" : "2014-04-09 20:51:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elcthat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453997168454819840",
  "geo" : { },
  "id_str" : "453997945017597952",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl education is a lot about deciding between good and bad and not only truth #elcthat",
  "id" : 453997945017597952,
  "in_reply_to_status_id" : 453997168454819840,
  "created_at" : "2014-04-09 20:48:39 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 11, 20 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453996058356776960",
  "geo" : { },
  "id_str" : "453996458292039680",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @Marisa_C the poorest kids with best results get into college about the same rate as richest kids with worst results #eltchat",
  "id" : 453996458292039680,
  "in_reply_to_status_id" : 453996058356776960,
  "created_at" : "2014-04-09 20:42:45 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 0, 10 ],
      "id_str" : "444977554",
      "id" : 444977554
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 11, 22 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453994313639534593",
  "geo" : { },
  "id_str" : "453995095088717825",
  "in_reply_to_user_id" : 444977554,
  "text" : "@joannacre @naomishema yeah pcs arguably would have accelerated process, it's my turn to watch cat videos piggy! :)",
  "id" : 453995095088717825,
  "in_reply_to_status_id" : 453994313639534593,
  "created_at" : "2014-04-09 20:37:20 +0000",
  "in_reply_to_screen_name" : "joannacre",
  "in_reply_to_user_id_str" : "444977554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 10, 19 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453994023448248320",
  "geo" : { },
  "id_str" : "453994713771966465",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K @Marisa_C huge group dynamic issues like social conformism #eltchat",
  "id" : 453994713771966465,
  "in_reply_to_status_id" : 453994023448248320,
  "created_at" : "2014-04-09 20:35:49 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Sobocan",
      "screen_name" : "LeaSobocan",
      "indices" : [ 0, 11 ],
      "id_str" : "391891207",
      "id" : 391891207
    }, {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 12, 24 ],
      "id_str" : "15350512",
      "id" : 15350512
    }, {
      "name" : "Christine Mullaney",
      "screen_name" : "ChristineMulla",
      "indices" : [ 25, 40 ],
      "id_str" : "594377945",
      "id" : 594377945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453993039560966144",
  "geo" : { },
  "id_str" : "453993621508087808",
  "in_reply_to_user_id" : 391891207,
  "text" : "@LeaSobocan @Shaunwilden @ChristineMulla in the bio-tech study neither did the kids the texts were selected by experts #eltchat",
  "id" : 453993621508087808,
  "in_reply_to_status_id" : 453993039560966144,
  "created_at" : "2014-04-09 20:31:28 +0000",
  "in_reply_to_screen_name" : "LeaSobocan",
  "in_reply_to_user_id_str" : "391891207",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453991938405175298",
  "geo" : { },
  "id_str" : "453992452970774531",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K cause like we need to +think of the children+ make us all warm and fuzzy while siphoning their future away #ELTchat",
  "id" : 453992452970774531,
  "in_reply_to_status_id" : 453991938405175298,
  "created_at" : "2014-04-09 20:26:50 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nati Gonzalez Brandi",
      "screen_name" : "natibrandi",
      "indices" : [ 0, 11 ],
      "id_str" : "111053153",
      "id" : 111053153
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 12, 21 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 22, 31 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453990669271703554",
  "geo" : { },
  "id_str" : "453991281191313408",
  "in_reply_to_user_id" : 111053153,
  "text" : "@natibrandi @Marisa_C @Wiktor_K or gov put money in outside school factors which would have much more impact on education #ELTchat",
  "id" : 453991281191313408,
  "in_reply_to_status_id" : 453990669271703554,
  "created_at" : "2014-04-09 20:22:10 +0000",
  "in_reply_to_screen_name" : "natibrandi",
  "in_reply_to_user_id_str" : "111053153",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 3, 12 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    }, {
      "name" : "LouiseRobertson",
      "screen_name" : "LouiseRobertson",
      "indices" : [ 14, 30 ],
      "id_str" : "18779876",
      "id" : 18779876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453990861333094400",
  "text" : "RT @Wiktor_K: @LouiseRobertson ...or, unfortunately, watch all the cat videos there are. A computer does not a learning make, imho. #ELTChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LouiseRobertson",
        "screen_name" : "LouiseRobertson",
        "indices" : [ 0, 16 ],
        "id_str" : "18779876",
        "id" : 18779876
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTChat",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453990501885423618",
    "in_reply_to_user_id" : 18779876,
    "text" : "@LouiseRobertson ...or, unfortunately, watch all the cat videos there are. A computer does not a learning make, imho. #ELTChat",
    "id" : 453990501885423618,
    "created_at" : "2014-04-09 20:19:05 +0000",
    "in_reply_to_screen_name" : "LouiseRobertson",
    "in_reply_to_user_id_str" : "18779876",
    "user" : {
      "name" : "BRAVE Learning",
      "screen_name" : "BRAVE_Learning",
      "protected" : false,
      "id_str" : "222498082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714724460461473792\/_xHUkSmB_normal.jpg",
      "id" : 222498082,
      "verified" : false
    }
  },
  "id" : 453990861333094400,
  "created_at" : "2014-04-09 20:20:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LouiseRobertson",
      "screen_name" : "LouiseRobertson",
      "indices" : [ 0, 16 ],
      "id_str" : "18779876",
      "id" : 18779876
    }, {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 17, 25 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453989477267308545",
  "geo" : { },
  "id_str" : "453989982248898561",
  "in_reply_to_user_id" : 18779876,
  "text" : "@LouiseRobertson @Sugatam erm i want to know things who can teach me? :\/ #ELTchat",
  "id" : 453989982248898561,
  "in_reply_to_status_id" : 453989477267308545,
  "created_at" : "2014-04-09 20:17:01 +0000",
  "in_reply_to_screen_name" : "LouiseRobertson",
  "in_reply_to_user_id_str" : "18779876",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453987931171323904",
  "geo" : { },
  "id_str" : "453988405970747393",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C i think chaos \"theory\" as a theory of learning is dubious at best #ELTchat",
  "id" : 453988405970747393,
  "in_reply_to_status_id" : 453987931171323904,
  "created_at" : "2014-04-09 20:10:45 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 11, 20 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 21, 30 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 31, 40 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453987102519463936",
  "geo" : { },
  "id_str" : "453987468044681217",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @Ashowski @Marisa_C @Wiktor_K mitra is a fan of chaos theory not social constructivism as a theory of learning",
  "id" : 453987468044681217,
  "in_reply_to_status_id" : 453987102519463936,
  "created_at" : "2014-04-09 20:07:01 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453987099419885568",
  "text" : "#eltchat no of words in comments to mitra posts nearly same as posts 13477 to 16586; top keyword in comments- teacher, in posts - mitra",
  "id" : 453987099419885568,
  "created_at" : "2014-04-09 20:05:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 3, 14 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 127, 131 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PbTpOaUE8s",
      "expanded_url" : "http:\/\/bit.ly\/OEyvKz",
      "display_url" : "bit.ly\/OEyvKz"
    } ]
  },
  "geo" : { },
  "id_str" : "453985755644571649",
  "text" : "RT @elawassell: via Geoff Jordan - Newsflash: Hoey Well; Monitor Theory and Lexical Approach Still Dead http:\/\/t.co\/PbTpOaUE8s #elt #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 111, 115 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 116, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/PbTpOaUE8s",
        "expanded_url" : "http:\/\/bit.ly\/OEyvKz",
        "display_url" : "bit.ly\/OEyvKz"
      } ]
    },
    "geo" : { },
    "id_str" : "453978518104207360",
    "text" : "via Geoff Jordan - Newsflash: Hoey Well; Monitor Theory and Lexical Approach Still Dead http:\/\/t.co\/PbTpOaUE8s #elt #eltchat",
    "id" : 453978518104207360,
    "created_at" : "2014-04-09 19:31:27 +0000",
    "user" : {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "protected" : false,
      "id_str" : "51157050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1879392732\/11elwas_normal.jpg",
      "id" : 51157050,
      "verified" : false
    }
  },
  "id" : 453985755644571649,
  "created_at" : "2014-04-09 20:00:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453978518104207360",
  "geo" : { },
  "id_str" : "453979370366189568",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell whayhay a non mitra #iatefl post :)",
  "id" : 453979370366189568,
  "in_reply_to_status_id" : 453978518104207360,
  "created_at" : "2014-04-09 19:34:51 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 0, 16 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453968185889660929",
  "geo" : { },
  "id_str" : "453968646449410048",
  "in_reply_to_user_id" : 1400748798,
  "text" : "@linguisticpulse yeah it is, sometimes i copy paste your text into text editor to read, must be getting old!",
  "id" : 453968646449410048,
  "in_reply_to_status_id" : 453968185889660929,
  "created_at" : "2014-04-09 18:52:14 +0000",
  "in_reply_to_screen_name" : "linguisticpulse",
  "in_reply_to_user_id_str" : "1400748798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 0, 16 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453967182435991553",
  "geo" : { },
  "id_str" : "453967849489698816",
  "in_reply_to_user_id" : 1400748798,
  "text" : "@linguisticpulse hi u ever had comments on white text back background\/ yellow surround? somewhat difficult to read your great posts!",
  "id" : 453967849489698816,
  "in_reply_to_status_id" : 453967182435991553,
  "created_at" : "2014-04-09 18:49:04 +0000",
  "in_reply_to_screen_name" : "linguisticpulse",
  "in_reply_to_user_id_str" : "1400748798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/qBwHKPYYMS",
      "expanded_url" : "http:\/\/bit.ly\/1qj3KZG",
      "display_url" : "bit.ly\/1qj3KZG"
    } ]
  },
  "geo" : { },
  "id_str" : "453967567997374465",
  "text" : "RT @linguisticpulse: Do we talk about men more than women? http:\/\/t.co\/qBwHKPYYMS Answering previous question about data showing men overre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/qBwHKPYYMS",
        "expanded_url" : "http:\/\/bit.ly\/1qj3KZG",
        "display_url" : "bit.ly\/1qj3KZG"
      } ]
    },
    "geo" : { },
    "id_str" : "453967182435991553",
    "text" : "Do we talk about men more than women? http:\/\/t.co\/qBwHKPYYMS Answering previous question about data showing men overrepresented in corpora",
    "id" : 453967182435991553,
    "created_at" : "2014-04-09 18:46:25 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 453967567997374465,
  "created_at" : "2014-04-09 18:47:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Bennett",
      "screen_name" : "natalieben",
      "indices" : [ 0, 11 ],
      "id_str" : "16596200",
      "id" : 16596200
    }, {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 12, 24 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/7KSvSHx3Tb",
      "expanded_url" : "http:\/\/loopthetube.com\/#sgOWTM5R2DA&start=151.853&end=156.800",
      "display_url" : "loopthetube.com\/#sgOWTM5R2DA&s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453897363535724545",
  "geo" : { },
  "id_str" : "453965943639912448",
  "in_reply_to_user_id" : 16596200,
  "text" : "@natalieben @onalifeglug http:\/\/t.co\/7KSvSHx3Tb an idea whose time has come for sure",
  "id" : 453965943639912448,
  "in_reply_to_status_id" : 453897363535724545,
  "created_at" : "2014-04-09 18:41:29 +0000",
  "in_reply_to_screen_name" : "natalieben",
  "in_reply_to_user_id_str" : "16596200",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Mike Butcher MBE",
      "screen_name" : "mikebutcher",
      "indices" : [ 11, 23 ],
      "id_str" : "13666",
      "id" : 13666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/jfjtwRN8RC",
      "expanded_url" : "http:\/\/techcrunch.com\/2010\/10\/28\/busuu-partners-with-publisher-collins-to-push-more-traditional-language-learning-content\/",
      "display_url" : "techcrunch.com\/2010\/10\/28\/bus\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453918717903376384",
  "geo" : { },
  "id_str" : "453932557890244608",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @mikebutcher last Busuu \"disruption\" did not stop those dam TEFLers lets have another go http:\/\/t.co\/jfjtwRN8RC :)",
  "id" : 453932557890244608,
  "in_reply_to_status_id" : 453918717903376384,
  "created_at" : "2014-04-09 16:28:50 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UOb4kjz4mJ",
      "expanded_url" : "http:\/\/www.etprofessional.com\/The_obsolescence_of_teachers__the_Sugata_Mitra_controversy_25769809797.aspx",
      "display_url" : "etprofessional.com\/The_obsolescen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453908912304320513",
  "text" : "RT @chiasuan: Is teaching as we know it becoming obsolete? This is my humble take on the Sugata Mitra #IATEFL plenary controversy.\nhttp:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/UOb4kjz4mJ",
        "expanded_url" : "http:\/\/www.etprofessional.com\/The_obsolescence_of_teachers__the_Sugata_Mitra_controversy_25769809797.aspx",
        "display_url" : "etprofessional.com\/The_obsolescen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453903191550484480",
    "text" : "Is teaching as we know it becoming obsolete? This is my humble take on the Sugata Mitra #IATEFL plenary controversy.\nhttp:\/\/t.co\/UOb4kjz4mJ",
    "id" : 453903191550484480,
    "created_at" : "2014-04-09 14:32:08 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 453908912304320513,
  "created_at" : "2014-04-09 14:54:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 0, 15 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453898271959031809",
  "geo" : { },
  "id_str" : "453899662651838464",
  "in_reply_to_user_id" : 1327355143,
  "text" : "@EvilJoeMcVeigh cause with the hyphens would be more than 5 :)",
  "id" : 453899662651838464,
  "in_reply_to_status_id" : 453898271959031809,
  "created_at" : "2014-04-09 14:18:07 +0000",
  "in_reply_to_screen_name" : "EvilJoeMcVeigh",
  "in_reply_to_user_id_str" : "1327355143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 62, 73 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/mFGefkKi0O",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/",
      "display_url" : "digitalcounterrevolution.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "453894421248233472",
  "text" : "@TESOLatRennert yr welcome, i would suggest u check out other @tornhalves writings at http:\/\/t.co\/mFGefkKi0O",
  "id" : 453894421248233472,
  "created_at" : "2014-04-09 13:57:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/cbjD85Gqyg",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/04\/06\/iatefl-harrogate-2014-mitra-having-a-jelly-good-time\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/04\/06\/iat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453891492042403842",
  "geo" : { },
  "id_str" : "453892148312936449",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga ideological clash yes, fyi my hybrid #iatefl graddol\/mitra post and links at bottom for u to peruse http:\/\/t.co\/cbjD85Gqyg",
  "id" : 453892148312936449,
  "in_reply_to_status_id" : 453891492042403842,
  "created_at" : "2014-04-09 13:48:15 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453887816297381888",
  "geo" : { },
  "id_str" : "453888195462451200",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga erm people like drama?",
  "id" : 453888195462451200,
  "in_reply_to_status_id" : 453887816297381888,
  "created_at" : "2014-04-09 13:32:33 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453887244907331584",
  "text" : "so far by my count ratio of #iatefl mitra posts to graddol posts is 12:4",
  "id" : 453887244907331584,
  "created_at" : "2014-04-09 13:28:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 3, 10 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/odKaySWzEt",
      "expanded_url" : "http:\/\/ffeathers.wordpress.com\/2014\/04\/06\/login-or-log-in-a-way-to-choose-one-word-or-two\/",
      "display_url" : "ffeathers.wordpress.com\/2014\/04\/06\/log\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453872144112693248",
  "text" : "RT @WordLo: Login or log in \u2013 a way to choose one word or two | ffeathers http:\/\/t.co\/odKaySWzEt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/odKaySWzEt",
        "expanded_url" : "http:\/\/ffeathers.wordpress.com\/2014\/04\/06\/login-or-log-in-a-way-to-choose-one-word-or-two\/",
        "display_url" : "ffeathers.wordpress.com\/2014\/04\/06\/log\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453867751241560064",
    "text" : "Login or log in \u2013 a way to choose one word or two | ffeathers http:\/\/t.co\/odKaySWzEt",
    "id" : 453867751241560064,
    "created_at" : "2014-04-09 12:11:19 +0000",
    "user" : {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "protected" : false,
      "id_str" : "190569306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660652749881782272\/BB1P3zUR_normal.jpg",
      "id" : 190569306,
      "verified" : false
    }
  },
  "id" : 453872144112693248,
  "created_at" : "2014-04-09 12:28:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ifYcMQ1kAy",
      "expanded_url" : "http:\/\/larryferlazzo.edublogs.org\/2013\/06\/16\/a-response-to-my-questions-about-sugata-mitra\/comment-page-1\/#comment-46952",
      "display_url" : "larryferlazzo.edublogs.org\/2013\/06\/16\/a-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453865503283765248",
  "text" : "\"...but Mitra succeeds in turning it into the pedagogical equivalent of a bumper sticker. How can we not get angry?\" http:\/\/t.co\/ifYcMQ1kAy",
  "id" : 453865503283765248,
  "created_at" : "2014-04-09 12:02:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 3, 15 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 24, 31 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 53, 64 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7QCN4yIrCa",
      "expanded_url" : "http:\/\/www.eltjam.com\/why-we-should-be-afraid-of-the-big-bad-wolf-sugata-mitra-and-the-neoliberal-takeover-in-sheeps-clothing\/",
      "display_url" : "eltjam.com\/why-we-should-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453862456209981440",
  "text" : "RT @nmkrobinson: New on @eltjam from our good friend @hughdellar: Sugata Mitra and the neoliberal takeover in sheep's clothing: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELTjam",
        "screen_name" : "eltjam",
        "indices" : [ 7, 14 ],
        "id_str" : "1356363686",
        "id" : 1356363686
      }, {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 36, 47 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/7QCN4yIrCa",
        "expanded_url" : "http:\/\/www.eltjam.com\/why-we-should-be-afraid-of-the-big-bad-wolf-sugata-mitra-and-the-neoliberal-takeover-in-sheeps-clothing\/",
        "display_url" : "eltjam.com\/why-we-should-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453847027344891904",
    "text" : "New on @eltjam from our good friend @hughdellar: Sugata Mitra and the neoliberal takeover in sheep's clothing: http:\/\/t.co\/7QCN4yIrCa",
    "id" : 453847027344891904,
    "created_at" : "2014-04-09 10:48:58 +0000",
    "user" : {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "protected" : false,
      "id_str" : "20425399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706797940669599744\/6lTpszWm_normal.jpg",
      "id" : 20425399,
      "verified" : false
    }
  },
  "id" : 453862456209981440,
  "created_at" : "2014-04-09 11:50:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry cuban",
      "screen_name" : "CubanLarry",
      "indices" : [ 106, 117 ],
      "id_str" : "2324494104",
      "id" : 2324494104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/quEMaqfxgP",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-27d",
      "display_url" : "wp.me\/pBm7c-27d"
    } ]
  },
  "geo" : { },
  "id_str" : "453827720573493248",
  "text" : "What's The Evidence on School Devices and Software Improving Student Learning? http:\/\/t.co\/quEMaqfxgP via @CubanLarry",
  "id" : 453827720573493248,
  "created_at" : "2014-04-09 09:32:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453663353010130945",
  "text" : "some talk about balance in mitra debate but as zinn said u can't be neutral on a moving train",
  "id" : 453663353010130945,
  "created_at" : "2014-04-08 22:39:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/K0MZt5bFVc",
      "expanded_url" : "http:\/\/www.eltplustech.com\/2014\/04\/iatefl-2014-roundup-predictions.html",
      "display_url" : "eltplustech.com\/2014\/04\/iatefl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453656480366215168",
  "text" : "RT @jo_sayers: My #IATEFL roundup and predictions for the year ahead http:\/\/t.co\/K0MZt5bFVc #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 3, 10 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 77, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/K0MZt5bFVc",
        "expanded_url" : "http:\/\/www.eltplustech.com\/2014\/04\/iatefl-2014-roundup-predictions.html",
        "display_url" : "eltplustech.com\/2014\/04\/iatefl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453653285174390784",
    "text" : "My #IATEFL roundup and predictions for the year ahead http:\/\/t.co\/K0MZt5bFVc #eltchat",
    "id" : 453653285174390784,
    "created_at" : "2014-04-08 21:59:06 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 453656480366215168,
  "created_at" : "2014-04-08 22:11:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/2Jvzl5mdHc",
      "expanded_url" : "http:\/\/wp.me\/p3J3ai-1t0",
      "display_url" : "wp.me\/p3J3ai-1t0"
    } ]
  },
  "geo" : { },
  "id_str" : "453655494146547713",
  "text" : "How to add a brain to your smart phone http:\/\/t.co\/2Jvzl5mdHc via @wordpressdotcom",
  "id" : 453655494146547713,
  "created_at" : "2014-04-08 22:07:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 3, 12 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/viGlmpv8i0",
      "expanded_url" : "http:\/\/bit.ly\/1srg4ZQ",
      "display_url" : "bit.ly\/1srg4ZQ"
    } ]
  },
  "geo" : { },
  "id_str" : "453649974450864129",
  "text" : "RT @Marisa_C: Reminders abt tomorrow #ELTchat back on track with a topic from IATEFL Harrogate - watch - read - come and talk http:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/viGlmpv8i0",
        "expanded_url" : "http:\/\/bit.ly\/1srg4ZQ",
        "display_url" : "bit.ly\/1srg4ZQ"
      } ]
    },
    "geo" : { },
    "id_str" : "453647499018792962",
    "text" : "Reminders abt tomorrow #ELTchat back on track with a topic from IATEFL Harrogate - watch - read - come and talk http:\/\/t.co\/viGlmpv8i0",
    "id" : 453647499018792962,
    "created_at" : "2014-04-08 21:36:06 +0000",
    "user" : {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "protected" : false,
      "id_str" : "18272500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551128180497457153\/DRrY3cNw_normal.jpeg",
      "id" : 18272500,
      "verified" : false
    }
  },
  "id" : 453649974450864129,
  "created_at" : "2014-04-08 21:45:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453647499018792962",
  "geo" : { },
  "id_str" : "453649478868692992",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C given topic and twitter format expect tears? :\/",
  "id" : 453649478868692992,
  "in_reply_to_status_id" : 453647499018792962,
  "created_at" : "2014-04-08 21:43:58 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 0, 14 ],
      "id_str" : "118014141",
      "id" : 118014141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DFLuBvMVcE",
      "expanded_url" : "http:\/\/procommotion.wordpress.com\/2012\/12\/16\/moocs-as-geopolitical-weapons\/",
      "display_url" : "procommotion.wordpress.com\/2012\/12\/16\/moo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453621585371738112",
  "geo" : { },
  "id_str" : "453625916909178880",
  "in_reply_to_user_id" : 118014141,
  "text" : "@alexanderding indeed - We are here to bring the American ways of thinking to the people...http:\/\/t.co\/DFLuBvMVcE",
  "id" : 453625916909178880,
  "in_reply_to_status_id" : 453621585371738112,
  "created_at" : "2014-04-08 20:10:21 +0000",
  "in_reply_to_screen_name" : "alexanderding",
  "in_reply_to_user_id_str" : "118014141",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JYPEFyjYOE",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-04-08\/seymour-hersh-and-the-spineless-nay-sayers\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-04-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453622330380390400",
  "text" : "RT @johnwhilley: More vital defence of real journalism from Jonathan Cook: Seymour Hersh and the spineless nay-sayers http:\/\/t.co\/JYPEFyjYOE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/JYPEFyjYOE",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-04-08\/seymour-hersh-and-the-spineless-nay-sayers\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-04-0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453559392471113728",
    "text" : "More vital defence of real journalism from Jonathan Cook: Seymour Hersh and the spineless nay-sayers http:\/\/t.co\/JYPEFyjYOE",
    "id" : 453559392471113728,
    "created_at" : "2014-04-08 15:46:00 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 453622330380390400,
  "created_at" : "2014-04-08 19:56:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Allington",
      "screen_name" : "dr_d_allington",
      "indices" : [ 3, 18 ],
      "id_str" : "1287008022",
      "id" : 1287008022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/mlGHA4wpHS",
      "expanded_url" : "http:\/\/gu.com\/p\/3z92f\/tw",
      "display_url" : "gu.com\/p\/3z92f\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "453585218222702592",
  "text" : "RT @dr_d_allington: Australian National Health &amp; Medical Research Council concludes 'no reliable evidence that homeopathy is effective' htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/mlGHA4wpHS",
        "expanded_url" : "http:\/\/gu.com\/p\/3z92f\/tw",
        "display_url" : "gu.com\/p\/3z92f\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "453580237788299264",
    "text" : "Australian National Health &amp; Medical Research Council concludes 'no reliable evidence that homeopathy is effective' http:\/\/t.co\/mlGHA4wpHS",
    "id" : 453580237788299264,
    "created_at" : "2014-04-08 17:08:50 +0000",
    "user" : {
      "name" : "Daniel Allington",
      "screen_name" : "dr_d_allington",
      "protected" : false,
      "id_str" : "1287008022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490077921202032640\/t4J01KCX_normal.jpeg",
      "id" : 1287008022,
      "verified" : false
    }
  },
  "id" : 453585218222702592,
  "created_at" : "2014-04-08 17:28:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 19, 32 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453531331142877184",
  "text" : "RT @audreywatters: @tressiemcphd so much \"white savior\" narrative in MOOC talk. so much about model minorities in Sal Khan. etc.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tressie Mc",
        "screen_name" : "tressiemcphd",
        "indices" : [ 0, 13 ],
        "id_str" : "148593548",
        "id" : 148593548
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "453368322818842624",
    "geo" : { },
    "id_str" : "453368829070958592",
    "in_reply_to_user_id" : 148593548,
    "text" : "@tressiemcphd so much \"white savior\" narrative in MOOC talk. so much about model minorities in Sal Khan. etc.",
    "id" : 453368829070958592,
    "in_reply_to_status_id" : 453368322818842624,
    "created_at" : "2014-04-08 03:08:46 +0000",
    "in_reply_to_screen_name" : "tressiemcphd",
    "in_reply_to_user_id_str" : "148593548",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 453531331142877184,
  "created_at" : "2014-04-08 13:54:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/p8Ey4t5cto",
      "expanded_url" : "http:\/\/www.schoolleadership20.com\/forum\/topics\/effects-of-inequality-and-poverty-vs-teachers-and-schooling-on-am",
      "display_url" : "schoolleadership20.com\/forum\/topics\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453500742398410753",
  "text" : "Effects of Inequality and Poverty vs. Teachers and Schooling on America\u2019s Youth by David C. Berliner http:\/\/t.co\/p8Ey4t5cto",
  "id" : 453500742398410753,
  "created_at" : "2014-04-08 11:52:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/AxLVOB37Ol",
      "expanded_url" : "http:\/\/tabula.nerdpower.org\/",
      "display_url" : "tabula.nerdpower.org"
    } ]
  },
  "geo" : { },
  "id_str" : "453496203897217024",
  "text" : "RT @flowingdata: Extract CSV data from PDF files with Tabula. Makes it super simple http:\/\/t.co\/AxLVOB37Ol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/flowingdata.com\" rel=\"nofollow\"\u003EFlowingData\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/AxLVOB37Ol",
        "expanded_url" : "http:\/\/tabula.nerdpower.org\/",
        "display_url" : "tabula.nerdpower.org"
      } ]
    },
    "geo" : { },
    "id_str" : "453476782704840704",
    "text" : "Extract CSV data from PDF files with Tabula. Makes it super simple http:\/\/t.co\/AxLVOB37Ol",
    "id" : 453476782704840704,
    "created_at" : "2014-04-08 10:17:44 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 453496203897217024,
  "created_at" : "2014-04-08 11:34:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 3, 12 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/4Uqahjzyfh",
      "expanded_url" : "http:\/\/wp.me\/p1kzD1-Va",
      "display_url" : "wp.me\/p1kzD1-Va"
    } ]
  },
  "geo" : { },
  "id_str" : "453485469062676480",
  "text" : "RT @teflgeek: #IATEFL 2014: The Sugata Mitra\u00A0Debate http:\/\/t.co\/4Uqahjzyfh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/4Uqahjzyfh",
        "expanded_url" : "http:\/\/wp.me\/p1kzD1-Va",
        "display_url" : "wp.me\/p1kzD1-Va"
      } ]
    },
    "geo" : { },
    "id_str" : "453477438048067584",
    "text" : "#IATEFL 2014: The Sugata Mitra\u00A0Debate http:\/\/t.co\/4Uqahjzyfh",
    "id" : 453477438048067584,
    "created_at" : "2014-04-08 10:20:21 +0000",
    "user" : {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "protected" : false,
      "id_str" : "305260555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431754836795613184\/0uiw9Mhs_normal.jpeg",
      "id" : 305260555,
      "verified" : false
    }
  },
  "id" : 453485469062676480,
  "created_at" : "2014-04-08 10:52:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453452475631009792",
  "geo" : { },
  "id_str" : "453452928544940032",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow wha u mean that's not how its done? ek!",
  "id" : 453452928544940032,
  "in_reply_to_status_id" : 453452475631009792,
  "created_at" : "2014-04-08 08:42:57 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453424002136940544",
  "geo" : { },
  "id_str" : "453425209174159360",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith there does seem to be a lot of noise and not much signal...",
  "id" : 453425209174159360,
  "in_reply_to_status_id" : 453424002136940544,
  "created_at" : "2014-04-08 06:52:48 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 72, 80 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/WfHYJbRBYH",
      "expanded_url" : "http:\/\/fourc.ca\/4cwebinar1\/",
      "display_url" : "fourc.ca\/4cwebinar1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "453397038034853888",
  "text" : "RT @seburnt: More online CPD is a good thing http:\/\/t.co\/WfHYJbRBYH via @seburnt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyson Seburn",
        "screen_name" : "seburnt",
        "indices" : [ 59, 67 ],
        "id_str" : "20650366",
        "id" : 20650366
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/WfHYJbRBYH",
        "expanded_url" : "http:\/\/fourc.ca\/4cwebinar1\/",
        "display_url" : "fourc.ca\/4cwebinar1\/"
      } ]
    },
    "geo" : { },
    "id_str" : "453389294585913344",
    "text" : "More online CPD is a good thing http:\/\/t.co\/WfHYJbRBYH via @seburnt",
    "id" : 453389294585913344,
    "created_at" : "2014-04-08 04:30:06 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 453397038034853888,
  "created_at" : "2014-04-08 05:00:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 9, 17 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453297478272831488",
  "geo" : { },
  "id_str" : "453297795873910784",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @cgoodey hehe u never know!",
  "id" : 453297795873910784,
  "in_reply_to_status_id" : 453297478272831488,
  "created_at" : "2014-04-07 22:26:31 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453297341496578048",
  "text" : "Alan Kay - Any problem the schools cannot solve without computers, they cannot solve with them",
  "id" : 453297341496578048,
  "created_at" : "2014-04-07 22:24:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 9, 17 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/byGSDdLUe4",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nDjdJCbteKA",
      "display_url" : "youtube.com\/watch?v=nDjdJC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453295058029412352",
  "geo" : { },
  "id_str" : "453296644357115904",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @cgoodey sorry to but in u may find this vid on #corpusmooc reactions useful or not https:\/\/t.co\/byGSDdLUe4 37mins",
  "id" : 453296644357115904,
  "in_reply_to_status_id" : 453295058029412352,
  "created_at" : "2014-04-07 22:21:56 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/FEDIgk84GE",
      "expanded_url" : "http:\/\/youtu.be\/GslzLHrve2M",
      "display_url" : "youtu.be\/GslzLHrve2M"
    } ]
  },
  "geo" : { },
  "id_str" : "453294291679330304",
  "text" : "Neil Postman on what is lacking in schools.: http:\/\/t.co\/FEDIgk84GE via @YouTube",
  "id" : 453294291679330304,
  "created_at" : "2014-04-07 22:12:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 11, 25 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 71, 84 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453268920624246785",
  "geo" : { },
  "id_str" : "453271298991738881",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @NicolaPrentis true though does have stiff competition from @sbrowntweets",
  "id" : 453271298991738881,
  "in_reply_to_status_id" : 453268920624246785,
  "created_at" : "2014-04-07 20:41:13 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/iN3HGNMJVS",
      "expanded_url" : "http:\/\/boomy.so\/ue_n3o3ry",
      "display_url" : "boomy.so\/ue_n3o3ry"
    } ]
  },
  "in_reply_to_status_id_str" : "453268675479764992",
  "geo" : { },
  "id_str" : "453270294514659329",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis eltcelebs deserve celeb music - http:\/\/t.co\/iN3HGNMJVS :)",
  "id" : 453270294514659329,
  "in_reply_to_status_id" : 453268675479764992,
  "created_at" : "2014-04-07 20:37:14 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/LcXgnmMQBI",
      "expanded_url" : "http:\/\/wp.me\/p1wlqw-bIVHN",
      "display_url" : "wp.me\/p1wlqw-bIVHN"
    } ]
  },
  "geo" : { },
  "id_str" : "453269691747016704",
  "text" : "RT @AnnLoseva: An ELT play of\u00A0sorts. http:\/\/t.co\/LcXgnmMQBI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/LcXgnmMQBI",
        "expanded_url" : "http:\/\/wp.me\/p1wlqw-bIVHN",
        "display_url" : "wp.me\/p1wlqw-bIVHN"
      } ]
    },
    "geo" : { },
    "id_str" : "453268169000378368",
    "text" : "An ELT play of\u00A0sorts. http:\/\/t.co\/LcXgnmMQBI",
    "id" : 453268169000378368,
    "created_at" : "2014-04-07 20:28:47 +0000",
    "user" : {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "protected" : false,
      "id_str" : "38822368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767034457748541441\/VJrp4Jie_normal.jpg",
      "id" : 38822368,
      "verified" : false
    }
  },
  "id" : 453269691747016704,
  "created_at" : "2014-04-07 20:34:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453221384857346048",
  "geo" : { },
  "id_str" : "453265485011120128",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle watch the graddol #iatefl vid!",
  "id" : 453265485011120128,
  "in_reply_to_status_id" : 453221384857346048,
  "created_at" : "2014-04-07 20:18:07 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453219445734129664",
  "geo" : { },
  "id_str" : "453221074155868160",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle yeah though that is explained more by the economic rationalisation drive that Graddol talks about",
  "id" : 453221074155868160,
  "in_reply_to_status_id" : 453219445734129664,
  "created_at" : "2014-04-07 17:21:39 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453213445069234176",
  "text" : "let's have more Graddol posts #iatefl peeps :)",
  "id" : 453213445069234176,
  "created_at" : "2014-04-07 16:51:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453211373175312384",
  "geo" : { },
  "id_str" : "453211535360679936",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug nooooooo! :)",
  "id" : 453211535360679936,
  "in_reply_to_status_id" : 453211373175312384,
  "created_at" : "2014-04-07 16:43:44 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453210405419376640",
  "geo" : { },
  "id_str" : "453210905892093952",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug thx for the reminder :)",
  "id" : 453210905892093952,
  "in_reply_to_status_id" : 453210405419376640,
  "created_at" : "2014-04-07 16:41:14 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerjelt",
      "indices" : [ 3, 14 ],
      "id_str" : "2382522692",
      "id" : 2382522692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/boIE0ezxX9",
      "expanded_url" : "http:\/\/jeremyharmer.wordpress.com\/2014\/04\/07\/angel-or-devil-the-strange-case-of-sugata-mitra\/",
      "display_url" : "jeremyharmer.wordpress.com\/2014\/04\/07\/ang\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453202165486878720",
  "text" : "RT @Harmerjelt: One last (?!) blog about Sugata Mitra. Angel or devil? What do you think? http:\/\/t.co\/boIE0ezxX9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/boIE0ezxX9",
        "expanded_url" : "http:\/\/jeremyharmer.wordpress.com\/2014\/04\/07\/angel-or-devil-the-strange-case-of-sugata-mitra\/",
        "display_url" : "jeremyharmer.wordpress.com\/2014\/04\/07\/ang\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453200330071998466",
    "text" : "One last (?!) blog about Sugata Mitra. Angel or devil? What do you think? http:\/\/t.co\/boIE0ezxX9",
    "id" : 453200330071998466,
    "created_at" : "2014-04-07 15:59:13 +0000",
    "user" : {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerjelt",
      "protected" : false,
      "id_str" : "2382522692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445276193625886720\/anAEX49t_normal.jpeg",
      "id" : 2382522692,
      "verified" : false
    }
  },
  "id" : 453202165486878720,
  "created_at" : "2014-04-07 16:06:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 80, 91 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/iN3HGNMJVS",
      "expanded_url" : "http:\/\/boomy.so\/ue_n3o3ry",
      "display_url" : "boomy.so\/ue_n3o3ry"
    } ]
  },
  "geo" : { },
  "id_str" : "453197821928538112",
  "text" : "could not resist, playing around w\/th boomy.so http:\/\/t.co\/iN3HGNMJVS apologies @hughdellar :)",
  "id" : 453197821928538112,
  "created_at" : "2014-04-07 15:49:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry M",
      "screen_name" : "tmannet",
      "indices" : [ 0, 8 ],
      "id_str" : "28612460",
      "id" : 28612460
    }, {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 9, 22 ],
      "id_str" : "702925903",
      "id" : 702925903
    }, {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 23, 36 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453144173709783040",
  "geo" : { },
  "id_str" : "453193904528306176",
  "in_reply_to_user_id" : 28612460,
  "text" : "@tmannet @WatchedPotts @WatchedPotts no fav unit wks 3, 5 &amp; 8 stick liked the discourse aspects, fav video difficult but prob mike scott",
  "id" : 453193904528306176,
  "in_reply_to_status_id" : 453144173709783040,
  "created_at" : "2014-04-07 15:33:41 +0000",
  "in_reply_to_screen_name" : "tmannet",
  "in_reply_to_user_id_str" : "28612460",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 6, 13 ],
      "id_str" : "116922669",
      "id" : 116922669
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 93, 99 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452967207124086784",
  "geo" : { },
  "id_str" : "453102608929259520",
  "in_reply_to_user_id" : 116922669,
  "text" : "yikes @mrkm_a that's wtf bingo - chaos theory, learning styles and multiple intelligences cc @ebefl",
  "id" : 453102608929259520,
  "in_reply_to_status_id" : 452967207124086784,
  "created_at" : "2014-04-07 09:30:54 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Whiteside",
      "screen_name" : "nutrich",
      "indices" : [ 0, 8 ],
      "id_str" : "95495064",
      "id" : 95495064
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 9, 18 ],
      "id_str" : "238993337",
      "id" : 238993337
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 19, 29 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 30, 41 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453102034318020608",
  "in_reply_to_user_id" : 95495064,
  "text" : "@nutrich @bealer81 @ElkySmith @kevchanwow thanks for share folks, what r your thoughts on this?",
  "id" : 453102034318020608,
  "created_at" : "2014-04-07 09:28:37 +0000",
  "in_reply_to_screen_name" : "nutrich",
  "in_reply_to_user_id_str" : "95495064",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richardjuckes",
      "screen_name" : "richardjuckes",
      "indices" : [ 0, 14 ],
      "id_str" : "18752640",
      "id" : 18752640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453020855095009280",
  "geo" : { },
  "id_str" : "453041445768007680",
  "in_reply_to_user_id" : 18752640,
  "text" : "@richardjuckes according to the paper looks like it",
  "id" : 453041445768007680,
  "in_reply_to_status_id" : 453020855095009280,
  "created_at" : "2014-04-07 05:27:52 +0000",
  "in_reply_to_screen_name" : "richardjuckes",
  "in_reply_to_user_id_str" : "18752640",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/iZE0zhoq6i",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-04-06\/seymour-hersh-unearths-more-lies-on-syria\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-04-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452957792266358785",
  "text" : "RT @johnwhilley: Jonathan Cook: Seymour Hersh unearths more lies on Syria http:\/\/t.co\/iZE0zhoq6i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/iZE0zhoq6i",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-04-06\/seymour-hersh-unearths-more-lies-on-syria\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-04-0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452955630664699904",
    "text" : "Jonathan Cook: Seymour Hersh unearths more lies on Syria http:\/\/t.co\/iZE0zhoq6i",
    "id" : 452955630664699904,
    "created_at" : "2014-04-06 23:46:52 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 452957792266358785,
  "created_at" : "2014-04-06 23:55:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Simpson",
      "screen_name" : "pevansimpson",
      "indices" : [ 0, 13 ],
      "id_str" : "230954247",
      "id" : 230954247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452925159158992896",
  "geo" : { },
  "id_str" : "452926177649651713",
  "in_reply_to_user_id" : 230954247,
  "text" : "@pevansimpson irony much :\/",
  "id" : 452926177649651713,
  "in_reply_to_status_id" : 452925159158992896,
  "created_at" : "2014-04-06 21:49:50 +0000",
  "in_reply_to_screen_name" : "pevansimpson",
  "in_reply_to_user_id_str" : "230954247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richardjuckes",
      "screen_name" : "richardjuckes",
      "indices" : [ 0, 14 ],
      "id_str" : "18752640",
      "id" : 18752640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/UQbgNghjht",
      "expanded_url" : "http:\/\/www.hole-in-the-wall.com\/docs\/paper13.pdf",
      "display_url" : "hole-in-the-wall.com\/docs\/paper13.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452382684149739520",
  "geo" : { },
  "id_str" : "452925657904062464",
  "in_reply_to_user_id" : 18752640,
  "text" : "@richardjuckes yes, if u look at that study experts actually chose biotech texts from net not the kids http:\/\/t.co\/UQbgNghjht",
  "id" : 452925657904062464,
  "in_reply_to_status_id" : 452382684149739520,
  "created_at" : "2014-04-06 21:47:46 +0000",
  "in_reply_to_screen_name" : "richardjuckes",
  "in_reply_to_user_id_str" : "18752640",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Municipales2014",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/WHmCf0k2k4",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452907553127940096",
  "text" : "&lt;&lt;Apprendre que sa prof d'anglais du lyc\u00E9e a \u00E9t\u00E9 \u00E9lue Maire, c'est pas commun #Municipales2014&gt;&gt; http:\/\/t.co\/WHmCf0k2k4",
  "id" : 452907553127940096,
  "created_at" : "2014-04-06 20:35:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 3, 14 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 86, 97 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/FjcanlUGxL",
      "expanded_url" : "http:\/\/youtu.be\/755gblfOjks",
      "display_url" : "youtu.be\/755gblfOjks"
    } ]
  },
  "geo" : { },
  "id_str" : "452903438251462657",
  "text" : "RT @elawassell: \"As teachers, we know we have the best job in the world.\" Hugh Dellar @hughdellar's talk at #iatefl 2014 http:\/\/t.co\/Fjcanl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 70, 81 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/FjcanlUGxL",
        "expanded_url" : "http:\/\/youtu.be\/755gblfOjks",
        "display_url" : "youtu.be\/755gblfOjks"
      } ]
    },
    "geo" : { },
    "id_str" : "452901742968328192",
    "text" : "\"As teachers, we know we have the best job in the world.\" Hugh Dellar @hughdellar's talk at #iatefl 2014 http:\/\/t.co\/FjcanlUGxL",
    "id" : 452901742968328192,
    "created_at" : "2014-04-06 20:12:44 +0000",
    "user" : {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "protected" : false,
      "id_str" : "51157050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1879392732\/11elwas_normal.jpg",
      "id" : 51157050,
      "verified" : false
    }
  },
  "id" : 452903438251462657,
  "created_at" : "2014-04-06 20:19:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/5air6Xoogd",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/03\/23\/business\/international\/some-french-entrepreneurs-say-au-revoir.html?_r=0",
      "display_url" : "nytimes.com\/2014\/03\/23\/bus\u2026"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/gXaJW0Cqhx",
      "expanded_url" : "http:\/\/idibon.com\/entrepreneurs-french-spanish-english\/",
      "display_url" : "idibon.com\/entrepreneurs-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452876371274911744",
  "geo" : { },
  "id_str" : "452877600139268096",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble hi anne did u read this? http:\/\/t.co\/5air6Xoogd \nand have a read of this after http:\/\/t.co\/gXaJW0Cqhx",
  "id" : 452877600139268096,
  "in_reply_to_status_id" : 452876371274911744,
  "created_at" : "2014-04-06 18:36:48 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 76, 92 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PQBOrOuYCN",
      "expanded_url" : "http:\/\/wp.me\/p4gDtp-1j",
      "display_url" : "wp.me\/p4gDtp-1j"
    } ]
  },
  "geo" : { },
  "id_str" : "452870227177390080",
  "text" : "EdTech and neo-liberalism: fragment of a network http:\/\/t.co\/PQBOrOuYCN via @wordpressdotcom",
  "id" : 452870227177390080,
  "created_at" : "2014-04-06 18:07:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john",
      "screen_name" : "johncmulligan",
      "indices" : [ 3, 17 ],
      "id_str" : "2283919177",
      "id" : 2283919177
    }, {
      "name" : "Brown Daily Herald",
      "screen_name" : "the_herald",
      "indices" : [ 111, 122 ],
      "id_str" : "25581369",
      "id" : 25581369
    }, {
      "name" : "Brown GSC",
      "screen_name" : "browngsc",
      "indices" : [ 123, 132 ],
      "id_str" : "195949141",
      "id" : 195949141
    }, {
      "name" : "Brown UCS",
      "screen_name" : "BrownUCS",
      "indices" : [ 133, 140 ],
      "id_str" : "24831707",
      "id" : 24831707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/HvWBjfr8jT",
      "expanded_url" : "http:\/\/blogs.edweek.org\/edweek\/DigitalEducation\/2014\/04\/google_amends_its_terms_on_sca.html",
      "display_url" : "blogs.edweek.org\/edweek\/Digital\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452841113481908224",
  "text" : "RT @johncmulligan: Do we have a clear idea of how Google is using our campus mail data? http:\/\/t.co\/HvWBjfr8jT @the_herald @browngsc @Brown\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brown Daily Herald",
        "screen_name" : "the_herald",
        "indices" : [ 92, 103 ],
        "id_str" : "25581369",
        "id" : 25581369
      }, {
        "name" : "Brown GSC",
        "screen_name" : "browngsc",
        "indices" : [ 104, 113 ],
        "id_str" : "195949141",
        "id" : 195949141
      }, {
        "name" : "Brown UCS",
        "screen_name" : "BrownUCS",
        "indices" : [ 114, 123 ],
        "id_str" : "24831707",
        "id" : 24831707
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/HvWBjfr8jT",
        "expanded_url" : "http:\/\/blogs.edweek.org\/edweek\/DigitalEducation\/2014\/04\/google_amends_its_terms_on_sca.html",
        "display_url" : "blogs.edweek.org\/edweek\/Digital\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452840882048602112",
    "text" : "Do we have a clear idea of how Google is using our campus mail data? http:\/\/t.co\/HvWBjfr8jT @the_herald @browngsc @BrownUCS",
    "id" : 452840882048602112,
    "created_at" : "2014-04-06 16:10:54 +0000",
    "user" : {
      "name" : "john",
      "screen_name" : "johncmulligan",
      "protected" : false,
      "id_str" : "2283919177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421339740638441472\/TbBBUz_r_normal.jpeg",
      "id" : 2283919177,
      "verified" : false
    }
  },
  "id" : 452841113481908224,
  "created_at" : "2014-04-06 16:11:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 11, 19 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 20, 33 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gjPjGhKCzF",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2013\/sugata-mitra-knowing-is-obsolete\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2013\/sugata-mi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452795345471541248",
  "geo" : { },
  "id_str" : "452797129879486465",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @Ven_VVE @ZhenyaDnipro it is just not the practical implication his ideology of edu  people object to e.g. http:\/\/t.co\/gjPjGhKCzF",
  "id" : 452797129879486465,
  "in_reply_to_status_id" : 452795345471541248,
  "created_at" : "2014-04-06 13:17:03 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/cbjD85Gqyg",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/04\/06\/iatefl-harrogate-2014-mitra-having-a-jelly-good-time\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/04\/06\/iat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452582699719729152",
  "geo" : { },
  "id_str" : "452789698898165760",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K hi, my response http:\/\/t.co\/cbjD85Gqyg",
  "id" : 452789698898165760,
  "in_reply_to_status_id" : 452582699719729152,
  "created_at" : "2014-04-06 12:47:31 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 3, 12 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/A2jPzfy4r1",
      "expanded_url" : "http:\/\/bit.ly\/1jikkGf",
      "display_url" : "bit.ly\/1jikkGf"
    } ]
  },
  "geo" : { },
  "id_str" : "452789149591175168",
  "text" : "RT @Wiktor_K: How Sugata Mitra Annoyed English Teachers at #IATEFL http:\/\/t.co\/A2jPzfy4r1 - questions &amp; guts make you EVIL in education. Wh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/A2jPzfy4r1",
        "expanded_url" : "http:\/\/bit.ly\/1jikkGf",
        "display_url" : "bit.ly\/1jikkGf"
      } ]
    },
    "geo" : { },
    "id_str" : "452582699719729152",
    "text" : "How Sugata Mitra Annoyed English Teachers at #IATEFL http:\/\/t.co\/A2jPzfy4r1 - questions &amp; guts make you EVIL in education. Who knew?",
    "id" : 452582699719729152,
    "created_at" : "2014-04-05 23:04:58 +0000",
    "user" : {
      "name" : "BRAVE Learning",
      "screen_name" : "BRAVE_Learning",
      "protected" : false,
      "id_str" : "222498082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714724460461473792\/_xHUkSmB_normal.jpg",
      "id" : 222498082,
      "verified" : false
    }
  },
  "id" : 452789149591175168,
  "created_at" : "2014-04-06 12:45:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 11, 23 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452788968288174080",
  "text" : "@_FTaylor_ @nathanghall thumbs up agree with florentina, very good idea :)",
  "id" : 452788968288174080,
  "created_at" : "2014-04-06 12:44:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL2014",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/v6M4z42xjT",
      "expanded_url" : "http:\/\/tinyurl.com\/pwvlfgg",
      "display_url" : "tinyurl.com\/pwvlfgg"
    } ]
  },
  "geo" : { },
  "id_str" : "452788570617810944",
  "text" : "RT @HancockMcDonald: #IATEFL2014: The ELT World in Four Plenaries http:\/\/t.co\/v6M4z42xjT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL2014",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/v6M4z42xjT",
        "expanded_url" : "http:\/\/tinyurl.com\/pwvlfgg",
        "display_url" : "tinyurl.com\/pwvlfgg"
      } ]
    },
    "geo" : { },
    "id_str" : "452727350417817600",
    "text" : "#IATEFL2014: The ELT World in Four Plenaries http:\/\/t.co\/v6M4z42xjT",
    "id" : 452727350417817600,
    "created_at" : "2014-04-06 08:39:46 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 452788570617810944,
  "created_at" : "2014-04-06 12:43:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miracel Juanta",
      "screen_name" : "msjuanta",
      "indices" : [ 0, 9 ],
      "id_str" : "23180284",
      "id" : 23180284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452785472587063297",
  "in_reply_to_user_id" : 23180284,
  "text" : "@msjuanta thanks for share, what do  u think of mitra's message?",
  "id" : 452785472587063297,
  "created_at" : "2014-04-06 12:30:43 +0000",
  "in_reply_to_screen_name" : "msjuanta",
  "in_reply_to_user_id_str" : "23180284",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nobody",
      "screen_name" : "oliverselya",
      "indices" : [ 0, 12 ],
      "id_str" : "925894784",
      "id" : 925894784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452774348554645504",
  "geo" : { },
  "id_str" : "452785250557779968",
  "in_reply_to_user_id" : 925894784,
  "text" : "@oliverselya thanks for share :)",
  "id" : 452785250557779968,
  "in_reply_to_status_id" : 452774348554645504,
  "created_at" : "2014-04-06 12:29:50 +0000",
  "in_reply_to_screen_name" : "oliverselya",
  "in_reply_to_user_id_str" : "925894784",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 14, 23 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452711953098887168",
  "geo" : { },
  "id_str" : "452785144940990464",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @vmorgana thanks for share valentina, did u get a chance to see mitra video laura?",
  "id" : 452785144940990464,
  "in_reply_to_status_id" : 452711953098887168,
  "created_at" : "2014-04-06 12:29:25 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "indices" : [ 3, 19 ],
      "id_str" : "91870534",
      "id" : 91870534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Rd5SiY6T9G",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qJ8RA3QF0EU&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=qJ8RA3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452622693851217920",
  "text" : "RT @MichaelRosenYes: Jess Green, poet, talks to Mr Gove with passion and anger: https:\/\/t.co\/Rd5SiY6T9G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/Rd5SiY6T9G",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qJ8RA3QF0EU&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=qJ8RA3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452332315344384000",
    "text" : "Jess Green, poet, talks to Mr Gove with passion and anger: https:\/\/t.co\/Rd5SiY6T9G",
    "id" : 452332315344384000,
    "created_at" : "2014-04-05 06:30:02 +0000",
    "user" : {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "protected" : false,
      "id_str" : "91870534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488029217104207874\/F0pxhrFu_normal.jpeg",
      "id" : 91870534,
      "verified" : false
    }
  },
  "id" : 452622693851217920,
  "created_at" : "2014-04-06 01:43:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Y6bat2dWOH",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Mn",
      "display_url" : "wp.me\/pgHyE-Mn"
    } ]
  },
  "geo" : { },
  "id_str" : "452608218850918400",
  "text" : "#IATEFL Harrogate 2014: Mitra having a jelly good time http:\/\/t.co\/Y6bat2dWOH",
  "id" : 452608218850918400,
  "created_at" : "2014-04-06 00:46:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 14, 27 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452502008181039104",
  "geo" : { },
  "id_str" : "452538954026582016",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike @sbrowntweets hehe what a post genius!",
  "id" : 452538954026582016,
  "in_reply_to_status_id" : 452502008181039104,
  "created_at" : "2014-04-05 20:11:09 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/onr0NYvwnh",
      "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2014\/04\/05\/never-mind-the-boocks-heres-the-tefl-skeptic\/",
      "display_url" : "stevebrown70.wordpress.com\/2014\/04\/05\/nev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452538744957337600",
  "text" : "RT @sbrowntweets: My initial reflections on #IATEFL in this blog post: http:\/\/t.co\/onr0NYvwnh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 26, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/onr0NYvwnh",
        "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2014\/04\/05\/never-mind-the-boocks-heres-the-tefl-skeptic\/",
        "display_url" : "stevebrown70.wordpress.com\/2014\/04\/05\/nev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452493127245627392",
    "text" : "My initial reflections on #IATEFL in this blog post: http:\/\/t.co\/onr0NYvwnh",
    "id" : 452493127245627392,
    "created_at" : "2014-04-05 17:09:03 +0000",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 452538744957337600,
  "created_at" : "2014-04-05 20:10:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Scott",
      "screen_name" : "teachAdam",
      "indices" : [ 3, 13 ],
      "id_str" : "284617563",
      "id" : 284617563
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl2014",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "esl",
      "indices" : [ 41, 45 ]
    }, {
      "text" : "beginners",
      "indices" : [ 46, 56 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 63, 81 ]
    }, {
      "text" : "lexicalapproach",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/rMJSJVmwxv",
      "expanded_url" : "http:\/\/goo.gl\/O52b2d",
      "display_url" : "goo.gl\/O52b2d"
    } ]
  },
  "geo" : { },
  "id_str" : "452474955687788544",
  "text" : "RT @teachAdam: #iatefl2014 talk Teaching #esl #beginners using #corpuslinguistics in a #lexicalapproach slides download here http:\/\/t.co\/rM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl2014",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "esl",
        "indices" : [ 26, 30 ]
      }, {
        "text" : "beginners",
        "indices" : [ 31, 41 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 48, 66 ]
      }, {
        "text" : "lexicalapproach",
        "indices" : [ 72, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/rMJSJVmwxv",
        "expanded_url" : "http:\/\/goo.gl\/O52b2d",
        "display_url" : "goo.gl\/O52b2d"
      } ]
    },
    "geo" : { },
    "id_str" : "452473272211603456",
    "text" : "#iatefl2014 talk Teaching #esl #beginners using #corpuslinguistics in a #lexicalapproach slides download here http:\/\/t.co\/rMJSJVmwxv :)",
    "id" : 452473272211603456,
    "created_at" : "2014-04-05 15:50:09 +0000",
    "user" : {
      "name" : "Adam Scott",
      "screen_name" : "teachAdam",
      "protected" : false,
      "id_str" : "284617563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435763086642151424\/fMaWgo24_normal.jpeg",
      "id" : 284617563,
      "verified" : false
    }
  },
  "id" : 452474955687788544,
  "created_at" : "2014-04-05 15:56:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CamillaMariannaBaran",
      "screen_name" : "baran_camilla",
      "indices" : [ 28, 42 ],
      "id_str" : "2365687700",
      "id" : 2365687700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/7GqRUoWpd3",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mithraic_Mysteries",
      "display_url" : "en.wikipedia.org\/wiki\/Mithraic_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452438249370570752",
  "geo" : { },
  "id_str" : "452443791199576064",
  "in_reply_to_user_id" : 2365687700,
  "text" : "hi thanks thats interesting @baran_camilla e.g. http:\/\/t.co\/7GqRUoWpd3",
  "id" : 452443791199576064,
  "in_reply_to_status_id" : 452438249370570752,
  "created_at" : "2014-04-05 13:53:00 +0000",
  "in_reply_to_screen_name" : "baran_camilla",
  "in_reply_to_user_id_str" : "2365687700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/OmLdz2RCR4",
      "expanded_url" : "http:\/\/bit.ly\/Khqc5d",
      "display_url" : "bit.ly\/Khqc5d"
    } ]
  },
  "geo" : { },
  "id_str" : "452436339930435584",
  "text" : "RT @heatherfro: \"white, technical, American men have finally become targets of the surveillant gaze\" http:\/\/t.co\/OmLdz2RCR4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/OmLdz2RCR4",
        "expanded_url" : "http:\/\/bit.ly\/Khqc5d",
        "display_url" : "bit.ly\/Khqc5d"
      } ]
    },
    "geo" : { },
    "id_str" : "452415718814801920",
    "text" : "\"white, technical, American men have finally become targets of the surveillant gaze\" http:\/\/t.co\/OmLdz2RCR4",
    "id" : 452415718814801920,
    "created_at" : "2014-04-05 12:01:27 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 452436339930435584,
  "created_at" : "2014-04-05 13:23:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/UQbgNghjht",
      "expanded_url" : "http:\/\/www.hole-in-the-wall.com\/docs\/paper13.pdf",
      "display_url" : "hole-in-the-wall.com\/docs\/paper13.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452405286662578176",
  "geo" : { },
  "id_str" : "452410063135973376",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson sticking to research, internet resources in biotech study chosen by experts not children &gt; http:\/\/t.co\/UQbgNghjht",
  "id" : 452410063135973376,
  "in_reply_to_status_id" : 452405286662578176,
  "created_at" : "2014-04-05 11:38:59 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452403964223700992",
  "text" : "#iatefl mitra the wonder of soles like the wonder of the invisiblehand of the market, dont ask how just be awed",
  "id" : 452403964223700992,
  "created_at" : "2014-04-05 11:14:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452378411940720641",
  "text" : "RT @hughdellar: #iatefl Sugata Mitra's seductive narrative a surefire smash in age of austerity when governments are keen to find principle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452362019929608192",
    "text" : "#iatefl Sugata Mitra's seductive narrative a surefire smash in age of austerity when governments are keen to find principles for cut budgets",
    "id" : 452362019929608192,
    "created_at" : "2014-04-05 08:28:04 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 452378411940720641,
  "created_at" : "2014-04-05 09:33:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452376365825015808",
  "text" : "#iatefl mitra likes retired teachers - granny cloud, just not working teachers",
  "id" : 452376365825015808,
  "created_at" : "2014-04-05 09:25:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 12, 27 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452373457402347520",
  "geo" : { },
  "id_str" : "452374887085400065",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @_divyamadhavan did not hear any boos on livefeed",
  "id" : 452374887085400065,
  "in_reply_to_status_id" : 452373457402347520,
  "created_at" : "2014-04-05 09:19:12 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452374798321328128",
  "text" : "RT @hughdellar: I honestly don't think I've ever felt angrier about a talk I've seen at #iatefl than I am now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452373457402347520",
    "text" : "I honestly don't think I've ever felt angrier about a talk I've seen at #iatefl than I am now.",
    "id" : 452373457402347520,
    "created_at" : "2014-04-05 09:13:31 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 452374798321328128,
  "created_at" : "2014-04-05 09:18:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 93, 105 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/0togs8XRTK",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-6SY",
      "display_url" : "wp.me\/p1U04a-6SY"
    } ]
  },
  "geo" : { },
  "id_str" : "452373987431940096",
  "text" : "Head of failing schools employed as schools inspector for Ofsted: http:\/\/t.co\/0togs8XRTK via @ThomasPride",
  "id" : 452373987431940096,
  "created_at" : "2014-04-05 09:15:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Scott",
      "screen_name" : "teachAdam",
      "indices" : [ 0, 10 ],
      "id_str" : "284617563",
      "id" : 284617563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452372536043765760",
  "geo" : { },
  "id_str" : "452372783000199168",
  "in_reply_to_user_id" : 284617563,
  "text" : "@teachAdam cheering on their own doom...",
  "id" : 452372783000199168,
  "in_reply_to_status_id" : 452372536043765760,
  "created_at" : "2014-04-05 09:10:50 +0000",
  "in_reply_to_screen_name" : "teachAdam",
  "in_reply_to_user_id_str" : "284617563",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 12, 27 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 28, 44 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452370923216457728",
  "geo" : { },
  "id_str" : "452371481700626432",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @_divyamadhavan @theteacherjames one thing he has big balls to say at a tchers conf",
  "id" : 452371481700626432,
  "in_reply_to_status_id" : 452370923216457728,
  "created_at" : "2014-04-05 09:05:40 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452365284427718656",
  "geo" : { },
  "id_str" : "452369687608057856",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames amazing it's like being a hypnotic trance :\/ amazed he is not being booed off stage considering the edu situ in UK",
  "id" : 452369687608057856,
  "in_reply_to_status_id" : 452365284427718656,
  "created_at" : "2014-04-05 08:58:32 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samira Chaibeddra",
      "screen_name" : "SChaibeddra",
      "indices" : [ 0, 12 ],
      "id_str" : "989087534",
      "id" : 989087534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452135271099039744",
  "geo" : { },
  "id_str" : "452146939422081024",
  "in_reply_to_user_id" : 989087534,
  "text" : "@SChaibeddra hi no i didn't, luckily much thanks to #iatefl for all the grt online vids :)",
  "id" : 452146939422081024,
  "in_reply_to_status_id" : 452135271099039744,
  "created_at" : "2014-04-04 18:13:25 +0000",
  "in_reply_to_screen_name" : "SChaibeddra",
  "in_reply_to_user_id_str" : "989087534",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 35, 41 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 71, 87 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTRisingStar",
      "indices" : [ 88, 102 ]
    }, {
      "text" : "ELTinterviews",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/KMzuBYgsax",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-uF",
      "display_url" : "wp.me\/p25Kfd-uF"
    } ]
  },
  "geo" : { },
  "id_str" : "452146624769560576",
  "text" : "RT @AnneHendler: An Interview with @EBEFL!  http:\/\/t.co\/KMzuBYgsax via @michaelegriffin #ELTRisingStar #ELTinterviews and why DO ghosts wea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 18, 24 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 54, 70 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTRisingStar",
        "indices" : [ 71, 85 ]
      }, {
        "text" : "ELTinterviews",
        "indices" : [ 86, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/KMzuBYgsax",
        "expanded_url" : "http:\/\/wp.me\/p25Kfd-uF",
        "display_url" : "wp.me\/p25Kfd-uF"
      } ]
    },
    "geo" : { },
    "id_str" : "452139780701028353",
    "text" : "An Interview with @EBEFL!  http:\/\/t.co\/KMzuBYgsax via @michaelegriffin #ELTRisingStar #ELTinterviews and why DO ghosts wear clothes?",
    "id" : 452139780701028353,
    "created_at" : "2014-04-04 17:44:58 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 452146624769560576,
  "created_at" : "2014-04-04 18:12:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 3, 16 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "iatefl2014",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/pOGrEveFPz",
      "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2014\/04\/04\/plenary-michael-hoey-the-implications-of-a-corpus-linguistic-theory-for-learning-the-english-language-and-the-chinese-language-too\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2014\/04\/04\/ple\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452052176668733440",
  "text" : "RT @LizziePinard: Michael Hoey did a fab plenary this morning at #iatefl http:\/\/t.co\/pOGrEveFPz #iatefl2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "iatefl2014",
        "indices" : [ 78, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/pOGrEveFPz",
        "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2014\/04\/04\/plenary-michael-hoey-the-implications-of-a-corpus-linguistic-theory-for-learning-the-english-language-and-the-chinese-language-too\/",
        "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2014\/04\/04\/ple\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452012613770420224",
    "text" : "Michael Hoey did a fab plenary this morning at #iatefl http:\/\/t.co\/pOGrEveFPz #iatefl2014",
    "id" : 452012613770420224,
    "created_at" : "2014-04-04 09:19:39 +0000",
    "user" : {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "protected" : false,
      "id_str" : "287093748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628657904460132352\/nS6hzUBs_normal.png",
      "id" : 287093748,
      "verified" : false
    }
  },
  "id" : 452052176668733440,
  "created_at" : "2014-04-04 11:56:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 3, 16 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eKgICQqFOF",
      "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2014\/04\/04\/julie-moore-how-do-engineers-say-that-encouraging-academic-independence-in-elt-session-1\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2014\/04\/04\/jul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452052129436676096",
  "text" : "RT @LizziePinard: Julie Moore\/OUP on encouraging academic independence - brilliant talk!! http:\/\/t.co\/eKgICQqFOF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/eKgICQqFOF",
        "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2014\/04\/04\/julie-moore-how-do-engineers-say-that-encouraging-academic-independence-in-elt-session-1\/",
        "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2014\/04\/04\/jul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452022888464678912",
    "text" : "Julie Moore\/OUP on encouraging academic independence - brilliant talk!! http:\/\/t.co\/eKgICQqFOF",
    "id" : 452022888464678912,
    "created_at" : "2014-04-04 10:00:29 +0000",
    "user" : {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "protected" : false,
      "id_str" : "287093748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628657904460132352\/nS6hzUBs_normal.png",
      "id" : 287093748,
      "verified" : false
    }
  },
  "id" : 452052129436676096,
  "created_at" : "2014-04-04 11:56:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452048254264705024",
  "geo" : { },
  "id_str" : "452048550176641024",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thx saw that on the site, be interested to read about nitty gritty :) i guess the paper goes into that?",
  "id" : 452048550176641024,
  "in_reply_to_status_id" : 452048254264705024,
  "created_at" : "2014-04-04 11:42:27 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452047164253147136",
  "geo" : { },
  "id_str" : "452047874650812416",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco hi yeah be great to read paper you can reach me on my gmail account, thx",
  "id" : 452047874650812416,
  "in_reply_to_status_id" : 452047164253147136,
  "created_at" : "2014-04-04 11:39:46 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452045740760899584",
  "geo" : { },
  "id_str" : "452046146253643776",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco ah right been testing now and can't get out of the red! :) will u be writing about how it works exactly?",
  "id" : 452046146253643776,
  "in_reply_to_status_id" : 452045740760899584,
  "created_at" : "2014-04-04 11:32:54 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NLP",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452029927983153152",
  "geo" : { },
  "id_str" : "452043272161329153",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco iLexIR my kind of #NLP consultancy :), interesting tool, thanks.",
  "id" : 452043272161329153,
  "in_reply_to_status_id" : 452029927983153152,
  "created_at" : "2014-04-04 11:21:29 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "indices" : [ 3, 12 ],
      "id_str" : "34639201",
      "id" : 34639201
    }, {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 39, 50 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/l5IeerPk1E",
      "expanded_url" : "http:\/\/ow.ly\/vpiXo",
      "display_url" : "ow.ly\/vpiXo"
    } ]
  },
  "geo" : { },
  "id_str" : "451972980898545664",
  "text" : "RT @CALPERPA: Our latest PPT upload to @Slideshare: Corpus Tools for Language Teaching. http:\/\/t.co\/l5IeerPk1E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LinkedIn SlideShare",
        "screen_name" : "SlideShare",
        "indices" : [ 25, 36 ],
        "id_str" : "9676152",
        "id" : 9676152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/l5IeerPk1E",
        "expanded_url" : "http:\/\/ow.ly\/vpiXo",
        "display_url" : "ow.ly\/vpiXo"
      } ]
    },
    "geo" : { },
    "id_str" : "451840710950780928",
    "text" : "Our latest PPT upload to @Slideshare: Corpus Tools for Language Teaching. http:\/\/t.co\/l5IeerPk1E",
    "id" : 451840710950780928,
    "created_at" : "2014-04-03 21:56:34 +0000",
    "user" : {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "protected" : false,
      "id_str" : "34639201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634442828626563073\/ZRmLNoOU_normal.png",
      "id" : 34639201,
      "verified" : false
    }
  },
  "id" : 451972980898545664,
  "created_at" : "2014-04-04 06:42:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 3, 18 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IoxatvdjGS",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-30",
      "display_url" : "wp.me\/p35kaI-30"
    } ]
  },
  "geo" : { },
  "id_str" : "451707021411491840",
  "text" : "RT @AndrewBrindle2: Gender in the Far-Right: An Observation of Masculinities in the EDL using Corpus\u00A0Linguistics http:\/\/t.co\/IoxatvdjGS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/IoxatvdjGS",
        "expanded_url" : "http:\/\/wp.me\/p35kaI-30",
        "display_url" : "wp.me\/p35kaI-30"
      } ]
    },
    "geo" : { },
    "id_str" : "451700368125083650",
    "text" : "Gender in the Far-Right: An Observation of Masculinities in the EDL using Corpus\u00A0Linguistics http:\/\/t.co\/IoxatvdjGS",
    "id" : 451700368125083650,
    "created_at" : "2014-04-03 12:38:54 +0000",
    "user" : {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "protected" : false,
      "id_str" : "358143205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3159032513\/6388ad14eee8e221dba33ca6f3186650_normal.jpeg",
      "id" : 358143205,
      "verified" : false
    }
  },
  "id" : 451707021411491840,
  "created_at" : "2014-04-03 13:05:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 74, 85 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/yJaLfvjzKp",
      "expanded_url" : "http:\/\/iatefl.britishcouncil.org\/2014\/sessions\/2014-04-03\/interview-hugh-dellar",
      "display_url" : "iatefl.britishcouncil.org\/2014\/sessions\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451704580272058368",
  "text" : "#iatefl interesting announcement of Lexical Lab http:\/\/t.co\/yJaLfvjzKp by @hughdellar and @CELTtraining",
  "id" : 451704580272058368,
  "created_at" : "2014-04-03 12:55:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mustafa polat",
      "screen_name" : "muspol",
      "indices" : [ 78, 85 ],
      "id_str" : "133806782",
      "id" : 133806782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/TecyaYQ7hQ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Mf",
      "display_url" : "wp.me\/pgHyE-Mf"
    } ]
  },
  "geo" : { },
  "id_str" : "451701401098657792",
  "text" : "#IATEFL Chain reaction, Paula Lyra &amp; Mustafa Polat http:\/\/t.co\/TecyaYQ7hQ @muspol",
  "id" : 451701401098657792,
  "created_at" : "2014-04-03 12:43:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 44, 60 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/h27OLO43sS",
      "expanded_url" : "http:\/\/wp.me\/p1mEF-31J",
      "display_url" : "wp.me\/p1mEF-31J"
    } ]
  },
  "geo" : { },
  "id_str" : "451666439775059968",
  "text" : "Mixing Stuff Up: http:\/\/t.co\/h27OLO43sS via @wordpressdotcom",
  "id" : 451666439775059968,
  "created_at" : "2014-04-03 10:24:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451642802280337408",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith thanks for share :):)",
  "id" : 451642802280337408,
  "created_at" : "2014-04-03 08:50:09 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Entrepreneur",
      "screen_name" : "EntMagazine",
      "indices" : [ 119, 131 ],
      "id_str" : "2932542566",
      "id" : 2932542566
    }, {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "indices" : [ 132, 136 ],
      "id_str" : "16896485",
      "id" : 16896485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/bhtG1QxK1o",
      "expanded_url" : "http:\/\/idibon.com\/entrepreneurs-french-spanish-english\/",
      "display_url" : "idibon.com\/entrepreneurs-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451496298886492161",
  "text" : "RT @TSchnoebelen: English, French, and Spanish tweets about entrepreneurs are pretty different: http:\/\/t.co\/bhtG1QxK1o @EntMagazine @Inc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Entrepreneur",
        "screen_name" : "EntMagazine",
        "indices" : [ 101, 113 ],
        "id_str" : "2932542566",
        "id" : 2932542566
      }, {
        "name" : "Inc.",
        "screen_name" : "Inc",
        "indices" : [ 114, 118 ],
        "id_str" : "16896485",
        "id" : 16896485
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/bhtG1QxK1o",
        "expanded_url" : "http:\/\/idibon.com\/entrepreneurs-french-spanish-english\/",
        "display_url" : "idibon.com\/entrepreneurs-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451434386873786368",
    "text" : "English, French, and Spanish tweets about entrepreneurs are pretty different: http:\/\/t.co\/bhtG1QxK1o @EntMagazine @Inc",
    "id" : 451434386873786368,
    "created_at" : "2014-04-02 19:01:59 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 451496298886492161,
  "created_at" : "2014-04-02 23:08:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 3, 17 ],
      "id_str" : "118014141",
      "id" : 118014141
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 81, 87 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl2014",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/M7LwiPOsbC",
      "expanded_url" : "http:\/\/iatefl.britishcouncil.org\/2014\/sessions\/2014-04-02\/guide-pseudo-science-english-language-teaching",
      "display_url" : "iatefl.britishcouncil.org\/2014\/sessions\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451489436627644416",
  "text" : "RT @alexanderding: http:\/\/t.co\/M7LwiPOsbC just watched this excellent session by @ebefl on pseudoscience in TESOL. Highly recommended! #iat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 62, 68 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl2014",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/M7LwiPOsbC",
        "expanded_url" : "http:\/\/iatefl.britishcouncil.org\/2014\/sessions\/2014-04-02\/guide-pseudo-science-english-language-teaching",
        "display_url" : "iatefl.britishcouncil.org\/2014\/sessions\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451488940084957184",
    "text" : "http:\/\/t.co\/M7LwiPOsbC just watched this excellent session by @ebefl on pseudoscience in TESOL. Highly recommended! #iatefl2014",
    "id" : 451488940084957184,
    "created_at" : "2014-04-02 22:38:46 +0000",
    "user" : {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "protected" : false,
      "id_str" : "118014141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539699809939378176\/wRkQk33z_normal.jpeg",
      "id" : 118014141,
      "verified" : false
    }
  },
  "id" : 451489436627644416,
  "created_at" : "2014-04-02 22:40:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 12, 24 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451482426624049152",
  "geo" : { },
  "id_str" : "451489320181202945",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @AnneHendler sure, though have only skimmmed that text myself",
  "id" : 451489320181202945,
  "in_reply_to_status_id" : 451482426624049152,
  "created_at" : "2014-04-02 22:40:16 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451483740431454208",
  "geo" : { },
  "id_str" : "451489148445396992",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana cheers nope can only follow online, hope u r havin fun :)",
  "id" : 451489148445396992,
  "in_reply_to_status_id" : 451483740431454208,
  "created_at" : "2014-04-02 22:39:35 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 0, 14 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451480267224776704",
  "geo" : { },
  "id_str" : "451489012394770432",
  "in_reply_to_user_id" : 48839094,
  "text" : "@duygucandarli thanks for share :)",
  "id" : 451489012394770432,
  "in_reply_to_status_id" : 451480267224776704,
  "created_at" : "2014-04-02 22:39:03 +0000",
  "in_reply_to_screen_name" : "duygucandarli",
  "in_reply_to_user_id_str" : "48839094",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/l3memPHNfu",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/04\/02\/iatefl-harrogate-2014-english-as-a-medium-of-instruction-zero-for-the-price-of-two\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/04\/02\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451476128298180609",
  "text" : "new blog post - English as a medium of instruction \u2013 zero for the price of two? http:\/\/t.co\/l3memPHNfu #iatefl",
  "id" : 451476128298180609,
  "created_at" : "2014-04-02 21:47:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 133, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ghLAAE1P6L",
      "expanded_url" : "http:\/\/bit.ly\/OdHhPm",
      "display_url" : "bit.ly\/OdHhPm"
    } ]
  },
  "geo" : { },
  "id_str" : "451447858987036673",
  "text" : "RT @nathanghall: No document camera? No problem! Use your smartphone, Dropbox, and PicMonkey to do even more! http:\/\/t.co\/ghLAAE1P6L #edtec\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 116, 123 ]
      }, {
        "text" : "elt",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "edchat",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/ghLAAE1P6L",
        "expanded_url" : "http:\/\/bit.ly\/OdHhPm",
        "display_url" : "bit.ly\/OdHhPm"
      } ]
    },
    "geo" : { },
    "id_str" : "451440312850739203",
    "text" : "No document camera? No problem! Use your smartphone, Dropbox, and PicMonkey to do even more! http:\/\/t.co\/ghLAAE1P6L #edtech #elt #edchat",
    "id" : 451440312850739203,
    "created_at" : "2014-04-02 19:25:32 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 451447858987036673,
  "created_at" : "2014-04-02 19:55:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TALC11",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451395539704479744",
  "geo" : { },
  "id_str" : "451401018153381888",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco if had chance the one conference this year would have been #TALC11, will u be going there?",
  "id" : 451401018153381888,
  "in_reply_to_status_id" : 451395539704479744,
  "created_at" : "2014-04-02 16:49:24 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 13, 24 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451393410927034371",
  "geo" : { },
  "id_str" : "451395085675270144",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @kevchanwow cheers anne :)",
  "id" : 451395085675270144,
  "in_reply_to_status_id" : 451393410927034371,
  "created_at" : "2014-04-02 16:25:49 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451394771941355520",
  "text" : "RT @ibogost: Gamifee-gamify-gamifo-gamifum\nI smell the blood of a swindler",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448537167284150272",
    "text" : "Gamifee-gamify-gamifo-gamifum\nI smell the blood of a swindler",
    "id" : 448537167284150272,
    "created_at" : "2014-03-25 19:09:28 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677930477752193025\/DUdmOVVK_normal.jpg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 451394771941355520,
  "created_at" : "2014-04-02 16:24:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451393719238160385",
  "geo" : { },
  "id_str" : "451394708934496256",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco i wish diane can only follow online, trust you'll be going to some interesting talks :)",
  "id" : 451394708934496256,
  "in_reply_to_status_id" : 451393719238160385,
  "created_at" : "2014-04-02 16:24:19 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451392389362745345",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow eh up what happened to your wordlist post?",
  "id" : 451392389362745345,
  "created_at" : "2014-04-02 16:15:06 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 91, 107 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Rh63xPWz4U",
      "expanded_url" : "http:\/\/wp.me\/p1Ayq4-61",
      "display_url" : "wp.me\/p1Ayq4-61"
    } ]
  },
  "geo" : { },
  "id_str" : "451392130531860480",
  "text" : "How to engage with research talks at the IATEFL 2014 Conference http:\/\/t.co\/Rh63xPWz4U via @wordpressdotcom",
  "id" : 451392130531860480,
  "created_at" : "2014-04-02 16:14:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 97, 109 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/9I3eRHLFhm",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-6QS",
      "display_url" : "wp.me\/p1U04a-6QS"
    } ]
  },
  "geo" : { },
  "id_str" : "451083053398372352",
  "text" : "8 government policies that look like April Fool's jokes but are real: http:\/\/t.co\/9I3eRHLFhm via @ThomasPride",
  "id" : 451083053398372352,
  "created_at" : "2014-04-01 19:45:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 3, 18 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/5yM4gbkQJo",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-2M",
      "display_url" : "wp.me\/p35kaI-2M"
    } ]
  },
  "geo" : { },
  "id_str" : "451002563832590337",
  "text" : "RT @AndrewBrindle2: Threat from the White House: Using corpus linguistics to look at White House press\u00A0briefings http:\/\/t.co\/5yM4gbkQJo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/5yM4gbkQJo",
        "expanded_url" : "http:\/\/wp.me\/p35kaI-2M",
        "display_url" : "wp.me\/p35kaI-2M"
      } ]
    },
    "geo" : { },
    "id_str" : "450993349067956224",
    "text" : "Threat from the White House: Using corpus linguistics to look at White House press\u00A0briefings http:\/\/t.co\/5yM4gbkQJo",
    "id" : 450993349067956224,
    "created_at" : "2014-04-01 13:49:28 +0000",
    "user" : {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "protected" : false,
      "id_str" : "358143205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3159032513\/6388ad14eee8e221dba33ca6f3186650_normal.jpeg",
      "id" : 358143205,
      "verified" : false
    }
  },
  "id" : 451002563832590337,
  "created_at" : "2014-04-01 14:26:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 3, 10 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/JubGP3gLfy",
      "expanded_url" : "http:\/\/www.wordsforthat.com\/scenarios\/2184#.UzkhTMVNgIA.twitter",
      "display_url" : "wordsforthat.com\/scenarios\/2184\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450980375171698688",
  "text" : "RT @WordLo: New website for Wordlovers!!!Words For That http:\/\/t.co\/JubGP3gLfy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/JubGP3gLfy",
        "expanded_url" : "http:\/\/www.wordsforthat.com\/scenarios\/2184#.UzkhTMVNgIA.twitter",
        "display_url" : "wordsforthat.com\/scenarios\/2184\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450544141131210753",
    "text" : "New website for Wordlovers!!!Words For That http:\/\/t.co\/JubGP3gLfy",
    "id" : 450544141131210753,
    "created_at" : "2014-03-31 08:04:28 +0000",
    "user" : {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "protected" : false,
      "id_str" : "190569306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660652749881782272\/BB1P3zUR_normal.jpg",
      "id" : 190569306,
      "verified" : false
    }
  },
  "id" : 450980375171698688,
  "created_at" : "2014-04-01 12:57:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CamillaMariannaBaran",
      "screen_name" : "baran_camilla",
      "indices" : [ 0, 14 ],
      "id_str" : "2365687700",
      "id" : 2365687700
    }, {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 15, 30 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450658909737734144",
  "geo" : { },
  "id_str" : "450948610856091648",
  "in_reply_to_user_id" : 2365687700,
  "text" : "@baran_camilla @markwarschauer quite!",
  "id" : 450948610856091648,
  "in_reply_to_status_id" : 450658909737734144,
  "created_at" : "2014-04-01 10:51:41 +0000",
  "in_reply_to_screen_name" : "baran_camilla",
  "in_reply_to_user_id_str" : "2365687700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 3, 16 ],
      "id_str" : "287093748",
      "id" : 287093748
    }, {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "indices" : [ 54, 67 ],
      "id_str" : "141530833",
      "id" : 141530833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl2014",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1GQ5obTSaT",
      "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2014\/04\/01\/learning-technologies-sig-p-c-e-adrian-holliday-web-based-learning-cultural-travel-and-claiming-the-world\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2014\/04\/01\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450945785572909056",
  "text" : "RT @LizziePinard: #iatefl2014 #IATEFL Adrian Holliday @iatefl_ltsig 's PCE day's first talk: my notes from it! BIG THX for livestream! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IATEFL LTSIG",
        "screen_name" : "iatefl_ltsig",
        "indices" : [ 36, 49 ],
        "id_str" : "141530833",
        "id" : 141530833
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl2014",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "IATEFL",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/1GQ5obTSaT",
        "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2014\/04\/01\/learning-technologies-sig-p-c-e-adrian-holliday-web-based-learning-cultural-travel-and-claiming-the-world\/",
        "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2014\/04\/01\/lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450943652911919104",
    "text" : "#iatefl2014 #IATEFL Adrian Holliday @iatefl_ltsig 's PCE day's first talk: my notes from it! BIG THX for livestream! http:\/\/t.co\/1GQ5obTSaT",
    "id" : 450943652911919104,
    "created_at" : "2014-04-01 10:31:59 +0000",
    "user" : {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "protected" : false,
      "id_str" : "287093748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628657904460132352\/nS6hzUBs_normal.png",
      "id" : 287093748,
      "verified" : false
    }
  },
  "id" : 450945785572909056,
  "created_at" : "2014-04-01 10:40:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "indices" : [ 3, 16 ],
      "id_str" : "141530833",
      "id" : 141530833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "ltsig",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450924438700449792",
  "text" : "RT @iatefl_ltsig: #IATEFL #ltsig PCE ready to start. Our first speaker is Prof. Adrian Holliday Web-based learning, cultural travel and cla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "ltsig",
        "indices" : [ 8, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450920664124620801",
    "text" : "#IATEFL #ltsig PCE ready to start. Our first speaker is Prof. Adrian Holliday Web-based learning, cultural travel and claiming the world",
    "id" : 450920664124620801,
    "created_at" : "2014-04-01 09:00:38 +0000",
    "user" : {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "protected" : false,
      "id_str" : "141530833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3559398421\/c33454189d56b57c68d3bfadec038dcb_normal.jpeg",
      "id" : 141530833,
      "verified" : false
    }
  },
  "id" : 450924438700449792,
  "created_at" : "2014-04-01 09:15:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450895698310213632",
  "geo" : { },
  "id_str" : "450915440295174144",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang neat vid though can one make \"life changing relationships\" remotely hmm, massive open romance course?",
  "id" : 450915440295174144,
  "in_reply_to_status_id" : 450895698310213632,
  "created_at" : "2014-04-01 08:39:53 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]