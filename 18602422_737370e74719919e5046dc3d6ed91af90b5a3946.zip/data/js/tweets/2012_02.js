Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174429600502386688",
  "geo" : { },
  "id_str" : "174995603091234816",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames thx for suggestions bout brussels. had a good time though too short!",
  "id" : 174995603091234816,
  "in_reply_to_status_id" : 174429600502386688,
  "created_at" : "2012-02-29 23:12:57 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174978171152773120",
  "text" : "thx all #eltchat",
  "id" : 174978171152773120,
  "created_at" : "2012-02-29 22:03:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174963431022137344",
  "text" : "since using soundcloud for listening activity on the lookout for webtools with *commenting* features #eltchat",
  "id" : 174963431022137344,
  "created_at" : "2012-02-29 21:05:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ollie Bray",
      "screen_name" : "olliebray",
      "indices" : [ 0, 10 ],
      "id_str" : "6896272",
      "id" : 6896272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174181448415322112",
  "geo" : { },
  "id_str" : "174253095587549185",
  "in_reply_to_user_id" : 6896272,
  "text" : "@olliebray any pointers to open source ed stuff you've used?",
  "id" : 174253095587549185,
  "in_reply_to_status_id" : 174181448415322112,
  "created_at" : "2012-02-27 22:02:30 +0000",
  "in_reply_to_screen_name" : "olliebray",
  "in_reply_to_user_id_str" : "6896272",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ollie Bray",
      "screen_name" : "olliebray",
      "indices" : [ 0, 10 ],
      "id_str" : "6896272",
      "id" : 6896272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174161881722925057",
  "in_reply_to_user_id" : 6896272,
  "text" : "@olliebray any plans for an open source sponsered gaming ebook?",
  "id" : 174161881722925057,
  "created_at" : "2012-02-27 16:00:03 +0000",
  "in_reply_to_screen_name" : "olliebray",
  "in_reply_to_user_id_str" : "6896272",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174147919660847104",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames going to be in Brussels tomorrow for a night\/2days with my wife, any recommendations, restos, sights? cheers in advance",
  "id" : 174147919660847104,
  "created_at" : "2012-02-27 15:04:34 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SGI Tesol Training",
      "screen_name" : "TesolTrainingUK",
      "indices" : [ 3, 19 ],
      "id_str" : "353681537",
      "id" : 353681537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/DJKCKGlX",
      "expanded_url" : "http:\/\/bit.ly\/y5Ug5F",
      "display_url" : "bit.ly\/y5Ug5F"
    } ]
  },
  "geo" : { },
  "id_str" : "174108766575398913",
  "text" : "RT @TesolTrainingUK: http:\/\/t.co\/DJKCKGlX content of students' reading written by teachers\/sts nxt 2 them?&lt;-blast frm past student mags!:)",
  "id" : 174108766575398913,
  "created_at" : "2012-02-27 12:28:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 53, 64 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174082655082659842",
  "text" : "tried to comment on latest post but it won't let me! @leoselivan",
  "id" : 174082655082659842,
  "created_at" : "2012-02-27 10:45:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 11, 21 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173908445496483840",
  "text" : "thx for RT @willycard",
  "id" : 173908445496483840,
  "created_at" : "2012-02-26 23:12:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 3, 14 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/iSXss4WI",
      "expanded_url" : "http:\/\/freelanceteacherinfrance.blogspot.com\/2012\/02\/numero-de-declaration-dactivite-part-1.html?m=1",
      "display_url" : "freelanceteacherinfrance.blogspot.com\/2012\/02\/numero\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173907806657851392",
  "text" : "RT @bethcagnol: how 2 get your Num\u00E9ro de D\u00E9claration http:\/\/t.co\/iSXss4WI&lt;--good info",
  "id" : 173907806657851392,
  "created_at" : "2012-02-26 23:10:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 76, 86 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/MpB0bYuM",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-3r",
      "display_url" : "wp.me\/pgHyE-3r"
    } ]
  },
  "geo" : { },
  "id_str" : "173841830339817473",
  "text" : "Waiting for Babel - some thoughts on using translation http:\/\/t.co\/MpB0bYuM @willycard",
  "id" : 173841830339817473,
  "created_at" : "2012-02-26 18:48:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 79, 95 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 96, 107 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/vPofO1cE",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-36",
      "display_url" : "wp.me\/pgHyE-36"
    } ]
  },
  "geo" : { },
  "id_str" : "173047858981900289",
  "text" : "#ELTchat Feb blog challenge response...sort of :\/ http:\/\/t.co\/vPofO1cE@ELTchat @theteacherjames @bethcagnol",
  "id" : 173047858981900289,
  "created_at" : "2012-02-24 14:13:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 3, 14 ],
      "id_str" : "14548913",
      "id" : 14548913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173026648202022912",
  "text" : "RT @NikPeachey: Can anyone say hello to new Twitter users from BC Pakistan please. Say where you are.&lt;-hellow there from Paris, France",
  "id" : 173026648202022912,
  "created_at" : "2012-02-24 12:49:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172642237170188288",
  "geo" : { },
  "id_str" : "172643480265437184",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yeah i think because it is deep will take a while figuring i out!",
  "id" : 172643480265437184,
  "in_reply_to_status_id" : 172642237170188288,
  "created_at" : "2012-02-23 11:26:27 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/NPHHEPrv",
      "expanded_url" : "http:\/\/www.wordandphrase.info\/analyzeText.asp",
      "display_url" : "wordandphrase.info\/analyzeText.asp"
    } ]
  },
  "geo" : { },
  "id_str" : "172629784147398660",
  "text" : "a new COCA interface http:\/\/t.co\/NPHHEPrv; impressive",
  "id" : 172629784147398660,
  "created_at" : "2012-02-23 10:32:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 3, 15 ],
      "id_str" : "23870533",
      "id" : 23870533
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 60, 68 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/uxosUs2K",
      "expanded_url" : "http:\/\/bit.ly\/zO8NQY",
      "display_url" : "bit.ly\/zO8NQY"
    } ]
  },
  "geo" : { },
  "id_str" : "172627662391615488",
  "text" : "RT @creedpatton: Get Lamp: The Text Adventure Documentary | @scoopit http:\/\/t.co\/uxosUs2K",
  "id" : 172627662391615488,
  "created_at" : "2012-02-23 10:23:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 52, 67 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "The New School",
      "screen_name" : "TheNewSchool",
      "indices" : [ 72, 85 ],
      "id_str" : "17995712",
      "id" : 17995712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172400977465454592",
  "text" : "attended a great webinar on discourse analysis from @thornburyscott for @thenewschool",
  "id" : 172400977465454592,
  "created_at" : "2012-02-22 19:22:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 45, 61 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/x2wbGg8K",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2W",
      "display_url" : "wp.me\/pgHyE-2W"
    } ]
  },
  "geo" : { },
  "id_str" : "172352695485730817",
  "text" : "A ramble in the Twitter http:\/\/t.co\/x2wbGg8K @theteacherjames",
  "id" : 172352695485730817,
  "created_at" : "2012-02-22 16:10:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 3, 14 ],
      "id_str" : "14548913",
      "id" : 14548913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172350281634418688",
  "text" : "RT @NikPeachey: Can you please say hello to my MA TESL class + say where u R --Hey there! Hope all is good. from Paris, France",
  "id" : 172350281634418688,
  "created_at" : "2012-02-22 16:01:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 45, 53 ],
      "id_str" : "189578708",
      "id" : 189578708
    }, {
      "name" : "#EAPChat",
      "screen_name" : "EAPChat",
      "indices" : [ 54, 62 ],
      "id_str" : "471670258",
      "id" : 471670258
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 63, 71 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "James Wallace",
      "screen_name" : "TeacherJames",
      "indices" : [ 72, 85 ],
      "id_str" : "20246173",
      "id" : 20246173
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 86, 97 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/x2wbGg8K",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2W",
      "display_url" : "wp.me\/pgHyE-2W"
    } ]
  },
  "geo" : { },
  "id_str" : "172347276667273217",
  "text" : "A ramble in the Twitter http:\/\/t.co\/x2wbGg8K @ELTchat @EAPchat @seburnt @teacherjames @leoselivan",
  "id" : 172347276667273217,
  "created_at" : "2012-02-22 15:49:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172280421533483008",
  "geo" : { },
  "id_str" : "172287867954016256",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard Tumbler?",
  "id" : 172287867954016256,
  "in_reply_to_status_id" : 172280421533483008,
  "created_at" : "2012-02-22 11:53:23 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 4, 16 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/8hwDFySs",
      "expanded_url" : "http:\/\/su.pr\/2OYodB",
      "display_url" : "su.pr\/2OYodB"
    } ]
  },
  "geo" : { },
  "id_str" : "171992148030406656",
  "text" : "RT  @davidmearns Loading... http:\/\/t.co\/8hwDFySs good od BR&lt;--good quote got similar by Yeats in my profile =)",
  "id" : 171992148030406656,
  "created_at" : "2012-02-21 16:18:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 3, 16 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/CDkgRfBY",
      "expanded_url" : "http:\/\/fb.me\/1C",
      "display_url" : "fb.me\/1C"
    }, {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/wgkFN0b0",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2H",
      "display_url" : "wp.me\/pgHyE-2H"
    } ]
  },
  "geo" : { },
  "id_str" : "171990534951419904",
  "text" : "RT @Sharonzspace Interactive and breathtaking. http:\/\/t.co\/CDkgRfBY&lt;--used this in a lesson c http:\/\/t.co\/wgkFN0b0",
  "id" : 171990534951419904,
  "created_at" : "2012-02-21 16:11:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171926883708059648",
  "text" : "just finished first unit on udacity prog course! took about 3hrs multitasking; got concept of final quiz but not full execution!",
  "id" : 171926883708059648,
  "created_at" : "2012-02-21 11:58:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 2, 15 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171908582906929153",
  "text" : "RT@harrisonmike I would love to know what problems your learners have with reading - recently problems in paraphrasing, generally lexis",
  "id" : 171908582906929153,
  "created_at" : "2012-02-21 10:46:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171886404496924672",
  "text" : "udacity online comp course - had to try out 3 browsers before got it working on safari! running on mac tiger",
  "id" : 171886404496924672,
  "created_at" : "2012-02-21 09:18:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/VBxi2Drq",
      "expanded_url" : "http:\/\/fourc.ca\/100\/",
      "display_url" : "fourc.ca\/100\/"
    } ]
  },
  "geo" : { },
  "id_str" : "171744952500486144",
  "text" : "RT @seburnt It also happens to be my 100th post. Twice the reason to celebrate! http:\/\/t.co\/VBxi2Drq &lt;---good job u centurion!",
  "id" : 171744952500486144,
  "created_at" : "2012-02-20 23:56:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#EAPChat",
      "screen_name" : "EAPChat",
      "indices" : [ 55, 63 ],
      "id_str" : "471670258",
      "id" : 471670258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171671553250045952",
  "text" : "thx all, good chat shame my internet lag is horrendous @EAPchat",
  "id" : 171671553250045952,
  "created_at" : "2012-02-20 19:04:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171670880492064768",
  "text" : "even wth adult learners vocab learn skills are quite basic i.e. record in notebook; show them other systems like bristol card #EAPchat",
  "id" : 171670880492064768,
  "created_at" : "2012-02-20 19:01:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 86, 99 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171663892001472512",
  "text" : "giving research-carried-out templates and reinforce imp to final project report marks @Sharonzspace #EAPchat",
  "id" : 171663892001472512,
  "created_at" : "2012-02-20 18:33:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171660270131871745",
  "text" : "study habits - recording\/organising their research? an issue i have with a project class #EAPchat",
  "id" : 171660270131871745,
  "created_at" : "2012-02-20 18:19:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171658701160189953",
  "text" : "with some of my sts a big question is that they ignore how they learn; their workload is what to learn #EAPchat",
  "id" : 171658701160189953,
  "created_at" : "2012-02-20 18:13:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 3, 16 ],
      "id_str" : "39718253",
      "id" : 39718253
    }, {
      "name" : "Ken Wilson",
      "screen_name" : "kenwilsonlondon",
      "indices" : [ 19, 35 ],
      "id_str" : "29030280",
      "id" : 29030280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/D6HKdraM",
      "expanded_url" : "http:\/\/bit.ly\/zoDny2",
      "display_url" : "bit.ly\/zoDny2"
    } ]
  },
  "geo" : { },
  "id_str" : "171609526397710337",
  "text" : "RT @LukeMeddings: \u201C@kenwilsonlondon: Motivating the Unmotivated  http:\/\/t.co\/D6HKdraM\u201D&lt;--great talk!",
  "id" : 171609526397710337,
  "created_at" : "2012-02-20 14:57:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 3, 13 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/LEGrtTFz",
      "expanded_url" : "http:\/\/bit.ly\/AzRQLo",
      "display_url" : "bit.ly\/AzRQLo"
    } ]
  },
  "geo" : { },
  "id_str" : "171591245364330497",
  "text" : "RT @willycard:Play as development: Vygotsky and teaching English to adults http:\/\/t.co\/LEGrtTFz &lt;--comment here",
  "id" : 171591245364330497,
  "created_at" : "2012-02-20 13:45:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 3, 15 ],
      "id_str" : "23870533",
      "id" : 23870533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171573773059899392",
  "text" : "RT @creedpatton: I'll be bringing  Interactive Fiction to the masses at #IATEFL in Glasgow.&lt;--nice one Joe!",
  "id" : 171573773059899392,
  "created_at" : "2012-02-20 12:35:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171322083530387456",
  "text" : "help! looking for a recently tweeted(2weeks?) video in a seminar, i think in poland, on teaching young kids?",
  "id" : 171322083530387456,
  "created_at" : "2012-02-19 19:55:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 3, 15 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/zQ00HNxG",
      "expanded_url" : "http:\/\/bit.ly\/wKobys",
      "display_url" : "bit.ly\/wKobys"
    } ]
  },
  "geo" : { },
  "id_str" : "171268137344446464",
  "text" : "RT @LanguageLog: Sing, sang, sung: http:\/\/t.co\/zQ00HNxG&lt;--something to think about nxt time your stds make irreg vocab errors =)",
  "id" : 171268137344446464,
  "created_at" : "2012-02-19 16:21:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171220680950546434",
  "geo" : { },
  "id_str" : "171228737218691073",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan \"figures may be wrong\" is main point re incidental reading and vocab learning? also thx fr backseatling link",
  "id" : 171228737218691073,
  "in_reply_to_status_id" : 171220680950546434,
  "created_at" : "2012-02-19 13:44:46 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/l1Xd7DqL",
      "expanded_url" : "http:\/\/bit.ly\/yAUFgU",
      "display_url" : "bit.ly\/yAUFgU"
    } ]
  },
  "geo" : { },
  "id_str" : "171202594113470464",
  "text" : "RT @leoselivan: Figures may be wrong http:\/\/t.co\/l1Xd7DqL &lt;- is not issue pickup rates for infreq words are not sig low?",
  "id" : 171202594113470464,
  "created_at" : "2012-02-19 12:00:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170537419597283328",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard sent link to your wordpress email",
  "id" : 170537419597283328,
  "created_at" : "2012-02-17 15:57:43 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EdTech",
      "screen_name" : "EdTech",
      "indices" : [ 67, 74 ],
      "id_str" : "10197402",
      "id" : 10197402
    }, {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 76, 91 ],
      "id_str" : "67682458",
      "id" : 67682458
    }, {
      "name" : "elton naicker",
      "screen_name" : "elt",
      "indices" : [ 92, 96 ],
      "id_str" : "131938942",
      "id" : 131938942
    }, {
      "name" : "ESL",
      "screen_name" : "ESL",
      "indices" : [ 97, 101 ],
      "id_str" : "16905329",
      "id" : 16905329
    }, {
      "name" : "edupunk",
      "screen_name" : "edupunk",
      "indices" : [ 102, 110 ],
      "id_str" : "15388670",
      "id" : 15388670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/wgkFN0b0",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2H",
      "display_url" : "wp.me\/pgHyE-2H"
    } ]
  },
  "geo" : { },
  "id_str" : "170536912036179968",
  "text" : "Online whiteboard to enhance reading activity http:\/\/t.co\/wgkFN0b0 @edtech, @eltdigitalplay @ELT @esl @edupunk @ ict",
  "id" : 170536912036179968,
  "created_at" : "2012-02-17 15:55:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Computerworld UK",
      "screen_name" : "computerworlduk",
      "indices" : [ 114, 130 ],
      "id_str" : "16884750",
      "id" : 16884750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/s4bzAMiV",
      "expanded_url" : "http:\/\/ComputerworldUK.com",
      "display_url" : "ComputerworldUK.com"
    }, {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/BEBdUoFf",
      "expanded_url" : "http:\/\/www.computerworlduk.com\/news\/applications\/3337689\/wikileaks-backed-global-square-p2p-activist-platform-due-in-march\/",
      "display_url" : "computerworlduk.com\/news\/applicati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170417899771674624",
  "text" : "Wikileaks-backed Global Square P2P activist platform due in March - http:\/\/t.co\/s4bzAMiV http:\/\/t.co\/BEBdUoFf via @computerworlduk",
  "id" : 170417899771674624,
  "created_at" : "2012-02-17 08:02:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/fb5wosQp",
      "expanded_url" : "http:\/\/youtu.be\/DdNAUJWJN08",
      "display_url" : "youtu.be\/DdNAUJWJN08"
    } ]
  },
  "geo" : { },
  "id_str" : "170415102158307329",
  "text" : "watching chomsky on purpose of education\nhttp:\/\/t.co\/fb5wosQp",
  "id" : 170415102158307329,
  "created_at" : "2012-02-17 07:51:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 3, 11 ],
      "id_str" : "21094022",
      "id" : 21094022
    }, {
      "name" : "Steve Bingham",
      "screen_name" : "Steve_Bingham",
      "indices" : [ 51, 65 ],
      "id_str" : "21244878",
      "id" : 21244878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ldMrhVCU",
      "expanded_url" : "http:\/\/bit.ly\/xGDgzK",
      "display_url" : "bit.ly\/xGDgzK"
    } ]
  },
  "geo" : { },
  "id_str" : "170297225027653632",
  "text" : "RT @Harmerj: Mulling over my visit to Israel  with @Steve_Bingham http:\/\/t.co\/ldMrhVCU &lt;----interesting reflections",
  "id" : 170297225027653632,
  "created_at" : "2012-02-17 00:03:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Excellence",
      "screen_name" : "GExcellence",
      "indices" : [ 3, 15 ],
      "id_str" : "176417512",
      "id" : 176417512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Uw3ze5Zh",
      "expanded_url" : "http:\/\/bbc.in\/wMuVP0",
      "display_url" : "bbc.in\/wMuVP0"
    } ]
  },
  "geo" : { },
  "id_str" : "169852202662379520",
  "text" : "RT @GExcellence:http:\/\/t.co\/Uw3ze5Zh&lt;---what's a good word to describe state broadcaster attempt to defuse public anger?",
  "id" : 169852202662379520,
  "created_at" : "2012-02-15 18:34:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 80, 95 ],
      "id_str" : "67682458",
      "id" : 67682458
    }, {
      "name" : "elton naicker",
      "screen_name" : "elt",
      "indices" : [ 110, 114 ],
      "id_str" : "131938942",
      "id" : 131938942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "edtech",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/vLga9vph",
      "expanded_url" : "http:\/\/www.bbchelloworld.co.uk\/",
      "display_url" : "bbchelloworld.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "169707547329175552",
  "text" : "BBC revives computer literacy project, Raspberry Pi based! http:\/\/t.co\/vLga9vph @eltdigitalplay #gamification @ELT #edtech",
  "id" : 169707547329175552,
  "created_at" : "2012-02-15 09:00:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/Ik0HNY3k",
      "expanded_url" : "http:\/\/youtu.be\/IngvNUaWvck",
      "display_url" : "youtu.be\/IngvNUaWvck"
    } ]
  },
  "geo" : { },
  "id_str" : "169556964618141697",
  "text" : "pre-fixes in song! http:\/\/t.co\/Ik0HNY3k hatip Langauge Log",
  "id" : 169556964618141697,
  "created_at" : "2012-02-14 23:01:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169427453368999936",
  "geo" : { },
  "id_str" : "169436240045801472",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt unfollowed a couple of peeps who'd tweeted some bog standard 'holiday' lessons =) last keddie lessonstream lesson was okay",
  "id" : 169436240045801472,
  "in_reply_to_status_id" : 169427453368999936,
  "created_at" : "2012-02-14 15:02:02 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169203067839971328",
  "geo" : { },
  "id_str" : "169203988732981248",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard is one of the reasons the wide availability of undubbed English programmes?",
  "id" : 169203988732981248,
  "in_reply_to_status_id" : 169203067839971328,
  "created_at" : "2012-02-13 23:39:09 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 76, 88 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/A9nCCHXY",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2r",
      "display_url" : "wp.me\/pgHyE-2r"
    } ]
  },
  "geo" : { },
  "id_str" : "169198026777300994",
  "text" : "Film extract to illustrate international communication http:\/\/t.co\/A9nCCHXY @TESOLFrance",
  "id" : 169198026777300994,
  "created_at" : "2012-02-13 23:15:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 3, 14 ],
      "id_str" : "14548913",
      "id" : 14548913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/jbD886Or",
      "expanded_url" : "http:\/\/www.onlineteachingdegree.com\/ipads-vs-textbooks\/",
      "display_url" : "onlineteachingdegree.com\/ipads-vs-textb\u2026"
    }, {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/aznAwSTy",
      "expanded_url" : "http:\/\/fb.me\/1uaH2yl8a",
      "display_url" : "fb.me\/1uaH2yl8a"
    } ]
  },
  "geo" : { },
  "id_str" : "169165569453600769",
  "text" : "RT @NikPeachey: iPad vs textbook infographic http:\/\/t.co\/jbD886Or http:\/\/t.co\/aznAwSTy",
  "id" : 169165569453600769,
  "created_at" : "2012-02-13 21:06:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/Zlue9LjR",
      "expanded_url" : "http:\/\/leninology.blogspot.com\/2012\/02\/in-athens-tahrir.html",
      "display_url" : "leninology.blogspot.com\/2012\/02\/in-ath\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169155262656163841",
  "text" : "In Athens, Tahrir http:\/\/t.co\/Zlue9LjR &lt;---future present?",
  "id" : 169155262656163841,
  "created_at" : "2012-02-13 20:25:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/nqBdLrpE",
      "expanded_url" : "http:\/\/youtu.be\/NUVrvOSDQ-s",
      "display_url" : "youtu.be\/NUVrvOSDQ-s"
    } ]
  },
  "geo" : { },
  "id_str" : "169148975268630528",
  "text" : "why does this make some wierd sense? cricket engelse http:\/\/t.co\/nqBdLrpE =)",
  "id" : 169148975268630528,
  "created_at" : "2012-02-13 20:00:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moira Hunter",
      "screen_name" : "MoiraH",
      "indices" : [ 3, 10 ],
      "id_str" : "6206432",
      "id" : 6206432
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 63, 71 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/BvbjeBei",
      "expanded_url" : "http:\/\/youtu.be\/oyZxzkd-Jsk",
      "display_url" : "youtu.be\/oyZxzkd-Jsk"
    } ]
  },
  "geo" : { },
  "id_str" : "169135555198730240",
  "text" : "RT @MoiraH: Why I LOVE My 3D Printer: http:\/\/t.co\/BvbjeBei via @youtube&lt;---which one of the seven dwarfs is that? ;)",
  "id" : 169135555198730240,
  "created_at" : "2012-02-13 19:07:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elearning",
      "indices" : [ 80, 90 ]
    }, {
      "text" : "edchat",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "elt",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "esl",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "homeschool",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "edtools",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/kfCBncll",
      "expanded_url" : "http:\/\/meetu.ps\/7k30P",
      "display_url" : "meetu.ps\/7k30P"
    } ]
  },
  "geo" : { },
  "id_str" : "168966449686265856",
  "text" : "English teachers in Paris http:\/\/t.co\/kfCBncll social inc ELT talk with Pearson #elearning #edchat #elt #esl #homeschool #edtools",
  "id" : 168966449686265856,
  "created_at" : "2012-02-13 07:55:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 0, 12 ],
      "id_str" : "23870533",
      "id" : 23870533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168835455092137984",
  "in_reply_to_user_id" : 23870533,
  "text" : "@creedpatton sorry forgot to say cheers for RT",
  "id" : 168835455092137984,
  "created_at" : "2012-02-12 23:14:43 +0000",
  "in_reply_to_screen_name" : "creedpatton",
  "in_reply_to_user_id_str" : "23870533",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EDTECH HULK",
      "screen_name" : "EDTECHHULK",
      "indices" : [ 47, 58 ],
      "id_str" : "235000147",
      "id" : 235000147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/ebVtU2eK",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1T",
      "display_url" : "wp.me\/pgHyE-1T"
    } ]
  },
  "geo" : { },
  "id_str" : "168822632937046016",
  "text" : "Is one Ipad worth it? No! http:\/\/t.co\/ebVtU2eK @EDTECHHULK what say you?",
  "id" : 168822632937046016,
  "created_at" : "2012-02-12 22:23:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/ebVtU2eK",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1T",
      "display_url" : "wp.me\/pgHyE-1T"
    } ]
  },
  "geo" : { },
  "id_str" : "168743490895884288",
  "text" : "Is one Ipad worth it? No! http:\/\/t.co\/ebVtU2eK",
  "id" : 168743490895884288,
  "created_at" : "2012-02-12 17:09:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168393387400118272",
  "geo" : { },
  "id_str" : "168634947203112960",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan thanks for the RT :)",
  "id" : 168634947203112960,
  "in_reply_to_status_id" : 168393387400118272,
  "created_at" : "2012-02-12 09:57:59 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 36, 47 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168250795454771200",
  "text" : "How to explain a word using corpora @leoselivan",
  "id" : 168250795454771200,
  "created_at" : "2012-02-11 08:31:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLFR",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168250289902718976",
  "text" : "RT @TESOLFrance: Feb 11th #TESOLFR welcomes Steve Flinders from York Associates for a workshop on Developing People Internationally. 35+ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TESOLFR",
        "indices" : [ 9, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168114932427128832",
    "text" : "Feb 11th #TESOLFR welcomes Steve Flinders from York Associates for a workshop on Developing People Internationally. 35+ people registered!",
    "id" : 168114932427128832,
    "created_at" : "2012-02-10 23:31:37 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 168250289902718976,
  "created_at" : "2012-02-11 08:29:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vance Stevens",
      "screen_name" : "VanceS",
      "indices" : [ 3, 10 ],
      "id_str" : "5981982",
      "id" : 5981982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "m1ict",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168023683883991040",
  "text" : "RT @VanceS: nicky hockley says we're in a state of perpetual beta at #m1ict",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "m1ict",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168023178914963456",
    "text" : "nicky hockley says we're in a state of perpetual beta at #m1ict",
    "id" : 168023178914963456,
    "created_at" : "2012-02-10 17:27:02 +0000",
    "user" : {
      "name" : "Vance Stevens",
      "screen_name" : "VanceS",
      "protected" : false,
      "id_str" : "5981982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746211022583668738\/LJB-Kr3r_normal.jpg",
      "id" : 5981982,
      "verified" : false
    }
  },
  "id" : 168023683883991040,
  "created_at" : "2012-02-10 17:29:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 67, 79 ],
      "id_str" : "23870533",
      "id" : 23870533
    }, {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 80, 95 ],
      "id_str" : "67682458",
      "id" : 67682458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EVO2012",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "tllg",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "gamifcation",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/wi4VEwUM",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1I",
      "display_url" : "wp.me\/pgHyE-1I"
    } ]
  },
  "geo" : { },
  "id_str" : "168015808235175939",
  "text" : "Reflections on using interactive fiction 9.05 http:\/\/t.co\/wi4VEwUM @creedpatton @eltdigitalplay #EVO2012 #tllg #gamifcation",
  "id" : 168015808235175939,
  "created_at" : "2012-02-10 16:57:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 3, 17 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EVO2012",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "tllg",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "gamifcation",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MdlXzbC2",
      "expanded_url" : "http:\/\/bit.ly\/xaAjYF",
      "display_url" : "bit.ly\/xaAjYF"
    } ]
  },
  "geo" : { },
  "id_str" : "167714059666472960",
  "text" : "RT @grahamstanley: Final live session for the #EVO2012 #tllg #gamifcation through language learning and teaching session http:\/\/t.co\/Mdl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EVO2012",
        "indices" : [ 27, 35 ]
      }, {
        "text" : "tllg",
        "indices" : [ 36, 41 ]
      }, {
        "text" : "gamifcation",
        "indices" : [ 42, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/MdlXzbC2",
        "expanded_url" : "http:\/\/bit.ly\/xaAjYF",
        "display_url" : "bit.ly\/xaAjYF"
      } ]
    },
    "geo" : { },
    "id_str" : "167706983586205697",
    "text" : "Final live session for the #EVO2012 #tllg #gamifcation through language learning and teaching session http:\/\/t.co\/MdlXzbC2 - please join us",
    "id" : 167706983586205697,
    "created_at" : "2012-02-09 20:30:35 +0000",
    "user" : {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "protected" : false,
      "id_str" : "74143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609337542530371584\/NtU8gHwV_normal.jpg",
      "id" : 74143,
      "verified" : false
    }
  },
  "id" : 167714059666472960,
  "created_at" : "2012-02-09 20:58:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/FfdUo7sJ",
      "expanded_url" : "http:\/\/htwins.net\/scale2\/",
      "display_url" : "htwins.net\/scale2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "167631220828672000",
  "text" : "Vertigo alert! Scale of the universe http:\/\/t.co\/FfdUo7sJ",
  "id" : 167631220828672000,
  "created_at" : "2012-02-09 15:29:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cheimi10",
      "screen_name" : "cheimi10",
      "indices" : [ 57, 66 ],
      "id_str" : "2547295525",
      "id" : 2547295525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/w4106IKo",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1t",
      "display_url" : "wp.me\/pgHyE-1t"
    } ]
  },
  "geo" : { },
  "id_str" : "167372450462572545",
  "text" : "How to explain a word using corpora http:\/\/t.co\/w4106IKo @cheimi10",
  "id" : 167372450462572545,
  "created_at" : "2012-02-08 22:21:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Stannard",
      "screen_name" : "russell1955",
      "indices" : [ 3, 15 ],
      "id_str" : "14796284",
      "id" : 14796284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "edchat",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "elearn",
      "indices" : [ 115, 122 ]
    }, {
      "text" : "elt",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/NaSQTHOJ",
      "expanded_url" : "http:\/\/bit.ly\/fwj25R",
      "display_url" : "bit.ly\/fwj25R"
    } ]
  },
  "geo" : { },
  "id_str" : "167334098078150657",
  "text" : "RT @russell1955: step by step guide to using Twitter and building following http:\/\/t.co\/NaSQTHOJ   #edtech #edchat #elearn #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "edchat",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "elearn",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "elt",
        "indices" : [ 106, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/NaSQTHOJ",
        "expanded_url" : "http:\/\/bit.ly\/fwj25R",
        "display_url" : "bit.ly\/fwj25R"
      } ]
    },
    "geo" : { },
    "id_str" : "167328001409822720",
    "text" : "step by step guide to using Twitter and building following http:\/\/t.co\/NaSQTHOJ   #edtech #edchat #elearn #elt",
    "id" : 167328001409822720,
    "created_at" : "2012-02-08 19:24:38 +0000",
    "user" : {
      "name" : "Russell Stannard",
      "screen_name" : "russell1955",
      "protected" : false,
      "id_str" : "14796284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740709795\/RussellELTons_normal.jpg",
      "id" : 14796284,
      "verified" : false
    }
  },
  "id" : 167334098078150657,
  "created_at" : "2012-02-08 19:48:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Stannard",
      "screen_name" : "russell1955",
      "indices" : [ 67, 79 ],
      "id_str" : "14796284",
      "id" : 14796284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/oHk1GpI7",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-i",
      "display_url" : "wp.me\/pgHyE-i"
    } ]
  },
  "geo" : { },
  "id_str" : "167333973540872193",
  "text" : "Social media and professional development http:\/\/t.co\/oHk1GpI7 via @russell1955",
  "id" : 167333973540872193,
  "created_at" : "2012-02-08 19:48:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 38, 53 ],
      "id_str" : "67682458",
      "id" : 67682458
    }, {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 54, 66 ],
      "id_str" : "23870533",
      "id" : 23870533
    }, {
      "name" : "kylemawer",
      "screen_name" : "KyleMawer",
      "indices" : [ 67, 77 ],
      "id_str" : "41313717",
      "id" : 41313717
    }, {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 78, 92 ],
      "id_str" : "74143",
      "id" : 74143
    }, {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 93, 102 ],
      "id_str" : "130975050",
      "id" : 130975050
    }, {
      "name" : "Ozge Karaoglu Ergen",
      "screen_name" : "ozge",
      "indices" : [ 103, 108 ],
      "id_str" : "12847482",
      "id" : 12847482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/os6DqUhW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-S",
      "display_url" : "wp.me\/pgHyE-S"
    } ]
  },
  "geo" : { },
  "id_str" : "166996182873284608",
  "text" : "Ready Player One http:\/\/t.co\/os6DqUhW @eltdigitalplay @creedpatton @KyleMawer @grahamstanley @bcnpaul1 @ozge",
  "id" : 166996182873284608,
  "created_at" : "2012-02-07 21:26:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 78, 86 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/zxFSkEbV",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-r",
      "display_url" : "wp.me\/pgHyE-r"
    } ]
  },
  "geo" : { },
  "id_str" : "166885858983682048",
  "text" : "SoundCloud commenting and enhancing listening activities http:\/\/t.co\/zxFSkEbV @seburnt",
  "id" : 166885858983682048,
  "created_at" : "2012-02-07 14:07:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gbl",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "tllg",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "EVO2012",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/cRXSP1Js",
      "expanded_url" : "http:\/\/www.wired.com\/magazine\/2011\/12\/ff_cowclicker\/",
      "display_url" : "wired.com\/magazine\/2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165449761229512705",
  "text" : "some dissenting views to 'gamification' in The Curse of Cow Clicker http:\/\/t.co\/cRXSP1Js #gbl #tllg #EVO2012 #IATEFL",
  "id" : 165449761229512705,
  "created_at" : "2012-02-03 15:01:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]