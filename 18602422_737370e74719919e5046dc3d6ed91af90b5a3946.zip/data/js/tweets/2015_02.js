Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/wFKSfkarya",
      "expanded_url" : "http:\/\/ow.ly\/JzbvI",
      "display_url" : "ow.ly\/JzbvI"
    } ]
  },
  "geo" : { },
  "id_str" : "571591158645702656",
  "text" : "RT @umasslinguistic: A massive database now translates news in 65 languages in real time http:\/\/t.co\/wFKSfkarya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/wFKSfkarya",
        "expanded_url" : "http:\/\/ow.ly\/JzbvI",
        "display_url" : "ow.ly\/JzbvI"
      } ]
    },
    "geo" : { },
    "id_str" : "571419679086022656",
    "text" : "A massive database now translates news in 65 languages in real time http:\/\/t.co\/wFKSfkarya",
    "id" : 571419679086022656,
    "created_at" : "2015-02-27 21:20:42 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 571591158645702656,
  "created_at" : "2015-02-28 08:42:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/WuKu5q3Olv",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1425062994.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571434174739058689",
  "text" : "Snowmail...\"the poster boy for Islamic State\u2019s barbarism.\"... short email to Cathy Newman...http:\/\/t.co\/WuKu5q3Olv",
  "id" : 571434174739058689,
  "created_at" : "2015-02-27 22:18:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cybersecurity",
      "indices" : [ 83, 97 ]
    }, {
      "text" : "NSA",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VIWYYDPThD",
      "expanded_url" : "http:\/\/ow.ly\/JCbQs",
      "display_url" : "ow.ly\/JCbQs"
    } ]
  },
  "geo" : { },
  "id_str" : "571410455186554880",
  "text" : "RT @patrickDurusau: RP Russian researchers expose breakthrough U.S. spying program #cybersecurity #NSA http:\/\/t.co\/VIWYYDPThD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cybersecurity",
        "indices" : [ 63, 77 ]
      }, {
        "text" : "NSA",
        "indices" : [ 78, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/VIWYYDPThD",
        "expanded_url" : "http:\/\/ow.ly\/JCbQs",
        "display_url" : "ow.ly\/JCbQs"
      } ]
    },
    "geo" : { },
    "id_str" : "571399986619015168",
    "text" : "RP Russian researchers expose breakthrough U.S. spying program #cybersecurity #NSA http:\/\/t.co\/VIWYYDPThD",
    "id" : 571399986619015168,
    "created_at" : "2015-02-27 20:02:27 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 571410455186554880,
  "created_at" : "2015-02-27 20:44:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/nVHeD4c6D9",
      "expanded_url" : "http:\/\/youtu.be\/aE8hn5Yv9NA",
      "display_url" : "youtu.be\/aE8hn5Yv9NA"
    } ]
  },
  "geo" : { },
  "id_str" : "571363478805590016",
  "text" : "The Secret Untold History of Commodore Computers: http:\/\/t.co\/nVHeD4c6D9 via @YouTube",
  "id" : 571363478805590016,
  "created_at" : "2015-02-27 17:37:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 3, 15 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/uTccfhXTew",
      "expanded_url" : "https:\/\/www.surveymonkey.com\/s\/Y3KNJST",
      "display_url" : "surveymonkey.com\/s\/Y3KNJST"
    } ]
  },
  "geo" : { },
  "id_str" : "571358406340182017",
  "text" : "RT @Shaunwilden: Please help a colleague with her research on ereaders by taking this 2 minute survey https:\/\/t.co\/uTccfhXTew #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/uTccfhXTew",
        "expanded_url" : "https:\/\/www.surveymonkey.com\/s\/Y3KNJST",
        "display_url" : "surveymonkey.com\/s\/Y3KNJST"
      } ]
    },
    "geo" : { },
    "id_str" : "571356382164881409",
    "text" : "Please help a colleague with her research on ereaders by taking this 2 minute survey https:\/\/t.co\/uTccfhXTew #eltchat",
    "id" : 571356382164881409,
    "created_at" : "2015-02-27 17:09:11 +0000",
    "user" : {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "protected" : false,
      "id_str" : "15350512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443867028005212160\/pvFEA7Px_normal.jpeg",
      "id" : 15350512,
      "verified" : false
    }
  },
  "id" : 571358406340182017,
  "created_at" : "2015-02-27 17:17:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571237033642827777",
  "geo" : { },
  "id_str" : "571257629080756224",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl shame quote is from an Islamic bigot",
  "id" : 571257629080756224,
  "in_reply_to_status_id" : 571237033642827777,
  "created_at" : "2015-02-27 10:36:46 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/DPmr6lqJIw",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1424974953.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571013072908886016",
  "text" : "Snowmail...\"The Islamic State terrorist 'Jihadi John'\"...short email to 6 Pilgers... http:\/\/t.co\/DPmr6lqJIw",
  "id" : 571013072908886016,
  "created_at" : "2015-02-26 18:25:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WUFYS",
      "screen_name" : "wufys",
      "indices" : [ 111, 117 ],
      "id_str" : "150027200",
      "id" : 150027200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/WBBGdhZ6ap",
      "expanded_url" : "http:\/\/wakeupfromyourslumber.com\/there-is-no-such-thing-as-russian-language-deputy-and-mp-for-poroshenkos-party\/",
      "display_url" : "wakeupfromyourslumber.com\/there-is-no-su\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570983079050932224",
  "text" : "\"There is no such thing as Russian language\" - Deputy and MP for Poroshenko's Party http:\/\/t.co\/WBBGdhZ6ap via @WUFYS",
  "id" : 570983079050932224,
  "created_at" : "2015-02-26 16:25:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570972234359148544",
  "geo" : { },
  "id_str" : "570972865920679937",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble ah right yeah heard of that have u used it?",
  "id" : 570972865920679937,
  "in_reply_to_status_id" : 570972234359148544,
  "created_at" : "2015-02-26 15:45:14 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570969933775015936",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble hi what was the tool u mentioned  u got via thesis whisperer in your q&amp;A section of Cultures of EAP video talk? thx",
  "id" : 570969933775015936,
  "created_at" : "2015-02-26 15:33:34 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AI",
      "indices" : [ 64, 67 ]
    }, {
      "text" : "Google",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "DeepMind",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ZhBWoHGlQK",
      "expanded_url" : "http:\/\/ow.ly\/JEW2o",
      "display_url" : "ow.ly\/JEW2o"
    } ]
  },
  "geo" : { },
  "id_str" : "570910747049512960",
  "text" : "RT @patrickDurusau: Elon Musk Must Be Wringing His Hands, Again #AI #Google #DeepMind http:\/\/t.co\/ZhBWoHGlQK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AI",
        "indices" : [ 44, 47 ]
      }, {
        "text" : "Google",
        "indices" : [ 48, 55 ]
      }, {
        "text" : "DeepMind",
        "indices" : [ 56, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/ZhBWoHGlQK",
        "expanded_url" : "http:\/\/ow.ly\/JEW2o",
        "display_url" : "ow.ly\/JEW2o"
      } ]
    },
    "geo" : { },
    "id_str" : "570886372921368577",
    "text" : "Elon Musk Must Be Wringing His Hands, Again #AI #Google #DeepMind http:\/\/t.co\/ZhBWoHGlQK",
    "id" : 570886372921368577,
    "created_at" : "2015-02-26 10:01:32 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 570910747049512960,
  "created_at" : "2015-02-26 11:38:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/t8JE2oYmlc",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1586",
      "display_url" : "cass.lancs.ac.uk\/?p=1586"
    } ]
  },
  "geo" : { },
  "id_str" : "570902621634088960",
  "text" : "RT @CorpusSocialSci: New CASS Briefing available: How to communicate successfully in English? Exploring the Trinity Lancaster Corpus http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/t8JE2oYmlc",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1586",
        "display_url" : "cass.lancs.ac.uk\/?p=1586"
      } ]
    },
    "geo" : { },
    "id_str" : "570900104384815105",
    "text" : "New CASS Briefing available: How to communicate successfully in English? Exploring the Trinity Lancaster Corpus http:\/\/t.co\/t8JE2oYmlc",
    "id" : 570900104384815105,
    "created_at" : "2015-02-26 10:56:06 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 570902621634088960,
  "created_at" : "2015-02-26 11:06:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 43, 51 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/yjV8tPs3Zd",
      "expanded_url" : "http:\/\/youtu.be\/kgzyOAqwHjI",
      "display_url" : "youtu.be\/kgzyOAqwHjI"
    } ]
  },
  "geo" : { },
  "id_str" : "570894853992796160",
  "text" : "Banksy in Gaza: http:\/\/t.co\/yjV8tPs3Zd via @YouTube",
  "id" : 570894853992796160,
  "created_at" : "2015-02-26 10:35:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Roy Greenslade",
      "screen_name" : "GreensladeR",
      "indices" : [ 80, 92 ],
      "id_str" : "20326751",
      "id" : 20326751
    }, {
      "name" : "Simon Kelner",
      "screen_name" : "Simon_Kelner",
      "indices" : [ 93, 106 ],
      "id_str" : "219289074",
      "id" : 219289074
    }, {
      "name" : "Archie Bland",
      "screen_name" : "archiebland",
      "indices" : [ 107, 119 ],
      "id_str" : "36780720",
      "id" : 36780720
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 120, 132 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xCv81PtS3s",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/787-peter-oborne.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570887896225488896",
  "text" : "RT @medialens: 'Corrosive, Shallow, Herd-Like And Gross' - Oborne And The Media @GreensladeR @Simon_Kelner @archiebland @OwenJones84 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roy Greenslade",
        "screen_name" : "GreensladeR",
        "indices" : [ 65, 77 ],
        "id_str" : "20326751",
        "id" : 20326751
      }, {
        "name" : "Simon Kelner",
        "screen_name" : "Simon_Kelner",
        "indices" : [ 78, 91 ],
        "id_str" : "219289074",
        "id" : 219289074
      }, {
        "name" : "Archie Bland",
        "screen_name" : "archiebland",
        "indices" : [ 92, 104 ],
        "id_str" : "36780720",
        "id" : 36780720
      }, {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 105, 117 ],
        "id_str" : "65045121",
        "id" : 65045121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xCv81PtS3s",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/787-peter-oborne.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570545388555542528",
    "text" : "'Corrosive, Shallow, Herd-Like And Gross' - Oborne And The Media @GreensladeR @Simon_Kelner @archiebland @OwenJones84 http:\/\/t.co\/xCv81PtS3s",
    "id" : 570545388555542528,
    "created_at" : "2015-02-25 11:26:35 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 570887896225488896,
  "created_at" : "2015-02-26 10:07:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 48, 63 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/3VPuX7xAaW",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4P9",
      "display_url" : "wp.me\/p93oK-4P9"
    } ]
  },
  "geo" : { },
  "id_str" : "570531625727090689",
  "text" : "Tax-Dodging is Theft http:\/\/t.co\/3VPuX7xAaW via @bellacaledonia",
  "id" : 570531625727090689,
  "created_at" : "2015-02-25 10:31:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/aqj1lFxrhk",
      "expanded_url" : "http:\/\/bit.ly\/1FngC7M",
      "display_url" : "bit.ly\/1FngC7M"
    } ]
  },
  "geo" : { },
  "id_str" : "570520421960982528",
  "text" : "RT @DonaldClark: Astonishing story about \u00A31.27 BILLION wasted in UK HE expansion http:\/\/t.co\/aqj1lFxrhk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/aqj1lFxrhk",
        "expanded_url" : "http:\/\/bit.ly\/1FngC7M",
        "display_url" : "bit.ly\/1FngC7M"
      } ]
    },
    "geo" : { },
    "id_str" : "570294638302638080",
    "text" : "Astonishing story about \u00A31.27 BILLION wasted in UK HE expansion http:\/\/t.co\/aqj1lFxrhk",
    "id" : 570294638302638080,
    "created_at" : "2015-02-24 18:50:11 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 570520421960982528,
  "created_at" : "2015-02-25 09:47:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570350085386563584",
  "geo" : { },
  "id_str" : "570352990931918848",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K uh-oh :)",
  "id" : 570352990931918848,
  "in_reply_to_status_id" : 570350085386563584,
  "created_at" : "2015-02-24 22:42:04 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/b0XlP2ymKp",
      "expanded_url" : "http:\/\/www.backpackinglight.com\/cgi-bin\/backpackinglight\/forums\/thread_display.html?forum_thread_id=52688",
      "display_url" : "backpackinglight.com\/cgi-bin\/backpa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570343756957757440",
  "text" : "What kind of pole is strongest? http:\/\/t.co\/b0XlP2ymKp for those interested :\/",
  "id" : 570343756957757440,
  "created_at" : "2015-02-24 22:05:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/WoN9BotKbU",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/02\/20\/some-obvious-notes-on-mitra-and-crawley-2014\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/02\/20\/som\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "570336147961831426",
  "geo" : { },
  "id_str" : "570341006391914497",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K new conference season means more mitra means more mitra posts arghhh! run away! https:\/\/t.co\/WoN9BotKbU",
  "id" : 570341006391914497,
  "in_reply_to_status_id" : 570336147961831426,
  "created_at" : "2015-02-24 21:54:27 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 82, 98 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/XhPB2WNXm9",
      "expanded_url" : "http:\/\/wp.me\/p2ZJCG-ou7",
      "display_url" : "wp.me\/p2ZJCG-ou7"
    } ]
  },
  "geo" : { },
  "id_str" : "570326603630186497",
  "text" : "Doubts about ELF pronunciation \u2013 1) schwa within words http:\/\/t.co\/XhPB2WNXm9 via @wordpressdotcom",
  "id" : 570326603630186497,
  "created_at" : "2015-02-24 20:57:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/4GO9xFS84t",
      "expanded_url" : "http:\/\/www.washingtonsblog.com\/2015\/02\/snowden-calls-disobedience-u-s-government.html",
      "display_url" : "washingtonsblog.com\/2015\/02\/snowde\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570223232500023296",
  "text" : "Snowden Calls for Disobedience Against the U.S. Gover\u2026 http:\/\/t.co\/4GO9xFS84t",
  "id" : 570223232500023296,
  "created_at" : "2015-02-24 14:06:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569997775204589568",
  "geo" : { },
  "id_str" : "569998160824799232",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas no worries was interested in answer myself :)",
  "id" : 569998160824799232,
  "in_reply_to_status_id" : 569997775204589568,
  "created_at" : "2015-02-23 23:12:06 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/BkDKj3jgDH",
      "expanded_url" : "http:\/\/lav.io\/2015\/02\/c-span-excerpts\/",
      "display_url" : "lav.io\/2015\/02\/c-span\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569996423594446848",
  "text" : "RT @sam_lavigne: Autogenerated CSPAN excerpts: http:\/\/t.co\/BkDKj3jgDH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/BkDKj3jgDH",
        "expanded_url" : "http:\/\/lav.io\/2015\/02\/c-span-excerpts\/",
        "display_url" : "lav.io\/2015\/02\/c-span\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569695454344179712",
    "text" : "Autogenerated CSPAN excerpts: http:\/\/t.co\/BkDKj3jgDH",
    "id" : 569695454344179712,
    "created_at" : "2015-02-23 03:09:15 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 569996423594446848,
  "created_at" : "2015-02-23 23:05:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 3, 17 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "English",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "ISIS",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "wasntexpectingthat",
      "indices" : [ 87, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Go3UBHhN3Y",
      "expanded_url" : "http:\/\/ind.pn\/1a6nAoc",
      "display_url" : "ind.pn\/1a6nAoc"
    } ]
  },
  "geo" : { },
  "id_str" : "569992240099155968",
  "text" : "RT @Glenn_Hadikin: ISIS opening English schools? http:\/\/t.co\/Go3UBHhN3Y #English #ISIS #wasntexpectingthat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "English",
        "indices" : [ 53, 61 ]
      }, {
        "text" : "ISIS",
        "indices" : [ 62, 67 ]
      }, {
        "text" : "wasntexpectingthat",
        "indices" : [ 68, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/Go3UBHhN3Y",
        "expanded_url" : "http:\/\/ind.pn\/1a6nAoc",
        "display_url" : "ind.pn\/1a6nAoc"
      } ]
    },
    "geo" : { },
    "id_str" : "569929197440905216",
    "text" : "ISIS opening English schools? http:\/\/t.co\/Go3UBHhN3Y #English #ISIS #wasntexpectingthat",
    "id" : 569929197440905216,
    "created_at" : "2015-02-23 18:38:04 +0000",
    "user" : {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "protected" : false,
      "id_str" : "24455799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451444841910530052\/M3o_yNR1_normal.jpeg",
      "id" : 24455799,
      "verified" : false
    }
  },
  "id" : 569992240099155968,
  "created_at" : "2015-02-23 22:48:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zPvlLwDb9z",
      "expanded_url" : "http:\/\/www.lognostics.co.uk\/tools\/D_Tools.zip",
      "display_url" : "lognostics.co.uk\/tools\/D_Tools.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569944485326692353",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas hi another win prog to calculate D statistic http:\/\/t.co\/zPvlLwDb9z not used it but it has useful doc about ttr measures",
  "id" : 569944485326692353,
  "created_at" : "2015-02-23 19:38:49 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569911198218641408",
  "geo" : { },
  "id_str" : "569939657213001728",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland thx may be able to lurk :)",
  "id" : 569939657213001728,
  "in_reply_to_status_id" : 569911198218641408,
  "created_at" : "2015-02-23 19:19:37 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "tefl",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/D8iTHBkJ1w",
      "expanded_url" : "http:\/\/languageworkergas.com\/",
      "display_url" : "languageworkergas.com"
    } ]
  },
  "geo" : { },
  "id_str" : "569855201320013824",
  "text" : "RT @josipa74: Berlin's own teacher-run organisation - Berlin LW GAS - now has a website in BETA! http:\/\/t.co\/D8iTHBkJ1w #elt #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 106, 110 ]
      }, {
        "text" : "tefl",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/D8iTHBkJ1w",
        "expanded_url" : "http:\/\/languageworkergas.com\/",
        "display_url" : "languageworkergas.com"
      } ]
    },
    "geo" : { },
    "id_str" : "569854438275469312",
    "text" : "Berlin's own teacher-run organisation - Berlin LW GAS - now has a website in BETA! http:\/\/t.co\/D8iTHBkJ1w #elt #tefl",
    "id" : 569854438275469312,
    "created_at" : "2015-02-23 13:41:00 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 569855201320013824,
  "created_at" : "2015-02-23 13:44:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLW Nottingham",
      "screen_name" : "UoN_CLW",
      "indices" : [ 0, 8 ],
      "id_str" : "3055425035",
      "id" : 3055425035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/HWQ12J13Bd",
      "expanded_url" : "http:\/\/www.nottingham.ac.uk\/research\/groups\/cral\/research-groups\/clw\/index.aspx",
      "display_url" : "nottingham.ac.uk\/research\/group\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569855034349002752",
  "in_reply_to_user_id" : 3055425035,
  "text" : "@UoN_CLW hi your list of talks and discussions here look grt http:\/\/t.co\/HWQ12J13Bd any plans to share presentation slides? thx",
  "id" : 569855034349002752,
  "created_at" : "2015-02-23 13:43:22 +0000",
  "in_reply_to_screen_name" : "UoN_CLW",
  "in_reply_to_user_id_str" : "3055425035",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LxptOqcoEq",
      "expanded_url" : "http:\/\/www.morningstaronline.co.uk\/a-146e-Another-nail-in-the-coffin-of-the-case-for-Libyan-intervention#.VOsc4RbfqJZ.twitter",
      "display_url" : "morningstaronline.co.uk\/a-146e-Another\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569836170944884736",
  "text" : "Morning Star :: Another nail in the coffin of the case for Libyan \u2018intervention\u2019 http:\/\/t.co\/LxptOqcoEq",
  "id" : 569836170944884736,
  "created_at" : "2015-02-23 12:28:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 136, 140 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teflequity",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3nTIeN4pT0",
      "expanded_url" : "http:\/\/wp.me\/P4Gcmh-35",
      "display_url" : "wp.me\/P4Gcmh-35"
    } ]
  },
  "geo" : { },
  "id_str" : "569559252299341826",
  "text" : "RT @DavidHarbinson: Please share this survey with your students (and recruiters if you know any) #teflequity http:\/\/t.co\/3nTIeN4pT0 via @Ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marek Kiczkowiak",
        "screen_name" : "MarekKiczkowiak",
        "indices" : [ 116, 132 ],
        "id_str" : "2561325079",
        "id" : 2561325079
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teflequity",
        "indices" : [ 77, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/3nTIeN4pT0",
        "expanded_url" : "http:\/\/wp.me\/P4Gcmh-35",
        "display_url" : "wp.me\/P4Gcmh-35"
      } ]
    },
    "geo" : { },
    "id_str" : "569545626066661376",
    "text" : "Please share this survey with your students (and recruiters if you know any) #teflequity http:\/\/t.co\/3nTIeN4pT0 via @MarekKiczkowiak",
    "id" : 569545626066661376,
    "created_at" : "2015-02-22 17:13:53 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 569559252299341826,
  "created_at" : "2015-02-22 18:08:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 47, 63 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/2jkZW2v9lF",
      "expanded_url" : "http:\/\/wp.me\/pJw7u-1eS",
      "display_url" : "wp.me\/pJw7u-1eS"
    } ]
  },
  "geo" : { },
  "id_str" : "569423877551607808",
  "text" : "I is for Intonation http:\/\/t.co\/2jkZW2v9lF via @wordpressdotcom",
  "id" : 569423877551607808,
  "created_at" : "2015-02-22 09:10:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Pzk9uTRjZQ",
      "expanded_url" : "http:\/\/childes.psy.cmu.edu\/clan\/",
      "display_url" : "childes.psy.cmu.edu\/clan\/"
    } ]
  },
  "in_reply_to_status_id_str" : "569232756586061825",
  "geo" : { },
  "id_str" : "569245224968589312",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas another program multiplatform u could try CLAN http:\/\/t.co\/Pzk9uTRjZQ",
  "id" : 569245224968589312,
  "in_reply_to_status_id" : 569232756586061825,
  "created_at" : "2015-02-21 21:20:12 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/E0xuWLpWBF",
      "expanded_url" : "https:\/\/umdrive.memphis.edu\/pmmccrth\/public\/software\/software_index.htm",
      "display_url" : "umdrive.memphis.edu\/pmmccrth\/publi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569232756586061825",
  "geo" : { },
  "id_str" : "569235443075702784",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas there is this program for windows https:\/\/t.co\/E0xuWLpWBF",
  "id" : 569235443075702784,
  "in_reply_to_status_id" : 569232756586061825,
  "created_at" : "2015-02-21 20:41:20 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/lGQ0NdQyxa",
      "expanded_url" : "http:\/\/textinspector.com\/workflow",
      "display_url" : "textinspector.com\/workflow"
    } ]
  },
  "in_reply_to_status_id_str" : "569207051156455424",
  "geo" : { },
  "id_str" : "569221335571955712",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas if text is less than 500 you could try http:\/\/t.co\/lGQ0NdQyxa",
  "id" : 569221335571955712,
  "in_reply_to_status_id" : 569207051156455424,
  "created_at" : "2015-02-21 19:45:16 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569164369579405312",
  "geo" : { },
  "id_str" : "569165537059717122",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard hi Rose thx for reading &amp; sharing and for finding it helpful hope yr w\/e is going well",
  "id" : 569165537059717122,
  "in_reply_to_status_id" : 569164369579405312,
  "created_at" : "2015-02-21 16:03:33 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 16, 26 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pron15",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/2MYPEzOE7n",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=J15-i8uKtDE&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=J15-i8\u2026"
    }, {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/AR9uffj9EU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_TjMz6wkV0w",
      "display_url" : "youtube.com\/watch?v=_TjMz6\u2026"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ZlLijxRZba",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EGFusdW9Qu8",
      "display_url" : "youtube.com\/watch?v=EGFusd\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569156566009524224",
  "geo" : { },
  "id_str" : "569159843820527616",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @pronbites somevids from Roslyn cld help https:\/\/t.co\/2MYPEzOE7n, https:\/\/t.co\/AR9uffj9EU, https:\/\/t.co\/ZlLijxRZba #pron15",
  "id" : 569159843820527616,
  "in_reply_to_status_id" : 569156566009524224,
  "created_at" : "2015-02-21 15:40:55 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    }, {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 10, 20 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569146932704231425",
  "geo" : { },
  "id_str" : "569147620653989888",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K @pronbites that is more of a issue with listen&amp;repeat than articulatory approach, i guess?",
  "id" : 569147620653989888,
  "in_reply_to_status_id" : 569146932704231425,
  "created_at" : "2015-02-21 14:52:21 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 11, 20 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569145725407383552",
  "geo" : { },
  "id_str" : "569146105059000320",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites @Wiktor_K doubt people are very far from there mouths :)",
  "id" : 569146105059000320,
  "in_reply_to_status_id" : 569145725407383552,
  "created_at" : "2015-02-21 14:46:20 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Project 252",
      "screen_name" : "proj252",
      "indices" : [ 0, 8 ],
      "id_str" : "2966453283",
      "id" : 2966453283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569144347943444480",
  "geo" : { },
  "id_str" : "569145312557854720",
  "in_reply_to_user_id" : 2966453283,
  "text" : "@proj252 it is a very nice project will definitely keep an eye on it :)",
  "id" : 569145312557854720,
  "in_reply_to_status_id" : 569144347943444480,
  "created_at" : "2015-02-21 14:43:11 +0000",
  "in_reply_to_screen_name" : "proj252",
  "in_reply_to_user_id_str" : "2966453283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Project 252",
      "screen_name" : "proj252",
      "indices" : [ 0, 8 ],
      "id_str" : "2966453283",
      "id" : 2966453283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569127269429592064",
  "geo" : { },
  "id_str" : "569142223218077697",
  "in_reply_to_user_id" : 2966453283,
  "text" : "@proj252 pleasure just noticed a typo when i entered description 'their mosy frequent meanings' thx",
  "id" : 569142223218077697,
  "in_reply_to_status_id" : 569127269429592064,
  "created_at" : "2015-02-21 14:30:54 +0000",
  "in_reply_to_screen_name" : "proj252",
  "in_reply_to_user_id_str" : "2966453283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/X0ej9Z4keo",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/02\/20\/people-have-the-star-trek-computer-backwards\/",
      "display_url" : "hapgood.us\/2015\/02\/20\/peo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568867037344354304",
  "text" : "RT @holden: Some lunchtime thoughts about the Star Trek computer and the Bay Area's lack of history: http:\/\/t.co\/X0ej9Z4keo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/X0ej9Z4keo",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/02\/20\/people-have-the-star-trek-computer-backwards\/",
        "display_url" : "hapgood.us\/2015\/02\/20\/peo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568864224320946177",
    "text" : "Some lunchtime thoughts about the Star Trek computer and the Bay Area's lack of history: http:\/\/t.co\/X0ej9Z4keo",
    "id" : 568864224320946177,
    "created_at" : "2015-02-20 20:06:14 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 568867037344354304,
  "created_at" : "2015-02-20 20:17:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 92, 108 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/pbYJhEz7Ev",
      "expanded_url" : "http:\/\/wp.me\/p4GKyu-1G",
      "display_url" : "wp.me\/p4GKyu-1G"
    } ]
  },
  "geo" : { },
  "id_str" : "568803259240058882",
  "text" : "Give It A Voice: An online project for English Language Teachers http:\/\/t.co\/pbYJhEz7Ev via @wordpressdotcom",
  "id" : 568803259240058882,
  "created_at" : "2015-02-20 16:03:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/5F9eRKkoGA",
      "expanded_url" : "http:\/\/disq.us\/8m99u5",
      "display_url" : "disq.us\/8m99u5"
    } ]
  },
  "geo" : { },
  "id_str" : "568802145312612353",
  "text" : "if u have read all the Demand High debates why not check out comments in Jordan vs Lexical Lab http:\/\/t.co\/5F9eRKkoGA :)",
  "id" : 568802145312612353,
  "created_at" : "2015-02-20 15:59:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568789888369344512",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 thanks for sharing Sophia, enjoy yr w\/e :)",
  "id" : 568789888369344512,
  "created_at" : "2015-02-20 15:10:51 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 3, 13 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/yYvLz7jgSE",
      "expanded_url" : "http:\/\/fb.me\/1Fym20ydA",
      "display_url" : "fb.me\/1Fym20ydA"
    } ]
  },
  "geo" : { },
  "id_str" : "568697509348032512",
  "text" : "RT @pronbites: Summary on today's webinar: \"The Melody of English\" by Tamara Jones and Marnie Reed. Very interesting for us,... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/yYvLz7jgSE",
        "expanded_url" : "http:\/\/fb.me\/1Fym20ydA",
        "display_url" : "fb.me\/1Fym20ydA"
      } ]
    },
    "geo" : { },
    "id_str" : "567772865227804672",
    "text" : "Summary on today's webinar: \"The Melody of English\" by Tamara Jones and Marnie Reed. Very interesting for us,... http:\/\/t.co\/yYvLz7jgSE",
    "id" : 567772865227804672,
    "created_at" : "2015-02-17 19:49:34 +0000",
    "user" : {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "protected" : false,
      "id_str" : "2451770871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744911290766868480\/VQAhoA7h_normal.jpg",
      "id" : 2451770871,
      "verified" : false
    }
  },
  "id" : 568697509348032512,
  "created_at" : "2015-02-20 09:03:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason West",
      "screen_name" : "EnglishOutThere",
      "indices" : [ 3, 19 ],
      "id_str" : "66951936",
      "id" : 66951936
    }, {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 20, 34 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/WoN9Boc9km",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/02\/20\/some-obvious-notes-on-mitra-and-crawley-2014\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/02\/20\/som\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565145257042788352",
  "geo" : { },
  "id_str" : "568676598330880000",
  "in_reply_to_user_id" : 18602422,
  "text" : "hi @EnglishOutThere @GrowMyEnglish  you may find this of interest - Some obvious notes on Mitra and Crawley (2014) https:\/\/t.co\/WoN9Boc9km",
  "id" : 568676598330880000,
  "in_reply_to_status_id" : 565145257042788352,
  "created_at" : "2015-02-20 07:40:41 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568672782109822976",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx for RT have a good w\/e :)",
  "id" : 568672782109822976,
  "created_at" : "2015-02-20 07:25:31 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 10, 21 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568575108857651200",
  "geo" : { },
  "id_str" : "568672670176436225",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @bethcagnol i think with open spaces one can nominate whatever topic one wants no?",
  "id" : 568672670176436225,
  "in_reply_to_status_id" : 568575108857651200,
  "created_at" : "2015-02-20 07:25:04 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 10, 21 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568506132953763840",
  "geo" : { },
  "id_str" : "568569326544019456",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @bethcagnol maybe IATEFL conf  open space could be a venue for such conversations?",
  "id" : 568569326544019456,
  "in_reply_to_status_id" : 568506132953763840,
  "created_at" : "2015-02-20 00:34:25 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568562128254308352",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith hi Kyle thx for RT how ya doing?",
  "id" : 568562128254308352,
  "created_at" : "2015-02-20 00:05:49 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "auselt",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/um1kndjh8G",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-T4",
      "display_url" : "wp.me\/pgHyE-T4"
    } ]
  },
  "geo" : { },
  "id_str" : "568558432996831232",
  "text" : "Some obvious notes on Mitra and Crawley (2014) #eltchat #eltchinwag #keltchat #auselt http:\/\/t.co\/um1kndjh8G",
  "id" : 568558432996831232,
  "created_at" : "2015-02-19 23:51:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 0, 12 ],
      "id_str" : "31179355",
      "id" : 31179355
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stefanquilliet\/status\/568412688654725120\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/hKHaUhBVPJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-NoU_CIMAASnq5.jpg",
      "id_str" : "568412687705845760",
      "id" : 568412687705845760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-NoU_CIMAASnq5.jpg",
      "sizes" : [ {
        "h" : 599,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/hKHaUhBVPJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568421256531447808",
  "geo" : { },
  "id_str" : "568422378008657920",
  "in_reply_to_user_id" : 31179355,
  "text" : "@mattledding am reminded of this http:\/\/t.co\/hKHaUhBVPJ :)",
  "id" : 568422378008657920,
  "in_reply_to_status_id" : 568421256531447808,
  "created_at" : "2015-02-19 14:50:30 +0000",
  "in_reply_to_screen_name" : "mattledding",
  "in_reply_to_user_id_str" : "31179355",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Hampson",
      "screen_name" : "timhampson",
      "indices" : [ 3, 14 ],
      "id_str" : "19422628",
      "id" : 19422628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/AySfw2nP4p",
      "expanded_url" : "http:\/\/wp.me\/p57doF-2q",
      "display_url" : "wp.me\/p57doF-2q"
    } ]
  },
  "geo" : { },
  "id_str" : "568421229075562496",
  "text" : "RT @timhampson: A survey for TEFL bloggers http:\/\/t.co\/AySfw2nP4p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/AySfw2nP4p",
        "expanded_url" : "http:\/\/wp.me\/p57doF-2q",
        "display_url" : "wp.me\/p57doF-2q"
      } ]
    },
    "geo" : { },
    "id_str" : "568407315868618752",
    "text" : "A survey for TEFL bloggers http:\/\/t.co\/AySfw2nP4p",
    "id" : 568407315868618752,
    "created_at" : "2015-02-19 13:50:39 +0000",
    "user" : {
      "name" : "Tim Hampson",
      "screen_name" : "timhampson",
      "protected" : false,
      "id_str" : "19422628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763417942369312768\/nURc8BGo_normal.jpg",
      "id" : 19422628,
      "verified" : false
    }
  },
  "id" : 568421229075562496,
  "created_at" : "2015-02-19 14:45:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 55, 63 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/wpQNYArul5",
      "expanded_url" : "http:\/\/youtu.be\/QDmWYVdN8ug",
      "display_url" : "youtu.be\/QDmWYVdN8ug"
    } ]
  },
  "geo" : { },
  "id_str" : "568420782147276800",
  "text" : "Negativland - \"Time Zones\": http:\/\/t.co\/wpQNYArul5 via @YouTube",
  "id" : 568420782147276800,
  "created_at" : "2015-02-19 14:44:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "tleap",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 94, 112 ]
    }, {
      "text" : "oss",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "oer",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/ibhYqL6FFf",
      "expanded_url" : "https:\/\/plus.google.com\/108850472041635416528\/posts\/Z5JCniTX5ZS",
      "display_url" : "plus.google.com\/10885047204163\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568401513221132288",
  "text" : "RT @AlannahFitz: FLAX Collocation Dominoes Language Learning Game App for Android #elt #tleap #corpuslinguistics #oss #oer https:\/\/t.co\/ibh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 65, 69 ]
      }, {
        "text" : "tleap",
        "indices" : [ 70, 76 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 77, 95 ]
      }, {
        "text" : "oss",
        "indices" : [ 96, 100 ]
      }, {
        "text" : "oer",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/ibhYqL6FFf",
        "expanded_url" : "https:\/\/plus.google.com\/108850472041635416528\/posts\/Z5JCniTX5ZS",
        "display_url" : "plus.google.com\/10885047204163\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566796577549733888",
    "text" : "FLAX Collocation Dominoes Language Learning Game App for Android #elt #tleap #corpuslinguistics #oss #oer https:\/\/t.co\/ibhYqL6FFf",
    "id" : 566796577549733888,
    "created_at" : "2015-02-15 03:10:09 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 568401513221132288,
  "created_at" : "2015-02-19 13:27:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 78, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GJq7K7yh5G",
      "expanded_url" : "http:\/\/techcollo.stringnet.org\/",
      "display_url" : "techcollo.stringnet.org"
    } ]
  },
  "geo" : { },
  "id_str" : "568396025922248704",
  "text" : "http:\/\/t.co\/GJq7K7yh5G collocation explorer for Medical Engineering Law texts #corpuslinguistics",
  "id" : 568396025922248704,
  "created_at" : "2015-02-19 13:05:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MiLL",
      "screen_name" : "MiLL_Network",
      "indices" : [ 65, 78 ],
      "id_str" : "2976617727",
      "id" : 2976617727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/2G8dtLy5VF",
      "expanded_url" : "https:\/\/millnetwork.files.wordpress.com\/2015\/02\/slides-tanya-grammar-in-meaning.pdf",
      "display_url" : "millnetwork.files.wordpress.com\/2015\/02\/slides\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568390910716841984",
  "text" : "Teaching grammar in a meaningful way https:\/\/t.co\/2G8dtLy5VF h\/t @MiLL_Network",
  "id" : 568390910716841984,
  "created_at" : "2015-02-19 12:45:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cherry M P",
      "screen_name" : "cherrymp",
      "indices" : [ 3, 12 ],
      "id_str" : "42655926",
      "id" : 42655926
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/740Ij7choT",
      "expanded_url" : "http:\/\/bit.ly\/17ouN0I",
      "display_url" : "bit.ly\/17ouN0I"
    } ]
  },
  "geo" : { },
  "id_str" : "568366386285817856",
  "text" : "RT @cherrymp: If you are an English teacher who uses the internet for your PD can you fill this up for me? http:\/\/t.co\/740Ij7choT. TIA. #EL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/740Ij7choT",
        "expanded_url" : "http:\/\/bit.ly\/17ouN0I",
        "display_url" : "bit.ly\/17ouN0I"
      } ]
    },
    "geo" : { },
    "id_str" : "568364284306022400",
    "text" : "If you are an English teacher who uses the internet for your PD can you fill this up for me? http:\/\/t.co\/740Ij7choT. TIA. #ELT #ELTchat",
    "id" : 568364284306022400,
    "created_at" : "2015-02-19 10:59:39 +0000",
    "user" : {
      "name" : "Cherry M P",
      "screen_name" : "cherrymp",
      "protected" : false,
      "id_str" : "42655926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526987965210173440\/zzm01G3B_normal.jpeg",
      "id" : 42655926,
      "verified" : false
    }
  },
  "id" : 568366386285817856,
  "created_at" : "2015-02-19 11:08:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 3, 11 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 28, 43 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCN",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "cooperative",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "teachertraining",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8fmpswCyj5",
      "expanded_url" : "http:\/\/wp.me\/p4WoHi-6u",
      "display_url" : "wp.me\/p4WoHi-6u"
    } ]
  },
  "geo" : { },
  "id_str" : "568288398391316480",
  "text" : "RT @SLBCoop: Interview with @GeoffreyJordan, previewing this Saturday\u2019s #BCN #cooperative #teachertraining clinic. Spaces limited! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 15, 30 ],
        "id_str" : "334332424",
        "id" : 334332424
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCN",
        "indices" : [ 59, 63 ]
      }, {
        "text" : "cooperative",
        "indices" : [ 64, 76 ]
      }, {
        "text" : "teachertraining",
        "indices" : [ 77, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/8fmpswCyj5",
        "expanded_url" : "http:\/\/wp.me\/p4WoHi-6u",
        "display_url" : "wp.me\/p4WoHi-6u"
      } ]
    },
    "geo" : { },
    "id_str" : "567974480926121984",
    "text" : "Interview with @GeoffreyJordan, previewing this Saturday\u2019s #BCN #cooperative #teachertraining clinic. Spaces limited! http:\/\/t.co\/8fmpswCyj5",
    "id" : 567974480926121984,
    "created_at" : "2015-02-18 09:10:43 +0000",
    "user" : {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "protected" : false,
      "id_str" : "2365399801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705151471386546176\/ECVLcba-_normal.jpg",
      "id" : 2365399801,
      "verified" : false
    }
  },
  "id" : 568288398391316480,
  "created_at" : "2015-02-19 05:58:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/CrU96lL9JW",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-15W",
      "display_url" : "wp.me\/p3qkCB-15W"
    } ]
  },
  "geo" : { },
  "id_str" : "568136964131696641",
  "text" : "RT @GeoffreyJordan: New books for your\u00A0library http:\/\/t.co\/CrU96lL9JW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/CrU96lL9JW",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-15W",
        "display_url" : "wp.me\/p3qkCB-15W"
      } ]
    },
    "geo" : { },
    "id_str" : "568135319058399236",
    "text" : "New books for your\u00A0library http:\/\/t.co\/CrU96lL9JW",
    "id" : 568135319058399236,
    "created_at" : "2015-02-18 19:49:50 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 568136964131696641,
  "created_at" : "2015-02-18 19:56:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 84, 99 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/Tswuqv2zsR",
      "expanded_url" : "http:\/\/wp.me\/p1Ayq4-7H",
      "display_url" : "wp.me\/p1Ayq4-7H"
    } ]
  },
  "geo" : { },
  "id_str" : "568118785686818816",
  "text" : "RT @HanaTicha: Action research and the voice of teachers http:\/\/t.co\/Tswuqv2zsR via @_divyamadhavan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Divya Madhavan",
        "screen_name" : "_divyamadhavan",
        "indices" : [ 69, 84 ],
        "id_str" : "408492806",
        "id" : 408492806
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/Tswuqv2zsR",
        "expanded_url" : "http:\/\/wp.me\/p1Ayq4-7H",
        "display_url" : "wp.me\/p1Ayq4-7H"
      } ]
    },
    "geo" : { },
    "id_str" : "568115232675110912",
    "text" : "Action research and the voice of teachers http:\/\/t.co\/Tswuqv2zsR via @_divyamadhavan",
    "id" : 568115232675110912,
    "created_at" : "2015-02-18 18:30:01 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 568118785686818816,
  "created_at" : "2015-02-18 18:44:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 110, 122 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Wsfh4WVqvr",
      "expanded_url" : "http:\/\/wp.me\/p1ZDGy-gQ",
      "display_url" : "wp.me\/p1ZDGy-gQ"
    } ]
  },
  "geo" : { },
  "id_str" : "568118683979153409",
  "text" : "Keeping it in the family: how parents' education shapes their children's schooling http:\/\/t.co\/Wsfh4WVqvr via @John__Field",
  "id" : 568118683979153409,
  "created_at" : "2015-02-18 18:43:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 83, 94 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567999708561592320",
  "geo" : { },
  "id_str" : "568001117252153344",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 hi dont know about collective action maybe indiv representation, perhaps @bethcagnol may know of examples?",
  "id" : 568001117252153344,
  "in_reply_to_status_id" : 567999708561592320,
  "created_at" : "2015-02-18 10:56:33 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 74, 86 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567975695625760768",
  "geo" : { },
  "id_str" : "567999720406315008",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow hey kev thx glad u found  it useful, originally got link from @usage_based",
  "id" : 567999720406315008,
  "in_reply_to_status_id" : 567975695625760768,
  "created_at" : "2015-02-18 10:51:00 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosario Iguin",
      "screen_name" : "Rosario_ELT",
      "indices" : [ 3, 15 ],
      "id_str" : "1016631306",
      "id" : 1016631306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/SGxLWbMTAO",
      "expanded_url" : "http:\/\/freeonlinesurveys.com\/app\/rendersurvey.asp?sid=bl6zvr6lm3s8gmd594630&refer=m%2Efacebook%2Ecom",
      "display_url" : "freeonlinesurveys.com\/app\/rendersurv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567809843839660034",
  "text" : "RT @Rosario_ELT: Hey ELTers! Help a brother out with his dissertation. Takes no time at all. Cheers! http:\/\/t.co\/SGxLWbMTAO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/SGxLWbMTAO",
        "expanded_url" : "http:\/\/freeonlinesurveys.com\/app\/rendersurvey.asp?sid=bl6zvr6lm3s8gmd594630&refer=m%2Efacebook%2Ecom",
        "display_url" : "freeonlinesurveys.com\/app\/rendersurv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567804468181385216",
    "text" : "Hey ELTers! Help a brother out with his dissertation. Takes no time at all. Cheers! http:\/\/t.co\/SGxLWbMTAO",
    "id" : 567804468181385216,
    "created_at" : "2015-02-17 21:55:09 +0000",
    "user" : {
      "name" : "Rosario Iguin",
      "screen_name" : "Rosario_ELT",
      "protected" : false,
      "id_str" : "1016631306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630999545665597440\/uow3Xtcg_normal.jpg",
      "id" : 1016631306,
      "verified" : false
    }
  },
  "id" : 567809843839660034,
  "created_at" : "2015-02-17 22:16:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/u406SMCkRp",
      "expanded_url" : "http:\/\/edu.au.dk\/fileadmin\/edu\/Cursiv\/CURSIV_14_www.pdf",
      "display_url" : "edu.au.dk\/fileadmin\/edu\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567747362182139905",
  "text" : "RT @gbiesta: new: 'Who knows? On the need to ask critical questions about the turn towards evidence' &amp; interesting special issue: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/u406SMCkRp",
        "expanded_url" : "http:\/\/edu.au.dk\/fileadmin\/edu\/Cursiv\/CURSIV_14_www.pdf",
        "display_url" : "edu.au.dk\/fileadmin\/edu\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567443884775837696",
    "text" : "new: 'Who knows? On the need to ask critical questions about the turn towards evidence' &amp; interesting special issue: http:\/\/t.co\/u406SMCkRp",
    "id" : 567443884775837696,
    "created_at" : "2015-02-16 22:02:19 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 567747362182139905,
  "created_at" : "2015-02-17 18:08:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 3, 15 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 18, 25 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 28, 38 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "flovo.co",
      "screen_name" : "flovoco",
      "indices" : [ 62, 70 ],
      "id_str" : "2583934020",
      "id" : 2583934020
    }, {
      "name" : "Mind the Product",
      "screen_name" : "MindtheProduct",
      "indices" : [ 98, 113 ],
      "id_str" : "260486152",
      "id" : 260486152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/wsOQ7Aucd0",
      "expanded_url" : "http:\/\/www.mindtheproduct.com\/2015\/02\/5-lessons-learned-first-product\/",
      "display_url" : "mindtheproduct.com\/2015\/02\/5-less\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567736979895615488",
  "text" : "RT @nmkrobinson: .@eltjam's @jo_sayers writing about building @flovoco, our first product, on the @MindTheProduct blog http:\/\/t.co\/wsOQ7Auc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELTjam",
        "screen_name" : "eltjam",
        "indices" : [ 1, 8 ],
        "id_str" : "1356363686",
        "id" : 1356363686
      }, {
        "name" : "Jo Sayers",
        "screen_name" : "jo_sayers",
        "indices" : [ 11, 21 ],
        "id_str" : "87176766",
        "id" : 87176766
      }, {
        "name" : "flovo.co",
        "screen_name" : "flovoco",
        "indices" : [ 45, 53 ],
        "id_str" : "2583934020",
        "id" : 2583934020
      }, {
        "name" : "Mind the Product",
        "screen_name" : "MindtheProduct",
        "indices" : [ 81, 96 ],
        "id_str" : "260486152",
        "id" : 260486152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/wsOQ7Aucd0",
        "expanded_url" : "http:\/\/www.mindtheproduct.com\/2015\/02\/5-lessons-learned-first-product\/",
        "display_url" : "mindtheproduct.com\/2015\/02\/5-less\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567693738953433089",
    "text" : ".@eltjam's @jo_sayers writing about building @flovoco, our first product, on the @MindTheProduct blog http:\/\/t.co\/wsOQ7Aucd0",
    "id" : 567693738953433089,
    "created_at" : "2015-02-17 14:35:09 +0000",
    "user" : {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "protected" : false,
      "id_str" : "20425399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706797940669599744\/6lTpszWm_normal.jpg",
      "id" : 20425399,
      "verified" : false
    }
  },
  "id" : 567736979895615488,
  "created_at" : "2015-02-17 17:26:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567708903056879616",
  "geo" : { },
  "id_str" : "567720449107578880",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran thks for the pron issues in ATC English :)",
  "id" : 567720449107578880,
  "in_reply_to_status_id" : 567708903056879616,
  "created_at" : "2015-02-17 16:21:17 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "BBC Learning English",
      "screen_name" : "bbcle",
      "indices" : [ 34, 40 ],
      "id_str" : "2450291",
      "id" : 2450291
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 47, 62 ],
      "id_str" : "14732889",
      "id" : 14732889
    }, {
      "name" : "Not Michael Phelps",
      "screen_name" : "harrisonmike",
      "indices" : [ 113, 126 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESOL",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/Smk6ATvSAp",
      "expanded_url" : "http:\/\/ow.ly\/JbtmK",
      "display_url" : "ow.ly\/JbtmK"
    } ]
  },
  "geo" : { },
  "id_str" : "567720258052849664",
  "text" : "RT @eltjam: Today's post is about @bbcle's and @BritishCouncil social enterprise project in UK communities #ESOL @harrisonmike http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Learning English",
        "screen_name" : "bbcle",
        "indices" : [ 22, 28 ],
        "id_str" : "2450291",
        "id" : 2450291
      }, {
        "name" : "British Council",
        "screen_name" : "BritishCouncil",
        "indices" : [ 35, 50 ],
        "id_str" : "14732889",
        "id" : 14732889
      }, {
        "name" : "Not Michael Phelps",
        "screen_name" : "harrisonmike",
        "indices" : [ 101, 114 ],
        "id_str" : "1685397408",
        "id" : 1685397408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESOL",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Smk6ATvSAp",
        "expanded_url" : "http:\/\/ow.ly\/JbtmK",
        "display_url" : "ow.ly\/JbtmK"
      } ]
    },
    "geo" : { },
    "id_str" : "567685182539317248",
    "text" : "Today's post is about @bbcle's and @BritishCouncil social enterprise project in UK communities #ESOL @harrisonmike http:\/\/t.co\/Smk6ATvSAp",
    "id" : 567685182539317248,
    "created_at" : "2015-02-17 14:01:09 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 567720258052849664,
  "created_at" : "2015-02-17 16:20:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/TeZk0iBmkx",
      "expanded_url" : "http:\/\/www.kollokation.at\/en\/our-project\/what-we-mean-by-collocation\/",
      "display_url" : "kollokation.at\/en\/our-project\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "567677172065009664",
  "geo" : { },
  "id_str" : "567677688564178944",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle http:\/\/t.co\/TeZk0iBmkx",
  "id" : 567677688564178944,
  "in_reply_to_status_id" : 567677172065009664,
  "created_at" : "2015-02-17 13:31:22 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567677172065009664",
  "geo" : { },
  "id_str" : "567677431025508354",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle it has nice description of collocation and other info",
  "id" : 567677431025508354,
  "in_reply_to_status_id" : 567677172065009664,
  "created_at" : "2015-02-17 13:30:21 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567674688550105089",
  "geo" : { },
  "id_str" : "567675244522262529",
  "in_reply_to_user_id" : 1479290418,
  "text" : "@usage_based erm i got it from your tweet in fact, h\/t means hat tip :)",
  "id" : 567675244522262529,
  "in_reply_to_status_id" : 567674688550105089,
  "created_at" : "2015-02-17 13:21:39 +0000",
  "in_reply_to_screen_name" : "usage_based",
  "in_reply_to_user_id_str" : "1479290418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    }, {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 65, 77 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/PzNjoTAE2o",
      "expanded_url" : "http:\/\/www.kollokation.at\/en\/",
      "display_url" : "kollokation.at\/en\/"
    } ]
  },
  "geo" : { },
  "id_str" : "567672828863193088",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle hi have you seen this website http:\/\/t.co\/PzNjoTAE2o h\/t @usage_based",
  "id" : 567672828863193088,
  "created_at" : "2015-02-17 13:12:03 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 107, 123 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/SjZG7VEkDO",
      "expanded_url" : "http:\/\/wp.me\/p5dOWM-1O",
      "display_url" : "wp.me\/p5dOWM-1O"
    } ]
  },
  "geo" : { },
  "id_str" : "567670840247222272",
  "text" : "04 - Questioning the Native English Norm in English Teaching - Jennifer Jenkins http:\/\/t.co\/SjZG7VEkDO via @wordpressdotcom",
  "id" : 567670840247222272,
  "created_at" : "2015-02-17 13:04:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 3, 18 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/2vnqByGckc",
      "expanded_url" : "http:\/\/wp.me\/p39fMp-uf",
      "display_url" : "wp.me\/p39fMp-uf"
    } ]
  },
  "geo" : { },
  "id_str" : "567670442933387264",
  "text" : "RT @LjiljanaHavran: My new Aviation English post: Good pronunciation in pilot\/controller communications is vital to safety http:\/\/t.co\/2vnq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/2vnqByGckc",
        "expanded_url" : "http:\/\/wp.me\/p39fMp-uf",
        "display_url" : "wp.me\/p39fMp-uf"
      } ]
    },
    "geo" : { },
    "id_str" : "567665983113150464",
    "text" : "My new Aviation English post: Good pronunciation in pilot\/controller communications is vital to safety http:\/\/t.co\/2vnqByGckc",
    "id" : 567665983113150464,
    "created_at" : "2015-02-17 12:44:51 +0000",
    "user" : {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "protected" : false,
      "id_str" : "1395825290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729054439496159232\/58roonKM_normal.jpg",
      "id" : 1395825290,
      "verified" : false
    }
  },
  "id" : 567670442933387264,
  "created_at" : "2015-02-17 13:02:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/EfZKVFdfP3",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article41008.htm#.VOMtlHI5kRc.twitter",
      "display_url" : "informationclearinghouse.info\/article41008.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567655070142304256",
  "text" : "\u2018Pornography Is What the End of the World Looks Like\u2019 :\u00A0 Information Clearing House - ICH http:\/\/t.co\/EfZKVFdfP3",
  "id" : 567655070142304256,
  "created_at" : "2015-02-17 12:01:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/n4AdTvfXBO",
      "expanded_url" : "http:\/\/nyti.ms\/1AwF6O4",
      "display_url" : "nyti.ms\/1AwF6O4"
    } ]
  },
  "geo" : { },
  "id_str" : "567645364875169792",
  "text" : "RT @heatherfro: \"[he] began examining a website called the Glossary of Science Fiction Ideas, Technology and Inventions\" http:\/\/t.co\/n4AdTv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/n4AdTvfXBO",
        "expanded_url" : "http:\/\/nyti.ms\/1AwF6O4",
        "display_url" : "nyti.ms\/1AwF6O4"
      } ]
    },
    "geo" : { },
    "id_str" : "567627271964356608",
    "text" : "\"[he] began examining a website called the Glossary of Science Fiction Ideas, Technology and Inventions\" http:\/\/t.co\/n4AdTvfXBO",
    "id" : 567627271964356608,
    "created_at" : "2015-02-17 10:11:02 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 567645364875169792,
  "created_at" : "2015-02-17 11:22:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0411\u0430\u043B\u0438\u043D\u0433",
      "screen_name" : "websofsubstance",
      "indices" : [ 0, 16 ],
      "id_str" : "235176479",
      "id" : 235176479
    }, {
      "name" : "Ted O'Neill (DB-\u7ADC\u725B)",
      "screen_name" : "gotanda",
      "indices" : [ 17, 25 ],
      "id_str" : "9875912",
      "id" : 9875912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567590693984829441",
  "text" : "@websofsubstance @gotanda it is one line, bigger weakness is equating failure factors, out of school factors dominate",
  "id" : 567590693984829441,
  "created_at" : "2015-02-17 07:45:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 64, 79 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/9bQXqnUhLr",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/can-tesol-save-the-world-part-iii",
      "display_url" : "anthonyteacher.com\/blog\/can-tesol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567481810603745281",
  "text" : "Can TESOL Save the World? (Part III) http:\/\/t.co\/9bQXqnUhLr via @AnthonyTeacher",
  "id" : 567481810603745281,
  "created_at" : "2015-02-17 00:33:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 94, 106 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9zlqdwgpoA",
      "expanded_url" : "http:\/\/wp.me\/p3cig0-ot",
      "display_url" : "wp.me\/p3cig0-ot"
    } ]
  },
  "geo" : { },
  "id_str" : "567481636062003200",
  "text" : "\u201CThe medium is the message\u201D: The message of educational technology http:\/\/t.co\/9zlqdwgpoA via @nathanghall",
  "id" : 567481636062003200,
  "created_at" : "2015-02-17 00:32:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 60, 75 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/i8gr4b7Q9G",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4Nr",
      "display_url" : "wp.me\/p93oK-4Nr"
    } ]
  },
  "geo" : { },
  "id_str" : "567424935271075840",
  "text" : "Big Business, Tax and the Tories http:\/\/t.co\/i8gr4b7Q9G via @bellacaledonia",
  "id" : 567424935271075840,
  "created_at" : "2015-02-16 20:47:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567369461674811392",
  "geo" : { },
  "id_str" : "567380321365413889",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt reminds of student who told me today  phillipp morris forgot to patent malboro in canada, what book is equivalent over there?",
  "id" : 567380321365413889,
  "in_reply_to_status_id" : 567369461674811392,
  "created_at" : "2015-02-16 17:49:44 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567335631614140416",
  "geo" : { },
  "id_str" : "567339883812122624",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt true that, another common refrain is 'tech is neutral' - it is conceived, designed, implemented in a far from neutral position",
  "id" : 567339883812122624,
  "in_reply_to_status_id" : 567335631614140416,
  "created_at" : "2015-02-16 15:09:03 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567331509162737666",
  "geo" : { },
  "id_str" : "567333169897406464",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt strange how some critiques tech use preface \"i am not anti-tech\", seems such discussion still revolves round tech vs no tech? :\/",
  "id" : 567333169897406464,
  "in_reply_to_status_id" : 567331509162737666,
  "created_at" : "2015-02-16 14:42:22 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Townley",
      "screen_name" : "The_Gorilla_LC",
      "indices" : [ 3, 18 ],
      "id_str" : "2295023113",
      "id" : 2295023113
    }, {
      "name" : "Usable Knowledge",
      "screen_name" : "UKnowHGSE",
      "indices" : [ 113, 123 ],
      "id_str" : "2571454915",
      "id" : 2571454915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/4FA6W8wqCB",
      "expanded_url" : "http:\/\/www.gse.harvard.edu\/news\/uk\/15\/02\/smart-talk",
      "display_url" : "gse.harvard.edu\/news\/uk\/15\/02\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567326963229265920",
  "text" : "RT @The_Gorilla_LC: Excellent article from Harvard Ed on what influences the rate of a child's vocabulary growth @UKnowHGSE http:\/\/t.co\/4FA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Usable Knowledge",
        "screen_name" : "UKnowHGSE",
        "indices" : [ 93, 103 ],
        "id_str" : "2571454915",
        "id" : 2571454915
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/4FA6W8wqCB",
        "expanded_url" : "http:\/\/www.gse.harvard.edu\/news\/uk\/15\/02\/smart-talk",
        "display_url" : "gse.harvard.edu\/news\/uk\/15\/02\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567146971027099648",
    "text" : "Excellent article from Harvard Ed on what influences the rate of a child's vocabulary growth @UKnowHGSE http:\/\/t.co\/4FA6W8wqCB",
    "id" : 567146971027099648,
    "created_at" : "2015-02-16 02:22:29 +0000",
    "user" : {
      "name" : "Simon Townley",
      "screen_name" : "The_Gorilla_LC",
      "protected" : false,
      "id_str" : "2295023113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660767947955138560\/wEo0Kbtu_normal.jpg",
      "id" : 2295023113,
      "verified" : false
    }
  },
  "id" : 567326963229265920,
  "created_at" : "2015-02-16 14:17:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "[\u02C8d\u0292e\u026An \u02C8set\u0259 ]",
      "screen_name" : "JaneSetter",
      "indices" : [ 3, 14 ],
      "id_str" : "53649036",
      "id" : 53649036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "English",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "Phonetics",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/2UkQTIDgHl",
      "expanded_url" : "http:\/\/youtu.be\/_mikec322bM",
      "display_url" : "youtu.be\/_mikec322bM"
    } ]
  },
  "geo" : { },
  "id_str" : "567308249448607744",
  "text" : "RT @JaneSetter: Need a mid-week #English #Phonetics boost? Try the happY vowel song: http:\/\/t.co\/2UkQTIDgHl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "English",
        "indices" : [ 16, 24 ]
      }, {
        "text" : "Phonetics",
        "indices" : [ 25, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/2UkQTIDgHl",
        "expanded_url" : "http:\/\/youtu.be\/_mikec322bM",
        "display_url" : "youtu.be\/_mikec322bM"
      } ]
    },
    "geo" : { },
    "id_str" : "565515481319481344",
    "text" : "Need a mid-week #English #Phonetics boost? Try the happY vowel song: http:\/\/t.co\/2UkQTIDgHl",
    "id" : 565515481319481344,
    "created_at" : "2015-02-11 14:19:32 +0000",
    "user" : {
      "name" : "[\u02C8d\u0292e\u026An \u02C8set\u0259 ]",
      "screen_name" : "JaneSetter",
      "protected" : false,
      "id_str" : "53649036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654400451656462336\/Xn5l4bAj_normal.jpg",
      "id" : 53649036,
      "verified" : false
    }
  },
  "id" : 567308249448607744,
  "created_at" : "2015-02-16 13:03:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason West",
      "screen_name" : "EnglishOutThere",
      "indices" : [ 3, 19 ],
      "id_str" : "66951936",
      "id" : 66951936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 94, 98 ]
    }, {
      "text" : "esl",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "english",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/9oquaJiDfe",
      "expanded_url" : "http:\/\/ow.ly\/J7n5N",
      "display_url" : "ow.ly\/J7n5N"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MVh2NBRjLb",
      "expanded_url" : "http:\/\/fb.me\/3MVohw9ZT",
      "display_url" : "fb.me\/3MVohw9ZT"
    } ]
  },
  "geo" : { },
  "id_str" : "567294952544415744",
  "text" : "RT @EnglishOutThere: It's A Racket (re-edited due to fear of reprisal) http:\/\/t.co\/9oquaJiDfe #elt #esl #english http:\/\/t.co\/MVh2NBRjLb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 73, 77 ]
      }, {
        "text" : "esl",
        "indices" : [ 78, 82 ]
      }, {
        "text" : "english",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/9oquaJiDfe",
        "expanded_url" : "http:\/\/ow.ly\/J7n5N",
        "display_url" : "ow.ly\/J7n5N"
      }, {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/MVh2NBRjLb",
        "expanded_url" : "http:\/\/fb.me\/3MVohw9ZT",
        "display_url" : "fb.me\/3MVohw9ZT"
      } ]
    },
    "geo" : { },
    "id_str" : "567293394389831680",
    "text" : "It's A Racket (re-edited due to fear of reprisal) http:\/\/t.co\/9oquaJiDfe #elt #esl #english http:\/\/t.co\/MVh2NBRjLb",
    "id" : 567293394389831680,
    "created_at" : "2015-02-16 12:04:19 +0000",
    "user" : {
      "name" : "Jason West",
      "screen_name" : "EnglishOutThere",
      "protected" : false,
      "id_str" : "66951936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1168492102\/jason-avatar_normal.jpg",
      "id" : 66951936,
      "verified" : false
    }
  },
  "id" : 567294952544415744,
  "created_at" : "2015-02-16 12:10:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 56, 65 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/9xPuFIWEL3",
      "expanded_url" : "http:\/\/wp.me\/p1kzD1-YG",
      "display_url" : "wp.me\/p1kzD1-YG"
    } ]
  },
  "geo" : { },
  "id_str" : "567293302865928194",
  "text" : "The TEFL Blame Game - redux: http:\/\/t.co\/9xPuFIWEL3 via @teflgeek",
  "id" : 567293302865928194,
  "created_at" : "2015-02-16 12:03:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 3, 16 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 69, 79 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JTDnDUNuEq",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/02\/a-perfect-match.html?view=classic",
      "display_url" : "how-i-see-it-now.blogspot.com\/2015\/02\/a-perf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567232206423478272",
  "text" : "RT @ZhenyaDnipro: What do you learn from your colleagues? Every day? @HanaTicha shares her examples in a new post http:\/\/t.co\/JTDnDUNuEq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hana Tich\u00E1",
        "screen_name" : "HanaTicha",
        "indices" : [ 51, 61 ],
        "id_str" : "512296705",
        "id" : 512296705
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/JTDnDUNuEq",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/02\/a-perfect-match.html?view=classic",
        "display_url" : "how-i-see-it-now.blogspot.com\/2015\/02\/a-perf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567230647245488128",
    "text" : "What do you learn from your colleagues? Every day? @HanaTicha shares her examples in a new post http:\/\/t.co\/JTDnDUNuEq",
    "id" : 567230647245488128,
    "created_at" : "2015-02-16 07:54:59 +0000",
    "user" : {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "protected" : false,
      "id_str" : "2248486418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766906932875714560\/KfDv1cK8_normal.jpg",
      "id" : 2248486418,
      "verified" : false
    }
  },
  "id" : 567232206423478272,
  "created_at" : "2015-02-16 08:01:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/34034Z3cXb",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/2015\/02\/16\/a-dummies-guide-to-decentralised-teaching\/",
      "display_url" : "decentralisedteachingandlearning.com\/2015\/02\/16\/a-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567231383438118914",
  "text" : "A dummies guide to decentralised teaching http:\/\/t.co\/34034Z3cXb",
  "id" : 567231383438118914,
  "created_at" : "2015-02-16 07:57:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4VBAhkvNMe",
      "expanded_url" : "http:\/\/wp.me\/p3OWOG-pN",
      "display_url" : "wp.me\/p3OWOG-pN"
    } ]
  },
  "geo" : { },
  "id_str" : "567230164728561664",
  "text" : "RT @DavidHarbinson: PowerPoint Bingo Caller http:\/\/t.co\/4VBAhkvNMe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/4VBAhkvNMe",
        "expanded_url" : "http:\/\/wp.me\/p3OWOG-pN",
        "display_url" : "wp.me\/p3OWOG-pN"
      } ]
    },
    "geo" : { },
    "id_str" : "567226809754714112",
    "text" : "PowerPoint Bingo Caller http:\/\/t.co\/4VBAhkvNMe",
    "id" : 567226809754714112,
    "created_at" : "2015-02-16 07:39:44 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 567230164728561664,
  "created_at" : "2015-02-16 07:53:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaimalee Y",
      "screen_name" : "malee_saru",
      "indices" : [ 3, 14 ],
      "id_str" : "130483372",
      "id" : 130483372
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/malee_saru\/status\/567214722907254784\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/xlyAdLs8qp",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B98mqgeIEAA3XiD.png",
      "id_str" : "567214589784625152",
      "id" : 567214589784625152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B98mqgeIEAA3XiD.png",
      "sizes" : [ {
        "h" : 820,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/xlyAdLs8qp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/bcv4YfiaoG",
      "expanded_url" : "http:\/\/portal.nifty.com\/kiji\/150214192769_4.htm",
      "display_url" : "portal.nifty.com\/kiji\/150214192\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567219009159188480",
  "text" : "RT @malee_saru: \u30C1\u30FC\u30BA across \u30CF\u30F3\u30D0\u30FC\u30B0 - \u30C7\u30A4\u30EA\u30FC\u30DD\u30FC\u30BF\u30EBZ\nhttp:\/\/t.co\/bcv4YfiaoG http:\/\/t.co\/xlyAdLs8qp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/malee_saru\/status\/567214722907254784\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/xlyAdLs8qp",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B98mqgeIEAA3XiD.png",
        "id_str" : "567214589784625152",
        "id" : 567214589784625152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B98mqgeIEAA3XiD.png",
        "sizes" : [ {
          "h" : 820,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/xlyAdLs8qp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/bcv4YfiaoG",
        "expanded_url" : "http:\/\/portal.nifty.com\/kiji\/150214192769_4.htm",
        "display_url" : "portal.nifty.com\/kiji\/150214192\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567214722907254784",
    "text" : "\u30C1\u30FC\u30BA across \u30CF\u30F3\u30D0\u30FC\u30B0 - \u30C7\u30A4\u30EA\u30FC\u30DD\u30FC\u30BF\u30EBZ\nhttp:\/\/t.co\/bcv4YfiaoG http:\/\/t.co\/xlyAdLs8qp",
    "id" : 567214722907254784,
    "created_at" : "2015-02-16 06:51:42 +0000",
    "user" : {
      "name" : "Chaimalee Y",
      "screen_name" : "malee_saru",
      "protected" : false,
      "id_str" : "130483372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1212853228\/30032010010_e1_normal.jpg",
      "id" : 130483372,
      "verified" : false
    }
  },
  "id" : 567219009159188480,
  "created_at" : "2015-02-16 07:08:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Ruiz Tinoco",
      "screen_name" : "aruiztinoco",
      "indices" : [ 3, 15 ],
      "id_str" : "26511350",
      "id" : 26511350
    }, {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 139, 140 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coding",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "literacy",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/SM68PxEWEk",
      "expanded_url" : "http:\/\/qz.com\/341447",
      "display_url" : "qz.com\/341447"
    } ]
  },
  "geo" : { },
  "id_str" : "566981539700158464",
  "text" : "RT @aruiztinoco: The idea that \u201C#coding is the new literacy\u201D  takes a narrow view of what #literacy really is. Check out: http:\/\/t.co\/SM68P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quartz",
        "screen_name" : "qz",
        "indices" : [ 132, 135 ],
        "id_str" : "573918122",
        "id" : 573918122
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coding",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "literacy",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/SM68PxEWEk",
        "expanded_url" : "http:\/\/qz.com\/341447",
        "display_url" : "qz.com\/341447"
      } ]
    },
    "geo" : { },
    "id_str" : "566970424508968960",
    "text" : "The idea that \u201C#coding is the new literacy\u201D  takes a narrow view of what #literacy really is. Check out: http:\/\/t.co\/SM68PxEWEk via @qz",
    "id" : 566970424508968960,
    "created_at" : "2015-02-15 14:40:57 +0000",
    "user" : {
      "name" : "Antonio Ruiz Tinoco",
      "screen_name" : "aruiztinoco",
      "protected" : false,
      "id_str" : "26511350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643023538442498048\/wr85Umcp_normal.jpg",
      "id" : 26511350,
      "verified" : false
    }
  },
  "id" : 566981539700158464,
  "created_at" : "2015-02-15 15:25:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "indices" : [ 3, 10 ],
      "id_str" : "15921173",
      "id" : 15921173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/NSghDHoQek",
      "expanded_url" : "http:\/\/gu.com\/p\/45mmt\/stw",
      "display_url" : "gu.com\/p\/45mmt\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "566888440521056256",
  "text" : "RT @edyson: The fascinating truth behind all those \u2018great firewall of China\u2019 headlines http:\/\/t.co\/NSghDHoQek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/NSghDHoQek",
        "expanded_url" : "http:\/\/gu.com\/p\/45mmt\/stw",
        "display_url" : "gu.com\/p\/45mmt\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "566778721189646336",
    "text" : "The fascinating truth behind all those \u2018great firewall of China\u2019 headlines http:\/\/t.co\/NSghDHoQek",
    "id" : 566778721189646336,
    "created_at" : "2015-02-15 01:59:12 +0000",
    "user" : {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "protected" : false,
      "id_str" : "15921173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474207333111705601\/GYvWOPew_normal.jpeg",
      "id" : 15921173,
      "verified" : false
    }
  },
  "id" : 566888440521056256,
  "created_at" : "2015-02-15 09:15:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setosa",
      "screen_name" : "setosaio",
      "indices" : [ 75, 84 ],
      "id_str" : "2691964027",
      "id" : 2691964027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/PQYyIDtvDp",
      "expanded_url" : "http:\/\/setosa.io\/ev\/principal-component-analysis\/",
      "display_url" : "setosa.io\/ev\/principal-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566887679917580288",
  "text" : "Principal Component Analysis explained visually http:\/\/t.co\/PQYyIDtvDp via @setosaio",
  "id" : 566887679917580288,
  "created_at" : "2015-02-15 09:12:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto Bruzos",
      "screen_name" : "abruzos",
      "indices" : [ 3, 11 ],
      "id_str" : "150242940",
      "id" : 150242940
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sociology",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/xbzFUwF5Hz",
      "expanded_url" : "https:\/\/ursulahuws.wordpress.com\/2015\/02\/14\/more-on-the-citizens-income-a-quick-update\/",
      "display_url" : "ursulahuws.wordpress.com\/2015\/02\/14\/mor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566723121328443392",
  "text" : "RT @abruzos: More on the Citizens Income \u2013 a quick update https:\/\/t.co\/xbzFUwF5Hz #sociology",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sociology",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/xbzFUwF5Hz",
        "expanded_url" : "https:\/\/ursulahuws.wordpress.com\/2015\/02\/14\/more-on-the-citizens-income-a-quick-update\/",
        "display_url" : "ursulahuws.wordpress.com\/2015\/02\/14\/mor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566721619985723392",
    "text" : "More on the Citizens Income \u2013 a quick update https:\/\/t.co\/xbzFUwF5Hz #sociology",
    "id" : 566721619985723392,
    "created_at" : "2015-02-14 22:12:18 +0000",
    "user" : {
      "name" : "Alberto Bruzos",
      "screen_name" : "abruzos",
      "protected" : false,
      "id_str" : "150242940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946606779\/aj__normal.JPG",
      "id" : 150242940,
      "verified" : false
    }
  },
  "id" : 566723121328443392,
  "created_at" : "2015-02-14 22:18:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/d2SxbTPmGV",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/2\/13\/43214\/3178",
      "display_url" : "eurotrib.com\/story\/2015\/2\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566715222795497473",
  "text" : "Varoufakis and the memorandum http:\/\/t.co\/d2SxbTPmGV",
  "id" : 566715222795497473,
  "created_at" : "2015-02-14 21:46:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/GtVMoOKLP3",
      "expanded_url" : "http:\/\/usir.salford.ac.uk\/28516\/1\/AEFLJ2013_%2D_HJarticle.pdf",
      "display_url" : "usir.salford.ac.uk\/28516\/1\/AEFLJ2\u2026"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/9OyVoVXIcn",
      "expanded_url" : "http:\/\/usir.salford.ac.uk\/11268\/1\/ECEbookchapter.pdf",
      "display_url" : "usir.salford.ac.uk\/11268\/1\/ECEboo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "566686204595535873",
  "geo" : { },
  "id_str" : "566688471117746176",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic a ref here about unconscious learning http:\/\/t.co\/GtVMoOKLP3 to http:\/\/t.co\/9OyVoVXIcn but can't find there?",
  "id" : 566688471117746176,
  "in_reply_to_status_id" : 566686204595535873,
  "created_at" : "2015-02-14 20:00:34 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/6Fl3dqALfa",
      "expanded_url" : "http:\/\/usir.salford.ac.uk\/view\/authors\/1377.html",
      "display_url" : "usir.salford.ac.uk\/view\/authors\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "566676547973963777",
  "geo" : { },
  "id_str" : "566683304737669120",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic could you point to ref as I can't see in quick scan of papers available http:\/\/t.co\/6Fl3dqALfa thanks",
  "id" : 566683304737669120,
  "in_reply_to_status_id" : 566676547973963777,
  "created_at" : "2015-02-14 19:40:02 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566622398930505728",
  "geo" : { },
  "id_str" : "566655256256593920",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic hi do you have links to multi-tasking, unconscious learning and technology use?",
  "id" : 566655256256593920,
  "in_reply_to_status_id" : 566622398930505728,
  "created_at" : "2015-02-14 17:48:35 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 114, 122 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/dvWgk8aFnW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=21YZ_LFf5O8",
      "display_url" : "youtube.com\/watch?v=21YZ_L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566616048884260864",
  "text" : "RT @medialens: The kind of \u2018cult of personality\u2019 propaganda you\u2019ll only ever see in Russia or North Korea. Uhm... @BBCNews\nhttps:\/\/t.co\/dvW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 99, 107 ],
        "id_str" : "612473",
        "id" : 612473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/dvWgk8aFnW",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=21YZ_LFf5O8",
        "display_url" : "youtube.com\/watch?v=21YZ_L\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566513148522663936",
    "text" : "The kind of \u2018cult of personality\u2019 propaganda you\u2019ll only ever see in Russia or North Korea. Uhm... @BBCNews\nhttps:\/\/t.co\/dvWgk8aFnW",
    "id" : 566513148522663936,
    "created_at" : "2015-02-14 08:23:54 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 566616048884260864,
  "created_at" : "2015-02-14 15:12:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/38fYRUggep",
      "expanded_url" : "http:\/\/russia-insider.com\/2015\/02\/14\/3489",
      "display_url" : "russia-insider.com\/2015\/02\/14\/3489"
    } ]
  },
  "geo" : { },
  "id_str" : "566614716748156928",
  "text" : "Financial Times Finally Prints the Unvarnished Truth: Kiev Is the Violent Aggressor in East Ukraine http:\/\/t.co\/38fYRUggep",
  "id" : 566614716748156928,
  "created_at" : "2015-02-14 15:07:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 3, 13 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566608902465548290",
  "text" : "RT @pronbites: Hope you all get to practise some quadrilabial clicks with someone you fancy or love today! &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566458722977738752",
    "text" : "Hope you all get to practise some quadrilabial clicks with someone you fancy or love today! &lt;3",
    "id" : 566458722977738752,
    "created_at" : "2015-02-14 04:47:38 +0000",
    "user" : {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "protected" : false,
      "id_str" : "2451770871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744911290766868480\/VQAhoA7h_normal.jpg",
      "id" : 2451770871,
      "verified" : false
    }
  },
  "id" : 566608902465548290,
  "created_at" : "2015-02-14 14:44:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Tennant",
      "screen_name" : "gary10ant",
      "indices" : [ 0, 10 ],
      "id_str" : "332510619",
      "id" : 332510619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566597969206841345",
  "in_reply_to_user_id" : 332510619,
  "text" : "@gary10ant hi thx for RT of pron post :)",
  "id" : 566597969206841345,
  "created_at" : "2015-02-14 14:00:57 +0000",
  "in_reply_to_screen_name" : "gary10ant",
  "in_reply_to_user_id_str" : "332510619",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/vmkFbh8bpa",
      "expanded_url" : "http:\/\/www.pipeline.fm\/podcast\/episode-009-gert-biesta",
      "display_url" : "pipeline.fm\/podcast\/episod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566534721765908480",
  "text" : "RT @gbiesta: audio interview (from spring 2014) by Winston Thompson now posted on PiPEline http:\/\/t.co\/vmkFbh8bpa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/vmkFbh8bpa",
        "expanded_url" : "http:\/\/www.pipeline.fm\/podcast\/episode-009-gert-biesta",
        "display_url" : "pipeline.fm\/podcast\/episod\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565793712224362496",
    "text" : "audio interview (from spring 2014) by Winston Thompson now posted on PiPEline http:\/\/t.co\/vmkFbh8bpa",
    "id" : 565793712224362496,
    "created_at" : "2015-02-12 08:45:07 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 566534721765908480,
  "created_at" : "2015-02-14 09:49:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566531499575771136",
  "geo" : { },
  "id_str" : "566532913093935104",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish i read that as dothraki at first... looks like a biscuit?",
  "id" : 566532913093935104,
  "in_reply_to_status_id" : 566531499575771136,
  "created_at" : "2015-02-14 09:42:26 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 3, 14 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademicValentines",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566530582562492416",
  "text" : "RT @congabonga: Roses are constructed as red\nViolets are stereotyped as blue\nClearly a CDA is needed\nWith a quantitative component too\n#Aca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AcademicValentines",
        "indices" : [ 119, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566527109284515840",
    "text" : "Roses are constructed as red\nViolets are stereotyped as blue\nClearly a CDA is needed\nWith a quantitative component too\n#AcademicValentines",
    "id" : 566527109284515840,
    "created_at" : "2015-02-14 09:19:23 +0000",
    "user" : {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "protected" : false,
      "id_str" : "187484412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603260667534127104\/FkSbeNEt_normal.jpg",
      "id" : 187484412,
      "verified" : false
    }
  },
  "id" : 566530582562492416,
  "created_at" : "2015-02-14 09:33:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Daniels",
      "screen_name" : "matthew_daniels",
      "indices" : [ 3, 19 ],
      "id_str" : "14328463",
      "id" : 14328463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Zexn03sGiI",
      "expanded_url" : "http:\/\/samplestitch.com",
      "display_url" : "samplestitch.com"
    } ]
  },
  "geo" : { },
  "id_str" : "566320567679451136",
  "text" : "RT @matthew_daniels: I've been working on an interactive hip hop sampler for a while...would love some feedback: http:\/\/t.co\/Zexn03sGiI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Zexn03sGiI",
        "expanded_url" : "http:\/\/samplestitch.com",
        "display_url" : "samplestitch.com"
      } ]
    },
    "geo" : { },
    "id_str" : "566247002196176896",
    "text" : "I've been working on an interactive hip hop sampler for a while...would love some feedback: http:\/\/t.co\/Zexn03sGiI",
    "id" : 566247002196176896,
    "created_at" : "2015-02-13 14:46:20 +0000",
    "user" : {
      "name" : "Matt Daniels",
      "screen_name" : "matthew_daniels",
      "protected" : false,
      "id_str" : "14328463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520248912943128576\/Lqk11ogo_normal.png",
      "id" : 14328463,
      "verified" : false
    }
  },
  "id" : 566320567679451136,
  "created_at" : "2015-02-13 19:38:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ROAR Magazine",
      "screen_name" : "ROAR_Magazine",
      "indices" : [ 82, 96 ],
      "id_str" : "282272701",
      "id" : 282272701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/nr6T6SZIKE",
      "expanded_url" : "http:\/\/roarmag.org\/2015\/02\/hsbc-scandal-austerity-finance\/",
      "display_url" : "roarmag.org\/2015\/02\/hsbc-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566307961614909441",
  "text" : "HSBC and the upside-down world of austerity politics - http:\/\/t.co\/nr6T6SZIKE via @ROAR_Magazine",
  "id" : 566307961614909441,
  "created_at" : "2015-02-13 18:48:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 104, 120 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/gULchIBiFh",
      "expanded_url" : "http:\/\/wp.me\/p3swZr-8m",
      "display_url" : "wp.me\/p3swZr-8m"
    } ]
  },
  "geo" : { },
  "id_str" : "566306352906391553",
  "text" : "Why are lobbyists for Israel providing official statistics on anti-Semitism? http:\/\/t.co\/gULchIBiFh via @wordpressdotcom",
  "id" : 566306352906391553,
  "created_at" : "2015-02-13 18:42:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566281948700487680",
  "geo" : { },
  "id_str" : "566289728887349248",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar Bez is launching a political party this week apparently in bed",
  "id" : 566289728887349248,
  "in_reply_to_status_id" : 566281948700487680,
  "created_at" : "2015-02-13 17:36:07 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566277900127981568",
  "geo" : { },
  "id_str" : "566279613819940864",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar or a Frank Sidebottom tribute? :)",
  "id" : 566279613819940864,
  "in_reply_to_status_id" : 566277900127981568,
  "created_at" : "2015-02-13 16:55:55 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Phrasal Verb Demon",
      "screen_name" : "phrasalverbdmon",
      "indices" : [ 21, 37 ],
      "id_str" : "87405828",
      "id" : 87405828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/7uuNqAITKE",
      "expanded_url" : "http:\/\/www.phrasalverbdemon.com\/",
      "display_url" : "phrasalverbdemon.com"
    } ]
  },
  "in_reply_to_status_id_str" : "566223720578940929",
  "geo" : { },
  "id_str" : "566224327532883968",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish the @phrasalverbdmon site  - http:\/\/t.co\/7uuNqAITKE is worth checking if u haven't already",
  "id" : 566224327532883968,
  "in_reply_to_status_id" : 566223720578940929,
  "created_at" : "2015-02-13 13:16:14 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566220549777420289",
  "geo" : { },
  "id_str" : "566220860865138688",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish great let me know how that goes, not sure in current form is ideally suited for students?",
  "id" : 566220860865138688,
  "in_reply_to_status_id" : 566220549777420289,
  "created_at" : "2015-02-13 13:02:27 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/vsvBaHR7jh",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/blog-shoutouts\/",
      "display_url" : "eflnotes.wordpress.com\/blog-shoutouts\/"
    } ]
  },
  "geo" : { },
  "id_str" : "566220641012318210",
  "text" : "updated my blog shoutouts for Jan &amp; Feb maybe u might find something to use there as well https:\/\/t.co\/vsvBaHR7jh",
  "id" : 566220641012318210,
  "created_at" : "2015-02-13 13:01:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566220002710536192",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish really appreciate the RT fella have a good w\/e!",
  "id" : 566220002710536192,
  "created_at" : "2015-02-13 12:59:03 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 3, 15 ],
      "id_str" : "142598896",
      "id" : 142598896
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 87, 101 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hj0IcadMNs",
      "expanded_url" : "http:\/\/bit.ly\/16OOUFg",
      "display_url" : "bit.ly\/16OOUFg"
    } ]
  },
  "geo" : { },
  "id_str" : "566195843213316096",
  "text" : "RT @Neil_Selwyn: 'Wikipedia should be better integrated into teaching' - coverage from @timeshighered of our HE #edtech research - http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TimesHigherEducation",
        "screen_name" : "timeshighered",
        "indices" : [ 70, 84 ],
        "id_str" : "23602600",
        "id" : 23602600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/hj0IcadMNs",
        "expanded_url" : "http:\/\/bit.ly\/16OOUFg",
        "display_url" : "bit.ly\/16OOUFg"
      } ]
    },
    "geo" : { },
    "id_str" : "565300932452569089",
    "text" : "'Wikipedia should be better integrated into teaching' - coverage from @timeshighered of our HE #edtech research - http:\/\/t.co\/hj0IcadMNs",
    "id" : 565300932452569089,
    "created_at" : "2015-02-11 00:06:59 +0000",
    "user" : {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "protected" : false,
      "id_str" : "142598896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726948956538728448\/nzGgydvr_normal.jpg",
      "id" : 142598896,
      "verified" : false
    }
  },
  "id" : 566195843213316096,
  "created_at" : "2015-02-13 11:23:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566105242203197440",
  "geo" : { },
  "id_str" : "566159109029109760",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson thx David have a good w\/e :)",
  "id" : 566159109029109760,
  "in_reply_to_status_id" : 566105242203197440,
  "created_at" : "2015-02-13 08:57:04 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/zDF5X6qrfo",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/02\/12\/first-one-to-one-laptop-program\/",
      "display_url" : "hackeducation.com\/2015\/02\/12\/fir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566035883565285377",
  "text" : "RT @audreywatters: 25 years ago today: the first school one-to-one laptop program http:\/\/t.co\/zDF5X6qrfo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/zDF5X6qrfo",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/02\/12\/first-one-to-one-laptop-program\/",
        "display_url" : "hackeducation.com\/2015\/02\/12\/fir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565772717475889152",
    "text" : "25 years ago today: the first school one-to-one laptop program http:\/\/t.co\/zDF5X6qrfo",
    "id" : 565772717475889152,
    "created_at" : "2015-02-12 07:21:42 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 566035883565285377,
  "created_at" : "2015-02-13 00:47:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/zwLVlpcCxE",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/02\/12\/a-portfolio-of-connections\/",
      "display_url" : "hapgood.us\/2015\/02\/12\/a-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566033844915421184",
  "text" : "RT @holden: A portfolio of connections: rethinking our ridiculously small notions of the power of hypertext: http:\/\/t.co\/zwLVlpcCxE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/zwLVlpcCxE",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/02\/12\/a-portfolio-of-connections\/",
        "display_url" : "hapgood.us\/2015\/02\/12\/a-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566031614971346944",
    "text" : "A portfolio of connections: rethinking our ridiculously small notions of the power of hypertext: http:\/\/t.co\/zwLVlpcCxE",
    "id" : 566031614971346944,
    "created_at" : "2015-02-13 00:30:28 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 566033844915421184,
  "created_at" : "2015-02-13 00:39:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/sa9fWrUAYE",
      "expanded_url" : "http:\/\/rt.com\/op-edge\/231599-nazis-williams-syria-ukraine\/#.VN1AA2Oy6Io.twitter",
      "display_url" : "rt.com\/op-edge\/231599\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566025616127188992",
  "text" : "I\u2019m confused, can anyone help me? \u2013 Part 4 \u2014 RT Op-Edge http:\/\/t.co\/sa9fWrUAYE",
  "id" : 566025616127188992,
  "created_at" : "2015-02-13 00:06:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Snow",
      "screen_name" : "jonsnowC4",
      "indices" : [ 62, 72 ],
      "id_str" : "128216887",
      "id" : 128216887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/i4TIVTXW1t",
      "expanded_url" : "http:\/\/youtu.be\/YmshN5b92Ic",
      "display_url" : "youtu.be\/YmshN5b92Ic"
    } ]
  },
  "geo" : { },
  "id_str" : "566024468901154816",
  "text" : "this is what passes for UK \"journalism\", Noam Chomsky schools @jonsnowC4 http:\/\/t.co\/i4TIVTXW1t",
  "id" : 566024468901154816,
  "created_at" : "2015-02-13 00:02:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 83, 94 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "auselt",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HRB9AOXAtT",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-SU",
      "display_url" : "wp.me\/pgHyE-SU"
    } ]
  },
  "geo" : { },
  "id_str" : "566018825301135361",
  "text" : "...and the classroom stars aligned - in class use of the PHaVE dictionary #eltchat #eltchinwag #keltchat #auselt http:\/\/t.co\/HRB9AOXAtT",
  "id" : 566018825301135361,
  "created_at" : "2015-02-12 23:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IH London",
      "screen_name" : "IHLondon",
      "indices" : [ 3, 12 ],
      "id_str" : "21182478",
      "id" : 21182478
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 14, 25 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 56, 60 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Y8ZwdrCvXQ",
      "expanded_url" : "http:\/\/ow.ly\/ISjFi",
      "display_url" : "ow.ly\/ISjFi"
    } ]
  },
  "geo" : { },
  "id_str" : "565992475974979584",
  "text" : "RT @IHLondon: @hughdellar challenges the orthodoxies of #EFL classroom management in ten short videos: http:\/\/t.co\/Y8ZwdrCvXQ #TEFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 0, 11 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFL",
        "indices" : [ 42, 46 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Y8ZwdrCvXQ",
        "expanded_url" : "http:\/\/ow.ly\/ISjFi",
        "display_url" : "ow.ly\/ISjFi"
      } ]
    },
    "geo" : { },
    "id_str" : "565794981127127040",
    "in_reply_to_user_id" : 88202140,
    "text" : "@hughdellar challenges the orthodoxies of #EFL classroom management in ten short videos: http:\/\/t.co\/Y8ZwdrCvXQ #TEFL",
    "id" : 565794981127127040,
    "created_at" : "2015-02-12 08:50:10 +0000",
    "in_reply_to_screen_name" : "hughdellar",
    "in_reply_to_user_id_str" : "88202140",
    "user" : {
      "name" : "IH London",
      "screen_name" : "IHLondon",
      "protected" : false,
      "id_str" : "21182478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1764387699\/ihl-fb_normal.gif",
      "id" : 21182478,
      "verified" : false
    }
  },
  "id" : 565992475974979584,
  "created_at" : "2015-02-12 21:54:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/bWgRuYkcN1",
      "expanded_url" : "https:\/\/inquiryblog.wordpress.com\/2015\/02\/12\/the-question-formulation-technique\/",
      "display_url" : "inquiryblog.wordpress.com\/2015\/02\/12\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565981686543155200",
  "text" : "The Question Formulation Technique https:\/\/t.co\/bWgRuYkcN1",
  "id" : 565981686543155200,
  "created_at" : "2015-02-12 21:12:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "macmillanelt",
      "screen_name" : "MacmillanELT",
      "indices" : [ 0, 13 ],
      "id_str" : "16294897",
      "id" : 16294897
    }, {
      "name" : "Jayne Whistance",
      "screen_name" : "JayneWhistance",
      "indices" : [ 14, 29 ],
      "id_str" : "539398225",
      "id" : 539398225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565100315478069248",
  "geo" : { },
  "id_str" : "565978615863836672",
  "in_reply_to_user_id" : 16294897,
  "text" : "@MacmillanELT @JayneWhistance out of 12 cities surveyed 6 nominally speak English :\/ bah humbug PR for a dating site",
  "id" : 565978615863836672,
  "in_reply_to_status_id" : 565100315478069248,
  "created_at" : "2015-02-12 20:59:52 +0000",
  "in_reply_to_screen_name" : "MacmillanELT",
  "in_reply_to_user_id_str" : "16294897",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/T8lcW3DXb2",
      "expanded_url" : "https:\/\/speechdudes.wordpress.com\/2015\/02\/12\/valentines-presidents-whose-day-is-it\/",
      "display_url" : "speechdudes.wordpress.com\/2015\/02\/12\/val\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565896241792700417",
  "text" : "Valentine\u2019s? President\u2019s? Whose Day IS It? https:\/\/t.co\/T8lcW3DXb2",
  "id" : 565896241792700417,
  "created_at" : "2015-02-12 15:32:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565874466526601216",
  "geo" : { },
  "id_str" : "565882039954841600",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen glad you liked it Stephen :)",
  "id" : 565882039954841600,
  "in_reply_to_status_id" : 565874466526601216,
  "created_at" : "2015-02-12 14:36:06 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/2SwNEyDOBG",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/2015\/02\/12\/paper_powerpoints\/",
      "display_url" : "decentralisedteachingandlearning.com\/2015\/02\/12\/pap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565881650916380672",
  "text" : "Paper Powerpoints http:\/\/t.co\/2SwNEyDOBG",
  "id" : 565881650916380672,
  "created_at" : "2015-02-12 14:34:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565861122431918081",
  "geo" : { },
  "id_str" : "565862373261864960",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 it's an interesting way to represent keywords from a corpus I think",
  "id" : 565862373261864960,
  "in_reply_to_status_id" : 565861122431918081,
  "created_at" : "2015-02-12 13:17:57 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565860594675634176",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 thx for RT of demand high poetry ;)",
  "id" : 565860594675634176,
  "created_at" : "2015-02-12 13:10:53 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 64, 75 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "mikejharrison",
      "indices" : [ 76, 90 ],
      "id_str" : "141956495",
      "id" : 141956495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/F4fpkPgXSg",
      "expanded_url" : "https:\/\/e117f55cd2f9e52e4e6d613d1866d2aa95aff6b7.googledrive.com\/host\/0B7FW2BYaBgeibnlQOUlKOGUxWDQ\/demand_high_flurry.html",
      "display_url" : "\u2026d613d1866d2aa95aff6b7.googledrive.com\/host\/0B7FW2BYa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565780596950306817",
  "geo" : { },
  "id_str" : "565795546074714112",
  "in_reply_to_user_id" : 408365496,
  "text" : "If u have little time to read debate try a poetic point of view @leoselivan @mikejharrison https:\/\/t.co\/F4fpkPgXSg :)",
  "id" : 565795546074714112,
  "in_reply_to_status_id" : 565780596950306817,
  "created_at" : "2015-02-12 08:52:24 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/84wWrcpqC7",
      "expanded_url" : "http:\/\/Climate.gov",
      "display_url" : "Climate.gov"
    }, {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/C6uMtckqJj",
      "expanded_url" : "http:\/\/climate.gov\/news-features\/videos\/old-ice-arctic-vanishingly-rare#.VNxJnagiCRI.twitter",
      "display_url" : "climate.gov\/news-features\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565761024843083776",
  "text" : "Old ice in Arctic vanishingly rare | NOAA http:\/\/t.co\/84wWrcpqC7 http:\/\/t.co\/C6uMtckqJj",
  "id" : 565761024843083776,
  "created_at" : "2015-02-12 06:35:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "indices" : [ 3, 13 ],
      "id_str" : "303905601",
      "id" : 303905601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/mKMUhf7SLv",
      "expanded_url" : "http:\/\/frenchteachernet.blogspot.co.uk\/2015\/02\/conscious-and-unconscious-language_12.html",
      "display_url" : "frenchteachernet.blogspot.co.uk\/2015\/02\/consci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565755937743732736",
  "text" : "RT @spsmith45: Final blog in the series about conscious and unconscious 2nd language learning. Implications for teachers. http:\/\/t.co\/mKMUh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/mKMUhf7SLv",
        "expanded_url" : "http:\/\/frenchteachernet.blogspot.co.uk\/2015\/02\/conscious-and-unconscious-language_12.html",
        "display_url" : "frenchteachernet.blogspot.co.uk\/2015\/02\/consci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565669371390197762",
    "text" : "Final blog in the series about conscious and unconscious 2nd language learning. Implications for teachers. http:\/\/t.co\/mKMUhf7SLv",
    "id" : 565669371390197762,
    "created_at" : "2015-02-12 00:31:02 +0000",
    "user" : {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "protected" : false,
      "id_str" : "303905601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766281389037813760\/eXdJEsQr_normal.jpg",
      "id" : 303905601,
      "verified" : false
    }
  },
  "id" : 565755937743732736,
  "created_at" : "2015-02-12 06:15:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565653887835975680",
  "geo" : { },
  "id_str" : "565655033426219009",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C you don't need antconc to play around with the html",
  "id" : 565655033426219009,
  "in_reply_to_status_id" : 565653887835975680,
  "created_at" : "2015-02-11 23:34:03 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565652814895271937",
  "geo" : { },
  "id_str" : "565653741660291074",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C it's a concordance program",
  "id" : 565653741660291074,
  "in_reply_to_status_id" : 565652814895271937,
  "created_at" : "2015-02-11 23:28:56 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565650281556639744",
  "geo" : { },
  "id_str" : "565651435275423745",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C hi, have a look at the html source, used antconc to pick keywords from comments to DH posts",
  "id" : 565651435275423745,
  "in_reply_to_status_id" : 565650281556639744,
  "created_at" : "2015-02-11 23:19:46 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "EFL",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "grammar",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/cEuOwV5VG4",
      "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/02\/some-reflections-on-the-universal-panacea\/",
      "display_url" : "lexicallab.com\/2015\/02\/some-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565646730650484736",
  "text" : "RT @hughdellar: #ELT #EFL #grammar Just put up a post reflecting on my first lesson with a new FOCUS ON GRAMMAR course class: http:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "EFL",
        "indices" : [ 5, 9 ]
      }, {
        "text" : "grammar",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/cEuOwV5VG4",
        "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/02\/some-reflections-on-the-universal-panacea\/",
        "display_url" : "lexicallab.com\/2015\/02\/some-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565645052358430720",
    "text" : "#ELT #EFL #grammar Just put up a post reflecting on my first lesson with a new FOCUS ON GRAMMAR course class: http:\/\/t.co\/cEuOwV5VG4",
    "id" : 565645052358430720,
    "created_at" : "2015-02-11 22:54:24 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 565646730650484736,
  "created_at" : "2015-02-11 23:01:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 122, 131 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/GhEeHwnQB7",
      "expanded_url" : "https:\/\/googledrive.com\/host\/0B7FW2BYaBgeibnlQOUlKOGUxWDQ\/demand_high_flurry.html",
      "display_url" : "googledrive.com\/host\/0B7FW2BYa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565639355893809152",
  "text" : "demand high flurry, everyone loves poetry https:\/\/t.co\/GhEeHwnQB7 made (mostly) from flurry comments #eltchat #eltchinwag #keltchat #AusELT",
  "id" : 565639355893809152,
  "created_at" : "2015-02-11 22:31:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565528870670315520",
  "geo" : { },
  "id_str" : "565638206042177536",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet sure is :)",
  "id" : 565638206042177536,
  "in_reply_to_status_id" : 565528870670315520,
  "created_at" : "2015-02-11 22:27:12 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    }, {
      "name" : "Teaching Village",
      "screen_name" : "TeachingVillage",
      "indices" : [ 111, 127 ],
      "id_str" : "19234804",
      "id" : 19234804
    }, {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 128, 140 ],
      "id_str" : "21313816",
      "id" : 21313816
    }, {
      "name" : "Richmond",
      "screen_name" : "Richmond_ELT",
      "indices" : [ 139, 140 ],
      "id_str" : "455924296",
      "id" : 455924296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/cBJUPipjS2",
      "expanded_url" : "http:\/\/www.richmondshare.com.br\/video-listening-skills\/",
      "display_url" : "richmondshare.com.br\/video-listenin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565583458354085888",
  "text" : "RT @luizotavioELT: 7 things to keep in mind when using video to teach listening skills.\nhttp:\/\/t.co\/cBJUPipjS2\n@TeachingVillage @TeachingEn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Teaching Village",
        "screen_name" : "TeachingVillage",
        "indices" : [ 92, 108 ],
        "id_str" : "19234804",
        "id" : 19234804
      }, {
        "name" : "TeachingEnglish",
        "screen_name" : "TeachingEnglish",
        "indices" : [ 109, 125 ],
        "id_str" : "21313816",
        "id" : 21313816
      }, {
        "name" : "Richmond",
        "screen_name" : "Richmond_ELT",
        "indices" : [ 126, 139 ],
        "id_str" : "455924296",
        "id" : 455924296
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/cBJUPipjS2",
        "expanded_url" : "http:\/\/www.richmondshare.com.br\/video-listening-skills\/",
        "display_url" : "richmondshare.com.br\/video-listenin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565518447577403392",
    "text" : "7 things to keep in mind when using video to teach listening skills.\nhttp:\/\/t.co\/cBJUPipjS2\n@TeachingVillage @TeachingEnglish @Richmond_ELT",
    "id" : 565518447577403392,
    "created_at" : "2015-02-11 14:31:19 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 565583458354085888,
  "created_at" : "2015-02-11 18:49:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565274748184436736",
  "geo" : { },
  "id_str" : "565401557731385345",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS thanks old chap :)",
  "id" : 565401557731385345,
  "in_reply_to_status_id" : 565274748184436736,
  "created_at" : "2015-02-11 06:46:50 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason West",
      "screen_name" : "EnglishOutThere",
      "indices" : [ 27, 43 ],
      "id_str" : "66951936",
      "id" : 66951936
    }, {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 44, 58 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/eEeEKfKOmR",
      "expanded_url" : "http:\/\/scholarlyoa.com\/2014\/01\/09\/questionable-oa-publisher-launches-with-a-clever-website-and-52-new-journals\/",
      "display_url" : "scholarlyoa.com\/2014\/01\/09\/que\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565109384645464064",
  "geo" : { },
  "id_str" : "565145257042788352",
  "in_reply_to_user_id" : 66951936,
  "text" : "hmm http:\/\/t.co\/eEeEKfKOmR @EnglishOutThere @GrowMyEnglish",
  "id" : 565145257042788352,
  "in_reply_to_status_id" : 565109384645464064,
  "created_at" : "2015-02-10 13:48:23 +0000",
  "in_reply_to_screen_name" : "EnglishOutThere",
  "in_reply_to_user_id_str" : "66951936",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    }, {
      "name" : "Jonathan Freedland",
      "screen_name" : "Freedland",
      "indices" : [ 68, 78 ],
      "id_str" : "44578328",
      "id" : 44578328
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 139, 140 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/sZHbCPGz50",
      "expanded_url" : "http:\/\/shar.es\/1ozDic",
      "display_url" : "shar.es\/1ozDic"
    } ]
  },
  "geo" : { },
  "id_str" : "565141783483801600",
  "text" : "RT @Jonathan_K_Cook: The grand hypocrisy of the Guardian's Jonathan @freedland on BBC Question Time | Jonathan Cook's Blog http:\/\/t.co\/sZHb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Freedland",
        "screen_name" : "Freedland",
        "indices" : [ 47, 57 ],
        "id_str" : "44578328",
        "id" : 44578328
      }, {
        "name" : "George Galloway",
        "screen_name" : "georgegalloway",
        "indices" : [ 125, 140 ],
        "id_str" : "15484198",
        "id" : 15484198
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/sZHbCPGz50",
        "expanded_url" : "http:\/\/shar.es\/1ozDic",
        "display_url" : "shar.es\/1ozDic"
      } ]
    },
    "geo" : { },
    "id_str" : "564910953553469441",
    "text" : "The grand hypocrisy of the Guardian's Jonathan @freedland on BBC Question Time | Jonathan Cook's Blog http:\/\/t.co\/sZHbCPGz50 @georgegalloway",
    "id" : 564910953553469441,
    "created_at" : "2015-02-09 22:17:21 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 565141783483801600,
  "created_at" : "2015-02-10 13:34:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/WXN4vNo489",
      "expanded_url" : "http:\/\/tecsquared.com\/node\/88",
      "display_url" : "tecsquared.com\/node\/88"
    } ]
  },
  "geo" : { },
  "id_str" : "565135102897045505",
  "text" : "In the Salt Mines: Death of a Classroom http:\/\/t.co\/WXN4vNo489",
  "id" : 565135102897045505,
  "created_at" : "2015-02-10 13:08:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 3, 12 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 56, 64 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/jIDlI4Sq53",
      "expanded_url" : "http:\/\/sco.lt\/7Hfj4j",
      "display_url" : "sco.lt\/7Hfj4j"
    } ]
  },
  "geo" : { },
  "id_str" : "565131090265116672",
  "text" : "RT @whyshona: A class with no teacher: Darren Elliott | @scoopit http:\/\/t.co\/jIDlI4Sq53",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scoop.it",
        "screen_name" : "scoopit",
        "indices" : [ 42, 50 ],
        "id_str" : "209484168",
        "id" : 209484168
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/jIDlI4Sq53",
        "expanded_url" : "http:\/\/sco.lt\/7Hfj4j",
        "display_url" : "sco.lt\/7Hfj4j"
      } ]
    },
    "geo" : { },
    "id_str" : "565128459265921026",
    "text" : "A class with no teacher: Darren Elliott | @scoopit http:\/\/t.co\/jIDlI4Sq53",
    "id" : 565128459265921026,
    "created_at" : "2015-02-10 12:41:38 +0000",
    "user" : {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "protected" : false,
      "id_str" : "121063600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459074158974889984\/nMzMr6_1_normal.jpeg",
      "id" : 121063600,
      "verified" : false
    }
  },
  "id" : 565131090265116672,
  "created_at" : "2015-02-10 12:52:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "vaclav",
      "screen_name" : "vaclavbrezina",
      "indices" : [ 35, 49 ],
      "id_str" : "1201576646",
      "id" : 1201576646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/u5ziPmMFcg",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1568",
      "display_url" : "cass.lancs.ac.uk\/?p=1568"
    } ]
  },
  "geo" : { },
  "id_str" : "565109138225922048",
  "text" : "RT @CorpusSocialSci: New blog from @vaclavbrezina on the Trinity Lancaster Corpus at the International ESOL Examiner Training Conference ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "vaclav",
        "screen_name" : "vaclavbrezina",
        "indices" : [ 14, 28 ],
        "id_str" : "1201576646",
        "id" : 1201576646
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/u5ziPmMFcg",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1568",
        "display_url" : "cass.lancs.ac.uk\/?p=1568"
      } ]
    },
    "geo" : { },
    "id_str" : "565076006802034689",
    "text" : "New blog from @vaclavbrezina on the Trinity Lancaster Corpus at the International ESOL Examiner Training Conference http:\/\/t.co\/u5ziPmMFcg",
    "id" : 565076006802034689,
    "created_at" : "2015-02-10 09:13:13 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 565109138225922048,
  "created_at" : "2015-02-10 11:24:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "indices" : [ 3, 13 ],
      "id_str" : "303905601",
      "id" : 303905601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mfltwitterati",
      "indices" : [ 74, 88 ]
    }, {
      "text" : "langchat",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/15rXKmdJ86",
      "expanded_url" : "http:\/\/frenchteachernet.blogspot.co.uk",
      "display_url" : "frenchteachernet.blogspot.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "565021344803610624",
  "text" : "RT @spsmith45: Part 5: Krashen and Krashen bashin' http:\/\/t.co\/15rXKmdJ86 #mfltwitterati #langchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mfltwitterati",
        "indices" : [ 59, 73 ]
      }, {
        "text" : "langchat",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/15rXKmdJ86",
        "expanded_url" : "http:\/\/frenchteachernet.blogspot.co.uk",
        "display_url" : "frenchteachernet.blogspot.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "564922762452828160",
    "text" : "Part 5: Krashen and Krashen bashin' http:\/\/t.co\/15rXKmdJ86 #mfltwitterati #langchat",
    "id" : 564922762452828160,
    "created_at" : "2015-02-09 23:04:16 +0000",
    "user" : {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "protected" : false,
      "id_str" : "303905601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766281389037813760\/eXdJEsQr_normal.jpg",
      "id" : 303905601,
      "verified" : false
    }
  },
  "id" : 565021344803610624,
  "created_at" : "2015-02-10 05:36:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Democracy Now!",
      "screen_name" : "democracynow",
      "indices" : [ 125, 138 ],
      "id_str" : "16935292",
      "id" : 16935292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/JWsJeHtM6J",
      "expanded_url" : "http:\/\/www.democracynow.org\/2015\/2\/9\/exclusive_freed_cia_whistleblower_john_kiriakou",
      "display_url" : "democracynow.org\/2015\/2\/9\/exclu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565011759480995840",
  "text" : "Exclusive: Freed CIA Whistleblower John Kiriakou Says \"I Would Do It All Again\" to Expose Torture http:\/\/t.co\/JWsJeHtM6J via @democracynow",
  "id" : 565011759480995840,
  "created_at" : "2015-02-10 04:57:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564869586613719040",
  "geo" : { },
  "id_str" : "564870075577294848",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland prob b lurking if i get time to :)",
  "id" : 564870075577294848,
  "in_reply_to_status_id" : 564869586613719040,
  "created_at" : "2015-02-09 19:34:55 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7ZII1t8WSO",
      "expanded_url" : "http:\/\/andrewgelman.com\/2015\/02\/09\/24741\/",
      "display_url" : "andrewgelman.com\/2015\/02\/09\/247\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564866597421338625",
  "text" : "RT @mrkm_a: Discussion with Steven Pinker connecting cognitive psychology research to the difficulties of writing \/ Statistical \u2026\nhttp:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/7ZII1t8WSO",
        "expanded_url" : "http:\/\/andrewgelman.com\/2015\/02\/09\/24741\/",
        "display_url" : "andrewgelman.com\/2015\/02\/09\/247\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564811083840778240",
    "text" : "Discussion with Steven Pinker connecting cognitive psychology research to the difficulties of writing \/ Statistical \u2026\nhttp:\/\/t.co\/7ZII1t8WSO",
    "id" : 564811083840778240,
    "created_at" : "2015-02-09 15:40:30 +0000",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 564866597421338625,
  "created_at" : "2015-02-09 19:21:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "indices" : [ 13, 20 ],
      "id_str" : "2937071",
      "id" : 2937071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/4TVLCzlKtD",
      "expanded_url" : "http:\/\/www.infoworld.com\/article\/2880204\/collaboration-software\/wiki-creator-reinvents-collaboration-again.html",
      "display_url" : "infoworld.com\/article\/288020\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564861035698733057",
  "text" : "RT @holden: .@judell has written one of the more concise explanations of federated wiki and why it matters in Infoworld: http:\/\/t.co\/4TVLCz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Udell",
        "screen_name" : "judell",
        "indices" : [ 1, 8 ],
        "id_str" : "2937071",
        "id" : 2937071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/4TVLCzlKtD",
        "expanded_url" : "http:\/\/www.infoworld.com\/article\/2880204\/collaboration-software\/wiki-creator-reinvents-collaboration-again.html",
        "display_url" : "infoworld.com\/article\/288020\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564833734528995328",
    "text" : ".@judell has written one of the more concise explanations of federated wiki and why it matters in Infoworld: http:\/\/t.co\/4TVLCzlKtD",
    "id" : 564833734528995328,
    "created_at" : "2015-02-09 17:10:31 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 564861035698733057,
  "created_at" : "2015-02-09 18:59:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "indices" : [ 0, 12 ],
      "id_str" : "83570076",
      "id" : 83570076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564799182591254528",
  "geo" : { },
  "id_str" : "564850330144604161",
  "in_reply_to_user_id" : 18602422,
  "text" : "@nottyknight ok thanks :)",
  "id" : 564850330144604161,
  "in_reply_to_status_id" : 564799182591254528,
  "created_at" : "2015-02-09 18:16:27 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 97, 105 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/j2xYj87Q0m",
      "expanded_url" : "http:\/\/youtu.be\/9JVVRWBekYo",
      "display_url" : "youtu.be\/9JVVRWBekYo"
    } ]
  },
  "geo" : { },
  "id_str" : "564815784506294273",
  "text" : "Calls to Action: Noam Chomsky on the dangers of standardized testing: http:\/\/t.co\/j2xYj87Q0m via @YouTube",
  "id" : 564815784506294273,
  "created_at" : "2015-02-09 15:59:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "indices" : [ 0, 12 ],
      "id_str" : "83570076",
      "id" : 83570076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564728553372397570",
  "geo" : { },
  "id_str" : "564799182591254528",
  "in_reply_to_user_id" : 83570076,
  "text" : "@nottyknight hi is it possible to get access to newsletters?",
  "id" : 564799182591254528,
  "in_reply_to_status_id" : 564728553372397570,
  "created_at" : "2015-02-09 14:53:13 +0000",
  "in_reply_to_screen_name" : "nottyknight",
  "in_reply_to_user_id_str" : "83570076",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 3, 19 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 67, 83 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MarekKiczkowiak\/status\/564774669900070912\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rngbA4qnww",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Z7kbSIEAA0WeM.jpg",
      "id_str" : "564774669010866176",
      "id" : 564774669010866176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Z7kbSIEAA0WeM.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1772,
        "resize" : "fit",
        "w" : 1772
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rngbA4qnww"
    } ],
    "hashtags" : [ {
      "text" : "teflequity",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/l5dmRaVVLY",
      "expanded_url" : "http:\/\/wp.me\/P4Gcmh-a6",
      "display_url" : "wp.me\/P4Gcmh-a6"
    } ]
  },
  "geo" : { },
  "id_str" : "564794023572156416",
  "text" : "RT @MarekKiczkowiak: Don't miss the first #teflequity webinar with @theteacherjames on 'Why I wish I was a nNEST': http:\/\/t.co\/l5dmRaVVLY h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Taylor",
        "screen_name" : "theteacherjames",
        "indices" : [ 46, 62 ],
        "id_str" : "71746265",
        "id" : 71746265
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MarekKiczkowiak\/status\/564774669900070912\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/rngbA4qnww",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Z7kbSIEAA0WeM.jpg",
        "id_str" : "564774669010866176",
        "id" : 564774669010866176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Z7kbSIEAA0WeM.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1772,
          "resize" : "fit",
          "w" : 1772
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rngbA4qnww"
      } ],
      "hashtags" : [ {
        "text" : "teflequity",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/l5dmRaVVLY",
        "expanded_url" : "http:\/\/wp.me\/P4Gcmh-a6",
        "display_url" : "wp.me\/P4Gcmh-a6"
      } ]
    },
    "geo" : { },
    "id_str" : "564774669900070912",
    "text" : "Don't miss the first #teflequity webinar with @theteacherjames on 'Why I wish I was a nNEST': http:\/\/t.co\/l5dmRaVVLY http:\/\/t.co\/rngbA4qnww",
    "id" : 564774669900070912,
    "created_at" : "2015-02-09 13:15:48 +0000",
    "user" : {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "protected" : false,
      "id_str" : "2561325079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476735541497450498\/KCwdjZhZ_normal.jpeg",
      "id" : 2561325079,
      "verified" : false
    }
  },
  "id" : 564794023572156416,
  "created_at" : "2015-02-09 14:32:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "indices" : [ 3, 15 ],
      "id_str" : "83570076",
      "id" : 83570076
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nottyknight\/status\/564728553372397570\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DsWLa7ie7Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ZRoGlIYAAH9ao.png",
      "id_str" : "564728552684544000",
      "id" : 564728552684544000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ZRoGlIYAAH9ao.png",
      "sizes" : [ {
        "h" : 80,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 80,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 80,
        "resize" : "crop",
        "w" : 80
      }, {
        "h" : 80,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 58,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DsWLa7ie7Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/OHdOr3Ou2s",
      "expanded_url" : "http:\/\/blogs.cardiff.ac.uk\/lexicalstudies\/",
      "display_url" : "blogs.cardiff.ac.uk\/lexicalstudies\/"
    } ]
  },
  "geo" : { },
  "id_str" : "564790503997472768",
  "text" : "RT @nottyknight: Check out the new Lexical Studies @ CardiffUni site for info on our 'Lexical Studies Month' http:\/\/t.co\/OHdOr3Ou2s http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nottyknight\/status\/564728553372397570\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/DsWLa7ie7Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ZRoGlIYAAH9ao.png",
        "id_str" : "564728552684544000",
        "id" : 564728552684544000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ZRoGlIYAAH9ao.png",
        "sizes" : [ {
          "h" : 80,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 80,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 80,
          "resize" : "crop",
          "w" : 80
        }, {
          "h" : 80,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 58,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DsWLa7ie7Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/OHdOr3Ou2s",
        "expanded_url" : "http:\/\/blogs.cardiff.ac.uk\/lexicalstudies\/",
        "display_url" : "blogs.cardiff.ac.uk\/lexicalstudies\/"
      } ]
    },
    "geo" : { },
    "id_str" : "564728553372397570",
    "text" : "Check out the new Lexical Studies @ CardiffUni site for info on our 'Lexical Studies Month' http:\/\/t.co\/OHdOr3Ou2s http:\/\/t.co\/DsWLa7ie7Y",
    "id" : 564728553372397570,
    "created_at" : "2015-02-09 10:12:33 +0000",
    "user" : {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "protected" : false,
      "id_str" : "83570076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1250586986\/Twitter_normal.png",
      "id" : 83570076,
      "verified" : false
    }
  },
  "id" : 564790503997472768,
  "created_at" : "2015-02-09 14:18:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 144 ],
      "url" : "http:\/\/t.co\/WbE91fRc4x",
      "expanded_url" : "http:\/\/socialtheoryapplied.com\/2015\/02\/08\/can-emancipation-happen-school\/",
      "display_url" : "socialtheoryapplied.com\/2015\/02\/08\/can\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564550430538342400",
  "text" : "RT @gbiesta: new review of Bingham &amp; Biesta (2010) \u2018Jacques Ranciere: Education, Truth, Emancipation\u2019 by Allessandra Aloisi http:\/\/t.co\/WbE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/WbE91fRc4x",
        "expanded_url" : "http:\/\/socialtheoryapplied.com\/2015\/02\/08\/can-emancipation-happen-school\/",
        "display_url" : "socialtheoryapplied.com\/2015\/02\/08\/can\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564521140828528640",
    "text" : "new review of Bingham &amp; Biesta (2010) \u2018Jacques Ranciere: Education, Truth, Emancipation\u2019 by Allessandra Aloisi http:\/\/t.co\/WbE91fRc4x",
    "id" : 564521140828528640,
    "created_at" : "2015-02-08 20:28:22 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 564550430538342400,
  "created_at" : "2015-02-08 22:24:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Roach",
      "screen_name" : "RoachPeterJ",
      "indices" : [ 0, 12 ],
      "id_str" : "2218138523",
      "id" : 2218138523
    }, {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 29, 36 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564394387317469184",
  "geo" : { },
  "id_str" : "564518525784825857",
  "in_reply_to_user_id" : 2218138523,
  "text" : "@RoachPeterJ great check out @holden blog posts for any further info",
  "id" : 564518525784825857,
  "in_reply_to_status_id" : 564394387317469184,
  "created_at" : "2015-02-08 20:17:59 +0000",
  "in_reply_to_screen_name" : "RoachPeterJ",
  "in_reply_to_user_id_str" : "2218138523",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 3, 11 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "elt",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "lexicalapproach",
      "indices" : [ 109, 125 ]
    }, {
      "text" : "teachertraining",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/5zxwGsedn9",
      "expanded_url" : "http:\/\/wp.me\/p4WoHi-66",
      "display_url" : "wp.me\/p4WoHi-66"
    } ]
  },
  "geo" : { },
  "id_str" : "564510112250077184",
  "text" : "RT @SLBCoop: A summary of our last SLB training session: Teaching Lexically http:\/\/t.co\/5zxwGsedn9 #efl #elt #lexicalapproach #teachertrain\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "elt",
        "indices" : [ 91, 95 ]
      }, {
        "text" : "lexicalapproach",
        "indices" : [ 96, 112 ]
      }, {
        "text" : "teachertraining",
        "indices" : [ 113, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/5zxwGsedn9",
        "expanded_url" : "http:\/\/wp.me\/p4WoHi-66",
        "display_url" : "wp.me\/p4WoHi-66"
      } ]
    },
    "geo" : { },
    "id_str" : "564502060444704769",
    "text" : "A summary of our last SLB training session: Teaching Lexically http:\/\/t.co\/5zxwGsedn9 #efl #elt #lexicalapproach #teachertraining",
    "id" : 564502060444704769,
    "created_at" : "2015-02-08 19:12:33 +0000",
    "user" : {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "protected" : false,
      "id_str" : "2365399801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705151471386546176\/ECVLcba-_normal.jpg",
      "id" : 2365399801,
      "verified" : false
    }
  },
  "id" : 564510112250077184,
  "created_at" : "2015-02-08 19:44:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 80, 92 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/cb9MTzL5fo",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-9ap",
      "display_url" : "wp.me\/p1U04a-9ap"
    } ]
  },
  "geo" : { },
  "id_str" : "564509850772967424",
  "text" : "Man burned alive in Britain - but does anybody care? http:\/\/t.co\/cb9MTzL5fo via @ThomasPride",
  "id" : 564509850772967424,
  "created_at" : "2015-02-08 19:43:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt B PhD",
      "screen_name" : "The_Intermezzo",
      "indices" : [ 0, 15 ],
      "id_str" : "45582028",
      "id" : 45582028
    }, {
      "name" : "David Darts",
      "screen_name" : "daviddarts",
      "indices" : [ 61, 72 ],
      "id_str" : "15828244",
      "id" : 15828244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562691114072023041",
  "geo" : { },
  "id_str" : "564165836148318209",
  "in_reply_to_user_id" : 45582028,
  "text" : "@The_Intermezzo i think this was one of the original uses by @daviddarts",
  "id" : 564165836148318209,
  "in_reply_to_status_id" : 562691114072023041,
  "created_at" : "2015-02-07 20:56:31 +0000",
  "in_reply_to_screen_name" : "The_Intermezzo",
  "in_reply_to_user_id_str" : "45582028",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/3bLxxj2gCf",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/02\/peace-in-our-time.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/02\/peace-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564111516589649922",
  "text" : "RT @pchallinor: New mudgeonry: Peace in our time http:\/\/t.co\/3bLxxj2gCf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/3bLxxj2gCf",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/02\/peace-in-our-time.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/02\/peace-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564066027022331904",
    "text" : "New mudgeonry: Peace in our time http:\/\/t.co\/3bLxxj2gCf",
    "id" : 564066027022331904,
    "created_at" : "2015-02-07 14:19:55 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 564111516589649922,
  "created_at" : "2015-02-07 17:20:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "indices" : [ 3, 15 ],
      "id_str" : "222618390",
      "id" : 222618390
    }, {
      "name" : "Claire Cain Miller",
      "screen_name" : "clairecm",
      "indices" : [ 91, 100 ],
      "id_str" : "17877122",
      "id" : 17877122
    }, {
      "name" : "The Upshot",
      "screen_name" : "UpshotNYT",
      "indices" : [ 105, 115 ],
      "id_str" : "16955870",
      "id" : 16955870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jx0EN5EGnd",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/02\/07\/upshot\/is-the-professor-bossy-or-brilliant-much-depends-on-gender.html?_r=0",
      "display_url" : "nytimes.com\/2015\/02\/07\/ups\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564100651983327232",
  "text" : "RT @benmschmidt: Great writeup with some broader context on my teacher evaluations site by @clairecm for @UpshotNYT : http:\/\/t.co\/jx0EN5EGnd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Claire Cain Miller",
        "screen_name" : "clairecm",
        "indices" : [ 74, 83 ],
        "id_str" : "17877122",
        "id" : 17877122
      }, {
        "name" : "The Upshot",
        "screen_name" : "UpshotNYT",
        "indices" : [ 88, 98 ],
        "id_str" : "16955870",
        "id" : 16955870
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/jx0EN5EGnd",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/02\/07\/upshot\/is-the-professor-bossy-or-brilliant-much-depends-on-gender.html?_r=0",
        "display_url" : "nytimes.com\/2015\/02\/07\/ups\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564083579672858624",
    "text" : "Great writeup with some broader context on my teacher evaluations site by @clairecm for @UpshotNYT : http:\/\/t.co\/jx0EN5EGnd",
    "id" : 564083579672858624,
    "created_at" : "2015-02-07 15:29:40 +0000",
    "user" : {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "protected" : false,
      "id_str" : "222618390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1181931710\/Screen_shot_2010-12-03_at_7.00.07_PM_normal.png",
      "id" : 222618390,
      "verified" : false
    }
  },
  "id" : 564100651983327232,
  "created_at" : "2015-02-07 16:37:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564096738588233728",
  "geo" : { },
  "id_str" : "564097206131884032",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin by contrast adding a single e to dud would cause more interest :)",
  "id" : 564097206131884032,
  "in_reply_to_status_id" : 564096738588233728,
  "created_at" : "2015-02-07 16:23:49 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 17, 32 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564047340265172993",
  "geo" : { },
  "id_str" : "564090012636299264",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @GeoffreyJordan the devil &amp; the deep blue sea :)",
  "id" : 564090012636299264,
  "in_reply_to_status_id" : 564047340265172993,
  "created_at" : "2015-02-07 15:55:13 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 25, 32 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564086706132226048",
  "geo" : { },
  "id_str" : "564088881440882688",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona you could pick @WordLo 's brain maybe?",
  "id" : 564088881440882688,
  "in_reply_to_status_id" : 564086706132226048,
  "created_at" : "2015-02-07 15:50:44 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/TTywyE9WSn",
      "expanded_url" : "http:\/\/recremisi.blogspot.fr\/p\/acrolinxterminology-lifecycle.html",
      "display_url" : "recremisi.blogspot.fr\/p\/acrolinxterm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "564075936682110977",
  "geo" : { },
  "id_str" : "564080210581405696",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hi there may be something here http:\/\/t.co\/TTywyE9WSn",
  "id" : 564080210581405696,
  "in_reply_to_status_id" : 564075936682110977,
  "created_at" : "2015-02-07 15:16:16 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564045495098961920",
  "geo" : { },
  "id_str" : "564046735824400385",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan true but imo he makes a convincing case e.g. making the most of what teachers are given",
  "id" : 564046735824400385,
  "in_reply_to_status_id" : 564045495098961920,
  "created_at" : "2015-02-07 13:03:15 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 0, 9 ],
      "id_str" : "13533482",
      "id" : 13533482
    }, {
      "name" : "Paul Driver",
      "screen_name" : "Paul_Driver",
      "indices" : [ 10, 22 ],
      "id_str" : "21322269",
      "id" : 21322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564016240587735040",
  "geo" : { },
  "id_str" : "564027224203227136",
  "in_reply_to_user_id" : 13533482,
  "text" : "@whippler @Paul_Driver @cellointensive woah hectic but good :)",
  "id" : 564027224203227136,
  "in_reply_to_status_id" : 564016240587735040,
  "created_at" : "2015-02-07 11:45:44 +0000",
  "in_reply_to_screen_name" : "whippler",
  "in_reply_to_user_id_str" : "13533482",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 3, 16 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 33, 43 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/dVhKgTvzA3",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/02\/let-them-know-why-they-are-really-there.html?spref=tw",
      "display_url" : "how-i-see-it-now.blogspot.com\/2015\/02\/let-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564012669548912640",
  "text" : "RT @ZhenyaDnipro: A cool post by @HanaTicha: http:\/\/t.co\/dVhKgTvzA3 - learning a l-ge or communication, or both, or... neither?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hana Tich\u00E1",
        "screen_name" : "HanaTicha",
        "indices" : [ 15, 25 ],
        "id_str" : "512296705",
        "id" : 512296705
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/dVhKgTvzA3",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/02\/let-them-know-why-they-are-really-there.html?spref=tw",
        "display_url" : "how-i-see-it-now.blogspot.com\/2015\/02\/let-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564010369459699712",
    "text" : "A cool post by @HanaTicha: http:\/\/t.co\/dVhKgTvzA3 - learning a l-ge or communication, or both, or... neither?",
    "id" : 564010369459699712,
    "created_at" : "2015-02-07 10:38:45 +0000",
    "user" : {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "protected" : false,
      "id_str" : "2248486418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766906932875714560\/KfDv1cK8_normal.jpg",
      "id" : 2248486418,
      "verified" : false
    }
  },
  "id" : 564012669548912640,
  "created_at" : "2015-02-07 10:47:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tVPMYuFKZK",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/ejed.12109\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/ej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563989638432702464",
  "text" : "RT @gbiesta: new  (nice introduction to some of my key ideas) \"What is education for?\" European Journal of Education 50(1), 75-87. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/tVPMYuFKZK",
        "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/ejed.12109\/full",
        "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/ej\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563486768557998080",
    "text" : "new  (nice introduction to some of my key ideas) \"What is education for?\" European Journal of Education 50(1), 75-87. http:\/\/t.co\/tVPMYuFKZK",
    "id" : 563486768557998080,
    "created_at" : "2015-02-05 23:58:09 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 563989638432702464,
  "created_at" : "2015-02-07 09:16:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 23, 36 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 82, 97 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/py8foaRNVr",
      "expanded_url" : "http:\/\/www.beltabelgium.com\/webinars\/",
      "display_url" : "beltabelgium.com\/webinars\/"
    } ]
  },
  "geo" : { },
  "id_str" : "563979724448628736",
  "text" : "RT @adi_rajan: March's @BELTABelgium webinar is with the fantabulously articulate @_divyamadhavan http:\/\/t.co\/py8foaRNVr Mark the date on y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 8, 21 ],
        "id_str" : "884934438",
        "id" : 884934438
      }, {
        "name" : "Divya Madhavan",
        "screen_name" : "_divyamadhavan",
        "indices" : [ 67, 82 ],
        "id_str" : "408492806",
        "id" : 408492806
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/py8foaRNVr",
        "expanded_url" : "http:\/\/www.beltabelgium.com\/webinars\/",
        "display_url" : "beltabelgium.com\/webinars\/"
      } ]
    },
    "geo" : { },
    "id_str" : "563974262805905408",
    "text" : "March's @BELTABelgium webinar is with the fantabulously articulate @_divyamadhavan http:\/\/t.co\/py8foaRNVr Mark the date on your calendars!",
    "id" : 563974262805905408,
    "created_at" : "2015-02-07 08:15:17 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 563979724448628736,
  "created_at" : "2015-02-07 08:36:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563839124109803520",
  "geo" : { },
  "id_str" : "563979527609942017",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl it's a funky visualisation tool for sure :)",
  "id" : 563979527609942017,
  "in_reply_to_status_id" : 563839124109803520,
  "created_at" : "2015-02-07 08:36:12 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563835761544282113",
  "geo" : { },
  "id_str" : "563979220993736704",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @GeoffreyJordan my pleasure stumbled on that as u do on the internets same author has book on neoliberal universities &amp; eap",
  "id" : 563979220993736704,
  "in_reply_to_status_id" : 563835761544282113,
  "created_at" : "2015-02-07 08:34:59 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/1Hl5n7NctY",
      "expanded_url" : "http:\/\/goo.gl\/Kwczcl",
      "display_url" : "goo.gl\/Kwczcl"
    } ]
  },
  "geo" : { },
  "id_str" : "563822587223224321",
  "text" : "The Fiery Cage and the Lynching Tree, Brutality\u2019s Never Far Away - http:\/\/t.co\/1Hl5n7NctY",
  "id" : 563822587223224321,
  "created_at" : "2015-02-06 22:12:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 108, 114 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/aVOcwHE7vO",
      "expanded_url" : "http:\/\/benschmidt.org\/profGender\/#",
      "display_url" : "benschmidt.org\/profGender\/#"
    } ]
  },
  "geo" : { },
  "id_str" : "563791261061365760",
  "text" : "MT @holden Try cold, warm, unorganized, organized, brilliant, boring, knows, did. http:\/\/t.co\/aVOcwHE7vO cc @ebefl",
  "id" : 563791261061365760,
  "created_at" : "2015-02-06 20:08:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canan Aktu\u011F",
      "screen_name" : "Jananstwit",
      "indices" : [ 3, 14 ],
      "id_str" : "179676661",
      "id" : 179676661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/aR89x7zSFK",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/world\/europe\/filmmaker-challenges-culture-of-collective-guilt-by-making-dutch-children-apologise-for-terrorism-10028593.html",
      "display_url" : "independent.co.uk\/news\/world\/eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563776720462168065",
  "text" : "RT @Jananstwit: Filmmaker challenges culture of 'collective guilt' by making 'Dutch children apologise for terrorism' http:\/\/t.co\/aR89x7zSFK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/aR89x7zSFK",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/world\/europe\/filmmaker-challenges-culture-of-collective-guilt-by-making-dutch-children-apologise-for-terrorism-10028593.html",
        "display_url" : "independent.co.uk\/news\/world\/eur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563772884091695104",
    "text" : "Filmmaker challenges culture of 'collective guilt' by making 'Dutch children apologise for terrorism' http:\/\/t.co\/aR89x7zSFK",
    "id" : 563772884091695104,
    "created_at" : "2015-02-06 18:55:04 +0000",
    "user" : {
      "name" : "Canan Aktu\u011F",
      "screen_name" : "Jananstwit",
      "protected" : false,
      "id_str" : "179676661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654708058040365056\/bxSMwSJt_normal.jpg",
      "id" : 179676661,
      "verified" : false
    }
  },
  "id" : 563776720462168065,
  "created_at" : "2015-02-06 19:10:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 107, 120 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 121, 136 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/pC0q0SpLKJ",
      "expanded_url" : "https:\/\/www.academia.edu\/10498454\/Global_Textbooks_in_Local_Contexts_An_Empirical_Investigation_of_Effectiveness",
      "display_url" : "academia.edu\/10498454\/Globa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563767195646562304",
  "text" : "Global Textbooks in Local Contexts: An Empirical Investigation of Effectiveness https:\/\/t.co\/pC0q0SpLKJ cc @LauraSoracco @GeoffreyJordan",
  "id" : 563767195646562304,
  "created_at" : "2015-02-06 18:32:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Van Amelsvoort",
      "screen_name" : "Marcelva",
      "indices" : [ 0, 9 ],
      "id_str" : "21634927",
      "id" : 21634927
    }, {
      "name" : "Larry Ferlazzo",
      "screen_name" : "Larryferlazzo",
      "indices" : [ 10, 24 ],
      "id_str" : "18107749",
      "id" : 18107749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563679062954999809",
  "geo" : { },
  "id_str" : "563684923006255104",
  "in_reply_to_user_id" : 21634927,
  "text" : "@Marcelva @Larryferlazzo be handy to get paper to see how they controlled for say sub-vocal rehearsal, can anyone get a copy?",
  "id" : 563684923006255104,
  "in_reply_to_status_id" : 563679062954999809,
  "created_at" : "2015-02-06 13:05:33 +0000",
  "in_reply_to_screen_name" : "Marcelva",
  "in_reply_to_user_id_str" : "21634927",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaleem Mirza",
      "screen_name" : "citywhizkid",
      "indices" : [ 3, 15 ],
      "id_str" : "185215302",
      "id" : 185215302
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 17, 32 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563678248690008064",
  "text" : "RT @citywhizkid: @georgegalloway I salute your stout defence of freedom  of speech in the face of a BBC sponsored Finchley ambush!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Galloway",
        "screen_name" : "georgegalloway",
        "indices" : [ 0, 15 ],
        "id_str" : "15484198",
        "id" : 15484198
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "563483063695724544",
    "geo" : { },
    "id_str" : "563515616834113536",
    "in_reply_to_user_id" : 15484198,
    "text" : "@georgegalloway I salute your stout defence of freedom  of speech in the face of a BBC sponsored Finchley ambush!",
    "id" : 563515616834113536,
    "in_reply_to_status_id" : 563483063695724544,
    "created_at" : "2015-02-06 01:52:47 +0000",
    "in_reply_to_screen_name" : "georgegalloway",
    "in_reply_to_user_id_str" : "15484198",
    "user" : {
      "name" : "Kaleem Mirza",
      "screen_name" : "citywhizkid",
      "protected" : false,
      "id_str" : "185215302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3735067236\/b931b8d0f33a72f2ddbf8f8f345f698a_normal.jpeg",
      "id" : 185215302,
      "verified" : false
    }
  },
  "id" : 563678248690008064,
  "created_at" : "2015-02-06 12:39:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Mikhail Zinshteyn",
      "screen_name" : "mzinshteyn",
      "indices" : [ 74, 85 ],
      "id_str" : "56519267",
      "id" : 56519267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/qjDpqYNmen",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/02\/05\/whos-investing-in-ed-tech\/",
      "display_url" : "hackeducation.com\/2015\/02\/05\/who\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563645637343068160",
  "text" : "RT @audreywatters: Who's Investing in Ed-tech http:\/\/t.co\/qjDpqYNmen (for @mzinshteyn)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mikhail Zinshteyn",
        "screen_name" : "mzinshteyn",
        "indices" : [ 55, 66 ],
        "id_str" : "56519267",
        "id" : 56519267
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/qjDpqYNmen",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/02\/05\/whos-investing-in-ed-tech\/",
        "display_url" : "hackeducation.com\/2015\/02\/05\/who\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563532932501864448",
    "text" : "Who's Investing in Ed-tech http:\/\/t.co\/qjDpqYNmen (for @mzinshteyn)",
    "id" : 563532932501864448,
    "created_at" : "2015-02-06 03:01:35 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 563645637343068160,
  "created_at" : "2015-02-06 10:29:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 0, 7 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563586948732690432",
  "geo" : { },
  "id_str" : "563591859566829568",
  "in_reply_to_user_id" : 740343,
  "text" : "@cogdog those feedback lines by agarwal might go well with a Hendrix clip :)",
  "id" : 563591859566829568,
  "in_reply_to_status_id" : 563586948732690432,
  "created_at" : "2015-02-06 06:55:45 +0000",
  "in_reply_to_screen_name" : "cogdog",
  "in_reply_to_user_id_str" : "740343",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 71, 78 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Vj6ujhWxAx",
      "expanded_url" : "http:\/\/youtu.be\/eFpThn8E3W4",
      "display_url" : "youtu.be\/eFpThn8E3W4"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NUnz05gGWm",
      "expanded_url" : "http:\/\/cogdogblog.com\/2015\/02\/04\/the-moocing-machine\/",
      "display_url" : "cogdogblog.com\/2015\/02\/04\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563586289858260992",
  "text" : "Pressey VS Agarwal The MOOC answer: http:\/\/t.co\/Vj6ujhWxAx inspired by @cogdog http:\/\/t.co\/NUnz05gGWm",
  "id" : 563586289858260992,
  "created_at" : "2015-02-06 06:33:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/562912590079479811\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/LM0Er1CWLl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8_eBHRIMAAWg_R.png",
      "id_str" : "562912589156724736",
      "id" : 562912589156724736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8_eBHRIMAAWg_R.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LM0Er1CWLl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/JfIgAd0eIc",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/786-conundrum-syriza-democracy-and-the-death-of-a-saudi-tyrant.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563482926793633792",
  "text" : "RT @medialens: Our latest media alert: 'Conundrum \u2013 Syriza, Democracy And The Death Of A Saudi Tyrant'.\nhttp:\/\/t.co\/JfIgAd0eIc http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/562912590079479811\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/LM0Er1CWLl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8_eBHRIMAAWg_R.png",
        "id_str" : "562912589156724736",
        "id" : 562912589156724736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8_eBHRIMAAWg_R.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LM0Er1CWLl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/JfIgAd0eIc",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/786-conundrum-syriza-democracy-and-the-death-of-a-saudi-tyrant.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562912590079479811",
    "text" : "Our latest media alert: 'Conundrum \u2013 Syriza, Democracy And The Death Of A Saudi Tyrant'.\nhttp:\/\/t.co\/JfIgAd0eIc http:\/\/t.co\/LM0Er1CWLl",
    "id" : 562912590079479811,
    "created_at" : "2015-02-04 09:56:34 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 563482926793633792,
  "created_at" : "2015-02-05 23:42:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/IiggFDYEUv",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1423151050.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563471806640975872",
  "text" : "Je Suis Merchandise http:\/\/t.co\/IiggFDYEUv",
  "id" : 563471806640975872,
  "created_at" : "2015-02-05 22:58:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cyanide & Happiness",
      "screen_name" : "Explosm",
      "indices" : [ 13, 21 ],
      "id_str" : "29054474",
      "id" : 29054474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/r9F9lu7iXr",
      "expanded_url" : "http:\/\/explosm.net\/comics\/3786\/",
      "display_url" : "explosm.net\/comics\/3786\/"
    } ]
  },
  "geo" : { },
  "id_str" : "563470016197431296",
  "text" : "Selfie stick @explosm comic! http:\/\/t.co\/r9F9lu7iXr",
  "id" : 563470016197431296,
  "created_at" : "2015-02-05 22:51:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/cRjjVcIpl5",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article40896.htm#.VNPxtW0t0xo.twitter",
      "display_url" : "informationclearinghouse.info\/article40896.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563467644167544832",
  "text" : "Sami Al-Arian, Professor Who Defeated Controversial Terrorism Charges, is Deported from U.S\u00A0http:\/\/t.co\/cRjjVcIpl5",
  "id" : 563467644167544832,
  "created_at" : "2015-02-05 22:42:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "indices" : [ 0, 10 ],
      "id_str" : "533509442",
      "id" : 533509442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/563464227843997696\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/5VkuCL1XOL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HTup_IQAIw92O.png",
      "id_str" : "563464226896101378",
      "id" : 563464226896101378,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HTup_IQAIw92O.png",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 1253
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5VkuCL1XOL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/95ifB3hRJO",
      "expanded_url" : "http:\/\/bncgender.englishup.me\/",
      "display_url" : "bncgender.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "563431644800237569",
  "geo" : { },
  "id_str" : "563464227843997696",
  "in_reply_to_user_id" : 533509442,
  "text" : "@JessFrye1 er and mm show similar patterns for male and female respectively in BNC spoken http:\/\/t.co\/95ifB3hRJO http:\/\/t.co\/5VkuCL1XOL",
  "id" : 563464227843997696,
  "in_reply_to_status_id" : 563431644800237569,
  "created_at" : "2015-02-05 22:28:35 +0000",
  "in_reply_to_screen_name" : "JessFrye1",
  "in_reply_to_user_id_str" : "533509442",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563459640852508672",
  "text" : "feck a 180M excel file just to file in some marks :\/",
  "id" : 563459640852508672,
  "created_at" : "2015-02-05 22:10:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Assange",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "Chilcot",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563450370262040578",
  "text" : "RT @wikileaks: UK gov has now spent more surrounding #Assange (\u00A310million) than #Chilcot Iraq War inquiry and Westminster pedophile ring in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Assange",
        "indices" : [ 38, 46 ]
      }, {
        "text" : "Chilcot",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563250092699058176",
    "text" : "UK gov has now spent more surrounding #Assange (\u00A310million) than #Chilcot Iraq War inquiry and Westminster pedophile ring investigation.",
    "id" : 563250092699058176,
    "created_at" : "2015-02-05 08:17:41 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 563450370262040578,
  "created_at" : "2015-02-05 21:33:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/08cCgH7MhC",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article40904.htm#.VNPg3DxuWE4.twitter",
      "display_url" : "informationclearinghouse.info\/article40904.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563449511797080064",
  "text" : "NATO is Already at War in Ukraine\u2026 and it is Losing :\u00A0 Information Clearing House - ICH http:\/\/t.co\/08cCgH7MhC",
  "id" : 563449511797080064,
  "created_at" : "2015-02-05 21:30:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563437387418583040",
  "geo" : { },
  "id_str" : "563440266062102531",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet sure glad u liked it, need to get round to finishing more of that studs terkels book &amp; hand it bk to u!",
  "id" : 563440266062102531,
  "in_reply_to_status_id" : 563437387418583040,
  "created_at" : "2015-02-05 20:53:22 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 100, 108 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 112, 127 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/YzQlLCO9aE",
      "expanded_url" : "http:\/\/youtu.be\/zS1gdn6vAWc",
      "display_url" : "youtu.be\/zS1gdn6vAWc"
    } ]
  },
  "geo" : { },
  "id_str" : "563432274289770496",
  "text" : "John Pilger - Conversations With a Working Man - World in Action (1971): http:\/\/t.co\/YzQlLCO9aE via @YouTube cc @4tunetellernet",
  "id" : 563432274289770496,
  "created_at" : "2015-02-05 20:21:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "indices" : [ 3, 15 ],
      "id_str" : "310919399",
      "id" : 310919399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slpbloggers",
      "indices" : [ 78, 90 ]
    }, {
      "text" : "slpeeps",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "sped",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/lFD40gy8hY",
      "expanded_url" : "http:\/\/ow.ly\/IxSAN",
      "display_url" : "ow.ly\/IxSAN"
    } ]
  },
  "geo" : { },
  "id_str" : "563415311995912192",
  "text" : "RT @SpeechDudes: New blog post: \"28 Words to Boost Your Client's Vocabulary.\" #slpbloggers #slpeeps #sped http:\/\/t.co\/lFD40gy8hY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "slpbloggers",
        "indices" : [ 61, 73 ]
      }, {
        "text" : "slpeeps",
        "indices" : [ 74, 82 ]
      }, {
        "text" : "sped",
        "indices" : [ 83, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/lFD40gy8hY",
        "expanded_url" : "http:\/\/ow.ly\/IxSAN",
        "display_url" : "ow.ly\/IxSAN"
      } ]
    },
    "geo" : { },
    "id_str" : "563348918193651713",
    "text" : "New blog post: \"28 Words to Boost Your Client's Vocabulary.\" #slpbloggers #slpeeps #sped http:\/\/t.co\/lFD40gy8hY",
    "id" : 563348918193651713,
    "created_at" : "2015-02-05 14:50:23 +0000",
    "user" : {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "protected" : false,
      "id_str" : "310919399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2630404839\/ded339c018067c3300f6e855e18b897b_normal.png",
      "id" : 310919399,
      "verified" : false
    }
  },
  "id" : 563415311995912192,
  "created_at" : "2015-02-05 19:14:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aral\/status\/563248643420192768\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5ppu3vzNx7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9EPp-pIEAIoYBv.png",
      "id_str" : "563248642262568962",
      "id" : 563248642262568962,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9EPp-pIEAIoYBv.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/5ppu3vzNx7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/bkLi7hYwNR",
      "expanded_url" : "https:\/\/ind.ie\/the-camera-panopticon",
      "display_url" : "ind.ie\/the-camera-pan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563406212629528578",
  "text" : "RT @aral: Twitter: \u201CLet\u2019s speak privately\u201D (Where private means just you, your friends, *and Twitter*)\n\nhttps:\/\/t.co\/bkLi7hYwNR http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aral\/status\/563248643420192768\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/5ppu3vzNx7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9EPp-pIEAIoYBv.png",
        "id_str" : "563248642262568962",
        "id" : 563248642262568962,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9EPp-pIEAIoYBv.png",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/5ppu3vzNx7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/bkLi7hYwNR",
        "expanded_url" : "https:\/\/ind.ie\/the-camera-panopticon",
        "display_url" : "ind.ie\/the-camera-pan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563248643420192768",
    "text" : "Twitter: \u201CLet\u2019s speak privately\u201D (Where private means just you, your friends, *and Twitter*)\n\nhttps:\/\/t.co\/bkLi7hYwNR http:\/\/t.co\/5ppu3vzNx7",
    "id" : 563248643420192768,
    "created_at" : "2015-02-05 08:11:55 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 563406212629528578,
  "created_at" : "2015-02-05 18:38:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 3, 13 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 15, 24 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/7Pvifd2kxQ",
      "expanded_url" : "http:\/\/eltmakespace.blogspot.ie\/2015\/02\/elt-maker-night-recap.html",
      "display_url" : "eltmakespace.blogspot.ie\/2015\/02\/elt-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563395476536688640",
  "text" : "RT @ELTMAKERS: @muranava http:\/\/t.co\/7Pvifd2kxQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/7Pvifd2kxQ",
        "expanded_url" : "http:\/\/eltmakespace.blogspot.ie\/2015\/02\/elt-maker-night-recap.html",
        "display_url" : "eltmakespace.blogspot.ie\/2015\/02\/elt-ma\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "560855249012137984",
    "geo" : { },
    "id_str" : "563377332946477056",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava http:\/\/t.co\/7Pvifd2kxQ",
    "id" : 563377332946477056,
    "in_reply_to_status_id" : 560855249012137984,
    "created_at" : "2015-02-05 16:43:17 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "protected" : false,
      "id_str" : "2894570578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537944364534611969\/BegFDTeR_normal.png",
      "id" : 2894570578,
      "verified" : false
    }
  },
  "id" : 563395476536688640,
  "created_at" : "2015-02-05 17:55:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563377332946477056",
  "geo" : { },
  "id_str" : "563395262853705728",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS thx,great report, looks like a great night &amp; some intriguing makes, any further info\/blog links to them?",
  "id" : 563395262853705728,
  "in_reply_to_status_id" : 563377332946477056,
  "created_at" : "2015-02-05 17:54:32 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MiLL",
      "screen_name" : "MiLL_Network",
      "indices" : [ 3, 16 ],
      "id_str" : "2976617727",
      "id" : 2976617727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/nVC46WUAvm",
      "expanded_url" : "http:\/\/ow.ly\/ImR4Y",
      "display_url" : "ow.ly\/ImR4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "563323531232960512",
  "text" : "RT @MiLL_Network: Renowned researcher Bill VanPatten explores the centrality of meaning in language acquisition and teaching -  http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/nVC46WUAvm",
        "expanded_url" : "http:\/\/ow.ly\/ImR4Y",
        "display_url" : "ow.ly\/ImR4Y"
      } ]
    },
    "geo" : { },
    "id_str" : "563316186465980416",
    "text" : "Renowned researcher Bill VanPatten explores the centrality of meaning in language acquisition and teaching -  http:\/\/t.co\/nVC46WUAvm",
    "id" : 563316186465980416,
    "created_at" : "2015-02-05 12:40:19 +0000",
    "user" : {
      "name" : "MiLL",
      "screen_name" : "MiLL_Network",
      "protected" : false,
      "id_str" : "2976617727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555032763338743809\/hmErud48_normal.jpeg",
      "id" : 2976617727,
      "verified" : false
    }
  },
  "id" : 563323531232960512,
  "created_at" : "2015-02-05 13:09:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563257363323699200",
  "geo" : { },
  "id_str" : "563257804375724033",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a wonder if it is a spoken grammar use? :)",
  "id" : 563257804375724033,
  "in_reply_to_status_id" : 563257363323699200,
  "created_at" : "2015-02-05 08:48:20 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry cuban",
      "screen_name" : "CubanLarry",
      "indices" : [ 106, 117 ],
      "id_str" : "2324494104",
      "id" : 2324494104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NhAKHYHtvx",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-2mo",
      "display_url" : "wp.me\/pBm7c-2mo"
    } ]
  },
  "geo" : { },
  "id_str" : "563256354136424448",
  "text" : "The Lack of Evidence-Based Practice: The Case of Classroom Technology (Part 1) http:\/\/t.co\/NhAKHYHtvx via @CubanLarry",
  "id" : 563256354136424448,
  "created_at" : "2015-02-05 08:42:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563229276133400577",
  "geo" : { },
  "id_str" : "563253634528718848",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a interesting use of evidence as verb in that abstract",
  "id" : 563253634528718848,
  "in_reply_to_status_id" : 563229276133400577,
  "created_at" : "2015-02-05 08:31:45 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/1N3agvUdPA",
      "expanded_url" : "http:\/\/edtechconcerns.podomatic.com\/entry\/2015-01-30T02_28_25-08_00#.VNMlPsD2HRc.twitter",
      "display_url" : "edtechconcerns.podomatic.com\/entry\/2015-01-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563248090338316289",
  "text" : "Edtechconcerns final episode http:\/\/t.co\/1N3agvUdPA",
  "id" : 563248090338316289,
  "created_at" : "2015-02-05 08:09:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/B5iACJ0JuC",
      "expanded_url" : "http:\/\/ow.ly\/Iaeh3",
      "display_url" : "ow.ly\/Iaeh3"
    } ]
  },
  "geo" : { },
  "id_str" : "562996104665772032",
  "text" : "RT @umasslinguistic: Welsh speakers email, text and social media mostly in English, survey finds http:\/\/t.co\/B5iACJ0JuC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/B5iACJ0JuC",
        "expanded_url" : "http:\/\/ow.ly\/Iaeh3",
        "display_url" : "ow.ly\/Iaeh3"
      } ]
    },
    "geo" : { },
    "id_str" : "562995312193978368",
    "text" : "Welsh speakers email, text and social media mostly in English, survey finds http:\/\/t.co\/B5iACJ0JuC",
    "id" : 562995312193978368,
    "created_at" : "2015-02-04 15:25:17 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 562996104665772032,
  "created_at" : "2015-02-04 15:28:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/XKHv7rfCv7",
      "expanded_url" : "http:\/\/eer.sagepub.com\/content\/14\/1\/11.full.pdf+html",
      "display_url" : "eer.sagepub.com\/content\/14\/1\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562907151237386240",
  "text" : "RT @gbiesta: new: \"On the two cultures of educational research, and how we might move ahead\u201D (my 2014 ECER keynote)  free download http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/XKHv7rfCv7",
        "expanded_url" : "http:\/\/eer.sagepub.com\/content\/14\/1\/11.full.pdf+html",
        "display_url" : "eer.sagepub.com\/content\/14\/1\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "561971448789876736",
    "text" : "new: \"On the two cultures of educational research, and how we might move ahead\u201D (my 2014 ECER keynote)  free download http:\/\/t.co\/XKHv7rfCv7",
    "id" : 561971448789876736,
    "created_at" : "2015-02-01 19:36:48 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 562907151237386240,
  "created_at" : "2015-02-04 09:34:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Transcription",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mtNNpDm2U9",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1551",
      "display_url" : "cass.lancs.ac.uk\/?p=1551"
    } ]
  },
  "geo" : { },
  "id_str" : "562675976375906306",
  "text" : "RT @CorpusSocialSci: Interested in progress on our learner lang. corpus? Read \"A Journey into #Transcription, P. 4: The Question Question\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Transcription",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/mtNNpDm2U9",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1551",
        "display_url" : "cass.lancs.ac.uk\/?p=1551"
      } ]
    },
    "geo" : { },
    "id_str" : "562649853126529024",
    "text" : "Interested in progress on our learner lang. corpus? Read \"A Journey into #Transcription, P. 4: The Question Question\" http:\/\/t.co\/mtNNpDm2U9",
    "id" : 562649853126529024,
    "created_at" : "2015-02-03 16:32:33 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 562675976375906306,
  "created_at" : "2015-02-03 18:16:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 3, 16 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/RbYWHvcqVx",
      "expanded_url" : "http:\/\/bit.ly\/1zuPulF",
      "display_url" : "bit.ly\/1zuPulF"
    }, {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/iXLKkA2qK3",
      "expanded_url" : "http:\/\/bit.ly\/166YMKl",
      "display_url" : "bit.ly\/166YMKl"
    } ]
  },
  "geo" : { },
  "id_str" : "562484843771330560",
  "text" : "RT @RobertEPoole: Interested in corpus-aided pedagogy? Read my overview at http:\/\/t.co\/RbYWHvcqVx and download an activity at http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/RbYWHvcqVx",
        "expanded_url" : "http:\/\/bit.ly\/1zuPulF",
        "display_url" : "bit.ly\/1zuPulF"
      }, {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/iXLKkA2qK3",
        "expanded_url" : "http:\/\/bit.ly\/166YMKl",
        "display_url" : "bit.ly\/166YMKl"
      } ]
    },
    "geo" : { },
    "id_str" : "562275254056124416",
    "text" : "Interested in corpus-aided pedagogy? Read my overview at http:\/\/t.co\/RbYWHvcqVx and download an activity at http:\/\/t.co\/iXLKkA2qK3 #corpus",
    "id" : 562275254056124416,
    "created_at" : "2015-02-02 15:44:01 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 562484843771330560,
  "created_at" : "2015-02-03 05:36:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept Education York",
      "screen_name" : "DeptEdYork",
      "indices" : [ 3, 14 ],
      "id_str" : "2370144774",
      "id" : 2370144774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/wpRPTEHaKR",
      "expanded_url" : "http:\/\/www.york.ac.uk\/education\/news-events\/news\/2014\/phd-tesol\/",
      "display_url" : "york.ac.uk\/education\/news\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562382023437086720",
  "text" : "RT @DeptEdYork: Did you know we are launching a Phd in TESOL at University of York Dept of Education? Find out more here: http:\/\/t.co\/wpRPT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/wpRPTEHaKR",
        "expanded_url" : "http:\/\/www.york.ac.uk\/education\/news-events\/news\/2014\/phd-tesol\/",
        "display_url" : "york.ac.uk\/education\/news\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "558637310678687744",
    "text" : "Did you know we are launching a Phd in TESOL at University of York Dept of Education? Find out more here: http:\/\/t.co\/wpRPTEHaKR",
    "id" : 558637310678687744,
    "created_at" : "2015-01-23 14:48:08 +0000",
    "user" : {
      "name" : "Dept Education York",
      "screen_name" : "DeptEdYork",
      "protected" : false,
      "id_str" : "2370144774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440449336929828864\/m8_EUZed_normal.jpeg",
      "id" : 2370144774,
      "verified" : false
    }
  },
  "id" : 562382023437086720,
  "created_at" : "2015-02-02 22:48:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "indices" : [ 90, 100 ],
      "id_str" : "303905601",
      "id" : 303905601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/McdeaBUior",
      "expanded_url" : "http:\/\/frenchteachernet.blogspot.com\/2015\/02\/conscious-and-unconscious-language.html",
      "display_url" : "frenchteachernet.blogspot.com\/2015\/02\/consci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562371215323848704",
  "text" : "frenchteacher: Conscious and unconscious language learning (1) http:\/\/t.co\/McdeaBUior via @spsmith45",
  "id" : 562371215323848704,
  "created_at" : "2015-02-02 22:05:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/560798368877010944\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/8CSE3g8Ffb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8hbJLOIcAEBm37.jpg",
      "id_str" : "560798366796640257",
      "id" : 560798366796640257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8hbJLOIcAEBm37.jpg",
      "sizes" : [ {
        "h" : 1331,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8CSE3g8Ffb"
    } ],
    "hashtags" : [ {
      "text" : "Syriza",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "Podemos",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "politics",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/ldcUORgrAl",
      "expanded_url" : "http:\/\/goo.gl\/YC2qX3",
      "display_url" : "goo.gl\/YC2qX3"
    } ]
  },
  "geo" : { },
  "id_str" : "562330510991822848",
  "text" : "RT @josipa74: How the Left got its groove back http:\/\/t.co\/ldcUORgrAl #Syriza #Podemos #politics http:\/\/t.co\/8CSE3g8Ffb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/560798368877010944\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/8CSE3g8Ffb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8hbJLOIcAEBm37.jpg",
        "id_str" : "560798366796640257",
        "id" : 560798366796640257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8hbJLOIcAEBm37.jpg",
        "sizes" : [ {
          "h" : 1331,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8CSE3g8Ffb"
      } ],
      "hashtags" : [ {
        "text" : "Syriza",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "Podemos",
        "indices" : [ 64, 72 ]
      }, {
        "text" : "politics",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/ldcUORgrAl",
        "expanded_url" : "http:\/\/goo.gl\/YC2qX3",
        "display_url" : "goo.gl\/YC2qX3"
      } ]
    },
    "geo" : { },
    "id_str" : "560798368877010944",
    "text" : "How the Left got its groove back http:\/\/t.co\/ldcUORgrAl #Syriza #Podemos #politics http:\/\/t.co\/8CSE3g8Ffb",
    "id" : 560798368877010944,
    "created_at" : "2015-01-29 13:55:24 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 562330510991822848,
  "created_at" : "2015-02-02 19:23:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561815679276294145",
  "geo" : { },
  "id_str" : "562330216912420864",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler hi sure :)",
  "id" : 562330216912420864,
  "in_reply_to_status_id" : 561815679276294145,
  "created_at" : "2015-02-02 19:22:25 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bureau",
      "screen_name" : "TBIJ",
      "indices" : [ 117, 122 ],
      "id_str" : "116009193",
      "id" : 116009193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/hOATbhIWeI",
      "expanded_url" : "http:\/\/www.thebureauinvestigates.com\/2015\/02\/02\/almost-2500-killed-covert-us-drone-strikes-obama-inauguration\/",
      "display_url" : "thebureauinvestigates.com\/2015\/02\/02\/alm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562329871385640961",
  "text" : "Almost 2,500 now killed by covert US drone strikes since Obama inauguration six years ago http:\/\/t.co\/hOATbhIWeI via @tbij",
  "id" : 562329871385640961,
  "created_at" : "2015-02-02 19:21:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 143, 144 ],
      "id_str" : "374391424",
      "id" : 374391424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/U1mJ166sYG",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2015\/02\/01\/how-stephen-krashen-saved-my-job-why-he-still-wants-to-save-your-children\/",
      "display_url" : "itdi.pro\/blog\/2015\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561800068765065216",
  "text" : "RT @AnneHendler: New on the #iTDi blog: How Stephen Krashen Saved My Job &amp; Why He Still Wants to Save your Children http:\/\/t.co\/U1mJ166sYG \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "itdi.pro",
        "screen_name" : "iTDipro",
        "indices" : [ 130, 138 ],
        "id_str" : "374391424",
        "id" : 374391424
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 11, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/U1mJ166sYG",
        "expanded_url" : "http:\/\/itdi.pro\/blog\/2015\/02\/01\/how-stephen-krashen-saved-my-job-why-he-still-wants-to-save-your-children\/",
        "display_url" : "itdi.pro\/blog\/2015\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "561793934834163712",
    "text" : "New on the #iTDi blog: How Stephen Krashen Saved My Job &amp; Why He Still Wants to Save your Children http:\/\/t.co\/U1mJ166sYG via @itdipro",
    "id" : 561793934834163712,
    "created_at" : "2015-02-01 07:51:26 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 561800068765065216,
  "created_at" : "2015-02-01 08:15:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 77, 92 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/KT1p1gfAVc",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-15Y",
      "display_url" : "wp.me\/p3qkCB-15Y"
    } ]
  },
  "geo" : { },
  "id_str" : "561795363766824960",
  "text" : "Demand High, Part 2: An Exchange with Steve Brown http:\/\/t.co\/KT1p1gfAVc via @GeoffreyJordan",
  "id" : 561795363766824960,
  "created_at" : "2015-02-01 07:57:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]