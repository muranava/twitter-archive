Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "David Deubelbeiss",
      "screen_name" : "ddeubel",
      "indices" : [ 14, 22 ],
      "id_str" : "52174903",
      "id" : 52174903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/DwG4jUcQzG",
      "expanded_url" : "https:\/\/www.academia.edu\/8391376\/1_Against_Learning_Biesta",
      "display_url" : "academia.edu\/8391376\/1_Agai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "593834718065483777",
  "geo" : { },
  "id_str" : "593869548308299777",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @ddeubel it's interesting to look at the wider discourse of learning vs teaching e.g. https:\/\/t.co\/DwG4jUcQzG",
  "id" : 593869548308299777,
  "in_reply_to_status_id" : 593834718065483777,
  "created_at" : "2015-04-30 20:08:28 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidedc",
      "screen_name" : "davidedc",
      "indices" : [ 3, 12 ],
      "id_str" : "14684455",
      "id" : 14684455
    }, {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 122, 134 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/FZG4ev5iKt",
      "expanded_url" : "http:\/\/antiboredom.github.io\/oddjobs\/",
      "display_url" : "antiboredom.github.io\/oddjobs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "593852817091231744",
  "text" : "RT @davidedc: http:\/\/t.co\/FZG4ev5iKt top 25 things computers can't do today and we can exploit people to do anyways. from @sam_lavigne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Lavigne",
        "screen_name" : "sam_lavigne",
        "indices" : [ 108, 120 ],
        "id_str" : "6428702",
        "id" : 6428702
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/FZG4ev5iKt",
        "expanded_url" : "http:\/\/antiboredom.github.io\/oddjobs\/",
        "display_url" : "antiboredom.github.io\/oddjobs\/"
      } ]
    },
    "geo" : { },
    "id_str" : "593719685792800769",
    "text" : "http:\/\/t.co\/FZG4ev5iKt top 25 things computers can't do today and we can exploit people to do anyways. from @sam_lavigne",
    "id" : 593719685792800769,
    "created_at" : "2015-04-30 10:12:58 +0000",
    "user" : {
      "name" : "davidedc",
      "screen_name" : "davidedc",
      "protected" : false,
      "id_str" : "14684455",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719862860483051520\/RPPUiWYX_normal.jpg",
      "id" : 14684455,
      "verified" : false
    }
  },
  "id" : 593852817091231744,
  "created_at" : "2015-04-30 19:01:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TaWSIG",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "elt",
      "indices" : [ 78, 82 ]
    }, {
      "text" : "esl",
      "indices" : [ 83, 87 ]
    }, {
      "text" : "efl",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "tefl",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/l5MZ8Pkxqx",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/?p=3139",
      "display_url" : "decentralisedteachingandlearning.com\/?p=3139"
    } ]
  },
  "geo" : { },
  "id_str" : "593840603970011138",
  "text" : "RT @josipa74: Finding our way: THANKS to supporters AND 3 myths about #TaWSIG #elt #esl #efl #tefl http:\/\/t.co\/l5MZ8Pkxqx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TaWSIG",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "elt",
        "indices" : [ 64, 68 ]
      }, {
        "text" : "esl",
        "indices" : [ 69, 73 ]
      }, {
        "text" : "efl",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "tefl",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/l5MZ8Pkxqx",
        "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/?p=3139",
        "display_url" : "decentralisedteachingandlearning.com\/?p=3139"
      } ]
    },
    "geo" : { },
    "id_str" : "593803964015063040",
    "text" : "Finding our way: THANKS to supporters AND 3 myths about #TaWSIG #elt #esl #efl #tefl http:\/\/t.co\/l5MZ8Pkxqx",
    "id" : 593803964015063040,
    "created_at" : "2015-04-30 15:47:52 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 593840603970011138,
  "created_at" : "2015-04-30 18:13:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593769034425958400",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery thanks for RT :)",
  "id" : 593769034425958400,
  "created_at" : "2015-04-30 13:29:04 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "ESL",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "TaWSIG",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "TaWSIG",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "TaWSIG",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/kdoqaSOa5V",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZRCWxuL5bCk",
      "display_url" : "youtube.com\/watch?v=ZRCWxu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593768950812569600",
  "text" : "RT @taw_sig: #ELT \/ #ESL \/ #TEFL teachers - WE DID IT!!! 222 subscribers in 2 weeks!!! #TaWSIG #TaWSIG #TaWSIG https:\/\/t.co\/kdoqaSOa5V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 14, 19 ]
      }, {
        "text" : "TaWSIG",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "TaWSIG",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "TaWSIG",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/kdoqaSOa5V",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZRCWxuL5bCk",
        "display_url" : "youtube.com\/watch?v=ZRCWxu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593757126268461057",
    "text" : "#ELT \/ #ESL \/ #TEFL teachers - WE DID IT!!! 222 subscribers in 2 weeks!!! #TaWSIG #TaWSIG #TaWSIG https:\/\/t.co\/kdoqaSOa5V",
    "id" : 593757126268461057,
    "created_at" : "2015-04-30 12:41:45 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 593768950812569600,
  "created_at" : "2015-04-30 13:28:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593741957932933120",
  "geo" : { },
  "id_str" : "593765287977160704",
  "in_reply_to_user_id" : 1479898584,
  "text" : "@PaddytheRabbit lovely thank you :)",
  "id" : 593765287977160704,
  "in_reply_to_status_id" : 593741957932933120,
  "created_at" : "2015-04-30 13:14:10 +0000",
  "in_reply_to_screen_name" : "DavidMSherlock",
  "in_reply_to_user_id_str" : "1479898584",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593765204346941441",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock thx for RT :)",
  "id" : 593765204346941441,
  "created_at" : "2015-04-30 13:13:50 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593737142146326528",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga thx for RT :)",
  "id" : 593737142146326528,
  "created_at" : "2015-04-30 11:22:20 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593735107074199552",
  "geo" : { },
  "id_str" : "593736404838023168",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin hi thx, my pleasure :)",
  "id" : 593736404838023168,
  "in_reply_to_status_id" : 593735107074199552,
  "created_at" : "2015-04-30 11:19:24 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 12, 23 ],
      "id_str" : "228469472",
      "id" : 228469472
    }, {
      "name" : "peter stange",
      "screen_name" : "gingy2",
      "indices" : [ 24, 31 ],
      "id_str" : "25981177",
      "id" : 25981177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593723251651522560",
  "geo" : { },
  "id_str" : "593735965627326464",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @naomishema @gingy2 :) if u know others let me know :)",
  "id" : 593735965627326464,
  "in_reply_to_status_id" : 593723251651522560,
  "created_at" : "2015-04-30 11:17:39 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/soDtNlSS6F",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/04\/20\/iatefl-2015-recent-corpus-tools-for-your-students\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/04\/20\/iat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "593719004549746688",
  "geo" : { },
  "id_str" : "593719700745490432",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle hi it sure is :) included it with some other #corpus tools here if u haven't read it https:\/\/t.co\/soDtNlSS6F",
  "id" : 593719700745490432,
  "in_reply_to_status_id" : 593719004549746688,
  "created_at" : "2015-04-30 10:13:02 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 62, 69 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/7nUD4lAQTn",
      "expanded_url" : "http:\/\/wp.me\/pUvFH-gO",
      "display_url" : "wp.me\/pUvFH-gO"
    } ]
  },
  "geo" : { },
  "id_str" : "593717814109831168",
  "text" : "Post Manchester Iatefl Reflections http:\/\/t.co\/7nUD4lAQTn via @hartle",
  "id" : 593717814109831168,
  "created_at" : "2015-04-30 10:05:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 20, 34 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 40, 58 ]
    }, {
      "text" : "engcorpora2015",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/PlVXDeWO3H",
      "expanded_url" : "https:\/\/youtu.be\/pxJ7doUf9pU",
      "display_url" : "youtu.be\/pxJ7doUf9pU"
    } ]
  },
  "geo" : { },
  "id_str" : "593685409583988736",
  "text" : "John Williams &amp; @Glenn_Hadikin talk #corpuslinguistics &amp; memes at #engcorpora2015 https:\/\/t.co\/PlVXDeWO3H",
  "id" : 593685409583988736,
  "created_at" : "2015-04-30 07:56:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tri-TESOL Conference",
      "screen_name" : "tritesol",
      "indices" : [ 0, 9 ],
      "id_str" : "3215441645",
      "id" : 3215441645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593673027117690880",
  "geo" : { },
  "id_str" : "593684489156583425",
  "in_reply_to_user_id" : 3215441645,
  "text" : "@tritesol thanks for sharing :)",
  "id" : 593684489156583425,
  "in_reply_to_status_id" : 593673027117690880,
  "created_at" : "2015-04-30 07:53:06 +0000",
  "in_reply_to_screen_name" : "tritesol",
  "in_reply_to_user_id_str" : "3215441645",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "textivate",
      "screen_name" : "textivate",
      "indices" : [ 3, 13 ],
      "id_str" : "757151820",
      "id" : 757151820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitofpolitics",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/mjXxU8t2Mv",
      "expanded_url" : "http:\/\/www.textivate.com\/frames.php?vid=you-vbLGG5UGEKw&res=1in3-eenjn1&colscheme=blue",
      "display_url" : "textivate.com\/frames.php?vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593523499546771456",
  "text" : "RT @textivate: \"Cassette boy: Emperor\u2019s new clothes rap\"\nhttp:\/\/t.co\/mjXxU8t2Mv\n\n#bitofpolitics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitofpolitics",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/mjXxU8t2Mv",
        "expanded_url" : "http:\/\/www.textivate.com\/frames.php?vid=you-vbLGG5UGEKw&res=1in3-eenjn1&colscheme=blue",
        "display_url" : "textivate.com\/frames.php?vid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593519451812728832",
    "text" : "\"Cassette boy: Emperor\u2019s new clothes rap\"\nhttp:\/\/t.co\/mjXxU8t2Mv\n\n#bitofpolitics",
    "id" : 593519451812728832,
    "created_at" : "2015-04-29 20:57:19 +0000",
    "user" : {
      "name" : "textivate",
      "screen_name" : "textivate",
      "protected" : false,
      "id_str" : "757151820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616568320066764800\/rx5tLnzg_normal.png",
      "id" : 757151820,
      "verified" : false
    }
  },
  "id" : 593523499546771456,
  "created_at" : "2015-04-29 21:13:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593487051481317377",
  "geo" : { },
  "id_str" : "593515249933754368",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock my pleasure :)",
  "id" : 593515249933754368,
  "in_reply_to_status_id" : 593487051481317377,
  "created_at" : "2015-04-29 20:40:37 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/linguisticpulse\/status\/593436078087938048\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HipQqJmdad",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxO99AVIAI1SgM.png",
      "id_str" : "593436077160996866",
      "id" : 593436077160996866,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxO99AVIAI1SgM.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HipQqJmdad"
    } ],
    "hashtags" : [ {
      "text" : "baltimore",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "BaltimoreUprising",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/9QkDaP272w",
      "expanded_url" : "http:\/\/bit.ly\/1bexAvs",
      "display_url" : "bit.ly\/1bexAvs"
    } ]
  },
  "geo" : { },
  "id_str" : "593514602186452994",
  "text" : "RT @linguisticpulse: hey media, is #baltimore RIOTING or PROTESTING? (http:\/\/t.co\/9QkDaP272w) the difference matters. #BaltimoreUprising ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/linguisticpulse\/status\/593436078087938048\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/HipQqJmdad",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxO99AVIAI1SgM.png",
        "id_str" : "593436077160996866",
        "id" : 593436077160996866,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxO99AVIAI1SgM.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HipQqJmdad"
      } ],
      "hashtags" : [ {
        "text" : "baltimore",
        "indices" : [ 14, 24 ]
      }, {
        "text" : "BaltimoreUprising",
        "indices" : [ 97, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/9QkDaP272w",
        "expanded_url" : "http:\/\/bit.ly\/1bexAvs",
        "display_url" : "bit.ly\/1bexAvs"
      } ]
    },
    "geo" : { },
    "id_str" : "593436078087938048",
    "text" : "hey media, is #baltimore RIOTING or PROTESTING? (http:\/\/t.co\/9QkDaP272w) the difference matters. #BaltimoreUprising http:\/\/t.co\/HipQqJmdad",
    "id" : 593436078087938048,
    "created_at" : "2015-04-29 15:26:01 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 593514602186452994,
  "created_at" : "2015-04-29 20:38:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 6, 16 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "translation",
      "indices" : [ 32, 44 ]
    }, {
      "text" : "engcorpora2015",
      "indices" : [ 75, 90 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/KvzI7d8pru",
      "expanded_url" : "https:\/\/youtu.be\/kFclzdePyyA",
      "display_url" : "youtu.be\/kFclzdePyyA"
    } ]
  },
  "geo" : { },
  "id_str" : "593470465672355841",
  "text" : "Watch @RudyLoock talk about his #translation sts corpora of celeb obits at #engcorpora2015 #corpuslinguistics con https:\/\/t.co\/KvzI7d8pru",
  "id" : 593470465672355841,
  "created_at" : "2015-04-29 17:42:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "indices" : [ 3, 11 ],
      "id_str" : "96139902",
      "id" : 96139902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldaily",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/S21Avpj0Kf",
      "expanded_url" : "http:\/\/www.downes.ca\/post\/63799",
      "display_url" : "downes.ca\/post\/63799"
    } ]
  },
  "geo" : { },
  "id_str" : "593405338600263680",
  "text" : "RT @oldaily: Prime Minister David Cameron visits Microsoft Global Showcase School Sandymoor #oldaily http:\/\/t.co\/S21Avpj0Kf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.downes.ca\" rel=\"nofollow\"\u003EOLDaily\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oldaily",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/S21Avpj0Kf",
        "expanded_url" : "http:\/\/www.downes.ca\/post\/63799",
        "display_url" : "downes.ca\/post\/63799"
      } ]
    },
    "geo" : { },
    "id_str" : "592488159042080769",
    "text" : "Prime Minister David Cameron visits Microsoft Global Showcase School Sandymoor #oldaily http:\/\/t.co\/S21Avpj0Kf",
    "id" : 592488159042080769,
    "created_at" : "2015-04-27 00:39:19 +0000",
    "user" : {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "protected" : false,
      "id_str" : "96139902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000106238229\/f8a550530e001b52581340d3e3d8e60c_normal.jpeg",
      "id" : 96139902,
      "verified" : false
    }
  },
  "id" : 593405338600263680,
  "created_at" : "2015-04-29 13:23:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/D0J3KVxqi1",
      "expanded_url" : "https:\/\/scottthornbury.wordpress.com\/2015\/04\/26\/p-is-for-power\/#comment-20446",
      "display_url" : "scottthornbury.wordpress.com\/2015\/04\/26\/p-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593369296782434304",
  "text" : "RT @thornburyscott: 'There's a very real deterioration in [teachers'] working conditions and pay across the board' - salutary comment at ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/D0J3KVxqi1",
        "expanded_url" : "https:\/\/scottthornbury.wordpress.com\/2015\/04\/26\/p-is-for-power\/#comment-20446",
        "display_url" : "scottthornbury.wordpress.com\/2015\/04\/26\/p-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593358539877392384",
    "text" : "'There's a very real deterioration in [teachers'] working conditions and pay across the board' - salutary comment at https:\/\/t.co\/D0J3KVxqi1",
    "id" : 593358539877392384,
    "created_at" : "2015-04-29 10:17:54 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 593369296782434304,
  "created_at" : "2015-04-29 11:00:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Vl6cAGJoSw",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article41700.htm",
      "display_url" : "informationclearinghouse.info\/article41700.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593366888543100929",
  "text" : "Rise of the New Black Radicals By Chris Hedges http:\/\/t.co\/Vl6cAGJoSw",
  "id" : 593366888543100929,
  "created_at" : "2015-04-29 10:51:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593188583667834881",
  "geo" : { },
  "id_str" : "593188920336195584",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway cool :) he seems a very interesting character",
  "id" : 593188920336195584,
  "in_reply_to_status_id" : 593188583667834881,
  "created_at" : "2015-04-28 23:03:54 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593186580271095809",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher thanks kindly for RT :)",
  "id" : 593186580271095809,
  "created_at" : "2015-04-28 22:54:36 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "593180369777754112",
  "geo" : { },
  "id_str" : "593186468274765824",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway nice, John is a member of the CL community https:\/\/t.co\/gnEFqIeLpA",
  "id" : 593186468274765824,
  "in_reply_to_status_id" : 593180369777754112,
  "created_at" : "2015-04-28 22:54:09 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 0, 14 ],
      "id_str" : "118014141",
      "id" : 118014141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593153234027606016",
  "geo" : { },
  "id_str" : "593158051571589122",
  "in_reply_to_user_id" : 118014141,
  "text" : "@alexanderding thx, is there a write-up of it anywhere?",
  "id" : 593158051571589122,
  "in_reply_to_status_id" : 593153234027606016,
  "created_at" : "2015-04-28 21:01:14 +0000",
  "in_reply_to_screen_name" : "alexanderding",
  "in_reply_to_user_id_str" : "118014141",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/DWTg6gyEO1",
      "expanded_url" : "https:\/\/sites.google.com\/site\/casualconc\/Home",
      "display_url" : "sites.google.com\/site\/casualcon\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "593153284560531456",
  "geo" : { },
  "id_str" : "593157579418824705",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway with free antconc c no need to buy :) btw there is this free one for osx but it is somewhat clunky - https:\/\/t.co\/DWTg6gyEO1",
  "id" : 593157579418824705,
  "in_reply_to_status_id" : 593153284560531456,
  "created_at" : "2015-04-28 20:59:21 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593151963820367872",
  "geo" : { },
  "id_str" : "593152487613399042",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thx have u used this?",
  "id" : 593152487613399042,
  "in_reply_to_status_id" : 593151963820367872,
  "created_at" : "2015-04-28 20:39:07 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Riley-Jones",
      "screen_name" : "GoldLinguist",
      "indices" : [ 0, 13 ],
      "id_str" : "603879138",
      "id" : 603879138
    }, {
      "name" : "BALEAP",
      "screen_name" : "baleap",
      "indices" : [ 14, 21 ],
      "id_str" : "1359788672",
      "id" : 1359788672
    }, {
      "name" : "Steve Kirk",
      "screen_name" : "stiivkirk",
      "indices" : [ 22, 32 ],
      "id_str" : "69068757",
      "id" : 69068757
    }, {
      "name" : "Susie CowleyHaselden",
      "screen_name" : "SusieCowley",
      "indices" : [ 33, 45 ],
      "id_str" : "613540409",
      "id" : 613540409
    }, {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 46, 60 ],
      "id_str" : "118014141",
      "id" : 118014141
    }, {
      "name" : "Doctoral EAP",
      "screen_name" : "DoctoralEap",
      "indices" : [ 61, 73 ],
      "id_str" : "3201093550",
      "id" : 3201093550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593020755270598659",
  "geo" : { },
  "id_str" : "593151859218620416",
  "in_reply_to_user_id" : 603879138,
  "text" : "@GoldLinguist @baleap @stiivkirk @SusieCowley @alexanderding @DoctoralEap is that soon?",
  "id" : 593151859218620416,
  "in_reply_to_status_id" : 593020755270598659,
  "created_at" : "2015-04-28 20:36:38 +0000",
  "in_reply_to_screen_name" : "GoldLinguist",
  "in_reply_to_user_id_str" : "603879138",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593118685075795968",
  "geo" : { },
  "id_str" : "593121476288581632",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL don't remember character being all shouty what with the ALLCAPS :)",
  "id" : 593121476288581632,
  "in_reply_to_status_id" : 593118685075795968,
  "created_at" : "2015-04-28 18:35:54 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 16, 26 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 27, 40 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593120073595953153",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan @HanaTicha @rosemerebard many thanks for RTs and shares :)",
  "id" : 593120073595953153,
  "created_at" : "2015-04-28 18:30:19 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 69, 85 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/S8Ao3FJPUd",
      "expanded_url" : "http:\/\/wp.me\/pglsT-5mS",
      "display_url" : "wp.me\/pglsT-5mS"
    } ]
  },
  "geo" : { },
  "id_str" : "593035888931770369",
  "text" : "Cutthroat compounds in English morphology http:\/\/t.co\/S8Ao3FJPUd via @wordpressdotcom",
  "id" : 593035888931770369,
  "created_at" : "2015-04-28 12:55:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Veigga",
      "screen_name" : "TVeigga",
      "indices" : [ 3, 11 ],
      "id_str" : "3124589793",
      "id" : 3124589793
    }, {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 67, 83 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTTV",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "PassportsShouldNotMatter",
      "indices" : [ 112, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/QqxA4jFUza",
      "expanded_url" : "http:\/\/bit.ly\/1OxrloS",
      "display_url" : "bit.ly\/1OxrloS"
    } ]
  },
  "geo" : { },
  "id_str" : "593005733114970112",
  "text" : "RT @TVeigga: http:\/\/t.co\/QqxA4jFUza Our first interview on #ELTTV! @MarekKiczkowiak and I discuss equity in ELT #PassportsShouldNotMatter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marek Kiczkowiak",
        "screen_name" : "MarekKiczkowiak",
        "indices" : [ 54, 70 ],
        "id_str" : "2561325079",
        "id" : 2561325079
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTTV",
        "indices" : [ 46, 52 ]
      }, {
        "text" : "PassportsShouldNotMatter",
        "indices" : [ 99, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/QqxA4jFUza",
        "expanded_url" : "http:\/\/bit.ly\/1OxrloS",
        "display_url" : "bit.ly\/1OxrloS"
      } ]
    },
    "geo" : { },
    "id_str" : "592873707506393090",
    "text" : "http:\/\/t.co\/QqxA4jFUza Our first interview on #ELTTV! @MarekKiczkowiak and I discuss equity in ELT #PassportsShouldNotMatter",
    "id" : 592873707506393090,
    "created_at" : "2015-04-28 02:11:21 +0000",
    "user" : {
      "name" : "T. Veigga",
      "screen_name" : "TVeigga",
      "protected" : false,
      "id_str" : "3124589793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606139890250711040\/GUDIgZmG_normal.jpg",
      "id" : 3124589793,
      "verified" : false
    }
  },
  "id" : 593005733114970112,
  "created_at" : "2015-04-28 10:55:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 53, 68 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/e1nKollUFf",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1g2",
      "display_url" : "wp.me\/p3qkCB-1g2"
    } ]
  },
  "geo" : { },
  "id_str" : "593004849467432960",
  "text" : "Power in the ELT industry http:\/\/t.co\/e1nKollUFf via @GeoffreyJordan",
  "id" : 593004849467432960,
  "created_at" : "2015-04-28 10:52:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593000773925101568",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thanks for RT :)",
  "id" : 593000773925101568,
  "created_at" : "2015-04-28 10:36:16 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592988221367328768",
  "geo" : { },
  "id_str" : "593000716622548992",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike thanks for sharing and for your question :)",
  "id" : 593000716622548992,
  "in_reply_to_status_id" : 592988221367328768,
  "created_at" : "2015-04-28 10:36:02 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 67, 78 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "auselt",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "tesol",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "tefl",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/J162f5TFEv",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Wn",
      "display_url" : "wp.me\/pgHyE-Wn"
    } ]
  },
  "geo" : { },
  "id_str" : "592987132781670400",
  "text" : "Quick cup of COCA - compound words http:\/\/t.co\/J162f5TFEv #eltchat #eltchinwag #keltchat #auselt #tesol #tefl",
  "id" : 592987132781670400,
  "created_at" : "2015-04-28 09:42:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592972176141201408",
  "geo" : { },
  "id_str" : "592973981902381056",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike also don't forget to double check any result in concordance as sometimes the tagging of POS is off",
  "id" : 592973981902381056,
  "in_reply_to_status_id" : 592972176141201408,
  "created_at" : "2015-04-28 08:49:48 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592972176141201408",
  "geo" : { },
  "id_str" : "592972547517489152",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike adjective, you can click on question mark next to POS box to get links for parts of speech codes in COCA",
  "id" : 592972547517489152,
  "in_reply_to_status_id" : 592972176141201408,
  "created_at" : "2015-04-28 08:44:06 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592971491966324736",
  "geo" : { },
  "id_str" : "592972278872350720",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike hmm sounds like a new cup of coca is in order :)",
  "id" : 592972278872350720,
  "in_reply_to_status_id" : 592971491966324736,
  "created_at" : "2015-04-28 08:43:02 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/8MR2ts1txD",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=38905107",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "592970881162436609",
  "geo" : { },
  "id_str" : "592971898339926016",
  "in_reply_to_user_id" : 18602422,
  "text" : "@harrisonmike or even [*-*].[j*] - http:\/\/t.co\/8MR2ts1txD",
  "id" : 592971898339926016,
  "in_reply_to_status_id" : 592970881162436609,
  "created_at" : "2015-04-28 08:41:32 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/tQtTBH4yCy",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=38904940",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "592967129852465152",
  "geo" : { },
  "id_str" : "592970881162436609",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike have u tried coca-byu? e.g. [well-*].[j*] - http:\/\/t.co\/tQtTBH4yCy",
  "id" : 592970881162436609,
  "in_reply_to_status_id" : 592967129852465152,
  "created_at" : "2015-04-28 08:37:29 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Bednarek",
      "screen_name" : "Corpusling",
      "indices" : [ 3, 14 ],
      "id_str" : "2208665992",
      "id" : 2208665992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corpuslinguistics",
      "indices" : [ 73, 91 ]
    }, {
      "text" : "collocation",
      "indices" : [ 95, 107 ]
    }, {
      "text" : "keywords",
      "indices" : [ 108, 117 ]
    }, {
      "text" : "concordances",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/A2XLK7xsyo",
      "expanded_url" : "https:\/\/www.youtube.com\/user\/CorpusLingAnalysis",
      "display_url" : "youtube.com\/user\/CorpusLin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592794324875780098",
  "text" : "RT @Corpusling: A series of short (3-5mins) screencasts on Key Topics in #Corpuslinguistics eg #collocation #keywords #concordances: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corpuslinguistics",
        "indices" : [ 57, 75 ]
      }, {
        "text" : "collocation",
        "indices" : [ 79, 91 ]
      }, {
        "text" : "keywords",
        "indices" : [ 92, 101 ]
      }, {
        "text" : "concordances",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/A2XLK7xsyo",
        "expanded_url" : "https:\/\/www.youtube.com\/user\/CorpusLingAnalysis",
        "display_url" : "youtube.com\/user\/CorpusLin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592616677868638208",
    "text" : "A series of short (3-5mins) screencasts on Key Topics in #Corpuslinguistics eg #collocation #keywords #concordances: https:\/\/t.co\/A2XLK7xsyo",
    "id" : 592616677868638208,
    "created_at" : "2015-04-27 09:10:00 +0000",
    "user" : {
      "name" : "Monika Bednarek",
      "screen_name" : "Corpusling",
      "protected" : false,
      "id_str" : "2208665992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444356153636421634\/D70JwNc9_normal.jpeg",
      "id" : 2208665992,
      "verified" : false
    }
  },
  "id" : 592794324875780098,
  "created_at" : "2015-04-27 20:55:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Institute of Play",
      "screen_name" : "instituteofplay",
      "indices" : [ 0, 16 ],
      "id_str" : "14947998",
      "id" : 14947998
    }, {
      "name" : "HCLEMuseum",
      "screen_name" : "HCLEMuseum",
      "indices" : [ 17, 28 ],
      "id_str" : "1287422462",
      "id" : 1287422462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592696668342083584",
  "geo" : { },
  "id_str" : "592743987770974209",
  "in_reply_to_user_id" : 14947998,
  "text" : "@instituteofplay @HCLEMuseum hmm has it been published?",
  "id" : 592743987770974209,
  "in_reply_to_status_id" : 592696668342083584,
  "created_at" : "2015-04-27 17:35:53 +0000",
  "in_reply_to_screen_name" : "instituteofplay",
  "in_reply_to_user_id_str" : "14947998",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 3, 12 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    }, {
      "name" : "grassrootsELT",
      "screen_name" : "roots2go",
      "indices" : [ 95, 104 ],
      "id_str" : "3177454779",
      "id" : 3177454779
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 105, 113 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/4fRUNBvvXY",
      "expanded_url" : "https:\/\/ltelt.wordpress.com\/2015\/04\/27\/el-free\/",
      "display_url" : "ltelt.wordpress.com\/2015\/04\/27\/el-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592696473365643265",
  "text" : "RT @Liam_ELT: New blogpost! On the culture of working for free in ELT: https:\/\/t.co\/4fRUNBvvXY @roots2go @taw_sig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "grassrootsELT",
        "screen_name" : "roots2go",
        "indices" : [ 81, 90 ],
        "id_str" : "3177454779",
        "id" : 3177454779
      }, {
        "name" : "teachers_as_workers",
        "screen_name" : "taw_sig",
        "indices" : [ 91, 99 ],
        "id_str" : "3152637711",
        "id" : 3152637711
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/4fRUNBvvXY",
        "expanded_url" : "https:\/\/ltelt.wordpress.com\/2015\/04\/27\/el-free\/",
        "display_url" : "ltelt.wordpress.com\/2015\/04\/27\/el-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592687805278638081",
    "text" : "New blogpost! On the culture of working for free in ELT: https:\/\/t.co\/4fRUNBvvXY @roots2go @taw_sig",
    "id" : 592687805278638081,
    "created_at" : "2015-04-27 13:52:39 +0000",
    "user" : {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "protected" : false,
      "id_str" : "3165901457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587981501532340224\/zUoyjkD5_normal.png",
      "id" : 3165901457,
      "verified" : false
    }
  },
  "id" : 592696473365643265,
  "created_at" : "2015-04-27 14:27:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley",
      "screen_name" : "cioccas",
      "indices" : [ 3, 11 ],
      "id_str" : "227474018",
      "id" : 227474018
    }, {
      "name" : "Fiona Mauchline",
      "screen_name" : "fionamau",
      "indices" : [ 16, 25 ],
      "id_str" : "181518110",
      "id" : 181518110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ausELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/q4hJkjsP8u",
      "expanded_url" : "http:\/\/eflmagazine.com\/",
      "display_url" : "eflmagazine.com"
    } ]
  },
  "geo" : { },
  "id_str" : "592683968329310208",
  "text" : "RT @cioccas: RT @fionamau There's a new online ELT mag - free too! - with podcasts, articles, columns... Check it out http:\/\/t.co\/q4hJkjsP8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fiona Mauchline",
        "screen_name" : "fionamau",
        "indices" : [ 3, 12 ],
        "id_str" : "181518110",
        "id" : 181518110
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ausELT",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/q4hJkjsP8u",
        "expanded_url" : "http:\/\/eflmagazine.com\/",
        "display_url" : "eflmagazine.com"
      } ]
    },
    "geo" : { },
    "id_str" : "592682687514705921",
    "text" : "RT @fionamau There's a new online ELT mag - free too! - with podcasts, articles, columns... Check it out http:\/\/t.co\/q4hJkjsP8u #ausELT",
    "id" : 592682687514705921,
    "created_at" : "2015-04-27 13:32:18 +0000",
    "user" : {
      "name" : "Lesley",
      "screen_name" : "cioccas",
      "protected" : false,
      "id_str" : "227474018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627072938970255360\/EAJndCUy_normal.jpg",
      "id" : 227474018,
      "verified" : false
    }
  },
  "id" : 592683968329310208,
  "created_at" : "2015-04-27 13:37:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ctj3uvMSb6",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/4\/22\/43035\/9709",
      "display_url" : "eurotrib.com\/story\/2015\/4\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592681543354691585",
  "text" : "Operation underpants http:\/\/t.co\/ctj3uvMSb6",
  "id" : 592681543354691585,
  "created_at" : "2015-04-27 13:27:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "indices" : [ 3, 14 ],
      "id_str" : "1559079607",
      "id" : 1559079607
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 77, 92 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/owgnNu11rR",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/a-board-warmup-that-is-not-boring",
      "display_url" : "anthonyteacher.com\/blog\/a-board-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592679483821404160",
  "text" : "RT @TesalKoksi: A Board Warmup That Is Not Boring http:\/\/t.co\/owgnNu11rR via @AnthonyTeacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AnthonyTeacher",
        "screen_name" : "AnthonyTeacher",
        "indices" : [ 61, 76 ],
        "id_str" : "285614027",
        "id" : 285614027
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/owgnNu11rR",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/a-board-warmup-that-is-not-boring",
        "display_url" : "anthonyteacher.com\/blog\/a-board-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592576171516243968",
    "text" : "A Board Warmup That Is Not Boring http:\/\/t.co\/owgnNu11rR via @AnthonyTeacher",
    "id" : 592576171516243968,
    "created_at" : "2015-04-27 06:29:03 +0000",
    "user" : {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "protected" : false,
      "id_str" : "1559079607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754294097939140608\/DAVljhdE_normal.jpg",
      "id" : 1559079607,
      "verified" : false
    }
  },
  "id" : 592679483821404160,
  "created_at" : "2015-04-27 13:19:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592518899368787970",
  "geo" : { },
  "id_str" : "592679268892680192",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith  a nice reminder of giving some serious thought when using \"technology\" in class, not easy to do with the tech evangelism around",
  "id" : 592679268892680192,
  "in_reply_to_status_id" : 592518899368787970,
  "created_at" : "2015-04-27 13:18:43 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry cuban",
      "screen_name" : "CubanLarry",
      "indices" : [ 120, 131 ],
      "id_str" : "2324494104",
      "id" : 2324494104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BiExSkJzSQ",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-2pW",
      "display_url" : "wp.me\/pBm7c-2pW"
    } ]
  },
  "geo" : { },
  "id_str" : "592314567495176192",
  "text" : "Lessons Learned from a Chalkboard: Slow and Steady Technology Integration (Bradley Emerling) http:\/\/t.co\/BiExSkJzSQ via @CubanLarry",
  "id" : 592314567495176192,
  "created_at" : "2015-04-26 13:09:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/cFiGKW755u",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2015\/04\/26\/student-voices-issue\/",
      "display_url" : "itdi.pro\/blog\/2015\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592282093478125568",
  "text" : "RT @kevchanwow: Students sharing their ideas on teaching, teachers, &amp; learning at the #iTDi blog: http:\/\/t.co\/cFiGKW755u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 74, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/cFiGKW755u",
        "expanded_url" : "http:\/\/itdi.pro\/blog\/2015\/04\/26\/student-voices-issue\/",
        "display_url" : "itdi.pro\/blog\/2015\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592204263624835072",
    "text" : "Students sharing their ideas on teaching, teachers, &amp; learning at the #iTDi blog: http:\/\/t.co\/cFiGKW755u",
    "id" : 592204263624835072,
    "created_at" : "2015-04-26 05:51:13 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 592282093478125568,
  "created_at" : "2015-04-26 11:00:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "EFL",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kXVXwoV7ud",
      "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/04\/asking-more-why-some-questions-are-better-than-others",
      "display_url" : "lexicallab.com\/2015\/04\/asking\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592282094015016962",
  "text" : "RT @hughdellar: #ELT #EFL New post on why some kinds of questions are better than others and the problem with using CCQs with lexis: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "EFL",
        "indices" : [ 5, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kXVXwoV7ud",
        "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/04\/asking-more-why-some-questions-are-better-than-others",
        "display_url" : "lexicallab.com\/2015\/04\/asking\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592246632835633152",
    "text" : "#ELT #EFL New post on why some kinds of questions are better than others and the problem with using CCQs with lexis: http:\/\/t.co\/kXVXwoV7ud",
    "id" : 592246632835633152,
    "created_at" : "2015-04-26 08:39:35 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 592282094015016962,
  "created_at" : "2015-04-26 11:00:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592219157795573760",
  "geo" : { },
  "id_str" : "592234319667658752",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja nice program is it free?",
  "id" : 592234319667658752,
  "in_reply_to_status_id" : 592219157795573760,
  "created_at" : "2015-04-26 07:50:39 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 3, 13 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 15, 24 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 25, 41 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Adobe",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "Slate",
      "indices" : [ 122, 128 ]
    }, {
      "text" : "edTech",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/IjABlWGFgF",
      "expanded_url" : "http:\/\/goo.gl\/F7vvOX",
      "display_url" : "goo.gl\/F7vvOX"
    } ]
  },
  "geo" : { },
  "id_str" : "592234211194630144",
  "text" : "RT @TEFLninja: @muranava @wordpressdotcom \n\nHectoring ? \n\n&lt;deeply hurt emoticon&gt;\n\nhttp:\/\/t.co\/IjABlWGFgF\n\nPS #Adobe #Slate for #edTech app \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 10, 26 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Adobe",
        "indices" : [ 100, 106 ]
      }, {
        "text" : "Slate",
        "indices" : [ 107, 113 ]
      }, {
        "text" : "edTech",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/IjABlWGFgF",
        "expanded_url" : "http:\/\/goo.gl\/F7vvOX",
        "display_url" : "goo.gl\/F7vvOX"
      } ]
    },
    "in_reply_to_status_id_str" : "592212260807925760",
    "geo" : { },
    "id_str" : "592219157795573760",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava @wordpressdotcom \n\nHectoring ? \n\n&lt;deeply hurt emoticon&gt;\n\nhttp:\/\/t.co\/IjABlWGFgF\n\nPS #Adobe #Slate for #edTech app of the year !",
    "id" : 592219157795573760,
    "in_reply_to_status_id" : 592212260807925760,
    "created_at" : "2015-04-26 06:50:24 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "protected" : false,
      "id_str" : "3131267981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583575211745894400\/TmUR03jo_normal.jpg",
      "id" : 3131267981,
      "verified" : false
    }
  },
  "id" : 592234211194630144,
  "created_at" : "2015-04-26 07:50:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "justice",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "equity",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/H6qXXnoC0L",
      "expanded_url" : "http:\/\/narrative.ly\/stories\/cruel-education-for-baghdads-toughest-teacher\/",
      "display_url" : "narrative.ly\/stories\/cruel-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592223112814530560",
  "text" : "RT @courosa: \"A cruel education for Bagdad's toughest teacher\" http:\/\/t.co\/H6qXXnoC0L #edchat #justice #equity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "justice",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "equity",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/H6qXXnoC0L",
        "expanded_url" : "http:\/\/narrative.ly\/stories\/cruel-education-for-baghdads-toughest-teacher\/",
        "display_url" : "narrative.ly\/stories\/cruel-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592100730321797120",
    "text" : "\"A cruel education for Bagdad's toughest teacher\" http:\/\/t.co\/H6qXXnoC0L #edchat #justice #equity",
    "id" : 592100730321797120,
    "created_at" : "2015-04-25 22:59:49 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 592223112814530560,
  "created_at" : "2015-04-26 07:06:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 42, 58 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/wYMpz7vAId",
      "expanded_url" : "http:\/\/wp.me\/pJw7u-1hq",
      "display_url" : "wp.me\/pJw7u-1hq"
    } ]
  },
  "geo" : { },
  "id_str" : "592212260807925760",
  "text" : "P is for Power http:\/\/t.co\/wYMpz7vAId via @wordpressdotcom",
  "id" : 592212260807925760,
  "created_at" : "2015-04-26 06:23:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/JLFKT2nkku",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/04\/25\/factory-model\/",
      "display_url" : "hackeducation.com\/2015\/04\/25\/fac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591961440480788480",
  "text" : "RT @audreywatters: The Invented History of \"The Factory Model of Education\" http:\/\/t.co\/JLFKT2nkku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/JLFKT2nkku",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/04\/25\/factory-model\/",
        "display_url" : "hackeducation.com\/2015\/04\/25\/fac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591915117564076032",
    "text" : "The Invented History of \"The Factory Model of Education\" http:\/\/t.co\/JLFKT2nkku",
    "id" : 591915117564076032,
    "created_at" : "2015-04-25 10:42:15 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 591961440480788480,
  "created_at" : "2015-04-25 13:46:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "indices" : [ 3, 15 ],
      "id_str" : "2491487924",
      "id" : 2491487924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/EF66XNhalS",
      "expanded_url" : "http:\/\/schoolsweek.co.uk\/protesters-gatecrash-pearsons-annual-general-meeting-over-education-privatisation-concerns\/",
      "display_url" : "schoolsweek.co.uk\/protesters-gat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591686483226001408",
  "text" : "RT @SchoolsWeek: Protesters gatecrashed Pearson's AGM today. Find out why here - http:\/\/t.co\/EF66XNhalS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/EF66XNhalS",
        "expanded_url" : "http:\/\/schoolsweek.co.uk\/protesters-gatecrash-pearsons-annual-general-meeting-over-education-privatisation-concerns\/",
        "display_url" : "schoolsweek.co.uk\/protesters-gat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591647050082738176",
    "text" : "Protesters gatecrashed Pearson's AGM today. Find out why here - http:\/\/t.co\/EF66XNhalS",
    "id" : 591647050082738176,
    "created_at" : "2015-04-24 16:57:03 +0000",
    "user" : {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "protected" : false,
      "id_str" : "2491487924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552459478465904640\/rO10ze_u_normal.jpeg",
      "id" : 2491487924,
      "verified" : false
    }
  },
  "id" : 591686483226001408,
  "created_at" : "2015-04-24 19:33:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan",
      "screen_name" : "PUNK3R22",
      "indices" : [ 3, 12 ],
      "id_str" : "396068452",
      "id" : 396068452
    }, {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "indices" : [ 14, 30 ],
      "id_str" : "303429700",
      "id" : 303429700
    }, {
      "name" : "Nic James",
      "screen_name" : "nicfromwales",
      "indices" : [ 31, 44 ],
      "id_str" : "280158255",
      "id" : 280158255
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PUNK3R22\/status\/591672556664553472\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/HXtOKBkV52",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDYLDdhWoAENrH4.jpg",
      "id_str" : "591672555137835009",
      "id" : 591672555137835009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDYLDdhWoAENrH4.jpg",
      "sizes" : [ {
        "h" : 547,
        "resize" : "fit",
        "w" : 538
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 538
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 538
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HXtOKBkV52"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591685441839071232",
  "text" : "RT @PUNK3R22: @welshnotbritish @nicfromwales sums up my thoughts on labour http:\/\/t.co\/HXtOKBkV52",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Welsh not British",
        "screen_name" : "welshnotbritish",
        "indices" : [ 0, 16 ],
        "id_str" : "303429700",
        "id" : 303429700
      }, {
        "name" : "Nic James",
        "screen_name" : "nicfromwales",
        "indices" : [ 17, 30 ],
        "id_str" : "280158255",
        "id" : 280158255
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PUNK3R22\/status\/591672556664553472\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/HXtOKBkV52",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDYLDdhWoAENrH4.jpg",
        "id_str" : "591672555137835009",
        "id" : 591672555137835009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDYLDdhWoAENrH4.jpg",
        "sizes" : [ {
          "h" : 547,
          "resize" : "fit",
          "w" : 538
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 538
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 538
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HXtOKBkV52"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "591666606658334720",
    "geo" : { },
    "id_str" : "591672556664553472",
    "in_reply_to_user_id" : 303429700,
    "text" : "@welshnotbritish @nicfromwales sums up my thoughts on labour http:\/\/t.co\/HXtOKBkV52",
    "id" : 591672556664553472,
    "in_reply_to_status_id" : 591666606658334720,
    "created_at" : "2015-04-24 18:38:24 +0000",
    "in_reply_to_screen_name" : "welshnotbritish",
    "in_reply_to_user_id_str" : "303429700",
    "user" : {
      "name" : "Morgan",
      "screen_name" : "PUNK3R22",
      "protected" : false,
      "id_str" : "396068452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718388022379692032\/2PsU7V7N_normal.jpg",
      "id" : 396068452,
      "verified" : false
    }
  },
  "id" : 591685441839071232,
  "created_at" : "2015-04-24 19:29:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "indices" : [ 3, 12 ],
      "id_str" : "2211139201",
      "id" : 2211139201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/5P8pxuFRdh",
      "expanded_url" : "http:\/\/commoncrawl.org\/the-data\/get-started\/",
      "display_url" : "commoncrawl.org\/the-data\/get-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591664443098013697",
  "text" : "RT @FORGE_LU: Get started with the Common Crawl Corpus, containing online data collected over 7 years: http:\/\/t.co\/5P8pxuFRdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/5P8pxuFRdh",
        "expanded_url" : "http:\/\/commoncrawl.org\/the-data\/get-started\/",
        "display_url" : "commoncrawl.org\/the-data\/get-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591649596088127489",
    "text" : "Get started with the Common Crawl Corpus, containing online data collected over 7 years: http:\/\/t.co\/5P8pxuFRdh",
    "id" : 591649596088127489,
    "created_at" : "2015-04-24 17:07:10 +0000",
    "user" : {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "protected" : false,
      "id_str" : "2211139201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426766695777058817\/npxHPteK_normal.png",
      "id" : 2211139201,
      "verified" : false
    }
  },
  "id" : 591664443098013697,
  "created_at" : "2015-04-24 18:06:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "Plaid Cymru",
      "screen_name" : "Plaid_Cymru",
      "indices" : [ 10, 22 ],
      "id_str" : "14411725",
      "id" : 14411725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591644679818633216",
  "geo" : { },
  "id_str" : "591647973106458625",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson @Plaid_Cymru hehe :)",
  "id" : 591647973106458625,
  "in_reply_to_status_id" : 591644679818633216,
  "created_at" : "2015-04-24 17:00:43 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "indices" : [ 3, 15 ],
      "id_str" : "2491487924",
      "id" : 2491487924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tellpearson",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591601428063506432",
  "text" : "RT @SchoolsWeek: Re spying on kids in America, Fallon says company has responsibility to ensure tests are fair. #tellpearson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tellpearson",
        "indices" : [ 95, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591575715243544576",
    "text" : "Re spying on kids in America, Fallon says company has responsibility to ensure tests are fair. #tellpearson",
    "id" : 591575715243544576,
    "created_at" : "2015-04-24 12:13:36 +0000",
    "user" : {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "protected" : false,
      "id_str" : "2491487924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552459478465904640\/rO10ze_u_normal.jpeg",
      "id" : 2491487924,
      "verified" : false
    }
  },
  "id" : 591601428063506432,
  "created_at" : "2015-04-24 13:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "indices" : [ 3, 15 ],
      "id_str" : "2491487924",
      "id" : 2491487924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tellpearson",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591601198123319296",
  "text" : "RT @SchoolsWeek: Fallon: profit is by product of doing something really useful to society and doing it really well #tellpearson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tellpearson",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591575262015463425",
    "text" : "Fallon: profit is by product of doing something really useful to society and doing it really well #tellpearson",
    "id" : 591575262015463425,
    "created_at" : "2015-04-24 12:11:48 +0000",
    "user" : {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "protected" : false,
      "id_str" : "2491487924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552459478465904640\/rO10ze_u_normal.jpeg",
      "id" : 2491487924,
      "verified" : false
    }
  },
  "id" : 591601198123319296,
  "created_at" : "2015-04-24 13:54:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Old",
      "screen_name" : "oldandrewuk",
      "indices" : [ 0, 12 ],
      "id_str" : "97858519",
      "id" : 97858519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591595916752195588",
  "geo" : { },
  "id_str" : "591598686980993024",
  "in_reply_to_user_id" : 97858519,
  "text" : "@oldandrewuk it is enough that they +are+ never mind +do+ :)",
  "id" : 591598686980993024,
  "in_reply_to_status_id" : 591595916752195588,
  "created_at" : "2015-04-24 13:44:53 +0000",
  "in_reply_to_screen_name" : "oldandrewuk",
  "in_reply_to_user_id_str" : "97858519",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "python",
      "indices" : [ 114, 121 ]
    }, {
      "text" : "elt",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "corpus",
      "indices" : [ 127, 134 ]
    }, {
      "text" : "code",
      "indices" : [ 135, 140 ]
    }, {
      "text" : "nlp",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "nltk",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/fM5V0Qxyc6",
      "expanded_url" : "http:\/\/goo.gl\/kXm4Do",
      "display_url" : "goo.gl\/kXm4Do"
    } ]
  },
  "geo" : { },
  "id_str" : "591595377687662592",
  "text" : "RT @heyboyle: What's a python dictionary? My notes on Ch. 1 of the Python NLTK tutorial http:\/\/t.co\/fM5V0Qxyc6  \u2026 #python #elt #corpus #cod\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "python",
        "indices" : [ 100, 107 ]
      }, {
        "text" : "elt",
        "indices" : [ 108, 112 ]
      }, {
        "text" : "corpus",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "code",
        "indices" : [ 121, 126 ]
      }, {
        "text" : "nlp",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "nltk",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/fM5V0Qxyc6",
        "expanded_url" : "http:\/\/goo.gl\/kXm4Do",
        "display_url" : "goo.gl\/kXm4Do"
      } ]
    },
    "geo" : { },
    "id_str" : "591593445363478528",
    "text" : "What's a python dictionary? My notes on Ch. 1 of the Python NLTK tutorial http:\/\/t.co\/fM5V0Qxyc6  \u2026 #python #elt #corpus #code #nlp #nltk",
    "id" : 591593445363478528,
    "created_at" : "2015-04-24 13:24:03 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 591595377687662592,
  "created_at" : "2015-04-24 13:31:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 3, 15 ],
      "id_str" : "142598896",
      "id" : 142598896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 145, 146 ]
    }, {
      "text" : "edtech",
      "indices" : [ 145, 146 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/rigz6ihrKa",
      "expanded_url" : "http:\/\/academia.edu",
      "display_url" : "academia.edu"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/d3Mpl1JmD7",
      "expanded_url" : "http:\/\/bit.ly\/1O7mF9g",
      "display_url" : "bit.ly\/1O7mF9g"
    } ]
  },
  "geo" : { },
  "id_str" : "591588908229652480",
  "text" : "RT @Neil_Selwyn: &lt;Exploring the role of digital data in contemporary schools&gt; article via http:\/\/t.co\/rigz6ihrKa - http:\/\/t.co\/d3Mpl1JmD7 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 127, 134 ]
      }, {
        "text" : "edtech",
        "indices" : [ 135, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/rigz6ihrKa",
        "expanded_url" : "http:\/\/academia.edu",
        "display_url" : "academia.edu"
      }, {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/d3Mpl1JmD7",
        "expanded_url" : "http:\/\/bit.ly\/1O7mF9g",
        "display_url" : "bit.ly\/1O7mF9g"
      } ]
    },
    "geo" : { },
    "id_str" : "590093958082011136",
    "text" : "&lt;Exploring the role of digital data in contemporary schools&gt; article via http:\/\/t.co\/rigz6ihrKa - http:\/\/t.co\/d3Mpl1JmD7 #edchat #edtech",
    "id" : 590093958082011136,
    "created_at" : "2015-04-20 10:05:37 +0000",
    "user" : {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "protected" : false,
      "id_str" : "142598896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726948956538728448\/nzGgydvr_normal.jpg",
      "id" : 142598896,
      "verified" : false
    }
  },
  "id" : 591588908229652480,
  "created_at" : "2015-04-24 13:06:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 3, 15 ],
      "id_str" : "142598896",
      "id" : 142598896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rigz6ihrKa",
      "expanded_url" : "http:\/\/academia.edu",
      "display_url" : "academia.edu"
    }, {
      "indices" : [ 145, 146 ],
      "url" : "http:\/\/t.co\/ce4xQRFsK6",
      "expanded_url" : "http:\/\/bit.ly\/1zAXGiu",
      "display_url" : "bit.ly\/1zAXGiu"
    } ]
  },
  "geo" : { },
  "id_str" : "591588875635662848",
  "text" : "RT @Neil_Selwyn: &lt; What works and why? University students' perceptions of \u2018useful' #edtech &gt; article via http:\/\/t.co\/rigz6ihrKa - http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/rigz6ihrKa",
        "expanded_url" : "http:\/\/academia.edu",
        "display_url" : "academia.edu"
      }, {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/ce4xQRFsK6",
        "expanded_url" : "http:\/\/bit.ly\/1zAXGiu",
        "display_url" : "bit.ly\/1zAXGiu"
      } ]
    },
    "geo" : { },
    "id_str" : "590093587326509056",
    "text" : "&lt; What works and why? University students' perceptions of \u2018useful' #edtech &gt; article via http:\/\/t.co\/rigz6ihrKa - http:\/\/t.co\/ce4xQRFsK6",
    "id" : 590093587326509056,
    "created_at" : "2015-04-20 10:04:09 +0000",
    "user" : {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "protected" : false,
      "id_str" : "142598896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726948956538728448\/nzGgydvr_normal.jpg",
      "id" : 142598896,
      "verified" : false
    }
  },
  "id" : 591588875635662848,
  "created_at" : "2015-04-24 13:05:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "indices" : [ 3, 15 ],
      "id_str" : "2491487924",
      "id" : 2491487924
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SchoolsWeek\/status\/591553133358223360\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TXm3i1LzdY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDWecMKWEAAJvgn.jpg",
      "id_str" : "591553133207228416",
      "id" : 591553133207228416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDWecMKWEAAJvgn.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TXm3i1LzdY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591585062770106368",
  "text" : "RT @SchoolsWeek: Protesters outside Pearson AGM.They are campaigning against high stakes testing and private education in global south http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SchoolsWeek\/status\/591553133358223360\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/TXm3i1LzdY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDWecMKWEAAJvgn.jpg",
        "id_str" : "591553133207228416",
        "id" : 591553133207228416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDWecMKWEAAJvgn.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TXm3i1LzdY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591553133358223360",
    "text" : "Protesters outside Pearson AGM.They are campaigning against high stakes testing and private education in global south http:\/\/t.co\/TXm3i1LzdY",
    "id" : 591553133358223360,
    "created_at" : "2015-04-24 10:43:52 +0000",
    "user" : {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "protected" : false,
      "id_str" : "2491487924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552459478465904640\/rO10ze_u_normal.jpeg",
      "id" : 2491487924,
      "verified" : false
    }
  },
  "id" : 591585062770106368,
  "created_at" : "2015-04-24 12:50:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura McInerney",
      "screen_name" : "miss_mcinerney",
      "indices" : [ 3, 18 ],
      "id_str" : "41098406",
      "id" : 41098406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591584540294045696",
  "text" : "RT @miss_mcinerney: Appears that protestors are gathering at shareholder meeting of Pearson, the exam board operator. Anger at 'high stakes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591538640637009920",
    "text" : "Appears that protestors are gathering at shareholder meeting of Pearson, the exam board operator. Anger at 'high stakes testing'.",
    "id" : 591538640637009920,
    "created_at" : "2015-04-24 09:46:16 +0000",
    "user" : {
      "name" : "Laura McInerney",
      "screen_name" : "miss_mcinerney",
      "protected" : false,
      "id_str" : "41098406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746605606581207040\/0aqAlp0U_normal.jpg",
      "id" : 41098406,
      "verified" : true
    }
  },
  "id" : 591584540294045696,
  "created_at" : "2015-04-24 12:48:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/UYXrj776Y4",
      "expanded_url" : "http:\/\/www.dur.ac.uk\/foundation.focus\/external",
      "display_url" : "dur.ac.uk\/foundation.foc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "591552379570540544",
  "geo" : { },
  "id_str" : "591558126006046721",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen the Focus corpus has chemistry texts http:\/\/t.co\/UYXrj776Y4 u cld also enquire about access to their chem exercises",
  "id" : 591558126006046721,
  "in_reply_to_status_id" : 591552379570540544,
  "created_at" : "2015-04-24 11:03:42 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Fiona Price",
      "screen_name" : "fionaljp",
      "indices" : [ 12, 21 ],
      "id_str" : "251372057",
      "id" : 251372057
    }, {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 22, 37 ],
      "id_str" : "309578964",
      "id" : 309578964
    }, {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 38, 46 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    }, {
      "name" : "Theodora Pap",
      "screen_name" : "dorapap72",
      "indices" : [ 47, 57 ],
      "id_str" : "124145035",
      "id" : 124145035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591512013462962176",
  "geo" : { },
  "id_str" : "591548246826344448",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @fionaljp @angelos_bollas @olyaelt @dorapap72 thx have a great w\/e folks :)",
  "id" : 591548246826344448,
  "in_reply_to_status_id" : 591512013462962176,
  "created_at" : "2015-04-24 10:24:27 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yutaka Ishii (\u77F3\u4E95\u96C4\u9686)",
      "screen_name" : "yishii_0207",
      "indices" : [ 0, 12 ],
      "id_str" : "171376048",
      "id" : 171376048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/jHY7hUb9Hi",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/QtLDDDLLXbQ",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "591310666214047745",
  "geo" : { },
  "id_str" : "591511361613471744",
  "in_reply_to_user_id" : 171376048,
  "text" : "@yishii_0207 hi fyi there is an interview with Ivor Timmis about book https:\/\/t.co\/jHY7hUb9Hi",
  "id" : 591511361613471744,
  "in_reply_to_status_id" : 591310666214047745,
  "created_at" : "2015-04-24 07:57:53 +0000",
  "in_reply_to_screen_name" : "yishii_0207",
  "in_reply_to_user_id_str" : "171376048",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Osborne House",
      "screen_name" : "osbornehouse1",
      "indices" : [ 0, 14 ],
      "id_str" : "3133955877",
      "id" : 3133955877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591505181927342081",
  "in_reply_to_user_id" : 3133955877,
  "text" : "@osbornehouse1 thx for RT :)",
  "id" : 591505181927342081,
  "created_at" : "2015-04-24 07:33:19 +0000",
  "in_reply_to_screen_name" : "osbornehouse1",
  "in_reply_to_user_id_str" : "3133955877",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maddie Boldero Rito",
      "screen_name" : "MaddieRito",
      "indices" : [ 0, 11 ],
      "id_str" : "2802897028",
      "id" : 2802897028
    }, {
      "name" : "Heather Buchanan",
      "screen_name" : "HeatherBu2011",
      "indices" : [ 12, 26 ],
      "id_str" : "243323218",
      "id" : 243323218
    }, {
      "name" : "Richard Badger",
      "screen_name" : "RichardBadger2",
      "indices" : [ 27, 42 ],
      "id_str" : "382586050",
      "id" : 382586050
    }, {
      "name" : "Louise Guyett",
      "screen_name" : "Louiseguyett",
      "indices" : [ 43, 56 ],
      "id_str" : "47996448",
      "id" : 47996448
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 57, 65 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "TESL PHE",
      "screen_name" : "TESLPHE",
      "indices" : [ 66, 74 ],
      "id_str" : "2402277127",
      "id" : 2402277127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591480636512174081",
  "in_reply_to_user_id" : 2802897028,
  "text" : "@MaddieRito @HeatherBu2011 @RichardBadger2 @Louiseguyett @seburnt @TESLPHE many thx for sharing &amp; RTs :)",
  "id" : 591480636512174081,
  "created_at" : "2015-04-24 05:55:47 +0000",
  "in_reply_to_screen_name" : "MaddieRito",
  "in_reply_to_user_id_str" : "2802897028",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591325017234739201",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C appreciate RT :)",
  "id" : 591325017234739201,
  "created_at" : "2015-04-23 19:37:25 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591318711686008832",
  "geo" : { },
  "id_str" : "591324401787764739",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass hi thx for sharing :)",
  "id" : 591324401787764739,
  "in_reply_to_status_id" : 591318711686008832,
  "created_at" : "2015-04-23 19:34:58 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Mexico",
      "screen_name" : "MacmillanMexico",
      "indices" : [ 0, 16 ],
      "id_str" : "66474084",
      "id" : 66474084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591318847455682561",
  "in_reply_to_user_id" : 66474084,
  "text" : "@MacmillanMexico thx for sharing post :)",
  "id" : 591318847455682561,
  "created_at" : "2015-04-23 19:12:54 +0000",
  "in_reply_to_screen_name" : "MacmillanMexico",
  "in_reply_to_user_id_str" : "66474084",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591318647076945920",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx for RT Rose :)",
  "id" : 591318647076945920,
  "created_at" : "2015-04-23 19:12:06 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 12, 20 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 21, 32 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 33, 39 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 40, 52 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 53, 64 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    }, {
      "name" : "Susie CowleyHaselden",
      "screen_name" : "SusieCowley",
      "indices" : [ 65, 77 ],
      "id_str" : "613540409",
      "id" : 613540409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591238507542220800",
  "geo" : { },
  "id_str" : "591317856870125568",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @seburnt @JenMac_ESL @ebefl @nathanghall @DustinAcEd @SusieCowley no CB but occasionally dip into comm activities for eap",
  "id" : 591317856870125568,
  "in_reply_to_status_id" : 591238507542220800,
  "created_at" : "2015-04-23 19:08:57 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 12, 24 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "CollinsELT",
      "screen_name" : "CollinsELT",
      "indices" : [ 25, 36 ],
      "id_str" : "389406441",
      "id" : 389406441
    }, {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 37, 49 ],
      "id_str" : "96138105",
      "id" : 96138105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591207124287492096",
  "geo" : { },
  "id_str" : "591207572205674497",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @lexicojules @CollinsELT @claire_hart some access free full access subscription",
  "id" : 591207572205674497,
  "in_reply_to_status_id" : 591207124287492096,
  "created_at" : "2015-04-23 11:50:43 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "CollinsELT",
      "screen_name" : "CollinsELT",
      "indices" : [ 13, 24 ],
      "id_str" : "389406441",
      "id" : 389406441
    }, {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 25, 37 ],
      "id_str" : "96138105",
      "id" : 96138105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591201891784269824",
  "geo" : { },
  "id_str" : "591204531352035329",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @CollinsELT @claire_hart apparently it's not going to be fully open",
  "id" : 591204531352035329,
  "in_reply_to_status_id" : 591201891784269824,
  "created_at" : "2015-04-23 11:38:38 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CollinsELT",
      "screen_name" : "CollinsELT",
      "indices" : [ 0, 11 ],
      "id_str" : "389406441",
      "id" : 389406441
    }, {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 12, 24 ],
      "id_str" : "96138105",
      "id" : 96138105
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 25, 37 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591184367017426944",
  "geo" : { },
  "id_str" : "591186033238286336",
  "in_reply_to_user_id" : 389406441,
  "text" : "@CollinsELT @claire_hart @lexicojules nice news about open access corpus :)",
  "id" : 591186033238286336,
  "in_reply_to_status_id" : 591184367017426944,
  "created_at" : "2015-04-23 10:25:08 +0000",
  "in_reply_to_screen_name" : "CollinsELT",
  "in_reply_to_user_id_str" : "389406441",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CollinsELT",
      "screen_name" : "CollinsELT",
      "indices" : [ 3, 14 ],
      "id_str" : "389406441",
      "id" : 389406441
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 143, 144 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/XKFJdruONa",
      "expanded_url" : "http:\/\/lexicoblog.blogspot.co.uk\/2015\/04\/iatefl-slides-and-new-corpus.html",
      "display_url" : "lexicoblog.blogspot.co.uk\/2015\/04\/iatefl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591185956939653120",
  "text" : "RT @CollinsELT: Julie Moore's #IATEFL talk&amp;slides 'Dictionary evolution:exploiting modern referencing tools to the max' http:\/\/t.co\/XKFJdru\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Moore",
        "screen_name" : "lexicojules",
        "indices" : [ 131, 143 ],
        "id_str" : "424320799",
        "id" : 424320799
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 14, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/XKFJdruONa",
        "expanded_url" : "http:\/\/lexicoblog.blogspot.co.uk\/2015\/04\/iatefl-slides-and-new-corpus.html",
        "display_url" : "lexicoblog.blogspot.co.uk\/2015\/04\/iatefl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591184367017426944",
    "text" : "Julie Moore's #IATEFL talk&amp;slides 'Dictionary evolution:exploiting modern referencing tools to the max' http:\/\/t.co\/XKFJdruONa @lexicojules",
    "id" : 591184367017426944,
    "created_at" : "2015-04-23 10:18:31 +0000",
    "user" : {
      "name" : "CollinsELT",
      "screen_name" : "CollinsELT",
      "protected" : false,
      "id_str" : "389406441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2658111296\/d06eb96b74b2b88552b44f8f53ef5606_normal.jpeg",
      "id" : 389406441,
      "verified" : false
    }
  },
  "id" : 591185956939653120,
  "created_at" : "2015-04-23 10:24:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 16, 28 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591166358538289152",
  "text" : "RT @medialens: .@OwenJones84 The elitist, Oxbridge propaganda view of a dumb, mindlessly angry, always in-fighting left. A potent lie - why\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 1, 13 ],
        "id_str" : "65045121",
        "id" : 65045121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "591141012136992768",
    "geo" : { },
    "id_str" : "591144804244926464",
    "in_reply_to_user_id" : 65045121,
    "text" : ".@OwenJones84 The elitist, Oxbridge propaganda view of a dumb, mindlessly angry, always in-fighting left. A potent lie - why it's so famous.",
    "id" : 591144804244926464,
    "in_reply_to_status_id" : 591141012136992768,
    "created_at" : "2015-04-23 07:41:18 +0000",
    "in_reply_to_screen_name" : "OwenJones84",
    "in_reply_to_user_id_str" : "65045121",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 591166358538289152,
  "created_at" : "2015-04-23 09:06:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/nQRa1DwS6V",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/WmEh4wdTKXq",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "591163550380457984",
  "geo" : { },
  "id_str" : "591164557894234112",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco here you go https:\/\/t.co\/nQRa1DwS6V",
  "id" : 591164557894234112,
  "in_reply_to_status_id" : 591163550380457984,
  "created_at" : "2015-04-23 08:59:48 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591160052964265985",
  "geo" : { },
  "id_str" : "591162597992456192",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thx, have u read the Alex Boulton interview?",
  "id" : 591162597992456192,
  "in_reply_to_status_id" : 591160052964265985,
  "created_at" : "2015-04-23 08:52:01 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591159807337439232",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thx for RT :)",
  "id" : 591159807337439232,
  "created_at" : "2015-04-23 08:40:55 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/591106621046185984\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/oZVchpjj3W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDQIVtqWAAAN8mu.jpg",
      "id_str" : "591106620219850752",
      "id" : 591106620219850752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDQIVtqWAAAN8mu.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 621
      } ],
      "display_url" : "pic.twitter.com\/oZVchpjj3W"
    } ],
    "hashtags" : [ {
      "text" : "TAWSIG",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "ELT",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "ESL",
      "indices" : [ 66, 70 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ZNczQ2am4s",
      "expanded_url" : "https:\/\/tinyletter.com\/TeachersasWorkers",
      "display_url" : "tinyletter.com\/TeachersasWork\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591125503882481664",
  "text" : "RT @taw_sig: Join #TAWSIG to discuss working conditions in #ELT \/ #ESL https:\/\/t.co\/ZNczQ2am4s #eltchat #eltchinwag http:\/\/t.co\/oZVchpjj3W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/591106621046185984\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/oZVchpjj3W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDQIVtqWAAAN8mu.jpg",
        "id_str" : "591106620219850752",
        "id" : 591106620219850752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDQIVtqWAAAN8mu.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 621
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 621
        } ],
        "display_url" : "pic.twitter.com\/oZVchpjj3W"
      } ],
      "hashtags" : [ {
        "text" : "TAWSIG",
        "indices" : [ 5, 12 ]
      }, {
        "text" : "ELT",
        "indices" : [ 46, 50 ]
      }, {
        "text" : "ESL",
        "indices" : [ 53, 57 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "eltchinwag",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/ZNczQ2am4s",
        "expanded_url" : "https:\/\/tinyletter.com\/TeachersasWorkers",
        "display_url" : "tinyletter.com\/TeachersasWork\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591106621046185984",
    "text" : "Join #TAWSIG to discuss working conditions in #ELT \/ #ESL https:\/\/t.co\/ZNczQ2am4s #eltchat #eltchinwag http:\/\/t.co\/oZVchpjj3W",
    "id" : 591106621046185984,
    "created_at" : "2015-04-23 05:09:35 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 591125503882481664,
  "created_at" : "2015-04-23 06:24:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/8ylfh8B7E9",
      "expanded_url" : "http:\/\/htl.linguist.univ-paris-diderot.fr\/leon\/leon_hs.pdf",
      "display_url" : "htl.linguist.univ-paris-diderot.fr\/leon\/leon_hs.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590899600585658368",
  "geo" : { },
  "id_str" : "590997052785618945",
  "in_reply_to_user_id" : 1479290418,
  "text" : "@usage_based it is interesting that Leech's criticisms of Chomsky as anti-corpus may not have been well founded - http:\/\/t.co\/8ylfh8B7E9",
  "id" : 590997052785618945,
  "in_reply_to_status_id" : 590899600585658368,
  "created_at" : "2015-04-22 21:54:12 +0000",
  "in_reply_to_screen_name" : "usage_based",
  "in_reply_to_user_id_str" : "1479290418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590984222967488512",
  "text" : "#eltchat thanks all",
  "id" : 590984222967488512,
  "created_at" : "2015-04-22 21:03:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590981895296548865",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock thx for RT :)",
  "id" : 590981895296548865,
  "created_at" : "2015-04-22 20:53:58 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590979780125794305",
  "geo" : { },
  "id_str" : "590980362194530304",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames sts taking handwrittten notes won't go away as much as tchrs giving photocopied handouts #eltchat",
  "id" : 590980362194530304,
  "in_reply_to_status_id" : 590979780125794305,
  "created_at" : "2015-04-22 20:47:52 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 3, 16 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/5gbqB4crvz",
      "expanded_url" : "http:\/\/www.mikejharrison.com\/2010\/11\/wanderous-whiteboard-challenge-with-entry-one\/",
      "display_url" : "mikejharrison.com\/2010\/11\/wander\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590979926901293056",
  "text" : "RT @harrisonmike: How about starting by getting your students to write whatever on the board  http:\/\/t.co\/5gbqB4crvz no instructions other \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/5gbqB4crvz",
        "expanded_url" : "http:\/\/www.mikejharrison.com\/2010\/11\/wanderous-whiteboard-challenge-with-entry-one\/",
        "display_url" : "mikejharrison.com\/2010\/11\/wander\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590977920186896385",
    "text" : "How about starting by getting your students to write whatever on the board  http:\/\/t.co\/5gbqB4crvz no instructions other than write #ELTchat",
    "id" : 590977920186896385,
    "created_at" : "2015-04-22 20:38:10 +0000",
    "user" : {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "protected" : false,
      "id_str" : "1685397408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697937835127672832\/Z5BuTNo2_normal.jpg",
      "id" : 1685397408,
      "verified" : false
    }
  },
  "id" : 590979926901293056,
  "created_at" : "2015-04-22 20:46:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Phang",
      "screen_name" : "juliacphang",
      "indices" : [ 0, 12 ],
      "id_str" : "3169618481",
      "id" : 3169618481
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 13, 22 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590976719605075970",
  "geo" : { },
  "id_str" : "590977246531321856",
  "in_reply_to_user_id" : 3169618481,
  "text" : "@juliacphang @Marisa_C lol when i 1st started in France sts used to tut tut for not using two sides of paper for photocopies :0 #eltchat",
  "id" : 590977246531321856,
  "in_reply_to_status_id" : 590976719605075970,
  "created_at" : "2015-04-22 20:35:30 +0000",
  "in_reply_to_screen_name" : "juliacphang",
  "in_reply_to_user_id_str" : "3169618481",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590975149236686849",
  "geo" : { },
  "id_str" : "590976788450381824",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C though admittedly only once so far with adults :) #eltchat",
  "id" : 590976788450381824,
  "in_reply_to_status_id" : 590975149236686849,
  "created_at" : "2015-04-22 20:33:40 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590974488256339968",
  "geo" : { },
  "id_str" : "590974774714757120",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C yes worked well #eltchat",
  "id" : 590974774714757120,
  "in_reply_to_status_id" : 590974488256339968,
  "created_at" : "2015-04-22 20:25:40 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESL Library",
      "screen_name" : "ESLlibrary",
      "indices" : [ 0, 11 ],
      "id_str" : "32568971",
      "id" : 32568971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/zVs3BgYKd4",
      "expanded_url" : "https:\/\/eflnotes.files.wordpress.com\/2014\/11\/tesolfrance_2014_poster-compressed.pdf",
      "display_url" : "eflnotes.files.wordpress.com\/2014\/11\/tesolf\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590973321698799616",
  "geo" : { },
  "id_str" : "590974139315396609",
  "in_reply_to_user_id" : 32568971,
  "text" : "@ESLlibrary it's a way to share files https:\/\/t.co\/zVs3BgYKd4 #eltchat",
  "id" : 590974139315396609,
  "in_reply_to_status_id" : 590973321698799616,
  "created_at" : "2015-04-22 20:23:09 +0000",
  "in_reply_to_screen_name" : "ESLlibrary",
  "in_reply_to_user_id_str" : "32568971",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "piratebox",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590973018958143490",
  "text" : "#eltchat have cut down on photocopying by dictating  &amp; using #piratebox",
  "id" : 590973018958143490,
  "created_at" : "2015-04-22 20:18:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 19, 37 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/nQRa1DwS6V",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/WmEh4wdTKXq",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590970465381941248",
  "text" : "Alex Boulton talks #corpuslinguistics &amp; DDL https:\/\/t.co\/nQRa1DwS6V #corpusmooc",
  "id" : 590970465381941248,
  "created_at" : "2015-04-22 20:08:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 45, 60 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/6N4rmoFAAB",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1fN",
      "display_url" : "wp.me\/p3qkCB-1fN"
    } ]
  },
  "geo" : { },
  "id_str" : "590958982094807040",
  "text" : "Radical Happiness http:\/\/t.co\/6N4rmoFAAB via @GeoffreyJordan",
  "id" : 590958982094807040,
  "created_at" : "2015-04-22 19:22:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590923199770189824",
  "geo" : { },
  "id_str" : "590928561839669248",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle windows users have some options for command line practice e.g. cygwin, levinux",
  "id" : 590928561839669248,
  "in_reply_to_status_id" : 590923199770189824,
  "created_at" : "2015-04-22 17:22:02 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 129, 136 ]
    }, {
      "text" : "python",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "nlp",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/x5aH5AnIqI",
      "expanded_url" : "http:\/\/www.mikesboyle.com\/post\/117052642714\/learning-python-nltk-command-line-setup",
      "display_url" : "mikesboyle.com\/post\/117052642\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590925936901672960",
  "text" : "RT @heyboyle: Learn Python text analysis with me! Easy guide to set up Python NLTK on the command line: http:\/\/t.co\/x5aH5AnIqI \u2026 #corpus #p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 115, 122 ]
      }, {
        "text" : "python",
        "indices" : [ 123, 130 ]
      }, {
        "text" : "nlp",
        "indices" : [ 131, 135 ]
      }, {
        "text" : "elt",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/x5aH5AnIqI",
        "expanded_url" : "http:\/\/www.mikesboyle.com\/post\/117052642714\/learning-python-nltk-command-line-setup",
        "display_url" : "mikesboyle.com\/post\/117052642\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590923199770189824",
    "text" : "Learn Python text analysis with me! Easy guide to set up Python NLTK on the command line: http:\/\/t.co\/x5aH5AnIqI \u2026 #corpus #python #nlp #elt",
    "id" : 590923199770189824,
    "created_at" : "2015-04-22 17:00:44 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 590925936901672960,
  "created_at" : "2015-04-22 17:11:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/4u2CVR1fh4",
      "expanded_url" : "http:\/\/wp.me\/p3aC93-e1",
      "display_url" : "wp.me\/p3aC93-e1"
    } ]
  },
  "geo" : { },
  "id_str" : "590830157688111104",
  "text" : "Why tactical voting is a terrible idea http:\/\/t.co\/4u2CVR1fh4 via @wordpressdotcom",
  "id" : 590830157688111104,
  "created_at" : "2015-04-22 10:51:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590647205754699776",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson thx for RT :)",
  "id" : 590647205754699776,
  "created_at" : "2015-04-21 22:44:02 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELECTION2015",
      "indices" : [ 11, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/bAssl6FuwF",
      "expanded_url" : "http:\/\/ukmanifestos.englishup.me",
      "display_url" : "ukmanifestos.englishup.me"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Uk5E735BVj",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/efvz6G9iA6A",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590640877246226432",
  "text" : "explore UK #ELECTION2015 manifestos http:\/\/t.co\/bAssl6FuwF see any diffs\/similarities? tweet me back i :) xtra info https:\/\/t.co\/Uk5E735BVj",
  "id" : 590640877246226432,
  "created_at" : "2015-04-21 22:18:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Albutt",
      "screen_name" : "davealbutt",
      "indices" : [ 0, 11 ],
      "id_str" : "2872285019",
      "id" : 2872285019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590636149246406657",
  "in_reply_to_user_id" : 2872285019,
  "text" : "@davealbutt hi thanks for RT :)",
  "id" : 590636149246406657,
  "created_at" : "2015-04-21 22:00:06 +0000",
  "in_reply_to_screen_name" : "davealbutt",
  "in_reply_to_user_id_str" : "2872285019",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 0, 8 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590608303195103232",
  "in_reply_to_user_id" : 783214,
  "text" : "@twitter latest mobile update has lost my lists?",
  "id" : 590608303195103232,
  "created_at" : "2015-04-21 20:09:27 +0000",
  "in_reply_to_screen_name" : "twitter",
  "in_reply_to_user_id_str" : "783214",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590596663766556672",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja thx for RT :)",
  "id" : 590596663766556672,
  "created_at" : "2015-04-21 19:23:12 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Farrell",
      "screen_name" : "ChrisPatrickF",
      "indices" : [ 0, 14 ],
      "id_str" : "3165431237",
      "id" : 3165431237
    }, {
      "name" : "Tom Flaherty",
      "screen_name" : "tom_flaherty",
      "indices" : [ 15, 28 ],
      "id_str" : "20362849",
      "id" : 20362849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590565141311315968",
  "in_reply_to_user_id" : 3165431237,
  "text" : "@ChrisPatrickF @tom_flaherty thanks a lot for RT :)",
  "id" : 590565141311315968,
  "created_at" : "2015-04-21 17:17:56 +0000",
  "in_reply_to_screen_name" : "ChrisPatrickF",
  "in_reply_to_user_id_str" : "3165431237",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare  Lavery",
      "screen_name" : "clerotto",
      "indices" : [ 0, 9 ],
      "id_str" : "1445778456",
      "id" : 1445778456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590564899539046400",
  "in_reply_to_user_id" : 1445778456,
  "text" : "@clerotto thx for sharing post :)",
  "id" : 590564899539046400,
  "created_at" : "2015-04-21 17:16:58 +0000",
  "in_reply_to_screen_name" : "clerotto",
  "in_reply_to_user_id_str" : "1445778456",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590442214104428544",
  "geo" : { },
  "id_str" : "590447426915454976",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen thanks :)",
  "id" : 590447426915454976,
  "in_reply_to_status_id" : 590442214104428544,
  "created_at" : "2015-04-21 09:30:11 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/oqTHHILujW",
      "expanded_url" : "https:\/\/youtu.be\/884RCxG61K4",
      "display_url" : "youtu.be\/884RCxG61K4"
    } ]
  },
  "geo" : { },
  "id_str" : "590447350298083328",
  "text" : "Katie Hopkins Gets Her Dead Immigrants - Happy Now? Russell Brand The Tr... https:\/\/t.co\/oqTHHILujW via @YouTube",
  "id" : 590447350298083328,
  "created_at" : "2015-04-21 09:29:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/wek4EiP3Dp",
      "expanded_url" : "http:\/\/gu.com\/p\/47kjc\/stw",
      "display_url" : "gu.com\/p\/47kjc\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "590440113991245824",
  "text" : "Britain\u2019s criminally stupid attitudes to race and immigration are beyond parody | Frankie Boyle http:\/\/t.co\/wek4EiP3Dp",
  "id" : 590440113991245824,
  "created_at" : "2015-04-21 09:01:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 0, 11 ],
      "id_str" : "10052752",
      "id" : 10052752
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 12, 28 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590438761420361728",
  "geo" : { },
  "id_str" : "590438881213972481",
  "in_reply_to_user_id" : 10052752,
  "text" : "@daylemajor @MichaelChesnut2 i mean a lot of the links on that page",
  "id" : 590438881213972481,
  "in_reply_to_status_id" : 590438761420361728,
  "created_at" : "2015-04-21 08:56:13 +0000",
  "in_reply_to_screen_name" : "daylemajor",
  "in_reply_to_user_id_str" : "10052752",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590437535488331776",
  "geo" : { },
  "id_str" : "590438091564916736",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz no worries my writing need to be clearer!",
  "id" : 590438091564916736,
  "in_reply_to_status_id" : 590437535488331776,
  "created_at" : "2015-04-21 08:53:05 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 0, 11 ],
      "id_str" : "10052752",
      "id" : 10052752
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 12, 28 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590437140347035648",
  "geo" : { },
  "id_str" : "590437560679272450",
  "in_reply_to_user_id" : 10052752,
  "text" : "@daylemajor @MichaelChesnut2 that page is 404, broken link land :\/",
  "id" : 590437560679272450,
  "in_reply_to_status_id" : 590437140347035648,
  "created_at" : "2015-04-21 08:50:58 +0000",
  "in_reply_to_screen_name" : "daylemajor",
  "in_reply_to_user_id_str" : "10052752",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 11, 19 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/52aMyrNw5l",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2015\/session\/uncertain-and-approximate-business-why-teachers-should-love-testing",
      "display_url" : "iatefl.britishcouncil.org\/2015\/session\/u\u2026"
    }, {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/dsztO4ZP1p",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2015\/session\/pearson-signature-event",
      "display_url" : "iatefl.britishcouncil.org\/2015\/session\/p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590334322428620800",
  "geo" : { },
  "id_str" : "590432077042098176",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @seburnt hi these 2 - https:\/\/t.co\/52aMyrNw5l, https:\/\/t.co\/dsztO4ZP1p",
  "id" : 590432077042098176,
  "in_reply_to_status_id" : 590334322428620800,
  "created_at" : "2015-04-21 08:29:11 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590343540623806465",
  "geo" : { },
  "id_str" : "590431749320114176",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish cheers :)",
  "id" : 590431749320114176,
  "in_reply_to_status_id" : 590343540623806465,
  "created_at" : "2015-04-21 08:27:53 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590383816813871104",
  "geo" : { },
  "id_str" : "590431685147238400",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson thanks for sharing hope the vid made u chuckle :)",
  "id" : 590431685147238400,
  "in_reply_to_status_id" : 590383816813871104,
  "created_at" : "2015-04-21 08:27:38 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 17, 28 ],
      "id_str" : "10052752",
      "id" : 10052752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590386598274969600",
  "geo" : { },
  "id_str" : "590431561427849217",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 @daylemajor thanks for sharing big question now is how long those tools will be around for!",
  "id" : 590431561427849217,
  "in_reply_to_status_id" : 590386598274969600,
  "created_at" : "2015-04-21 08:27:08 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590412653031346176",
  "geo" : { },
  "id_str" : "590431308033216512",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi those tools were not featured at #iatefl used the corpus talk as springboard for post, thx for sharing :)",
  "id" : 590431308033216512,
  "in_reply_to_status_id" : 590412653031346176,
  "created_at" : "2015-04-21 08:26:08 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590317027543359488",
  "geo" : { },
  "id_str" : "590317550908616704",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt do :)",
  "id" : 590317550908616704,
  "in_reply_to_status_id" : 590317027543359488,
  "created_at" : "2015-04-21 00:54:06 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590314768034111489",
  "geo" : { },
  "id_str" : "590315807814586368",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt have you seen the two #iatefl  presentations related to Pearson &amp; \"softride\" they had in crucial area like testing?",
  "id" : 590315807814586368,
  "in_reply_to_status_id" : 590314768034111489,
  "created_at" : "2015-04-21 00:47:10 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590312375447908352",
  "geo" : { },
  "id_str" : "590312587587354624",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin nice to hear thx :)",
  "id" : 590312587587354624,
  "in_reply_to_status_id" : 590312375447908352,
  "created_at" : "2015-04-21 00:34:23 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 3, 14 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "EAPChat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/QVaY7nQYMB",
      "expanded_url" : "https:\/\/jenmacdonald.wordpress.com\/2015\/04\/20\/getting-into-academic-corpora\/",
      "display_url" : "jenmacdonald.wordpress.com\/2015\/04\/20\/get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590308479753134080",
  "text" : "RT @JenMac_ESL: Just blogged: Getting into Academic Corpora. https:\/\/t.co\/QVaY7nQYMB #tleap #EAPChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tleap",
        "indices" : [ 69, 75 ]
      }, {
        "text" : "EAPChat",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/QVaY7nQYMB",
        "expanded_url" : "https:\/\/jenmacdonald.wordpress.com\/2015\/04\/20\/getting-into-academic-corpora\/",
        "display_url" : "jenmacdonald.wordpress.com\/2015\/04\/20\/get\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590308311523721217",
    "text" : "Just blogged: Getting into Academic Corpora. https:\/\/t.co\/QVaY7nQYMB #tleap #EAPChat",
    "id" : 590308311523721217,
    "created_at" : "2015-04-21 00:17:23 +0000",
    "user" : {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "protected" : false,
      "id_str" : "608800026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450682476781129728\/SBKeLuvN_normal.jpeg",
      "id" : 608800026,
      "verified" : false
    }
  },
  "id" : 590308479753134080,
  "created_at" : "2015-04-21 00:18:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590304476289966080",
  "geo" : { },
  "id_str" : "590305586635534336",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt if one sponsor\/guest is upset how long before other sponsors\/guests get to hear of it?",
  "id" : 590305586635534336,
  "in_reply_to_status_id" : 590304476289966080,
  "created_at" : "2015-04-21 00:06:33 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590291637743570944",
  "geo" : { },
  "id_str" : "590301319531012096",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt though the truth in the saying don't bite the hand that feeds can't be discounted in such discussions",
  "id" : 590301319531012096,
  "in_reply_to_status_id" : 590291637743570944,
  "created_at" : "2015-04-20 23:49:36 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590255817191993344",
  "geo" : { },
  "id_str" : "590257384381161472",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava another doozer \"'The Snowden Files is a walloping fraud, written by frauds to be praised by frauds\"",
  "id" : 590257384381161472,
  "in_reply_to_status_id" : 590255817191993344,
  "created_at" : "2015-04-20 20:55:01 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590254692631994369",
  "geo" : { },
  "id_str" : "590255817191993344",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava oof Assange does not mince words \"We are left with a \"Bullshitter's Guide\" to the world of the world's most wanted man.\"",
  "id" : 590255817191993344,
  "in_reply_to_status_id" : 590254692631994369,
  "created_at" : "2015-04-20 20:48:47 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/PNAmgNUfoj",
      "expanded_url" : "http:\/\/www.newsweek.com\/assange-how-guardian-milked-edward-snowdens-story-323480",
      "display_url" : "newsweek.com\/assange-how-gu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590254692631994369",
  "text" : "Assange: How 'The Guardian' Milked Edward Snowden's Story http:\/\/t.co\/PNAmgNUfoj",
  "id" : 590254692631994369,
  "created_at" : "2015-04-20 20:44:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JackieGerstein Ed.D.",
      "screen_name" : "jackiegerstein",
      "indices" : [ 0, 15 ],
      "id_str" : "16005270",
      "id" : 16005270
    }, {
      "name" : "Susie CowleyHaselden",
      "screen_name" : "SusieCowley",
      "indices" : [ 16, 28 ],
      "id_str" : "613540409",
      "id" : 613540409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ajstream",
      "indices" : [ 125, 134 ]
    }, {
      "text" : "sole",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590244854787022848",
  "geo" : { },
  "id_str" : "590252173461745664",
  "in_reply_to_user_id" : 16005270,
  "text" : "@jackiegerstein @SusieCowley many teachers wouldn't recognise this statement considering the many ed reforms over many years #ajstream #sole",
  "id" : 590252173461745664,
  "in_reply_to_status_id" : 590244854787022848,
  "created_at" : "2015-04-20 20:34:19 +0000",
  "in_reply_to_screen_name" : "jackiegerstein",
  "in_reply_to_user_id_str" : "16005270",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m_paradowski",
      "screen_name" : "m_paradowski",
      "indices" : [ 0, 13 ],
      "id_str" : "15028542",
      "id" : 15028542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AJStream",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "sole",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590247808336265216",
  "in_reply_to_user_id" : 15028542,
  "text" : "@m_paradowski liked yr video comment, amazing goalposts moving  response by Mitra :\/ #AJStream #sole",
  "id" : 590247808336265216,
  "created_at" : "2015-04-20 20:16:58 +0000",
  "in_reply_to_screen_name" : "m_paradowski",
  "in_reply_to_user_id_str" : "15028542",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AJStream",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "sole",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590245607421452288",
  "text" : "#AJStream #sole how does one understand a google search? knowledge builds on knowledge",
  "id" : 590245607421452288,
  "created_at" : "2015-04-20 20:08:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m_paradowski",
      "screen_name" : "m_paradowski",
      "indices" : [ 3, 16 ],
      "id_str" : "15028542",
      "id" : 15028542
    }, {
      "name" : "The Stream",
      "screen_name" : "AJStream",
      "indices" : [ 18, 27 ],
      "id_str" : "236891946",
      "id" : 236891946
    }, {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 34, 42 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sole",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "AJStream",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fChmvgibN5",
      "expanded_url" : "https:\/\/www.academia.edu\/7475327\/Classrooms_in_the_cloud_or_castles_in_the_air",
      "display_url" : "academia.edu\/7475327\/Classr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590243396083650560",
  "text" : "RT @m_paradowski: @AJStream #sole @Sugatam the pros and cons of EdTech considered https:\/\/t.co\/fChmvgibN5 #AJStream",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Stream",
        "screen_name" : "AJStream",
        "indices" : [ 0, 9 ],
        "id_str" : "236891946",
        "id" : 236891946
      }, {
        "name" : "Sugata Mitra",
        "screen_name" : "Sugatam",
        "indices" : [ 16, 24 ],
        "id_str" : "9242922",
        "id" : 9242922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sole",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "AJStream",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/fChmvgibN5",
        "expanded_url" : "https:\/\/www.academia.edu\/7475327\/Classrooms_in_the_cloud_or_castles_in_the_air",
        "display_url" : "academia.edu\/7475327\/Classr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590242676244611073",
    "in_reply_to_user_id" : 236891946,
    "text" : "@AJStream #sole @Sugatam the pros and cons of EdTech considered https:\/\/t.co\/fChmvgibN5 #AJStream",
    "id" : 590242676244611073,
    "created_at" : "2015-04-20 19:56:34 +0000",
    "in_reply_to_screen_name" : "AJStream",
    "in_reply_to_user_id_str" : "236891946",
    "user" : {
      "name" : "m_paradowski",
      "screen_name" : "m_paradowski",
      "protected" : false,
      "id_str" : "15028542",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 15028542,
      "verified" : false
    }
  },
  "id" : 590243396083650560,
  "created_at" : "2015-04-20 19:59:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AJStream",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "sole",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/WoN9Boc9km",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/02\/20\/some-obvious-notes-on-mitra-and-crawley-2014\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/02\/20\/som\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590243338839846912",
  "text" : "#AJStream #sole Some obvious notes on Mitra and Crawley (2014) https:\/\/t.co\/WoN9Boc9km",
  "id" : 590243338839846912,
  "created_at" : "2015-04-20 19:59:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AJStream",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "sole",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590241845772476416",
  "text" : "#AJStream #sole how is this \"new\" approach different from say Rousseau's Emile?",
  "id" : 590241845772476416,
  "created_at" : "2015-04-20 19:53:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AJStream",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "sole",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590239548774440961",
  "text" : "#AJStream #sole lack of teachers is a social political problem, tech fixes are temporary and doesn't address underlying issues",
  "id" : 590239548774440961,
  "created_at" : "2015-04-20 19:44:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AJStream",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "sole",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590238555017977856",
  "text" : "#AJStream #sole seems to be confusing problems with education in general and Mitra's approach",
  "id" : 590238555017977856,
  "created_at" : "2015-04-20 19:40:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 3, 13 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590232375084318721",
  "text" : "RT @_ctaylor_: (3) no. of times people were named wrt their role on the ship:\nCosta concordia: 25% (passengers)\nYday's disaster: 0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590151206640738304",
    "text" : "(3) no. of times people were named wrt their role on the ship:\nCosta concordia: 25% (passengers)\nYday's disaster: 0",
    "id" : 590151206640738304,
    "created_at" : "2015-04-20 13:53:06 +0000",
    "user" : {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "protected" : false,
      "id_str" : "1428024560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747118162383085568\/dvYEKKWl_normal.jpg",
      "id" : 1428024560,
      "verified" : false
    }
  },
  "id" : 590232375084318721,
  "created_at" : "2015-04-20 19:15:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 3, 13 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "naming",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590232033059807233",
  "text" : "RT @_ctaylor_: (1) A bit of number crunching re #naming: comparing 2 day's headlines from UK newspapers on Costa Concordia boat disaster in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "naming",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590150827735650305",
    "text" : "(1) A bit of number crunching re #naming: comparing 2 day's headlines from UK newspapers on Costa Concordia boat disaster in Med, and yday's",
    "id" : 590150827735650305,
    "created_at" : "2015-04-20 13:51:36 +0000",
    "user" : {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "protected" : false,
      "id_str" : "1428024560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747118162383085568\/dvYEKKWl_normal.jpg",
      "id" : 1428024560,
      "verified" : false
    }
  },
  "id" : 590232033059807233,
  "created_at" : "2015-04-20 19:14:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "David John Bradshaw",
      "screen_name" : "djb667",
      "indices" : [ 12, 19 ],
      "id_str" : "35684587",
      "id" : 35684587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590224241196408832",
  "geo" : { },
  "id_str" : "590228626433515521",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta @djb667 thanks for sharing and RTing :)",
  "id" : 590228626433515521,
  "in_reply_to_status_id" : 590224241196408832,
  "created_at" : "2015-04-20 19:00:45 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590223395561803776",
  "geo" : { },
  "id_str" : "590228470334119936",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 appreciate  v much the share :)",
  "id" : 590228470334119936,
  "in_reply_to_status_id" : 590223395561803776,
  "created_at" : "2015-04-20 19:00:07 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590202448016449537",
  "geo" : { },
  "id_str" : "590221725155008512",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson it's alright google gave some pointers thx",
  "id" : 590221725155008512,
  "in_reply_to_status_id" : 590202448016449537,
  "created_at" : "2015-04-20 18:33:19 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m_paradowski",
      "screen_name" : "m_paradowski",
      "indices" : [ 0, 13 ],
      "id_str" : "15028542",
      "id" : 15028542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590167173169082368",
  "geo" : { },
  "id_str" : "590219908824354817",
  "in_reply_to_user_id" : 15028542,
  "text" : "@m_paradowski cool is there a link for stream?",
  "id" : 590219908824354817,
  "in_reply_to_status_id" : 590167173169082368,
  "created_at" : "2015-04-20 18:26:06 +0000",
  "in_reply_to_screen_name" : "m_paradowski",
  "in_reply_to_user_id_str" : "15028542",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590219336813400064",
  "geo" : { },
  "id_str" : "590219582142570496",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim great :) &amp; thanks for sharing",
  "id" : 590219582142570496,
  "in_reply_to_status_id" : 590219336813400064,
  "created_at" : "2015-04-20 18:24:48 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590219319897886720",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin cheers for sharing Mike :)",
  "id" : 590219319897886720,
  "created_at" : "2015-04-20 18:23:46 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590166647673073664",
  "geo" : { },
  "id_str" : "590219223340843009",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL thanks Jennifer :)",
  "id" : 590219223340843009,
  "in_reply_to_status_id" : 590166647673073664,
  "created_at" : "2015-04-20 18:23:23 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590163351738658816",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir thanks for RT :)",
  "id" : 590163351738658816,
  "created_at" : "2015-04-20 14:41:22 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 75, 91 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/skowVjpVp7",
      "expanded_url" : "http:\/\/wp.me\/p3augf-gW",
      "display_url" : "wp.me\/p3augf-gW"
    } ]
  },
  "geo" : { },
  "id_str" : "590163141482414080",
  "text" : "WrELFA 2015: the written corpus of academic ELF http:\/\/t.co\/skowVjpVp7 via @wordpressdotcom",
  "id" : 590163141482414080,
  "created_at" : "2015-04-20 14:40:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeremy scahill",
      "screen_name" : "jeremyscahill",
      "indices" : [ 80, 94 ],
      "id_str" : "23839835",
      "id" : 23839835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/g7vcNbTSRK",
      "expanded_url" : "http:\/\/interc.pt\/1E9T7TH",
      "display_url" : "interc.pt\/1E9T7TH"
    } ]
  },
  "geo" : { },
  "id_str" : "590144535524671488",
  "text" : "Germany is the Tell-Tale Heart of America\u2019s Drone War http:\/\/t.co\/g7vcNbTSRK by @jeremyscahill",
  "id" : 590144535524671488,
  "created_at" : "2015-04-20 13:26:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Fii5imESoz",
      "expanded_url" : "http:\/\/parles.upf.edu\/llocs\/moodle\/login\/index.php",
      "display_url" : "parles.upf.edu\/llocs\/moodle\/l\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590137537378803712",
  "geo" : { },
  "id_str" : "590143622777069569",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock thx for RT, have u seen this moodle for corpora and translators (can use as guest) - http:\/\/t.co\/Fii5imESoz",
  "id" : 590143622777069569,
  "in_reply_to_status_id" : 590137537378803712,
  "created_at" : "2015-04-20 13:22:58 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590133545848479746",
  "geo" : { },
  "id_str" : "590135033354199040",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock avec plaisir :)",
  "id" : 590135033354199040,
  "in_reply_to_status_id" : 590133545848479746,
  "created_at" : "2015-04-20 12:48:50 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 3, 11 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/bWE3zMUzom",
      "expanded_url" : "http:\/\/eltjam.com\/app-design-green-owls-and-pots-of-gold\/",
      "display_url" : "eltjam.com\/app-design-gre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590133171250921473",
  "text" : "RT @Ven_VVE: App Design: Green Owls and Pots of Gold http:\/\/t.co\/bWE3zMUzom &gt; fav line: \"it can be a lonely online world when you're lookin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/bWE3zMUzom",
        "expanded_url" : "http:\/\/eltjam.com\/app-design-green-owls-and-pots-of-gold\/",
        "display_url" : "eltjam.com\/app-design-gre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590130989118201857",
    "text" : "App Design: Green Owls and Pots of Gold http:\/\/t.co\/bWE3zMUzom &gt; fav line: \"it can be a lonely online world when you're looking for fdbk\"",
    "id" : 590130989118201857,
    "created_at" : "2015-04-20 12:32:46 +0000",
    "user" : {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "protected" : false,
      "id_str" : "270839603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551061595602681856\/KylACR1R_normal.jpeg",
      "id" : 270839603,
      "verified" : false
    }
  },
  "id" : 590133171250921473,
  "created_at" : "2015-04-20 12:41:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EGManagement Consult",
      "screen_name" : "EGMConsultant",
      "indices" : [ 0, 14 ],
      "id_str" : "2309771683",
      "id" : 2309771683
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 15, 27 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590132706178117632",
  "in_reply_to_user_id" : 2309771683,
  "text" : "@EGMConsultant @AnneHendler many thanks for RT :)",
  "id" : 590132706178117632,
  "created_at" : "2015-04-20 12:39:35 +0000",
  "in_reply_to_screen_name" : "EGMConsultant",
  "in_reply_to_user_id_str" : "2309771683",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/wlY42q5nl5",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/12\/16\/2nd-elt-research-blog-carnival-learner-autonomy-online-data-driven-dictionaries\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/12\/16\/2nd\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GgZItp6zHb",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/?s=cobra",
      "display_url" : "eflnotes.wordpress.com\/?s=cobra"
    } ]
  },
  "in_reply_to_status_id_str" : "590131292798377984",
  "geo" : { },
  "id_str" : "590132499487023104",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock salut :) u may find the following of interest re linguee - https:\/\/t.co\/wlY42q5nl5 et cobra - https:\/\/t.co\/GgZItp6zHb",
  "id" : 590132499487023104,
  "in_reply_to_status_id" : 590131292798377984,
  "created_at" : "2015-04-20 12:38:46 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Haile",
      "screen_name" : "shikorina78",
      "indices" : [ 0, 12 ],
      "id_str" : "246031350",
      "id" : 246031350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590115875442860032",
  "geo" : { },
  "id_str" : "590117497375973376",
  "in_reply_to_user_id" : 246031350,
  "text" : "@shikorina78 thks for RT, i do wonder how long some of them will be available for though :\/",
  "id" : 590117497375973376,
  "in_reply_to_status_id" : 590115875442860032,
  "created_at" : "2015-04-20 11:39:09 +0000",
  "in_reply_to_screen_name" : "shikorina78",
  "in_reply_to_user_id_str" : "246031350",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "auselt",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/xBCUdc7Dgl",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-VV",
      "display_url" : "wp.me\/pgHyE-VV"
    } ]
  },
  "geo" : { },
  "id_str" : "590114997759385601",
  "text" : "#IATEFL 2015: Recent corpus tools for your students http:\/\/t.co\/xBCUdc7Dgl #eltchat #eltchinwag #keltchat #auselt",
  "id" : 590114997759385601,
  "created_at" : "2015-04-20 11:29:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590089256602902528",
  "geo" : { },
  "id_str" : "590093861768327169",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja hahaha :)",
  "id" : 590093861768327169,
  "in_reply_to_status_id" : 590089256602902528,
  "created_at" : "2015-04-20 10:05:14 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 3, 13 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "Adobe",
      "indices" : [ 51, 57 ]
    }, {
      "text" : "esl",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "ELT",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "edtech",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/41y2epvXmh",
      "expanded_url" : "http:\/\/youtu.be\/znQhVMZWkdQ",
      "display_url" : "youtu.be\/znQhVMZWkdQ"
    } ]
  },
  "geo" : { },
  "id_str" : "590093782156189697",
  "text" : "RT @TEFLninja: #IATEFL SIGs As LOL Cats\n\nMade with #Adobe Voice \n\nhttp:\/\/t.co\/41y2epvXmh\n\n#esl #ELT #edtech #TEFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Adobe",
        "indices" : [ 36, 42 ]
      }, {
        "text" : "esl",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "ELT",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "edtech",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/41y2epvXmh",
        "expanded_url" : "http:\/\/youtu.be\/znQhVMZWkdQ",
        "display_url" : "youtu.be\/znQhVMZWkdQ"
      } ]
    },
    "geo" : { },
    "id_str" : "590089256602902528",
    "text" : "#IATEFL SIGs As LOL Cats\n\nMade with #Adobe Voice \n\nhttp:\/\/t.co\/41y2epvXmh\n\n#esl #ELT #edtech #TEFL",
    "id" : 590089256602902528,
    "created_at" : "2015-04-20 09:46:56 +0000",
    "user" : {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "protected" : false,
      "id_str" : "3131267981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583575211745894400\/TmUR03jo_normal.jpg",
      "id" : 3131267981,
      "verified" : false
    }
  },
  "id" : 590093782156189697,
  "created_at" : "2015-04-20 10:04:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted O'Neill (DB-\u7ADC\u725B)",
      "screen_name" : "gotanda",
      "indices" : [ 0, 8 ],
      "id_str" : "9875912",
      "id" : 9875912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590091021490343936",
  "geo" : { },
  "id_str" : "590092405489201152",
  "in_reply_to_user_id" : 9875912,
  "text" : "@gotanda an English teacher? :)",
  "id" : 590092405489201152,
  "in_reply_to_status_id" : 590091021490343936,
  "created_at" : "2015-04-20 09:59:27 +0000",
  "in_reply_to_screen_name" : "gotanda",
  "in_reply_to_user_id_str" : "9875912",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 44, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/PjgDbeHysz",
      "expanded_url" : "http:\/\/mwetoolkit.sourceforge.net\/PHITE.php",
      "display_url" : "mwetoolkit.sourceforge.net\/PHITE.php"
    } ]
  },
  "geo" : { },
  "id_str" : "590078501987995648",
  "text" : "another multi-word expression tagger on the #corpuslinguistics scene http:\/\/t.co\/PjgDbeHysz nice :) h\/t corporalist",
  "id" : 590078501987995648,
  "created_at" : "2015-04-20 09:04:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590070441722642432",
  "geo" : { },
  "id_str" : "590071161519742976",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter yr welcome, u could also check\/join G+ CL community to get such resources https:\/\/t.co\/gnEFqIeLpA",
  "id" : 590071161519742976,
  "in_reply_to_status_id" : 590070441722642432,
  "created_at" : "2015-04-20 08:35:02 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590056732870758400",
  "geo" : { },
  "id_str" : "590070432964988928",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thx for hat tip :)",
  "id" : 590070432964988928,
  "in_reply_to_status_id" : 590056732870758400,
  "created_at" : "2015-04-20 08:32:08 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verity Cole",
      "screen_name" : "CreatEdELT",
      "indices" : [ 0, 11 ],
      "id_str" : "399696885",
      "id" : 399696885
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 12, 22 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 23, 35 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/9yVZHTD8qf",
      "expanded_url" : "https:\/\/sites.google.com\/site\/sketchengineforeslteachers\/",
      "display_url" : "sites.google.com\/site\/sketcheng\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "588747470030688256",
  "geo" : { },
  "id_str" : "590070021059190784",
  "in_reply_to_user_id" : 399696885,
  "text" : "@CreatEdELT @ELTwriter @lexicojules hi u may find this useful as well https:\/\/t.co\/9yVZHTD8qf",
  "id" : 590070021059190784,
  "in_reply_to_status_id" : 588747470030688256,
  "created_at" : "2015-04-20 08:30:30 +0000",
  "in_reply_to_screen_name" : "CreatEdELT",
  "in_reply_to_user_id_str" : "399696885",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Haile",
      "screen_name" : "shikorina78",
      "indices" : [ 0, 12 ],
      "id_str" : "246031350",
      "id" : 246031350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590061586527744001",
  "in_reply_to_user_id" : 246031350,
  "text" : "@shikorina78 hi re your winning poster on corpora teaching, do u have a link to it? fyi  CL comm here u may like https:\/\/t.co\/gnEFqIeLpA thx",
  "id" : 590061586527744001,
  "created_at" : "2015-04-20 07:56:59 +0000",
  "in_reply_to_screen_name" : "shikorina78",
  "in_reply_to_user_id_str" : "246031350",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/8Xh2qfPReF",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/4\/19\/12550\/6796",
      "display_url" : "eurotrib.com\/story\/2015\/4\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590056310764412929",
  "text" : "A tale of two OCAs? http:\/\/t.co\/8Xh2qfPReF",
  "id" : 590056310764412929,
  "created_at" : "2015-04-20 07:36:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UCU Salford",
      "screen_name" : "ucusalford",
      "indices" : [ 3, 14 ],
      "id_str" : "125935756",
      "id" : 125935756
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ucusalford\/status\/590048440723312640\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/nRpfqTReCw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDBF7hVXIAEkF8k.png",
      "id_str" : "590048440048099329",
      "id" : 590048440048099329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDBF7hVXIAEkF8k.png",
      "sizes" : [ {
        "h" : 69,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 1232
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nRpfqTReCw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9y0mTy5HL8",
      "expanded_url" : "https:\/\/www.ucu.org.uk\/fair-treatment-for-salford-staff",
      "display_url" : "ucu.org.uk\/fair-treatment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590052785082753025",
  "text" : "RT @ucusalford: Please sign the national petition. You can access it and sign by clicking on the link: https:\/\/t.co\/9y0mTy5HL8 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ucusalford\/status\/590048440723312640\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/nRpfqTReCw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDBF7hVXIAEkF8k.png",
        "id_str" : "590048440048099329",
        "id" : 590048440048099329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDBF7hVXIAEkF8k.png",
        "sizes" : [ {
          "h" : 69,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 1232
        }, {
          "h" : 122,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/nRpfqTReCw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/9y0mTy5HL8",
        "expanded_url" : "https:\/\/www.ucu.org.uk\/fair-treatment-for-salford-staff",
        "display_url" : "ucu.org.uk\/fair-treatment\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590048440723312640",
    "text" : "Please sign the national petition. You can access it and sign by clicking on the link: https:\/\/t.co\/9y0mTy5HL8 http:\/\/t.co\/nRpfqTReCw",
    "id" : 590048440723312640,
    "created_at" : "2015-04-20 07:04:45 +0000",
    "user" : {
      "name" : "UCU Salford",
      "screen_name" : "ucusalford",
      "protected" : false,
      "id_str" : "125935756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3702403788\/90a11bf9bbfb0cff4307083e54642000_normal.jpeg",
      "id" : 125935756,
      "verified" : false
    }
  },
  "id" : 590052785082753025,
  "created_at" : "2015-04-20 07:22:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590046559984717824",
  "geo" : { },
  "id_str" : "590048742365130754",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish true and costs not necessarily passed down :\/",
  "id" : 590048742365130754,
  "in_reply_to_status_id" : 590046559984717824,
  "created_at" : "2015-04-20 07:05:57 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590045136609882112",
  "geo" : { },
  "id_str" : "590046005174870016",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish lol though there are benefits which i omitted such as turnaround time, scoring costs",
  "id" : 590046005174870016,
  "in_reply_to_status_id" : 590045136609882112,
  "created_at" : "2015-04-20 06:55:04 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "indices" : [ 17, 29 ],
      "id_str" : "3112144043",
      "id" : 3112144043
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 30, 38 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590044046090964992",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @bee_visible @taw_sig many thanks for RT folks :)",
  "id" : 590044046090964992,
  "created_at" : "2015-04-20 06:47:17 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589911653145321474",
  "geo" : { },
  "id_str" : "589913497049378816",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran i wanted to run the line about pilot testing past you as was not sure it was well founded?",
  "id" : 589913497049378816,
  "in_reply_to_status_id" : 589911653145321474,
  "created_at" : "2015-04-19 22:08:32 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589902731898441728",
  "geo" : { },
  "id_str" : "589910892122349568",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard very glad u found it useful ,maybe could inspire u in that direction?",
  "id" : 589910892122349568,
  "in_reply_to_status_id" : 589902731898441728,
  "created_at" : "2015-04-19 21:58:11 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589910235399196672",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran thks for sharing, and congrats! for getting dreamreader featured :)",
  "id" : 589910235399196672,
  "created_at" : "2015-04-19 21:55:34 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589904007134609408",
  "geo" : { },
  "id_str" : "589909446383575041",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach well u can judge for yourself :)",
  "id" : 589909446383575041,
  "in_reply_to_status_id" : 589904007134609408,
  "created_at" : "2015-04-19 21:52:26 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/NyOGmJyRrP",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-VO",
      "display_url" : "wp.me\/pgHyE-VO"
    } ]
  },
  "geo" : { },
  "id_str" : "589901762812743681",
  "text" : "#IATEFL 2015: Testing times all-round http:\/\/t.co\/NyOGmJyRrP",
  "id" : 589901762812743681,
  "created_at" : "2015-04-19 21:21:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589901596026363906",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx for RT Rose hope u had a good w\/e",
  "id" : 589901596026363906,
  "created_at" : "2015-04-19 21:21:14 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keltchat",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/pOylTLVEwS",
      "expanded_url" : "http:\/\/www.lancaster.ac.uk\/fass\/projects\/impoliteness\/index.htm",
      "display_url" : "lancaster.ac.uk\/fass\/projects\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589720807422713856",
  "text" : "#keltchat Impoliteness:\nUsing and Understanding the Language of Offence  http:\/\/t.co\/pOylTLVEwS",
  "id" : 589720807422713856,
  "created_at" : "2015-04-19 09:22:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    }, {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 31, 41 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Sir Michael Barber",
      "screen_name" : "MichaelBarber9",
      "indices" : [ 80, 95 ],
      "id_str" : "376740606",
      "id" : 376740606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/F08jd6rdOy",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=80yXKnln44I",
      "display_url" : "youtube.com\/watch?v=80yXKn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589698694267723777",
  "text" : "RT @gsiemens: Just reminded of @dkernohan's exceptional video on \"deliverology\"\/@MichaelBarber9 : https:\/\/t.co\/F08jd6rdOy. Best video I've \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Kern\u24C4h\u24B6n",
        "screen_name" : "dkernohan",
        "indices" : [ 17, 27 ],
        "id_str" : "12219232",
        "id" : 12219232
      }, {
        "name" : "Sir Michael Barber",
        "screen_name" : "MichaelBarber9",
        "indices" : [ 66, 81 ],
        "id_str" : "376740606",
        "id" : 376740606
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/F08jd6rdOy",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=80yXKnln44I",
        "display_url" : "youtube.com\/watch?v=80yXKn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "589618613805404160",
    "text" : "Just reminded of @dkernohan's exceptional video on \"deliverology\"\/@MichaelBarber9 : https:\/\/t.co\/F08jd6rdOy. Best video I've seen in years",
    "id" : 589618613805404160,
    "created_at" : "2015-04-19 02:36:46 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 589698694267723777,
  "created_at" : "2015-04-19 07:54:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 101, 109 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/HVJ6DCO8I9",
      "expanded_url" : "https:\/\/youtu.be\/oYO1ZmdH5nw",
      "display_url" : "youtu.be\/oYO1ZmdH5nw"
    } ]
  },
  "geo" : { },
  "id_str" : "589546263303086080",
  "text" : "Noam Chomsky: Neoliberal assault led to significant decline in democracy https:\/\/t.co\/HVJ6DCO8I9 via @YouTube",
  "id" : 589546263303086080,
  "created_at" : "2015-04-18 21:49:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Walter",
      "screen_name" : "damiengwalter",
      "indices" : [ 3, 17 ],
      "id_str" : "1409161",
      "id" : 1409161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0YhgGadBwS",
      "expanded_url" : "http:\/\/buff.ly\/1G6gNso",
      "display_url" : "buff.ly\/1G6gNso"
    } ]
  },
  "geo" : { },
  "id_str" : "589508876317372416",
  "text" : "RT @damiengwalter: \"He barked the standard protocol for answering every red alert on ship. \u201CI\u2019m not gay! Report!\u201D\" http:\/\/t.co\/0YhgGadBwS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/0YhgGadBwS",
        "expanded_url" : "http:\/\/buff.ly\/1G6gNso",
        "display_url" : "buff.ly\/1G6gNso"
      } ]
    },
    "geo" : { },
    "id_str" : "589483474853179392",
    "text" : "\"He barked the standard protocol for answering every red alert on ship. \u201CI\u2019m not gay! Report!\u201D\" http:\/\/t.co\/0YhgGadBwS",
    "id" : 589483474853179392,
    "created_at" : "2015-04-18 17:39:47 +0000",
    "user" : {
      "name" : "Damien Walter",
      "screen_name" : "damiengwalter",
      "protected" : false,
      "id_str" : "1409161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724245164269522950\/sQrkA0jN_normal.jpg",
      "id" : 1409161,
      "verified" : false
    }
  },
  "id" : 589508876317372416,
  "created_at" : "2015-04-18 19:20:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy van Olst",
      "screen_name" : "CandyOlst",
      "indices" : [ 0, 10 ],
      "id_str" : "2541190448",
      "id" : 2541190448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589348776600588289",
  "geo" : { },
  "id_str" : "589495432142815232",
  "in_reply_to_user_id" : 2541190448,
  "text" : "@CandyOlst  true that though always good to read it in black and white",
  "id" : 589495432142815232,
  "in_reply_to_status_id" : 589348776600588289,
  "created_at" : "2015-04-18 18:27:17 +0000",
  "in_reply_to_screen_name" : "CandyOlst",
  "in_reply_to_user_id_str" : "2541190448",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589490065144950784",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo thx for RT :)",
  "id" : 589490065144950784,
  "created_at" : "2015-04-18 18:05:58 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589474245492789248",
  "geo" : { },
  "id_str" : "589489969498038272",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson yes wonder if much difference? do u have any good refs for such rhetorical analysis? thx",
  "id" : 589489969498038272,
  "in_reply_to_status_id" : 589474245492789248,
  "created_at" : "2015-04-18 18:05:35 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Kaur Gibbons",
      "screen_name" : "kaurgibbons",
      "indices" : [ 0, 12 ],
      "id_str" : "1219941942",
      "id" : 1219941942
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 13, 21 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589478873261350914",
  "geo" : { },
  "id_str" : "589489728833085440",
  "in_reply_to_user_id" : 1219941942,
  "text" : "@kaurgibbons @taw_sig hi you can also use an image widget",
  "id" : 589489728833085440,
  "in_reply_to_status_id" : 589478873261350914,
  "created_at" : "2015-04-18 18:04:38 +0000",
  "in_reply_to_screen_name" : "kaurgibbons",
  "in_reply_to_user_id_str" : "1219941942",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/589469965658488832\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/GUiePyIXZk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC43z1DWgAElvhN.png",
      "id_str" : "589469964786106369",
      "id" : 589469964786106369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC43z1DWgAElvhN.png",
      "sizes" : [ {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GUiePyIXZk"
    } ],
    "hashtags" : [ {
      "text" : "elections2015",
      "indices" : [ 38, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/EC4qG3y1dF",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/Hu1otJ45zyB",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589469965658488832",
  "text" : "some basic rhetorical analysis Labour #elections2015 manifesto foreward https:\/\/t.co\/EC4qG3y1dF http:\/\/t.co\/GUiePyIXZk",
  "id" : 589469965658488832,
  "created_at" : "2015-04-18 16:46:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/EC4qG3y1dF",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/Hu1otJ45zyB",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "589394425769496576",
  "geo" : { },
  "id_str" : "589467979571691520",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi Paul was inspired to do some basic rhetorical analysis https:\/\/t.co\/EC4qG3y1dF",
  "id" : 589467979571691520,
  "in_reply_to_status_id" : 589394425769496576,
  "created_at" : "2015-04-18 16:38:12 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hacking",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "passengerJet",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gYagJ7Z7nz",
      "expanded_url" : "http:\/\/ow.ly\/LLTtK",
      "display_url" : "ow.ly\/LLTtK"
    } ]
  },
  "geo" : { },
  "id_str" : "589332787745939456",
  "text" : "RT @patrickDurusau: Hacking a Passenger Jet (No Fooling) (+ FBI Watches Fox News) #hacking #passengerJet http:\/\/t.co\/gYagJ7Z7nz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hacking",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "passengerJet",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/gYagJ7Z7nz",
        "expanded_url" : "http:\/\/ow.ly\/LLTtK",
        "display_url" : "ow.ly\/LLTtK"
      } ]
    },
    "geo" : { },
    "id_str" : "589275942390013952",
    "text" : "Hacking a Passenger Jet (No Fooling) (+ FBI Watches Fox News) #hacking #passengerJet http:\/\/t.co\/gYagJ7Z7nz",
    "id" : 589275942390013952,
    "created_at" : "2015-04-18 03:55:07 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 589332787745939456,
  "created_at" : "2015-04-18 07:41:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589324550728462336",
  "geo" : { },
  "id_str" : "589329665845788672",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson grt thx",
  "id" : 589329665845788672,
  "in_reply_to_status_id" : 589324550728462336,
  "created_at" : "2015-04-18 07:28:36 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589325488478388224",
  "geo" : { },
  "id_str" : "589329492205817856",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga an alternative - take clear pics of slides?",
  "id" : 589329492205817856,
  "in_reply_to_status_id" : 589325488478388224,
  "created_at" : "2015-04-18 07:27:54 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589320454080491521",
  "geo" : { },
  "id_str" : "589322253378183169",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi tried it on another text still the case",
  "id" : 589322253378183169,
  "in_reply_to_status_id" : 589320454080491521,
  "created_at" : "2015-04-18 06:59:08 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/R2gUGm5TPT",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=oFJQ_czaOBo&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=oFJQ_c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "589188609846173696",
  "geo" : { },
  "id_str" : "589223558741696512",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan great, u may like this one off from the #iatefl cutting room floor https:\/\/t.co\/R2gUGm5TPT :)",
  "id" : 589223558741696512,
  "in_reply_to_status_id" : 589188609846173696,
  "created_at" : "2015-04-18 00:26:58 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 83, 99 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/eSpfQMJx7I",
      "expanded_url" : "http:\/\/wp.me\/p3swZr-9u",
      "display_url" : "wp.me\/p3swZr-9u"
    } ]
  },
  "geo" : { },
  "id_str" : "589139797891010563",
  "text" : "11 of the biggest lies you\u2019ll hear this election season http:\/\/t.co\/eSpfQMJx7I via @wordpressdotcom",
  "id" : 589139797891010563,
  "created_at" : "2015-04-17 18:54:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/MJmAm4w7rX",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2015\/interview\/interview-evan-frendo-and-almut-koester",
      "display_url" : "iatefl.britishcouncil.org\/2015\/interview\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "589122907176972288",
  "geo" : { },
  "id_str" : "589136209227677696",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan did u watch all the interviews? this one was not bad i thought https:\/\/t.co\/MJmAm4w7rX",
  "id" : 589136209227677696,
  "in_reply_to_status_id" : 589122907176972288,
  "created_at" : "2015-04-17 18:39:52 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 3, 12 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "The Labour Party",
      "screen_name" : "UKLabour",
      "indices" : [ 53, 62 ],
      "id_str" : "14291684",
      "id" : 14291684
    }, {
      "name" : "Conservatives",
      "screen_name" : "Conservatives",
      "indices" : [ 115, 129 ],
      "id_str" : "14281853",
      "id" : 14281853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wmatrix",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MQSt5uMlsL",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/wmatrix\/ukmanifestos2015\/",
      "display_url" : "ucrel.lancs.ac.uk\/wmatrix\/ukmani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589114236158267393",
  "text" : "RT @perayson: Up next on my #wmatrix analysis is the @UKLabour party. Their manifesto is 11,709 words shorter than @Conservatives http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Labour Party",
        "screen_name" : "UKLabour",
        "indices" : [ 39, 48 ],
        "id_str" : "14291684",
        "id" : 14291684
      }, {
        "name" : "Conservatives",
        "screen_name" : "Conservatives",
        "indices" : [ 101, 115 ],
        "id_str" : "14281853",
        "id" : 14281853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wmatrix",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/MQSt5uMlsL",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/wmatrix\/ukmanifestos2015\/",
        "display_url" : "ucrel.lancs.ac.uk\/wmatrix\/ukmani\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "589108236768440321",
    "text" : "Up next on my #wmatrix analysis is the @UKLabour party. Their manifesto is 11,709 words shorter than @Conservatives http:\/\/t.co\/MQSt5uMlsL",
    "id" : 589108236768440321,
    "created_at" : "2015-04-17 16:48:43 +0000",
    "user" : {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "protected" : false,
      "id_str" : "263108959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490485533911445505\/BNOoOchF_normal.jpeg",
      "id" : 263108959,
      "verified" : false
    }
  },
  "id" : 589114236158267393,
  "created_at" : "2015-04-17 17:12:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589093937886945280",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi is there a reason the free claws tagger psuedo xml for &lt;w&gt; starts at 2.1 and not 1.1? thx",
  "id" : 589093937886945280,
  "created_at" : "2015-04-17 15:51:54 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "methodology",
      "indices" : [ 68, 80 ]
    }, {
      "text" : "elt",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "esl",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "efl",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "tefl",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "educhat",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/FYoKFQHpcC",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/start-now\/",
      "display_url" : "decentralisedteachingandlearning.com\/start-now\/"
    } ]
  },
  "geo" : { },
  "id_str" : "589044685219434496",
  "text" : "RT @josipa74: Start now! DO decentralised teaching OR make your own #methodology #elt #esl #efl #tefl #educhat  http:\/\/t.co\/FYoKFQHpcC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "methodology",
        "indices" : [ 54, 66 ]
      }, {
        "text" : "elt",
        "indices" : [ 67, 71 ]
      }, {
        "text" : "esl",
        "indices" : [ 72, 76 ]
      }, {
        "text" : "efl",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "tefl",
        "indices" : [ 82, 87 ]
      }, {
        "text" : "educhat",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/FYoKFQHpcC",
        "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/start-now\/",
        "display_url" : "decentralisedteachingandlearning.com\/start-now\/"
      } ]
    },
    "geo" : { },
    "id_str" : "589021345507385344",
    "text" : "Start now! DO decentralised teaching OR make your own #methodology #elt #esl #efl #tefl #educhat  http:\/\/t.co\/FYoKFQHpcC",
    "id" : 589021345507385344,
    "created_at" : "2015-04-17 11:03:26 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 589044685219434496,
  "created_at" : "2015-04-17 12:36:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589043335685373952",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 the for RT :)",
  "id" : 589043335685373952,
  "created_at" : "2015-04-17 12:30:49 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 25, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8ylfh8B7E9",
      "expanded_url" : "http:\/\/htl.linguist.univ-paris-diderot.fr\/leon\/leon_hs.pdf",
      "display_url" : "htl.linguist.univ-paris-diderot.fr\/leon\/leon_hs.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589010432515518465",
  "text" : "has Chomsky \"bashing\" by #corpuslinguistics been overplayed? http:\/\/t.co\/8ylfh8B7E9",
  "id" : 589010432515518465,
  "created_at" : "2015-04-17 10:20:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/U7OeeLPSvJ",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-us-canada-32306097",
      "display_url" : "bbc.co.uk\/news\/world-us-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588992902036123648",
  "text" : "RT @gbiesta: BBC News - Jail for cheating Atlanta teachers http:\/\/t.co\/U7OeeLPSvJ Am I only one who wonders why system leading to this isn'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/U7OeeLPSvJ",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-us-canada-32306097",
        "display_url" : "bbc.co.uk\/news\/world-us-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588105370054348800",
    "text" : "BBC News - Jail for cheating Atlanta teachers http:\/\/t.co\/U7OeeLPSvJ Am I only one who wonders why system leading to this isn't in the dock?",
    "id" : 588105370054348800,
    "created_at" : "2015-04-14 22:23:41 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 588992902036123648,
  "created_at" : "2015-04-17 09:10:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/wiBbP4IMEk",
      "expanded_url" : "http:\/\/www.thebaffler.com\/salvos\/taming-tech-criticism",
      "display_url" : "thebaffler.com\/salvos\/taming-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588992066044223489",
  "text" : "The Taming of Tech Criticism - The Baffler http:\/\/t.co\/wiBbP4IMEk",
  "id" : 588992066044223489,
  "created_at" : "2015-04-17 09:07:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588974785360752640",
  "geo" : { },
  "id_str" : "588989118958477313",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja thx for sharing, hope u have a relaxing w\/e :)",
  "id" : 588989118958477313,
  "in_reply_to_status_id" : 588974785360752640,
  "created_at" : "2015-04-17 08:55:23 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588970454272122880",
  "geo" : { },
  "id_str" : "588971439430230016",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig cheers and thx for sharing post and well done on getting past 100 followers here's to more :)",
  "id" : 588971439430230016,
  "in_reply_to_status_id" : 588970454272122880,
  "created_at" : "2015-04-17 07:45:08 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 14, 26 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588847373025021952",
  "geo" : { },
  "id_str" : "588967995361329152",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @AnneHendler thanks for sharing, here's to a good w\/e :)",
  "id" : 588967995361329152,
  "in_reply_to_status_id" : 588847373025021952,
  "created_at" : "2015-04-17 07:31:27 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy van Olst",
      "screen_name" : "dingtonia",
      "indices" : [ 49, 59 ],
      "id_str" : "3171471195",
      "id" : 3171471195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/5VLGcUDa4j",
      "expanded_url" : "http:\/\/wp.me\/pYJvF-fn",
      "display_url" : "wp.me\/pYJvF-fn"
    } ]
  },
  "geo" : { },
  "id_str" : "588730620945235968",
  "text" : "Why I loathe testing. http:\/\/t.co\/5VLGcUDa4j via @dingtonia",
  "id" : 588730620945235968,
  "created_at" : "2015-04-16 15:48:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588701293839003649",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx for RT!",
  "id" : 588701293839003649,
  "created_at" : "2015-04-16 13:51:40 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/PWEFruWfFU",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/791-hillary-clinton-of-glass-ceilings-and-shattered-countries.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588696283189288960",
  "text" : "RT @medialens: For the media, Obama's colour &amp; Clinton's gender are key ethical concerns; not their responsibility for mass killing. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/PWEFruWfFU",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/791-hillary-clinton-of-glass-ceilings-and-shattered-countries.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588651458343608320",
    "text" : "For the media, Obama's colour &amp; Clinton's gender are key ethical concerns; not their responsibility for mass killing. http:\/\/t.co\/PWEFruWfFU",
    "id" : 588651458343608320,
    "created_at" : "2015-04-16 10:33:38 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 588696283189288960,
  "created_at" : "2015-04-16 13:31:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/S1PMgB60E6",
      "expanded_url" : "http:\/\/wp.me\/p1Ayq4-8u",
      "display_url" : "wp.me\/p1Ayq4-8u"
    } ]
  },
  "geo" : { },
  "id_str" : "588652163049598978",
  "text" : "RT @_divyamadhavan: Parent-teacher dialogues http:\/\/t.co\/S1PMgB60E6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/S1PMgB60E6",
        "expanded_url" : "http:\/\/wp.me\/p1Ayq4-8u",
        "display_url" : "wp.me\/p1Ayq4-8u"
      } ]
    },
    "geo" : { },
    "id_str" : "588644918756683777",
    "text" : "Parent-teacher dialogues http:\/\/t.co\/S1PMgB60E6",
    "id" : 588644918756683777,
    "created_at" : "2015-04-16 10:07:39 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 588652163049598978,
  "created_at" : "2015-04-16 10:36:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/vHC01ZCDfU",
      "expanded_url" : "https:\/\/youtu.be\/8boFDUwbS7M",
      "display_url" : "youtu.be\/8boFDUwbS7M"
    } ]
  },
  "geo" : { },
  "id_str" : "588641295209537536",
  "text" : "Alex Boulton engcorpora2015 Paris April 8 https:\/\/t.co\/vHC01ZCDfU reports on a metanalysis of DDL #corpuslinguistics",
  "id" : 588641295209537536,
  "created_at" : "2015-04-16 09:53:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 0, 7 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588640594836205568",
  "in_reply_to_user_id" : 1356363686,
  "text" : "@eltjam thanks for RT :)",
  "id" : 588640594836205568,
  "created_at" : "2015-04-16 09:50:28 +0000",
  "in_reply_to_screen_name" : "eltjam",
  "in_reply_to_user_id_str" : "1356363686",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry cuban",
      "screen_name" : "CubanLarry",
      "indices" : [ 127, 138 ],
      "id_str" : "2324494104",
      "id" : 2324494104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/3Z3BQeYcBs",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-2pe",
      "display_url" : "wp.me\/pBm7c-2pe"
    } ]
  },
  "geo" : { },
  "id_str" : "588618314823282689",
  "text" : "iPads and Teachers: Why Technology-assisted Learning Will Never, on Its Own, Solve Our Education C\u2026 http:\/\/t.co\/3Z3BQeYcBs via @CubanLarry",
  "id" : 588618314823282689,
  "created_at" : "2015-04-16 08:21:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Zen",
      "screen_name" : "dailyzen",
      "indices" : [ 0, 9 ],
      "id_str" : "14850840",
      "id" : 14850840
    }, {
      "name" : "\u771F\u79C0 Matthew Ruttley",
      "screen_name" : "matt_ruttley",
      "indices" : [ 10, 23 ],
      "id_str" : "287593094",
      "id" : 287593094
    }, {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 24, 33 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588547410214846464",
  "geo" : { },
  "id_str" : "588591241056505857",
  "in_reply_to_user_id" : 14850840,
  "text" : "@dailyzen @matt_ruttley @TheOnion only funny if one is blissfully unaware of Buddhist bigots in Sri Lanka",
  "id" : 588591241056505857,
  "in_reply_to_status_id" : 588547410214846464,
  "created_at" : "2015-04-16 06:34:22 +0000",
  "in_reply_to_screen_name" : "dailyzen",
  "in_reply_to_user_id_str" : "14850840",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588587593173864448",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson hi Glenys u have a comment\/compliment on yr post :)",
  "id" : 588587593173864448,
  "created_at" : "2015-04-16 06:19:52 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588587137164976130",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler many thx for RT Anne :)",
  "id" : 588587137164976130,
  "created_at" : "2015-04-16 06:18:03 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 0, 13 ],
      "id_str" : "20932918",
      "id" : 20932918
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 14, 22 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588464038406926337",
  "geo" : { },
  "id_str" : "588464530809757696",
  "in_reply_to_user_id" : 20932918,
  "text" : "@blairteacher @taw_sig maybe u should link the relevant recent post in newsletter link Paul?",
  "id" : 588464530809757696,
  "in_reply_to_status_id" : 588464038406926337,
  "created_at" : "2015-04-15 22:10:51 +0000",
  "in_reply_to_screen_name" : "blairteacher",
  "in_reply_to_user_id_str" : "20932918",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/588456931448107009\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/uc2iRLO0cn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCqeddNXIAEx0UQ.png",
      "id_str" : "588456930219335681",
      "id" : 588456930219335681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCqeddNXIAEx0UQ.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/uc2iRLO0cn"
    } ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "elt",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "esl",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "tefl",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ZNczQ2rWW0",
      "expanded_url" : "https:\/\/tinyletter.com\/TeachersasWorkers",
      "display_url" : "tinyletter.com\/TeachersasWork\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588459214873370624",
  "text" : "RT @taw_sig: #IATEFL have spoken! But maybe we can go it alone - spread the word! https:\/\/t.co\/ZNczQ2rWW0 #elt #esl #tefl http:\/\/t.co\/uc2iR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/588456931448107009\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/uc2iRLO0cn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCqeddNXIAEx0UQ.png",
        "id_str" : "588456930219335681",
        "id" : 588456930219335681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCqeddNXIAEx0UQ.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/uc2iRLO0cn"
      } ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "elt",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "esl",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "tefl",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/ZNczQ2rWW0",
        "expanded_url" : "https:\/\/tinyletter.com\/TeachersasWorkers",
        "display_url" : "tinyletter.com\/TeachersasWork\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588456931448107009",
    "text" : "#IATEFL have spoken! But maybe we can go it alone - spread the word! https:\/\/t.co\/ZNczQ2rWW0 #elt #esl #tefl http:\/\/t.co\/uc2iRLO0cn",
    "id" : 588456931448107009,
    "created_at" : "2015-04-15 21:40:40 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 588459214873370624,
  "created_at" : "2015-04-15 21:49:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 10, 17 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588440941922422785",
  "geo" : { },
  "id_str" : "588446072294346754",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C @iatefl i guess though i recall last time embed ran fairly smoothly thanks for quick response",
  "id" : 588446072294346754,
  "in_reply_to_status_id" : 588440941922422785,
  "created_at" : "2015-04-15 20:57:31 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 103, 114 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 115, 124 ]
    }, {
      "text" : "auselt",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/3NDrbulkO5",
      "expanded_url" : "http:\/\/exl-exos.info",
      "display_url" : "exl-exos.info"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/PQ53C6FE43",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/04\/15\/grassroots-language-technology-glenys-hanson-exl-exos-info\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/04\/15\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588445467970637824",
  "text" : "Grassroots language technology: Glenys Hanson, http:\/\/t.co\/3NDrbulkO5 https:\/\/t.co\/PQ53C6FE43 #eltchat #eltchinwag #keltchat #auselt #iatefl",
  "id" : 588445467970637824,
  "created_at" : "2015-04-15 20:55:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 5, 12 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588437687910076420",
  "text" : "have @iatefl registered bloggers been able to embed #iatefl conf videos? been having probs to do so",
  "id" : 588437687910076420,
  "created_at" : "2015-04-15 20:24:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/2Jmp5rpJuc",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/04\/hussein-obama-is-no-jack-kennedy.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/04\/hussei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588429202380218368",
  "text" : "RT @pchallinor: New mudgeonry: Hussein Obama is no Jack Kennedy http:\/\/t.co\/2Jmp5rpJuc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/2Jmp5rpJuc",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/04\/hussein-obama-is-no-jack-kennedy.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/04\/hussei\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588065748674879488",
    "text" : "New mudgeonry: Hussein Obama is no Jack Kennedy http:\/\/t.co\/2Jmp5rpJuc",
    "id" : 588065748674879488,
    "created_at" : "2015-04-14 19:46:14 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 588429202380218368,
  "created_at" : "2015-04-15 19:50:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 69, 75 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/oTkeH40KfU",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/04\/15\/noam_chomsky_were_facing_a_new_cold_war_partner\/",
      "display_url" : "salon.com\/2015\/04\/15\/noa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588421154081234945",
  "text" : "Noam Chomsky: We\u2019re facing a new Cold War http:\/\/t.co\/oTkeH40KfU via @Salon",
  "id" : 588421154081234945,
  "created_at" : "2015-04-15 19:18:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588377072168382464",
  "geo" : { },
  "id_str" : "588378772426096640",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS nice post though the white on black on text does me eyes, must be getting old :\/",
  "id" : 588378772426096640,
  "in_reply_to_status_id" : 588377072168382464,
  "created_at" : "2015-04-15 16:30:05 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 3, 13 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/xrsVZItQjK",
      "expanded_url" : "http:\/\/eltmakespace.blogspot.ie\/2015\/04\/recap-on-elt-maker-night-3.html",
      "display_url" : "eltmakespace.blogspot.ie\/2015\/04\/recap-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588378621993033728",
  "text" : "RT @ELTMAKERS: ELT Maker Night 3: Here's the recap. Lots of links- enjoy. http:\/\/t.co\/xrsVZItQjK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/xrsVZItQjK",
        "expanded_url" : "http:\/\/eltmakespace.blogspot.ie\/2015\/04\/recap-on-elt-maker-night-3.html",
        "display_url" : "eltmakespace.blogspot.ie\/2015\/04\/recap-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588377072168382464",
    "text" : "ELT Maker Night 3: Here's the recap. Lots of links- enjoy. http:\/\/t.co\/xrsVZItQjK",
    "id" : 588377072168382464,
    "created_at" : "2015-04-15 16:23:20 +0000",
    "user" : {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "protected" : false,
      "id_str" : "2894570578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537944364534611969\/BegFDTeR_normal.png",
      "id" : 2894570578,
      "verified" : false
    }
  },
  "id" : 588378621993033728,
  "created_at" : "2015-04-15 16:29:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588367875414556672",
  "geo" : { },
  "id_str" : "588368260778893312",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab true that :)",
  "id" : 588368260778893312,
  "in_reply_to_status_id" : 588367875414556672,
  "created_at" : "2015-04-15 15:48:19 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 12, 27 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 66, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/BdcItJdKDa",
      "expanded_url" : "https:\/\/youtu.be\/21pHWDQx-wo",
      "display_url" : "youtu.be\/21pHWDQx-wo"
    } ]
  },
  "geo" : { },
  "id_str" : "588367180384862208",
  "text" : "Mark Davies #engcorpora2015 Paris April 8 https:\/\/t.co\/BdcItJdKDa #corpuslinguistics",
  "id" : 588367180384862208,
  "created_at" : "2015-04-15 15:44:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588366044932243456",
  "geo" : { },
  "id_str" : "588366685909950465",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab a reflection maybe tool doesn't quite abate the need to throw something at the TV? :)",
  "id" : 588366685909950465,
  "in_reply_to_status_id" : 588366044932243456,
  "created_at" : "2015-04-15 15:42:03 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/qXsfvF4f9W",
      "expanded_url" : "https:\/\/twitter.com\/OpenUniversity\/status\/588361931657871360",
      "display_url" : "twitter.com\/OpenUniversity\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588365957694914560",
  "text" : "RT @amyaishab: Do I always look so .... so .... (I can't even bring myself to say it)? https:\/\/t.co\/qXsfvF4f9W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/qXsfvF4f9W",
        "expanded_url" : "https:\/\/twitter.com\/OpenUniversity\/status\/588361931657871360",
        "display_url" : "twitter.com\/OpenUniversity\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588364350009782272",
    "text" : "Do I always look so .... so .... (I can't even bring myself to say it)? https:\/\/t.co\/qXsfvF4f9W",
    "id" : 588364350009782272,
    "created_at" : "2015-04-15 15:32:46 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 588365957694914560,
  "created_at" : "2015-04-15 15:39:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588364350009782272",
  "geo" : { },
  "id_str" : "588365660188712960",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab seems interesting tool will try it out",
  "id" : 588365660188712960,
  "in_reply_to_status_id" : 588364350009782272,
  "created_at" : "2015-04-15 15:37:59 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 139, 140 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pronunciation",
      "indices" : [ 43, 57 ]
    }, {
      "text" : "IATEFL2015",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xQmIrZQUfd",
      "expanded_url" : "http:\/\/shar.es\/1gVua5",
      "display_url" : "shar.es\/1gVua5"
    } ]
  },
  "geo" : { },
  "id_str" : "588351210618544128",
  "text" : "RT @HancockMcDonald: Mark Hancock: Lots of #pronunciation at #IATEFL2015 - great stuff! here are some talks reviewed http:\/\/t.co\/xQmIrZQUfd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 123, 133 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pronunciation",
        "indices" : [ 22, 36 ]
      }, {
        "text" : "IATEFL2015",
        "indices" : [ 40, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/xQmIrZQUfd",
        "expanded_url" : "http:\/\/shar.es\/1gVua5",
        "display_url" : "shar.es\/1gVua5"
      } ]
    },
    "geo" : { },
    "id_str" : "588345988022165504",
    "text" : "Mark Hancock: Lots of #pronunciation at #IATEFL2015 - great stuff! here are some talks reviewed http:\/\/t.co\/xQmIrZQUfd via @sharethis",
    "id" : 588345988022165504,
    "created_at" : "2015-04-15 14:19:49 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 588351210618544128,
  "created_at" : "2015-04-15 14:40:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 64, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588293503014281217",
  "text" : "those dastardly phishers\/spammers have gotten past corpora list #corpuslinguistics mailing list filters :\/",
  "id" : 588293503014281217,
  "created_at" : "2015-04-15 10:51:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 31, 42 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "businessenglish",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/LPdnMTUmlY",
      "expanded_url" : "http:\/\/fb.me\/1NxNJqMIj",
      "display_url" : "fb.me\/1NxNJqMIj"
    } ]
  },
  "geo" : { },
  "id_str" : "588256553725272066",
  "text" : "RT @Charlesrei1: Koester &amp; @evanfrendo show why they are still the best resources for #businessenglish - he just described my job :-) http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "evanfrendo",
        "screen_name" : "evanfrendo",
        "indices" : [ 14, 25 ],
        "id_str" : "17589664",
        "id" : 17589664
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "businessenglish",
        "indices" : [ 73, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/LPdnMTUmlY",
        "expanded_url" : "http:\/\/fb.me\/1NxNJqMIj",
        "display_url" : "fb.me\/1NxNJqMIj"
      } ]
    },
    "geo" : { },
    "id_str" : "588220097786998784",
    "text" : "Koester &amp; @evanfrendo show why they are still the best resources for #businessenglish - he just described my job :-) http:\/\/t.co\/LPdnMTUmlY",
    "id" : 588220097786998784,
    "created_at" : "2015-04-15 05:59:34 +0000",
    "user" : {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "protected" : false,
      "id_str" : "464454382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461561508057468928\/BA8otRW0_normal.jpeg",
      "id" : 464454382,
      "verified" : false
    }
  },
  "id" : 588256553725272066,
  "created_at" : "2015-04-15 08:24:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 13, 24 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588220097786998784",
  "geo" : { },
  "id_str" : "588256043408424960",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 @evanfrendo a great informative interview, i guess the debate\/discussion was not recorded?",
  "id" : 588256043408424960,
  "in_reply_to_status_id" : 588220097786998784,
  "created_at" : "2015-04-15 08:22:24 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587999407766929408",
  "geo" : { },
  "id_str" : "588000114129690625",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 i think holding a \"skeptic\" or a \"pessimistic\" position in regards to edtech is sensible",
  "id" : 588000114129690625,
  "in_reply_to_status_id" : 587999407766929408,
  "created_at" : "2015-04-14 15:25:26 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buisinessenglish",
      "indices" : [ 32, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587997808638169089",
  "geo" : { },
  "id_str" : "587999714806730753",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 depends i guess as #buisinessenglish covers quite a lot from specialised bods to general bods no?",
  "id" : 587999714806730753,
  "in_reply_to_status_id" : 587997808638169089,
  "created_at" : "2015-04-14 15:23:51 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 3, 16 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL2015",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/QglECbZpwk",
      "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2015\/04\/14\/iatefl-2015-bringing-corpus-research-into-the-language-classroom-jane-templeton\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2015\/04\/14\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587965356553203712",
  "text" : "RT @LizziePinard: #IATEFL2015 @jane_templeton on bringing corpus research into the classroom -my write-up. http:\/\/t.co\/QglECbZpwk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL2015",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/QglECbZpwk",
        "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2015\/04\/14\/iatefl-2015-bringing-corpus-research-into-the-language-classroom-jane-templeton\/",
        "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2015\/04\/14\/iat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "587959808063594496",
    "text" : "#IATEFL2015 @jane_templeton on bringing corpus research into the classroom -my write-up. http:\/\/t.co\/QglECbZpwk",
    "id" : 587959808063594496,
    "created_at" : "2015-04-14 12:45:16 +0000",
    "user" : {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "protected" : false,
      "id_str" : "287093748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628657904460132352\/nS6hzUBs_normal.png",
      "id" : 287093748,
      "verified" : false
    }
  },
  "id" : 587965356553203712,
  "created_at" : "2015-04-14 13:07:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 0, 10 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587895544028205056",
  "geo" : { },
  "id_str" : "587962479780564992",
  "in_reply_to_user_id" : 1428024560,
  "text" : "@_ctaylor_ Glowbe shows how term is GB(46) based except for 1 hit in Australia",
  "id" : 587962479780564992,
  "in_reply_to_status_id" : 587895544028205056,
  "created_at" : "2015-04-14 12:55:53 +0000",
  "in_reply_to_screen_name" : "_ctaylor_",
  "in_reply_to_user_id_str" : "1428024560",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 3, 13 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/hq2xUkOJfR",
      "expanded_url" : "http:\/\/gu.com\/p\/47dap",
      "display_url" : "gu.com\/p\/47dap"
    } ]
  },
  "geo" : { },
  "id_str" : "587962104860299264",
  "text" : "RT @_ctaylor_: Michael Rundell deconstructing the myth of the metropolitan elite with a bit of #corpuslinguistics\n\nhttp:\/\/t.co\/hq2xUkOJfR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 80, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/hq2xUkOJfR",
        "expanded_url" : "http:\/\/gu.com\/p\/47dap",
        "display_url" : "gu.com\/p\/47dap"
      } ]
    },
    "geo" : { },
    "id_str" : "587895544028205056",
    "text" : "Michael Rundell deconstructing the myth of the metropolitan elite with a bit of #corpuslinguistics\n\nhttp:\/\/t.co\/hq2xUkOJfR",
    "id" : 587895544028205056,
    "created_at" : "2015-04-14 08:29:54 +0000",
    "user" : {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "protected" : false,
      "id_str" : "1428024560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747118162383085568\/dvYEKKWl_normal.jpg",
      "id" : 1428024560,
      "verified" : false
    }
  },
  "id" : 587962104860299264,
  "created_at" : "2015-04-14 12:54:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 3, 16 ],
      "id_str" : "10187072",
      "id" : 10187072
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 31, 45 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/jDwNwTO5ME",
      "expanded_url" : "http:\/\/Lynda.com",
      "display_url" : "Lynda.com"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lDTVXO56jF",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/04\/13\/linkedin-lyndacom\/",
      "display_url" : "hackeducation.com\/2015\/04\/13\/lin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587887101619867648",
  "text" : "RT @mfeldstein67: Great post: \u201C@audreywatters: Data and Diplomas: On LinkedIn's Acquisition of http:\/\/t.co\/jDwNwTO5ME http:\/\/t.co\/lDTVXO56j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 13, 27 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/jDwNwTO5ME",
        "expanded_url" : "http:\/\/Lynda.com",
        "display_url" : "Lynda.com"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/lDTVXO56jF",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/04\/13\/linkedin-lyndacom\/",
        "display_url" : "hackeducation.com\/2015\/04\/13\/lin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "587821518014525440",
    "text" : "Great post: \u201C@audreywatters: Data and Diplomas: On LinkedIn's Acquisition of http:\/\/t.co\/jDwNwTO5ME http:\/\/t.co\/lDTVXO56jF\u201D",
    "id" : 587821518014525440,
    "created_at" : "2015-04-14 03:35:45 +0000",
    "user" : {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "protected" : false,
      "id_str" : "10187072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612670776047603712\/1oUXVo2E_normal.png",
      "id" : 10187072,
      "verified" : false
    }
  },
  "id" : 587887101619867648,
  "created_at" : "2015-04-14 07:56:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 9, 19 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 20, 32 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/587856516826402816\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/D5iHvrMT9l",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CCh8YuyWEAAYCf7.png",
      "id_str" : "587856515689746432",
      "id" : 587856515689746432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CCh8YuyWEAAYCf7.png",
      "sizes" : [ {
        "h" : 184,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/D5iHvrMT9l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587748012857958400",
  "geo" : { },
  "id_str" : "587856516826402816",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig @TEFLninja @NewbieCELTA maybe someone could do something with this can't think of anything myself? http:\/\/t.co\/D5iHvrMT9l",
  "id" : 587856516826402816,
  "in_reply_to_status_id" : 587748012857958400,
  "created_at" : "2015-04-14 05:54:50 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 0, 12 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    }, {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 13, 23 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 24, 32 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 33, 40 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587736790703988737",
  "geo" : { },
  "id_str" : "587737127661793280",
  "in_reply_to_user_id" : 2311153903,
  "text" : "@NewbieCELTA @TEFLninja @taw_sig @iatefl oldies are the goldies :)",
  "id" : 587737127661793280,
  "in_reply_to_status_id" : 587736790703988737,
  "created_at" : "2015-04-13 22:00:25 +0000",
  "in_reply_to_screen_name" : "NewbieCELTA",
  "in_reply_to_user_id_str" : "2311153903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 11, 19 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587734059805241344",
  "geo" : { },
  "id_str" : "587734473980170240",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja @taw_sig don't know any names but google will sure to dig something out",
  "id" : 587734473980170240,
  "in_reply_to_status_id" : 587734059805241344,
  "created_at" : "2015-04-13 21:49:52 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 9, 19 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587733248169664512",
  "geo" : { },
  "id_str" : "587733513773912064",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig @TEFLninja can get screensaver program for pc, and photoshop equivalents and some googling :)",
  "id" : 587733513773912064,
  "in_reply_to_status_id" : 587733248169664512,
  "created_at" : "2015-04-13 21:46:03 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 11, 19 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587732741032030208",
  "geo" : { },
  "id_str" : "587733102656618496",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja @taw_sig screen save quicktime, then gif program, then  photoshop",
  "id" : 587733102656618496,
  "in_reply_to_status_id" : 587732741032030208,
  "created_at" : "2015-04-13 21:44:25 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 3, 13 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 15, 24 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 25, 33 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TEFLninja\/status\/587676940670218240\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/MWAcZY82oz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfZBc-UkAIVZCl.jpg",
      "id_str" : "587676895375822850",
      "id" : 587676895375822850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfZBc-UkAIVZCl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MWAcZY82oz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587732877967810562",
  "text" : "RT @TEFLninja: @muranava @taw_sig People like dogs ! Get a dog that will pose properly (unlike mine) in house with... http:\/\/t.co\/MWAcZY82oz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "teachers_as_workers",
        "screen_name" : "taw_sig",
        "indices" : [ 10, 18 ],
        "id_str" : "3152637711",
        "id" : 3152637711
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TEFLninja\/status\/587676940670218240\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/MWAcZY82oz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfZBc-UkAIVZCl.jpg",
        "id_str" : "587676895375822850",
        "id" : 587676895375822850,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfZBc-UkAIVZCl.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MWAcZY82oz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "587671359901343744",
    "geo" : { },
    "id_str" : "587676940670218240",
    "in_reply_to_user_id" : 3131267981,
    "text" : "@muranava @taw_sig People like dogs ! Get a dog that will pose properly (unlike mine) in house with... http:\/\/t.co\/MWAcZY82oz",
    "id" : 587676940670218240,
    "in_reply_to_status_id" : 587671359901343744,
    "created_at" : "2015-04-13 18:01:15 +0000",
    "in_reply_to_screen_name" : "TEFLninja",
    "in_reply_to_user_id_str" : "3131267981",
    "user" : {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "protected" : false,
      "id_str" : "3131267981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583575211745894400\/TmUR03jo_normal.jpg",
      "id" : 3131267981,
      "verified" : false
    }
  },
  "id" : 587732877967810562,
  "created_at" : "2015-04-13 21:43:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 126, 137 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Xx1XHpph5d",
      "expanded_url" : "https:\/\/technaverbascripta.wordpress.com\/2015\/04\/13\/graphing-early-modern-memory-treatises\/",
      "display_url" : "technaverbascripta.wordpress.com\/2015\/04\/13\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587732236117606400",
  "text" : "interesting post on poss religious reasons for dip in memory publications in england btw 1601-1650 https:\/\/t.co\/Xx1XHpph5d cc @hughdellar",
  "id" : 587732236117606400,
  "created_at" : "2015-04-13 21:40:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 9, 19 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587729681409056768",
  "geo" : { },
  "id_str" : "587730849870774272",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig @TEFLninja there's some audio of him saying something about increasing teachers wages but yeah death matal\/julie andrews fusion :)",
  "id" : 587730849870774272,
  "in_reply_to_status_id" : 587729681409056768,
  "created_at" : "2015-04-13 21:35:28 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 9, 19 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587728922500014080",
  "geo" : { },
  "id_str" : "587729098891468801",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig @TEFLninja by all means though i think maybe missing some sound? any ideas?",
  "id" : 587729098891468801,
  "in_reply_to_status_id" : 587728922500014080,
  "created_at" : "2015-04-13 21:28:31 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 0, 10 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 11, 19 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/587728271627972608\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/0VUSHObT0y",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CCgHvunXIAEzL-j.png",
      "id_str" : "587728267920220161",
      "id" : 587728267920220161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CCgHvunXIAEzL-j.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/0VUSHObT0y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587705696579358720",
  "geo" : { },
  "id_str" : "587728271627972608",
  "in_reply_to_user_id" : 3131267981,
  "text" : "@TEFLninja @taw_sig hehe some good ones how about this? :) http:\/\/t.co\/0VUSHObT0y",
  "id" : 587728271627972608,
  "in_reply_to_status_id" : 587705696579358720,
  "created_at" : "2015-04-13 21:25:14 +0000",
  "in_reply_to_screen_name" : "TEFLninja",
  "in_reply_to_user_id_str" : "3131267981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587656677853364224",
  "geo" : { },
  "id_str" : "587669737053749248",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig OK will have a think :)",
  "id" : 587669737053749248,
  "in_reply_to_status_id" : 587656677853364224,
  "created_at" : "2015-04-13 17:32:38 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 0, 15 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587655451032027139",
  "in_reply_to_user_id" : 501629829,
  "text" : "@ETprofessional thx for RT :)",
  "id" : 587655451032027139,
  "created_at" : "2015-04-13 16:35:52 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 96, 108 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Brg1Vu48bl",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-9BR",
      "display_url" : "wp.me\/p1U04a-9BR"
    } ]
  },
  "geo" : { },
  "id_str" : "587643308387786752",
  "text" : "Police arrest parliamentary candidate for putting up campaign poster http:\/\/t.co\/Brg1Vu48bl via @ThomasPride",
  "id" : 587643308387786752,
  "created_at" : "2015-04-13 15:47:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Leys",
      "screen_name" : "BrunoLeys",
      "indices" : [ 0, 10 ],
      "id_str" : "19535265",
      "id" : 19535265
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 11, 22 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587615940784873472",
  "geo" : { },
  "id_str" : "587639885315633153",
  "in_reply_to_user_id" : 19535265,
  "text" : "@BrunoLeys @hughdellar true, also difficult to disregard results of paired-associate learning findings re:not to use word translations",
  "id" : 587639885315633153,
  "in_reply_to_status_id" : 587615940784873472,
  "created_at" : "2015-04-13 15:34:01 +0000",
  "in_reply_to_screen_name" : "BrunoLeys",
  "in_reply_to_user_id_str" : "19535265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 0, 15 ],
      "id_str" : "501629829",
      "id" : 501629829
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 16, 23 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/L2aPNQcz5j",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/tag\/grassroots-language-tech\/",
      "display_url" : "eflnotes.wordpress.com\/tag\/grassroots\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587632929465094147",
  "geo" : { },
  "id_str" : "587633651535454208",
  "in_reply_to_user_id" : 501629829,
  "text" : "@ETprofessional @eltjam featured here along with another grassroots lang tech apps4fl https:\/\/t.co\/L2aPNQcz5j #IATEFL more to follow",
  "id" : 587633651535454208,
  "in_reply_to_status_id" : 587632929465094147,
  "created_at" : "2015-04-13 15:09:14 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 11, 18 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/prOLgimydq",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Female_hysteria",
      "display_url" : "en.wikipedia.org\/wiki\/Female_hy\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587628387398766592",
  "geo" : { },
  "id_str" : "587630559372910592",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @eltjam is screechindex similar to this? http:\/\/t.co\/prOLgimydq  #IATEFL",
  "id" : 587630559372910592,
  "in_reply_to_status_id" : 587628387398766592,
  "created_at" : "2015-04-13 14:56:57 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 15, 22 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Gary Motteram",
      "screen_name" : "garymotteram",
      "indices" : [ 23, 36 ],
      "id_str" : "10738912",
      "id" : 10738912
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/587629649791995904\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/mFvf3yuyX5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCeuDToWgAAB1Yv.jpg",
      "id_str" : "587629648227500032",
      "id" : 587629648227500032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCeuDToWgAAB1Yv.jpg",
      "sizes" : [ {
        "h" : 301,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/mFvf3yuyX5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587627548118515712",
  "geo" : { },
  "id_str" : "587629649791995904",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic @eltjam @garymotteram or further back with these guys :) http:\/\/t.co\/mFvf3yuyX5",
  "id" : 587629649791995904,
  "in_reply_to_status_id" : 587627548118515712,
  "created_at" : "2015-04-13 14:53:20 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587593745366966272",
  "geo" : { },
  "id_str" : "587602818237919232",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig oh noes not that meme bah humbug :\/)",
  "id" : 587602818237919232,
  "in_reply_to_status_id" : 587593745366966272,
  "created_at" : "2015-04-13 13:06:43 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 3, 15 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sandymillin\/status\/587579651826049024\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/40MDN4yg7Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCeAeenVEAEYLB1.jpg",
      "id_str" : "587579537497591809",
      "id" : 587579537497591809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCeAeenVEAEYLB1.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/40MDN4yg7Y"
    } ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587582261282873344",
  "text" : "RT @sandymillin: #iatefl Julie Douglas A message from one of the Talk English students who is now studying obstetrics in Durban http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sandymillin\/status\/587579651826049024\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/40MDN4yg7Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCeAeenVEAEYLB1.jpg",
        "id_str" : "587579537497591809",
        "id" : 587579537497591809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCeAeenVEAEYLB1.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/40MDN4yg7Y"
      } ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587579651826049024",
    "text" : "#iatefl Julie Douglas A message from one of the Talk English students who is now studying obstetrics in Durban http:\/\/t.co\/40MDN4yg7Y",
    "id" : 587579651826049024,
    "created_at" : "2015-04-13 11:34:40 +0000",
    "user" : {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "protected" : false,
      "id_str" : "144236944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429614623923269632\/yY-O4eno_normal.jpeg",
      "id" : 144236944,
      "verified" : false
    }
  },
  "id" : 587582261282873344,
  "created_at" : "2015-04-13 11:45:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Northern",
      "screen_name" : "Andrew_Northern",
      "indices" : [ 3, 19 ],
      "id_str" : "388826563",
      "id" : 388826563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/dgS3zJJxYe",
      "expanded_url" : "http:\/\/youtu.be\/XvNFEcmzCL0",
      "display_url" : "youtu.be\/XvNFEcmzCL0"
    } ]
  },
  "geo" : { },
  "id_str" : "587581633689190401",
  "text" : "RT @Andrew_Northern: Exclusive: Mumia Abu-Jamal Releases New Prison Radio Commentary on Walter Scott Shooting http:\/\/t.co\/dgS3zJJxYe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/dgS3zJJxYe",
        "expanded_url" : "http:\/\/youtu.be\/XvNFEcmzCL0",
        "display_url" : "youtu.be\/XvNFEcmzCL0"
      } ]
    },
    "geo" : { },
    "id_str" : "587577623426936836",
    "text" : "Exclusive: Mumia Abu-Jamal Releases New Prison Radio Commentary on Walter Scott Shooting http:\/\/t.co\/dgS3zJJxYe",
    "id" : 587577623426936836,
    "created_at" : "2015-04-13 11:26:36 +0000",
    "user" : {
      "name" : "Andrew Northern",
      "screen_name" : "Andrew_Northern",
      "protected" : false,
      "id_str" : "388826563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659977402840322048\/JJFkEJrx_normal.jpg",
      "id" : 388826563,
      "verified" : false
    }
  },
  "id" : 587581633689190401,
  "created_at" : "2015-04-13 11:42:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Bruno Leys",
      "screen_name" : "BrunoLeys",
      "indices" : [ 12, 22 ],
      "id_str" : "19535265",
      "id" : 19535265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587567269686935552",
  "geo" : { },
  "id_str" : "587572668926455808",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @BrunoLeys q of balancing focus on later phases of word learning vs initial beginner phases, where lists r useful?",
  "id" : 587572668926455808,
  "in_reply_to_status_id" : 587567269686935552,
  "created_at" : "2015-04-13 11:06:55 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587556861739716608",
  "geo" : { },
  "id_str" : "587567009489166336",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hi Leo my pleasure thanks for h\/t and linking :)",
  "id" : 587567009489166336,
  "in_reply_to_status_id" : 587556861739716608,
  "created_at" : "2015-04-13 10:44:26 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 14, 21 ]
    }, {
      "text" : "elt",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Btc2AtGoj8",
      "expanded_url" : "http:\/\/goo.gl\/X7LukG",
      "display_url" : "goo.gl\/X7LukG"
    }, {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ulko8Vi5gl",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4vHvzybkqfo",
      "display_url" : "youtube.com\/watch?v=4vHvzy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587509673227657216",
  "text" : "RT @josipa74: #IATEFL calling: the story of Teachers as Workers SIG so far! http:\/\/t.co\/Btc2AtGoj8 https:\/\/t.co\/ulko8Vi5gl #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "elt",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/Btc2AtGoj8",
        "expanded_url" : "http:\/\/goo.gl\/X7LukG",
        "display_url" : "goo.gl\/X7LukG"
      }, {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ulko8Vi5gl",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4vHvzybkqfo",
        "display_url" : "youtube.com\/watch?v=4vHvzy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "587496095128952833",
    "text" : "#IATEFL calling: the story of Teachers as Workers SIG so far! http:\/\/t.co\/Btc2AtGoj8 https:\/\/t.co\/ulko8Vi5gl #elt",
    "id" : 587496095128952833,
    "created_at" : "2015-04-13 06:02:38 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 587509673227657216,
  "created_at" : "2015-04-13 06:56:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587338758254624768",
  "text" : "@IreneVoulgaris interesting writeup, thx",
  "id" : 587338758254624768,
  "created_at" : "2015-04-12 19:37:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "esl",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/JdpswdIRVM",
      "expanded_url" : "http:\/\/www.codeshare.io\/mIDmN",
      "display_url" : "codeshare.io\/mIDmN"
    } ]
  },
  "geo" : { },
  "id_str" : "587264702255869952",
  "text" : "RT @taw_sig: #elt and #esl bloggers! Put 'Teachers as Workers' badge in yr next blog post http:\/\/t.co\/JdpswdIRVM  (copy\/ paste into html ed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "esl",
        "indices" : [ 9, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/JdpswdIRVM",
        "expanded_url" : "http:\/\/www.codeshare.io\/mIDmN",
        "display_url" : "codeshare.io\/mIDmN"
      } ]
    },
    "geo" : { },
    "id_str" : "587264146133123072",
    "text" : "#elt and #esl bloggers! Put 'Teachers as Workers' badge in yr next blog post http:\/\/t.co\/JdpswdIRVM  (copy\/ paste into html editor).",
    "id" : 587264146133123072,
    "created_at" : "2015-04-12 14:40:57 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 587264702255869952,
  "created_at" : "2015-04-12 14:43:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 26, 37 ],
      "id_str" : "857732892",
      "id" : 857732892
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 44, 55 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587239594921459712",
  "geo" : { },
  "id_str" : "587240508566691841",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin i guess then @LexicalLab &amp; @leoselivan need to up their game ;)",
  "id" : 587240508566691841,
  "in_reply_to_status_id" : 587239594921459712,
  "created_at" : "2015-04-12 13:07:02 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 25, 38 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587237740862930945",
  "geo" : { },
  "id_str" : "587239884852699137",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle approved :) cc @LauraSoracco",
  "id" : 587239884852699137,
  "in_reply_to_status_id" : 587237740862930945,
  "created_at" : "2015-04-12 13:04:33 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaime Miller",
      "screen_name" : "teachESLonline",
      "indices" : [ 3, 18 ],
      "id_str" : "1605400032",
      "id" : 1605400032
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 20, 35 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 42, 54 ],
      "id_str" : "31179355",
      "id" : 31179355
    }, {
      "name" : "Ken Wilson",
      "screen_name" : "kenwilsonlondon",
      "indices" : [ 56, 72 ],
      "id_str" : "29030280",
      "id" : 29030280
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogme",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "IATEFL2015",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/ymjz01XlM6",
      "expanded_url" : "http:\/\/esalink.info\/kenwilson",
      "display_url" : "esalink.info\/kenwilson"
    } ]
  },
  "geo" : { },
  "id_str" : "587223220262195200",
  "text" : "RT @teachESLonline: @thornburyscott &amp; @mattledding: @kenwilsonlondon sang #dogme praise at #IATEFL2015 ... which I reported on here http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 0, 15 ],
        "id_str" : "23090474",
        "id" : 23090474
      }, {
        "name" : "matt ledding",
        "screen_name" : "mattledding",
        "indices" : [ 22, 34 ],
        "id_str" : "31179355",
        "id" : 31179355
      }, {
        "name" : "Ken Wilson",
        "screen_name" : "kenwilsonlondon",
        "indices" : [ 36, 52 ],
        "id_str" : "29030280",
        "id" : 29030280
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dogme",
        "indices" : [ 58, 64 ]
      }, {
        "text" : "IATEFL2015",
        "indices" : [ 75, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ymjz01XlM6",
        "expanded_url" : "http:\/\/esalink.info\/kenwilson",
        "display_url" : "esalink.info\/kenwilson"
      } ]
    },
    "geo" : { },
    "id_str" : "586946240698572800",
    "in_reply_to_user_id" : 23090474,
    "text" : "@thornburyscott &amp; @mattledding: @kenwilsonlondon sang #dogme praise at #IATEFL2015 ... which I reported on here http:\/\/t.co\/ymjz01XlM6",
    "id" : 586946240698572800,
    "created_at" : "2015-04-11 17:37:43 +0000",
    "in_reply_to_screen_name" : "thornburyscott",
    "in_reply_to_user_id_str" : "23090474",
    "user" : {
      "name" : "Jaime Miller",
      "screen_name" : "teachESLonline",
      "protected" : false,
      "id_str" : "1605400032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576930976724471808\/gjhwpTwd_normal.jpeg",
      "id" : 1605400032,
      "verified" : false
    }
  },
  "id" : 587223220262195200,
  "created_at" : "2015-04-12 11:58:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 11, 26 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langdebate",
      "indices" : [ 115, 126 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/pGdBzizpgM",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/T1g8vYXtRSJ",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587217358336294912",
  "geo" : { },
  "id_str" : "587220844285419521",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim @CambridgeUPELT some info on that from Chris Tribble's 2012 survey, paper lhere https:\/\/t.co\/pGdBzizpgM #langdebate #IATEFL",
  "id" : 587220844285419521,
  "in_reply_to_status_id" : 587217358336294912,
  "created_at" : "2015-04-12 11:48:53 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 0, 15 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langdebate",
      "indices" : [ 68, 79 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587214916886593536",
  "geo" : { },
  "id_str" : "587216082819231744",
  "in_reply_to_user_id" : 73107903,
  "text" : "@CambridgeUPELT easier said than done with many corpora locked down #langdebate #IATEFL",
  "id" : 587216082819231744,
  "in_reply_to_status_id" : 587214916886593536,
  "created_at" : "2015-04-12 11:29:58 +0000",
  "in_reply_to_screen_name" : "CambridgeUPELT",
  "in_reply_to_user_id_str" : "73107903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587212604222869504",
  "geo" : { },
  "id_str" : "587214369425072129",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle yr welcome looks like an enjoyable do :)",
  "id" : 587214369425072129,
  "in_reply_to_status_id" : 587212604222869504,
  "created_at" : "2015-04-12 11:23:10 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/oy1SBTHLMR",
      "expanded_url" : "https:\/\/iatefl.britishcouncil.org\/2015\/session\/appropriate-strategies-teaching-grammar-%E2%80%93-dave-willis-retrospective",
      "display_url" : "iatefl.britishcouncil.org\/2015\/session\/a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587206605088890881",
  "geo" : { },
  "id_str" : "587209681694810112",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar this is good on language https:\/\/t.co\/oy1SBTHLMR",
  "id" : 587209681694810112,
  "in_reply_to_status_id" : 587206605088890881,
  "created_at" : "2015-04-12 11:04:32 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 79, 86 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/TjtC9hRdAk",
      "expanded_url" : "http:\/\/wp.me\/pUvFH-gs",
      "display_url" : "wp.me\/pUvFH-gs"
    } ]
  },
  "geo" : { },
  "id_str" : "587203602738978816",
  "text" : "The Dark Matter, or themes at the Iatefl Conference http:\/\/t.co\/TjtC9hRdAk via @hartle",
  "id" : 587203602738978816,
  "created_at" : "2015-04-12 10:40:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 3, 11 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/rah0V8lbzf",
      "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2015\/04\/12\/iatefl2015-sheila-thorn-practical-advice-on-creating-authentic-medical-english-listening-materials-talk-summary\/",
      "display_url" : "eltgeek.wordpress.com\/2015\/04\/12\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587201373843906561",
  "text" : "RT @olyaelt: Sheila Thorn: Practical advice on creating authentic Medical English listening materials #IATEFL https:\/\/t.co\/rah0V8lbzf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/rah0V8lbzf",
        "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2015\/04\/12\/iatefl2015-sheila-thorn-practical-advice-on-creating-authentic-medical-english-listening-materials-talk-summary\/",
        "display_url" : "eltgeek.wordpress.com\/2015\/04\/12\/iat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "587200260763713536",
    "text" : "Sheila Thorn: Practical advice on creating authentic Medical English listening materials #IATEFL https:\/\/t.co\/rah0V8lbzf",
    "id" : 587200260763713536,
    "created_at" : "2015-04-12 10:27:06 +0000",
    "user" : {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "protected" : false,
      "id_str" : "2176726134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592983544823042049\/GQ3T3m4K_normal.jpg",
      "id" : 2176726134,
      "verified" : false
    }
  },
  "id" : 587201373843906561,
  "created_at" : "2015-04-12 10:31:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 0, 15 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/62EU1rRPic",
      "expanded_url" : "http:\/\/www.uvm.edu\/storylab\/share\/papers\/dodds2014a\/data.html",
      "display_url" : "uvm.edu\/storylab\/share\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587194549950382080",
  "in_reply_to_user_id" : 1327355143,
  "text" : "@EvilJoeMcVeigh hi Joe great post and title though maybe corpus girls be feeling left out? btw did u get scores from http:\/\/t.co\/62EU1rRPic?",
  "id" : 587194549950382080,
  "created_at" : "2015-04-12 10:04:24 +0000",
  "in_reply_to_screen_name" : "EvilJoeMcVeigh",
  "in_reply_to_user_id_str" : "1327355143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 70, 86 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/LzQuTlIE9E",
      "expanded_url" : "http:\/\/wp.me\/p16czy-eJ",
      "display_url" : "wp.me\/p16czy-eJ"
    } ]
  },
  "geo" : { },
  "id_str" : "587191062357213185",
  "text" : "My Corpus Brings All the Boys to the Yard: http:\/\/t.co\/LzQuTlIE9E via @wordpressdotcom",
  "id" : 587191062357213185,
  "created_at" : "2015-04-12 09:50:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/a5uhUvXnCm",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/04\/10\/grassroots-language-technology-mike-boyle-easytweets-net\/#comment-1921",
      "display_url" : "eflnotes.wordpress.com\/2015\/04\/10\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587188766256705536",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle hi Mike u have a question https:\/\/t.co\/a5uhUvXnCm",
  "id" : 587188766256705536,
  "created_at" : "2015-04-12 09:41:25 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 11, 22 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/KAcEWecflC",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/jgXwYfDRq9Z",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587004464940220416",
  "geo" : { },
  "id_str" : "587007060228907008",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @leoselivan no? u can get paper by emailing lead author though also original list here see 1st comment https:\/\/t.co\/KAcEWecflC",
  "id" : 587007060228907008,
  "in_reply_to_status_id" : 587004464940220416,
  "created_at" : "2015-04-11 21:39:23 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 115, 122 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/kKTQbpUPYC",
      "expanded_url" : "https:\/\/www.uni-marburg.de\/fb10\/iaa\/institut\/personal\/ruehlemann\/corpora",
      "display_url" : "uni-marburg.de\/fb10\/iaa\/insti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586950531190542336",
  "text" : "hi @peterrenshu this may help with xpath\/xml in lieu of me not yet writing about it :) https:\/\/t.co\/kKTQbpUPYC h\/t @mrkm_a",
  "id" : 586950531190542336,
  "created_at" : "2015-04-11 17:54:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "586946584337719296",
  "geo" : { },
  "id_str" : "586947010084925440",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yr welcome, if u want to see list check http:\/\/t.co\/feVV1F8lKr",
  "id" : 586947010084925440,
  "in_reply_to_status_id" : 586946584337719296,
  "created_at" : "2015-04-11 17:40:46 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/roNpf3n15x",
      "expanded_url" : "http:\/\/ltr.sagepub.com\/content\/early\/2014\/12\/08\/1362168814559798.abstract?rss=1",
      "display_url" : "ltr.sagepub.com\/content\/early\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "586939139645317120",
  "geo" : { },
  "id_str" : "586946276295606274",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hi are u aware of more recent PV list for pedgogical use? http:\/\/t.co\/roNpf3n15x",
  "id" : 586946276295606274,
  "in_reply_to_status_id" : 586939139645317120,
  "created_at" : "2015-04-11 17:37:51 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aaal2015",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "tesol",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/k4fL5cbuBQ",
      "expanded_url" : "http:\/\/bit.ly\/1aAiaBI",
      "display_url" : "bit.ly\/1aAiaBI"
    } ]
  },
  "geo" : { },
  "id_str" : "586944313164169217",
  "text" : "RT @leoselivan: New on Leoxicon: #aaal2015 highlights, insights &amp; implications http:\/\/t.co\/k4fL5cbuBQ -report fr biggest Appl Ling event of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aaal2015",
        "indices" : [ 17, 26 ]
      }, {
        "text" : "tesol",
        "indices" : [ 137, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/k4fL5cbuBQ",
        "expanded_url" : "http:\/\/bit.ly\/1aAiaBI",
        "display_url" : "bit.ly\/1aAiaBI"
      } ]
    },
    "geo" : { },
    "id_str" : "586939139645317120",
    "text" : "New on Leoxicon: #aaal2015 highlights, insights &amp; implications http:\/\/t.co\/k4fL5cbuBQ -report fr biggest Appl Ling event of the year #tesol",
    "id" : 586939139645317120,
    "created_at" : "2015-04-11 17:09:30 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 586944313164169217,
  "created_at" : "2015-04-11 17:30:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/TlTNFirQ3S",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/jfAewZedFPT",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "586764802258636800",
  "geo" : { },
  "id_str" : "586884437922701313",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock right thanks btw here are 2 other corpus based tools u may be interested in https:\/\/t.co\/TlTNFirQ3S",
  "id" : 586884437922701313,
  "in_reply_to_status_id" : 586764802258636800,
  "created_at" : "2015-04-11 13:32:08 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586644031750459393",
  "geo" : { },
  "id_str" : "586650424154972162",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock nice, did they mention when plugin will be released?",
  "id" : 586650424154972162,
  "in_reply_to_status_id" : 586644031750459393,
  "created_at" : "2015-04-10 22:02:15 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586637576775278593",
  "geo" : { },
  "id_str" : "586640520648196097",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard enjoy :) hopefully can catch a John Fanselow session in the future",
  "id" : 586640520648196097,
  "in_reply_to_status_id" : 586637576775278593,
  "created_at" : "2015-04-10 21:22:54 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586620408041988096",
  "geo" : { },
  "id_str" : "586640021488295937",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle u r most welcome Mike, look fwd to more of your coding advenures :)",
  "id" : 586640021488295937,
  "in_reply_to_status_id" : 586620408041988096,
  "created_at" : "2015-04-10 21:20:55 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 75, 88 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/GHOvKFX4X0",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-yF",
      "display_url" : "wp.me\/pKFOt-yF"
    } ]
  },
  "geo" : { },
  "id_str" : "586613542419324928",
  "text" : "Preparing for iTDi's course with John Fanselow: http:\/\/t.co\/GHOvKFX4X0 via @rosemerebard",
  "id" : 586613542419324928,
  "created_at" : "2015-04-10 19:35:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 0, 8 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "Miguel CorDi",
      "screen_name" : "MigueCorDi",
      "indices" : [ 9, 20 ],
      "id_str" : "1027073124",
      "id" : 1027073124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586597157878296576",
  "in_reply_to_user_id" : 3152637711,
  "text" : "@taw_sig @MigueCorDi thx for sharing hope u have a good w\/e :)",
  "id" : 586597157878296576,
  "created_at" : "2015-04-10 18:30:35 +0000",
  "in_reply_to_screen_name" : "taw_sig",
  "in_reply_to_user_id_str" : "3152637711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/evKsYw1A0T",
      "expanded_url" : "http:\/\/www.easytweets.net",
      "display_url" : "easytweets.net"
    } ]
  },
  "in_reply_to_status_id_str" : "586589796845387777",
  "geo" : { },
  "id_str" : "586596926197489666",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta thanks for share Natallia fyi the working link shld be http:\/\/t.co\/evKsYw1A0T forgot to update on twitter-WP link",
  "id" : 586596926197489666,
  "in_reply_to_status_id" : 586589796845387777,
  "created_at" : "2015-04-10 18:29:40 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 13, 23 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 24, 35 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586580590373302273",
  "geo" : { },
  "id_str" : "586595687124598784",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @jo_sayers @lexicoloco are there many CC corpora?",
  "id" : 586595687124598784,
  "in_reply_to_status_id" : 586580590373302273,
  "created_at" : "2015-04-10 18:24:44 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "auselt",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 107, 118 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/aLgaulEeEo",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-UY",
      "display_url" : "wp.me\/pgHyE-UY"
    } ]
  },
  "geo" : { },
  "id_str" : "586579496263929856",
  "text" : "Grassroots language technology: Mike Boyle, easytweets  http:\/\/t.co\/aLgaulEeEo  #eltchat #keltchat #auselt #eltchinwag #IATEFL",
  "id" : 586579496263929856,
  "created_at" : "2015-04-10 17:20:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/GwiLUivF5G",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/04\/27\/stringnet-exploring-will-suit-you\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/04\/27\/str\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "586463195239469056",
  "geo" : { },
  "id_str" : "586568710309212160",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock hi have a post about stringnet https:\/\/t.co\/GwiLUivF5G , what is the 3D glasses plugin?",
  "id" : 586568710309212160,
  "in_reply_to_status_id" : 586463195239469056,
  "created_at" : "2015-04-10 16:37:33 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 3, 17 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586568246809206784",
  "text" : "RT @Glenn_Hadikin: really enjoying #engcorpora2015 - interesting talks and great organisation here in sunny Paris.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "engcorpora2015",
        "indices" : [ 16, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586420774770081792",
    "text" : "really enjoying #engcorpora2015 - interesting talks and great organisation here in sunny Paris.",
    "id" : 586420774770081792,
    "created_at" : "2015-04-10 06:49:42 +0000",
    "user" : {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "protected" : false,
      "id_str" : "24455799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451444841910530052\/M3o_yNR1_normal.jpeg",
      "id" : 24455799,
      "verified" : false
    }
  },
  "id" : 586568246809206784,
  "created_at" : "2015-04-10 16:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 11, 22 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/EAzUIh4j7o",
      "expanded_url" : "http:\/\/yohasebe.com\/tcse\/",
      "display_url" : "yohasebe.com\/tcse\/"
    } ]
  },
  "in_reply_to_status_id_str" : "586553055249825792",
  "geo" : { },
  "id_str" : "586556734782713856",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @lexicoloco i guess you can include TED talks as creative commons? interface for that http:\/\/t.co\/EAzUIh4j7o",
  "id" : 586556734782713856,
  "in_reply_to_status_id" : 586553055249825792,
  "created_at" : "2015-04-10 15:49:57 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/586468746476261376\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/4GvMzNjxS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCOON1oUwAA4uBD.jpg",
      "id_str" : "586468744873951232",
      "id" : 586468744873951232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCOON1oUwAA4uBD.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/4GvMzNjxS2"
    } ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586555867224485888",
  "text" : "RT @taw_sig: We think teachers rock+we want a conversation about working conditions - if u agree RT! #IATEFL http:\/\/t.co\/4GvMzNjxS2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/586468746476261376\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/4GvMzNjxS2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCOON1oUwAA4uBD.jpg",
        "id_str" : "586468744873951232",
        "id" : 586468744873951232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCOON1oUwAA4uBD.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/4GvMzNjxS2"
      } ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586468746476261376",
    "text" : "We think teachers rock+we want a conversation about working conditions - if u agree RT! #IATEFL http:\/\/t.co\/4GvMzNjxS2",
    "id" : 586468746476261376,
    "created_at" : "2015-04-10 10:00:19 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 586555867224485888,
  "created_at" : "2015-04-10 15:46:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586535815506960384",
  "geo" : { },
  "id_str" : "586536870894514177",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers Wikipedia?",
  "id" : 586536870894514177,
  "in_reply_to_status_id" : 586535815506960384,
  "created_at" : "2015-04-10 14:31:02 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586536316055216128",
  "text" : "RT @RudyLoock: End of #engcorpora2015, an excellent conference! Congrats to organizers L. Gournay and L. Dufaye!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "engcorpora2015",
        "indices" : [ 7, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586535242946764800",
    "text" : "End of #engcorpora2015, an excellent conference! Congrats to organizers L. Gournay and L. Dufaye!",
    "id" : 586535242946764800,
    "created_at" : "2015-04-10 14:24:33 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 586536316055216128,
  "created_at" : "2015-04-10 14:28:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586536075692244992\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/mwYb3Elxu6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCPLcqgVEAAV3pY.jpg",
      "id_str" : "586536069794959360",
      "id" : 586536069794959360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCPLcqgVEAAV3pY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mwYb3Elxu6"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586536075692244992",
  "text" : "#engcorpora2015 organisers Lucie Gournay, Lionel Dufaye wrapping up end of conf http:\/\/t.co\/mwYb3Elxu6",
  "id" : 586536075692244992,
  "created_at" : "2015-04-10 14:27:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586532313007267840\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/tBFCV9JnKW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCPIB5uUsAAi6LD.jpg",
      "id_str" : "586532311488835584",
      "id" : 586532311488835584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCPIB5uUsAAi6LD.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tBFCV9JnKW"
    } ],
    "hashtags" : [ {
      "text" : "like",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "engcorpora2015",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586532313007267840",
  "text" : "Tita Kyriacopoulou local grammars #like regex with superpowers\" #engcorpora2015 http:\/\/t.co\/tBFCV9JnKW",
  "id" : 586532313007267840,
  "created_at" : "2015-04-10 14:12:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586531524037718018\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ghUcGY2DER",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCPHT8WUEAAKm37.jpg",
      "id_str" : "586531521919455232",
      "id" : 586531521919455232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCPHT8WUEAAKm37.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ghUcGY2DER"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586531524037718018",
  "text" : "Tita Kyriacopoulou Unitext corpus processing suite #engcorpora2015 http:\/\/t.co\/ghUcGY2DER",
  "id" : 586531524037718018,
  "created_at" : "2015-04-10 14:09:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586516563538403330",
  "geo" : { },
  "id_str" : "586529263635005440",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle if u have any Qs fire away :)",
  "id" : 586529263635005440,
  "in_reply_to_status_id" : 586516563538403330,
  "created_at" : "2015-04-10 14:00:48 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586519218792878080",
  "geo" : { },
  "id_str" : "586528984093065217",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thx for sharing efcamdat post enjoy #IATEFL :)",
  "id" : 586528984093065217,
  "in_reply_to_status_id" : 586519218792878080,
  "created_at" : "2015-04-10 13:59:41 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586525773340770304\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/dZJ4EJXQxG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCPCFQFVIAE-Oq-.jpg",
      "id_str" : "586525771960754177",
      "id" : 586525771960754177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCPCFQFVIAE-Oq-.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dZJ4EJXQxG"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/WaPTvtQAcL",
      "expanded_url" : "http:\/\/textopol.u-pec.fr\/text",
      "display_url" : "textopol.u-pec.fr\/text"
    } ]
  },
  "geo" : { },
  "id_str" : "586525773340770304",
  "text" : "Jean-Marc Leblanc, Marie Peres Text observer workshop http:\/\/t.co\/WaPTvtQAcL observer #engcorpora2015 http:\/\/t.co\/dZJ4EJXQxG",
  "id" : 586525773340770304,
  "created_at" : "2015-04-10 13:46:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586515700694568961",
  "geo" : { },
  "id_str" : "586517832868958208",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco woah that means a lot coming from u Diane thank you hope ur having a good Friday am enjoying #engcorpora2015 :)",
  "id" : 586517832868958208,
  "in_reply_to_status_id" : 586515700694568961,
  "created_at" : "2015-04-10 13:15:22 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 12, 21 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 22, 34 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    }, {
      "name" : "David Dodgson",
      "screen_name" : "DaveDodgson",
      "indices" : [ 35, 47 ],
      "id_str" : "112962705",
      "id" : 112962705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/eucL96YQIY",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/09\/16\/getting-learner-data-for-vocabulary-activities-efcamdat\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/09\/16\/get\u2026"
    }, {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/S8Glp9TVkS",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/09\/19\/counting-countability-efcamdat\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/09\/19\/cou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "586505857862656000",
  "geo" : { },
  "id_str" : "586513733368815616",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @heyboyle @NewbieCELTA @DaveDodgson hi posted ways to use this https:\/\/t.co\/eucL96YQIY, https:\/\/t.co\/S8Glp9TVkS",
  "id" : 586513733368815616,
  "in_reply_to_status_id" : 586505857862656000,
  "created_at" : "2015-04-10 12:59:05 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/KTei0qSlvR",
      "expanded_url" : "http:\/\/ucts.uniba.sk",
      "display_url" : "ucts.uniba.sk"
    } ]
  },
  "in_reply_to_status_id_str" : "586509515245359104",
  "geo" : { },
  "id_str" : "586510690732638208",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava http:\/\/t.co\/KTei0qSlvR",
  "id" : 586510690732638208,
  "in_reply_to_status_id" : 586509515245359104,
  "created_at" : "2015-04-10 12:47:00 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586509515245359104\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/ENpBVq1t8w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCOzS3fUsAEAKEp.jpg",
      "id_str" : "586509513202642945",
      "id" : 586509513202642945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCOzS3fUsAEAKEp.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ENpBVq1t8w"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586509515245359104",
  "text" : "Vladimir Benko Global English no sketch engine corpus #engcorpora2015 http:\/\/t.co\/ENpBVq1t8w",
  "id" : 586509515245359104,
  "created_at" : "2015-04-10 12:42:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/l8LuAQ22is",
      "expanded_url" : "http:\/\/wordandphrase.info",
      "display_url" : "wordandphrase.info"
    } ]
  },
  "geo" : { },
  "id_str" : "586501793988902912",
  "text" : "Mark Davies students can use http:\/\/t.co\/l8LuAQ22is to look for similar structures using phrase search feature #engcorpora2015",
  "id" : 586501793988902912,
  "created_at" : "2015-04-10 12:11:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586491762140655616\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/foMELl2GtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCOjJKkUIAAtPPy.jpg",
      "id_str" : "586491754339115008",
      "id" : 586491754339115008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCOjJKkUIAAtPPy.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/foMELl2GtJ"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586491762140655616",
  "text" : "Mark Davies Coca BYU workshop #engcorpora2015 http:\/\/t.co\/foMELl2GtJ",
  "id" : 586491762140655616,
  "created_at" : "2015-04-10 11:31:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m_paradowski",
      "screen_name" : "m_paradowski",
      "indices" : [ 0, 13 ],
      "id_str" : "15028542",
      "id" : 15028542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Y0BCMKMND9",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2014\/04\/06\/iatefl-harrogate-2014-mitra-having-a-jelly-good-time\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/04\/06\/iat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "586279699074125824",
  "geo" : { },
  "id_str" : "586380890663559169",
  "in_reply_to_user_id" : 15028542,
  "text" : "@m_paradowski hi Micha\u0142 yr welcome sorry bout font my phone let me down! thx more recent post on the big M https:\/\/t.co\/Y0BCMKMND9",
  "id" : 586380890663559169,
  "in_reply_to_status_id" : 586279699074125824,
  "created_at" : "2015-04-10 04:11:13 +0000",
  "in_reply_to_screen_name" : "m_paradowski",
  "in_reply_to_user_id_str" : "15028542",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586219737895559168",
  "geo" : { },
  "id_str" : "586221423653421057",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug what was the paper?",
  "id" : 586221423653421057,
  "in_reply_to_status_id" : 586219737895559168,
  "created_at" : "2015-04-09 17:37:33 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586181844116369408\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xKPksBgmsx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKJR9BWAAAEBgN.jpg",
      "id_str" : "586181843042566144",
      "id" : 586181843042566144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKJR9BWAAAEBgN.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xKPksBgmsx"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586181844116369408",
  "text" : "Micha\u00EE B Paradowski difficult to translate dishes #engcorpora2015 http:\/\/t.co\/xKPksBgmsx",
  "id" : 586181844116369408,
  "created_at" : "2015-04-09 15:00:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586177861352083456\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/8tcJIVUbOA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKFqHyWMAIw5QW.jpg",
      "id_str" : "586177860202803202",
      "id" : 586177860202803202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKFqHyWMAIw5QW.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8tcJIVUbOA"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586177861352083456",
  "text" : "Micha\u00EE B Paradowski importance of spacing #engcorpora2015 http:\/\/t.co\/8tcJIVUbOA",
  "id" : 586177861352083456,
  "created_at" : "2015-04-09 14:44:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586176440141533184\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/xq0lIIDPeP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKEXZ-WMAAemKS.jpg",
      "id_str" : "586176439155830784",
      "id" : 586176439155830784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKEXZ-WMAAemKS.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xq0lIIDPeP"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586176440141533184",
  "text" : "Micha\u00EE B Paradowski genre corpora in lang &amp; trans training #engcorpora2015 http:\/\/t.co\/xq0lIIDPeP",
  "id" : 586176440141533184,
  "created_at" : "2015-04-09 14:38:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586168432619577345\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/dpHJkxhnRJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJ9FTVWMAABDwn.jpg",
      "id_str" : "586168431554211840",
      "id" : 586168431554211840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJ9FTVWMAABDwn.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dpHJkxhnRJ"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586168432619577345",
  "text" : "Agnes Leroux delayed vs immediate pedagogy use #engcorpora2015 http:\/\/t.co\/dpHJkxhnRJ",
  "id" : 586168432619577345,
  "created_at" : "2015-04-09 14:06:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586166318036099072\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/B7xuPGMENf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJ7KNpWYAEas1l.jpg",
      "id_str" : "586166316903587841",
      "id" : 586166316903587841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJ7KNpWYAEas1l.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/B7xuPGMENf"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586166318036099072",
  "text" : "Agnes Leroux French uses of temporal for question hyp #engcorpora2015 http:\/\/t.co\/B7xuPGMENf",
  "id" : 586166318036099072,
  "created_at" : "2015-04-09 13:58:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 16, 30 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586156065789714433\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/YdOxwfsBUr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJx1atW8AANpRK.jpg",
      "id_str" : "586156064028160000",
      "id" : 586156064028160000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJx1atW8AANpRK.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YdOxwfsBUr"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586156065789714433",
  "text" : "#engcorpora2015 @Glenn_Hadikin John Williams lexical selection model http:\/\/t.co\/YdOxwfsBUr",
  "id" : 586156065789714433,
  "created_at" : "2015-04-09 13:17:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 30, 44 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586155011484340224\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/8FTehlHDsH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJw4CGXIAAPa8d.jpg",
      "id_str" : "586155009450123264",
      "id" : 586155009450123264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJw4CGXIAAPa8d.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8FTehlHDsH"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586155011484340224",
  "text" : "#engcorpora2015 John Williams @Glenn_Hadikin OR main function http:\/\/t.co\/8FTehlHDsH",
  "id" : 586155011484340224,
  "created_at" : "2015-04-09 13:13:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 16, 30 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586151181879238657\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/O02Ue4WF9v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJtZK3W8AAsWgp.jpg",
      "id_str" : "586151180692287488",
      "id" : 586151180692287488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJtZK3W8AAsWgp.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O02Ue4WF9v"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586151181879238657",
  "text" : "#engcorpora2015 @Glenn_Hadikin John Williams lang issues in citizen sci http:\/\/t.co\/O02Ue4WF9v",
  "id" : 586151181879238657,
  "created_at" : "2015-04-09 12:58:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 16, 30 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586149525775065088\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/87e1CWwE1z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJr4k7WEAMwbpQ.jpg",
      "id_str" : "586149521241018371",
      "id" : 586149521241018371,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJr4k7WEAMwbpQ.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/87e1CWwE1z"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586149525775065088",
  "text" : "#engcorpora2015 @Glenn_Hadikin John Williams Zooniverse http:\/\/t.co\/87e1CWwE1z",
  "id" : 586149525775065088,
  "created_at" : "2015-04-09 12:51:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 30, 44 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586148447725744128\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/EVBgPgwWsv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJq5yTXIAAJ8qt.jpg",
      "id_str" : "586148442499653632",
      "id" : 586148442499653632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJq5yTXIAAJ8qt.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EVBgPgwWsv"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586148447725744128",
  "text" : "#engcorpora2015 John Williams @Glenn_Hadikin citizen science http:\/\/t.co\/EVBgPgwWsv",
  "id" : 586148447725744128,
  "created_at" : "2015-04-09 12:47:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 16, 26 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586144077546180608\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/24KhMvL6SE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJm7ptXIAASgrg.jpg",
      "id_str" : "586144076506013696",
      "id" : 586144076506013696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJm7ptXIAASgrg.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/24KhMvL6SE"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586144077546180608",
  "text" : "#engcorpora2015 @RudyLoock diy comp corpora conclusions http:\/\/t.co\/24KhMvL6SE",
  "id" : 586144077546180608,
  "created_at" : "2015-04-09 12:30:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 16, 26 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586143431791083520\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/POHHarsDq0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJmWA_WAAAhbfl.jpg",
      "id_str" : "586143429920423936",
      "id" : 586143429920423936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJmWA_WAAAhbfl.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/POHHarsDq0"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586143431791083520",
  "text" : "#engcorpora2015 @RudyLoock quotations in eng\/fr press txts http:\/\/t.co\/POHHarsDq0",
  "id" : 586143431791083520,
  "created_at" : "2015-04-09 12:27:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 16, 26 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586142595061051392\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/dTsKkwMmaN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJllVIWEAAkuk8.jpg",
      "id_str" : "586142593513295872",
      "id" : 586142593513295872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJllVIWEAAkuk8.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dTsKkwMmaN"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586142595061051392",
  "text" : "#engcorpora2015 @RudyLoock some results of translating sts use of necrocorpus http:\/\/t.co\/dTsKkwMmaN",
  "id" : 586142595061051392,
  "created_at" : "2015-04-09 12:24:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 16, 26 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586141405141213184\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/BRuGE3SWXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJkUsZWgAEpSqa.jpg",
      "id_str" : "586141208189239297",
      "id" : 586141208189239297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJkUsZWgAEpSqa.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BRuGE3SWXh"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586141405141213184",
  "text" : "#engcorpora2015 @RudyLoock sts compiled an obit corpus of celebs http:\/\/t.co\/BRuGE3SWXh",
  "id" : 586141405141213184,
  "created_at" : "2015-04-09 12:19:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586113400620634112\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/xRbgGRPSNi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJLB_hWgAAiGDG.jpg",
      "id_str" : "586113399114858496",
      "id" : 586113399114858496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJLB_hWgAAiGDG.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xRbgGRPSNi"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586113400620634112",
  "text" : "Pavel Hucka conclusion #engcorpora2015 http:\/\/t.co\/xRbgGRPSNi",
  "id" : 586113400620634112,
  "created_at" : "2015-04-09 10:28:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586111612098113536\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/KyxWKobHrq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJJZ5oW4AEDgCr.jpg",
      "id_str" : "586111610827235329",
      "id" : 586111610827235329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJJZ5oW4AEDgCr.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KyxWKobHrq"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586111612098113536",
  "text" : "Pavel Hucka conglomerates #engcorpora2015 http:\/\/t.co\/KyxWKobHrq",
  "id" : 586111612098113536,
  "created_at" : "2015-04-09 10:21:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586100569430949888\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/IEDTXd7xAS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCI_XG1WYAA1VK3.jpg",
      "id_str" : "586100567715504128",
      "id" : 586100567715504128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCI_XG1WYAA1VK3.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IEDTXd7xAS"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586100569430949888",
  "text" : "Natalie Kubler complex lang units in ESP #engcorpora2015 http:\/\/t.co\/IEDTXd7xAS",
  "id" : 586100569430949888,
  "created_at" : "2015-04-09 09:37:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586088973359042560\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/9tQ3VFTNAL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCI00D0WIAAOxUQ.jpg",
      "id_str" : "586088970494287872",
      "id" : 586088970494287872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCI00D0WIAAOxUQ.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9tQ3VFTNAL"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586088973359042560",
  "text" : "Antoinette Renouf summary role of hapaxes #engcorpora2015 http:\/\/t.co\/9tQ3VFTNAL",
  "id" : 586088973359042560,
  "created_at" : "2015-04-09 08:51:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586082535907729408\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/0VEw1s78R1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCIu9a0W0AA1Ey7.jpg",
      "id_str" : "586082534217404416",
      "id" : 586082534217404416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCIu9a0W0AA1Ey7.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0VEw1s78R1"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586082535907729408",
  "text" : "Antoinette Renouf ity hapax blends #engcorpora2015 http:\/\/t.co\/0VEw1s78R1",
  "id" : 586082535907729408,
  "created_at" : "2015-04-09 08:25:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586081493086244864\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/JAOioMraGr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCIuAvrWAAA21aZ.jpg",
      "id_str" : "586081491844726784",
      "id" : 586081491844726784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCIuAvrWAAA21aZ.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JAOioMraGr"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586081493086244864",
  "text" : "Antoinette Renouf lexical productivity hapex affixes #engcorpora2015 http:\/\/t.co\/JAOioMraGr",
  "id" : 586081493086244864,
  "created_at" : "2015-04-09 08:21:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586079850101923841\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/iKoiG6KRm5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCIshHxWgAAsnzH.jpg",
      "id_str" : "586079849044934656",
      "id" : 586079849044934656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCIshHxWgAAsnzH.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iKoiG6KRm5"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 33, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586079850101923841",
  "text" : "Antoinette Renouf hapexes parsed #engcorpora2015 http:\/\/t.co\/iKoiG6KRm5",
  "id" : 586079850101923841,
  "created_at" : "2015-04-09 08:14:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586079513395798017\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Vl3PoCCQPW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCIsNhKW0AA-230.jpg",
      "id_str" : "586079512263315456",
      "id" : 586079512263315456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCIsNhKW0AA-230.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Vl3PoCCQPW"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586079513395798017",
  "text" : "Antoinette Renouf yo Chomsky explanatory principles in corp ling #engcorpora2015 http:\/\/t.co\/Vl3PoCCQPW",
  "id" : 586079513395798017,
  "created_at" : "2015-04-09 08:13:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/586078627185483776\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/SVsvE7Yqc7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCIrZ8gW0AAn3gs.jpg",
      "id_str" : "586078626250149888",
      "id" : 586078626250149888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCIrZ8gW0AAn3gs.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SVsvE7Yqc7"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 52, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586078627185483776",
  "text" : "Antoinette Renouf lexicological hyp testing history #engcorpora2015 http:\/\/t.co\/SVsvE7Yqc7",
  "id" : 586078627185483776,
  "created_at" : "2015-04-09 08:10:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Ferrario",
      "screen_name" : "FreeEnglishMFY",
      "indices" : [ 0, 15 ],
      "id_str" : "732820218",
      "id" : 732820218
    }, {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 16, 31 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586059520935239680",
  "geo" : { },
  "id_str" : "586060808876138497",
  "in_reply_to_user_id" : 732820218,
  "text" : "@FreeEnglishMFY @linkstoenglish by contrast the second mouse gets the cheese :)",
  "id" : 586060808876138497,
  "in_reply_to_status_id" : 586059520935239680,
  "created_at" : "2015-04-09 06:59:19 +0000",
  "in_reply_to_screen_name" : "FreeEnglishMFY",
  "in_reply_to_user_id_str" : "732820218",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 7, 21 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 22, 34 ],
      "id_str" : "1632891",
      "id" : 1632891
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 93, 104 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/YlOEJ5N5Qw",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2012\/ken-robinson-the-learning-revolution\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2012\/ken-robin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "586052026003496960",
  "geo" : { },
  "id_str" : "586057025316065281",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @NicolaPrentis @DonaldClark hi would recommend this as well http:\/\/t.co\/YlOEJ5N5Qw by @tornhalves",
  "id" : 586057025316065281,
  "in_reply_to_status_id" : 586052026003496960,
  "created_at" : "2015-04-09 06:44:17 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/wrIFnMo68J",
      "expanded_url" : "http:\/\/theweek.com\/articles\/548308\/what-talk-about-when-talk-about-word-copulation",
      "display_url" : "theweek.com\/articles\/54830\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586048046733070336",
  "text" : "What we talk about when we talk about (word) copulation http:\/\/t.co\/wrIFnMo68J",
  "id" : 586048046733070336,
  "created_at" : "2015-04-09 06:08:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PauloFreire",
      "indices" : [ 16, 28 ]
    }, {
      "text" : "education",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/OM8tA2YNCp",
      "expanded_url" : "http:\/\/bit.ly\/1H4ge16",
      "display_url" : "bit.ly\/1H4ge16"
    } ]
  },
  "geo" : { },
  "id_str" : "585942234182377472",
  "text" : "RT @tornhalves: #PauloFreire pedagogy nearly 50 years on: From the banking model to the online shopping model of #education. http:\/\/t.co\/OM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PauloFreire",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "education",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/OM8tA2YNCp",
        "expanded_url" : "http:\/\/bit.ly\/1H4ge16",
        "display_url" : "bit.ly\/1H4ge16"
      } ]
    },
    "geo" : { },
    "id_str" : "585795812283834369",
    "text" : "#PauloFreire pedagogy nearly 50 years on: From the banking model to the online shopping model of #education. http:\/\/t.co\/OM8tA2YNCp",
    "id" : 585795812283834369,
    "created_at" : "2015-04-08 13:26:19 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 585942234182377472,
  "created_at" : "2015-04-08 23:08:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 16, 29 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585866154322878464",
  "geo" : { },
  "id_str" : "585907816667414528",
  "in_reply_to_user_id" : 3083991707,
  "text" : "@linkstoenglish @GlenysHanson on the surface it is complex hence the fear i guess?",
  "id" : 585907816667414528,
  "in_reply_to_status_id" : 585866154322878464,
  "created_at" : "2015-04-08 20:51:23 +0000",
  "in_reply_to_screen_name" : "linkstoenglish",
  "in_reply_to_user_id_str" : "3083991707",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxane Harrison",
      "screen_name" : "roxaneharrison",
      "indices" : [ 0, 15 ],
      "id_str" : "267494842",
      "id" : 267494842
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 16, 24 ],
      "id_str" : "209484168",
      "id" : 209484168
    }, {
      "name" : "onlybooks.org",
      "screen_name" : "onlybooksorg",
      "indices" : [ 25, 38 ],
      "id_str" : "2611695462",
      "id" : 2611695462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585905156711153664",
  "geo" : { },
  "id_str" : "585905899363028992",
  "in_reply_to_user_id" : 267494842,
  "text" : "@roxaneharrison @scoopit @onlybooksorg looks a bit dodgy to me?",
  "id" : 585905899363028992,
  "in_reply_to_status_id" : 585905156711153664,
  "created_at" : "2015-04-08 20:43:46 +0000",
  "in_reply_to_screen_name" : "roxaneharrison",
  "in_reply_to_user_id_str" : "267494842",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 3, 19 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/HRekukccTg",
      "expanded_url" : "http:\/\/wp.me\/p4HLYW-c0",
      "display_url" : "wp.me\/p4HLYW-c0"
    } ]
  },
  "geo" : { },
  "id_str" : "585900890126692353",
  "text" : "RT @MarekKiczkowiak: TESOL Convention 2015 \u2013 \u2018NEST or NNEST: does it matter in pronunciation teaching?\u2019 by Marla Yoshida http:\/\/t.co\/HRekuk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/HRekukccTg",
        "expanded_url" : "http:\/\/wp.me\/p4HLYW-c0",
        "display_url" : "wp.me\/p4HLYW-c0"
      } ]
    },
    "geo" : { },
    "id_str" : "585820244935073792",
    "text" : "TESOL Convention 2015 \u2013 \u2018NEST or NNEST: does it matter in pronunciation teaching?\u2019 by Marla Yoshida http:\/\/t.co\/HRekukccTg",
    "id" : 585820244935073792,
    "created_at" : "2015-04-08 15:03:25 +0000",
    "user" : {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "protected" : false,
      "id_str" : "2561325079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476735541497450498\/KCwdjZhZ_normal.jpeg",
      "id" : 2561325079,
      "verified" : false
    }
  },
  "id" : 585900890126692353,
  "created_at" : "2015-04-08 20:23:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 3, 16 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/lWt5eGqQ7q",
      "expanded_url" : "http:\/\/www.glenys-hanson.info\/",
      "display_url" : "glenys-hanson.info"
    } ]
  },
  "geo" : { },
  "id_str" : "585855676674629632",
  "text" : "RT @GlenysHanson: Is the concept of \"phrasal verbs\" useful for English learners. Could it be more confusing than helpful? http:\/\/t.co\/lWt5e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/lWt5eGqQ7q",
        "expanded_url" : "http:\/\/www.glenys-hanson.info\/",
        "display_url" : "glenys-hanson.info"
      } ]
    },
    "geo" : { },
    "id_str" : "585853369849380865",
    "text" : "Is the concept of \"phrasal verbs\" useful for English learners. Could it be more confusing than helpful? http:\/\/t.co\/lWt5eGqQ7q",
    "id" : 585853369849380865,
    "created_at" : "2015-04-08 17:15:02 +0000",
    "user" : {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "protected" : false,
      "id_str" : "527238447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488943744226299904\/6SULCTUl_normal.png",
      "id" : 527238447,
      "verified" : false
    }
  },
  "id" : 585855676674629632,
  "created_at" : "2015-04-08 17:24:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585812705229037569\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/hzgIS5RbNO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCE5jK_WgAAg9Xs.jpg",
      "id_str" : "585812702943150080",
      "id" : 585812702943150080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCE5jK_WgAAg9Xs.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hzgIS5RbNO"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 61, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585812705229037569",
  "text" : "Brigitte Philippe Indirect speech syntactic enunciative defs #engcorpora2015 http:\/\/t.co\/hzgIS5RbNO",
  "id" : 585812705229037569,
  "created_at" : "2015-04-08 14:33:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585808326740566016\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/vKQJOMW410",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCE1kYmWEAAuiD-.jpg",
      "id_str" : "585808325729718272",
      "id" : 585808325729718272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCE1kYmWEAAuiD-.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vKQJOMW410"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585808326740566016",
  "text" : "Kimberly Oger British do #engcorpora2015 http:\/\/t.co\/vKQJOMW410",
  "id" : 585808326740566016,
  "created_at" : "2015-04-08 14:16:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585792528709984256",
  "text" : "Cesare Zanca can get lang sts to use Google image, n-gram to explore discourses #engcorpora2015",
  "id" : 585792528709984256,
  "created_at" : "2015-04-08 13:13:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585790167623008256\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/jPtgE1xa8L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCElDXBWgAA56w7.jpg",
      "id_str" : "585790166184394752",
      "id" : 585790166184394752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCElDXBWgAA56w7.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jPtgE1xa8L"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585790167623008256",
  "text" : "Cesare Zanca Diversity keywords UK press 1993 2010 #engcorpora2015 http:\/\/t.co\/jPtgE1xa8L",
  "id" : 585790167623008256,
  "created_at" : "2015-04-08 13:03:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585781624333271040\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/nKwXogRdZF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCEdSGRWIAAQ7Io.jpg",
      "id_str" : "585781623293091840",
      "id" : 585781623293091840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCEdSGRWIAAQ7Io.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nKwXogRdZF"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 29, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585781624333271040",
  "text" : "Alex Boulton DDL conclusions #engcorpora2015 http:\/\/t.co\/nKwXogRdZF",
  "id" : 585781624333271040,
  "created_at" : "2015-04-08 12:29:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585781007883886592\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/31Aoe5Iei2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCEcuIvWEAADZP6.jpg",
      "id_str" : "585781005480497152",
      "id" : 585781005480497152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCEcuIvWEAADZP6.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/31Aoe5Iei2"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 29, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585781007883886592",
  "text" : "Alex Boulton DDL effect size #engcorpora2015 http:\/\/t.co\/31Aoe5Iei2",
  "id" : 585781007883886592,
  "created_at" : "2015-04-08 12:27:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585750379603845120\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/XFINBDnjFf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCEA3YFWYAATdDo.jpg",
      "id_str" : "585750377892569088",
      "id" : 585750377892569088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCEA3YFWYAATdDo.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XFINBDnjFf"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 36, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585750379603845120",
  "text" : "I-Chung Ke pedagogical implications #engcorpora2015 http:\/\/t.co\/XFINBDnjFf",
  "id" : 585750379603845120,
  "created_at" : "2015-04-08 10:25:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585749400464527360\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/csq7g6l3cM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCD_-bOXIAAFi4E.jpg",
      "id_str" : "585749399483129856",
      "id" : 585749399483129856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCD_-bOXIAAFi4E.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/csq7g6l3cM"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585749400464527360",
  "text" : "I-Chung Ke trad corpus vs transling corpus #engcorpora2015 http:\/\/t.co\/csq7g6l3cM",
  "id" : 585749400464527360,
  "created_at" : "2015-04-08 10:21:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585746639077408768\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ClIqSNtagU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCD9dpKWMAAIwdd.jpg",
      "id_str" : "585746637265448960",
      "id" : 585746637265448960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCD9dpKWMAAIwdd.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ClIqSNtagU"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585746639077408768",
  "text" : "I-Chung Ke corpus data source #engcorpora2015 http:\/\/t.co\/ClIqSNtagU",
  "id" : 585746639077408768,
  "created_at" : "2015-04-08 10:10:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585745450105450496\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/0nq3fx7WG4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCD8YdGWMAAlPpD.jpg",
      "id_str" : "585745448616472576",
      "id" : 585745448616472576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCD8YdGWMAAlPpD.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0nq3fx7WG4"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585745450105450496",
  "text" : "I-Chung Ke Translanguaging #engcorpora2015 http:\/\/t.co\/0nq3fx7WG4",
  "id" : 585745450105450496,
  "created_at" : "2015-04-08 10:06:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585741679212290048\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/tkbsZLw4pY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCD48-6W0AAVdH-.jpg",
      "id_str" : "585741678121766912",
      "id" : 585741678121766912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCD48-6W0AAVdH-.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tkbsZLw4pY"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 75, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585741679212290048",
  "text" : "Guillaume Desagulier most productive adjective as noun phrase construction #engcorpora2015 http:\/\/t.co\/tkbsZLw4pY",
  "id" : 585741679212290048,
  "created_at" : "2015-04-08 09:51:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585738372477497345\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/4peFEYRXxS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCD18KhWYAAE713.jpg",
      "id_str" : "585738365523353600",
      "id" : 585738365523353600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCD18KhWYAAE713.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4peFEYRXxS"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585738372477497345",
  "text" : "Guillaume Desagulier Bartleby, Moby Dick vocabulary growth curve #engcorpora2015 http:\/\/t.co\/4peFEYRXxS",
  "id" : 585738372477497345,
  "created_at" : "2015-04-08 09:38:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 66, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585724314055548928",
  "text" : "Mark Davies Glowbe can compare dialectical variation in one click #engcorpora2015",
  "id" : 585724314055548928,
  "created_at" : "2015-04-08 08:42:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585722592964771840",
  "text" : "Mark Davies Recent increases in: like, so not, end up v-ing, get passive COCA #engcorpora2015",
  "id" : 585722592964771840,
  "created_at" : "2015-04-08 08:35:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585721488977846272",
  "text" : "Mark Davies COCA has same genre balance year by year #engcorpora2015",
  "id" : 585721488977846272,
  "created_at" : "2015-04-08 08:30:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585719861965430786",
  "text" : "Mark Davies large corpora like COHA show syntactic change e.g. increase in -ing 2ndry verbs #engcorpora2015",
  "id" : 585719861965430786,
  "created_at" : "2015-04-08 08:24:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585710624900050944\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/FHrQO0rUBG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCDctKHWgAEVgIA.jpg",
      "id_str" : "585710619925577729",
      "id" : 585710619925577729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCDctKHWgAEVgIA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FHrQO0rUBG"
    } ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 16, 31 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 32, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585710624900050944",
  "text" : "Registration at #engcorpora2015 #corpuslinguistics http:\/\/t.co\/FHrQO0rUBG",
  "id" : 585710624900050944,
  "created_at" : "2015-04-08 07:47:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/iICQF3nTx5",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/dLu29q5Ry7c",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    }, {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/FxcFaTpN0w",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/7mhfUphECCL",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585567352017793024",
  "text" : "my adventures in AMALGrAM 2.0 mwe tagger https:\/\/t.co\/iICQF3nTx5 &amp; https:\/\/t.co\/FxcFaTpN0w #corpuslinguistics",
  "id" : 585567352017793024,
  "created_at" : "2015-04-07 22:18:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "indices" : [ 3, 19 ],
      "id_str" : "2381084346",
      "id" : 2381084346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/amJYW9XUIe",
      "expanded_url" : "http:\/\/radicaltefl.weebly.com\/",
      "display_url" : "radicaltefl.weebly.com"
    } ]
  },
  "geo" : { },
  "id_str" : "585528510069997568",
  "text" : "RT @RichardSmithELT: Online annual bulletin - Radical TEFL - http:\/\/t.co\/amJYW9XUIe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/amJYW9XUIe",
        "expanded_url" : "http:\/\/radicaltefl.weebly.com\/",
        "display_url" : "radicaltefl.weebly.com"
      } ]
    },
    "geo" : { },
    "id_str" : "585489419471364096",
    "text" : "Online annual bulletin - Radical TEFL - http:\/\/t.co\/amJYW9XUIe.",
    "id" : 585489419471364096,
    "created_at" : "2015-04-07 17:08:50 +0000",
    "user" : {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "protected" : false,
      "id_str" : "2381084346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442784228007112704\/0oKivCvx_normal.jpeg",
      "id" : 2381084346,
      "verified" : false
    }
  },
  "id" : 585528510069997568,
  "created_at" : "2015-04-07 19:44:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "dystopia",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/2ZnIPVI0Ih",
      "expanded_url" : "http:\/\/bbc.in\/1JjIDzJ",
      "display_url" : "bbc.in\/1JjIDzJ"
    } ]
  },
  "geo" : { },
  "id_str" : "585406134359588864",
  "text" : "RT @tornhalves: The invention of smart technology was also the invention of idiotic waste. #edtech #dystopia http:\/\/t.co\/2ZnIPVI0Ih",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 75, 82 ]
      }, {
        "text" : "dystopia",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/2ZnIPVI0Ih",
        "expanded_url" : "http:\/\/bbc.in\/1JjIDzJ",
        "display_url" : "bbc.in\/1JjIDzJ"
      } ]
    },
    "geo" : { },
    "id_str" : "585393115269308416",
    "text" : "The invention of smart technology was also the invention of idiotic waste. #edtech #dystopia http:\/\/t.co\/2ZnIPVI0Ih",
    "id" : 585393115269308416,
    "created_at" : "2015-04-07 10:46:09 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 585406134359588864,
  "created_at" : "2015-04-07 11:37:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585085045968371712",
  "geo" : { },
  "id_str" : "585096415828914176",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler that's nice way to put Chomksy's distinction between thought and speech :)",
  "id" : 585096415828914176,
  "in_reply_to_status_id" : 585085045968371712,
  "created_at" : "2015-04-06 15:07:10 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585054067296174080",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thx for sharing interview, yes paperback is reasonably priced",
  "id" : 585054067296174080,
  "created_at" : "2015-04-06 12:18:54 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/585048632832958465\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UWIYhnPeXP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB6CoY3W4AAjSr6.png",
      "id_str" : "585048631985758208",
      "id" : 585048631985758208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB6CoY3W4AAjSr6.png",
      "sizes" : [ {
        "h" : 132,
        "resize" : "fit",
        "w" : 362
      }, {
        "h" : 132,
        "resize" : "crop",
        "w" : 132
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 362
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 362
      } ],
      "display_url" : "pic.twitter.com\/UWIYhnPeXP"
    } ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 52, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585048632832958465",
  "text" : "uh-oh maybe this explains some of the low uptake of #corpuslinguistics amongst teachers? :) http:\/\/t.co\/UWIYhnPeXP",
  "id" : 585048632832958465,
  "created_at" : "2015-04-06 11:57:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svetlana Lupasco",
      "screen_name" : "StanzaSL",
      "indices" : [ 3, 12 ],
      "id_str" : "787705808",
      "id" : 787705808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "cdnesl",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/5gH5bRDbfw",
      "expanded_url" : "http:\/\/bit.ly\/1HGZjjg",
      "display_url" : "bit.ly\/1HGZjjg"
    } ]
  },
  "geo" : { },
  "id_str" : "585044901877964800",
  "text" : "RT @StanzaSL: EdITLib is a digital library of the latest peer-reviewed research and presentations on #edtech http:\/\/t.co\/5gH5bRDbfw #cdnesl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 87, 94 ]
      }, {
        "text" : "cdnesl",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5gH5bRDbfw",
        "expanded_url" : "http:\/\/bit.ly\/1HGZjjg",
        "display_url" : "bit.ly\/1HGZjjg"
      } ]
    },
    "geo" : { },
    "id_str" : "585042153820262400",
    "text" : "EdITLib is a digital library of the latest peer-reviewed research and presentations on #edtech http:\/\/t.co\/5gH5bRDbfw #cdnesl",
    "id" : 585042153820262400,
    "created_at" : "2015-04-06 11:31:33 +0000",
    "user" : {
      "name" : "Svetlana Lupasco",
      "screen_name" : "StanzaSL",
      "protected" : false,
      "id_str" : "787705808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640181035234422784\/XBf6w9zV_normal.jpg",
      "id" : 787705808,
      "verified" : false
    }
  },
  "id" : 585044901877964800,
  "created_at" : "2015-04-06 11:42:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svetlana Lupasco",
      "screen_name" : "StanzaSL",
      "indices" : [ 0, 9 ],
      "id_str" : "787705808",
      "id" : 787705808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/8YDAWSGTan",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/elt-research-open-access-repositories-and-directories\/",
      "display_url" : "eflnotes.wordpress.com\/elt-research-o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "585042153820262400",
  "geo" : { },
  "id_str" : "585044826405662720",
  "in_reply_to_user_id" : 787705808,
  "text" : "@StanzaSL nice thanks added to repos and directory page https:\/\/t.co\/8YDAWSGTan",
  "id" : 585044826405662720,
  "in_reply_to_status_id" : 585042153820262400,
  "created_at" : "2015-04-06 11:42:10 +0000",
  "in_reply_to_screen_name" : "StanzaSL",
  "in_reply_to_user_id_str" : "787705808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/UokETesugq",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/04\/making-lessons-authentic-via-use-of.html",
      "display_url" : "how-i-see-it-now.blogspot.com\/2015\/04\/making\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585005824281415680",
  "text" : "RT @HanaTicha: Making lessons authentic via the use of corpora http:\/\/t.co\/UokETesugq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/UokETesugq",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2015\/04\/making-lessons-authentic-via-use-of.html",
        "display_url" : "how-i-see-it-now.blogspot.com\/2015\/04\/making\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "585003975805689856",
    "text" : "Making lessons authentic via the use of corpora http:\/\/t.co\/UokETesugq",
    "id" : 585003975805689856,
    "created_at" : "2015-04-06 08:59:51 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 585005824281415680,
  "created_at" : "2015-04-06 09:07:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "indices" : [ 3, 13 ],
      "id_str" : "303905601",
      "id" : 303905601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mfltwitterati",
      "indices" : [ 82, 96 ]
    }, {
      "text" : "langchat",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "TPRS",
      "indices" : [ 107, 112 ]
    }, {
      "text" : "aimlang",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/dY7EOKAiMl",
      "expanded_url" : "http:\/\/www.frenchteacher.net\/teachers-guide\/using-film\/",
      "display_url" : "frenchteacher.net\/teachers-guide\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584923998288478208",
  "text" : "RT @spsmith45: Many ways to use texts in the MFL classroom http:\/\/t.co\/dY7EOKAiMl #mfltwitterati #langchat #TPRS #aimlang",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mfltwitterati",
        "indices" : [ 67, 81 ]
      }, {
        "text" : "langchat",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "TPRS",
        "indices" : [ 92, 97 ]
      }, {
        "text" : "aimlang",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/dY7EOKAiMl",
        "expanded_url" : "http:\/\/www.frenchteacher.net\/teachers-guide\/using-film\/",
        "display_url" : "frenchteacher.net\/teachers-guide\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "584734864764612610",
    "text" : "Many ways to use texts in the MFL classroom http:\/\/t.co\/dY7EOKAiMl #mfltwitterati #langchat #TPRS #aimlang",
    "id" : 584734864764612610,
    "created_at" : "2015-04-05 15:10:30 +0000",
    "user" : {
      "name" : "Steve Smith",
      "screen_name" : "spsmith45",
      "protected" : false,
      "id_str" : "303905601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766281389037813760\/eXdJEsQr_normal.jpg",
      "id" : 303905601,
      "verified" : false
    }
  },
  "id" : 584923998288478208,
  "created_at" : "2015-04-06 03:42:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 32, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/MnFPi2GvdD",
      "expanded_url" : "http:\/\/easytweets.herokuapp.com\/",
      "display_url" : "easytweets.herokuapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "584920838647996416",
  "text" : "RT @heyboyle: Want a peek at my #ELT site that filters tweets by topic and level? Here's the beta: http:\/\/t.co\/MnFPi2GvdD Let me know what \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 18, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/MnFPi2GvdD",
        "expanded_url" : "http:\/\/easytweets.herokuapp.com\/",
        "display_url" : "easytweets.herokuapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "584769303855116288",
    "text" : "Want a peek at my #ELT site that filters tweets by topic and level? Here's the beta: http:\/\/t.co\/MnFPi2GvdD Let me know what you think!",
    "id" : 584769303855116288,
    "created_at" : "2015-04-05 17:27:21 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 584920838647996416,
  "created_at" : "2015-04-06 03:29:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 3, 15 ],
      "id_str" : "273375532",
      "id" : 273375532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/IBBDxpJmZJ",
      "expanded_url" : "https:\/\/medium.com\/aj-news\/not-fit-to-print-when-good-design-goes-bad-cc52931a2ce0",
      "display_url" : "medium.com\/aj-news\/not-fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584749562050523136",
  "text" : "RT @FryRsquared: A lesson from the New York Times on how to mislead with numbers: https:\/\/t.co\/IBBDxpJmZJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/IBBDxpJmZJ",
        "expanded_url" : "https:\/\/medium.com\/aj-news\/not-fit-to-print-when-good-design-goes-bad-cc52931a2ce0",
        "display_url" : "medium.com\/aj-news\/not-fi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "584648439125925889",
    "text" : "A lesson from the New York Times on how to mislead with numbers: https:\/\/t.co\/IBBDxpJmZJ",
    "id" : 584648439125925889,
    "created_at" : "2015-04-05 09:27:04 +0000",
    "user" : {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "protected" : false,
      "id_str" : "273375532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549666331805483009\/vYR8d3e0_normal.jpeg",
      "id" : 273375532,
      "verified" : false
    }
  },
  "id" : 584749562050523136,
  "created_at" : "2015-04-05 16:08:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 9, 19 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HHFmR0eN7y",
      "expanded_url" : "https:\/\/youtu.be\/Ml1G919Bts0?t=44m17s",
      "display_url" : "youtu.be\/Ml1G919Bts0?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584667239053406208",
  "geo" : { },
  "id_str" : "584678738010439680",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @HanaTicha  Chomsky \"u'll have to take a look on the internet cause ur not gonna find it in the library\" https:\/\/t.co\/HHFmR0eN7y",
  "id" : 584678738010439680,
  "in_reply_to_status_id" : 584667239053406208,
  "created_at" : "2015-04-05 11:27:28 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584659265471799296",
  "geo" : { },
  "id_str" : "584663367098507264",
  "in_reply_to_user_id" : 18602422,
  "text" : "woah, the speech to text in the Chomsky video seems pretty accurate",
  "id" : 584663367098507264,
  "in_reply_to_status_id" : 584659265471799296,
  "created_at" : "2015-04-05 10:26:23 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 103, 111 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/gSMqmKa7L5",
      "expanded_url" : "https:\/\/youtu.be\/Ml1G919Bts0",
      "display_url" : "youtu.be\/Ml1G919Bts0"
    } ]
  },
  "geo" : { },
  "id_str" : "584659265471799296",
  "text" : "Chomsky &amp; Krauss: An Origins Project Dialogue (OFFICIAL) - (Part 1\/2): https:\/\/t.co\/gSMqmKa7L5 via @YouTube",
  "id" : 584659265471799296,
  "created_at" : "2015-04-05 10:10:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584469659216433152",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta thanks for RT Natallia :)",
  "id" : 584469659216433152,
  "created_at" : "2015-04-04 21:36:40 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CQP",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/TG8OtLR2BK",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/CrWnRg6zeqW",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584469551888338945",
  "text" : "CQPwebinabox can run #CQP on your computer relatively painlessly, nice https:\/\/t.co\/TG8OtLR2BK #corpuslinguistics",
  "id" : 584469551888338945,
  "created_at" : "2015-04-04 21:36:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "indices" : [ 3, 10 ],
      "id_str" : "724473",
      "id" : 724473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RegEx",
      "indices" : [ 103, 109 ]
    }, {
      "text" : "Learn",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/XZRf658Gyo",
      "expanded_url" : "http:\/\/www.labnol.org\/?p=28841",
      "display_url" : "labnol.org\/?p=28841"
    } ]
  },
  "geo" : { },
  "id_str" : "584420967746838528",
  "text" : "RT @labnol: Regular Expressions save time and they aren't just for programmers. http:\/\/t.co\/XZRf658Gyo #RegEx #Learn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RegEx",
        "indices" : [ 91, 97 ]
      }, {
        "text" : "Learn",
        "indices" : [ 98, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/XZRf658Gyo",
        "expanded_url" : "http:\/\/www.labnol.org\/?p=28841",
        "display_url" : "labnol.org\/?p=28841"
      } ]
    },
    "geo" : { },
    "id_str" : "584229483651190784",
    "text" : "Regular Expressions save time and they aren't just for programmers. http:\/\/t.co\/XZRf658Gyo #RegEx #Learn",
    "id" : 584229483651190784,
    "created_at" : "2015-04-04 05:42:18 +0000",
    "user" : {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "protected" : false,
      "id_str" : "724473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641572075321229312\/3f_9iwzr_normal.jpg",
      "id" : 724473,
      "verified" : true
    }
  },
  "id" : 584420967746838528,
  "created_at" : "2015-04-04 18:23:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "gandi.net",
      "screen_name" : "gandibar",
      "indices" : [ 16, 25 ],
      "id_str" : "43079388",
      "id" : 43079388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583409043311570947",
  "geo" : { },
  "id_str" : "584415311014842368",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet @gandibar me too got half simple server price :) thx",
  "id" : 584415311014842368,
  "in_reply_to_status_id" : 583409043311570947,
  "created_at" : "2015-04-04 18:00:42 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 0, 7 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584403140465860609",
  "geo" : { },
  "id_str" : "584413477097369600",
  "in_reply_to_user_id" : 190569306,
  "text" : "@WordLo been running it on Brown corpus still running after 3hrs! :0",
  "id" : 584413477097369600,
  "in_reply_to_status_id" : 584403140465860609,
  "created_at" : "2015-04-04 17:53:25 +0000",
  "in_reply_to_screen_name" : "WordLo",
  "in_reply_to_user_id_str" : "190569306",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584349943332282369",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard hi Rose many thanks for the RTs, hope u r having a good Sat :)",
  "id" : 584349943332282369,
  "created_at" : "2015-04-04 13:40:57 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 126, 138 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/lCWV1RUpi0",
      "expanded_url" : "http:\/\/wp.me\/p1ZDGy-hX",
      "display_url" : "wp.me\/p1ZDGy-hX"
    } ]
  },
  "geo" : { },
  "id_str" : "584313217998057472",
  "text" : "What do populisms of Left and Right have in common? Armin Nassehi on the attraction of simple sol\u2026 http:\/\/t.co\/lCWV1RUpi0 via @John__Field",
  "id" : 584313217998057472,
  "created_at" : "2015-04-04 11:15:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "indices" : [ 0, 15 ],
      "id_str" : "570887893",
      "id" : 570887893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584154352501170176",
  "geo" : { },
  "id_str" : "584156184761991168",
  "in_reply_to_user_id" : 570887893,
  "text" : "@dreamreadernet a pleasure, comments welcome :)",
  "id" : 584156184761991168,
  "in_reply_to_status_id" : 584154352501170176,
  "created_at" : "2015-04-04 00:51:02 +0000",
  "in_reply_to_screen_name" : "dreamreadernet",
  "in_reply_to_user_id_str" : "570887893",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "indices" : [ 0, 15 ],
      "id_str" : "570887893",
      "id" : 570887893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "584143637501517824",
  "geo" : { },
  "id_str" : "584150161351409665",
  "in_reply_to_user_id" : 570887893,
  "text" : "@dreamreadernet hi u may find this of interest http:\/\/t.co\/feVV1F8lKr",
  "id" : 584150161351409665,
  "in_reply_to_status_id" : 584143637501517824,
  "created_at" : "2015-04-04 00:27:06 +0000",
  "in_reply_to_screen_name" : "dreamreadernet",
  "in_reply_to_user_id_str" : "570887893",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/CuKyOSQU0I",
      "expanded_url" : "http:\/\/www.smartsubs.fr\/",
      "display_url" : "smartsubs.fr"
    } ]
  },
  "geo" : { },
  "id_str" : "584100721731227649",
  "text" : "interesting subtitle glosses in French http:\/\/t.co\/CuKyOSQU0I",
  "id" : 584100721731227649,
  "created_at" : "2015-04-03 21:10:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Manning",
      "screen_name" : "xychelsea",
      "indices" : [ 3, 13 ],
      "id_str" : "1694040764",
      "id" : 1694040764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "90sproblems",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584084640727699456",
  "text" : "RT @xychelsea: Tweeting from prison reqs a lot of effort and using a voice phone to dictate #90sproblems",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "90sproblems",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584027836257857536",
    "text" : "Tweeting from prison reqs a lot of effort and using a voice phone to dictate #90sproblems",
    "id" : 584027836257857536,
    "created_at" : "2015-04-03 16:21:01 +0000",
    "user" : {
      "name" : "Chelsea Manning",
      "screen_name" : "xychelsea",
      "protected" : false,
      "id_str" : "1694040764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643848486010638336\/OmQvY0Rl_normal.png",
      "id" : 1694040764,
      "verified" : true
    }
  },
  "id" : 584084640727699456,
  "created_at" : "2015-04-03 20:06:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leadersdebate",
      "indices" : [ 74, 88 ]
    }, {
      "text" : "Election2015",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/w4MBMJvrGs",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/04\/the-austerity-of-political-debate.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/04\/the-au\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584074539442790401",
  "text" : "RT @johnwhilley: The austerity of political debate http:\/\/t.co\/w4MBMJvrGs #leadersdebate #Election2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leadersdebate",
        "indices" : [ 57, 71 ]
      }, {
        "text" : "Election2015",
        "indices" : [ 72, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/w4MBMJvrGs",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/04\/the-austerity-of-political-debate.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/04\/the-au\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583945836566081537",
    "text" : "The austerity of political debate http:\/\/t.co\/w4MBMJvrGs #leadersdebate #Election2015",
    "id" : 583945836566081537,
    "created_at" : "2015-04-03 10:55:11 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 584074539442790401,
  "created_at" : "2015-04-03 19:26:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 3, 18 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PirateBox",
      "indices" : [ 20, 30 ]
    }, {
      "text" : "Android",
      "indices" : [ 35, 43 ]
    }, {
      "text" : "Turkish",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "CM12",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584044655509168129",
  "text" : "RT @JoschiFun2Code: #PirateBox for #Android 0.5.6 is out with #Turkish translation and #CM12 support.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PirateBox",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Android",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "Turkish",
        "indices" : [ 42, 50 ]
      }, {
        "text" : "CM12",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584042617001926656",
    "text" : "#PirateBox for #Android 0.5.6 is out with #Turkish translation and #CM12 support.",
    "id" : 584042617001926656,
    "created_at" : "2015-04-03 17:19:45 +0000",
    "user" : {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "protected" : false,
      "id_str" : "2428512869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447798987320356864\/_FsQL523_normal.jpeg",
      "id" : 2428512869,
      "verified" : false
    }
  },
  "id" : 584044655509168129,
  "created_at" : "2015-04-03 17:27:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583761937604943872",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco hello and good night from France :)",
  "id" : 583761937604943872,
  "created_at" : "2015-04-02 22:44:26 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583761738119643136",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx for interview share Rose :)",
  "id" : 583761738119643136,
  "created_at" : "2015-04-02 22:43:38 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/DL9Sx10LhK",
      "expanded_url" : "https:\/\/youtu.be\/G66_HE9BRjs",
      "display_url" : "youtu.be\/G66_HE9BRjs"
    } ]
  },
  "geo" : { },
  "id_str" : "583761636554633216",
  "text" : "What wanna tells us about (forming) questions: https:\/\/t.co\/DL9Sx10LhK via @YouTube",
  "id" : 583761636554633216,
  "created_at" : "2015-04-02 22:43:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hosker",
      "screen_name" : "Chris_Hosker",
      "indices" : [ 3, 16 ],
      "id_str" : "371952783",
      "id" : 371952783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leadersdebate",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583721979712274432",
  "text" : "RT @Chris_Hosker: Go Cymru! No to scapegoating. Simple really... #leadersdebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leadersdebate",
        "indices" : [ 47, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583721818403536896",
    "text" : "Go Cymru! No to scapegoating. Simple really... #leadersdebate",
    "id" : 583721818403536896,
    "created_at" : "2015-04-02 20:05:01 +0000",
    "user" : {
      "name" : "Chris Hosker",
      "screen_name" : "Chris_Hosker",
      "protected" : false,
      "id_str" : "371952783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526025323398168577\/DNaUWT9Y_normal.jpeg",
      "id" : 371952783,
      "verified" : false
    }
  },
  "id" : 583721979712274432,
  "created_at" : "2015-04-02 20:05:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hXbj93qIx9",
      "expanded_url" : "http:\/\/linguafrankly.blogspot.com\/2015\/04\/the-uks-privatisation-agenda-hits.html?spref=tw",
      "display_url" : "linguafrankly.blogspot.com\/2015\/04\/the-uk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583713014098059267",
  "text" : "Lingua Frankly: The UK's privatisation agenda hits immigrants and ... http:\/\/t.co\/hXbj93qIx9",
  "id" : 583713014098059267,
  "created_at" : "2015-04-02 19:30:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/xe0fP5g1yt",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=38283356",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Dm2PzkHf0F",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=38283462",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "583660057994342400",
  "geo" : { },
  "id_str" : "583661645274206208",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd adj for trolling much more emotive (http:\/\/t.co\/xe0fP5g1yt )than for psyops which is more descriptive (http:\/\/t.co\/Dm2PzkHf0F)",
  "id" : 583661645274206208,
  "in_reply_to_status_id" : 583660057994342400,
  "created_at" : "2015-04-02 16:05:54 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/pBHokLO4CV",
      "expanded_url" : "http:\/\/www.googlefight.com\/index.php?word1=psychological+operations&word2=trolling#",
      "display_url" : "googlefight.com\/index.php?word\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "583660057994342400",
  "geo" : { },
  "id_str" : "583660450476400640",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd http:\/\/t.co\/pBHokLO4CV :\/",
  "id" : 583660450476400640,
  "in_reply_to_status_id" : 583660057994342400,
  "created_at" : "2015-04-02 16:01:09 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/wtryNUEypE",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1427989479.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583657379847397376",
  "text" : "A personal statement from Prof. Suleiman Sharkh, one of the conference organisers http:\/\/t.co\/wtryNUEypE",
  "id" : 583657379847397376,
  "created_at" : "2015-04-02 15:48:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 0, 14 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583655751442440193",
  "in_reply_to_user_id" : 48839094,
  "text" : "@duygucandarli thx for sharing interview post :)",
  "id" : 583655751442440193,
  "created_at" : "2015-04-02 15:42:29 +0000",
  "in_reply_to_screen_name" : "duygucandarli",
  "in_reply_to_user_id_str" : "48839094",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusLinguistics",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/jHY7hTTyPK",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/QtLDDDLLXbQ",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583639263658512386",
  "text" : "Dr. Ivor Timmis answers some questions about his new book #CorpusLinguistics for ELT: Research &amp; Practice https:\/\/t.co\/jHY7hTTyPK",
  "id" : 583639263658512386,
  "created_at" : "2015-04-02 14:36:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/vsvBaHR7jh",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/blog-shoutouts\/",
      "display_url" : "eflnotes.wordpress.com\/blog-shoutouts\/"
    } ]
  },
  "geo" : { },
  "id_str" : "583631874326683649",
  "text" : "adding a couple of new entries to blogshoutout https:\/\/t.co\/vsvBaHR7jh maybe u may find something interesting in there to use?",
  "id" : 583631874326683649,
  "created_at" : "2015-04-02 14:07:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/1DigzRVYGb",
      "expanded_url" : "http:\/\/wp.me\/p5Qaaj-JP",
      "display_url" : "wp.me\/p5Qaaj-JP"
    } ]
  },
  "geo" : { },
  "id_str" : "583544628802166785",
  "text" : "RT @perezparedes: New book: Corpus Linguistics for ELT: Research &amp;\u00A0Practice http:\/\/t.co\/1DigzRVYGb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/1DigzRVYGb",
        "expanded_url" : "http:\/\/wp.me\/p5Qaaj-JP",
        "display_url" : "wp.me\/p5Qaaj-JP"
      } ]
    },
    "geo" : { },
    "id_str" : "583543401519259648",
    "text" : "New book: Corpus Linguistics for ELT: Research &amp;\u00A0Practice http:\/\/t.co\/1DigzRVYGb",
    "id" : 583543401519259648,
    "created_at" : "2015-04-02 08:16:03 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 583544628802166785,
  "created_at" : "2015-04-02 08:20:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alastair Lane",
      "screen_name" : "alastairlaneelt",
      "indices" : [ 3, 19 ],
      "id_str" : "3034441707",
      "id" : 3034441707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL2015",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lXw1KoUL4Z",
      "expanded_url" : "https:\/\/alastairlaneelt.wordpress.com\/2015\/03\/24\/my-top-tips-for-iatefl-2015-in-manchester\/",
      "display_url" : "alastairlaneelt.wordpress.com\/2015\/03\/24\/my-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583543921965412352",
  "text" : "RT @alastairlaneelt: #IATEFL2015 - so many talks, so little time. Here are my top tips of recommended presentations: https:\/\/t.co\/lXw1KoUL4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL2015",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "ELT",
        "indices" : [ 120, 124 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/lXw1KoUL4Z",
        "expanded_url" : "https:\/\/alastairlaneelt.wordpress.com\/2015\/03\/24\/my-top-tips-for-iatefl-2015-in-manchester\/",
        "display_url" : "alastairlaneelt.wordpress.com\/2015\/03\/24\/my-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580656432141492224",
    "text" : "#IATEFL2015 - so many talks, so little time. Here are my top tips of recommended presentations: https:\/\/t.co\/lXw1KoUL4Z #ELT #TEFL",
    "id" : 580656432141492224,
    "created_at" : "2015-03-25 09:04:16 +0000",
    "user" : {
      "name" : "Alastair Lane",
      "screen_name" : "alastairlaneelt",
      "protected" : false,
      "id_str" : "3034441707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566203411024969728\/bMmiZkSO_normal.jpeg",
      "id" : 3034441707,
      "verified" : false
    }
  },
  "id" : 583543921965412352,
  "created_at" : "2015-04-02 08:18:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Pun",
      "screen_name" : "eltplanning",
      "indices" : [ 66, 78 ],
      "id_str" : "3128556058",
      "id" : 3128556058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Iv4a4WyrtJ",
      "expanded_url" : "http:\/\/wp.me\/p5Vbga-1d",
      "display_url" : "wp.me\/p5Vbga-1d"
    } ]
  },
  "geo" : { },
  "id_str" : "583493771721060352",
  "text" : "A fun way to introduce graphs in class http:\/\/t.co\/Iv4a4WyrtJ via @eltplanning",
  "id" : 583493771721060352,
  "created_at" : "2015-04-02 04:58:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/I60YskU4KJ",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/04\/01\/picketty-remix-and-the-most-important-student-blog-comment-of-the-21st-century\/",
      "display_url" : "hapgood.us\/2015\/04\/01\/pic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583491971299278849",
  "text" : "RT @holden: Picketty, Remix, and the Most Important Student Blog Comment of the 21st Century: http:\/\/t.co\/I60YskU4KJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/I60YskU4KJ",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/04\/01\/picketty-remix-and-the-most-important-student-blog-comment-of-the-21st-century\/",
        "display_url" : "hapgood.us\/2015\/04\/01\/pic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583415209752002560",
    "text" : "Picketty, Remix, and the Most Important Student Blog Comment of the 21st Century: http:\/\/t.co\/I60YskU4KJ",
    "id" : 583415209752002560,
    "created_at" : "2015-04-01 23:46:39 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 583491971299278849,
  "created_at" : "2015-04-02 04:51:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 9, 18 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AUsELT",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/xyKnqwCAam",
      "expanded_url" : "http:\/\/www.apps4efl.com",
      "display_url" : "apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "583489780182298624",
  "text" : "apps4efl @apps4efl http:\/\/t.co\/xyKnqwCAam #AUsELT recommended resource, new ones always being developed",
  "id" : 583489780182298624,
  "created_at" : "2015-04-02 04:42:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "UPEC",
      "screen_name" : "UPECactus",
      "indices" : [ 67, 77 ],
      "id_str" : "199646482",
      "id" : 199646482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engcorpora2015",
      "indices" : [ 37, 52 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/0iRXfJUZvs",
      "expanded_url" : "http:\/\/bit.ly\/19HTcj3",
      "display_url" : "bit.ly\/19HTcj3"
    } ]
  },
  "geo" : { },
  "id_str" : "583257177378414592",
  "text" : "RT @RudyLoock: Official programme of #engcorpora2015 conference at @UPECactus 8-10 April http:\/\/t.co\/0iRXfJUZvs #corpuslinguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UPEC",
        "screen_name" : "UPECactus",
        "indices" : [ 52, 62 ],
        "id_str" : "199646482",
        "id" : 199646482
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "engcorpora2015",
        "indices" : [ 22, 37 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 97, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/0iRXfJUZvs",
        "expanded_url" : "http:\/\/bit.ly\/19HTcj3",
        "display_url" : "bit.ly\/19HTcj3"
      } ]
    },
    "geo" : { },
    "id_str" : "583151473061699584",
    "text" : "Official programme of #engcorpora2015 conference at @UPECactus 8-10 April http:\/\/t.co\/0iRXfJUZvs #corpuslinguistics",
    "id" : 583151473061699584,
    "created_at" : "2015-04-01 06:18:40 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 583257177378414592,
  "created_at" : "2015-04-01 13:18:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/1KDJLa5cJC",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1do",
      "display_url" : "wp.me\/p3qkCB-1do"
    } ]
  },
  "geo" : { },
  "id_str" : "583244801564344320",
  "text" : "RT @GeoffreyJordan: The IATEFL 2015\u00A0Conference http:\/\/t.co\/1KDJLa5cJC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/1KDJLa5cJC",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-1do",
        "display_url" : "wp.me\/p3qkCB-1do"
      } ]
    },
    "geo" : { },
    "id_str" : "583183559210332161",
    "text" : "The IATEFL 2015\u00A0Conference http:\/\/t.co\/1KDJLa5cJC",
    "id" : 583183559210332161,
    "created_at" : "2015-04-01 08:26:10 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 583244801564344320,
  "created_at" : "2015-04-01 12:29:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/rhPHgJPSHO",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-i42",
      "display_url" : "wp.me\/p1RJaO-i42"
    } ]
  },
  "geo" : { },
  "id_str" : "583244637336399872",
  "text" : "RT @NicolaPrentis: Why am I going to #IATEFL 2015? http:\/\/t.co\/rhPHgJPSHO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/rhPHgJPSHO",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-i42",
        "display_url" : "wp.me\/p1RJaO-i42"
      } ]
    },
    "geo" : { },
    "id_str" : "583243319708233728",
    "text" : "Why am I going to #IATEFL 2015? http:\/\/t.co\/rhPHgJPSHO",
    "id" : 583243319708233728,
    "created_at" : "2015-04-01 12:23:38 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 583244637336399872,
  "created_at" : "2015-04-01 12:28:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "indices" : [ 0, 15 ],
      "id_str" : "245975798",
      "id" : 245975798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/O9C2mSXt94",
      "expanded_url" : "http:\/\/www.reelapp.com\/970fcc#1",
      "display_url" : "reelapp.com\/970fcc#1"
    } ]
  },
  "in_reply_to_status_id_str" : "583205591545430016",
  "geo" : { },
  "id_str" : "583230185882959873",
  "in_reply_to_user_id" : 245975798,
  "text" : "@AnthonyGaughan there were rumours of a back to basics kind of movement , some evidence here http:\/\/t.co\/O9C2mSXt94 :)",
  "id" : 583230185882959873,
  "in_reply_to_status_id" : 583205591545430016,
  "created_at" : "2015-04-01 11:31:26 +0000",
  "in_reply_to_screen_name" : "AnthonyGaughan",
  "in_reply_to_user_id_str" : "245975798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "indices" : [ 3, 18 ],
      "id_str" : "245975798",
      "id" : 245975798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tdsig",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "iatefl2015",
      "indices" : [ 117, 128 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/fYvbHLlFXf",
      "expanded_url" : "http:\/\/tdsig.org\/2015\/04\/shaving-and-innovation-in-education\/",
      "display_url" : "tdsig.org\/2015\/04\/shavin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583228178254180352",
  "text" : "RT @AnthonyGaughan: What does shaving have to do with innovation in education? http:\/\/t.co\/fYvbHLlFXf #tdsig #iatefl #iatefl2015 #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tdsig",
        "indices" : [ 82, 88 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "iatefl2015",
        "indices" : [ 97, 108 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/fYvbHLlFXf",
        "expanded_url" : "http:\/\/tdsig.org\/2015\/04\/shaving-and-innovation-in-education\/",
        "display_url" : "tdsig.org\/2015\/04\/shavin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583205591545430016",
    "text" : "What does shaving have to do with innovation in education? http:\/\/t.co\/fYvbHLlFXf #tdsig #iatefl #iatefl2015 #eltchat",
    "id" : 583205591545430016,
    "created_at" : "2015-04-01 09:53:43 +0000",
    "user" : {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "protected" : false,
      "id_str" : "245975798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453943102257242113\/NniGD88__normal.jpeg",
      "id" : 245975798,
      "verified" : false
    }
  },
  "id" : 583228178254180352,
  "created_at" : "2015-04-01 11:23:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    }, {
      "name" : "Synonymy",
      "screen_name" : "synonymygame",
      "indices" : [ 14, 27 ],
      "id_str" : "2841750604",
      "id" : 2841750604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583047748850708480",
  "geo" : { },
  "id_str" : "583052586686763009",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech @synonymygame ugh don't fancy funding dawkins :\/",
  "id" : 583052586686763009,
  "in_reply_to_status_id" : 583047748850708480,
  "created_at" : "2015-03-31 23:45:43 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 98, 114 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/BMxT4rg2g8",
      "expanded_url" : "http:\/\/wp.me\/p5AdSD-10",
      "display_url" : "wp.me\/p5AdSD-10"
    } ]
  },
  "geo" : { },
  "id_str" : "583051138037084160",
  "text" : "Fun with projectors: all guns blazing! grammar with shooting practise! http:\/\/t.co\/BMxT4rg2g8 via @wordpressdotcom",
  "id" : 583051138037084160,
  "created_at" : "2015-03-31 23:39:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]