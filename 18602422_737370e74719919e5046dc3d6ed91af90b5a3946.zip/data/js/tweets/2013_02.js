Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/K77Z5Ncbb8",
      "expanded_url" : "http:\/\/www.nhsforsale.info",
      "display_url" : "nhsforsale.info"
    } ]
  },
  "geo" : { },
  "id_str" : "307254469039628288",
  "text" : "interesting graphic based web info on NHS privatisation http:\/\/t.co\/K77Z5Ncbb8",
  "id" : 307254469039628288,
  "created_at" : "2013-02-28 22:22:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Harris",
      "screen_name" : "Stephen_H",
      "indices" : [ 0, 10 ],
      "id_str" : "15943690",
      "id" : 15943690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307203260375248896",
  "geo" : { },
  "id_str" : "307250505518813184",
  "in_reply_to_user_id" : 15943690,
  "text" : "@Stephen_H for some reason i read that as Mitra's cartoon version of education :)",
  "id" : 307250505518813184,
  "in_reply_to_status_id" : 307203260375248896,
  "created_at" : "2013-02-28 22:06:43 +0000",
  "in_reply_to_screen_name" : "Stephen_H",
  "in_reply_to_user_id_str" : "15943690",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerald Von Bourdeau",
      "screen_name" : "gvbourdeau",
      "indices" : [ 57, 68 ],
      "id_str" : "1029718040",
      "id" : 1029718040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/8sbgS0WtxJ",
      "expanded_url" : "http:\/\/wp.me\/p2QU2A-2m",
      "display_url" : "wp.me\/p2QU2A-2m"
    } ]
  },
  "geo" : { },
  "id_str" : "307157119046668288",
  "text" : "Howdy Folks, I Need Your Help http:\/\/t.co\/8sbgS0WtxJ via @gvbourdeau",
  "id" : 307157119046668288,
  "created_at" : "2013-02-28 15:55:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 32, 43 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/T3AnEG1Su8",
      "expanded_url" : "http:\/\/s.shr.lc\/Yscn5q",
      "display_url" : "s.shr.lc\/Yscn5q"
    } ]
  },
  "geo" : { },
  "id_str" : "307117527249584129",
  "text" : "Seymour in full flow&gt;&gt; RT @leninology: When neoconservative heroes perish - http:\/\/t.co\/T3AnEG1Su8  &lt;&lt; on that Newsweek review.",
  "id" : 307117527249584129,
  "created_at" : "2013-02-28 13:18:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StDavidsDay",
      "indices" : [ 40, 52 ]
    }, {
      "text" : "DewiSant",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/dcRwQG0GyO",
      "expanded_url" : "http:\/\/www.enterthemagic.com\/disneylandparis\/seasons\/st-davids-welsh-festival.asp",
      "display_url" : "enterthemagic.com\/disneylandpari\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307114492930699266",
  "text" : "Yikes!&gt;&gt; http:\/\/t.co\/dcRwQG0GyO \u2026 #StDavidsDay #DewiSant",
  "id" : 307114492930699266,
  "created_at" : "2013-02-28 13:06:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Meryl Alper",
      "screen_name" : "merylalper",
      "indices" : [ 15, 26 ],
      "id_str" : "103413137",
      "id" : 103413137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306868320697741312",
  "geo" : { },
  "id_str" : "307083986155470848",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters @merylalper anyone know what NIIT did with the hole in the walls childrens' browsing data?",
  "id" : 307083986155470848,
  "in_reply_to_status_id" : 306868320697741312,
  "created_at" : "2013-02-28 11:05:02 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Meryl Alper",
      "screen_name" : "merylalper",
      "indices" : [ 40, 51 ],
      "id_str" : "103413137",
      "id" : 103413137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/zsnbpBGQuX",
      "expanded_url" : "http:\/\/books.google.com\/books?id=j0ZkGcoX6rsC&pg=PA11&lpg=PA11&dq=Sugata+Mitra+hole+in+the+wall+ellen+seiter&source=bl&ots=SNBiMiU82B&sig=jroGFjPrYp9dgs9BbrY2nPGgpZI&hl=en&sa=X&ei=FnctUdbBL46NigLD9IDIBA&ved=0CDMQ6AEwAA#v=onepage&q=Sugata%20Mitra%20hole%20in%20the%20wall%20ellen%20seiter&f=false",
      "display_url" : "books.google.com\/books?id=j0ZkG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307080896069120000",
  "text" : "RT @audreywatters: Thanks to a tip from @merylalper last night, I\u2019ve been looking at this http:\/\/t.co\/zsnbpBGQuX re the initial $$ for t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Meryl Alper",
        "screen_name" : "merylalper",
        "indices" : [ 21, 32 ],
        "id_str" : "103413137",
        "id" : 103413137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/zsnbpBGQuX",
        "expanded_url" : "http:\/\/books.google.com\/books?id=j0ZkGcoX6rsC&pg=PA11&lpg=PA11&dq=Sugata+Mitra+hole+in+the+wall+ellen+seiter&source=bl&ots=SNBiMiU82B&sig=jroGFjPrYp9dgs9BbrY2nPGgpZI&hl=en&sa=X&ei=FnctUdbBL46NigLD9IDIBA&ved=0CDMQ6AEwAA#v=onepage&q=Sugata%20Mitra%20hole%20in%20the%20wall%20ellen%20seiter&f=false",
        "display_url" : "books.google.com\/books?id=j0ZkG\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306868320697741312",
    "text" : "Thanks to a tip from @merylalper last night, I\u2019ve been looking at this http:\/\/t.co\/zsnbpBGQuX re the initial $$ for the Hole in the Wall",
    "id" : 306868320697741312,
    "created_at" : "2013-02-27 20:48:03 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 307080896069120000,
  "created_at" : "2013-02-28 10:52:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307080260233592833",
  "text" : "RT @audreywatters: Ask. more. questions. people. FFS. Ask them of Bono. Of Sergei Brin. Of Mitra. Of the whom damn TED song-and-dance. J ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306868617981591554",
    "text" : "Ask. more. questions. people. FFS. Ask them of Bono. Of Sergei Brin. Of Mitra. Of the whom damn TED song-and-dance. Just. please. ask.",
    "id" : 306868617981591554,
    "created_at" : "2013-02-27 20:49:14 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 307080260233592833,
  "created_at" : "2013-02-28 10:50:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "PewResearch Internet",
      "screen_name" : "pewinternet",
      "indices" : [ 112, 124 ],
      "id_str" : "17071048",
      "id" : 17071048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/IJKJq1jt59",
      "expanded_url" : "http:\/\/www.pewinternet.org\/Reports\/2013\/Teachers-and-technology.aspx",
      "display_url" : "pewinternet.org\/Reports\/2013\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307079596002643968",
  "text" : "RT @audreywatters: How Teachers Are Using Technology at Home and in Their Classrooms http:\/\/t.co\/IJKJq1jt59 via @pewinternet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PewResearch Internet",
        "screen_name" : "pewinternet",
        "indices" : [ 93, 105 ],
        "id_str" : "17071048",
        "id" : 17071048
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/IJKJq1jt59",
        "expanded_url" : "http:\/\/www.pewinternet.org\/Reports\/2013\/Teachers-and-technology.aspx",
        "display_url" : "pewinternet.org\/Reports\/2013\/T\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306971656100917248",
    "text" : "How Teachers Are Using Technology at Home and in Their Classrooms http:\/\/t.co\/IJKJq1jt59 via @pewinternet",
    "id" : 306971656100917248,
    "created_at" : "2013-02-28 03:38:40 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 307079596002643968,
  "created_at" : "2013-02-28 10:47:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 24, 39 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/3wtHAPUbxr",
      "expanded_url" : "http:\/\/bit.ly\/VPwv2I",
      "display_url" : "bit.ly\/VPwv2I"
    } ]
  },
  "geo" : { },
  "id_str" : "307077318373941248",
  "text" : "fascinating paper&gt;RT @markwarschauer: A longitudinal study of follow predictors on Twitter http:\/\/t.co\/3wtHAPUbxr",
  "id" : 307077318373941248,
  "created_at" : "2013-02-28 10:38:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "culture",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tDlJcXUubP",
      "expanded_url" : "http:\/\/www.eltknowledge.com\/understanding_intercultural_communication__giving_feedback_32130.aspx",
      "display_url" : "eltknowledge.com\/understanding_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307074328258809856",
  "text" : "RT @eltknowledge: Would the 'Hamburger approach' to giving feedback work across cultures?\nHere's Part 2 of my blog series on #culture \nh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "culture",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tDlJcXUubP",
        "expanded_url" : "http:\/\/www.eltknowledge.com\/understanding_intercultural_communication__giving_feedback_32130.aspx",
        "display_url" : "eltknowledge.com\/understanding_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306847332492791808",
    "text" : "Would the 'Hamburger approach' to giving feedback work across cultures?\nHere's Part 2 of my blog series on #culture \nhttp:\/\/t.co\/tDlJcXUubP",
    "id" : 306847332492791808,
    "created_at" : "2013-02-27 19:24:39 +0000",
    "user" : {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "protected" : false,
      "id_str" : "501629829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3479623963\/94a4377e5848f6cb2857b8fc97a9f4c4_normal.png",
      "id" : 501629829,
      "verified" : false
    }
  },
  "id" : 307074328258809856,
  "created_at" : "2013-02-28 10:26:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307071147885862912",
  "text" : "@EBEFL the vid in my post? no thats Kirsteen Donaghy &amp; Rob Lewis along with Nicole Janneker",
  "id" : 307071147885862912,
  "created_at" : "2013-02-28 10:14:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306721301945516032",
  "geo" : { },
  "id_str" : "307062244146036738",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate they shld be called TED speeches not talks as a talk involves dialogue ;)",
  "id" : 307062244146036738,
  "in_reply_to_status_id" : 306721301945516032,
  "created_at" : "2013-02-28 09:38:38 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 17, 23 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 24, 33 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/plq9fAatSI",
      "expanded_url" : "http:\/\/marxistelf.wordpress.com\/?s=british+council",
      "display_url" : "marxistelf.wordpress.com\/?s=british+cou\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JdmnfrgFvY",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-5X",
      "display_url" : "wp.me\/pgHyE-5X"
    } ]
  },
  "in_reply_to_status_id_str" : "306890972300713984",
  "geo" : { },
  "id_str" : "307054125366001664",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @EBEFL @Marisa_C some reading here as well http:\/\/t.co\/plq9fAatSI my answer is no; my related post http:\/\/t.co\/JdmnfrgFvY",
  "id" : 307054125366001664,
  "in_reply_to_status_id" : 306890972300713984,
  "created_at" : "2013-02-28 09:06:22 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eddie Brennan",
      "screen_name" : "EddieBrennan",
      "indices" : [ 3, 16 ],
      "id_str" : "22502725",
      "id" : 22502725
    }, {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 78, 85 ],
      "id_str" : "14321959",
      "id" : 14321959
    }, {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 112, 125 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/SMf0Jgzu8a",
      "expanded_url" : "http:\/\/sfy.co\/iFb9",
      "display_url" : "sfy.co\/iFb9"
    } ]
  },
  "geo" : { },
  "id_str" : "306696698430889985",
  "text" : "MT @EddieBrennan Critique of TED's commercialised, high speed, geekthink from @umairh http:\/\/t.co\/SMf0Jgzu8a cc @Timothy_Tate",
  "id" : 306696698430889985,
  "created_at" : "2013-02-27 09:26:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 81, 91 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/8v4kkCxEmy",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/current-alert-sp-298539227\/cogitations-archive\/722-thespecialone.html",
      "display_url" : "medialens.org\/index.php\/curr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306567695195852801",
  "text" : "'The Special One' - Part 2: Looking Under The Lamppost http:\/\/t.co\/8v4kkCxEmy by @medialens",
  "id" : 306567695195852801,
  "created_at" : "2013-02-27 00:53:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 3, 14 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/feXHJOYAXF",
      "expanded_url" : "http:\/\/bit.ly\/XC3JQz",
      "display_url" : "bit.ly\/XC3JQz"
    } ]
  },
  "geo" : { },
  "id_str" : "306446608369848320",
  "text" : "RT @lynneguist: Linguistics Research Digest: Are regional dialects dying out? http:\/\/t.co\/feXHJOYAXF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/feXHJOYAXF",
        "expanded_url" : "http:\/\/bit.ly\/XC3JQz",
        "display_url" : "bit.ly\/XC3JQz"
      } ]
    },
    "geo" : { },
    "id_str" : "306185303121604609",
    "text" : "Linguistics Research Digest: Are regional dialects dying out? http:\/\/t.co\/feXHJOYAXF",
    "id" : 306185303121604609,
    "created_at" : "2013-02-25 23:33:59 +0000",
    "user" : {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "protected" : false,
      "id_str" : "16316886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632304665821081601\/BiPmyu1t_normal.jpg",
      "id" : 16316886,
      "verified" : false
    }
  },
  "id" : 306446608369848320,
  "created_at" : "2013-02-26 16:52:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "TEFL.net",
      "screen_name" : "TEFL",
      "indices" : [ 28, 33 ],
      "id_str" : "19223632",
      "id" : 19223632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306444540435374080",
  "text" : "@harrisonmike glad to help, @TEFL is one of those great resources sites u need when in a hurry",
  "id" : 306444540435374080,
  "created_at" : "2013-02-26 16:44:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/d32fb86V8B",
      "expanded_url" : "http:\/\/edition.tefl.net\/ideas\/games\/adverbs-of-frequency\/",
      "display_url" : "edition.tefl.net\/ideas\/games\/ad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306439511603281920",
  "text" : "@harrisonmike tried any of these? http:\/\/t.co\/d32fb86V8B",
  "id" : 306439511603281920,
  "created_at" : "2013-02-26 16:24:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306425775022825474",
  "geo" : { },
  "id_str" : "306426358286925825",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler i like the first title :)",
  "id" : 306426358286925825,
  "in_reply_to_status_id" : 306425775022825474,
  "created_at" : "2013-02-26 15:31:51 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306423859098292224",
  "geo" : { },
  "id_str" : "306424424352071680",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler grt, maybe worth a blog post? *nudge nudge wink wink* :)",
  "id" : 306424424352071680,
  "in_reply_to_status_id" : 306423859098292224,
  "created_at" : "2013-02-26 15:24:10 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corpora",
      "indices" : [ 22, 30 ]
    }, {
      "text" : "elt",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "esl",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "tefl",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/t2htdFoG2h",
      "expanded_url" : "http:\/\/bit.ly\/YoTEty",
      "display_url" : "bit.ly\/YoTEty"
    } ]
  },
  "geo" : { },
  "id_str" : "306423963771342849",
  "text" : "RT @leoselivan: Using #Corpora in the Language Classroom | Randi Reppen at The New School http:\/\/t.co\/t2htdFoG2h #elt #esl #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corpora",
        "indices" : [ 6, 14 ]
      }, {
        "text" : "elt",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "esl",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "tefl",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/t2htdFoG2h",
        "expanded_url" : "http:\/\/bit.ly\/YoTEty",
        "display_url" : "bit.ly\/YoTEty"
      } ]
    },
    "geo" : { },
    "id_str" : "306419408237117442",
    "text" : "Using #Corpora in the Language Classroom | Randi Reppen at The New School http:\/\/t.co\/t2htdFoG2h #elt #esl #tefl",
    "id" : 306419408237117442,
    "created_at" : "2013-02-26 15:04:14 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 306423963771342849,
  "created_at" : "2013-02-26 15:22:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "indices" : [ 3, 15 ],
      "id_str" : "38205414",
      "id" : 38205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306418467278577665",
  "text" : "RT @marcuschown: I did not take drugs - Lance Armstrong. I did not have sex with that woman - Bill Clinton. I am not privatising the NHS ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306303907292913664",
    "text" : "I did not take drugs - Lance Armstrong. I did not have sex with that woman - Bill Clinton. I am not privatising the NHS - David Cameron",
    "id" : 306303907292913664,
    "created_at" : "2013-02-26 07:25:17 +0000",
    "user" : {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "protected" : false,
      "id_str" : "38205414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681518625090580480\/BJUBjRiS_normal.jpg",
      "id" : 38205414,
      "verified" : false
    }
  },
  "id" : 306418467278577665,
  "created_at" : "2013-02-26 15:00:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 3, 12 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ZKJr9XpSaB",
      "expanded_url" : "http:\/\/www.dontgetcaught.biz\/2013\/02\/7-ineffective-habits-of-scientists-who.html",
      "display_url" : "dontgetcaught.biz\/2013\/02\/7-inef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306415597313474561",
  "text" : "RT @annehodg: 7 ineffective habits of scientists who communicate with public audiences #eapchat\nhttp:\/\/t.co\/ZKJr9XpSaB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eapchat",
        "indices" : [ 73, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/ZKJr9XpSaB",
        "expanded_url" : "http:\/\/www.dontgetcaught.biz\/2013\/02\/7-ineffective-habits-of-scientists-who.html",
        "display_url" : "dontgetcaught.biz\/2013\/02\/7-inef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306413051798761472",
    "text" : "7 ineffective habits of scientists who communicate with public audiences #eapchat\nhttp:\/\/t.co\/ZKJr9XpSaB",
    "id" : 306413051798761472,
    "created_at" : "2013-02-26 14:38:59 +0000",
    "user" : {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "protected" : false,
      "id_str" : "17589213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618152681920724993\/9dLkbtqM_normal.jpg",
      "id" : 17589213,
      "verified" : false
    }
  },
  "id" : 306415597313474561,
  "created_at" : "2013-02-26 14:49:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/VnNfbuwW3k",
      "expanded_url" : "http:\/\/www.i-am-bored.com\/bored_link.cfm?link_id=47346",
      "display_url" : "i-am-bored.com\/bored_link.cfm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306413576288100352",
  "text" : "If u r a pirate... - http:\/\/t.co\/VnNfbuwW3k re Copyright Alert System",
  "id" : 306413576288100352,
  "created_at" : "2013-02-26 14:41:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "indrit bulku",
      "screen_name" : "IndritB",
      "indices" : [ 3, 11 ],
      "id_str" : "53080983",
      "id" : 53080983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/95sr1P7p6A",
      "expanded_url" : "http:\/\/lnkd.in\/d_wTT3",
      "display_url" : "lnkd.in\/d_wTT3"
    } ]
  },
  "geo" : { },
  "id_str" : "306409969010475010",
  "text" : "RT @IndritB: Why I'm quitting Facebook http:\/\/t.co\/95sr1P7p6A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/95sr1P7p6A",
        "expanded_url" : "http:\/\/lnkd.in\/d_wTT3",
        "display_url" : "lnkd.in\/d_wTT3"
      } ]
    },
    "geo" : { },
    "id_str" : "306277164528070656",
    "text" : "Why I'm quitting Facebook http:\/\/t.co\/95sr1P7p6A",
    "id" : 306277164528070656,
    "created_at" : "2013-02-26 05:39:01 +0000",
    "user" : {
      "name" : "indrit bulku",
      "screen_name" : "IndritB",
      "protected" : false,
      "id_str" : "53080983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1460574554\/DSC00903_normal.JPG",
      "id" : 53080983,
      "verified" : false
    }
  },
  "id" : 306409969010475010,
  "created_at" : "2013-02-26 14:26:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 52, 63 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 92, 100 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/FzM9AkqB0r",
      "expanded_url" : "http:\/\/hughdellar.wordpress.com\/2013\/02\/26\/england-english-and-the-english-tackling-diversity-in-the-classroom\/",
      "display_url" : "hughdellar.wordpress.com\/2013\/02\/26\/eng\u2026"
    }, {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/jClWZ3Ihn8",
      "expanded_url" : "http:\/\/samuelshep.wordpress.com\/2013\/02\/26\/citizenship\/",
      "display_url" : "samuelshep.wordpress.com\/2013\/02\/26\/cit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306405187285827584",
  "text" : "2 grt posts on Identity http:\/\/t.co\/FzM9AkqB0r \u2026 by @hughdellar http:\/\/t.co\/jClWZ3Ihn8 \u2026 by @samshep",
  "id" : 306405187285827584,
  "created_at" : "2013-02-26 14:07:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 107, 118 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zLbZtG13Gp",
      "expanded_url" : "http:\/\/bit.ly\/XxW0D1",
      "display_url" : "bit.ly\/XxW0D1"
    } ]
  },
  "geo" : { },
  "id_str" : "306400979954307073",
  "text" : "RT @leoselivan: Assessment for Learning: a new way to meet individual learner needs? | #elt-resourceful by @teflerinha http:\/\/t.co\/zLbZt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Roberts",
        "screen_name" : "teflerinha",
        "indices" : [ 91, 102 ],
        "id_str" : "282659955",
        "id" : 282659955
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 71, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/zLbZtG13Gp",
        "expanded_url" : "http:\/\/bit.ly\/XxW0D1",
        "display_url" : "bit.ly\/XxW0D1"
      } ]
    },
    "geo" : { },
    "id_str" : "306342138696851456",
    "text" : "Assessment for Learning: a new way to meet individual learner needs? | #elt-resourceful by @teflerinha http:\/\/t.co\/zLbZtG13Gp",
    "id" : 306342138696851456,
    "created_at" : "2013-02-26 09:57:12 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 306400979954307073,
  "created_at" : "2013-02-26 13:51:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306400768376836096",
  "text" : "@EBEFL oh no! the EFL Scrooge\/Grinch strikes again! ;)",
  "id" : 306400768376836096,
  "created_at" : "2013-02-26 13:50:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 91, 102 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306227793086259201",
  "geo" : { },
  "id_str" : "306394224889303041",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt many thx for share Tyson,  v much appreciated, replied to your comment as well as @tornhalves",
  "id" : 306394224889303041,
  "in_reply_to_status_id" : 306227793086259201,
  "created_at" : "2013-02-26 13:24:10 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306304265641676800",
  "geo" : { },
  "id_str" : "306379931460444160",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler hi, cld try \/rang * up\/ then  \/[r*] rang up\/ and  \/rang [r*] up\/; 1st search will answr question, 2nd 2 how adverbs usd",
  "id" : 306379931460444160,
  "in_reply_to_status_id" : 306304265641676800,
  "created_at" : "2013-02-26 12:27:22 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open access MFL",
      "screen_name" : "YazikOpen",
      "indices" : [ 3, 13 ],
      "id_str" : "411834669",
      "id" : 411834669
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 111, 117 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/efkO7sFKdf",
      "expanded_url" : "http:\/\/bit.ly\/XUZMsj",
      "display_url" : "bit.ly\/XUZMsj"
    } ]
  },
  "geo" : { },
  "id_str" : "306173065337925632",
  "text" : "MT @YazikOpen: Statistics for the Humanities is now available in preview. Free d\/l. http:\/\/t.co\/efkO7sFKdf  cc @EBEFL",
  "id" : 306173065337925632,
  "created_at" : "2013-02-25 22:45:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "European Tribune",
      "screen_name" : "EuropeanTribune",
      "indices" : [ 80, 96 ],
      "id_str" : "568326306",
      "id" : 568326306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/HAlewQimoo",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2013\/2\/20\/163244\/612",
      "display_url" : "eurotrib.com\/story\/2013\/2\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306137117556367362",
  "text" : "Tires and deep fryers: competitiveness in the 2010's http:\/\/t.co\/HAlewQimoo via @EuropeanTribune",
  "id" : 306137117556367362,
  "created_at" : "2013-02-25 20:22:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305932719160963075",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard appreciate the RT Rose, have a good week :)",
  "id" : 305932719160963075,
  "created_at" : "2013-02-25 06:50:18 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305172612311560192",
  "geo" : { },
  "id_str" : "305799200048836609",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow cheers Kev, will look fwd to that :), though Europe surely beckons u first ;)",
  "id" : 305799200048836609,
  "in_reply_to_status_id" : 305172612311560192,
  "created_at" : "2013-02-24 21:59:45 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Larkin",
      "screen_name" : "patrickmlarkin",
      "indices" : [ 3, 18 ],
      "id_str" : "19074827",
      "id" : 19074827
    }, {
      "name" : "Dennis Villano",
      "screen_name" : "dvillanojr",
      "indices" : [ 118, 129 ],
      "id_str" : "128535697",
      "id" : 128535697
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UIIw6bPiUx",
      "expanded_url" : "http:\/\/bit.ly\/WfgTCA",
      "display_url" : "bit.ly\/WfgTCA"
    } ]
  },
  "geo" : { },
  "id_str" : "305039465674600448",
  "text" : "RT @patrickmlarkin: This looks interesting - WiFli Student Response System for Google Drive http:\/\/t.co\/UIIw6bPiUx cc @dvillanojr #google",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dennis Villano",
        "screen_name" : "dvillanojr",
        "indices" : [ 98, 109 ],
        "id_str" : "128535697",
        "id" : 128535697
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "google",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/UIIw6bPiUx",
        "expanded_url" : "http:\/\/bit.ly\/WfgTCA",
        "display_url" : "bit.ly\/WfgTCA"
      } ]
    },
    "geo" : { },
    "id_str" : "305006781233516545",
    "text" : "This looks interesting - WiFli Student Response System for Google Drive http:\/\/t.co\/UIIw6bPiUx cc @dvillanojr #google",
    "id" : 305006781233516545,
    "created_at" : "2013-02-22 17:30:58 +0000",
    "user" : {
      "name" : "Patrick Larkin",
      "screen_name" : "patrickmlarkin",
      "protected" : false,
      "id_str" : "19074827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479825616842137600\/mNYZ-arM_normal.jpeg",
      "id" : 19074827,
      "verified" : false
    }
  },
  "id" : 305039465674600448,
  "created_at" : "2013-02-22 19:40:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 39, 43 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "tefl",
      "indices" : [ 64, 69 ]
    }, {
      "text" : "esl",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "esol",
      "indices" : [ 75, 80 ]
    }, {
      "text" : "tesl",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eewBoZYNb0",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-zf",
      "display_url" : "wp.me\/p2hCXG-zf"
    } ]
  },
  "geo" : { },
  "id_str" : "305037042608394240",
  "text" : "RT @MrChrisJWilson: Weekly Round up in #ELT 22\/02\/2013 #eltchat #tefl #esl #esol #tesl http:\/\/t.co\/eewBoZYNb0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 35, 43 ]
      }, {
        "text" : "tefl",
        "indices" : [ 44, 49 ]
      }, {
        "text" : "esl",
        "indices" : [ 50, 54 ]
      }, {
        "text" : "esol",
        "indices" : [ 55, 60 ]
      }, {
        "text" : "tesl",
        "indices" : [ 61, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/eewBoZYNb0",
        "expanded_url" : "http:\/\/wp.me\/p2hCXG-zf",
        "display_url" : "wp.me\/p2hCXG-zf"
      } ]
    },
    "geo" : { },
    "id_str" : "305010016480555008",
    "text" : "Weekly Round up in #ELT 22\/02\/2013 #eltchat #tefl #esl #esol #tesl http:\/\/t.co\/eewBoZYNb0",
    "id" : 305010016480555008,
    "created_at" : "2013-02-22 17:43:49 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 305037042608394240,
  "created_at" : "2013-02-22 19:31:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 9, 24 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Ava Fruin",
      "screen_name" : "avafruin",
      "indices" : [ 25, 34 ],
      "id_str" : "22528522",
      "id" : 22528522
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 35, 46 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304991823246536704",
  "geo" : { },
  "id_str" : "305010120360878080",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey @MrChrisJWilson @avafruin @leoselivan +1 i agree :)",
  "id" : 305010120360878080,
  "in_reply_to_status_id" : 304991823246536704,
  "created_at" : "2013-02-22 17:44:14 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SGI Tesol Training",
      "screen_name" : "TesolTrainingUK",
      "indices" : [ 3, 19 ],
      "id_str" : "353681537",
      "id" : 353681537
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 33, 46 ],
      "id_str" : "39718253",
      "id" : 39718253
    }, {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 47, 55 ],
      "id_str" : "21094022",
      "id" : 21094022
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 56, 65 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEFL",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Na3mMo8XIQ",
      "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/workshops-conferences\/tefl-questions-about-real-world-frontline-teaching-answered-by-experts\/",
      "display_url" : "tesoltraining.co.uk\/blog\/workshops\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305009813392347136",
  "text" : "RT @TesolTrainingUK: Experts inc @LukeMeddings @Harmerj @chiasuan answer tricky #TEFL Qs on video... &amp; some Qs of my own for you!  h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Meddings",
        "screen_name" : "LukeMeddings",
        "indices" : [ 12, 25 ],
        "id_str" : "39718253",
        "id" : 39718253
      }, {
        "name" : "Jeremy Harmer",
        "screen_name" : "Harmerj",
        "indices" : [ 26, 34 ],
        "id_str" : "21094022",
        "id" : 21094022
      }, {
        "name" : "Chia Suan Chong",
        "screen_name" : "chiasuan",
        "indices" : [ 35, 44 ],
        "id_str" : "71588589",
        "id" : 71588589
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEFL",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "elt",
        "indices" : [ 137, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Na3mMo8XIQ",
        "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/workshops-conferences\/tefl-questions-about-real-world-frontline-teaching-answered-by-experts\/",
        "display_url" : "tesoltraining.co.uk\/blog\/workshops\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304998829332250624",
    "text" : "Experts inc @LukeMeddings @Harmerj @chiasuan answer tricky #TEFL Qs on video... &amp; some Qs of my own for you!  http:\/\/t.co\/Na3mMo8XIQ #elt",
    "id" : 304998829332250624,
    "created_at" : "2013-02-22 16:59:22 +0000",
    "user" : {
      "name" : "SGI Tesol Training",
      "screen_name" : "TesolTrainingUK",
      "protected" : false,
      "id_str" : "353681537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1491564841\/SGI-teacher-training-specialists_normal.jpg",
      "id" : 353681537,
      "verified" : false
    }
  },
  "id" : 305009813392347136,
  "created_at" : "2013-02-22 17:43:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "tesol",
      "indices" : [ 96, 102 ]
    }, {
      "text" : "elt",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/s6b05mbqkk",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-mm",
      "display_url" : "wp.me\/pgHyE-mm"
    } ]
  },
  "geo" : { },
  "id_str" : "305008347743129600",
  "text" : "blog post, Quick cup of COCA - quantifiers and relative clauses http:\/\/t.co\/s6b05mbqkk #eltchat #tesol #elt",
  "id" : 305008347743129600,
  "created_at" : "2013-02-22 17:37:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 21, 34 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 35, 45 ],
      "id_str" : "90093887",
      "id" : 90093887
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 46, 62 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304714152541310979",
  "text" : "@harrisonmike @EBEFL @TheSecretDoS @pterolaur @michaelegriffin how about only open ELT journals?",
  "id" : 304714152541310979,
  "created_at" : "2013-02-21 22:08:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 52, 62 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Oegb6A3C23",
      "expanded_url" : "http:\/\/wp.me\/pglsT-3Qp",
      "display_url" : "wp.me\/pglsT-3Qp"
    } ]
  },
  "geo" : { },
  "id_str" : "304631572966019072",
  "text" : "Link love: language (51) http:\/\/t.co\/Oegb6A3C23 via @StanCarey",
  "id" : 304631572966019072,
  "created_at" : "2013-02-21 16:40:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 20, 28 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "JeselleVictoria",
      "screen_name" : "jesellers",
      "indices" : [ 139, 140 ],
      "id_str" : "706016450733961216",
      "id" : 706016450733961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "literacies",
      "indices" : [ 118, 129 ]
    }, {
      "text" : "nwp",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/nBFt5iKLbE",
      "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/02\/21\/composing-interactive-fiction-4-resources-ideas-possibilities\/#.USYDuFKUWAc.twitter",
      "display_url" : "dogtrax.edublogs.org\/2013\/02\/21\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304570909379948545",
  "text" : "RT @chadsansing: RT @dogtrax: Composing Interactive Fiction 4: Resources, Ideas, Possibilities http:\/\/t.co\/nBFt5iKLbE #literacies #nwp @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KevinHodgson",
        "screen_name" : "dogtrax",
        "indices" : [ 3, 11 ],
        "id_str" : "13307352",
        "id" : 13307352
      }, {
        "name" : "JeselleVictoria",
        "screen_name" : "jesellers",
        "indices" : [ 118, 128 ],
        "id_str" : "706016450733961216",
        "id" : 706016450733961216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "literacies",
        "indices" : [ 101, 112 ]
      }, {
        "text" : "nwp",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/nBFt5iKLbE",
        "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/02\/21\/composing-interactive-fiction-4-resources-ideas-possibilities\/#.USYDuFKUWAc.twitter",
        "display_url" : "dogtrax.edublogs.org\/2013\/02\/21\/com\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304565836255997952",
    "text" : "RT @dogtrax: Composing Interactive Fiction 4: Resources, Ideas, Possibilities http:\/\/t.co\/nBFt5iKLbE #literacies #nwp @jesellers...",
    "id" : 304565836255997952,
    "created_at" : "2013-02-21 12:18:48 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 304570909379948545,
  "created_at" : "2013-02-21 12:38:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/HEpTAMEu1h",
      "expanded_url" : "http:\/\/www.nodashforgas.org.uk\/blog\/press-release-edf-suing-climate-activists-for-5-million---protesters-face-losing-homes",
      "display_url" : "nodashforgas.org.uk\/blog\/press-rel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304551150387085313",
  "text" : "EDF suing climate activists for \u00A35 million - protesters face losing homes http:\/\/t.co\/HEpTAMEu1h",
  "id" : 304551150387085313,
  "created_at" : "2013-02-21 11:20:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304525973175554048",
  "geo" : { },
  "id_str" : "304535458300440577",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha yr welcome",
  "id" : 304535458300440577,
  "in_reply_to_status_id" : 304525973175554048,
  "created_at" : "2013-02-21 10:18:05 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 108, 119 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "edtech",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/t7SORXNHCP",
      "expanded_url" : "http:\/\/bit.ly\/Xq3qbm",
      "display_url" : "bit.ly\/Xq3qbm"
    } ]
  },
  "geo" : { },
  "id_str" : "304535238439227394",
  "text" : "RT @leoselivan: RT @becksdad: great blog on lexical stuff, very practical http:\/\/t.co\/t7SORXNHCP good work  @leoselivan  #esl #edtech &g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 92, 103 ],
        "id_str" : "408365496",
        "id" : 408365496
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esl",
        "indices" : [ 105, 109 ]
      }, {
        "text" : "edtech",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/t7SORXNHCP",
        "expanded_url" : "http:\/\/bit.ly\/Xq3qbm",
        "display_url" : "bit.ly\/Xq3qbm"
      } ]
    },
    "geo" : { },
    "id_str" : "304477998558613504",
    "text" : "RT @becksdad: great blog on lexical stuff, very practical http:\/\/t.co\/t7SORXNHCP good work  @leoselivan  #esl #edtech &gt;thanks!",
    "id" : 304477998558613504,
    "created_at" : "2013-02-21 06:29:46 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 304535238439227394,
  "created_at" : "2013-02-21 10:17:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "esol",
      "indices" : [ 113, 118 ]
    }, {
      "text" : "horsemeat",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YgUeUOFQ",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-c1",
      "display_url" : "wp.me\/p2e2Wf-c1"
    } ]
  },
  "geo" : { },
  "id_str" : "304518856796409857",
  "text" : "RT @teflerinha: You won't believe your eyes...The chicken nugget experiment- a free downloadable lesson #eltchat #esol #horsemeat http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "esol",
        "indices" : [ 97, 102 ]
      }, {
        "text" : "horsemeat",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/YgUeUOFQ",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-c1",
        "display_url" : "wp.me\/p2e2Wf-c1"
      } ]
    },
    "geo" : { },
    "id_str" : "304512787630133248",
    "text" : "You won't believe your eyes...The chicken nugget experiment- a free downloadable lesson #eltchat #esol #horsemeat http:\/\/t.co\/YgUeUOFQ",
    "id" : 304512787630133248,
    "created_at" : "2013-02-21 08:48:00 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 304518856796409857,
  "created_at" : "2013-02-21 09:12:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 62, 68 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/0anAHSKH70",
      "expanded_url" : "http:\/\/wp.me\/p2NUdz-2w",
      "display_url" : "wp.me\/p2NUdz-2w"
    } ]
  },
  "geo" : { },
  "id_str" : "304516523328937984",
  "text" : "Small changes: My 6 week challenge http:\/\/t.co\/0anAHSKH70 via @GemL1",
  "id" : 304516523328937984,
  "created_at" : "2013-02-21 09:02:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 75, 90 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Konglish",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xyYWWhRQPN",
      "expanded_url" : "http:\/\/www.eltsquared.co.uk\/international-words\/",
      "display_url" : "eltsquared.co.uk\/international-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304515252966543360",
  "text" : "RT @AnneHendler: The benefits and dangers of using international words via @MrChrisJWilson http:\/\/t.co\/xyYWWhRQPN (Thinking of the #Kong ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Wilson",
        "screen_name" : "MrChrisJWilson",
        "indices" : [ 58, 73 ],
        "id_str" : "20760283",
        "id" : 20760283
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Konglish",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/xyYWWhRQPN",
        "expanded_url" : "http:\/\/www.eltsquared.co.uk\/international-words\/",
        "display_url" : "eltsquared.co.uk\/international-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304510257936347136",
    "text" : "The benefits and dangers of using international words via @MrChrisJWilson http:\/\/t.co\/xyYWWhRQPN (Thinking of the #Konglish implications...)",
    "id" : 304510257936347136,
    "created_at" : "2013-02-21 08:37:57 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 304515252966543360,
  "created_at" : "2013-02-21 08:57:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304326611354931200",
  "geo" : { },
  "id_str" : "304357226993311744",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus frm page u want&gt;with Firefox Tools\/PageInfo\/Media tab u will see mp3 in list.",
  "id" : 304357226993311744,
  "in_reply_to_status_id" : 304326611354931200,
  "created_at" : "2013-02-20 22:29:52 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304169028849647616",
  "geo" : { },
  "id_str" : "304235259229253632",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako hi, it's the other video on the youtube channel, using song 500 miles",
  "id" : 304235259229253632,
  "in_reply_to_status_id" : 304169028849647616,
  "created_at" : "2013-02-20 14:25:12 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Playfic",
      "screen_name" : "playfic",
      "indices" : [ 3, 11 ],
      "id_str" : "164426667",
      "id" : 164426667
    }, {
      "name" : "JeselleVictoria",
      "screen_name" : "jesellers",
      "indices" : [ 19, 29 ],
      "id_str" : "706016450733961216",
      "id" : 706016450733961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/THecpzdk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=00vEyUvPrkM",
      "display_url" : "youtube.com\/watch?v=00vEyU\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6fVQV4bP",
      "expanded_url" : "http:\/\/crookedletter.org\/?p=490",
      "display_url" : "crookedletter.org\/?p=490"
    } ]
  },
  "geo" : { },
  "id_str" : "304110257733513218",
  "text" : "RT @playfic: Whoa, @jesellers is using Playfic to teach interactive fiction to high school students: http:\/\/t.co\/THecpzdk More: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JeselleVictoria",
        "screen_name" : "jesellers",
        "indices" : [ 6, 16 ],
        "id_str" : "706016450733961216",
        "id" : 706016450733961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/THecpzdk",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=00vEyUvPrkM",
        "display_url" : "youtube.com\/watch?v=00vEyU\u2026"
      }, {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/6fVQV4bP",
        "expanded_url" : "http:\/\/crookedletter.org\/?p=490",
        "display_url" : "crookedletter.org\/?p=490"
      } ]
    },
    "geo" : { },
    "id_str" : "304019784998219776",
    "text" : "Whoa, @jesellers is using Playfic to teach interactive fiction to high school students: http:\/\/t.co\/THecpzdk More: http:\/\/t.co\/6fVQV4bP",
    "id" : 304019784998219776,
    "created_at" : "2013-02-20 00:08:59 +0000",
    "user" : {
      "name" : "Playfic",
      "screen_name" : "playfic",
      "protected" : false,
      "id_str" : "164426667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1829811712\/cursor_shiny_icon_normal.png",
      "id" : 164426667,
      "verified" : false
    }
  },
  "id" : 304110257733513218,
  "created_at" : "2013-02-20 06:08:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303991603884875776",
  "geo" : { },
  "id_str" : "304010458862608384",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako neat, the proclaimers one is good as well",
  "id" : 304010458862608384,
  "in_reply_to_status_id" : 303991603884875776,
  "created_at" : "2013-02-19 23:31:56 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Boyle",
      "screen_name" : "elyoBSekiM",
      "indices" : [ 0, 11 ],
      "id_str" : "1324597350",
      "id" : 1324597350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303995017570168833",
  "geo" : { },
  "id_str" : "303997497569865729",
  "in_reply_to_user_id" : 612840231,
  "text" : "@elyoBSekiM a strong version of Sapir-Whorf, language log has a few posts on Keith Chen",
  "id" : 303997497569865729,
  "in_reply_to_status_id" : 303995017570168833,
  "created_at" : "2013-02-19 22:40:26 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UzRudh15",
      "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/02\/18\/bulger-and-cultural-references\/",
      "display_url" : "blog.westminster.ac.uk\/celt\/2013\/02\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303991534754340864",
  "text" : "RT @CELTtraining: Jamie Bulger anniversary last week. How many cultural refernces like this? Do EFL students need to know? http:\/\/t.co\/U ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/UzRudh15",
        "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/02\/18\/bulger-and-cultural-references\/",
        "display_url" : "blog.westminster.ac.uk\/celt\/2013\/02\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303552695380348928",
    "text" : "Jamie Bulger anniversary last week. How many cultural refernces like this? Do EFL students need to know? http:\/\/t.co\/UzRudh15",
    "id" : 303552695380348928,
    "created_at" : "2013-02-18 17:12:56 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 303991534754340864,
  "created_at" : "2013-02-19 22:16:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303879639506505728",
  "geo" : { },
  "id_str" : "303991037108555777",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar cheers for the recommendation Hugh :)",
  "id" : 303991037108555777,
  "in_reply_to_status_id" : 303879639506505728,
  "created_at" : "2013-02-19 22:14:45 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 107, 119 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/48mARPXt",
      "expanded_url" : "http:\/\/lexicoblog.blogspot.co.uk\/2013\/02\/google-wikipedia-and-journey-from.html",
      "display_url" : "lexicoblog.blogspot.co.uk\/2013\/02\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303982990596403200",
  "text" : "RT @seburnt: Google, Wikipedia and the journey from \u2018information\u2019 to \u2018knowledge\u2019 \nhttp:\/\/t.co\/48mARPXt via @lexicojules #EAPchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Moore",
        "screen_name" : "lexicojules",
        "indices" : [ 94, 106 ],
        "id_str" : "424320799",
        "id" : 424320799
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAPchat",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/48mARPXt",
        "expanded_url" : "http:\/\/lexicoblog.blogspot.co.uk\/2013\/02\/google-wikipedia-and-journey-from.html",
        "display_url" : "lexicoblog.blogspot.co.uk\/2013\/02\/google\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303930230907744256",
    "text" : "Google, Wikipedia and the journey from \u2018information\u2019 to \u2018knowledge\u2019 \nhttp:\/\/t.co\/48mARPXt via @lexicojules #EAPchat",
    "id" : 303930230907744256,
    "created_at" : "2013-02-19 18:13:08 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 303982990596403200,
  "created_at" : "2013-02-19 21:42:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 0, 11 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303920294765133824",
  "geo" : { },
  "id_str" : "303982336809267200",
  "in_reply_to_user_id" : 897738066,
  "text" : "@jo_cummins a pleasure :)",
  "id" : 303982336809267200,
  "in_reply_to_status_id" : 303920294765133824,
  "created_at" : "2013-02-19 21:40:11 +0000",
  "in_reply_to_screen_name" : "jo_cummins",
  "in_reply_to_user_id_str" : "897738066",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 14, 30 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 31, 42 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303982217544204288",
  "text" : "@TheSecretDoS @michaelegriffin @jo_cummins eh up glad that's sorted :) now wtf is ECRIF?",
  "id" : 303982217544204288,
  "created_at" : "2013-02-19 21:39:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 3, 14 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/K4FLfqed",
      "expanded_url" : "http:\/\/wp.me\/p31JKG-7R",
      "display_url" : "wp.me\/p31JKG-7R"
    } ]
  },
  "geo" : { },
  "id_str" : "303908518887583744",
  "text" : "RT @jo_cummins: New blog post on using 'Very Short Stories' in class. http:\/\/t.co\/K4FLfqed #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 75, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/K4FLfqed",
        "expanded_url" : "http:\/\/wp.me\/p31JKG-7R",
        "display_url" : "wp.me\/p31JKG-7R"
      } ]
    },
    "geo" : { },
    "id_str" : "303906988969041922",
    "text" : "New blog post on using 'Very Short Stories' in class. http:\/\/t.co\/K4FLfqed #eltchat",
    "id" : 303906988969041922,
    "created_at" : "2013-02-19 16:40:47 +0000",
    "user" : {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "protected" : false,
      "id_str" : "897738066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2750667370\/74ec8eb84782e520ece4d20193e749a1_normal.jpeg",
      "id" : 897738066,
      "verified" : false
    }
  },
  "id" : 303908518887583744,
  "created_at" : "2013-02-19 16:46:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet Symmons",
      "screen_name" : "JanetSymmons",
      "indices" : [ 0, 13 ],
      "id_str" : "140522452",
      "id" : 140522452
    }, {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 15, 24 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303890514128809984",
  "geo" : { },
  "id_str" : "303906802985226240",
  "in_reply_to_user_id" : 140522452,
  "text" : "@JanetSymmons  @oyajimbo post cmts point out mobile co sponsored study &amp; online interview method will have selection bias. still int thgh.",
  "id" : 303906802985226240,
  "in_reply_to_status_id" : 303890514128809984,
  "created_at" : "2013-02-19 16:40:02 +0000",
  "in_reply_to_screen_name" : "JanetSymmons",
  "in_reply_to_user_id_str" : "140522452",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 11, 17 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 18, 31 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 32, 48 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303866580280958980",
  "geo" : { },
  "id_str" : "303869220448505857",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur @EBEFL @TheSecretDoS @michaelegriffin +1 for article reading club :)",
  "id" : 303869220448505857,
  "in_reply_to_status_id" : 303866580280958980,
  "created_at" : "2013-02-19 14:10:42 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303860838094237696",
  "text" : "RT @KateMfD: I want all the MOOC crusaders to go back into the phone box, change back into their ordinary clothes, and stop saving us. T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303838369509695489",
    "text" : "I want all the MOOC crusaders to go back into the phone box, change back into their ordinary clothes, and stop saving us. Think first.",
    "id" : 303838369509695489,
    "created_at" : "2013-02-19 12:08:06 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 303860838094237696,
  "created_at" : "2013-02-19 13:37:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gSGHZWlo",
      "expanded_url" : "http:\/\/bit.ly\/VnvTni",
      "display_url" : "bit.ly\/VnvTni"
    } ]
  },
  "geo" : { },
  "id_str" : "303857381702520832",
  "text" : "RT @CraigMurrayOrg: Celebrating Correa\u2019s Re-election: I am going to an election party in the Ecuador Embassy on Sunday. I shall do s...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/gSGHZWlo",
        "expanded_url" : "http:\/\/bit.ly\/VnvTni",
        "display_url" : "bit.ly\/VnvTni"
      } ]
    },
    "geo" : { },
    "id_str" : "302532264816943105",
    "text" : "Celebrating Correa\u2019s Re-election: I am going to an election party in the Ecuador Embassy on Sunday. I shall do s... http:\/\/t.co\/gSGHZWlo",
    "id" : 302532264816943105,
    "created_at" : "2013-02-15 21:38:07 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 303857381702520832,
  "created_at" : "2013-02-19 13:23:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 14, 25 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303854490984001537",
  "text" : "@TheSecretDoS @jo_cummins great :) self-organising FTW",
  "id" : 303854490984001537,
  "created_at" : "2013-02-19 13:12:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303833996498980865",
  "geo" : { },
  "id_str" : "303843081369812993",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith enjoyed revisit :) Wilson http:\/\/203.72.145.166\/ELT\/files\/57-4-2.pdf and Field pdfs http:\/\/203.72.145.166\/ELT\/files\/57-4-1.pdf",
  "id" : 303843081369812993,
  "in_reply_to_status_id" : 303833996498980865,
  "created_at" : "2013-02-19 12:26:50 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/1QutRZrZ",
      "expanded_url" : "http:\/\/wp.me\/p2n3Kv-2b",
      "display_url" : "wp.me\/p2n3Kv-2b"
    } ]
  },
  "geo" : { },
  "id_str" : "303839116775276544",
  "text" : "RT @ElkySmith: 'Discovery Listening' revisited (again) - a joint post with Arun Warszawski http:\/\/t.co\/1QutRZrZ #AusELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AusELT",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/1QutRZrZ",
        "expanded_url" : "http:\/\/wp.me\/p2n3Kv-2b",
        "display_url" : "wp.me\/p2n3Kv-2b"
      } ]
    },
    "geo" : { },
    "id_str" : "303833996498980865",
    "text" : "'Discovery Listening' revisited (again) - a joint post with Arun Warszawski http:\/\/t.co\/1QutRZrZ #AusELT",
    "id" : 303833996498980865,
    "created_at" : "2013-02-19 11:50:44 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 303839116775276544,
  "created_at" : "2013-02-19 12:11:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Adams",
      "screen_name" : "LesAdams3",
      "indices" : [ 3, 13 ],
      "id_str" : "581792166",
      "id" : 581792166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303837379351941120",
  "text" : "RT @LesAdams3: Radical, almost anarchist, idea from IDS. We all get a go at shelf-stacking so (by implication) all get a turn at being w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303276628576968705",
    "text" : "Radical, almost anarchist, idea from IDS. We all get a go at shelf-stacking so (by implication) all get a turn at being work secretary too?",
    "id" : 303276628576968705,
    "created_at" : "2013-02-17 22:55:57 +0000",
    "user" : {
      "name" : "Les Adams",
      "screen_name" : "LesAdams3",
      "protected" : false,
      "id_str" : "581792166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2330611582\/rldnjf1zjs9alsju5w02_normal.jpeg",
      "id" : 581792166,
      "verified" : false
    }
  },
  "id" : 303837379351941120,
  "created_at" : "2013-02-19 12:04:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/NnDA8bpv",
      "expanded_url" : "http:\/\/ow.ly\/hPpXu",
      "display_url" : "ow.ly\/hPpXu"
    } ]
  },
  "geo" : { },
  "id_str" : "303823431881859072",
  "text" : "RT @BoingBoing: What did the word \"Twitter\" mean in the late 1800s? Glad you asked. http:\/\/t.co\/NnDA8bpv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/NnDA8bpv",
        "expanded_url" : "http:\/\/ow.ly\/hPpXu",
        "display_url" : "ow.ly\/hPpXu"
      } ]
    },
    "geo" : { },
    "id_str" : "303630899227025408",
    "text" : "What did the word \"Twitter\" mean in the late 1800s? Glad you asked. http:\/\/t.co\/NnDA8bpv",
    "id" : 303630899227025408,
    "created_at" : "2013-02-18 22:23:42 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 303823431881859072,
  "created_at" : "2013-02-19 11:08:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 28, 39 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303815189025927168",
  "text" : "a tuesday tip of the hat to @leoselivan for number and quality of ELT pdfs :) ta leo!",
  "id" : 303815189025927168,
  "created_at" : "2013-02-19 10:36:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303790650732732416",
  "geo" : { },
  "id_str" : "303800855273021441",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow nice find",
  "id" : 303800855273021441,
  "in_reply_to_status_id" : 303790650732732416,
  "created_at" : "2013-02-19 09:39:02 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MindsDoWander",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/kRM9iJvj",
      "expanded_url" : "http:\/\/gking.harvard.edu\/files\/gking\/files\/teach.pdf",
      "display_url" : "gking.harvard.edu\/files\/gking\/fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303800321526861825",
  "text" : "RT @kevchanwow: Gary King &amp; Maya Sen on how Social science research can improve teaching. Well worth the read: http:\/\/t.co\/kRM9iJvj  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MindsDoWander",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/kRM9iJvj",
        "expanded_url" : "http:\/\/gking.harvard.edu\/files\/gking\/files\/teach.pdf",
        "display_url" : "gking.harvard.edu\/files\/gking\/fi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303790650732732416",
    "text" : "Gary King &amp; Maya Sen on how Social science research can improve teaching. Well worth the read: http:\/\/t.co\/kRM9iJvj #MindsDoWander",
    "id" : 303790650732732416,
    "created_at" : "2013-02-19 08:58:29 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 303800321526861825,
  "created_at" : "2013-02-19 09:36:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 0, 11 ],
      "id_str" : "897738066",
      "id" : 897738066
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 12, 25 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303795385229516800",
  "geo" : { },
  "id_str" : "303799092730019840",
  "in_reply_to_user_id" : 897738066,
  "text" : "@jo_cummins @TheSecretDoS raises question why we need managers at all",
  "id" : 303799092730019840,
  "in_reply_to_status_id" : 303795385229516800,
  "created_at" : "2013-02-19 09:32:02 +0000",
  "in_reply_to_screen_name" : "jo_cummins",
  "in_reply_to_user_id_str" : "897738066",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 3, 16 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5XZ8oXtR",
      "expanded_url" : "http:\/\/fb.me\/2LyXgBOj2",
      "display_url" : "fb.me\/2LyXgBOj2"
    } ]
  },
  "geo" : { },
  "id_str" : "303642527708372992",
  "text" : "RT @Sharonzspace: Considering a second (or new) times for #EAPchat to accommodate more participation.  Please let me know of your... htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAPchat",
        "indices" : [ 40, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/5XZ8oXtR",
        "expanded_url" : "http:\/\/fb.me\/2LyXgBOj2",
        "display_url" : "fb.me\/2LyXgBOj2"
      } ]
    },
    "geo" : { },
    "id_str" : "303641219312013314",
    "text" : "Considering a second (or new) times for #EAPchat to accommodate more participation.  Please let me know of your... http:\/\/t.co\/5XZ8oXtR",
    "id" : 303641219312013314,
    "created_at" : "2013-02-18 23:04:42 +0000",
    "user" : {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "protected" : false,
      "id_str" : "235194378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1228523517\/books_normal.JPG",
      "id" : 235194378,
      "verified" : false
    }
  },
  "id" : 303642527708372992,
  "created_at" : "2013-02-18 23:09:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/00LURTYT",
      "expanded_url" : "http:\/\/wg.serpmedia.org\/introducing_words.html",
      "display_url" : "wg.serpmedia.org\/introducing_wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303637189365989376",
  "text" : "very interesting project &amp; website&gt;Word Generation:Introducing new words http:\/\/t.co\/00LURTYT #eltchat",
  "id" : 303637189365989376,
  "created_at" : "2013-02-18 22:48:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 9, 25 ],
      "id_str" : "78543378",
      "id" : 78543378
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 26, 37 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303570595579310081",
  "geo" : { },
  "id_str" : "303626558881558529",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @yearinthelifeof @JenMac_ESL sorry missed out, next time!",
  "id" : 303626558881558529,
  "in_reply_to_status_id" : 303570595579310081,
  "created_at" : "2013-02-18 22:06:27 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 7, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/9H60NdS3",
      "expanded_url" : "http:\/\/hawksey.info\/tagsexplorer\/?key=txvQFGaRPV0juVyLGkwOlDw&sheet=oaw",
      "display_url" : "hawksey.info\/tagsexplorer\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303625873138020354",
  "text" : "missed #eapchat, used TAGSExplorer to catch up, best in Google Chrome http:\/\/t.co\/9H60NdS3",
  "id" : 303625873138020354,
  "created_at" : "2013-02-18 22:03:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rJWNhWgX",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-yy",
      "display_url" : "wp.me\/p2hCXG-yy"
    } ]
  },
  "geo" : { },
  "id_str" : "303618212942196736",
  "text" : "RT @MrChrisJWilson: Few! Finished the last #eltchat summary on \"How to survive, and make the most of, your delta or similar course.\" htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/rJWNhWgX",
        "expanded_url" : "http:\/\/wp.me\/p2hCXG-yy",
        "display_url" : "wp.me\/p2hCXG-yy"
      } ]
    },
    "geo" : { },
    "id_str" : "303435820138897409",
    "text" : "Few! Finished the last #eltchat summary on \"How to survive, and make the most of, your delta or similar course.\" http:\/\/t.co\/rJWNhWgX",
    "id" : 303435820138897409,
    "created_at" : "2013-02-18 09:28:31 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 303618212942196736,
  "created_at" : "2013-02-18 21:33:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/szaIqqYO",
      "expanded_url" : "http:\/\/www.dialectsarchive.com\/",
      "display_url" : "dialectsarchive.com"
    } ]
  },
  "in_reply_to_status_id_str" : "303399030040453120",
  "geo" : { },
  "id_str" : "303413005419442176",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus have you tried the the IDEA archive? http:\/\/t.co\/szaIqqYO",
  "id" : 303413005419442176,
  "in_reply_to_status_id" : 303399030040453120,
  "created_at" : "2013-02-18 07:57:52 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303259987709423616",
  "geo" : { },
  "id_str" : "303267987559960576",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson not aware ferguson's defence, no surprise given his past form; politicos rely on emotion need to counter likewise",
  "id" : 303267987559960576,
  "in_reply_to_status_id" : 303259987709423616,
  "created_at" : "2013-02-17 22:21:37 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/owJD6ct9",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/politics\/2013\/feb\/16\/historians-gove-curriculum",
      "display_url" : "guardian.co.uk\/politics\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303259722717478912",
  "text" : "'Old school and old-fashioned': historians turn their fire on Gove\nhttp:\/\/t.co\/owJD6ct9",
  "id" : 303259722717478912,
  "created_at" : "2013-02-17 21:48:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303177998515986434",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin cheers for RT mike, how's the beach? ;)",
  "id" : 303177998515986434,
  "created_at" : "2013-02-17 16:24:02 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 15, 26 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/xgm3YH5A",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/02\/14\/isnt-just-knowing-english-enough-raising-awareness-of-cultural-english\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/02\/14\/isn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303170355214835713",
  "text" : "short reply to @tornhalves on \nraising awareness of cultural English post\n http:\/\/t.co\/xgm3YH5A",
  "id" : 303170355214835713,
  "created_at" : "2013-02-17 15:53:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/IqLloipQ",
      "expanded_url" : "http:\/\/brianhaw.tv\/index.php\/blog\/1432-video-arrest-is-an-umbrella-a-bigger-crime-than-genocide-",
      "display_url" : "brianhaw.tv\/index.php\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302852817411006464",
  "text" : "VIDEO... \"ARREST\": IS AN UMBRELLA A BIGGER CRIME THAN GENOCIDE ?http:\/\/t.co\/IqLloipQ",
  "id" : 302852817411006464,
  "created_at" : "2013-02-16 18:51:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/Bakay3fb",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1360945650.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302544422468456448",
  "text" : "Bladerunners and whistleblowers http:\/\/t.co\/Bakay3fb",
  "id" : 302544422468456448,
  "created_at" : "2013-02-15 22:26:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 7, 18 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/HOfz8DpS",
      "expanded_url" : "http:\/\/www.macmillandictionary.com\/red-word-game\/",
      "display_url" : "macmillandictionary.com\/red-word-game\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302532659534495744",
  "text" : "thx to @teflerinha for intro to http:\/\/t.co\/HOfz8DpS , neat! and for comment on corpora post.",
  "id" : 302532659534495744,
  "created_at" : "2013-02-15 21:39:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 110, 121 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/sZKBM1Eb",
      "expanded_url" : "http:\/\/bit.ly\/12jBOeQ",
      "display_url" : "bit.ly\/12jBOeQ"
    } ]
  },
  "in_reply_to_status_id_str" : "302511526819020800",
  "geo" : { },
  "id_str" : "302529681096318976",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac assume u mean RSA and not the Maintain eye contact vid :) have a read of this http:\/\/t.co\/sZKBM1Eb by @tornhalves",
  "id" : 302529681096318976,
  "in_reply_to_status_id" : 302511526819020800,
  "created_at" : "2013-02-15 21:27:51 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302489669961125888",
  "geo" : { },
  "id_str" : "302494166703828992",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble  nice find, ta.",
  "id" : 302494166703828992,
  "in_reply_to_status_id" : 302489669961125888,
  "created_at" : "2013-02-15 19:06:44 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302480438436450304",
  "geo" : { },
  "id_str" : "302493521120751616",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson i like that moodle infographic, ta",
  "id" : 302493521120751616,
  "in_reply_to_status_id" : 302480438436450304,
  "created_at" : "2013-02-15 19:04:10 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 25, 36 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/3mpl2A8S",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-hr",
      "display_url" : "wp.me\/pgHyE-hr"
    } ]
  },
  "geo" : { },
  "id_str" : "302489324954464256",
  "text" : "thx to @CELTtraining and @hughdellar for more comments on corpora post http:\/\/t.co\/3mpl2A8S",
  "id" : 302489324954464256,
  "created_at" : "2013-02-15 18:47:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "esol",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "esl",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "tefl",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/D926SONK",
      "expanded_url" : "http:\/\/elt2.co.uk\/YvZSUV",
      "display_url" : "elt2.co.uk\/YvZSUV"
    } ]
  },
  "geo" : { },
  "id_str" : "302486441856991232",
  "text" : "RT @MrChrisJWilson: Latest ELT Squared round up for the week. Hope you enjoy it http:\/\/t.co\/D926SONK #eltchat #esol #esl #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "esol",
        "indices" : [ 90, 95 ]
      }, {
        "text" : "esl",
        "indices" : [ 96, 100 ]
      }, {
        "text" : "tefl",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/D926SONK",
        "expanded_url" : "http:\/\/elt2.co.uk\/YvZSUV",
        "display_url" : "elt2.co.uk\/YvZSUV"
      } ]
    },
    "geo" : { },
    "id_str" : "302480438436450304",
    "text" : "Latest ELT Squared round up for the week. Hope you enjoy it http:\/\/t.co\/D926SONK #eltchat #esol #esl #tefl",
    "id" : 302480438436450304,
    "created_at" : "2013-02-15 18:12:10 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 302486441856991232,
  "created_at" : "2013-02-15 18:36:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "ann foreman",
      "screen_name" : "ann_f",
      "indices" : [ 17, 23 ],
      "id_str" : "7173032",
      "id" : 7173032
    }, {
      "name" : "Uomo Inglese",
      "screen_name" : "LangInspired",
      "indices" : [ 24, 37 ],
      "id_str" : "750057139",
      "id" : 750057139
    }, {
      "name" : "Julie Raikou",
      "screen_name" : "JulieRaikou",
      "indices" : [ 38, 50 ],
      "id_str" : "157985894",
      "id" : 157985894
    }, {
      "name" : "EnglishTC",
      "screen_name" : "EnglishTC",
      "indices" : [ 51, 61 ],
      "id_str" : "364922516",
      "id" : 364922516
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 62, 75 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "10MillionDuneBuggies",
      "screen_name" : "phil_chappell",
      "indices" : [ 76, 90 ],
      "id_str" : "287874419",
      "id" : 287874419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302443704931737601",
  "geo" : { },
  "id_str" : "302485299634782208",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons @ann_f @LangInspired @JulieRaikou @EnglishTC @harrisonmike @phil_chappell fanatastic friday to all :)",
  "id" : 302485299634782208,
  "in_reply_to_status_id" : 302443704931737601,
  "created_at" : "2013-02-15 18:31:29 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302466257775632384",
  "geo" : { },
  "id_str" : "302484451932397568",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan that example with flight attendant is great, will use that in my intercultural comms skills class, cheers :)",
  "id" : 302484451932397568,
  "in_reply_to_status_id" : 302466257775632384,
  "created_at" : "2013-02-15 18:28:07 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "culture",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/l4mzAv0u",
      "expanded_url" : "http:\/\/www.eltknowledge.com\/understanding_intercultural_communication_part_1__saying_39no39_31678.aspx",
      "display_url" : "eltknowledge.com\/understanding_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302484227360972801",
  "text" : "RT @chiasuan: How do you say 'no' in your #culture ? Here's my newest post on Understanding Intercultural Communication-Saying 'no'! htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "culture",
        "indices" : [ 28, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/l4mzAv0u",
        "expanded_url" : "http:\/\/www.eltknowledge.com\/understanding_intercultural_communication_part_1__saying_39no39_31678.aspx",
        "display_url" : "eltknowledge.com\/understanding_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302466257775632384",
    "text" : "How do you say 'no' in your #culture ? Here's my newest post on Understanding Intercultural Communication-Saying 'no'! http:\/\/t.co\/l4mzAv0u",
    "id" : 302466257775632384,
    "created_at" : "2013-02-15 17:15:50 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 302484227360972801,
  "created_at" : "2013-02-15 18:27:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302348122623975424",
  "geo" : { },
  "id_str" : "302422344092250112",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana grazie mille valentina, bon weekend :)",
  "id" : 302422344092250112,
  "in_reply_to_status_id" : 302348122623975424,
  "created_at" : "2013-02-15 14:21:20 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/34a7nMHp",
      "expanded_url" : "http:\/\/wp.me\/PgHyE-kG",
      "display_url" : "wp.me\/PgHyE-kG"
    } ]
  },
  "in_reply_to_status_id_str" : "302326544741830656",
  "geo" : { },
  "id_str" : "302329932082728960",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 glad to help out did u find smthng int? here's a collection of open resource tools for research http:\/\/t.co\/34a7nMHp",
  "id" : 302329932082728960,
  "in_reply_to_status_id" : 302326544741830656,
  "created_at" : "2013-02-15 08:14:07 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302302036899278848",
  "geo" : { },
  "id_str" : "302321981418790912",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 cheers gemma, here's to a great weekend :)",
  "id" : 302321981418790912,
  "in_reply_to_status_id" : 302302036899278848,
  "created_at" : "2013-02-15 07:42:31 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302217575545335809",
  "text" : "decidedly underwhelmed by first episode of new Black Mirror, BoBo near fiction anyone? :\/ hope rest are better",
  "id" : 302217575545335809,
  "created_at" : "2013-02-15 00:47:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302171835498364928",
  "geo" : { },
  "id_str" : "302217001433182208",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol Elephant by Gus Van Sant is grt film, also the Chris Dorner manifesto has some interesting parts on sale of automatic weapons",
  "id" : 302217001433182208,
  "in_reply_to_status_id" : 302171835498364928,
  "created_at" : "2013-02-15 00:45:22 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302163762247507969",
  "geo" : { },
  "id_str" : "302165075643473921",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard the 2 refs linked in my post will help",
  "id" : 302165075643473921,
  "in_reply_to_status_id" : 302163762247507969,
  "created_at" : "2013-02-14 21:19:02 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/KqV8DyuK",
      "expanded_url" : "http:\/\/bit.ly\/Uk3xZh",
      "display_url" : "bit.ly\/Uk3xZh"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/9Q7x1OPT",
      "expanded_url" : "http:\/\/bit.ly\/Uk3xIL",
      "display_url" : "bit.ly\/Uk3xIL"
    } ]
  },
  "in_reply_to_status_id_str" : "301795549114421249",
  "geo" : { },
  "id_str" : "302161787808276480",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus very int, there are a @ posts agreeing with this-http:\/\/t.co\/KqV8DyuK &amp; http:\/\/t.co\/9Q7x1OPT",
  "id" : 302161787808276480,
  "in_reply_to_status_id" : 301795549114421249,
  "created_at" : "2013-02-14 21:05:58 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/fcFQBkGR",
      "expanded_url" : "http:\/\/youtu.be\/W7C83dg139A?a",
      "display_url" : "youtu.be\/W7C83dg139A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302140351282548736",
  "text" : "Fat grammar\/Spindly grammar&gt;grt conceptualization from Adrian Underhill http:\/\/t.co\/fcFQBkGR",
  "id" : 302140351282548736,
  "created_at" : "2013-02-14 19:40:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 3, 12 ],
      "id_str" : "130149739",
      "id" : 130149739
    }, {
      "name" : "International House",
      "screen_name" : "IHWorld",
      "indices" : [ 17, 25 ],
      "id_str" : "28518542",
      "id" : 28518542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/0uonCGDl",
      "expanded_url" : "http:\/\/youtu.be\/W7C83dg139A?a",
      "display_url" : "youtu.be\/W7C83dg139A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302132584782110720",
  "text" : "RT @jimscriv: RT @IHWorld: Adrian Underhill's practical examples of Demand High at IH DOS Conference 2013 http:\/\/t.co\/0uonCGDl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "International House",
        "screen_name" : "IHWorld",
        "indices" : [ 3, 11 ],
        "id_str" : "28518542",
        "id" : 28518542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/0uonCGDl",
        "expanded_url" : "http:\/\/youtu.be\/W7C83dg139A?a",
        "display_url" : "youtu.be\/W7C83dg139A?a"
      } ]
    },
    "geo" : { },
    "id_str" : "302124102414659584",
    "text" : "RT @IHWorld: Adrian Underhill's practical examples of Demand High at IH DOS Conference 2013 http:\/\/t.co\/0uonCGDl",
    "id" : 302124102414659584,
    "created_at" : "2013-02-14 18:36:13 +0000",
    "user" : {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "protected" : false,
      "id_str" : "130149739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000570779904\/352eef327f532ec9d3cefd637a55f90a_normal.jpeg",
      "id" : 130149739,
      "verified" : false
    }
  },
  "id" : 302132584782110720,
  "created_at" : "2013-02-14 19:09:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302102822852362241",
  "geo" : { },
  "id_str" : "302129094198427648",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard hi again, short reply to your comment.",
  "id" : 302129094198427648,
  "in_reply_to_status_id" : 302102822852362241,
  "created_at" : "2013-02-14 18:56:04 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/81635JuN",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-m",
      "display_url" : "wp.me\/p2e2Wf-m"
    } ]
  },
  "geo" : { },
  "id_str" : "302120737316171778",
  "text" : "RT @teflerinha: 1st post for 1st blogoversary this week: Simple ways to differentiate materials for mixed level classes http:\/\/t.co\/8163 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/81635JuN",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-m",
        "display_url" : "wp.me\/p2e2Wf-m"
      } ]
    },
    "geo" : { },
    "id_str" : "302101902861160450",
    "text" : "1st post for 1st blogoversary this week: Simple ways to differentiate materials for mixed level classes http:\/\/t.co\/81635JuN #eltchat",
    "id" : 302101902861160450,
    "created_at" : "2013-02-14 17:08:01 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 302120737316171778,
  "created_at" : "2013-02-14 18:22:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302101902861160450",
  "geo" : { },
  "id_str" : "302120665358684160",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha happy birthpostday!",
  "id" : 302120665358684160,
  "in_reply_to_status_id" : 302101902861160450,
  "created_at" : "2013-02-14 18:22:34 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 0, 13 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302115394347466752",
  "in_reply_to_user_id" : 146913655,
  "text" : "@iatefl_besig appreciate the RT veru much :)",
  "id" : 302115394347466752,
  "created_at" : "2013-02-14 18:01:37 +0000",
  "in_reply_to_screen_name" : "iatefl_besig",
  "in_reply_to_user_id_str" : "146913655",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302102822852362241",
  "geo" : { },
  "id_str" : "302114405527736320",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard many thanks Rose :)",
  "id" : 302114405527736320,
  "in_reply_to_status_id" : 302102822852362241,
  "created_at" : "2013-02-14 17:57:41 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ukoer",
      "indices" : [ 126, 132 ]
    }, {
      "text" : "oer13",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tesol",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Ay8BDbFc",
      "expanded_url" : "http:\/\/bit.ly\/15fvyVc",
      "display_url" : "bit.ly\/15fvyVc"
    } ]
  },
  "geo" : { },
  "id_str" : "302114072084750336",
  "text" : "RT @AlannahFitz: Love is a stranger in an open car ...to tempt you in and drive you far away: toward OEP http:\/\/t.co\/Ay8BDbFc #ukoer #oe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ukoer",
        "indices" : [ 109, 115 ]
      }, {
        "text" : "oer13",
        "indices" : [ 116, 122 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 123, 131 ]
      }, {
        "text" : "tesol",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/Ay8BDbFc",
        "expanded_url" : "http:\/\/bit.ly\/15fvyVc",
        "display_url" : "bit.ly\/15fvyVc"
      } ]
    },
    "geo" : { },
    "id_str" : "302098007556513792",
    "text" : "Love is a stranger in an open car ...to tempt you in and drive you far away: toward OEP http:\/\/t.co\/Ay8BDbFc #ukoer #oer13 #eapchat #tesol",
    "id" : 302098007556513792,
    "created_at" : "2013-02-14 16:52:32 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 302114072084750336,
  "created_at" : "2013-02-14 17:56:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    }, {
      "text" : "besig",
      "indices" : [ 135, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/UIznmJig",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-lc",
      "display_url" : "wp.me\/pgHyE-lc"
    } ]
  },
  "geo" : { },
  "id_str" : "302100308727836674",
  "text" : "4 out of 5 English speakers are 'non-native'&gt; alternative start to Isn't just knowing English enough? http:\/\/t.co\/UIznmJig #eltchat #besig",
  "id" : 302100308727836674,
  "created_at" : "2013-02-14 17:01:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302081934635450368",
  "geo" : { },
  "id_str" : "302082410651201538",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin damn working at the beach you are full on!",
  "id" : 302082410651201538,
  "in_reply_to_status_id" : 302081934635450368,
  "created_at" : "2013-02-14 15:50:33 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302081525845995520",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin cheers for RT of latest post, heard u were\/are on holiday? hope u had\/having fun :)",
  "id" : 302081525845995520,
  "created_at" : "2013-02-14 15:47:02 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/rx5ys7f9",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/elt-research-open-access-repositories-and-directories\/",
      "display_url" : "eflnotes.wordpress.com\/elt-research-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302080701308743681",
  "text" : "@harrisonmike maybe u could use some of these tools if u haven't already? http:\/\/t.co\/rx5ys7f9",
  "id" : 302080701308743681,
  "created_at" : "2013-02-14 15:43:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 9, 22 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302068676444712960",
  "geo" : { },
  "id_str" : "302075864605147136",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey @rosemerebard two great posts on identity in language learning for sure",
  "id" : 302075864605147136,
  "in_reply_to_status_id" : 302068676444712960,
  "created_at" : "2013-02-14 15:24:33 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave CrLo",
      "screen_name" : "DaveCr",
      "indices" : [ 89, 96 ],
      "id_str" : "2675303778",
      "id" : 2675303778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "besig",
      "indices" : [ 125, 131 ]
    }, {
      "text" : "tesol",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/UIznmJig",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-lc",
      "display_url" : "wp.me\/pgHyE-lc"
    } ]
  },
  "geo" : { },
  "id_str" : "302075204476223489",
  "text" : "new blog post http:\/\/t.co\/UIznmJig Isn't just knowing English enough? inspired by recent @davecr David Crystal talk #eltchat #besig #tesol",
  "id" : 302075204476223489,
  "created_at" : "2013-02-14 15:21:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Assange",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/TKQjB3n1",
      "expanded_url" : "http:\/\/tinyurl.com\/c6afsf5",
      "display_url" : "tinyurl.com\/c6afsf5"
    } ]
  },
  "geo" : { },
  "id_str" : "302007091068026880",
  "text" : "RT @medialens: John Pilger: 'WikiLeaks is a rare truth-teller. Smearing Julian #Assange is shameful' http:\/\/t.co\/TKQjB3n1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Assange",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/TKQjB3n1",
        "expanded_url" : "http:\/\/tinyurl.com\/c6afsf5",
        "display_url" : "tinyurl.com\/c6afsf5"
      } ]
    },
    "geo" : { },
    "id_str" : "301980096963702784",
    "text" : "John Pilger: 'WikiLeaks is a rare truth-teller. Smearing Julian #Assange is shameful' http:\/\/t.co\/TKQjB3n1",
    "id" : 301980096963702784,
    "created_at" : "2013-02-14 09:04:00 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 302007091068026880,
  "created_at" : "2013-02-14 10:51:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emphasis Training",
      "screen_name" : "EmphasisWriting",
      "indices" : [ 0, 16 ],
      "id_str" : "104867383",
      "id" : 104867383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EmphasisTest",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302002590122647552",
  "in_reply_to_user_id" : 104867383,
  "text" : "@EmphasisWriting adage \"Less is more\" = good both for reader &amp; writer #EmphasisTest",
  "id" : 302002590122647552,
  "created_at" : "2013-02-14 10:33:23 +0000",
  "in_reply_to_screen_name" : "EmphasisWriting",
  "in_reply_to_user_id_str" : "104867383",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExplorationsofStyle",
      "screen_name" : "explorstyle",
      "indices" : [ 3, 15 ],
      "id_str" : "356850668",
      "id" : 356850668
    }, {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 22, 32 ],
      "id_str" : "34347535",
      "id" : 34347535
    }, {
      "name" : "Emphasis Training",
      "screen_name" : "EmphasisWriting",
      "indices" : [ 44, 60 ],
      "id_str" : "104867383",
      "id" : 104867383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/EnKz5LuR",
      "expanded_url" : "http:\/\/ow.ly\/hHreB",
      "display_url" : "ow.ly\/hHreB"
    } ]
  },
  "geo" : { },
  "id_str" : "302001010786856960",
  "text" : "RT @explorstyle: From @StanCarey,writing in @EmphasisWriting blog, on making 140 characters go further: http:\/\/t.co\/EnKz5LuR Try the fun ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stan Carey",
        "screen_name" : "StanCarey",
        "indices" : [ 5, 15 ],
        "id_str" : "34347535",
        "id" : 34347535
      }, {
        "name" : "Emphasis Training",
        "screen_name" : "EmphasisWriting",
        "indices" : [ 27, 43 ],
        "id_str" : "104867383",
        "id" : 104867383
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/EnKz5LuR",
        "expanded_url" : "http:\/\/ow.ly\/hHreB",
        "display_url" : "ow.ly\/hHreB"
      } ]
    },
    "geo" : { },
    "id_str" : "301889619824349184",
    "text" : "From @StanCarey,writing in @EmphasisWriting blog, on making 140 characters go further: http:\/\/t.co\/EnKz5LuR Try the fun Twitter challenge!",
    "id" : 301889619824349184,
    "created_at" : "2013-02-14 03:04:28 +0000",
    "user" : {
      "name" : "ExplorationsofStyle",
      "screen_name" : "explorstyle",
      "protected" : false,
      "id_str" : "356850668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539534943508893696\/areF8fnm_normal.jpeg",
      "id" : 356850668,
      "verified" : false
    }
  },
  "id" : 302001010786856960,
  "created_at" : "2013-02-14 10:27:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "englishfortheweb",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/KpYUBGnb",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-kP",
      "display_url" : "wp.me\/pgHyE-kP"
    } ]
  },
  "geo" : { },
  "id_str" : "301820275106934784",
  "text" : "new blog post The Pirate Bay AFK - web related lexis\nhttp:\/\/t.co\/KpYUBGnb #englishfortheweb",
  "id" : 301820275106934784,
  "created_at" : "2013-02-13 22:28:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 3, 14 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 45, 61 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KELTChat",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "ELTChat",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "esol",
      "indices" : [ 103, 108 ]
    }, {
      "text" : "esl",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "efl",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/eZR4d3aJ",
      "expanded_url" : "http:\/\/fb.me\/Ypf0Ll3Q",
      "display_url" : "fb.me\/Ypf0Ll3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "301768670806425601",
  "text" : "RT @vickyloras: New post by Michael Griffin (@michaelegriffin) A Bad Reading Lesson #KELTChat #ELTChat #esol #esl #efl http:\/\/t.co\/eZR4d3aJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 29, 45 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KELTChat",
        "indices" : [ 68, 77 ]
      }, {
        "text" : "ELTChat",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "esol",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "esl",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "efl",
        "indices" : [ 98, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/eZR4d3aJ",
        "expanded_url" : "http:\/\/fb.me\/Ypf0Ll3Q",
        "display_url" : "fb.me\/Ypf0Ll3Q"
      } ]
    },
    "geo" : { },
    "id_str" : "301761678310248450",
    "text" : "New post by Michael Griffin (@michaelegriffin) A Bad Reading Lesson #KELTChat #ELTChat #esol #esl #efl http:\/\/t.co\/eZR4d3aJ",
    "id" : 301761678310248450,
    "created_at" : "2013-02-13 18:36:05 +0000",
    "user" : {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "protected" : false,
      "id_str" : "95957241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649856172317519872\/zNL8t04-_normal.jpg",
      "id" : 95957241,
      "verified" : false
    }
  },
  "id" : 301768670806425601,
  "created_at" : "2013-02-13 19:03:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 3, 16 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "besig",
      "indices" : [ 79, 85 ]
    }, {
      "text" : "businessEnglish",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ymyFbMRo",
      "expanded_url" : "http:\/\/bit.ly\/12zb4a2",
      "display_url" : "bit.ly\/12zb4a2"
    } ]
  },
  "geo" : { },
  "id_str" : "301669188873900032",
  "text" : "RT @iatefl_besig: Who will be the 1st to submit a proposal for the 1st #iatefl #besig online conference (from 15 Feb)? http:\/\/t.co\/ymyFb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 53, 60 ]
      }, {
        "text" : "besig",
        "indices" : [ 61, 67 ]
      }, {
        "text" : "businessEnglish",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/ymyFbMRo",
        "expanded_url" : "http:\/\/bit.ly\/12zb4a2",
        "display_url" : "bit.ly\/12zb4a2"
      } ]
    },
    "geo" : { },
    "id_str" : "301654426584760320",
    "text" : "Who will be the 1st to submit a proposal for the 1st #iatefl #besig online conference (from 15 Feb)? http:\/\/t.co\/ymyFbMRo #businessEnglish",
    "id" : 301654426584760320,
    "created_at" : "2013-02-13 11:29:54 +0000",
    "user" : {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "protected" : false,
      "id_str" : "146913655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921734243\/BesigLogoSmall_normal.jpg",
      "id" : 146913655,
      "verified" : false
    }
  },
  "id" : 301669188873900032,
  "created_at" : "2013-02-13 12:28:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 13, 23 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/zPpIg4Yu",
      "expanded_url" : "http:\/\/fourc.ca\/learning\/",
      "display_url" : "fourc.ca\/learning\/"
    } ]
  },
  "geo" : { },
  "id_str" : "301643260592541696",
  "text" : "RT @seburnt: @willycard Where and how our learning occurs http:\/\/t.co\/zPpIg4Yu &gt; it morphed from my original plan, but you're in it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Willy C. Cardoso",
        "screen_name" : "willycard",
        "indices" : [ 0, 10 ],
        "id_str" : "102353142",
        "id" : 102353142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/zPpIg4Yu",
        "expanded_url" : "http:\/\/fourc.ca\/learning\/",
        "display_url" : "fourc.ca\/learning\/"
      } ]
    },
    "geo" : { },
    "id_str" : "301562084322316288",
    "in_reply_to_user_id" : 102353142,
    "text" : "@willycard Where and how our learning occurs http:\/\/t.co\/zPpIg4Yu &gt; it morphed from my original plan, but you're in it.",
    "id" : 301562084322316288,
    "created_at" : "2013-02-13 05:22:58 +0000",
    "in_reply_to_screen_name" : "willycard",
    "in_reply_to_user_id_str" : "102353142",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 301643260592541696,
  "created_at" : "2013-02-13 10:45:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arizio Sweeting",
      "screen_name" : "ariziosweeting",
      "indices" : [ 3, 18 ],
      "id_str" : "75252733",
      "id" : 75252733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/8KxPw6Kn",
      "expanded_url" : "http:\/\/wp.me\/p2uffD-b9",
      "display_url" : "wp.me\/p2uffD-b9"
    }, {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/O4ID3v46",
      "expanded_url" : "http:\/\/wp.me\/s2uffD-691",
      "display_url" : "wp.me\/s2uffD-691"
    } ]
  },
  "geo" : { },
  "id_str" : "301641662373961728",
  "text" : "RT @ariziosweeting: A Winner at the Grammy. A Winner in the Classroom http:\/\/t.co\/8KxPw6Kn http:\/\/t.co\/O4ID3v46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/8KxPw6Kn",
        "expanded_url" : "http:\/\/wp.me\/p2uffD-b9",
        "display_url" : "wp.me\/p2uffD-b9"
      }, {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/O4ID3v46",
        "expanded_url" : "http:\/\/wp.me\/s2uffD-691",
        "display_url" : "wp.me\/s2uffD-691"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ -27.470933, 153.023502 ]
    },
    "id_str" : "301638741561339904",
    "text" : "A Winner at the Grammy. A Winner in the Classroom http:\/\/t.co\/8KxPw6Kn http:\/\/t.co\/O4ID3v46",
    "id" : 301638741561339904,
    "created_at" : "2013-02-13 10:27:34 +0000",
    "user" : {
      "name" : "Arizio Sweeting",
      "screen_name" : "ariziosweeting",
      "protected" : false,
      "id_str" : "75252733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517755471495581697\/cxdh7P7b_normal.jpeg",
      "id" : 75252733,
      "verified" : false
    }
  },
  "id" : 301641662373961728,
  "created_at" : "2013-02-13 10:39:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 3, 19 ],
      "id_str" : "21313816",
      "id" : 21313816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeachingEnglish",
      "indices" : [ 37, 53 ]
    }, {
      "text" : "BritishCouncil",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/dNWQRhCt",
      "expanded_url" : "http:\/\/on.fb.me\/15buyS0",
      "display_url" : "on.fb.me\/15buyS0"
    } ]
  },
  "geo" : { },
  "id_str" : "301624590554263552",
  "text" : "RT @TeachingEnglish: Shortlisted for #TeachingEnglish blog award: Chris Wilson \u2013 Using Wikis for process writings\rhttp:\/\/t.co\/dNWQRhCt # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeachingEnglish",
        "indices" : [ 16, 32 ]
      }, {
        "text" : "BritishCouncil",
        "indices" : [ 114, 129 ]
      }, {
        "text" : "elt",
        "indices" : [ 130, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/dNWQRhCt",
        "expanded_url" : "http:\/\/on.fb.me\/15buyS0",
        "display_url" : "on.fb.me\/15buyS0"
      } ]
    },
    "geo" : { },
    "id_str" : "301623926944051200",
    "text" : "Shortlisted for #TeachingEnglish blog award: Chris Wilson \u2013 Using Wikis for process writings\rhttp:\/\/t.co\/dNWQRhCt #BritishCouncil #elt",
    "id" : 301623926944051200,
    "created_at" : "2013-02-13 09:28:42 +0000",
    "user" : {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "protected" : false,
      "id_str" : "21313816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000613895430\/23c1ea78d94a01a30920c37db21785b3_normal.png",
      "id" : 21313816,
      "verified" : false
    }
  },
  "id" : 301624590554263552,
  "created_at" : "2013-02-13 09:31:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lEPnUaFR",
      "expanded_url" : "http:\/\/ow.ly\/hCZc9",
      "display_url" : "ow.ly\/hCZc9"
    } ]
  },
  "geo" : { },
  "id_str" : "301464171776729088",
  "text" : "RT @BoingBoing: Some extremely cool dude(s) at an ISP engineered a traceroute to produce the introductory crawl from Star Wars. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/lEPnUaFR",
        "expanded_url" : "http:\/\/ow.ly\/hCZc9",
        "display_url" : "ow.ly\/hCZc9"
      } ]
    },
    "geo" : { },
    "id_str" : "301459511439417344",
    "text" : "Some extremely cool dude(s) at an ISP engineered a traceroute to produce the introductory crawl from Star Wars. http:\/\/t.co\/lEPnUaFR",
    "id" : 301459511439417344,
    "created_at" : "2013-02-12 22:35:23 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 301464171776729088,
  "created_at" : "2013-02-12 22:53:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301455098612183040",
  "geo" : { },
  "id_str" : "301455509658144768",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate yeah but how big were those pancakes? delia can never be wrng shurely?",
  "id" : 301455509658144768,
  "in_reply_to_status_id" : 301455098612183040,
  "created_at" : "2013-02-12 22:19:28 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301454966692929538",
  "geo" : { },
  "id_str" : "301455120800030720",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac yum!",
  "id" : 301455120800030720,
  "in_reply_to_status_id" : 301454966692929538,
  "created_at" : "2013-02-12 22:17:56 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301453903575277568",
  "geo" : { },
  "id_str" : "301454685783597057",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac more pancakes! less tim :)",
  "id" : 301454685783597057,
  "in_reply_to_status_id" : 301453903575277568,
  "created_at" : "2013-02-12 22:16:12 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301442887407783936",
  "geo" : { },
  "id_str" : "301443165037158400",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson hehe :)",
  "id" : 301443165037158400,
  "in_reply_to_status_id" : 301442887407783936,
  "created_at" : "2013-02-12 21:30:25 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 0, 13 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301441669910364160",
  "geo" : { },
  "id_str" : "301442718473809921",
  "in_reply_to_user_id" : 624508480,
  "text" : "@ShetlandESOL a pleasure, the film site is great :)",
  "id" : 301442718473809921,
  "in_reply_to_status_id" : 301441669910364160,
  "created_at" : "2013-02-12 21:28:39 +0000",
  "in_reply_to_screen_name" : "ShetlandESOL",
  "in_reply_to_user_id_str" : "624508480",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 0, 11 ],
      "id_str" : "15557246",
      "id" : 15557246
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 22, 32 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/IjM83P2p",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/alerts-2013\/715-eyes-like-blank-discs-the-guardian-s-steven-poole-on-george-orwell-s-politics-and-the-english-language.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301347960149651457",
  "geo" : { },
  "id_str" : "301432048596430848",
  "in_reply_to_user_id" : 15557246,
  "text" : "@leninology hmm found @medialens reading more persuasive http:\/\/t.co\/IjM83P2p also neither of the 2 articles linkto essay which is curious",
  "id" : 301432048596430848,
  "in_reply_to_status_id" : 301347960149651457,
  "created_at" : "2013-02-12 20:46:15 +0000",
  "in_reply_to_screen_name" : "leninology",
  "in_reply_to_user_id_str" : "15557246",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 23, 34 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    }, {
      "text" : "edchat",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/rPl1Vnp7",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2013\/personalising-education-in-greece-george-drivas\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2013\/personali\u2026"
    }, {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/DFLuBJG2",
      "expanded_url" : "http:\/\/digitalcounterrevolution.co.uk\/2013\/ken-robinson-caricature-teacher-education-paradigms-or-changing-caricatures\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2013\/ken-robin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301425732347895808",
  "text" : "bambam new rounds from @tornhalves http:\/\/t.co\/rPl1Vnp7 \u2026 \u2026http:\/\/t.co\/DFLuBJG2 \u2026 \u2026 #eltchat #edchat",
  "id" : 301425732347895808,
  "created_at" : "2013-02-12 20:21:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Globalenglishlive",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301408825137827840",
  "text" : "are cultural diffs really minimal in non-everyday life? #Globalenglishlive",
  "id" : 301408825137827840,
  "created_at" : "2013-02-12 19:13:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/syYsQ2s0",
      "expanded_url" : "http:\/\/elt2.co.uk\/X1NBL2",
      "display_url" : "elt2.co.uk\/X1NBL2"
    } ]
  },
  "geo" : { },
  "id_str" : "301396379983568896",
  "text" : "RT @MrChrisJWilson: help needed from proof readers. I've just finished my Blogging for ELT ebook. go to the site and sign up if you want ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/syYsQ2s0",
        "expanded_url" : "http:\/\/elt2.co.uk\/X1NBL2",
        "display_url" : "elt2.co.uk\/X1NBL2"
      } ]
    },
    "geo" : { },
    "id_str" : "301392817366921217",
    "text" : "help needed from proof readers. I've just finished my Blogging for ELT ebook. go to the site and sign up if you want http:\/\/t.co\/syYsQ2s0",
    "id" : 301392817366921217,
    "created_at" : "2013-02-12 18:10:21 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 301396379983568896,
  "created_at" : "2013-02-12 18:24:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eduardo Santos",
      "screen_name" : "eltbakery",
      "indices" : [ 0, 10 ],
      "id_str" : "99758036",
      "id" : 99758036
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 11, 22 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/9BURGojV",
      "expanded_url" : "http:\/\/globalenglishlive.modstreaming.com",
      "display_url" : "globalenglishlive.modstreaming.com"
    } ]
  },
  "in_reply_to_status_id_str" : "301390937416953856",
  "geo" : { },
  "id_str" : "301391389848137728",
  "in_reply_to_user_id" : 99758036,
  "text" : "@eltbakery @BCseminars ah looks like a delay in transmission re David Crystal seminar 1815 start time http:\/\/t.co\/9BURGojV",
  "id" : 301391389848137728,
  "in_reply_to_status_id" : 301390937416953856,
  "created_at" : "2013-02-12 18:04:41 +0000",
  "in_reply_to_screen_name" : "eltbakery",
  "in_reply_to_user_id_str" : "99758036",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 62, 73 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301390267242668033",
  "text" : "can anyone log into BC David Crystal live stream seminar yet? @BCseminars",
  "id" : 301390267242668033,
  "created_at" : "2013-02-12 18:00:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Acu\u00F1a",
      "screen_name" : "jonacuso",
      "indices" : [ 0, 9 ],
      "id_str" : "234014699",
      "id" : 234014699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/rx5ys7f9",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/elt-research-open-access-repositories-and-directories\/",
      "display_url" : "eflnotes.wordpress.com\/elt-research-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301377919861813249",
  "in_reply_to_user_id" : 234014699,
  "text" : "@jonacuso hi there thx for RT of open repo page http:\/\/t.co\/rx5ys7f9, do u know of some?",
  "id" : 301377919861813249,
  "created_at" : "2013-02-12 17:11:10 +0000",
  "in_reply_to_screen_name" : "jonacuso",
  "in_reply_to_user_id_str" : "234014699",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301182820515213312",
  "geo" : { },
  "id_str" : "301265036985376769",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt cheers for share Tyson! how's weather in Toronto? hope not too bad!",
  "id" : 301265036985376769,
  "in_reply_to_status_id" : 301182820515213312,
  "created_at" : "2013-02-12 09:42:36 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301093837466632192",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson ta for RT of repo page, u come across any good ones?",
  "id" : 301093837466632192,
  "created_at" : "2013-02-11 22:22:19 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/rx5ys7f9",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/elt-research-open-access-repositories-and-directories\/",
      "display_url" : "eflnotes.wordpress.com\/elt-research-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301091958024204288",
  "text" : "added a new blog page listing mainly open access repos http:\/\/t.co\/rx5ys7f9 \u2026 please add if u can #eltchat",
  "id" : 301091958024204288,
  "created_at" : "2013-02-11 22:14:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/EH6xWI6H",
      "expanded_url" : "http:\/\/www.jstor.org\/action\/doBasicResults?hp=25&la=&wc=on&fc=off&acc=off&acc=off&bk=off&pm=off&jo=off&ar=off&re=off&ms=off&gw=jtx&Query=AAVE&sbq=AAVE&prq=%28%28AAVE%29+AND+%28standard+english%29%29&mxpg=27&aori=off&vf=jo",
      "display_url" : "jstor.org\/action\/doBasic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "300900568099078145",
  "geo" : { },
  "id_str" : "301085692493197313",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 might be something here? http:\/\/t.co\/EH6xWI6H",
  "id" : 301085692493197313,
  "in_reply_to_status_id" : 300900568099078145,
  "created_at" : "2013-02-11 21:49:57 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 3, 16 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esol",
      "indices" : [ 123, 128 ]
    }, {
      "text" : "ukesolchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/FEwa80EJ",
      "expanded_url" : "http:\/\/bit.ly\/11uvf9X",
      "display_url" : "bit.ly\/11uvf9X"
    } ]
  },
  "geo" : { },
  "id_str" : "301058069763325952",
  "text" : "RT @ShetlandESOL: The 2013 ESOL Film Festival website is up and running! http:\/\/t.co\/FEwa80EJ\nPlease pop by for a visit :) #esol #ukesol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esol",
        "indices" : [ 105, 110 ]
      }, {
        "text" : "ukesolchat",
        "indices" : [ 111, 122 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 123, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/FEwa80EJ",
        "expanded_url" : "http:\/\/bit.ly\/11uvf9X",
        "display_url" : "bit.ly\/11uvf9X"
      } ]
    },
    "geo" : { },
    "id_str" : "299884053673418752",
    "text" : "The 2013 ESOL Film Festival website is up and running! http:\/\/t.co\/FEwa80EJ\nPlease pop by for a visit :) #esol #ukesolchat #eltchat",
    "id" : 299884053673418752,
    "created_at" : "2013-02-08 14:15:04 +0000",
    "user" : {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "protected" : false,
      "id_str" : "624508480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701748823496990720\/Lv4r7Bie_normal.jpg",
      "id" : 624508480,
      "verified" : false
    }
  },
  "id" : 301058069763325952,
  "created_at" : "2013-02-11 20:00:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301048850070794240",
  "geo" : { },
  "id_str" : "301049413822971904",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir hehe maybe i'll add that - warning this post could cause u to miss your travel stop :)",
  "id" : 301049413822971904,
  "in_reply_to_status_id" : 301048850070794240,
  "created_at" : "2013-02-11 19:25:48 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 17, 30 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learning",
      "indices" : [ 66, 75 ]
    }, {
      "text" : "gaming",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/AtaNLs6y",
      "expanded_url" : "http:\/\/bit.ly\/Yloeko",
      "display_url" : "bit.ly\/Yloeko"
    } ]
  },
  "geo" : { },
  "id_str" : "301048457421021186",
  "text" : "int study &gt;RT @DTWillingham Willingham blog: Meta-anlalysis on #learning from #gaming http:\/\/t.co\/AtaNLs6y  #eapchat",
  "id" : 301048457421021186,
  "created_at" : "2013-02-11 19:22:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301044843793235969",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir thx for RT Steve, hope u r well :)",
  "id" : 301044843793235969,
  "created_at" : "2013-02-11 19:07:38 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Thirlway",
      "screen_name" : "Jess_Thirlway",
      "indices" : [ 0, 14 ],
      "id_str" : "151182674",
      "id" : 151182674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298859206382075905",
  "geo" : { },
  "id_str" : "301042364326219779",
  "in_reply_to_user_id" : 151182674,
  "text" : "@Jess_Thirlway hehe :)",
  "id" : 301042364326219779,
  "in_reply_to_status_id" : 298859206382075905,
  "created_at" : "2013-02-11 18:57:47 +0000",
  "in_reply_to_screen_name" : "Jess_Thirlway",
  "in_reply_to_user_id_str" : "151182674",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ncTy9aqE",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-bU",
      "display_url" : "wp.me\/p2e2Wf-bU"
    } ]
  },
  "geo" : { },
  "id_str" : "301039089887625216",
  "text" : "RT @teflerinha: New lesson for Valentine's Day, featuring an authentic listening\/animation and a great love story #eltchat  http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/ncTy9aqE",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-bU",
        "display_url" : "wp.me\/p2e2Wf-bU"
      } ]
    },
    "geo" : { },
    "id_str" : "301036049935781888",
    "text" : "New lesson for Valentine's Day, featuring an authentic listening\/animation and a great love story #eltchat  http:\/\/t.co\/ncTy9aqE",
    "id" : 301036049935781888,
    "created_at" : "2013-02-11 18:32:41 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 301039089887625216,
  "created_at" : "2013-02-11 18:44:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301036049935781888",
  "geo" : { },
  "id_str" : "301039065430638593",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha i likey the nice focus on 'like'  :)",
  "id" : 301039065430638593,
  "in_reply_to_status_id" : 301036049935781888,
  "created_at" : "2013-02-11 18:44:40 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 19, 35 ],
      "id_str" : "21313816",
      "id" : 21313816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeachingEnglish",
      "indices" : [ 53, 69 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wQwESil3",
      "expanded_url" : "http:\/\/bit.ly\/156rOW1",
      "display_url" : "bit.ly\/156rOW1"
    } ]
  },
  "geo" : { },
  "id_str" : "301034308292980736",
  "text" : "RT @leoselivan: RT @TeachingEnglish: Shortlisted for #TeachingEnglish blog award: Leo Selivan \u2013 Start teaching lexically http:\/\/t.co\/wQw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TeachingEnglish",
        "screen_name" : "TeachingEnglish",
        "indices" : [ 3, 19 ],
        "id_str" : "21313816",
        "id" : 21313816
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeachingEnglish",
        "indices" : [ 37, 53 ]
      }, {
        "text" : "elt",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/wQwESil3",
        "expanded_url" : "http:\/\/bit.ly\/156rOW1",
        "display_url" : "bit.ly\/156rOW1"
      } ]
    },
    "geo" : { },
    "id_str" : "301027372604456960",
    "text" : "RT @TeachingEnglish: Shortlisted for #TeachingEnglish blog award: Leo Selivan \u2013 Start teaching lexically http:\/\/t.co\/wQwESil3 #elt",
    "id" : 301027372604456960,
    "created_at" : "2013-02-11 17:58:13 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 301034308292980736,
  "created_at" : "2013-02-11 18:25:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301034184405811200",
  "text" : "thanks for follow Ava :)",
  "id" : 301034184405811200,
  "created_at" : "2013-02-11 18:25:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 35, 46 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/P1QtwJvD",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/02\/03\/this-corpora-bashing-parrot-has-ceased-to-be\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/02\/03\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301033984840830976",
  "text" : "short replies to @CELTtraining and @hughdellar comments on corpora post http:\/\/t.co\/P1QtwJvD",
  "id" : 301033984840830976,
  "created_at" : "2013-02-11 18:24:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301027372604456960",
  "geo" : { },
  "id_str" : "301033424406323200",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan well done Leo, shame not on FB to vote for you!",
  "id" : 301033424406323200,
  "in_reply_to_status_id" : 301027372604456960,
  "created_at" : "2013-02-11 18:22:15 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298493725246627841",
  "geo" : { },
  "id_str" : "301033194810122241",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson thanks for share Chris!",
  "id" : 301033194810122241,
  "in_reply_to_status_id" : 298493725246627841,
  "created_at" : "2013-02-11 18:21:21 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298486407591231489",
  "geo" : { },
  "id_str" : "301033064316940288",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons cheers George, that means a lot! hope you are good.",
  "id" : 301033064316940288,
  "in_reply_to_status_id" : 298486407591231489,
  "created_at" : "2013-02-11 18:20:50 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298459844464214018",
  "geo" : { },
  "id_str" : "298461376756723712",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin :)",
  "id" : 298461376756723712,
  "in_reply_to_status_id" : 298459844464214018,
  "created_at" : "2013-02-04 16:01:52 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 16, 32 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/WLXT43a3",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/abs\/10.1080\/13636820200200196",
      "display_url" : "tandfonline.com\/doi\/abs\/10.108\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "298453520791777280",
  "geo" : { },
  "id_str" : "298459311384977408",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @michaelegriffin how about this? http:\/\/t.co\/WLXT43a3 free download as well :)",
  "id" : 298459311384977408,
  "in_reply_to_status_id" : 298453520791777280,
  "created_at" : "2013-02-04 15:53:39 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/bBV2gnPH",
      "expanded_url" : "http:\/\/www.yazikopen.org.uk\/yazikopen\/search\/node\/reflective%20type%3Abiblio",
      "display_url" : "yazikopen.org.uk\/yazikopen\/sear\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "298447255302725633",
  "geo" : { },
  "id_str" : "298455502600417280",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson maybe something here? http:\/\/t.co\/bBV2gnPH",
  "id" : 298455502600417280,
  "in_reply_to_status_id" : 298447255302725633,
  "created_at" : "2013-02-04 15:38:31 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ceri Jones",
      "screen_name" : "cerirhiannon",
      "indices" : [ 0, 13 ],
      "id_str" : "125619029",
      "id" : 125619029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/WXk7o80N",
      "expanded_url" : "http:\/\/synergy-foss.org\/",
      "display_url" : "synergy-foss.org"
    } ]
  },
  "in_reply_to_status_id_str" : "298347991750815744",
  "geo" : { },
  "id_str" : "298451672408154113",
  "in_reply_to_user_id" : 125619029,
  "text" : "@cerirhiannon you could try something like this http:\/\/t.co\/WXk7o80N",
  "id" : 298451672408154113,
  "in_reply_to_status_id" : 298347991750815744,
  "created_at" : "2013-02-04 15:23:18 +0000",
  "in_reply_to_screen_name" : "cerirhiannon",
  "in_reply_to_user_id_str" : "125619029",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298445479639932928",
  "geo" : { },
  "id_str" : "298446065470947329",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha many thx rachael !",
  "id" : 298446065470947329,
  "in_reply_to_status_id" : 298445479639932928,
  "created_at" : "2013-02-04 15:01:01 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whynot",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/OEdyLZO0",
      "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/02\/04\/why-make-a-good-class-better\/",
      "display_url" : "lizzieserene.wordpress.com\/2013\/02\/04\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298445768874926081",
  "text" : "RT @AnneHendler: Why make a good class better? http:\/\/t.co\/OEdyLZO0 #whynot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whynot",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/OEdyLZO0",
        "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/02\/04\/why-make-a-good-class-better\/",
        "display_url" : "lizzieserene.wordpress.com\/2013\/02\/04\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298433061085917184",
    "text" : "Why make a good class better? http:\/\/t.co\/OEdyLZO0 #whynot",
    "id" : 298433061085917184,
    "created_at" : "2013-02-04 14:09:21 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 298445768874926081,
  "created_at" : "2013-02-04 14:59:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298401955003379712",
  "geo" : { },
  "id_str" : "298443661199409154",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin many thanks for RT and compliment mike :)",
  "id" : 298443661199409154,
  "in_reply_to_status_id" : 298401955003379712,
  "created_at" : "2013-02-04 14:51:28 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "efl",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "tesol",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "tefl",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "elt",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/3mpl2A8S",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-hr",
      "display_url" : "wp.me\/pgHyE-hr"
    } ]
  },
  "geo" : { },
  "id_str" : "298393263654715392",
  "text" : "new blog post This corpora-bashing parrot has ceased to be http:\/\/t.co\/3mpl2A8S  #eltchat #efl #tesol #tefl #elt",
  "id" : 298393263654715392,
  "created_at" : "2013-02-04 11:31:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 84, 90 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/223U8kRa",
      "expanded_url" : "http:\/\/teflresearch.com\/2013\/02\/03\/angry-words\/",
      "display_url" : "teflresearch.com\/2013\/02\/03\/ang\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298239698306990081",
  "text" : "missing some skeptical words?&gt;Angry words  http:\/\/t.co\/223U8kRa via @Karris72 cc @EBEFL",
  "id" : 298239698306990081,
  "created_at" : "2013-02-04 01:20:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    }, {
      "name" : "Mark Liddell",
      "screen_name" : "markliddell",
      "indices" : [ 15, 27 ],
      "id_str" : "19372896",
      "id" : 19372896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edreform",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/c3lCmFIx",
      "expanded_url" : "http:\/\/bit.ly\/WNNdQ3",
      "display_url" : "bit.ly\/WNNdQ3"
    } ]
  },
  "geo" : { },
  "id_str" : "298166835692580865",
  "text" : "RT @mcleod: MT @markliddell \"No one teaches to the test better than I do\" Teacher sues parents over kids' bad test scores http:\/\/t.co\/c3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Liddell",
        "screen_name" : "markliddell",
        "indices" : [ 3, 15 ],
        "id_str" : "19372896",
        "id" : 19372896
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edreform",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/c3lCmFIx",
        "expanded_url" : "http:\/\/bit.ly\/WNNdQ3",
        "display_url" : "bit.ly\/WNNdQ3"
      } ]
    },
    "geo" : { },
    "id_str" : "298159229150302209",
    "text" : "MT @markliddell \"No one teaches to the test better than I do\" Teacher sues parents over kids' bad test scores http:\/\/t.co\/c3lCmFIx #edreform",
    "id" : 298159229150302209,
    "created_at" : "2013-02-03 20:01:14 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 298166835692580865,
  "created_at" : "2013-02-03 20:31:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 3, 19 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/v8p7HJ45",
      "expanded_url" : "http:\/\/ilovetefl.wordpress.com\/2013\/02\/02\/lets-start-with-a-little-tai-chi-no-seriously\/",
      "display_url" : "ilovetefl.wordpress.com\/2013\/02\/02\/let\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298160046305574912",
  "text" : "RT @RebuffetBroadus: Trying Tai Chi in class for gr. cohesion &amp; concentration  http:\/\/t.co\/v8p7HJ45",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/v8p7HJ45",
        "expanded_url" : "http:\/\/ilovetefl.wordpress.com\/2013\/02\/02\/lets-start-with-a-little-tai-chi-no-seriously\/",
        "display_url" : "ilovetefl.wordpress.com\/2013\/02\/02\/let\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298048268687007747",
    "text" : "Trying Tai Chi in class for gr. cohesion &amp; concentration  http:\/\/t.co\/v8p7HJ45",
    "id" : 298048268687007747,
    "created_at" : "2013-02-03 12:40:19 +0000",
    "user" : {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "protected" : false,
      "id_str" : "22635290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3591430389\/aba53edd59922a0e1f786128e7797e4a_normal.jpeg",
      "id" : 22635290,
      "verified" : false
    }
  },
  "id" : 298160046305574912,
  "created_at" : "2013-02-03 20:04:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298146324614873090",
  "geo" : { },
  "id_str" : "298146766338011138",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson great a three day weekend :) party on!",
  "id" : 298146766338011138,
  "in_reply_to_status_id" : 298146324614873090,
  "created_at" : "2013-02-03 19:11:43 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 80, 91 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/3mpl2A8S",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-hr",
      "display_url" : "wp.me\/pgHyE-hr"
    } ]
  },
  "geo" : { },
  "id_str" : "298146472631889920",
  "text" : "This corpora-bashing parrot has ceased to be http:\/\/t.co\/3mpl2A8S a response to @hughdellar, forgive the stretching of the Python ref :)",
  "id" : 298146472631889920,
  "created_at" : "2013-02-03 19:10:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298144123804868608",
  "geo" : { },
  "id_str" : "298146175910047744",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson sounds groovy, what happens?",
  "id" : 298146175910047744,
  "in_reply_to_status_id" : 298144123804868608,
  "created_at" : "2013-02-03 19:09:22 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/MblVYE2B",
      "expanded_url" : "http:\/\/purl.org\/backbone\/searchtool",
      "display_url" : "purl.org\/backbone\/searc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297476327676719104",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar have you seen this http:\/\/t.co\/MblVYE2B, tried to comment again on yr bog but no luck so far",
  "id" : 297476327676719104,
  "created_at" : "2013-02-01 22:47:38 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 38, 42 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "tefl",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "tesol",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/GzkgNz77",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-vG",
      "display_url" : "wp.me\/p2hCXG-vG"
    } ]
  },
  "geo" : { },
  "id_str" : "297408768981991425",
  "text" : "RT @MrChrisJWilson: Weekly roundup in #elt for the last week of January http:\/\/t.co\/GzkgNz77 #eltchat #tefl #tesol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 18, 22 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 73, 81 ]
      }, {
        "text" : "tefl",
        "indices" : [ 82, 87 ]
      }, {
        "text" : "tesol",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/GzkgNz77",
        "expanded_url" : "http:\/\/wp.me\/p2hCXG-vG",
        "display_url" : "wp.me\/p2hCXG-vG"
      } ]
    },
    "geo" : { },
    "id_str" : "297366747760185346",
    "text" : "Weekly roundup in #elt for the last week of January http:\/\/t.co\/GzkgNz77 #eltchat #tefl #tesol",
    "id" : 297366747760185346,
    "created_at" : "2013-02-01 15:32:12 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 297408768981991425,
  "created_at" : "2013-02-01 18:19:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 37, 48 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/aRgJx0zm",
      "expanded_url" : "http:\/\/hughdellar.wordpress.com\/2013\/01\/31\/what-have-corpora-ever-done-for-us\/",
      "display_url" : "hughdellar.wordpress.com\/2013\/01\/31\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297405902615621632",
  "text" : "not content with havin a go at dogme @hughdellar is havin a go at corpora http:\/\/t.co\/aRgJx0zm will his madness not end? ;)",
  "id" : 297405902615621632,
  "created_at" : "2013-02-01 18:07:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 16, 27 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297395412334161920",
  "geo" : { },
  "id_str" : "297398733899984898",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @teflerinha yes i believe so, the video wld have been gd at that time to convince my skeptical BE sts :)",
  "id" : 297398733899984898,
  "in_reply_to_status_id" : 297395412334161920,
  "created_at" : "2013-02-01 17:39:18 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "esol",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/unUB2NBs",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-b8",
      "display_url" : "wp.me\/p2e2Wf-b8"
    } ]
  },
  "geo" : { },
  "id_str" : "297393962883375104",
  "text" : "RT @teflerinha: Living without money: new free downloadable lesson from ELT-Resourceful http:\/\/t.co\/unUB2NBs #eltchat #esol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 93, 101 ]
      }, {
        "text" : "esol",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/unUB2NBs",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-b8",
        "display_url" : "wp.me\/p2e2Wf-b8"
      } ]
    },
    "geo" : { },
    "id_str" : "297381386191511552",
    "text" : "Living without money: new free downloadable lesson from ELT-Resourceful http:\/\/t.co\/unUB2NBs #eltchat #esol",
    "id" : 297381386191511552,
    "created_at" : "2013-02-01 16:30:22 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 297393962883375104,
  "created_at" : "2013-02-01 17:20:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297381966167298048",
  "geo" : { },
  "id_str" : "297393918226624512",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @MrChrisJWilson yonks ago i used the german woman's story from new english file intermediate afair. a salutary story for sure!",
  "id" : 297393918226624512,
  "in_reply_to_status_id" : 297381966167298048,
  "created_at" : "2013-02-01 17:20:10 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 0, 12 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 13, 28 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 29, 42 ],
      "id_str" : "39718253",
      "id" : 39718253
    }, {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "indices" : [ 43, 55 ],
      "id_str" : "30663558",
      "id" : 30663558
    }, {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 56, 67 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297363689554731008",
  "geo" : { },
  "id_str" : "297365002380271616",
  "in_reply_to_user_id" : 20425399,
  "text" : "@nmkrobinson @thornburyscott @LukeMeddings @lclandfield @wetheround any sample page for this?",
  "id" : 297365002380271616,
  "in_reply_to_status_id" : 297363689554731008,
  "created_at" : "2013-02-01 15:25:15 +0000",
  "in_reply_to_screen_name" : "nmkrobinson",
  "in_reply_to_user_id_str" : "20425399",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297297530012704768",
  "geo" : { },
  "id_str" : "297364049371480064",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 what a cake! maybe a big enough ice\/cooler bag?",
  "id" : 297364049371480064,
  "in_reply_to_status_id" : 297297530012704768,
  "created_at" : "2013-02-01 15:21:28 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297235103480946688",
  "geo" : { },
  "id_str" : "297362717591867392",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras a class website, all the best!",
  "id" : 297362717591867392,
  "in_reply_to_status_id" : 297235103480946688,
  "created_at" : "2013-02-01 15:16:11 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/3c6ZP06g",
      "expanded_url" : "http:\/\/osakapov.blogspot.jp\/2013\/01\/who-we-are-international-course-from.html",
      "display_url" : "osakapov.blogspot.jp\/2013\/01\/who-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297362559303045121",
  "text" : "RT @kevchanwow: Osaka high school students w\/ a new blog, hoping for comments, especially from other teens: http:\/\/t.co\/3c6ZP06g (all RT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/3c6ZP06g",
        "expanded_url" : "http:\/\/osakapov.blogspot.jp\/2013\/01\/who-we-are-international-course-from.html",
        "display_url" : "osakapov.blogspot.jp\/2013\/01\/who-we\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297186695894425600",
    "text" : "Osaka high school students w\/ a new blog, hoping for comments, especially from other teens: http:\/\/t.co\/3c6ZP06g (all RTs &amp; MT appreciated)",
    "id" : 297186695894425600,
    "created_at" : "2013-02-01 03:36:44 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 297362559303045121,
  "created_at" : "2013-02-01 15:15:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 71, 86 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297169656815419393",
  "geo" : { },
  "id_str" : "297362381078675456",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt nice one tyson, though there is a glaring ELT blog omission - @thornburyscott",
  "id" : 297362381078675456,
  "in_reply_to_status_id" : 297169656815419393,
  "created_at" : "2013-02-01 15:14:51 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Yes, You're Racist",
      "screen_name" : "YesYoureRacist",
      "indices" : [ 7, 22 ],
      "id_str" : "858924511",
      "id" : 858924511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/VnrSXAKH",
      "expanded_url" : "http:\/\/dlvr.it\/2tN0H6",
      "display_url" : "dlvr.it\/2tN0H6"
    } ]
  },
  "geo" : { },
  "id_str" : "297361424345333761",
  "text" : "@EBEFL @YesYoureRacist have you seen this? http:\/\/t.co\/VnrSXAKH",
  "id" : 297361424345333761,
  "created_at" : "2013-02-01 15:11:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297283797043539968",
  "geo" : { },
  "id_str" : "297361078076198914",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi, this and another earlier link to yr blog seems broken?",
  "id" : 297361078076198914,
  "in_reply_to_status_id" : 297283797043539968,
  "created_at" : "2013-02-01 15:09:40 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297253574860238849",
  "geo" : { },
  "id_str" : "297358939572563968",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 a pleasure",
  "id" : 297358939572563968,
  "in_reply_to_status_id" : 297253574860238849,
  "created_at" : "2013-02-01 15:01:10 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297148208356937728",
  "geo" : { },
  "id_str" : "297358856663732226",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow many thx for rt and comment, a boingboing commenter coined glomitts which is cute as well",
  "id" : 297358856663732226,
  "in_reply_to_status_id" : 297148208356937728,
  "created_at" : "2013-02-01 15:00:50 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 12, 25 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297133031058182144",
  "geo" : { },
  "id_str" : "297358630817259524",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @harrisonmike hehe i hve theory one hulk organ did not get same gamma radiation so peeing could set him off :)",
  "id" : 297358630817259524,
  "in_reply_to_status_id" : 297133031058182144,
  "created_at" : "2013-02-01 14:59:56 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]