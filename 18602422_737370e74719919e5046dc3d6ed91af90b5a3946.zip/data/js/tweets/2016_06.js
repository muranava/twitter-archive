Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/748635954844401664\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/EY7bxK0pEI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmOwY6cWIAARmfo.jpg",
      "id_str" : "748635905125130240",
      "id" : 748635905125130240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmOwY6cWIAARmfo.jpg",
      "sizes" : [ {
        "h" : 273,
        "resize" : "fit",
        "w" : 1296
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 1296
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/EY7bxK0pEI"
    } ],
    "hashtags" : [ {
      "text" : "SardonicConcordancing",
      "indices" : [ 0, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/B639hMLqGn",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=48868537",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748635954844401664",
  "text" : "#SardonicConcordancing https:\/\/t.co\/B639hMLqGn https:\/\/t.co\/EY7bxK0pEI",
  "id" : 748635954844401664,
  "created_at" : "2016-06-30 21:54:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/KBzWVBrp4b",
      "expanded_url" : "https:\/\/shar.es\/1lrrkq",
      "display_url" : "shar.es\/1lrrkq"
    } ]
  },
  "geo" : { },
  "id_str" : "748632601347371009",
  "text" : "RT @Jonathan_K_Cook: My latest: Video exposes Guardian's malicious falsehood against Corbyn https:\/\/t.co\/KBzWVBrp4b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/KBzWVBrp4b",
        "expanded_url" : "https:\/\/shar.es\/1lrrkq",
        "display_url" : "shar.es\/1lrrkq"
      } ]
    },
    "geo" : { },
    "id_str" : "748615628051873793",
    "text" : "My latest: Video exposes Guardian's malicious falsehood against Corbyn https:\/\/t.co\/KBzWVBrp4b",
    "id" : 748615628051873793,
    "created_at" : "2016-06-30 20:34:08 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 748632601347371009,
  "created_at" : "2016-06-30 21:41:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748628338902728704",
  "geo" : { },
  "id_str" : "748629309049438209",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl who mentioned Corbyn? is he like the boogie monster?",
  "id" : 748629309049438209,
  "in_reply_to_status_id" : 748628338902728704,
  "created_at" : "2016-06-30 21:28:30 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/yXC78lgePA",
      "expanded_url" : "https:\/\/twitter.com\/MichaelLCrick\/status\/748624708090929154",
      "display_url" : "twitter.com\/MichaelLCrick\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748627178930249728",
  "text" : "RT @pchallinor: Sweet, isn't it. Santa Claus, the Tooth Fairy, British democracy... https:\/\/t.co\/yXC78lgePA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/yXC78lgePA",
        "expanded_url" : "https:\/\/twitter.com\/MichaelLCrick\/status\/748624708090929154",
        "display_url" : "twitter.com\/MichaelLCrick\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748626430737657856",
    "text" : "Sweet, isn't it. Santa Claus, the Tooth Fairy, British democracy... https:\/\/t.co\/yXC78lgePA",
    "id" : 748626430737657856,
    "created_at" : "2016-06-30 21:17:04 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 748627178930249728,
  "created_at" : "2016-06-30 21:20:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LabourCoup",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/lcVpts0mZY",
      "expanded_url" : "https:\/\/goo.gl\/hs5D1q",
      "display_url" : "goo.gl\/hs5D1q"
    } ]
  },
  "geo" : { },
  "id_str" : "748612147110883328",
  "text" : "RT @josipa74: Angela Eagle, did you lie when you resigned? Over to you. #LabourCoup\n\n https:\/\/t.co\/lcVpts0mZY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LabourCoup",
        "indices" : [ 58, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/lcVpts0mZY",
        "expanded_url" : "https:\/\/goo.gl\/hs5D1q",
        "display_url" : "goo.gl\/hs5D1q"
      } ]
    },
    "geo" : { },
    "id_str" : "748610458836410368",
    "text" : "Angela Eagle, did you lie when you resigned? Over to you. #LabourCoup\n\n https:\/\/t.co\/lcVpts0mZY",
    "id" : 748610458836410368,
    "created_at" : "2016-06-30 20:13:36 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 748612147110883328,
  "created_at" : "2016-06-30 20:20:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 78, 90 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/hYcpjyNYw5",
      "expanded_url" : "https:\/\/off-guardian.org\/2016\/06\/30\/how-the-eu-pushed-france-to-reforms-of-labour-law\/",
      "display_url" : "off-guardian.org\/2016\/06\/30\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748598996210487296",
  "text" : "How the EU pushed France to reforms of labour law https:\/\/t.co\/hYcpjyNYw5 via @OffGuardian",
  "id" : 748598996210487296,
  "created_at" : "2016-06-30 19:28:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    }, {
      "name" : "Douglas Carswell MP",
      "screen_name" : "DouglasCarswell",
      "indices" : [ 58, 74 ],
      "id_str" : "25097735",
      "id" : 25097735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/EddfnKIUad",
      "expanded_url" : "https:\/\/twitter.com\/Far_Right_Watch\/status\/748575101721927680",
      "display_url" : "twitter.com\/Far_Right_Watc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748596409830678528",
  "text" : "RT @pchallinor: While we're waiting for our \u00A3350 million, @DouglasCarswell, do you consider this a sensible proposition? https:\/\/t.co\/Eddfn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Douglas Carswell MP",
        "screen_name" : "DouglasCarswell",
        "indices" : [ 42, 58 ],
        "id_str" : "25097735",
        "id" : 25097735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/EddfnKIUad",
        "expanded_url" : "https:\/\/twitter.com\/Far_Right_Watch\/status\/748575101721927680",
        "display_url" : "twitter.com\/Far_Right_Watc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748593659885527041",
    "text" : "While we're waiting for our \u00A3350 million, @DouglasCarswell, do you consider this a sensible proposition? https:\/\/t.co\/EddfnKIUad",
    "id" : 748593659885527041,
    "created_at" : "2016-06-30 19:06:51 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 748596409830678528,
  "created_at" : "2016-06-30 19:17:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/748532078975684609\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/9KJYQSEJX7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNR9R_UsAAovhq.jpg",
      "id_str" : "748532076316504064",
      "id" : 748532076316504064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNR9R_UsAAovhq.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/9KJYQSEJX7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/sLVdgpDfZN",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/06\/30\/harmer-on-brexit",
      "display_url" : "criticalelt.wordpress.com\/2016\/06\/30\/har\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748538279277039616",
  "text" : "RT @GeoffreyJordan: Harmer on Brexit https:\/\/t.co\/sLVdgpDfZN https:\/\/t.co\/9KJYQSEJX7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/748532078975684609\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/9KJYQSEJX7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNR9R_UsAAovhq.jpg",
        "id_str" : "748532076316504064",
        "id" : 748532076316504064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNR9R_UsAAovhq.jpg",
        "sizes" : [ {
          "h" : 420,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/9KJYQSEJX7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/sLVdgpDfZN",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/06\/30\/harmer-on-brexit",
        "display_url" : "criticalelt.wordpress.com\/2016\/06\/30\/har\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748532078975684609",
    "text" : "Harmer on Brexit https:\/\/t.co\/sLVdgpDfZN https:\/\/t.co\/9KJYQSEJX7",
    "id" : 748532078975684609,
    "created_at" : "2016-06-30 15:02:09 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 748538279277039616,
  "created_at" : "2016-06-30 15:26:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "Theresa May",
      "screen_name" : "theresamay2016",
      "indices" : [ 8, 23 ],
      "id_str" : "752838065245347840",
      "id" : 752838065245347840
    }, {
      "name" : "Inclusion Meet",
      "screen_name" : "InclusionMeet",
      "indices" : [ 24, 38 ],
      "id_str" : "3748518795",
      "id" : 3748518795
    }, {
      "name" : "Daniel Trilling",
      "screen_name" : "trillingual",
      "indices" : [ 71, 83 ],
      "id_str" : "97471029",
      "id" : 97471029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/6BU2jn0wg1",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2012\/dec\/12\/theresa-may-immigration-speech",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "748476982141288448",
  "geo" : { },
  "id_str" : "748478695996788736",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed @TheresaMay2016 @InclusionMeet see https:\/\/t.co\/6BU2jn0wg1 h\/t @trillingual",
  "id" : 748478695996788736,
  "in_reply_to_status_id" : 748476982141288448,
  "created_at" : "2016-06-30 11:30:01 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "Theresa May",
      "screen_name" : "theresamay2016",
      "indices" : [ 8, 23 ],
      "id_str" : "752838065245347840",
      "id" : 752838065245347840
    }, {
      "name" : "Inclusion Meet",
      "screen_name" : "InclusionMeet",
      "indices" : [ 24, 38 ],
      "id_str" : "3748518795",
      "id" : 3748518795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748476014846746624",
  "geo" : { },
  "id_str" : "748476476933177344",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed @TheresaMay2016 @InclusionMeet fyi this from 2012 not today's speech",
  "id" : 748476476933177344,
  "in_reply_to_status_id" : 748476014846746624,
  "created_at" : "2016-06-30 11:21:12 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 3, 10 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "Schools Week",
      "screen_name" : "SchoolsWeek",
      "indices" : [ 35, 47 ],
      "id_str" : "2491487924",
      "id" : 2491487924
    }, {
      "name" : "Theresa May",
      "screen_name" : "theresamay2016",
      "indices" : [ 104, 119 ],
      "id_str" : "752838065245347840",
      "id" : 752838065245347840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAL",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/XCNOv7ZNR5",
      "expanded_url" : "https:\/\/twitter.com\/mehreenkhn\/status\/748447857263378432",
      "display_url" : "twitter.com\/mehreenkhn\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748465522455494656",
  "text" : "RT @DiLeed: Here it is. Right here @SchoolsWeek Evidence of anti #EAL bias and negativity from the top. @TheresaMay2016  https:\/\/t.co\/XCNOv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Schools Week",
        "screen_name" : "SchoolsWeek",
        "indices" : [ 23, 35 ],
        "id_str" : "2491487924",
        "id" : 2491487924
      }, {
        "name" : "Theresa May",
        "screen_name" : "theresamay2016",
        "indices" : [ 92, 107 ],
        "id_str" : "752838065245347840",
        "id" : 752838065245347840
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAL",
        "indices" : [ 53, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/XCNOv7ZNR5",
        "expanded_url" : "https:\/\/twitter.com\/mehreenkhn\/status\/748447857263378432",
        "display_url" : "twitter.com\/mehreenkhn\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748465312958418944",
    "text" : "Here it is. Right here @SchoolsWeek Evidence of anti #EAL bias and negativity from the top. @TheresaMay2016  https:\/\/t.co\/XCNOv7ZNR5",
    "id" : 748465312958418944,
    "created_at" : "2016-06-30 10:36:51 +0000",
    "user" : {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "protected" : false,
      "id_str" : "2335217159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531591034740826112\/jFKHAmex_normal.jpeg",
      "id" : 2335217159,
      "verified" : false
    }
  },
  "id" : 748465522455494656,
  "created_at" : "2016-06-30 10:37:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Curtis",
      "screen_name" : "markcurtis30",
      "indices" : [ 3, 16 ],
      "id_str" : "2278053312",
      "id" : 2278053312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748460222801412096",
  "text" : "RT @markcurtis30: Attack on Corbyn more important than Brexit for progressive change. We can work under Brexit, but hard if establishment w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748168151066677248",
    "text" : "Attack on Corbyn more important than Brexit for progressive change. We can work under Brexit, but hard if establishment wins now ag.Corbyn",
    "id" : 748168151066677248,
    "created_at" : "2016-06-29 14:56:02 +0000",
    "user" : {
      "name" : "Mark Curtis",
      "screen_name" : "markcurtis30",
      "protected" : false,
      "id_str" : "2278053312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644110073963397120\/s-BUPkdk_normal.jpg",
      "id" : 2278053312,
      "verified" : false
    }
  },
  "id" : 748460222801412096,
  "created_at" : "2016-06-30 10:16:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748458378305863680",
  "text" : "RT @medialens: So we've got all 'MSM' hammering Corbyn, and ex-journalists Johnson\/Gove 'trying to do a deal with' Dacre\/Murdoch. Are you g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748454936355155968",
    "text" : "So we've got all 'MSM' hammering Corbyn, and ex-journalists Johnson\/Gove 'trying to do a deal with' Dacre\/Murdoch. Are you getting it yet?",
    "id" : 748454936355155968,
    "created_at" : "2016-06-30 09:55:37 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 748458378305863680,
  "created_at" : "2016-06-30 10:09:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 3, 12 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 77, 91 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Hack Education",
      "screen_name" : "hackeducation",
      "indices" : [ 92, 106 ],
      "id_str" : "149029700",
      "id" : 149029700
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Ashowski\/status\/748273365333446660\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ZGjqHJCqs3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJmqKHWQAAPjHl.jpg",
      "id_str" : "748273362552635392",
      "id" : 748273362552635392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJmqKHWQAAPjHl.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ZGjqHJCqs3"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "edu",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/9KOuwG3kwI",
      "expanded_url" : "http:\/\/buff.ly\/2934y7u",
      "display_url" : "buff.ly\/2934y7u"
    } ]
  },
  "geo" : { },
  "id_str" : "748282626612559872",
  "text" : "RT @Ashowski: The Rough Beasts of edtech https:\/\/t.co\/9KOuwG3kwI #edtech via @audreywatters @hackeducation #edu https:\/\/t.co\/ZGjqHJCqs3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 63, 77 ],
        "id_str" : "25388528",
        "id" : 25388528
      }, {
        "name" : "Hack Education",
        "screen_name" : "hackeducation",
        "indices" : [ 78, 92 ],
        "id_str" : "149029700",
        "id" : 149029700
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Ashowski\/status\/748273365333446660\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/ZGjqHJCqs3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJmqKHWQAAPjHl.jpg",
        "id_str" : "748273362552635392",
        "id" : 748273362552635392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJmqKHWQAAPjHl.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ZGjqHJCqs3"
      } ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 51, 58 ]
      }, {
        "text" : "edu",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/9KOuwG3kwI",
        "expanded_url" : "http:\/\/buff.ly\/2934y7u",
        "display_url" : "buff.ly\/2934y7u"
      } ]
    },
    "geo" : { },
    "id_str" : "748273365333446660",
    "text" : "The Rough Beasts of edtech https:\/\/t.co\/9KOuwG3kwI #edtech via @audreywatters @hackeducation #edu https:\/\/t.co\/ZGjqHJCqs3",
    "id" : 748273365333446660,
    "created_at" : "2016-06-29 21:54:07 +0000",
    "user" : {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "protected" : false,
      "id_str" : "316596356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701193668896681984\/nWfDqOas_normal.jpg",
      "id" : 316596356,
      "verified" : false
    }
  },
  "id" : 748282626612559872,
  "created_at" : "2016-06-29 22:30:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Olds",
      "screen_name" : "GlobalHigherEd",
      "indices" : [ 3, 18 ],
      "id_str" : "20961822",
      "id" : 20961822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/dQoxQbFDDE",
      "expanded_url" : "http:\/\/parliamentlive.tv\/Event\/Index\/49e82a64-719f-4719-a19e-a7554c8791d3",
      "display_url" : "parliamentlive.tv\/Event\/Index\/49\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748251142543532033",
  "text" : "RT @GlobalHigherEd: Extraordinary UK Gov dialogue today https:\/\/t.co\/dQoxQbFDDE (15:31 to 15:37) bound to generate anxiety amongst 1.2 m EU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/dQoxQbFDDE",
        "expanded_url" : "http:\/\/parliamentlive.tv\/Event\/Index\/49e82a64-719f-4719-a19e-a7554c8791d3",
        "display_url" : "parliamentlive.tv\/Event\/Index\/49\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748222911534764032",
    "text" : "Extraordinary UK Gov dialogue today https:\/\/t.co\/dQoxQbFDDE (15:31 to 15:37) bound to generate anxiety amongst 1.2 m EU nationals in UK",
    "id" : 748222911534764032,
    "created_at" : "2016-06-29 18:33:38 +0000",
    "user" : {
      "name" : "Kris Olds",
      "screen_name" : "GlobalHigherEd",
      "protected" : false,
      "id_str" : "20961822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621032135546155008\/_rFTL8PI_normal.jpg",
      "id" : 20961822,
      "verified" : false
    }
  },
  "id" : 748251142543532033,
  "created_at" : "2016-06-29 20:25:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam H. Johnson",
      "screen_name" : "adamjohnsonNYC",
      "indices" : [ 3, 18 ],
      "id_str" : "756331316",
      "id" : 756331316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748243726200377344",
  "text" : "RT @adamjohnsonNYC: \"if only Corbyn handled MSM better\" is the question-begging of moral idiots who-either b\/c of cowardice or ignorance-ha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748225260953153537",
    "text" : "\"if only Corbyn handled MSM better\" is the question-begging of moral idiots who-either b\/c of cowardice or ignorance-have causation reversed",
    "id" : 748225260953153537,
    "created_at" : "2016-06-29 18:42:58 +0000",
    "user" : {
      "name" : "Adam H. Johnson",
      "screen_name" : "adamjohnsonNYC",
      "protected" : false,
      "id_str" : "756331316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643965876090327040\/MhtfHO9A_normal.jpg",
      "id" : 756331316,
      "verified" : true
    }
  },
  "id" : 748243726200377344,
  "created_at" : "2016-06-29 19:56:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DrSuzanneConboy-Hill",
      "screen_name" : "strayficshion",
      "indices" : [ 0, 14 ],
      "id_str" : "101487178",
      "id" : 101487178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748203728923148288",
  "geo" : { },
  "id_str" : "748205133863981057",
  "in_reply_to_user_id" : 101487178,
  "text" : "@strayficshion ah okay thanks seems 2 people thought this; and overall no preference for remain or stay",
  "id" : 748205133863981057,
  "in_reply_to_status_id" : 748203728923148288,
  "created_at" : "2016-06-29 17:22:59 +0000",
  "in_reply_to_screen_name" : "strayficshion",
  "in_reply_to_user_id_str" : "101487178",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "indices" : [ 68, 81 ],
      "id_str" : "270100506",
      "id" : 270100506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qxGDyZosyG",
      "expanded_url" : "https:\/\/twitter.com\/IanJSinclair\/status\/748193026317627392",
      "display_url" : "twitter.com\/IanJSinclair\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748201167885320192",
  "text" : "RT @johnwhilley: Turns out angelic Eagle is more of a Hillary hawk. @IanJSinclair unearths the coup plotters' 'great left hope'. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Sinclair",
        "screen_name" : "IanJSinclair",
        "indices" : [ 51, 64 ],
        "id_str" : "270100506",
        "id" : 270100506
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/qxGDyZosyG",
        "expanded_url" : "https:\/\/twitter.com\/IanJSinclair\/status\/748193026317627392",
        "display_url" : "twitter.com\/IanJSinclair\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748200669992058880",
    "text" : "Turns out angelic Eagle is more of a Hillary hawk. @IanJSinclair unearths the coup plotters' 'great left hope'. https:\/\/t.co\/qxGDyZosyG",
    "id" : 748200669992058880,
    "created_at" : "2016-06-29 17:05:15 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 748201167885320192,
  "created_at" : "2016-06-29 17:07:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DrSuzanneConboy-Hill",
      "screen_name" : "strayficshion",
      "indices" : [ 0, 14 ],
      "id_str" : "101487178",
      "id" : 101487178
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 15, 26 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748199382147805184",
  "geo" : { },
  "id_str" : "748200477708455936",
  "in_reply_to_user_id" : 101487178,
  "text" : "@strayficshion @lexicoj0hn do you have ref for that? thx",
  "id" : 748200477708455936,
  "in_reply_to_status_id" : 748199382147805184,
  "created_at" : "2016-06-29 17:04:29 +0000",
  "in_reply_to_screen_name" : "strayficshion",
  "in_reply_to_user_id_str" : "101487178",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 67, 77 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/HCPBhFRbt7",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2016\/822-killing-corbyn.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748198472260722688",
  "text" : "RT @johnwhilley: A very British media coup. Essential reading from @medialens on Killing Corbyn  https:\/\/t.co\/HCPBhFRbt7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 50, 60 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/HCPBhFRbt7",
        "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2016\/822-killing-corbyn.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748195621102850048",
    "text" : "A very British media coup. Essential reading from @medialens on Killing Corbyn  https:\/\/t.co\/HCPBhFRbt7",
    "id" : 748195621102850048,
    "created_at" : "2016-06-29 16:45:11 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 748198472260722688,
  "created_at" : "2016-06-29 16:56:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "DrSuzanneConboy-Hill",
      "screen_name" : "strayficshion",
      "indices" : [ 12, 26 ],
      "id_str" : "101487178",
      "id" : 101487178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/6XsvQ5Bfjg",
      "expanded_url" : "http:\/\/www.electoralcommission.org.uk\/find-information-by-subject\/elections-and-referendums\/upcoming-elections-and-referendums\/eu-referendum\/eu-referendum-question-assessment?a=166613",
      "display_url" : "electoralcommission.org.uk\/find-informati\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "748151852219367424",
  "geo" : { },
  "id_str" : "748190145820647424",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn @strayficshion according to  https:\/\/t.co\/6XsvQ5Bfjg  remain was seen as formal &amp; hence suitable not stay was seen  as command?",
  "id" : 748190145820647424,
  "in_reply_to_status_id" : 748151852219367424,
  "created_at" : "2016-06-29 16:23:26 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 3, 14 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Morse",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/27WxxVIYpl",
      "expanded_url" : "https:\/\/twitter.com\/strayficshion\/status\/748132933949493248",
      "display_url" : "twitter.com\/strayficshion\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748186412269314048",
  "text" : "RT @lexicoj0hn: Very different, linguistic way of explaining the result. I remember a #Morse case that hinged on the word 'remain'. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Morse",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/27WxxVIYpl",
        "expanded_url" : "https:\/\/twitter.com\/strayficshion\/status\/748132933949493248",
        "display_url" : "twitter.com\/strayficshion\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748151852219367424",
    "text" : "Very different, linguistic way of explaining the result. I remember a #Morse case that hinged on the word 'remain'. https:\/\/t.co\/27WxxVIYpl",
    "id" : 748151852219367424,
    "created_at" : "2016-06-29 13:51:16 +0000",
    "user" : {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "protected" : false,
      "id_str" : "4008981801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710135773476032516\/BNqiKR1y_normal.jpg",
      "id" : 4008981801,
      "verified" : false
    }
  },
  "id" : 748186412269314048,
  "created_at" : "2016-06-29 16:08:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 3, 17 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Forvo Pronunciations",
      "screen_name" : "forvo",
      "indices" : [ 40, 46 ],
      "id_str" : "14361701",
      "id" : 14361701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/45zaaCJfEJ",
      "expanded_url" : "http:\/\/www.audio-lingua.eu\/spip.php?page=themes&lang=es",
      "display_url" : "audio-lingua.eu\/spip.php?page=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748151283052331009",
  "text" : "RT @eannegrenoble: A great crowdsourced @forvo -type site: authetic short audio snippets for your students (several languages) https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Forvo Pronunciations",
        "screen_name" : "forvo",
        "indices" : [ 21, 27 ],
        "id_str" : "14361701",
        "id" : 14361701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/45zaaCJfEJ",
        "expanded_url" : "http:\/\/www.audio-lingua.eu\/spip.php?page=themes&lang=es",
        "display_url" : "audio-lingua.eu\/spip.php?page=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747921514415136768",
    "text" : "A great crowdsourced @forvo -type site: authetic short audio snippets for your students (several languages) https:\/\/t.co\/45zaaCJfEJ",
    "id" : 747921514415136768,
    "created_at" : "2016-06-28 22:35:59 +0000",
    "user" : {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "protected" : false,
      "id_str" : "19869781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486151060419907584\/DQRq7qOi_normal.jpeg",
      "id" : 19869781,
      "verified" : false
    }
  },
  "id" : 748151283052331009,
  "created_at" : "2016-06-29 13:49:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "indices" : [ 0, 14 ],
      "id_str" : "43068002",
      "id" : 43068002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748148319059312640",
  "geo" : { },
  "id_str" : "748149904703430656",
  "in_reply_to_user_id" : 43068002,
  "text" : "@annabooklover maybe(have no idea), is it efficient probably not?",
  "id" : 748149904703430656,
  "in_reply_to_status_id" : 748148319059312640,
  "created_at" : "2016-06-29 13:43:31 +0000",
  "in_reply_to_screen_name" : "annabooklover",
  "in_reply_to_user_id_str" : "43068002",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeardinLondon",
      "screen_name" : "HeardinLondon",
      "indices" : [ 3, 17 ],
      "id_str" : "172699095",
      "id" : 172699095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "safetyPin",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/AiPIaifpyv",
      "expanded_url" : "http:\/\/occupywallstreet.net\/story\/explaining-white-privilege-broke-white-person",
      "display_url" : "occupywallstreet.net\/story\/explaini\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748149453404672000",
  "text" : "RT @HeardinLondon: As well as a #safetyPin, let's also spread education. \nEXPLAINING WHITE PRIVILEGE TO A BROKE WHITE PERSON... https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "safetyPin",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/AiPIaifpyv",
        "expanded_url" : "http:\/\/occupywallstreet.net\/story\/explaining-white-privilege-broke-white-person",
        "display_url" : "occupywallstreet.net\/story\/explaini\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "748128321775468544",
    "geo" : { },
    "id_str" : "748128849649602560",
    "in_reply_to_user_id" : 172699095,
    "text" : "As well as a #safetyPin, let's also spread education. \nEXPLAINING WHITE PRIVILEGE TO A BROKE WHITE PERSON... https:\/\/t.co\/AiPIaifpyv",
    "id" : 748128849649602560,
    "in_reply_to_status_id" : 748128321775468544,
    "created_at" : "2016-06-29 12:19:51 +0000",
    "in_reply_to_screen_name" : "HeardinLondon",
    "in_reply_to_user_id_str" : "172699095",
    "user" : {
      "name" : "HeardinLondon",
      "screen_name" : "HeardinLondon",
      "protected" : false,
      "id_str" : "172699095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1261796856\/cnd_normal.jpg",
      "id" : 172699095,
      "verified" : false
    }
  },
  "id" : 748149453404672000,
  "created_at" : "2016-06-29 13:41:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748031257477550080",
  "geo" : { },
  "id_str" : "748086957088071680",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble aye &amp; that one about in order to have  colonized others first u had to colonize yr own?",
  "id" : 748086957088071680,
  "in_reply_to_status_id" : 748031257477550080,
  "created_at" : "2016-06-29 09:33:24 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 3, 17 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 19, 28 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/6ayWxxk3XH",
      "expanded_url" : "https:\/\/twitter.com\/Che_Matt\/status\/744595139683848193",
      "display_url" : "twitter.com\/Che_Matt\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748024355855163393",
  "text" : "RT @eannegrenoble: @muranava did you see this one? Published 14th June ... why oh why didn't it go viral? https:\/\/t.co\/6ayWxxk3XH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/6ayWxxk3XH",
        "expanded_url" : "https:\/\/twitter.com\/Che_Matt\/status\/744595139683848193",
        "display_url" : "twitter.com\/Che_Matt\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747942574992859136",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava did you see this one? Published 14th June ... why oh why didn't it go viral? https:\/\/t.co\/6ayWxxk3XH",
    "id" : 747942574992859136,
    "created_at" : "2016-06-28 23:59:40 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "protected" : false,
      "id_str" : "19869781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486151060419907584\/DQRq7qOi_normal.jpeg",
      "id" : 19869781,
      "verified" : false
    }
  },
  "id" : 748024355855163393,
  "created_at" : "2016-06-29 05:24:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Batu",
      "screen_name" : "imadruid",
      "indices" : [ 50, 59 ],
      "id_str" : "766054177407660033",
      "id" : 766054177407660033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/JEEWPjt9Eg",
      "expanded_url" : "https:\/\/taoteaching.wordpress.com\/2016\/06\/29\/1500-words-of-vitriol\/",
      "display_url" : "taoteaching.wordpress.com\/2016\/06\/29\/150\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748022161105952768",
  "text" : "1500 words of vitriol https:\/\/t.co\/JEEWPjt9Eg via @Imadruid",
  "id" : 748022161105952768,
  "created_at" : "2016-06-29 05:15:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747942574992859136",
  "geo" : { },
  "id_str" : "748020455278284802",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble no thx, though  campaigns r not won by rationality, stoked up fear was more powerful",
  "id" : 748020455278284802,
  "in_reply_to_status_id" : 747942574992859136,
  "created_at" : "2016-06-29 05:09:08 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/c4yWmpkIpc",
      "expanded_url" : "https:\/\/twitter.com\/bbclaurak\/status\/747895061103411200",
      "display_url" : "twitter.com\/bbclaurak\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747930369706590208",
  "text" : "RT @pchallinor: Maybe the BBC's political news department has asked her to do it live on air, just for yucks? https:\/\/t.co\/c4yWmpkIpc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/c4yWmpkIpc",
        "expanded_url" : "https:\/\/twitter.com\/bbclaurak\/status\/747895061103411200",
        "display_url" : "twitter.com\/bbclaurak\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747928962114924544",
    "text" : "Maybe the BBC's political news department has asked her to do it live on air, just for yucks? https:\/\/t.co\/c4yWmpkIpc",
    "id" : 747928962114924544,
    "created_at" : "2016-06-28 23:05:35 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 747930369706590208,
  "created_at" : "2016-06-28 23:11:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Wrack",
      "screen_name" : "NickWrack",
      "indices" : [ 3, 13 ],
      "id_str" : "482248338",
      "id" : 482248338
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 16, 28 ],
      "id_str" : "65045121",
      "id" : 65045121
    }, {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "indices" : [ 91, 104 ],
      "id_str" : "117777690",
      "id" : 117777690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/0VGcLlrQIA",
      "expanded_url" : "https:\/\/twitter.com\/OwenJones84\/status\/747531452284297217",
      "display_url" : "twitter.com\/OwenJones84\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747930047172984833",
  "text" : "RT @NickWrack: .@OwenJones84 has 471K twitter followers. Instead of mobilising them behind @jeremycorbyn he flees the battle field. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 1, 13 ],
        "id_str" : "65045121",
        "id" : 65045121
      }, {
        "name" : "Jeremy Corbyn MP",
        "screen_name" : "jeremycorbyn",
        "indices" : [ 76, 89 ],
        "id_str" : "117777690",
        "id" : 117777690
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0VGcLlrQIA",
        "expanded_url" : "https:\/\/twitter.com\/OwenJones84\/status\/747531452284297217",
        "display_url" : "twitter.com\/OwenJones84\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747891696508223489",
    "text" : ".@OwenJones84 has 471K twitter followers. Instead of mobilising them behind @jeremycorbyn he flees the battle field. https:\/\/t.co\/0VGcLlrQIA",
    "id" : 747891696508223489,
    "created_at" : "2016-06-28 20:37:30 +0000",
    "user" : {
      "name" : "Nick Wrack",
      "screen_name" : "NickWrack",
      "protected" : false,
      "id_str" : "482248338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703542157307736064\/i_-Tq4nd_normal.jpg",
      "id" : 482248338,
      "verified" : false
    }
  },
  "id" : 747930047172984833,
  "created_at" : "2016-06-28 23:09:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "switched",
      "screen_name" : "switch_d",
      "indices" : [ 87, 96 ],
      "id_str" : "263917895",
      "id" : 263917895
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 97, 106 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/8qeaCRaXoQ",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-ifq",
      "display_url" : "wp.me\/pSoaD-ifq"
    } ]
  },
  "geo" : { },
  "id_str" : "747924789310926848",
  "text" : "RT @patrickDurusau: How To Get On The FBI Terrorist Watch List https:\/\/t.co\/8qeaCRaXoQ @switch_d @doctorow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "switched",
        "screen_name" : "switch_d",
        "indices" : [ 67, 76 ],
        "id_str" : "263917895",
        "id" : 263917895
      }, {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 77, 86 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/8qeaCRaXoQ",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-ifq",
        "display_url" : "wp.me\/pSoaD-ifq"
      } ]
    },
    "geo" : { },
    "id_str" : "747895915780931588",
    "text" : "How To Get On The FBI Terrorist Watch List https:\/\/t.co\/8qeaCRaXoQ @switch_d @doctorow",
    "id" : 747895915780931588,
    "created_at" : "2016-06-28 20:54:16 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 747924789310926848,
  "created_at" : "2016-06-28 22:49:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "indices" : [ 3, 14 ],
      "id_str" : "168090600",
      "id" : 168090600
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LabourEoin\/status\/747756953535905792\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/toMuw8Xhhb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCQ-DhWYAEOi-8.png",
      "id_str" : "747756933914976257",
      "id" : 747756933914976257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCQ-DhWYAEOi-8.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1108,
        "resize" : "fit",
        "w" : 1719
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1108,
        "resize" : "fit",
        "w" : 1719
      } ],
      "display_url" : "pic.twitter.com\/toMuw8Xhhb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747921167458181120",
  "text" : "RT @LabourEoin: 3 reasons why Labour Plotters have behaved disgracefully. https:\/\/t.co\/toMuw8Xhhb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LabourEoin\/status\/747756953535905792\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/toMuw8Xhhb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCQ-DhWYAEOi-8.png",
        "id_str" : "747756933914976257",
        "id" : 747756933914976257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCQ-DhWYAEOi-8.png",
        "sizes" : [ {
          "h" : 773,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1108,
          "resize" : "fit",
          "w" : 1719
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1108,
          "resize" : "fit",
          "w" : 1719
        } ],
        "display_url" : "pic.twitter.com\/toMuw8Xhhb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747756953535905792",
    "text" : "3 reasons why Labour Plotters have behaved disgracefully. https:\/\/t.co\/toMuw8Xhhb",
    "id" : 747756953535905792,
    "created_at" : "2016-06-28 11:42:05 +0000",
    "user" : {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "protected" : false,
      "id_str" : "168090600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767054309792047104\/mJQBKMcG_normal.jpg",
      "id" : 168090600,
      "verified" : false
    }
  },
  "id" : 747921167458181120,
  "created_at" : "2016-06-28 22:34:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Honnibal",
      "screen_name" : "honnibal",
      "indices" : [ 3, 12 ],
      "id_str" : "14699038",
      "id" : 14699038
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/honnibal\/status\/747893556883361793\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/cOPQ45kejN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmEM867UgAAlnq1.jpg",
      "id_str" : "747893253869961216",
      "id" : 747893253869961216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmEM867UgAAlnq1.jpg",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/cOPQ45kejN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/H1jMTmr01S",
      "expanded_url" : "https:\/\/medium.com\/@honnibal\/a-natural-language-user-interface-is-just-a-user-interface-4a6d898e9721#.sb12otceb",
      "display_url" : "medium.com\/@honnibal\/a-na\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747895371582562306",
  "text" : "RT @honnibal: Some thoughts about \"chat bots\": A Natural Language User Interface is just a User Interface https:\/\/t.co\/H1jMTmr01S https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/honnibal\/status\/747893556883361793\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/cOPQ45kejN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmEM867UgAAlnq1.jpg",
        "id_str" : "747893253869961216",
        "id" : 747893253869961216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmEM867UgAAlnq1.jpg",
        "sizes" : [ {
          "h" : 168,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 173,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 173,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 173,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/cOPQ45kejN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/H1jMTmr01S",
        "expanded_url" : "https:\/\/medium.com\/@honnibal\/a-natural-language-user-interface-is-just-a-user-interface-4a6d898e9721#.sb12otceb",
        "display_url" : "medium.com\/@honnibal\/a-na\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747893556883361793",
    "text" : "Some thoughts about \"chat bots\": A Natural Language User Interface is just a User Interface https:\/\/t.co\/H1jMTmr01S https:\/\/t.co\/cOPQ45kejN",
    "id" : 747893556883361793,
    "created_at" : "2016-06-28 20:44:53 +0000",
    "user" : {
      "name" : "Matthew Honnibal",
      "screen_name" : "honnibal",
      "protected" : false,
      "id_str" : "14699038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699259760265338880\/v4j33DBl_normal.png",
      "id" : 14699038,
      "verified" : false
    }
  },
  "id" : 747895371582562306,
  "created_at" : "2016-06-28 20:52:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Sd6LM9jU4Y",
      "expanded_url" : "https:\/\/twitter.com\/bellacaledonia\/status\/747878232406515712",
      "display_url" : "twitter.com\/bellacaledonia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747886952930762752",
  "text" : "RT @pchallinor: \"Listen to me, you little shit. Listen to me speaking foreign RIGHT IN YOUR EAR\" https:\/\/t.co\/Sd6LM9jU4Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Sd6LM9jU4Y",
        "expanded_url" : "https:\/\/twitter.com\/bellacaledonia\/status\/747878232406515712",
        "display_url" : "twitter.com\/bellacaledonia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747879665973465088",
    "text" : "\"Listen to me, you little shit. Listen to me speaking foreign RIGHT IN YOUR EAR\" https:\/\/t.co\/Sd6LM9jU4Y",
    "id" : 747879665973465088,
    "created_at" : "2016-06-28 19:49:41 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 747886952930762752,
  "created_at" : "2016-06-28 20:18:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Uncut",
      "screen_name" : "UKuncut",
      "indices" : [ 3, 11 ],
      "id_str" : "208058457",
      "id" : 208058457
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UKuncut\/status\/747878563366338560\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/xXgiu4qIZy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmD_dZHWQAAwxNs.jpg",
      "id_str" : "747878418566496256",
      "id" : 747878418566496256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmD_dZHWQAAwxNs.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/xXgiu4qIZy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747886599250272256",
  "text" : "RT @UKuncut: Pull yourselves together Labour and start fighting the Tories. https:\/\/t.co\/xXgiu4qIZy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UKuncut\/status\/747878563366338560\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/xXgiu4qIZy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmD_dZHWQAAwxNs.jpg",
        "id_str" : "747878418566496256",
        "id" : 747878418566496256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmD_dZHWQAAwxNs.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/xXgiu4qIZy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747878563366338560",
    "text" : "Pull yourselves together Labour and start fighting the Tories. https:\/\/t.co\/xXgiu4qIZy",
    "id" : 747878563366338560,
    "created_at" : "2016-06-28 19:45:19 +0000",
    "user" : {
      "name" : "UK Uncut",
      "screen_name" : "UKuncut",
      "protected" : false,
      "id_str" : "208058457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718434162424700928\/FEdxJZe__normal.jpg",
      "id" : 208058457,
      "verified" : true
    }
  },
  "id" : 747886599250272256,
  "created_at" : "2016-06-28 20:17:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747861878068621317",
  "geo" : { },
  "id_str" : "747876297213382657",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 wld be justice, but he is well protected by parts of the establishment",
  "id" : 747876297213382657,
  "in_reply_to_status_id" : 747861878068621317,
  "created_at" : "2016-06-28 19:36:18 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 3, 10 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/99jEPEL2mr",
      "expanded_url" : "https:\/\/twitter.com\/mendcommunity\/status\/747832496478367744",
      "display_url" : "twitter.com\/mendcommunity\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747875907055067136",
  "text" : "RT @DiLeed: ---&gt; J'accuse. I am not interested in your pusillanimous platitudes Cameron, Johnson, Farage.  https:\/\/t.co\/99jEPEL2mr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/99jEPEL2mr",
        "expanded_url" : "https:\/\/twitter.com\/mendcommunity\/status\/747832496478367744",
        "display_url" : "twitter.com\/mendcommunity\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747847423360385024",
    "text" : "---&gt; J'accuse. I am not interested in your pusillanimous platitudes Cameron, Johnson, Farage.  https:\/\/t.co\/99jEPEL2mr",
    "id" : 747847423360385024,
    "created_at" : "2016-06-28 17:41:34 +0000",
    "user" : {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "protected" : false,
      "id_str" : "2335217159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531591034740826112\/jFKHAmex_normal.jpeg",
      "id" : 2335217159,
      "verified" : false
    }
  },
  "id" : 747875907055067136,
  "created_at" : "2016-06-28 19:34:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747852088953176064",
  "geo" : { },
  "id_str" : "747855329715695616",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 I think Campbell will be in firing line if Chilcot has any bullets?",
  "id" : 747855329715695616,
  "in_reply_to_status_id" : 747852088953176064,
  "created_at" : "2016-06-28 18:12:59 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747852088953176064",
  "geo" : { },
  "id_str" : "747854944158486529",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 had an interesting discussion with a student who was reading Campbell's autobiography a year or so back",
  "id" : 747854944158486529,
  "in_reply_to_status_id" : 747852088953176064,
  "created_at" : "2016-06-28 18:11:27 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael",
      "screen_name" : "Rachael_Swindon",
      "indices" : [ 3, 19 ],
      "id_str" : "2870848881",
      "id" : 2870848881
    }, {
      "name" : "Steve Topple",
      "screen_name" : "MrTopple",
      "indices" : [ 79, 88 ],
      "id_str" : "59240990",
      "id" : 59240990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LabourCoup",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/pUJeBlFhxo",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/06\/28\/truth-behind-labour-coup-really-began-manufactured-exclusive\/",
      "display_url" : "thecanary.co\/2016\/06\/28\/tru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747854414535360512",
  "text" : "RT @Rachael_Swindon: Corbyn supporter? Seriously, if you've not read this from @MrTopple then now is the time. Astonishing.. #LabourCoup  h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Topple",
        "screen_name" : "MrTopple",
        "indices" : [ 58, 67 ],
        "id_str" : "59240990",
        "id" : 59240990
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LabourCoup",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/pUJeBlFhxo",
        "expanded_url" : "http:\/\/www.thecanary.co\/2016\/06\/28\/truth-behind-labour-coup-really-began-manufactured-exclusive\/",
        "display_url" : "thecanary.co\/2016\/06\/28\/tru\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747848268105785344",
    "text" : "Corbyn supporter? Seriously, if you've not read this from @MrTopple then now is the time. Astonishing.. #LabourCoup  https:\/\/t.co\/pUJeBlFhxo",
    "id" : 747848268105785344,
    "created_at" : "2016-06-28 17:44:56 +0000",
    "user" : {
      "name" : "Rachael",
      "screen_name" : "Rachael_Swindon",
      "protected" : false,
      "id_str" : "2870848881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756232584330301440\/iUql06K0_normal.jpg",
      "id" : 2870848881,
      "verified" : false
    }
  },
  "id" : 747854414535360512,
  "created_at" : "2016-06-28 18:09:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/VSojDifrmr",
      "expanded_url" : "http:\/\/salvage.zone\/online-exclusive\/not-a-coup-but-a-blaze\/",
      "display_url" : "salvage.zone\/online-exclusi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747853202998059008",
  "text" : "RT @leninology: Salvage: Not a Coup but a Blaze - https:\/\/t.co\/VSojDifrmr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/VSojDifrmr",
        "expanded_url" : "http:\/\/salvage.zone\/online-exclusive\/not-a-coup-but-a-blaze\/",
        "display_url" : "salvage.zone\/online-exclusi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747849000292851712",
    "text" : "Salvage: Not a Coup but a Blaze - https:\/\/t.co\/VSojDifrmr",
    "id" : 747849000292851712,
    "created_at" : "2016-06-28 17:47:50 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 747853202998059008,
  "created_at" : "2016-06-28 18:04:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747836041856442368",
  "geo" : { },
  "id_str" : "747851133096431616",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheers Leo \uD83D\uDE03",
  "id" : 747851133096431616,
  "in_reply_to_status_id" : 747836041856442368,
  "created_at" : "2016-06-28 17:56:19 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "indices" : [ 3, 14 ],
      "id_str" : "19364252",
      "id" : 19364252
    }, {
      "name" : "Hayley Waily",
      "screen_name" : "HayleyWaily",
      "indices" : [ 17, 29 ],
      "id_str" : "351483361",
      "id" : 351483361
    }, {
      "name" : "CorbynSupporters50+",
      "screen_name" : "corbyn50plus",
      "indices" : [ 30, 43 ],
      "id_str" : "4483463926",
      "id" : 4483463926
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MarkJDoran\/status\/747849158774652929\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4Fes2YXPmF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDkySfWkAAJkdi.jpg",
      "id_str" : "747849090751434752",
      "id" : 747849090751434752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDkySfWkAAJkdi.jpg",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/4Fes2YXPmF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747851033498554373",
  "text" : "RT @MarkJDoran: .@HayleyWaily @corbyn50plus I think they imagine a *bigger* anti-immigrant mug will work for them next time... https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hayley Waily",
        "screen_name" : "HayleyWaily",
        "indices" : [ 1, 13 ],
        "id_str" : "351483361",
        "id" : 351483361
      }, {
        "name" : "CorbynSupporters50+",
        "screen_name" : "corbyn50plus",
        "indices" : [ 14, 27 ],
        "id_str" : "4483463926",
        "id" : 4483463926
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MarkJDoran\/status\/747849158774652929\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/4Fes2YXPmF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDkySfWkAAJkdi.jpg",
        "id_str" : "747849090751434752",
        "id" : 747849090751434752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDkySfWkAAJkdi.jpg",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/4Fes2YXPmF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "747848435232018433",
    "geo" : { },
    "id_str" : "747849158774652929",
    "in_reply_to_user_id" : 351483361,
    "text" : ".@HayleyWaily @corbyn50plus I think they imagine a *bigger* anti-immigrant mug will work for them next time... https:\/\/t.co\/4Fes2YXPmF",
    "id" : 747849158774652929,
    "in_reply_to_status_id" : 747848435232018433,
    "created_at" : "2016-06-28 17:48:28 +0000",
    "in_reply_to_screen_name" : "HayleyWaily",
    "in_reply_to_user_id_str" : "351483361",
    "user" : {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "protected" : false,
      "id_str" : "19364252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747220190887239680\/1sS-3xVw_normal.jpg",
      "id" : 19364252,
      "verified" : false
    }
  },
  "id" : 747851033498554373,
  "created_at" : "2016-06-28 17:55:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 3, 14 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747834592325931008",
  "text" : "RT @MattCarr55: Blair and Brown lost working class voters: not Corbyn.  Plotters have disgraced themselves no less than the Tories #Corbyn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747827333042692096",
    "text" : "Blair and Brown lost working class voters: not Corbyn.  Plotters have disgraced themselves no less than the Tories #Corbyn",
    "id" : 747827333042692096,
    "created_at" : "2016-06-28 16:21:44 +0000",
    "user" : {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "protected" : false,
      "id_str" : "288409122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708018901335085058\/-SENrQyC_normal.jpg",
      "id" : 288409122,
      "verified" : false
    }
  },
  "id" : 747834592325931008,
  "created_at" : "2016-06-28 16:50:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bertram",
      "screen_name" : "crookedfootball",
      "indices" : [ 0, 16 ],
      "id_str" : "141642937",
      "id" : 141642937
    }, {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 17, 30 ],
      "id_str" : "20932918",
      "id" : 20932918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747817849520001024",
  "geo" : { },
  "id_str" : "747820712220631044",
  "in_reply_to_user_id" : 141642937,
  "text" : "@crookedfootball @blairteacher Chilcot likely contender",
  "id" : 747820712220631044,
  "in_reply_to_status_id" : 747817849520001024,
  "created_at" : "2016-06-28 15:55:26 +0000",
  "in_reply_to_screen_name" : "crookedfootball",
  "in_reply_to_user_id_str" : "141642937",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare  Lavery",
      "screen_name" : "clerotto",
      "indices" : [ 0, 9 ],
      "id_str" : "1445778456",
      "id" : 1445778456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ABfiUXWSFu",
      "expanded_url" : "http:\/\/aworldofenglishes.blogspot.fr\/2016\/06\/english-no-longer-official-eu-language.html?m=1",
      "display_url" : "aworldofenglishes.blogspot.fr\/2016\/06\/englis\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "747772810177699841",
  "geo" : { },
  "id_str" : "747789835885240320",
  "in_reply_to_user_id" : 1445778456,
  "text" : "@clerotto ah right here is another realistic voice on future of eng after brexit https:\/\/t.co\/ABfiUXWSFu",
  "id" : 747789835885240320,
  "in_reply_to_status_id" : 747772810177699841,
  "created_at" : "2016-06-28 13:52:44 +0000",
  "in_reply_to_screen_name" : "clerotto",
  "in_reply_to_user_id_str" : "1445778456",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EPPlenary",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Ix1cupoBeD",
      "expanded_url" : "https:\/\/storify.com\/europarl_en\/ukreferendumdebate",
      "display_url" : "storify.com\/europarl_en\/uk\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/0gtRgtfD0d",
      "expanded_url" : "https:\/\/twitter.com\/padrg\/status\/747730717455572996",
      "display_url" : "twitter.com\/padrg\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747739082369998848",
  "text" : "RT @IgorBrigadir: If you still want to follow UK Referendum #EPPlenary but the site is down, liveblog is here: https:\/\/t.co\/Ix1cupoBeD http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EPPlenary",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/Ix1cupoBeD",
        "expanded_url" : "https:\/\/storify.com\/europarl_en\/ukreferendumdebate",
        "display_url" : "storify.com\/europarl_en\/uk\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0gtRgtfD0d",
        "expanded_url" : "https:\/\/twitter.com\/padrg\/status\/747730717455572996",
        "display_url" : "twitter.com\/padrg\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747733018522030080",
    "text" : "If you still want to follow UK Referendum #EPPlenary but the site is down, liveblog is here: https:\/\/t.co\/Ix1cupoBeD https:\/\/t.co\/0gtRgtfD0d",
    "id" : 747733018522030080,
    "created_at" : "2016-06-28 10:06:58 +0000",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 747739082369998848,
  "created_at" : "2016-06-28 10:31:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 0, 11 ],
      "id_str" : "18880320",
      "id" : 18880320
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 12, 28 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazoninspire",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747723429730787328",
  "geo" : { },
  "id_str" : "747737317989834752",
  "in_reply_to_user_id" : 18880320,
  "text" : "@chucksandy @getgreatenglish u can never think too much about megacorps #amazoninspire teachers to handover data gold :\/",
  "id" : 747737317989834752,
  "in_reply_to_status_id" : 747723429730787328,
  "created_at" : "2016-06-28 10:24:03 +0000",
  "in_reply_to_screen_name" : "chucksandy",
  "in_reply_to_user_id_str" : "18880320",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare  Lavery",
      "screen_name" : "clerotto",
      "indices" : [ 0, 9 ],
      "id_str" : "1445778456",
      "id" : 1445778456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747695895253254146",
  "geo" : { },
  "id_str" : "747703380898873345",
  "in_reply_to_user_id" : 1445778456,
  "text" : "@clerotto is this particular article scaremongering?",
  "id" : 747703380898873345,
  "in_reply_to_status_id" : 747695895253254146,
  "created_at" : "2016-06-28 08:09:12 +0000",
  "in_reply_to_screen_name" : "clerotto",
  "in_reply_to_user_id_str" : "1445778456",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "indices" : [ 3, 19 ],
      "id_str" : "91870534",
      "id" : 91870534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/JcONRPHp0G",
      "expanded_url" : "http:\/\/michaelrosenblog.blogspot.com\/2016\/06\/talk-on-grammar-at-british-library.html?spref=tw",
      "display_url" : "michaelrosenblog.blogspot.com\/2016\/06\/talk-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747698786462490625",
  "text" : "RT @MichaelRosenYes: Michael Rosen: Talk on grammar at British Library 27\/06\/2016 https:\/\/t.co\/JcONRPHp0G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/JcONRPHp0G",
        "expanded_url" : "http:\/\/michaelrosenblog.blogspot.com\/2016\/06\/talk-on-grammar-at-british-library.html?spref=tw",
        "display_url" : "michaelrosenblog.blogspot.com\/2016\/06\/talk-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747671468658561024",
    "text" : "Michael Rosen: Talk on grammar at British Library 27\/06\/2016 https:\/\/t.co\/JcONRPHp0G",
    "id" : 747671468658561024,
    "created_at" : "2016-06-28 06:02:23 +0000",
    "user" : {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "protected" : false,
      "id_str" : "91870534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488029217104207874\/F0pxhrFu_normal.jpeg",
      "id" : 91870534,
      "verified" : false
    }
  },
  "id" : 747698786462490625,
  "created_at" : "2016-06-28 07:50:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence Schimel",
      "screen_name" : "lawrenceschimel",
      "indices" : [ 3, 19 ],
      "id_str" : "22408955",
      "id" : 22408955
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lawrenceschimel\/status\/746991531530293248\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/ydy5VQLp15",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl3Y1KVWEAABKB8.jpg",
      "id_str" : "746991521031917568",
      "id" : 746991521031917568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl3Y1KVWEAABKB8.jpg",
      "sizes" : [ {
        "h" : 184,
        "resize" : "fit",
        "w" : 740
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 740
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 740
      } ],
      "display_url" : "pic.twitter.com\/ydy5VQLp15"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747563508183760901",
  "text" : "RT @lawrenceschimel: XKCD being brilliant as usual. https:\/\/t.co\/ydy5VQLp15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lawrenceschimel\/status\/746991531530293248\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/ydy5VQLp15",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl3Y1KVWEAABKB8.jpg",
        "id_str" : "746991521031917568",
        "id" : 746991521031917568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl3Y1KVWEAABKB8.jpg",
        "sizes" : [ {
          "h" : 184,
          "resize" : "fit",
          "w" : 740
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 740
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 740
        } ],
        "display_url" : "pic.twitter.com\/ydy5VQLp15"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746991531530293248",
    "text" : "XKCD being brilliant as usual. https:\/\/t.co\/ydy5VQLp15",
    "id" : 746991531530293248,
    "created_at" : "2016-06-26 09:00:34 +0000",
    "user" : {
      "name" : "Lawrence Schimel",
      "screen_name" : "lawrenceschimel",
      "protected" : false,
      "id_str" : "22408955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2287764496\/o6zk9foqt0a4je7j6mxc_normal.jpeg",
      "id" : 22408955,
      "verified" : false
    }
  },
  "id" : 747563508183760901,
  "created_at" : "2016-06-27 22:53:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 55, 63 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/5TPBAhPNl5",
      "expanded_url" : "https:\/\/samuelshep.wordpress.com\/2016\/06\/27\/the-inevitable-brexit-post\/",
      "display_url" : "samuelshep.wordpress.com\/2016\/06\/27\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747558739641798657",
  "text" : "The Inevitable Brexit Post https:\/\/t.co\/5TPBAhPNl5 via @samshep",
  "id" : 747558739641798657,
  "created_at" : "2016-06-27 22:34:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uche Jombo Rodriguez",
      "screen_name" : "uchejombo",
      "indices" : [ 3, 13 ],
      "id_str" : "67465811",
      "id" : 67465811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jessewilliams",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/3mJekMGp5I",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/09b024dc-0c8e-45f3-877e-582903d7ff1c",
      "display_url" : "amp.twimg.com\/v\/09b024dc-0c8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747541768606986241",
  "text" : "RT @uchejombo: #jessewilliams\n\nBest speech \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\n\nhttps:\/\/t.co\/3mJekMGp5I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jessewilliams",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/3mJekMGp5I",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/09b024dc-0c8e-45f3-877e-582903d7ff1c",
        "display_url" : "amp.twimg.com\/v\/09b024dc-0c8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747324131285172224",
    "text" : "#jessewilliams\n\nBest speech \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\n\nhttps:\/\/t.co\/3mJekMGp5I",
    "id" : 747324131285172224,
    "created_at" : "2016-06-27 07:02:12 +0000",
    "user" : {
      "name" : "Uche Jombo Rodriguez",
      "screen_name" : "uchejombo",
      "protected" : false,
      "id_str" : "67465811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750166940677734402\/FsAU9VIZ_normal.jpg",
      "id" : 67465811,
      "verified" : true
    }
  },
  "id" : 747541768606986241,
  "created_at" : "2016-06-27 21:27:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 3, 14 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorbynStays",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747541706137026560",
  "text" : "RT @MattCarr55: England lose to Iceland.  I blame Corbyn, don't you? #CorbynStays",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorbynStays",
        "indices" : [ 53, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747540164952621056",
    "text" : "England lose to Iceland.  I blame Corbyn, don't you? #CorbynStays",
    "id" : 747540164952621056,
    "created_at" : "2016-06-27 21:20:38 +0000",
    "user" : {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "protected" : false,
      "id_str" : "288409122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708018901335085058\/-SENrQyC_normal.jpg",
      "id" : 288409122,
      "verified" : false
    }
  },
  "id" : 747541706137026560,
  "created_at" : "2016-06-27 21:26:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Fraser",
      "screen_name" : "MIkef45",
      "indices" : [ 3, 11 ],
      "id_str" : "249634320",
      "id" : 249634320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENGICL",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747537049750765568",
  "text" : "RT @MIkef45: A country which jailed Bankers beat a country that gives them bonuses #ENGICL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ENGICL",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747534723354853376",
    "text" : "A country which jailed Bankers beat a country that gives them bonuses #ENGICL",
    "id" : 747534723354853376,
    "created_at" : "2016-06-27 20:59:01 +0000",
    "user" : {
      "name" : "Mike Fraser",
      "screen_name" : "MIkef45",
      "protected" : false,
      "id_str" : "249634320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631776343953379329\/q9uXAIyx_normal.jpg",
      "id" : 249634320,
      "verified" : false
    }
  },
  "id" : 747537049750765568,
  "created_at" : "2016-06-27 21:08:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Itzkoff",
      "screen_name" : "ditzkoff",
      "indices" : [ 3, 12 ],
      "id_str" : "81482674",
      "id" : 81482674
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ditzkoff\/status\/747534352947486721\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/6z3onrYG1C",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl_GhbeWYAA_MYi.jpg",
      "id_str" : "747534340779827200",
      "id" : 747534340779827200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl_GhbeWYAA_MYi.jpg",
      "sizes" : [ {
        "h" : 126,
        "resize" : "fit",
        "w" : 224
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 224
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 224
      }, {
        "h" : 126,
        "resize" : "crop",
        "w" : 126
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 224
      } ],
      "display_url" : "pic.twitter.com\/6z3onrYG1C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747536446781788160",
  "text" : "RT @ditzkoff: Quick summary of Britain's week so far https:\/\/t.co\/6z3onrYG1C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ditzkoff\/status\/747534352947486721\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/6z3onrYG1C",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl_GhbeWYAA_MYi.jpg",
        "id_str" : "747534340779827200",
        "id" : 747534340779827200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl_GhbeWYAA_MYi.jpg",
        "sizes" : [ {
          "h" : 126,
          "resize" : "fit",
          "w" : 224
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 224
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 224
        }, {
          "h" : 126,
          "resize" : "crop",
          "w" : 126
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 224
        } ],
        "display_url" : "pic.twitter.com\/6z3onrYG1C"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747534352947486721",
    "text" : "Quick summary of Britain's week so far https:\/\/t.co\/6z3onrYG1C",
    "id" : 747534352947486721,
    "created_at" : "2016-06-27 20:57:32 +0000",
    "user" : {
      "name" : "Dave Itzkoff",
      "screen_name" : "ditzkoff",
      "protected" : false,
      "id_str" : "81482674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2157386556\/Picture_2_normal.png",
      "id" : 81482674,
      "verified" : true
    }
  },
  "id" : 747536446781788160,
  "created_at" : "2016-06-27 21:05:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Cochrane",
      "screen_name" : "GlenFCochrane",
      "indices" : [ 72, 86 ],
      "id_str" : "61789211",
      "id" : 61789211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/tTki7VQdfh",
      "expanded_url" : "https:\/\/apointofcontact.net\/2016\/06\/27\/negotiating-word-meanings-what-is-racist\/",
      "display_url" : "apointofcontact.net\/2016\/06\/27\/neg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747535655044014080",
  "text" : "Negotiating Word Meanings - What is Racist? https:\/\/t.co\/tTki7VQdfh via @GlenFCochrane",
  "id" : 747535655044014080,
  "created_at" : "2016-06-27 21:02:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 3, 12 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/TaIQJ3oXzz",
      "expanded_url" : "https:\/\/twitter.com\/king_kaufman\/status\/747533187258023937",
      "display_url" : "twitter.com\/king_kaufman\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747534724726394880",
  "text" : "RT @Marisa_C: A ha ha!!!!  https:\/\/t.co\/TaIQJ3oXzz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/TaIQJ3oXzz",
        "expanded_url" : "https:\/\/twitter.com\/king_kaufman\/status\/747533187258023937",
        "display_url" : "twitter.com\/king_kaufman\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747534221271535616",
    "text" : "A ha ha!!!!  https:\/\/t.co\/TaIQJ3oXzz",
    "id" : 747534221271535616,
    "created_at" : "2016-06-27 20:57:01 +0000",
    "user" : {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "protected" : false,
      "id_str" : "18272500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551128180497457153\/DRrY3cNw_normal.jpeg",
      "id" : 18272500,
      "verified" : false
    }
  },
  "id" : 747534724726394880,
  "created_at" : "2016-06-27 20:59:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Evans",
      "screen_name" : "thingsbehindsun",
      "indices" : [ 0, 16 ],
      "id_str" : "22050679",
      "id" : 22050679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747533260251488257",
  "geo" : { },
  "id_str" : "747533717267189760",
  "in_reply_to_user_id" : 22050679,
  "text" : "@thingsbehindsun maybe considering Daveybloke &amp; co are all laughed out",
  "id" : 747533717267189760,
  "in_reply_to_status_id" : 747533260251488257,
  "created_at" : "2016-06-27 20:55:01 +0000",
  "in_reply_to_screen_name" : "thingsbehindsun",
  "in_reply_to_user_id_str" : "22050679",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Evans",
      "screen_name" : "thingsbehindsun",
      "indices" : [ 0, 16 ],
      "id_str" : "22050679",
      "id" : 22050679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747532512226729984",
  "geo" : { },
  "id_str" : "747532944164651008",
  "in_reply_to_user_id" : 22050679,
  "text" : "@thingsbehindsun wonder what the third laugh will be?",
  "id" : 747532944164651008,
  "in_reply_to_status_id" : 747532512226729984,
  "created_at" : "2016-06-27 20:51:57 +0000",
  "in_reply_to_screen_name" : "thingsbehindsun",
  "in_reply_to_user_id_str" : "22050679",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/747530490102562816\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/0Dznxh8AWw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_C_H_WEAAmUi2.png",
      "id_str" : "747530452899074048",
      "id" : 747530452899074048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_C_H_WEAAmUi2.png",
      "sizes" : [ {
        "h" : 671,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1185,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1387,
        "resize" : "fit",
        "w" : 1405
      }, {
        "h" : 1387,
        "resize" : "fit",
        "w" : 1405
      } ],
      "display_url" : "pic.twitter.com\/0Dznxh8AWw"
    } ],
    "hashtags" : [ {
      "text" : "eltmyths",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747530490102562816",
  "text" : "3 Ways Pearson GSE is sold #eltmyths https:\/\/t.co\/0Dznxh8AWw",
  "id" : 747530490102562816,
  "created_at" : "2016-06-27 20:42:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 0, 11 ],
      "id_str" : "18880320",
      "id" : 18880320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747503604613816320",
  "geo" : { },
  "id_str" : "747504148006977537",
  "in_reply_to_user_id" : 18880320,
  "text" : "@chucksandy haha \uD83D\uDE02",
  "id" : 747504148006977537,
  "in_reply_to_status_id" : 747503604613816320,
  "created_at" : "2016-06-27 18:57:31 +0000",
  "in_reply_to_screen_name" : "chucksandy",
  "in_reply_to_user_id_str" : "18880320",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 0, 11 ],
      "id_str" : "18880320",
      "id" : 18880320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747501143111012353",
  "geo" : { },
  "id_str" : "747503430235754497",
  "in_reply_to_user_id" : 18880320,
  "text" : "@chucksandy there goes all teacher training out window \uD83E\uDD23",
  "id" : 747503430235754497,
  "in_reply_to_status_id" : 747501143111012353,
  "created_at" : "2016-06-27 18:54:40 +0000",
  "in_reply_to_screen_name" : "chucksandy",
  "in_reply_to_user_id_str" : "18880320",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747498411323236352",
  "geo" : { },
  "id_str" : "747499819434938368",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ likewise \uD83D\uDE03",
  "id" : 747499819434938368,
  "in_reply_to_status_id" : 747498411323236352,
  "created_at" : "2016-06-27 18:40:19 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/cgS0scih34",
      "expanded_url" : "https:\/\/twitter.com\/Harryslaststand\/status\/747478415909990400",
      "display_url" : "twitter.com\/Harryslaststan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747496261796925441",
  "text" : "RT @johnwhilley: Wonderful comment. https:\/\/t.co\/cgS0scih34",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/cgS0scih34",
        "expanded_url" : "https:\/\/twitter.com\/Harryslaststand\/status\/747478415909990400",
        "display_url" : "twitter.com\/Harryslaststan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747495170615222272",
    "text" : "Wonderful comment. https:\/\/t.co\/cgS0scih34",
    "id" : 747495170615222272,
    "created_at" : "2016-06-27 18:21:51 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 747496261796925441,
  "created_at" : "2016-06-27 18:26:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Se\u00E1n Duffy",
      "screen_name" : "seantduffy",
      "indices" : [ 3, 14 ],
      "id_str" : "1512974670",
      "id" : 1512974670
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LabourCoup",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BHeyfmvVkT",
      "expanded_url" : "http:\/\/www.union-news.co.uk\/hands-off-jeremy-unions-defend-corbyn-against-labour-coup-attempt\/",
      "display_url" : "union-news.co.uk\/hands-off-jere\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747440812540198916",
  "text" : "RT @seantduffy: All of the major unions back Corbyn in a defiant statement - good luck funding your coup #LabourCoup https:\/\/t.co\/BHeyfmvVkT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LabourCoup",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/BHeyfmvVkT",
        "expanded_url" : "http:\/\/www.union-news.co.uk\/hands-off-jeremy-unions-defend-corbyn-against-labour-coup-attempt\/",
        "display_url" : "union-news.co.uk\/hands-off-jere\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747438066801971201",
    "text" : "All of the major unions back Corbyn in a defiant statement - good luck funding your coup #LabourCoup https:\/\/t.co\/BHeyfmvVkT",
    "id" : 747438066801971201,
    "created_at" : "2016-06-27 14:34:56 +0000",
    "user" : {
      "name" : "Se\u00E1n Duffy",
      "screen_name" : "seantduffy",
      "protected" : false,
      "id_str" : "1512974670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747033909322362880\/QOcAJNID_normal.jpg",
      "id" : 1512974670,
      "verified" : false
    }
  },
  "id" : 747440812540198916,
  "created_at" : "2016-06-27 14:45:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/AE8xDUTg8O",
      "expanded_url" : "http:\/\/go.shr.lc\/29fYUKD",
      "display_url" : "go.shr.lc\/29fYUKD"
    } ]
  },
  "geo" : { },
  "id_str" : "747420525463482368",
  "text" : "RT @leninology: Richard Seymour, 'They Want Their Party Back', Verso - https:\/\/t.co\/AE8xDUTg8O &lt;&lt; my latest on the Labour coup.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/AE8xDUTg8O",
        "expanded_url" : "http:\/\/go.shr.lc\/29fYUKD",
        "display_url" : "go.shr.lc\/29fYUKD"
      } ]
    },
    "geo" : { },
    "id_str" : "747413259452616704",
    "text" : "Richard Seymour, 'They Want Their Party Back', Verso - https:\/\/t.co\/AE8xDUTg8O &lt;&lt; my latest on the Labour coup.",
    "id" : 747413259452616704,
    "created_at" : "2016-06-27 12:56:21 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 747420525463482368,
  "created_at" : "2016-06-27 13:25:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Officer",
      "screen_name" : "Davidofficer",
      "indices" : [ 3, 16 ],
      "id_str" : "20852236",
      "id" : 20852236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747405054542503936",
  "text" : "RT @Davidofficer: Labour MPs: No one knows who you are let alone cares that you've resigned. We're just annoyed you're not holding governme\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747331993801654272",
    "text" : "Labour MPs: No one knows who you are let alone cares that you've resigned. We're just annoyed you're not holding government to account.",
    "id" : 747331993801654272,
    "created_at" : "2016-06-27 07:33:26 +0000",
    "user" : {
      "name" : "David Officer",
      "screen_name" : "Davidofficer",
      "protected" : false,
      "id_str" : "20852236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728621992199524352\/bv0OkF-E_normal.jpg",
      "id" : 20852236,
      "verified" : false
    }
  },
  "id" : 747405054542503936,
  "created_at" : "2016-06-27 12:23:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "indices" : [ 3, 13 ],
      "id_str" : "742333546421846016",
      "id" : 742333546421846016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBLTChat",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/9F6Ra3HBtg",
      "expanded_url" : "https:\/\/tbltchat.wordpress.com\/2016\/06\/27\/tbltchat-2-suggest-a-topic",
      "display_url" : "tbltchat.wordpress.com\/2016\/06\/27\/tbl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747373147498897408",
  "text" : "RT @TBLT_chat: #TBLTChat 2: suggest a\u00A0topic https:\/\/t.co\/9F6Ra3HBtg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TBLTChat",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/9F6Ra3HBtg",
        "expanded_url" : "https:\/\/tbltchat.wordpress.com\/2016\/06\/27\/tbltchat-2-suggest-a-topic",
        "display_url" : "tbltchat.wordpress.com\/2016\/06\/27\/tbl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747250155598929920",
    "text" : "#TBLTChat 2: suggest a\u00A0topic https:\/\/t.co\/9F6Ra3HBtg",
    "id" : 747250155598929920,
    "created_at" : "2016-06-27 02:08:14 +0000",
    "user" : {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "protected" : false,
      "id_str" : "742333546421846016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742335422508896256\/Fh5Df1hw_normal.jpg",
      "id" : 742333546421846016,
      "verified" : false
    }
  },
  "id" : 747373147498897408,
  "created_at" : "2016-06-27 10:16:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 3, 14 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/2dJ0O863v1",
      "expanded_url" : "http:\/\/infernalmachine.co.uk\/taking-our-country-back-brexit-and-the-seeds-of-hate\/",
      "display_url" : "infernalmachine.co.uk\/taking-our-cou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747363084965191680",
  "text" : "RT @MattCarr55: Taking Our Country Back: Brexit and the Seeds of\u00A0Hate https:\/\/t.co\/2dJ0O863v1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/2dJ0O863v1",
        "expanded_url" : "http:\/\/infernalmachine.co.uk\/taking-our-country-back-brexit-and-the-seeds-of-hate\/",
        "display_url" : "infernalmachine.co.uk\/taking-our-cou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747359807410049024",
    "text" : "Taking Our Country Back: Brexit and the Seeds of\u00A0Hate https:\/\/t.co\/2dJ0O863v1",
    "id" : 747359807410049024,
    "created_at" : "2016-06-27 09:23:58 +0000",
    "user" : {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "protected" : false,
      "id_str" : "288409122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708018901335085058\/-SENrQyC_normal.jpg",
      "id" : 288409122,
      "verified" : false
    }
  },
  "id" : 747363084965191680,
  "created_at" : "2016-06-27 09:36:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 56, 69 ],
      "id_str" : "39718253",
      "id" : 39718253
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 70, 85 ],
      "id_str" : "14732889",
      "id" : 14732889
    }, {
      "name" : "CentraleSup\u00E9lec",
      "screen_name" : "centralesupelec",
      "indices" : [ 92, 108 ],
      "id_str" : "140418661",
      "id" : 140418661
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/747356314821607424\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/VknyiUqgCP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl8kXUdWYAAjKG4.jpg",
      "id_str" : "747356046214193152",
      "id" : 747356046214193152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl8kXUdWYAAjKG4.jpg",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/VknyiUqgCP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/G7RgHin7i4",
      "expanded_url" : "http:\/\/bit.ly\/28VkjXI",
      "display_url" : "bit.ly\/28VkjXI"
    } ]
  },
  "geo" : { },
  "id_str" : "747362661562724352",
  "text" : "RT @_divyamadhavan: Speaking on Language and Power with @LukeMeddings @BritishCouncil Paris @centralesupelec https:\/\/t.co\/G7RgHin7i4 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Meddings",
        "screen_name" : "LukeMeddings",
        "indices" : [ 36, 49 ],
        "id_str" : "39718253",
        "id" : 39718253
      }, {
        "name" : "British Council",
        "screen_name" : "BritishCouncil",
        "indices" : [ 50, 65 ],
        "id_str" : "14732889",
        "id" : 14732889
      }, {
        "name" : "CentraleSup\u00E9lec",
        "screen_name" : "centralesupelec",
        "indices" : [ 72, 88 ],
        "id_str" : "140418661",
        "id" : 140418661
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/747356314821607424\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/VknyiUqgCP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl8kXUdWYAAjKG4.jpg",
        "id_str" : "747356046214193152",
        "id" : 747356046214193152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl8kXUdWYAAjKG4.jpg",
        "sizes" : [ {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/VknyiUqgCP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/G7RgHin7i4",
        "expanded_url" : "http:\/\/bit.ly\/28VkjXI",
        "display_url" : "bit.ly\/28VkjXI"
      } ]
    },
    "geo" : { },
    "id_str" : "747356314821607424",
    "text" : "Speaking on Language and Power with @LukeMeddings @BritishCouncil Paris @centralesupelec https:\/\/t.co\/G7RgHin7i4 https:\/\/t.co\/VknyiUqgCP",
    "id" : 747356314821607424,
    "created_at" : "2016-06-27 09:10:05 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 747362661562724352,
  "created_at" : "2016-06-27 09:35:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747195819581968384",
  "geo" : { },
  "id_str" : "747198866831843328",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand ok thx  : )",
  "id" : 747198866831843328,
  "in_reply_to_status_id" : 747195819581968384,
  "created_at" : "2016-06-26 22:44:26 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747188476362260480",
  "geo" : { },
  "id_str" : "747195437162070017",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand did Mark Davies mention accuracy, reliability of the texts classed into genres?",
  "id" : 747195437162070017,
  "in_reply_to_status_id" : 747188476362260480,
  "created_at" : "2016-06-26 22:30:49 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747188476362260480",
  "geo" : { },
  "id_str" : "747191314635198469",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand neato, v cool using CORE to build specialised corpora, thx : )",
  "id" : 747191314635198469,
  "in_reply_to_status_id" : 747188476362260480,
  "created_at" : "2016-06-26 22:14:26 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 3, 16 ],
      "id_str" : "254378772",
      "id" : 254378772
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 18, 27 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccrss16",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/vKR5Q2xPWu",
      "expanded_url" : "http:\/\/tinyurl.com\/jlndsml",
      "display_url" : "tinyurl.com\/jlndsml"
    } ]
  },
  "geo" : { },
  "id_str" : "747190975987068928",
  "text" : "RT @violawiegand: @muranava I've put up my slides and handout on my blog. Can be found in links to this post: https:\/\/t.co\/vKR5Q2xPWu :) #c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccrss16",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/vKR5Q2xPWu",
        "expanded_url" : "http:\/\/tinyurl.com\/jlndsml",
        "display_url" : "tinyurl.com\/jlndsml"
      } ]
    },
    "in_reply_to_status_id_str" : "746108796976664576",
    "geo" : { },
    "id_str" : "747188476362260480",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava I've put up my slides and handout on my blog. Can be found in links to this post: https:\/\/t.co\/vKR5Q2xPWu :) #ccrss16",
    "id" : 747188476362260480,
    "in_reply_to_status_id" : 746108796976664576,
    "created_at" : "2016-06-26 22:03:09 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "protected" : false,
      "id_str" : "254378772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565558040615587840\/dlB5Hv90_normal.jpeg",
      "id" : 254378772,
      "verified" : false
    }
  },
  "id" : 747190975987068928,
  "created_at" : "2016-06-26 22:13:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747098527373852672",
  "geo" : { },
  "id_str" : "747127617741066240",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish we can dream of a citizen of Earth passport : )",
  "id" : 747127617741066240,
  "in_reply_to_status_id" : 747098527373852672,
  "created_at" : "2016-06-26 18:01:19 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747092933279682560",
  "geo" : { },
  "id_str" : "747093766981435392",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga remarkable &amp; so why do they still exist? \uD83E\uDD14",
  "id" : 747093766981435392,
  "in_reply_to_status_id" : 747092933279682560,
  "created_at" : "2016-06-26 15:46:49 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747084645381115904",
  "geo" : { },
  "id_str" : "747089901657665536",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish \uD83D\uDE0B",
  "id" : 747089901657665536,
  "in_reply_to_status_id" : 747084645381115904,
  "created_at" : "2016-06-26 15:31:27 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747078468073054208",
  "geo" : { },
  "id_str" : "747081604368044032",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @getgreatenglish if u r following Euro2016 who r u cheering for more Glenys Fr or Wal? \uD83D\uDE03",
  "id" : 747081604368044032,
  "in_reply_to_status_id" : 747078468073054208,
  "created_at" : "2016-06-26 14:58:29 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747065642205876225",
  "geo" : { },
  "id_str" : "747071308928794625",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish rise of right parties across Europe is grim \u2623",
  "id" : 747071308928794625,
  "in_reply_to_status_id" : 747065642205876225,
  "created_at" : "2016-06-26 14:17:34 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747060429805912064",
  "geo" : { },
  "id_str" : "747065423183622144",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish u ever think about Japanese citizenship?",
  "id" : 747065423183622144,
  "in_reply_to_status_id" : 747060429805912064,
  "created_at" : "2016-06-26 13:54:11 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747060429805912064",
  "geo" : { },
  "id_str" : "747061735635443712",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish non pas encore,  ce serait pratique en tout cas",
  "id" : 747061735635443712,
  "in_reply_to_status_id" : 747060429805912064,
  "created_at" : "2016-06-26 13:39:32 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747052595240407040",
  "text" : "Oh la la",
  "id" : 747052595240407040,
  "created_at" : "2016-06-26 13:03:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/9z6jMA7cnv",
      "expanded_url" : "http:\/\/johnpilger.com\/articles\/why-the-british-said-no-to-europe",
      "display_url" : "johnpilger.com\/articles\/why-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747038247910576128",
  "text" : "Why the British said no to Europe - https:\/\/t.co\/9z6jMA7cnv",
  "id" : 747038247910576128,
  "created_at" : "2016-06-26 12:06:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Spokemon",
      "screen_name" : "BrianSpanner1",
      "indices" : [ 3, 17 ],
      "id_str" : "2371910443",
      "id" : 2371910443
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BrianSpanner1\/status\/746488316510482433\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/160NuQGeXX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClwPHLzWQAA8tNC.jpg",
      "id_str" : "746488254338318336",
      "id" : 746488254338318336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClwPHLzWQAA8tNC.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 633
      } ],
      "display_url" : "pic.twitter.com\/160NuQGeXX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746995527921844224",
  "text" : "RT @BrianSpanner1: Take back control.\n\nNo you take it back.\n\nNo you fucking take it.\n\nYou touched it last. https:\/\/t.co\/160NuQGeXX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BrianSpanner1\/status\/746488316510482433\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/160NuQGeXX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClwPHLzWQAA8tNC.jpg",
        "id_str" : "746488254338318336",
        "id" : 746488254338318336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClwPHLzWQAA8tNC.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 633
        } ],
        "display_url" : "pic.twitter.com\/160NuQGeXX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746488316510482433",
    "text" : "Take back control.\n\nNo you take it back.\n\nNo you fucking take it.\n\nYou touched it last. https:\/\/t.co\/160NuQGeXX",
    "id" : 746488316510482433,
    "created_at" : "2016-06-24 23:40:58 +0000",
    "user" : {
      "name" : "Brian Spokemon",
      "screen_name" : "BrianSpanner1",
      "protected" : false,
      "id_str" : "2371910443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760086424054095873\/F9j9t5j__normal.jpg",
      "id" : 2371910443,
      "verified" : false
    }
  },
  "id" : 746995527921844224,
  "created_at" : "2016-06-26 09:16:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/sBQuuG94yt",
      "expanded_url" : "https:\/\/twitter.com\/CraigMurrayOrg\/status\/746741398003716096",
      "display_url" : "twitter.com\/CraigMurrayOrg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746764176475947008",
  "text" : "RT @medialens: A single heckler shouts at Corbyn and is 'front page news in the Guardian, it is on BBC, ITN and Sky News'. Exactly. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/sBQuuG94yt",
        "expanded_url" : "https:\/\/twitter.com\/CraigMurrayOrg\/status\/746741398003716096",
        "display_url" : "twitter.com\/CraigMurrayOrg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746745552033878017",
    "text" : "A single heckler shouts at Corbyn and is 'front page news in the Guardian, it is on BBC, ITN and Sky News'. Exactly. https:\/\/t.co\/sBQuuG94yt",
    "id" : 746745552033878017,
    "created_at" : "2016-06-25 16:43:08 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 746764176475947008,
  "created_at" : "2016-06-25 17:57:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746761797517123585",
  "text" : "\uD83D\uDE03",
  "id" : 746761797517123585,
  "created_at" : "2016-06-25 17:47:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Andreou",
      "screen_name" : "sturdyAlex",
      "indices" : [ 3, 14 ],
      "id_str" : "42371615",
      "id" : 42371615
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sturdyAlex\/status\/746306103990956032\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/VCaG9pNrFj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CltpcTdWIAAHdfQ.jpg",
      "id_str" : "746306098240561152",
      "id" : 746306098240561152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CltpcTdWIAAHdfQ.jpg",
      "sizes" : [ {
        "h" : 744,
        "resize" : "fit",
        "w" : 1240
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 1240
      } ],
      "display_url" : "pic.twitter.com\/VCaG9pNrFj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746685521494179840",
  "text" : "RT @sturdyAlex: Do you know the moment in The Producers, when they realise that \"Springtime for Hitler\" is actually a hit? That. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sturdyAlex\/status\/746306103990956032\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/VCaG9pNrFj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CltpcTdWIAAHdfQ.jpg",
        "id_str" : "746306098240561152",
        "id" : 746306098240561152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CltpcTdWIAAHdfQ.jpg",
        "sizes" : [ {
          "h" : 744,
          "resize" : "fit",
          "w" : 1240
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1240
        } ],
        "display_url" : "pic.twitter.com\/VCaG9pNrFj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746306103990956032",
    "text" : "Do you know the moment in The Producers, when they realise that \"Springtime for Hitler\" is actually a hit? That. https:\/\/t.co\/VCaG9pNrFj",
    "id" : 746306103990956032,
    "created_at" : "2016-06-24 11:36:55 +0000",
    "user" : {
      "name" : "Alex Andreou",
      "screen_name" : "sturdyAlex",
      "protected" : false,
      "id_str" : "42371615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762367841635041280\/fz8OTZk7_normal.jpg",
      "id" : 42371615,
      "verified" : false
    }
  },
  "id" : 746685521494179840,
  "created_at" : "2016-06-25 12:44:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746501019111043072",
  "geo" : { },
  "id_str" : "746678570395799552",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith my pleasure, listened to beginning liked it \uD83D\uDE03",
  "id" : 746678570395799552,
  "in_reply_to_status_id" : 746501019111043072,
  "created_at" : "2016-06-25 12:16:58 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Back",
      "screen_name" : "AcademicDiary",
      "indices" : [ 3, 17 ],
      "id_str" : "271630221",
      "id" : 271630221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/FeiBvlJfFw",
      "expanded_url" : "http:\/\/www.perc.org.uk\/project_posts\/thoughts-on-the-sociology-of-brexit",
      "display_url" : "perc.org.uk\/project_posts\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746675209885876226",
  "text" : "RT @AcademicDiary: Thoughts on the sociology of Brexit  https:\/\/t.co\/FeiBvlJfFw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/FeiBvlJfFw",
        "expanded_url" : "http:\/\/www.perc.org.uk\/project_posts\/thoughts-on-the-sociology-of-brexit",
        "display_url" : "perc.org.uk\/project_posts\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746403142867238912",
    "text" : "Thoughts on the sociology of Brexit  https:\/\/t.co\/FeiBvlJfFw",
    "id" : 746403142867238912,
    "created_at" : "2016-06-24 18:02:31 +0000",
    "user" : {
      "name" : "Les Back",
      "screen_name" : "AcademicDiary",
      "protected" : false,
      "id_str" : "271630221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2651559596\/4d2275cd17762f26f995dd198c3fc56d_normal.png",
      "id" : 271630221,
      "verified" : false
    }
  },
  "id" : 746675209885876226,
  "created_at" : "2016-06-25 12:03:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 3, 15 ],
      "id_str" : "46382179",
      "id" : 46382179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/akliLknAQS",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=p86BPM1GV8M",
      "display_url" : "m.youtube.com\/watch?v=p86BPM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746481405518045184",
  "text" : "RT @patrickamon: https:\/\/t.co\/akliLknAQS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/akliLknAQS",
        "expanded_url" : "https:\/\/m.youtube.com\/watch?v=p86BPM1GV8M",
        "display_url" : "m.youtube.com\/watch?v=p86BPM\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746479552940081152",
    "text" : "https:\/\/t.co\/akliLknAQS",
    "id" : 746479552940081152,
    "created_at" : "2016-06-24 23:06:08 +0000",
    "user" : {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "protected" : false,
      "id_str" : "46382179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749896637603012609\/VxzFoEDQ_normal.jpg",
      "id" : 46382179,
      "verified" : false
    }
  },
  "id" : 746481405518045184,
  "created_at" : "2016-06-24 23:13:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 3, 14 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Elvis Costello",
      "screen_name" : "ElvisCostello",
      "indices" : [ 69, 83 ],
      "id_str" : "20117923",
      "id" : 20117923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BrodskyQuartet",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/hC6Eeourmf",
      "expanded_url" : "https:\/\/youtu.be\/7ukSBwl739A",
      "display_url" : "youtu.be\/7ukSBwl739A"
    } ]
  },
  "geo" : { },
  "id_str" : "746480474504167424",
  "text" : "RT @lexicoj0hn: My favourite election defeat song, recorded in 1992. @ElvisCostello &amp; #BrodskyQuartet https:\/\/t.co\/hC6Eeourmf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elvis Costello",
        "screen_name" : "ElvisCostello",
        "indices" : [ 53, 67 ],
        "id_str" : "20117923",
        "id" : 20117923
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BrodskyQuartet",
        "indices" : [ 74, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/hC6Eeourmf",
        "expanded_url" : "https:\/\/youtu.be\/7ukSBwl739A",
        "display_url" : "youtu.be\/7ukSBwl739A"
      } ]
    },
    "geo" : { },
    "id_str" : "746479389760700416",
    "text" : "My favourite election defeat song, recorded in 1992. @ElvisCostello &amp; #BrodskyQuartet https:\/\/t.co\/hC6Eeourmf",
    "id" : 746479389760700416,
    "created_at" : "2016-06-24 23:05:30 +0000",
    "user" : {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "protected" : false,
      "id_str" : "4008981801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710135773476032516\/BNqiKR1y_normal.jpg",
      "id" : 4008981801,
      "verified" : false
    }
  },
  "id" : 746480474504167424,
  "created_at" : "2016-06-24 23:09:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pegg",
      "screen_name" : "NicholasPegg",
      "indices" : [ 3, 16 ],
      "id_str" : "112400302",
      "id" : 112400302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746478688846372865",
  "text" : "RT @NicholasPegg: \u2019Twas Brexit, and the slithy Goves\nDid lie and grumble in the Mail,\nAll Menschy were the Boris droves,\nAnd Nigel Farage i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746061996089577472",
    "text" : "\u2019Twas Brexit, and the slithy Goves\nDid lie and grumble in the Mail,\nAll Menschy were the Boris droves,\nAnd Nigel Farage is a fascist.",
    "id" : 746061996089577472,
    "created_at" : "2016-06-23 19:26:55 +0000",
    "user" : {
      "name" : "Nicholas Pegg",
      "screen_name" : "NicholasPegg",
      "protected" : false,
      "id_str" : "112400302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742458627034750977\/QylIdUcW_normal.jpg",
      "id" : 112400302,
      "verified" : false
    }
  },
  "id" : 746478688846372865,
  "created_at" : "2016-06-24 23:02:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "indices" : [ 3, 15 ],
      "id_str" : "18225967",
      "id" : 18225967
    }, {
      "name" : "super furry animals",
      "screen_name" : "superfurry",
      "indices" : [ 94, 105 ],
      "id_str" : "556212490",
      "id" : 556212490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cymru",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/PbyodXiQUF",
      "expanded_url" : "https:\/\/soundcloud.com\/akirathedon\/super-furry-animals-bing-bong-akira-the-don-remix",
      "display_url" : "soundcloud.com\/akirathedon\/su\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746473636148686848",
  "text" : "RT @akirathedon: In celebration of Wales' superheroic display of MAXIMUM PEL DROED, here's my @superfurry BING BONG remix! #cymru\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "super furry animals",
        "screen_name" : "superfurry",
        "indices" : [ 77, 88 ],
        "id_str" : "556212490",
        "id" : 556212490
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cymru",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/PbyodXiQUF",
        "expanded_url" : "https:\/\/soundcloud.com\/akirathedon\/super-furry-animals-bing-bong-akira-the-don-remix",
        "display_url" : "soundcloud.com\/akirathedon\/su\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745026707548082176",
    "text" : "In celebration of Wales' superheroic display of MAXIMUM PEL DROED, here's my @superfurry BING BONG remix! #cymru\nhttps:\/\/t.co\/PbyodXiQUF",
    "id" : 745026707548082176,
    "created_at" : "2016-06-20 22:53:03 +0000",
    "user" : {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "protected" : false,
      "id_str" : "18225967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760238647706722304\/DYwlt1DW_normal.jpg",
      "id" : 18225967,
      "verified" : true
    }
  },
  "id" : 746473636148686848,
  "created_at" : "2016-06-24 22:42:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/NtpqB7OPuO",
      "expanded_url" : "https:\/\/youtu.be\/RRMgX-SfVoU",
      "display_url" : "youtu.be\/RRMgX-SfVoU"
    } ]
  },
  "geo" : { },
  "id_str" : "746468968785903616",
  "text" : "LKJ More Time https:\/\/t.co\/NtpqB7OPuO",
  "id" : 746468968785903616,
  "created_at" : "2016-06-24 22:24:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/8K1QM1VPLw",
      "expanded_url" : "https:\/\/youtu.be\/isMjvRpAckU",
      "display_url" : "youtu.be\/isMjvRpAckU"
    } ]
  },
  "geo" : { },
  "id_str" : "746466540762054656",
  "text" : "Linton Kwesi Johnson - Inglan Is a Bitch https:\/\/t.co\/8K1QM1VPLw via @YouTube",
  "id" : 746466540762054656,
  "created_at" : "2016-06-24 22:14:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/cnVytIKdLy",
      "expanded_url" : "https:\/\/youtu.be\/A-BlbEMzV5k",
      "display_url" : "youtu.be\/A-BlbEMzV5k"
    } ]
  },
  "geo" : { },
  "id_str" : "746465553141874688",
  "text" : "Linton Kwesi Johnson - It Noh Funny https:\/\/t.co\/cnVytIKdLy via @YouTube",
  "id" : 746465553141874688,
  "created_at" : "2016-06-24 22:10:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/CoYLJpE7OJ",
      "expanded_url" : "https:\/\/youtu.be\/2PD41qBDALE",
      "display_url" : "youtu.be\/2PD41qBDALE"
    } ]
  },
  "geo" : { },
  "id_str" : "746464253767487488",
  "text" : "Linton Kwesi Johnson - Fite Dem Back https:\/\/t.co\/CoYLJpE7OJ via @YouTube",
  "id" : 746464253767487488,
  "created_at" : "2016-06-24 22:05:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746463239073054720",
  "text" : "i'm sure it was Putin wot did it no?",
  "id" : 746463239073054720,
  "created_at" : "2016-06-24 22:01:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/746462774713327616\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ePf0n5MEO9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clv37AaWQAEbIaS.jpg",
      "id_str" : "746462756354801665",
      "id" : 746462756354801665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clv37AaWQAEbIaS.jpg",
      "sizes" : [ {
        "h" : 824,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 890,
        "resize" : "fit",
        "w" : 1296
      }, {
        "h" : 890,
        "resize" : "fit",
        "w" : 1296
      } ],
      "display_url" : "pic.twitter.com\/ePf0n5MEO9"
    } ],
    "hashtags" : [ {
      "text" : "comfortconcordancing",
      "indices" : [ 0, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746462774713327616",
  "text" : "#comfortconcordancing https:\/\/t.co\/ePf0n5MEO9",
  "id" : 746462774713327616,
  "created_at" : "2016-06-24 21:59:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746446111561388032",
  "geo" : { },
  "id_str" : "746449820672462848",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor seems nothing gets past that Dalek hive mind : )",
  "id" : 746449820672462848,
  "in_reply_to_status_id" : 746446111561388032,
  "created_at" : "2016-06-24 21:08:00 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sputnik",
      "screen_name" : "SputnikInt",
      "indices" : [ 66, 77 ],
      "id_str" : "34262462",
      "id" : 34262462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/wxYOZyLu80",
      "expanded_url" : "http:\/\/sputniknews.com\/analysis\/20160624\/1041906523\/uk-brexit-eu-referendum.html?utm_source=https%3A%2F%2Ft.co%2FKMB39Lt9af&utm_medium=short_url&utm_content=b7B3&utm_campaign=URL_shortening",
      "display_url" : "sputniknews.com\/analysis\/20160\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746444996908290048",
  "text" : "Britain's Peasants' in Brexit Revolt: https:\/\/t.co\/wxYOZyLu80 via @SputnikInt",
  "id" : 746444996908290048,
  "created_at" : "2016-06-24 20:48:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 3, 14 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/okUsoRRXfu",
      "expanded_url" : "https:\/\/twitter.com\/mashedradish\/status\/746329891369553920",
      "display_url" : "twitter.com\/mashedradish\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746399586097446912",
  "text" : "RT @lexicoj0hn: Ah... that answers the linguistic problem (eg. \"There are two days remaining\/left.\"), if not the political one. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/okUsoRRXfu",
        "expanded_url" : "https:\/\/twitter.com\/mashedradish\/status\/746329891369553920",
        "display_url" : "twitter.com\/mashedradish\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746361368664772608",
    "text" : "Ah... that answers the linguistic problem (eg. \"There are two days remaining\/left.\"), if not the political one. https:\/\/t.co\/okUsoRRXfu",
    "id" : 746361368664772608,
    "created_at" : "2016-06-24 15:16:31 +0000",
    "user" : {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "protected" : false,
      "id_str" : "4008981801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710135773476032516\/BNqiKR1y_normal.jpg",
      "id" : 4008981801,
      "verified" : false
    }
  },
  "id" : 746399586097446912,
  "created_at" : "2016-06-24 17:48:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vanessa beeley",
      "screen_name" : "VanessaBeeley",
      "indices" : [ 61, 75 ],
      "id_str" : "956171191",
      "id" : 956171191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/HvjgI5PUqw",
      "expanded_url" : "https:\/\/thewallwillfall.org\/2016\/06\/24\/who-are-the-syria-white-helmets\/",
      "display_url" : "thewallwillfall.org\/2016\/06\/24\/who\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746398704706392064",
  "text" : "WHO ARE THE SYRIA WHITE HELMETS? https:\/\/t.co\/HvjgI5PUqw via @VanessaBeeley",
  "id" : 746398704706392064,
  "created_at" : "2016-06-24 17:44:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 3, 12 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/teflgeek\/status\/746352664645009408\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Saj5b5ca3s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CluTyJ_UYAAosZn.jpg",
      "id_str" : "746352653144186880",
      "id" : 746352653144186880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CluTyJ_UYAAosZn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/Saj5b5ca3s"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Sgp2iezwij",
      "expanded_url" : "http:\/\/teflgeek.net\/2016\/06\/24\/the-impact-of-brexit-on-elt",
      "display_url" : "teflgeek.net\/2016\/06\/24\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746359797092585472",
  "text" : "RT @teflgeek: The impact of BREXIT on\u00A0ELT https:\/\/t.co\/Sgp2iezwij https:\/\/t.co\/Saj5b5ca3s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/teflgeek\/status\/746352664645009408\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/Saj5b5ca3s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CluTyJ_UYAAosZn.jpg",
        "id_str" : "746352653144186880",
        "id" : 746352653144186880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CluTyJ_UYAAosZn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/Saj5b5ca3s"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/Sgp2iezwij",
        "expanded_url" : "http:\/\/teflgeek.net\/2016\/06\/24\/the-impact-of-brexit-on-elt",
        "display_url" : "teflgeek.net\/2016\/06\/24\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746352664645009408",
    "text" : "The impact of BREXIT on\u00A0ELT https:\/\/t.co\/Sgp2iezwij https:\/\/t.co\/Saj5b5ca3s",
    "id" : 746352664645009408,
    "created_at" : "2016-06-24 14:41:56 +0000",
    "user" : {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "protected" : false,
      "id_str" : "305260555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431754836795613184\/0uiw9Mhs_normal.jpeg",
      "id" : 305260555,
      "verified" : false
    }
  },
  "id" : 746359797092585472,
  "created_at" : "2016-06-24 15:10:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yanis Varoufakis",
      "screen_name" : "yanisvaroufakis",
      "indices" : [ 3, 19 ],
      "id_str" : "124690469",
      "id" : 124690469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DiEM_25",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/BEIPZBhUtx",
      "expanded_url" : "https:\/\/diem25.org\/on-the-results-of-the-uk-referendum\/",
      "display_url" : "diem25.org\/on-the-results\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746301099427176448",
  "text" : "RT @yanisvaroufakis: #DiEM_25 on the Brexit result: It is entirely the fault of the EU establishment's contempt for democracy and reason ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DiEM_25",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/BEIPZBhUtx",
        "expanded_url" : "https:\/\/diem25.org\/on-the-results-of-the-uk-referendum\/",
        "display_url" : "diem25.org\/on-the-results\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746252622982684673",
    "text" : "#DiEM_25 on the Brexit result: It is entirely the fault of the EU establishment's contempt for democracy and reason https:\/\/t.co\/BEIPZBhUtx",
    "id" : 746252622982684673,
    "created_at" : "2016-06-24 08:04:24 +0000",
    "user" : {
      "name" : "Yanis Varoufakis",
      "screen_name" : "yanisvaroufakis",
      "protected" : false,
      "id_str" : "124690469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447489400\/8b2a294e679e0bef245c5573564c1fe6_normal.png",
      "id" : 124690469,
      "verified" : true
    }
  },
  "id" : 746301099427176448,
  "created_at" : "2016-06-24 11:17:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/utFoViduv7",
      "expanded_url" : "http:\/\/bit.ly\/28S2DP7",
      "display_url" : "bit.ly\/28S2DP7"
    } ]
  },
  "geo" : { },
  "id_str" : "746239162345349120",
  "text" : "RT @leninology: EU referendum vote https:\/\/t.co\/utFoViduv7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/utFoViduv7",
        "expanded_url" : "http:\/\/bit.ly\/28S2DP7",
        "display_url" : "bit.ly\/28S2DP7"
      } ]
    },
    "geo" : { },
    "id_str" : "746203390103805954",
    "text" : "EU referendum vote https:\/\/t.co\/utFoViduv7",
    "id" : 746203390103805954,
    "created_at" : "2016-06-24 04:48:46 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 746239162345349120,
  "created_at" : "2016-06-24 07:10:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746137944134553600",
  "geo" : { },
  "id_str" : "746215529715630080",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith no worries, I agree some good discussions had, hope he does more of these",
  "id" : 746215529715630080,
  "in_reply_to_status_id" : 746137944134553600,
  "created_at" : "2016-06-24 05:37:00 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746129081083789312",
  "geo" : { },
  "id_str" : "746129463080001536",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon only strange blip Assange throwaway comment mentioning NLP early on in stream :?",
  "id" : 746129463080001536,
  "in_reply_to_status_id" : 746129081083789312,
  "created_at" : "2016-06-23 23:55:01 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskBrexitClub",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/wO7g8nkvmx",
      "expanded_url" : "http:\/\/brexitclub.eu\/",
      "display_url" : "brexitclub.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "746128036601397249",
  "text" : "Varoufakis on at https:\/\/t.co\/wO7g8nkvmx #AskBrexitClub",
  "id" : 746128036601397249,
  "created_at" : "2016-06-23 23:49:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskBrexitClub",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/wO7g8nkvmx",
      "expanded_url" : "http:\/\/brexitclub.eu\/",
      "display_url" : "brexitclub.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "746127801607127042",
  "text" : "Murray on at https:\/\/t.co\/wO7g8nkvmx #AskBrexitClub",
  "id" : 746127801607127042,
  "created_at" : "2016-06-23 23:48:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746125689716379649",
  "geo" : { },
  "id_str" : "746125956826406912",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon yeah could not find the dad's army gif on twitter : )",
  "id" : 746125956826406912,
  "in_reply_to_status_id" : 746125689716379649,
  "created_at" : "2016-06-23 23:41:05 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746123899201552384",
  "geo" : { },
  "id_str" : "746124802201624577",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon oh thought u were taking mickey out of the current political theatre \uD83C\uDCCF",
  "id" : 746124802201624577,
  "in_reply_to_status_id" : 746123899201552384,
  "created_at" : "2016-06-23 23:36:29 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/746122768274554880\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/UYddL43mbB",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ClrCr9QWIAAyTEE.jpg",
      "id_str" : "746122748716523520",
      "id" : 746122748716523520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ClrCr9QWIAAyTEE.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/UYddL43mbB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746120944675098624",
  "geo" : { },
  "id_str" : "746122768274554880",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon \uD83C\uDF83\uD83E\uDD38\uD83E\uDD3D https:\/\/t.co\/UYddL43mbB",
  "id" : 746122768274554880,
  "in_reply_to_status_id" : 746120944675098624,
  "created_at" : "2016-06-23 23:28:24 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brexit",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/wO7g8nkvmx",
      "expanded_url" : "http:\/\/brexitclub.eu\/",
      "display_url" : "brexitclub.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "746109681064624128",
  "text" : "eek : 0 NLP reference by Assange #brexit https:\/\/t.co\/wO7g8nkvmx",
  "id" : 746109681064624128,
  "created_at" : "2016-06-23 22:36:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brexit",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/wO7g8nkvmx",
      "expanded_url" : "http:\/\/brexitclub.eu\/",
      "display_url" : "brexitclub.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "746109325547016194",
  "text" : "class divide in #brexit vote https:\/\/t.co\/wO7g8nkvmx",
  "id" : 746109325547016194,
  "created_at" : "2016-06-23 22:34:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746106970793517056",
  "geo" : { },
  "id_str" : "746108796976664576",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand ok : )",
  "id" : 746108796976664576,
  "in_reply_to_status_id" : 746106970793517056,
  "created_at" : "2016-06-23 22:32:53 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/wO7g8nkvmx",
      "expanded_url" : "http:\/\/brexitclub.eu\/",
      "display_url" : "brexitclub.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "746108681851371520",
  "text" : "extrawurst hehe : ) https:\/\/t.co\/wO7g8nkvmx",
  "id" : 746108681851371520,
  "created_at" : "2016-06-23 22:32:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/wO7g8nkvmx",
      "expanded_url" : "http:\/\/brexitclub.eu\/",
      "display_url" : "brexitclub.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "746105918610358272",
  "text" : "Assange, Murray, Eno, MIA and more live stream https:\/\/t.co\/wO7g8nkvmx",
  "id" : 746105918610358272,
  "created_at" : "2016-06-23 22:21:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/DTHynyJMxM",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/06\/bring-on-willy-pete.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/06\/bring-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746098991822151681",
  "text" : "RT @pchallinor: New mudgeonry: Bring on the Willy Pete https:\/\/t.co\/DTHynyJMxM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/DTHynyJMxM",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/06\/bring-on-willy-pete.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/06\/bring-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746097974061719552",
    "text" : "New mudgeonry: Bring on the Willy Pete https:\/\/t.co\/DTHynyJMxM",
    "id" : 746097974061719552,
    "created_at" : "2016-06-23 21:49:53 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 746098991822151681,
  "created_at" : "2016-06-23 21:53:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/NDFDXJ19cy",
      "expanded_url" : "https:\/\/twitter.com\/Paul_Driver\/status\/746040735267422208",
      "display_url" : "twitter.com\/Paul_Driver\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746076911835688960",
  "text" : "RT @eilymurphy: authentic and kinetic - lovely stuff! https:\/\/t.co\/NDFDXJ19cy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/NDFDXJ19cy",
        "expanded_url" : "https:\/\/twitter.com\/Paul_Driver\/status\/746040735267422208",
        "display_url" : "twitter.com\/Paul_Driver\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746046544852418560",
    "text" : "authentic and kinetic - lovely stuff! https:\/\/t.co\/NDFDXJ19cy",
    "id" : 746046544852418560,
    "created_at" : "2016-06-23 18:25:31 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 746076911835688960,
  "created_at" : "2016-06-23 20:26:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 0, 12 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746036437112463360",
  "geo" : { },
  "id_str" : "746068435415797764",
  "in_reply_to_user_id" : 126258726,
  "text" : "@John__Field yr welcome lk fwd to next post : )",
  "id" : 746068435415797764,
  "in_reply_to_status_id" : 746036437112463360,
  "created_at" : "2016-06-23 19:52:30 +0000",
  "in_reply_to_screen_name" : "John__Field",
  "in_reply_to_user_id_str" : "126258726",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/KZhIwbpVkt",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2016\/06\/22\/the-left-and-the-eu-why-cling-to-this-reactionary-institution\/",
      "display_url" : "counterpunch.org\/2016\/06\/22\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746005571103563777",
  "text" : "The Left and the EU: Why Cling to This Reactionary Institution? https:\/\/t.co\/KZhIwbpVkt",
  "id" : 746005571103563777,
  "created_at" : "2016-06-23 15:42:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/B3x0rBKSUM",
      "expanded_url" : "https:\/\/goo.gl\/d1CGjZ",
      "display_url" : "goo.gl\/d1CGjZ"
    } ]
  },
  "geo" : { },
  "id_str" : "745999575081705472",
  "text" : "RT @josipa74: #ELT - Training Teachers to be Paupers.\n\n\"All we ever get is gruel.\" https:\/\/t.co\/B3x0rBKSUM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/B3x0rBKSUM",
        "expanded_url" : "https:\/\/goo.gl\/d1CGjZ",
        "display_url" : "goo.gl\/d1CGjZ"
      } ]
    },
    "geo" : { },
    "id_str" : "745997149113036800",
    "text" : "#ELT - Training Teachers to be Paupers.\n\n\"All we ever get is gruel.\" https:\/\/t.co\/B3x0rBKSUM",
    "id" : 745997149113036800,
    "created_at" : "2016-06-23 15:09:14 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 745999575081705472,
  "created_at" : "2016-06-23 15:18:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745998703400464388",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand hi any handouts\/links for your session? Thx",
  "id" : 745998703400464388,
  "created_at" : "2016-06-23 15:15:25 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Python Software",
      "screen_name" : "ThePSF",
      "indices" : [ 14, 21 ],
      "id_str" : "63873759",
      "id" : 63873759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745969024991895552",
  "geo" : { },
  "id_str" : "745998163669049344",
  "in_reply_to_user_id" : 585316486,
  "text" : "@MayoushLoves @ThePSF hi, is there a link to notebook? Thx",
  "id" : 745998163669049344,
  "in_reply_to_status_id" : 745969024991895552,
  "created_at" : "2016-06-23 15:13:16 +0000",
  "in_reply_to_screen_name" : "MayoushWrites",
  "in_reply_to_user_id_str" : "585316486",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "indices" : [ 3, 13 ],
      "id_str" : "742333546421846016",
      "id" : 742333546421846016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Y4iCLMYAgg",
      "expanded_url" : "https:\/\/tbltchat.wordpress.com\/2016\/06\/22\/tbltchat-1-how-do-you-use-task-based-language-teaching\/",
      "display_url" : "tbltchat.wordpress.com\/2016\/06\/22\/tbl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745997483290013696",
  "text" : "RT @TBLT_chat: The 1st #tbltchat is archived. https:\/\/t.co\/Y4iCLMYAgg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tbltchat",
        "indices" : [ 8, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/Y4iCLMYAgg",
        "expanded_url" : "https:\/\/tbltchat.wordpress.com\/2016\/06\/22\/tbltchat-1-how-do-you-use-task-based-language-teaching\/",
        "display_url" : "tbltchat.wordpress.com\/2016\/06\/22\/tbl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745631266452574208",
    "text" : "The 1st #tbltchat is archived. https:\/\/t.co\/Y4iCLMYAgg",
    "id" : 745631266452574208,
    "created_at" : "2016-06-22 14:55:21 +0000",
    "user" : {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "protected" : false,
      "id_str" : "742333546421846016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742335422508896256\/Fh5Df1hw_normal.jpg",
      "id" : 742333546421846016,
      "verified" : false
    }
  },
  "id" : 745997483290013696,
  "created_at" : "2016-06-23 15:10:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 74, 86 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/xJuTxfhutR",
      "expanded_url" : "https:\/\/thelearningprofessor.wordpress.com\/2016\/06\/23\/ignorant-citizens-and-the-european-referendum\/",
      "display_url" : "thelearningprofessor.wordpress.com\/2016\/06\/23\/ign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745994546165714944",
  "text" : "Ignorant citizens and the European referendum https:\/\/t.co\/xJuTxfhutR via @John__Field",
  "id" : 745994546165714944,
  "created_at" : "2016-06-23 14:58:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745629903425437696",
  "geo" : { },
  "id_str" : "745645739456471040",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler lol good luck!",
  "id" : 745645739456471040,
  "in_reply_to_status_id" : 745629903425437696,
  "created_at" : "2016-06-22 15:52:52 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745644157956407296",
  "geo" : { },
  "id_str" : "745644581174251520",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand cheers : )",
  "id" : 745644581174251520,
  "in_reply_to_status_id" : 745644157956407296,
  "created_at" : "2016-06-22 15:48:16 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745642468465586177",
  "geo" : { },
  "id_str" : "745643659454980096",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand be interested in any notes\/handouts from this talk? : )",
  "id" : 745643659454980096,
  "in_reply_to_status_id" : 745642468465586177,
  "created_at" : "2016-06-22 15:44:36 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745580772552114180",
  "geo" : { },
  "id_str" : "745623652104802305",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler is there a cycle path on Mt Fuji? Happy trails \uD83D\uDE03",
  "id" : 745623652104802305,
  "in_reply_to_status_id" : 745580772552114180,
  "created_at" : "2016-06-22 14:25:06 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 0, 15 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 16, 32 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745396101931474945",
  "geo" : { },
  "id_str" : "745565573854158848",
  "in_reply_to_user_id" : 2908069515,
  "text" : "@myles_klynhout @getgreatenglish he can definitely write well which makes for easy reading which is always good",
  "id" : 745565573854158848,
  "in_reply_to_status_id" : 745396101931474945,
  "created_at" : "2016-06-22 10:34:19 +0000",
  "in_reply_to_screen_name" : "myles_klynhout",
  "in_reply_to_user_id_str" : "2908069515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 99, 110 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/qB47o0EwnL",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/22\/playing-by-ear-and-verbing-by-body-parts-using-coca-to-discover-usage\/",
      "display_url" : "corpling4efl.wordpress.com\/2016\/06\/22\/pla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745562218675081216",
  "text" : "Playing by ear and verbing by body parts: Using COCA to discover usage https:\/\/t.co\/qB47o0EwnL via @Za_Maikeru",
  "id" : 745562218675081216,
  "created_at" : "2016-06-22 10:20:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TXVXG3qFCp",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.fr\/",
      "display_url" : "curmudgucation.blogspot.fr"
    } ]
  },
  "in_reply_to_status_id_str" : "745501269414928384",
  "geo" : { },
  "id_str" : "745559754680872960",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski it was by chance thought arose after #tbltchat ; i think competency use in US been criticised e.g. from https:\/\/t.co\/TXVXG3qFCp",
  "id" : 745559754680872960,
  "in_reply_to_status_id" : 745501269414928384,
  "created_at" : "2016-06-22 10:11:12 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Richardson",
      "screen_name" : "johne326",
      "indices" : [ 3, 12 ],
      "id_str" : "62239481",
      "id" : 62239481
    }, {
      "name" : "TheUniofNorthampton",
      "screen_name" : "UniNorthants",
      "indices" : [ 61, 74 ],
      "id_str" : "20668046",
      "id" : 20668046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/rqoIhWeMY8",
      "expanded_url" : "https:\/\/medium.com\/@UniNorthants\/the-extreme-right-myth-of-the-lone-wolf-27146355978c#.nyww39g9x",
      "display_url" : "medium.com\/@UniNorthants\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745546616522702849",
  "text" : "RT @johne326: \u201CThe Extreme Right Myth of the \u2018Lone Wolf\u2019\u201D by @UniNorthants https:\/\/t.co\/rqoIhWeMY8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheUniofNorthampton",
        "screen_name" : "UniNorthants",
        "indices" : [ 47, 60 ],
        "id_str" : "20668046",
        "id" : 20668046
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/rqoIhWeMY8",
        "expanded_url" : "https:\/\/medium.com\/@UniNorthants\/the-extreme-right-myth-of-the-lone-wolf-27146355978c#.nyww39g9x",
        "display_url" : "medium.com\/@UniNorthants\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745529860274036736",
    "text" : "\u201CThe Extreme Right Myth of the \u2018Lone Wolf\u2019\u201D by @UniNorthants https:\/\/t.co\/rqoIhWeMY8",
    "id" : 745529860274036736,
    "created_at" : "2016-06-22 08:12:24 +0000",
    "user" : {
      "name" : "John Richardson",
      "screen_name" : "johne326",
      "protected" : false,
      "id_str" : "62239481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000306563268\/70b459abc819b82e1b855c6fef673742_normal.jpeg",
      "id" : 62239481,
      "verified" : false
    }
  },
  "id" : 745546616522702849,
  "created_at" : "2016-06-22 09:18:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/8gFQaNVwRG",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/06\/not-chilcot-report\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745383910046064640",
  "text" : "RT @pchallinor: Not the Chilcot Report https:\/\/t.co\/8gFQaNVwRG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/8gFQaNVwRG",
        "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/06\/not-chilcot-report\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745382226204860417",
    "text" : "Not the Chilcot Report https:\/\/t.co\/8gFQaNVwRG",
    "id" : 745382226204860417,
    "created_at" : "2016-06-21 22:25:45 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 745383910046064640,
  "created_at" : "2016-06-21 22:32:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 0, 15 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 16, 32 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745275837776281600",
  "geo" : { },
  "id_str" : "745378765098745857",
  "in_reply_to_user_id" : 2908069515,
  "text" : "@myles_klynhout @getgreatenglish  sounds like u have been reading Long recently as have I ; )",
  "id" : 745378765098745857,
  "in_reply_to_status_id" : 745275837776281600,
  "created_at" : "2016-06-21 22:12:00 +0000",
  "in_reply_to_screen_name" : "myles_klynhout",
  "in_reply_to_user_id_str" : "2908069515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745374234562592770",
  "geo" : { },
  "id_str" : "745376621536784385",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski guess it has simlr assumps as synthetic syllabus?= whatis2b taught broken down &amp; whatis2b learnt synthesised by studnts #tbltchat",
  "id" : 745376621536784385,
  "in_reply_to_status_id" : 745374234562592770,
  "created_at" : "2016-06-21 22:03:29 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turtlebiking",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745371157998669824",
  "geo" : { },
  "id_str" : "745371654197391360",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler #turtlebiking sounds sedentary : )",
  "id" : 745371654197391360,
  "in_reply_to_status_id" : 745371157998669824,
  "created_at" : "2016-06-21 21:43:45 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whatonomy",
      "screen_name" : "whatonomy",
      "indices" : [ 3, 13 ],
      "id_str" : "360454490",
      "id" : 360454490
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whatonomy\/status\/745351749293178880\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/eeXaykxdjQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClgFdr5WIAA3W3N.jpg",
      "id_str" : "745351745887412224",
      "id" : 745351745887412224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClgFdr5WIAA3W3N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/eeXaykxdjQ"
    } ],
    "hashtags" : [ {
      "text" : "MichaelBenzine",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/6O01Yrwhtr",
      "expanded_url" : "http:\/\/bit.ly\/28MwDQ3",
      "display_url" : "bit.ly\/28MwDQ3"
    } ]
  },
  "geo" : { },
  "id_str" : "745369993697763328",
  "text" : "RT @whatonomy: Teacher, High Forever \u2013 Episode 8 https:\/\/t.co\/6O01Yrwhtr #MichaelBenzine limbers up for TED https:\/\/t.co\/eeXaykxdjQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/whatonomy\/status\/745351749293178880\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/eeXaykxdjQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClgFdr5WIAA3W3N.jpg",
        "id_str" : "745351745887412224",
        "id" : 745351745887412224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClgFdr5WIAA3W3N.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/eeXaykxdjQ"
      } ],
      "hashtags" : [ {
        "text" : "MichaelBenzine",
        "indices" : [ 58, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/6O01Yrwhtr",
        "expanded_url" : "http:\/\/bit.ly\/28MwDQ3",
        "display_url" : "bit.ly\/28MwDQ3"
      } ]
    },
    "geo" : { },
    "id_str" : "745351749293178880",
    "text" : "Teacher, High Forever \u2013 Episode 8 https:\/\/t.co\/6O01Yrwhtr #MichaelBenzine limbers up for TED https:\/\/t.co\/eeXaykxdjQ",
    "id" : 745351749293178880,
    "created_at" : "2016-06-21 20:24:39 +0000",
    "user" : {
      "name" : "whatonomy",
      "screen_name" : "whatonomy",
      "protected" : false,
      "id_str" : "360454490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762977362392682496\/DvketV0c_normal.jpg",
      "id" : 360454490,
      "verified" : false
    }
  },
  "id" : 745369993697763328,
  "created_at" : "2016-06-21 21:37:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Tatman",
      "screen_name" : "rctatman",
      "indices" : [ 72, 81 ],
      "id_str" : "101609102",
      "id" : 101609102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/P6yyAHXoCy",
      "expanded_url" : "https:\/\/makingnoiseandhearingthings.com\/2016\/06\/21\/what-types-of-emoji-do-people-want-more-of\/",
      "display_url" : "makingnoiseandhearingthings.com\/2016\/06\/21\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745364798133702657",
  "text" : "What types of emoji do people want more of? https:\/\/t.co\/P6yyAHXoCy via @rctatman",
  "id" : 745364798133702657,
  "created_at" : "2016-06-21 21:16:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 3, 14 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EUdebate",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745364612556668928",
  "text" : "RT @lexicoj0hn: Funny that 'There are 48 hours remaining' &amp; 'There are 48 hours left' mean the same. #EUdebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EUdebate",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745361906211426304",
    "text" : "Funny that 'There are 48 hours remaining' &amp; 'There are 48 hours left' mean the same. #EUdebate",
    "id" : 745361906211426304,
    "created_at" : "2016-06-21 21:05:01 +0000",
    "user" : {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "protected" : false,
      "id_str" : "4008981801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710135773476032516\/BNqiKR1y_normal.jpg",
      "id" : 4008981801,
      "verified" : false
    }
  },
  "id" : 745364612556668928,
  "created_at" : "2016-06-21 21:15:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745261552819855361",
  "geo" : { },
  "id_str" : "745265819148484608",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish this tension could be artificial though due to conditioning by ELT publishing industry? #tbltchat",
  "id" : 745265819148484608,
  "in_reply_to_status_id" : 745261552819855361,
  "created_at" : "2016-06-21 14:43:12 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Giulia",
      "screen_name" : "wanderingELT",
      "indices" : [ 17, 30 ],
      "id_str" : "494920237",
      "id" : 494920237
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745260699002118144",
  "geo" : { },
  "id_str" : "745261372502573056",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @wanderingELT i was thinking how many do strong tblt as task focus is often in tension with language focus? #tbltchat",
  "id" : 745261372502573056,
  "in_reply_to_status_id" : 745260699002118144,
  "created_at" : "2016-06-21 14:25:32 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Giulia",
      "screen_name" : "wanderingELT",
      "indices" : [ 17, 30 ],
      "id_str" : "494920237",
      "id" : 494920237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745258465627508739",
  "geo" : { },
  "id_str" : "745259494305837060",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @wanderingELT yes if task ++outcome++ here is \"Got meal u wanted using only L2\"?",
  "id" : 745259494305837060,
  "in_reply_to_status_id" : 745258465627508739,
  "created_at" : "2016-06-21 14:18:04 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Giulia",
      "screen_name" : "wanderingELT",
      "indices" : [ 17, 30 ],
      "id_str" : "494920237",
      "id" : 494920237
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tblt",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "tbltchat",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745254227526619136",
  "geo" : { },
  "id_str" : "745257070904098816",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @wanderingELT in PPP L1 use concern tied to structural syllabus, in strong #tblt should not b a concern? #tbltchat",
  "id" : 745257070904098816,
  "in_reply_to_status_id" : 745254227526619136,
  "created_at" : "2016-06-21 14:08:26 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 71, 80 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/i0nE66Lieo",
      "expanded_url" : "https:\/\/shonawhyte.wordpress.com\/2016\/06\/20\/applied-linguistics-linguistics-applied-linguistique-appliquee\/",
      "display_url" : "shonawhyte.wordpress.com\/2016\/06\/20\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745255067826159616",
  "text" : "Applied linguistics, linguistique appliqu\u00E9 https:\/\/t.co\/i0nE66Lieo via @whyshona",
  "id" : 745255067826159616,
  "created_at" : "2016-06-21 14:00:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giulia",
      "screen_name" : "wanderingELT",
      "indices" : [ 0, 13 ],
      "id_str" : "494920237",
      "id" : 494920237
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 14, 30 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745250794266591232",
  "geo" : { },
  "id_str" : "745253518093783040",
  "in_reply_to_user_id" : 494920237,
  "text" : "@wanderingELT @getgreatenglish if task outcome achieved how much use of L1 is negative?",
  "id" : 745253518093783040,
  "in_reply_to_status_id" : 745250794266591232,
  "created_at" : "2016-06-21 13:54:19 +0000",
  "in_reply_to_screen_name" : "wanderingELT",
  "in_reply_to_user_id_str" : "494920237",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben nazer",
      "screen_name" : "BenCanTeach",
      "indices" : [ 0, 12 ],
      "id_str" : "729405603873951745",
      "id" : 729405603873951745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745007265346895872",
  "geo" : { },
  "id_str" : "745009685149921280",
  "in_reply_to_user_id" : 729405603873951745,
  "text" : "@BenCanTeach thanks : )",
  "id" : 745009685149921280,
  "in_reply_to_status_id" : 745007265346895872,
  "created_at" : "2016-06-20 21:45:25 +0000",
  "in_reply_to_screen_name" : "BenCanTeach",
  "in_reply_to_user_id_str" : "729405603873951745",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke",
      "screen_name" : "itsMrLuke",
      "indices" : [ 0, 10 ],
      "id_str" : "15564680",
      "id" : 15564680
    }, {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 11, 21 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745000335899492352",
  "geo" : { },
  "id_str" : "745009548365283328",
  "in_reply_to_user_id" : 15564680,
  "text" : "@itsMrLuke @JamesTheo future dad dance :0",
  "id" : 745009548365283328,
  "in_reply_to_status_id" : 745000335899492352,
  "created_at" : "2016-06-20 21:44:52 +0000",
  "in_reply_to_screen_name" : "itsMrLuke",
  "in_reply_to_user_id_str" : "15564680",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744989154660978688",
  "text" : ": ) : ) : )",
  "id" : 744989154660978688,
  "created_at" : "2016-06-20 20:23:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744973208919638016",
  "text" : ": ) : )",
  "id" : 744973208919638016,
  "created_at" : "2016-06-20 19:20:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744970915163836416",
  "text" : ": )",
  "id" : 744970915163836416,
  "created_at" : "2016-06-20 19:11:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744914754595094528",
  "geo" : { },
  "id_str" : "744968162312134656",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a guess it's a student paper, still :?",
  "id" : 744968162312134656,
  "in_reply_to_status_id" : 744914754595094528,
  "created_at" : "2016-06-20 19:00:25 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 3, 12 ],
      "id_str" : "130975050",
      "id" : 130975050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/yuO1mKbFPa",
      "expanded_url" : "http:\/\/britishcouncil.adobeconnect.com\/zooming_in_out\/",
      "display_url" : "britishcouncil.adobeconnect.com\/zooming_in_out\/"
    } ]
  },
  "geo" : { },
  "id_str" : "744871356668456960",
  "text" : "RT @bcnpaul1: Join us now for Nick Bilbrough's webinar Zooming in and zooming out, raising awareness of World Refugee Day https:\/\/t.co\/yuO1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/yuO1mKbFPa",
        "expanded_url" : "http:\/\/britishcouncil.adobeconnect.com\/zooming_in_out\/",
        "display_url" : "britishcouncil.adobeconnect.com\/zooming_in_out\/"
      } ]
    },
    "geo" : { },
    "id_str" : "744866613703380993",
    "text" : "Join us now for Nick Bilbrough's webinar Zooming in and zooming out, raising awareness of World Refugee Day https:\/\/t.co\/yuO1mKbFPa",
    "id" : 744866613703380993,
    "created_at" : "2016-06-20 12:16:54 +0000",
    "user" : {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "protected" : false,
      "id_str" : "130975050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537231504334540800\/NqpmAh0J_normal.jpeg",
      "id" : 130975050,
      "verified" : false
    }
  },
  "id" : 744871356668456960,
  "created_at" : "2016-06-20 12:35:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744782446219001857",
  "geo" : { },
  "id_str" : "744868968729612288",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish \uD83E\uDD1E\uD83D\uDCAA \uD83D\uDE00",
  "id" : 744868968729612288,
  "in_reply_to_status_id" : 744782446219001857,
  "created_at" : "2016-06-20 12:26:15 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744577233713528833",
  "geo" : { },
  "id_str" : "744796892668694529",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a curious paper as there does not appear to be any SLA papers in ref section?",
  "id" : 744796892668694529,
  "in_reply_to_status_id" : 744577233713528833,
  "created_at" : "2016-06-20 07:39:51 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744715248582594560",
  "geo" : { },
  "id_str" : "744782009843605504",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hope it went well",
  "id" : 744782009843605504,
  "in_reply_to_status_id" : 744715248582594560,
  "created_at" : "2016-06-20 06:40:43 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "English SE",
      "screen_name" : "StackEnglish",
      "indices" : [ 0, 13 ],
      "id_str" : "235339197",
      "id" : 235339197
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 14, 21 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744650425970851840",
  "geo" : { },
  "id_str" : "744656187380109312",
  "in_reply_to_user_id" : 235339197,
  "text" : "@StackEnglish @DiLeed glowbe gives some interesting examples with 2 onlys e.g. \"it is only open by invitation only\".",
  "id" : 744656187380109312,
  "in_reply_to_status_id" : 744650425970851840,
  "created_at" : "2016-06-19 22:20:44 +0000",
  "in_reply_to_screen_name" : "StackEnglish",
  "in_reply_to_user_id_str" : "235339197",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744636859444125696",
  "geo" : { },
  "id_str" : "744639746379489284",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish yr welcome bud, all ticketyboo here how's there?",
  "id" : 744639746379489284,
  "in_reply_to_status_id" : 744636859444125696,
  "created_at" : "2016-06-19 21:15:24 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Odell",
      "screen_name" : "the_jennitaur",
      "indices" : [ 3, 17 ],
      "id_str" : "145749531",
      "id" : 145749531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eyeo2016",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/VeWyyrvjEg",
      "expanded_url" : "http:\/\/jennyodell.com\/Jenny_Odell_Utopian_Fax_Machines_EYEO_2016.pdf",
      "display_url" : "jennyodell.com\/Jenny_Odell_Ut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744639456301486085",
  "text" : "RT @the_jennitaur: friends from #eyeo2016, a PDF version of my talk, \"utopian fax machines,\" is now up (with links to vids)! https:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eyeo2016",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/VeWyyrvjEg",
        "expanded_url" : "http:\/\/jennyodell.com\/Jenny_Odell_Utopian_Fax_Machines_EYEO_2016.pdf",
        "display_url" : "jennyodell.com\/Jenny_Odell_Ut\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743522003936673792",
    "text" : "friends from #eyeo2016, a PDF version of my talk, \"utopian fax machines,\" is now up (with links to vids)! https:\/\/t.co\/VeWyyrvjEg",
    "id" : 743522003936673792,
    "created_at" : "2016-06-16 19:13:54 +0000",
    "user" : {
      "name" : "Jenny Odell",
      "screen_name" : "the_jennitaur",
      "protected" : false,
      "id_str" : "145749531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729758111762800640\/Ppo9K8o1_normal.jpg",
      "id" : 145749531,
      "verified" : false
    }
  },
  "id" : 744639456301486085,
  "created_at" : "2016-06-19 21:14:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 64, 80 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/qepJjgIO2P",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2016\/06\/19\/task-based-links-and-news-sort-of\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2016\/06\/19\/tas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744629277975584768",
  "text" : "Task Based Links and News (sort of) https:\/\/t.co\/qepJjgIO2P via @getgreatenglish",
  "id" : 744629277975584768,
  "created_at" : "2016-06-19 20:33:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 94, 110 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/XQ7RQAVkRp",
      "expanded_url" : "https:\/\/ljiljanahavran.wordpress.com\/2016\/06\/18\/why-is-doing-tasks-the-best-way-to-learn-some-thoughts-on-tblt\/",
      "display_url" : "ljiljanahavran.wordpress.com\/2016\/06\/18\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744627394259091457",
  "text" : "Why is doing tasks the best way to learn? (some thoughts on TBLT) https:\/\/t.co\/XQ7RQAVkRp via @wordpressdotcom",
  "id" : 744627394259091457,
  "created_at" : "2016-06-19 20:26:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/744625998319222785\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/14Mn93DKpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClVxZXRWYAEc28Y.jpg",
      "id_str" : "744625993957138433",
      "id" : 744625993957138433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClVxZXRWYAEc28Y.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/14Mn93DKpf"
    } ],
    "hashtags" : [ {
      "text" : "eltmyths",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744625998319222785",
  "text" : "The Son of (CEFR) Frankenstein re-animated #eltmyths https:\/\/t.co\/14Mn93DKpf",
  "id" : 744625998319222785,
  "created_at" : "2016-06-19 20:20:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744448443842707456",
  "geo" : { },
  "id_str" : "744495799564894212",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco no worries : )",
  "id" : 744495799564894212,
  "in_reply_to_status_id" : 744448443842707456,
  "created_at" : "2016-06-19 11:43:25 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "People's Assembly",
      "screen_name" : "pplsassembly",
      "indices" : [ 3, 16 ],
      "id_str" : "1247478108",
      "id" : 1247478108
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pplsassembly\/status\/744236278909145088\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Z3OJ3GEyoj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQO8UKWAAADurI.jpg",
      "id_str" : "744236267790008320",
      "id" : 744236267790008320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQO8UKWAAADurI.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Z3OJ3GEyoj"
    } ],
    "hashtags" : [ {
      "text" : "FrenchEmbassy",
      "indices" : [ 64, 78 ]
    }, {
      "text" : "ConvoytoCalais",
      "indices" : [ 79, 94 ]
    }, {
      "text" : "J18C2C",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744495270881300480",
  "text" : "RT @pplsassembly: If we can't deliver Aid to Calais. You do it! #FrenchEmbassy #ConvoytoCalais #J18C2C https:\/\/t.co\/Z3OJ3GEyoj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pplsassembly\/status\/744236278909145088\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/Z3OJ3GEyoj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQO8UKWAAADurI.jpg",
        "id_str" : "744236267790008320",
        "id" : 744236267790008320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQO8UKWAAADurI.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Z3OJ3GEyoj"
      } ],
      "hashtags" : [ {
        "text" : "FrenchEmbassy",
        "indices" : [ 46, 60 ]
      }, {
        "text" : "ConvoytoCalais",
        "indices" : [ 61, 76 ]
      }, {
        "text" : "J18C2C",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744236278909145088",
    "text" : "If we can't deliver Aid to Calais. You do it! #FrenchEmbassy #ConvoytoCalais #J18C2C https:\/\/t.co\/Z3OJ3GEyoj",
    "id" : 744236278909145088,
    "created_at" : "2016-06-18 18:32:10 +0000",
    "user" : {
      "name" : "People's Assembly",
      "screen_name" : "pplsassembly",
      "protected" : false,
      "id_str" : "1247478108",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481531514044157952\/e8zlQs30_normal.jpeg",
      "id" : 1247478108,
      "verified" : false
    }
  },
  "id" : 744495270881300480,
  "created_at" : "2016-06-19 11:41:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene V Glass",
      "screen_name" : "GeneVGlass",
      "indices" : [ 3, 14 ],
      "id_str" : "2396466391",
      "id" : 2396466391
    }, {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 16, 26 ],
      "id_str" : "50393960",
      "id" : 50393960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/II1OG8rUYB",
      "expanded_url" : "http:\/\/ed2worlds.blogspot.com\/2016\/06\/why-bill-gates-wont-be-raising-chickens.html",
      "display_url" : "ed2worlds.blogspot.com\/2016\/06\/why-bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744491687360204804",
  "text" : "RT @GeneVGlass: @BillGates said it's your fault if you die poor &amp; tells the poor to raise chickens. He wants to educate your child. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Gates",
        "screen_name" : "BillGates",
        "indices" : [ 0, 10 ],
        "id_str" : "50393960",
        "id" : 50393960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/II1OG8rUYB",
        "expanded_url" : "http:\/\/ed2worlds.blogspot.com\/2016\/06\/why-bill-gates-wont-be-raising-chickens.html",
        "display_url" : "ed2worlds.blogspot.com\/2016\/06\/why-bi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744288530805862401",
    "in_reply_to_user_id" : 50393960,
    "text" : "@BillGates said it's your fault if you die poor &amp; tells the poor to raise chickens. He wants to educate your child. https:\/\/t.co\/II1OG8rUYB",
    "id" : 744288530805862401,
    "created_at" : "2016-06-18 21:59:48 +0000",
    "in_reply_to_screen_name" : "BillGates",
    "in_reply_to_user_id_str" : "50393960",
    "user" : {
      "name" : "Gene V Glass",
      "screen_name" : "GeneVGlass",
      "protected" : false,
      "id_str" : "2396466391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445958856909135872\/7OM8vSMn_normal.jpeg",
      "id" : 2396466391,
      "verified" : false
    }
  },
  "id" : 744491687360204804,
  "created_at" : "2016-06-19 11:27:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 52, 62 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/PcBKLi4f8t",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/06\/18\/sickness-health-death\/",
      "display_url" : "samkriss.wordpress.com\/2016\/06\/18\/sic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744231498841210880",
  "text" : "Sickness, health, death https:\/\/t.co\/PcBKLi4f8t via @sam_kriss",
  "id" : 744231498841210880,
  "created_at" : "2016-06-18 18:13:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "indices" : [ 0, 10 ],
      "id_str" : "742333546421846016",
      "id" : 742333546421846016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744165052706521088",
  "geo" : { },
  "id_str" : "744178766725906432",
  "in_reply_to_user_id" : 742333546421846016,
  "text" : "@TBLT_chat lookn fwd to it bud : )",
  "id" : 744178766725906432,
  "in_reply_to_status_id" : 744165052706521088,
  "created_at" : "2016-06-18 14:43:38 +0000",
  "in_reply_to_screen_name" : "TBLT_chat",
  "in_reply_to_user_id_str" : "742333546421846016",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "indices" : [ 3, 13 ],
      "id_str" : "742333546421846016",
      "id" : 742333546421846016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBLTchat",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Lcr7sup5g9",
      "expanded_url" : "http:\/\/wp.me\/p7DrqZ-7",
      "display_url" : "wp.me\/p7DrqZ-7"
    } ]
  },
  "geo" : { },
  "id_str" : "744159808190816257",
  "text" : "RT @TBLT_chat: Vote for the 1st #TBLTchat on 21st June. What's the topic?https:\/\/t.co\/Lcr7sup5g9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TBLTchat",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Lcr7sup5g9",
        "expanded_url" : "http:\/\/wp.me\/p7DrqZ-7",
        "display_url" : "wp.me\/p7DrqZ-7"
      } ]
    },
    "geo" : { },
    "id_str" : "743707299403829253",
    "text" : "Vote for the 1st #TBLTchat on 21st June. What's the topic?https:\/\/t.co\/Lcr7sup5g9",
    "id" : 743707299403829253,
    "created_at" : "2016-06-17 07:30:12 +0000",
    "user" : {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "protected" : false,
      "id_str" : "742333546421846016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742335422508896256\/Fh5Df1hw_normal.jpg",
      "id" : 742333546421846016,
      "verified" : false
    }
  },
  "id" : 744159808190816257,
  "created_at" : "2016-06-18 13:28:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/744156856856248320\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/UJstvR6LZO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClPGt6uXIAAEEyH.jpg",
      "id_str" : "744156855606386688",
      "id" : 744156855606386688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClPGt6uXIAAEEyH.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/UJstvR6LZO"
    } ],
    "hashtags" : [ {
      "text" : "eltmyths",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744156856856248320",
  "text" : "Global Scales new #eltmyths https:\/\/t.co\/UJstvR6LZO",
  "id" : 744156856856248320,
  "created_at" : "2016-06-18 13:16:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 12, 28 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 29, 40 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 41, 52 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/h63z6IaNDx",
      "expanded_url" : "https:\/\/www.academia.edu\/5963167\/English_in_the_Linguistic_Landscape_of_Japan_Corpus_Studies_for_Language_Education",
      "display_url" : "academia.edu\/5963167\/Englis\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "743944808889192450",
  "geo" : { },
  "id_str" : "743948185446584320",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @MichaelChesnut2 @lexicoj0hn @leoselivan this paper seems to have some advice https:\/\/t.co\/h63z6IaNDx",
  "id" : 743948185446584320,
  "in_reply_to_status_id" : 743944808889192450,
  "created_at" : "2016-06-17 23:27:23 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Slagoski",
      "screen_name" : "jdslagoski",
      "indices" : [ 0, 11 ],
      "id_str" : "22298696",
      "id" : 22298696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743933405708976129",
  "geo" : { },
  "id_str" : "743943347925061632",
  "in_reply_to_user_id" : 22298696,
  "text" : "@jdslagoski great cheers : )",
  "id" : 743943347925061632,
  "in_reply_to_status_id" : 743933405708976129,
  "created_at" : "2016-06-17 23:08:10 +0000",
  "in_reply_to_screen_name" : "jdslagoski",
  "in_reply_to_user_id_str" : "22298696",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 3, 14 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Editors of SpecGram",
      "screen_name" : "SpecGram",
      "indices" : [ 18, 27 ],
      "id_str" : "85925681",
      "id" : 85925681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BHS",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743942929434165249",
  "text" : "RT @lexicoj0hn: . @SpecGram Firthian business ethics: know a company by the word it keeps. Are you listening #BHS ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Editors of SpecGram",
        "screen_name" : "SpecGram",
        "indices" : [ 2, 11 ],
        "id_str" : "85925681",
        "id" : 85925681
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BHS",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "743836262944092160",
    "geo" : { },
    "id_str" : "743937865688702977",
    "in_reply_to_user_id" : 85925681,
    "text" : ". @SpecGram Firthian business ethics: know a company by the word it keeps. Are you listening #BHS ?",
    "id" : 743937865688702977,
    "in_reply_to_status_id" : 743836262944092160,
    "created_at" : "2016-06-17 22:46:23 +0000",
    "in_reply_to_screen_name" : "SpecGram",
    "in_reply_to_user_id_str" : "85925681",
    "user" : {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "protected" : false,
      "id_str" : "4008981801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710135773476032516\/BNqiKR1y_normal.jpg",
      "id" : 4008981801,
      "verified" : false
    }
  },
  "id" : 743942929434165249,
  "created_at" : "2016-06-17 23:06:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 54, 70 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/V9E063nyzM",
      "expanded_url" : "https:\/\/wronghands1.com\/2016\/06\/17\/rock-n-roll-weather-map\/",
      "display_url" : "wronghands1.com\/2016\/06\/17\/roc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743833925156478976",
  "text" : "rock \u2018n\u2019 roll weather map https:\/\/t.co\/V9E063nyzM via @wordpressdotcom",
  "id" : 743833925156478976,
  "created_at" : "2016-06-17 15:53:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Slagoski",
      "screen_name" : "jdslagoski",
      "indices" : [ 0, 11 ],
      "id_str" : "22298696",
      "id" : 22298696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743822610165800962",
  "geo" : { },
  "id_str" : "743833331796688896",
  "in_reply_to_user_id" : 22298696,
  "text" : "@jdslagoski nice post, any chance u cld send me Cho et al (2016) as well as link to EEWL as it doesn't seem to come with paper? thx!",
  "id" : 743833331796688896,
  "in_reply_to_status_id" : 743822610165800962,
  "created_at" : "2016-06-17 15:51:00 +0000",
  "in_reply_to_screen_name" : "jdslagoski",
  "in_reply_to_user_id_str" : "22298696",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Slagoski",
      "screen_name" : "jdslagoski",
      "indices" : [ 3, 14 ],
      "id_str" : "22298696",
      "id" : 22298696
    }, {
      "name" : "CESL at SIUC",
      "screen_name" : "CESL_SIUC",
      "indices" : [ 87, 97 ],
      "id_str" : "389615750",
      "id" : 389615750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "engineering",
      "indices" : [ 65, 77 ]
    }, {
      "text" : "curriculum",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/CtFHBHDblu",
      "expanded_url" : "http:\/\/jesl1.blogspot.com\/2016\/06\/designing-english-language-program-for.html",
      "display_url" : "jesl1.blogspot.com\/2016\/06\/design\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743823806683320321",
  "text" : "RT @jdslagoski: I'm designing an academic bridge #ESL course for #engineering students @CESL_SIUC Here's how I start: https:\/\/t.co\/CtFHBHDb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CESL at SIUC",
        "screen_name" : "CESL_SIUC",
        "indices" : [ 71, 81 ],
        "id_str" : "389615750",
        "id" : 389615750
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 33, 37 ]
      }, {
        "text" : "engineering",
        "indices" : [ 49, 61 ]
      }, {
        "text" : "curriculum",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/CtFHBHDblu",
        "expanded_url" : "http:\/\/jesl1.blogspot.com\/2016\/06\/designing-english-language-program-for.html",
        "display_url" : "jesl1.blogspot.com\/2016\/06\/design\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743822610165800962",
    "text" : "I'm designing an academic bridge #ESL course for #engineering students @CESL_SIUC Here's how I start: https:\/\/t.co\/CtFHBHDblu #curriculum",
    "id" : 743822610165800962,
    "created_at" : "2016-06-17 15:08:24 +0000",
    "user" : {
      "name" : "Jeremy Slagoski",
      "screen_name" : "jdslagoski",
      "protected" : false,
      "id_str" : "22298696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684183931646693376\/PQyDitmm_normal.jpg",
      "id" : 22298696,
      "verified" : false
    }
  },
  "id" : 743823806683320321,
  "created_at" : "2016-06-17 15:13:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saeval",
      "screen_name" : "IamSaeval",
      "indices" : [ 3, 13 ],
      "id_str" : "186416569",
      "id" : 186416569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/IyWZXGLagv",
      "expanded_url" : "http:\/\/iamsaeval.com\/2016\/04\/24\/keep-calm-and-demand-trial-by-combat\/",
      "display_url" : "iamsaeval.com\/2016\/04\/24\/kee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743822711219171328",
  "text" : "RT @IamSaeval: Demand Trial by Combat. https:\/\/t.co\/IyWZXGLagv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/IyWZXGLagv",
        "expanded_url" : "http:\/\/iamsaeval.com\/2016\/04\/24\/keep-calm-and-demand-trial-by-combat\/",
        "display_url" : "iamsaeval.com\/2016\/04\/24\/kee\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743821777495699456",
    "text" : "Demand Trial by Combat. https:\/\/t.co\/IyWZXGLagv",
    "id" : 743821777495699456,
    "created_at" : "2016-06-17 15:05:05 +0000",
    "user" : {
      "name" : "Saeval",
      "screen_name" : "IamSaeval",
      "protected" : false,
      "id_str" : "186416569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683675133874061313\/yLq1VLwA_normal.jpg",
      "id" : 186416569,
      "verified" : false
    }
  },
  "id" : 743822711219171328,
  "created_at" : "2016-06-17 15:08:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/GG8Gkr2yG1",
      "expanded_url" : "http:\/\/www.languagejones.com\/blog-1\/2016\/6\/15\/a-primer-on-imagined-black-english",
      "display_url" : "languagejones.com\/blog-1\/2016\/6\/\u2026"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/szKfuoIIYh",
      "expanded_url" : "http:\/\/www.londonlanguagelab.com\/word-of-the-day-banya\/",
      "display_url" : "londonlanguagelab.com\/word-of-the-da\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Q7aWlKYkm3",
      "expanded_url" : "http:\/\/www.macmillandictionaries.com\/MED-Magazine\/July2004\/21-FalseFriends-Russian.htm",
      "display_url" : "macmillandictionaries.com\/MED-Magazine\/J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743757477397704704",
  "text" : "a triple blog score on borrowings, loadwords &amp; appropriations: https:\/\/t.co\/GG8Gkr2yG1, https:\/\/t.co\/szKfuoIIYh, https:\/\/t.co\/Q7aWlKYkm3",
  "id" : 743757477397704704,
  "created_at" : "2016-06-17 10:49:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 12, 23 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 24, 35 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 44, 60 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743749128622989313",
  "geo" : { },
  "id_str" : "743750034965966848",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @lexicoj0hn @leoselivan i think @MichaelChesnut2 may have some pointers?",
  "id" : 743750034965966848,
  "in_reply_to_status_id" : 743749128622989313,
  "created_at" : "2016-06-17 10:20:01 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743749641745793025",
  "geo" : { },
  "id_str" : "743749764706013184",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco : )",
  "id" : 743749764706013184,
  "in_reply_to_status_id" : 743749641745793025,
  "created_at" : "2016-06-17 10:18:56 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/yhNEmTa5xV",
      "expanded_url" : "https:\/\/twitter.com\/CraigMurrayOrg\/status\/743588927806836736",
      "display_url" : "twitter.com\/CraigMurrayOrg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743747809556336640",
  "text" : "RT @medialens: 'Terrorism has not officially been redefined as a crime of violence committed by a Muslim, but it might as well be.' https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/yhNEmTa5xV",
        "expanded_url" : "https:\/\/twitter.com\/CraigMurrayOrg\/status\/743588927806836736",
        "display_url" : "twitter.com\/CraigMurrayOrg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743705045972115457",
    "text" : "'Terrorism has not officially been redefined as a crime of violence committed by a Muslim, but it might as well be.' https:\/\/t.co\/yhNEmTa5xV",
    "id" : 743705045972115457,
    "created_at" : "2016-06-17 07:21:14 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 743747809556336640,
  "created_at" : "2016-06-17 10:11:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeni Parsons",
      "screen_name" : "havantacluOTMP",
      "indices" : [ 3, 18 ],
      "id_str" : "406564080",
      "id" : 406564080
    }, {
      "name" : "Media Diversified",
      "screen_name" : "WritersofColour",
      "indices" : [ 107, 123 ],
      "id_str" : "1561448815",
      "id" : 1561448815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8s7iC4CnoD",
      "expanded_url" : "https:\/\/mediadiversified.org\/2016\/06\/17\/britain-has-confused-social-sociopathy-for-economic-debate\/",
      "display_url" : "mediadiversified.org\/2016\/06\/17\/bri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743742047601856512",
  "text" : "RT @havantacluOTMP: Britain has confused social sociopathy for economic debate https:\/\/t.co\/8s7iC4CnoD via @WritersofColour",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Diversified",
        "screen_name" : "WritersofColour",
        "indices" : [ 87, 103 ],
        "id_str" : "1561448815",
        "id" : 1561448815
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/8s7iC4CnoD",
        "expanded_url" : "https:\/\/mediadiversified.org\/2016\/06\/17\/britain-has-confused-social-sociopathy-for-economic-debate\/",
        "display_url" : "mediadiversified.org\/2016\/06\/17\/bri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743737662532530176",
    "text" : "Britain has confused social sociopathy for economic debate https:\/\/t.co\/8s7iC4CnoD via @WritersofColour",
    "id" : 743737662532530176,
    "created_at" : "2016-06-17 09:30:51 +0000",
    "user" : {
      "name" : "Jeni Parsons",
      "screen_name" : "havantacluOTMP",
      "protected" : false,
      "id_str" : "406564080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1862071846\/ec01b1b6-651c-4f50-bc59-ee994ec6cd50_normal.png",
      "id" : 406564080,
      "verified" : false
    }
  },
  "id" : 743742047601856512,
  "created_at" : "2016-06-17 09:48:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/etAAFP8Iiz",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=jp.ne.sakura.ccice.audipo",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743739144711462913",
  "text" : "if your students are looking for an audio speed changer I wld recommend Audipo available for Android &amp; iOS https:\/\/t.co\/etAAFP8Iiz",
  "id" : 743739144711462913,
  "created_at" : "2016-06-17 09:36:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "indices" : [ 0, 13 ],
      "id_str" : "141530833",
      "id" : 141530833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/Y50sL0OAr3",
      "expanded_url" : "https:\/\/twitter.com\/amicalnet\/status\/743721481251627010",
      "display_url" : "twitter.com\/amicalnet\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743735273066893312",
  "in_reply_to_user_id" : 141530833,
  "text" : "@iatefl_ltsig debate https:\/\/t.co\/Y50sL0OAr3",
  "id" : 743735273066893312,
  "created_at" : "2016-06-17 09:21:21 +0000",
  "in_reply_to_screen_name" : "iatefl_ltsig",
  "in_reply_to_user_id_str" : "141530833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdFlower",
      "screen_name" : "CrowdFlower",
      "indices" : [ 0, 12 ],
      "id_str" : "28165790",
      "id" : 28165790
    }, {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 13, 26 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743509728702005249",
  "geo" : { },
  "id_str" : "743579660089442304",
  "in_reply_to_user_id" : 28165790,
  "text" : "@CrowdFlower @TSchnoebelen just read about letter frequency laid out typesetters inspiration for SHRDLU coolbeans \uD83D\uDE03",
  "id" : 743579660089442304,
  "in_reply_to_status_id" : 743509728702005249,
  "created_at" : "2016-06-16 23:03:00 +0000",
  "in_reply_to_screen_name" : "CrowdFlower",
  "in_reply_to_user_id_str" : "28165790",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdFlower",
      "screen_name" : "CrowdFlower",
      "indices" : [ 3, 15 ],
      "id_str" : "28165790",
      "id" : 28165790
    }, {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 64, 77 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataScientists",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/Ll0rtEzesb",
      "expanded_url" : "https:\/\/www.crowdflower.com\/an-ai-springtime\/",
      "display_url" : "crowdflower.com\/an-ai-springti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743577504091373568",
  "text" : "RT @CrowdFlower: An AI Springtime | CrowdFlower | Blogpost | By @TSchnoebelen | Must read for #DataScientists | Enjoy https:\/\/t.co\/Ll0rtEze\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyler Schnoebelen",
        "screen_name" : "TSchnoebelen",
        "indices" : [ 47, 60 ],
        "id_str" : "14969147",
        "id" : 14969147
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DataScientists",
        "indices" : [ 77, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/Ll0rtEzesb",
        "expanded_url" : "https:\/\/www.crowdflower.com\/an-ai-springtime\/",
        "display_url" : "crowdflower.com\/an-ai-springti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743509728702005249",
    "text" : "An AI Springtime | CrowdFlower | Blogpost | By @TSchnoebelen | Must read for #DataScientists | Enjoy https:\/\/t.co\/Ll0rtEzesb",
    "id" : 743509728702005249,
    "created_at" : "2016-06-16 18:25:07 +0000",
    "user" : {
      "name" : "CrowdFlower",
      "screen_name" : "CrowdFlower",
      "protected" : false,
      "id_str" : "28165790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654078978395803648\/DG3h3Z7M_normal.png",
      "id" : 28165790,
      "verified" : false
    }
  },
  "id" : 743577504091373568,
  "created_at" : "2016-06-16 22:54:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "indices" : [ 48, 55 ],
      "id_str" : "2937071",
      "id" : 2937071
    }, {
      "name" : "Ward Cunningham",
      "screen_name" : "WardCunningham",
      "indices" : [ 56, 71 ],
      "id_str" : "12381352",
      "id" : 12381352
    }, {
      "name" : "(((Dr. Dean)))",
      "screen_name" : "dr_jdean",
      "indices" : [ 72, 81 ],
      "id_str" : "739521654",
      "id" : 739521654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Z1fa4RpRxm",
      "expanded_url" : "https:\/\/hapgood.us\/2016\/06\/16\/is-the-web-as-a-tool-for-thought-a-gating-item\/",
      "display_url" : "hapgood.us\/2016\/06\/16\/is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743553100372410368",
  "text" : "RT @holden: Interested in your thoughts on this @judell @WardCunningham @dr_jdean https:\/\/t.co\/Z1fa4RpRxm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Udell",
        "screen_name" : "judell",
        "indices" : [ 36, 43 ],
        "id_str" : "2937071",
        "id" : 2937071
      }, {
        "name" : "Ward Cunningham",
        "screen_name" : "WardCunningham",
        "indices" : [ 44, 59 ],
        "id_str" : "12381352",
        "id" : 12381352
      }, {
        "name" : "(((Dr. Dean)))",
        "screen_name" : "dr_jdean",
        "indices" : [ 60, 69 ],
        "id_str" : "739521654",
        "id" : 739521654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/Z1fa4RpRxm",
        "expanded_url" : "https:\/\/hapgood.us\/2016\/06\/16\/is-the-web-as-a-tool-for-thought-a-gating-item\/",
        "display_url" : "hapgood.us\/2016\/06\/16\/is-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743547698138120192",
    "text" : "Interested in your thoughts on this @judell @WardCunningham @dr_jdean https:\/\/t.co\/Z1fa4RpRxm",
    "id" : 743547698138120192,
    "created_at" : "2016-06-16 20:56:00 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 743553100372410368,
  "created_at" : "2016-06-16 21:17:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "indices" : [ 120, 133 ],
      "id_str" : "141530833",
      "id" : 141530833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/6XdP53M6ew",
      "expanded_url" : "http:\/\/www.abc.net.au\/nightlife\/stories\/4482705.htm",
      "display_url" : "abc.net.au\/nightlife\/stor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743551446201798657",
  "text" : "\"a lot of the money went into purchase of devices but not necessarily into the thinking behind\" https:\/\/t.co\/6XdP53M6ew @iatefl_ltsig debate",
  "id" : 743551446201798657,
  "created_at" : "2016-06-16 21:10:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Owen",
      "screen_name" : "ArrantPedantry",
      "indices" : [ 84, 99 ],
      "id_str" : "348284120",
      "id" : 348284120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/16wK0kNo8v",
      "expanded_url" : "http:\/\/www.arrantpedantry.com\/2016\/06\/15\/sorry-merriam-webster-but-hot-dogs-are-not-sandwiches\/",
      "display_url" : "arrantpedantry.com\/2016\/06\/15\/sor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743539038502682624",
  "text" : "Sorry, Merriam-Webster, but Hot Dogs Are Not Sandwiches https:\/\/t.co\/16wK0kNo8v via @ArrantPedantry",
  "id" : 743539038502682624,
  "created_at" : "2016-06-16 20:21:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben nazer",
      "screen_name" : "BenCanTeach",
      "indices" : [ 0, 12 ],
      "id_str" : "729405603873951745",
      "id" : 729405603873951745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743473968045244416",
  "geo" : { },
  "id_str" : "743535994864046081",
  "in_reply_to_user_id" : 729405603873951745,
  "text" : "@BenCanTeach thx dashed hopes &amp; all for that game",
  "id" : 743535994864046081,
  "in_reply_to_status_id" : 743473968045244416,
  "created_at" : "2016-06-16 20:09:30 +0000",
  "in_reply_to_screen_name" : "BenCanTeach",
  "in_reply_to_user_id_str" : "729405603873951745",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 13, 29 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743463985349963776",
  "geo" : { },
  "id_str" : "743466883802882048",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @getgreatenglish could look at CEFR descriptors?",
  "id" : 743466883802882048,
  "in_reply_to_status_id" : 743463985349963776,
  "created_at" : "2016-06-16 15:34:52 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743456088377401344",
  "text" : ":(",
  "id" : 743456088377401344,
  "created_at" : "2016-06-16 14:51:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/743451023658876929\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/R7p4Jaslqc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClFEw5QWgAAofUt.jpg",
      "id_str" : "743451020286656512",
      "id" : 743451020286656512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClFEw5QWgAAofUt.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/R7p4Jaslqc"
    } ],
    "hashtags" : [ {
      "text" : "eltmyths",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743451023658876929",
  "text" : "Granularity drawbacks new #eltmyths https:\/\/t.co\/R7p4Jaslqc",
  "id" : 743451023658876929,
  "created_at" : "2016-06-16 14:31:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743439472906375168",
  "text" : ": )",
  "id" : 743439472906375168,
  "created_at" : "2016-06-16 13:45:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Lucy Jones",
      "screen_name" : "jones_lucy",
      "indices" : [ 11, 22 ],
      "id_str" : "33185003",
      "id" : 33185003
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 39, 54 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742660681514770432",
  "geo" : { },
  "id_str" : "743405725129506816",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab @jones_lucy  have you tried @GeoffreyJordan blog?",
  "id" : 743405725129506816,
  "in_reply_to_status_id" : 742660681514770432,
  "created_at" : "2016-06-16 11:31:51 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743399295534137344",
  "geo" : { },
  "id_str" : "743399937904283648",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d great acronym : )",
  "id" : 743399937904283648,
  "in_reply_to_status_id" : 743399295534137344,
  "created_at" : "2016-06-16 11:08:51 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743211857528430598",
  "geo" : { },
  "id_str" : "743212615988555776",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne neat, where are you getting the categories from?",
  "id" : 743212615988555776,
  "in_reply_to_status_id" : 743211857528430598,
  "created_at" : "2016-06-15 22:44:30 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 3, 17 ],
      "id_str" : "273391079",
      "id" : 273391079
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 138, 139 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/qYivq7fueJ",
      "expanded_url" : "https:\/\/shar.es\/1JZoxu",
      "display_url" : "shar.es\/1JZoxu"
    } ]
  },
  "geo" : { },
  "id_str" : "743208905547845632",
  "text" : "RT @nickbilbrough: The free webinar I'll be doing on Monday for refugee day....Nick Bilbrough - Zooming in and out https:\/\/t.co\/qYivq7fueJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 124, 134 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/qYivq7fueJ",
        "expanded_url" : "https:\/\/shar.es\/1JZoxu",
        "display_url" : "shar.es\/1JZoxu"
      } ]
    },
    "geo" : { },
    "id_str" : "743165797892231168",
    "text" : "The free webinar I'll be doing on Monday for refugee day....Nick Bilbrough - Zooming in and out https:\/\/t.co\/qYivq7fueJ via @sharethis",
    "id" : 743165797892231168,
    "created_at" : "2016-06-15 19:38:28 +0000",
    "user" : {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "protected" : false,
      "id_str" : "273391079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705302580944117760\/4q5JmOoa_normal.jpg",
      "id" : 273391079,
      "verified" : false
    }
  },
  "id" : 743208905547845632,
  "created_at" : "2016-06-15 22:29:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hack Education",
      "screen_name" : "hackeducation",
      "indices" : [ 3, 17 ],
      "id_str" : "149029700",
      "id" : 149029700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eci830",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/xdH16lEn6M",
      "expanded_url" : "http:\/\/hackeducation.com\/2016\/06\/14\/commercialization",
      "display_url" : "hackeducation.com\/2016\/06\/14\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743111643131957248",
  "text" : "RT @hackeducation: Ed-Tech and the Commercialization of School #eci830 https:\/\/t.co\/xdH16lEn6M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eci830",
        "indices" : [ 44, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/xdH16lEn6M",
        "expanded_url" : "http:\/\/hackeducation.com\/2016\/06\/14\/commercialization",
        "display_url" : "hackeducation.com\/2016\/06\/14\/com\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742913905630924800",
    "text" : "Ed-Tech and the Commercialization of School #eci830 https:\/\/t.co\/xdH16lEn6M",
    "id" : 742913905630924800,
    "created_at" : "2016-06-15 02:57:32 +0000",
    "user" : {
      "name" : "Hack Education",
      "screen_name" : "hackeducation",
      "protected" : false,
      "id_str" : "149029700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737060505789960193\/jwugbbTJ_normal.jpg",
      "id" : 149029700,
      "verified" : true
    }
  },
  "id" : 743111643131957248,
  "created_at" : "2016-06-15 16:03:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 3, 14 ],
      "id_str" : "327186537",
      "id" : 327186537
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chimponobo\/status\/742902474600632322\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/O0epinKZjo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck9RvE-UkAEUJLo.jpg",
      "id_str" : "742902332770258945",
      "id" : 742902332770258945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck9RvE-UkAEUJLo.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/O0epinKZjo"
    } ],
    "hashtags" : [ {
      "text" : "auselt",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "EFL",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/z7u4Cm6wFx",
      "expanded_url" : "https:\/\/tecsquared.com\/node\/107",
      "display_url" : "tecsquared.com\/node\/107"
    } ]
  },
  "geo" : { },
  "id_str" : "743029581590974464",
  "text" : "RT @chimponobo: Bring out the Gimp: Being Pro-stuff in ESL part 1 https:\/\/t.co\/z7u4Cm6wFx #auselt #EFL #ELTchat #TESOL https:\/\/t.co\/O0epinK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chimponobo\/status\/742902474600632322\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/O0epinKZjo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck9RvE-UkAEUJLo.jpg",
        "id_str" : "742902332770258945",
        "id" : 742902332770258945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck9RvE-UkAEUJLo.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/O0epinKZjo"
      } ],
      "hashtags" : [ {
        "text" : "auselt",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "EFL",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 96, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/z7u4Cm6wFx",
        "expanded_url" : "https:\/\/tecsquared.com\/node\/107",
        "display_url" : "tecsquared.com\/node\/107"
      } ]
    },
    "geo" : { },
    "id_str" : "742902474600632322",
    "text" : "Bring out the Gimp: Being Pro-stuff in ESL part 1 https:\/\/t.co\/z7u4Cm6wFx #auselt #EFL #ELTchat #TESOL https:\/\/t.co\/O0epinKZjo",
    "id" : 742902474600632322,
    "created_at" : "2016-06-15 02:12:07 +0000",
    "user" : {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "protected" : false,
      "id_str" : "327186537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703504370713780224\/Ffd779uj_normal.jpg",
      "id" : 327186537,
      "verified" : false
    }
  },
  "id" : 743029581590974464,
  "created_at" : "2016-06-15 10:37:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McWhorter",
      "screen_name" : "JohnHMcWhorter",
      "indices" : [ 0, 15 ],
      "id_str" : "1306199515",
      "id" : 1306199515
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 16, 31 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 32, 38 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/1q5RZ57xLt",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=1314",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=1314"
    } ]
  },
  "in_reply_to_status_id_str" : "742813643436380160",
  "geo" : { },
  "id_str" : "742840650106871808",
  "in_reply_to_user_id" : 1306199515,
  "text" : "@JohnHMcWhorter @AnthonyTeacher @Slate hmm not convinced spellcheckers rulez : ) https:\/\/t.co\/1q5RZ57xLt",
  "id" : 742840650106871808,
  "in_reply_to_status_id" : 742813643436380160,
  "created_at" : "2016-06-14 22:06:26 +0000",
  "in_reply_to_screen_name" : "JohnHMcWhorter",
  "in_reply_to_user_id_str" : "1306199515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael TESOL",
      "screen_name" : "RachaelTESOL",
      "indices" : [ 0, 13 ],
      "id_str" : "537057787",
      "id" : 537057787
    }, {
      "name" : "Gavin Reddin",
      "screen_name" : "ReddinGavin",
      "indices" : [ 14, 26 ],
      "id_str" : "2723204205",
      "id" : 2723204205
    }, {
      "name" : "Chris Farrell",
      "screen_name" : "ChrisPatrickF",
      "indices" : [ 27, 41 ],
      "id_str" : "3165431237",
      "id" : 3165431237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/vwF7iusuaB",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243\/stream\/ea5b64fa-abb3-4788-bdaa-1db319ebcce0",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "742656137569390593",
  "geo" : { },
  "id_str" : "742812875476078592",
  "in_reply_to_user_id" : 537057787,
  "text" : "@RachaelTESOL @ReddinGavin @ChrisPatrickF hope u make it this round : ) u could check https:\/\/t.co\/vwF7iusuaB to get a flavour",
  "id" : 742812875476078592,
  "in_reply_to_status_id" : 742656137569390593,
  "created_at" : "2016-06-14 20:16:04 +0000",
  "in_reply_to_screen_name" : "RachaelTESOL",
  "in_reply_to_user_id_str" : "537057787",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B. the Unbridgeable",
      "screen_name" : "usageguides",
      "indices" : [ 75, 87 ],
      "id_str" : "369478225",
      "id" : 369478225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ToHP53XBrl",
      "expanded_url" : "https:\/\/bridgingtheunbridgeable.com\/2016\/06\/14\/how-do-sticklers-react-to-linguistic-findings\/",
      "display_url" : "bridgingtheunbridgeable.com\/2016\/06\/14\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742666206105198592",
  "text" : "How do sticklers react to linguistic findings? https:\/\/t.co\/ToHP53XBrl via @usageguides",
  "id" : 742666206105198592,
  "created_at" : "2016-06-14 10:33:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 13, 28 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742459831710298112",
  "geo" : { },
  "id_str" : "742464454416273412",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @AnthonyTeacher it's on sci-hub",
  "id" : 742464454416273412,
  "in_reply_to_status_id" : 742459831710298112,
  "created_at" : "2016-06-13 21:11:34 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/1gSRFcHvdu",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/wordlists\/",
      "display_url" : "eflnotes.wordpress.com\/wordlists\/"
    } ]
  },
  "in_reply_to_status_id_str" : "742441682482933760",
  "geo" : { },
  "id_str" : "742453439200940032",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher thanks added to wordlists https:\/\/t.co\/1gSRFcHvdu",
  "id" : 742453439200940032,
  "in_reply_to_status_id" : 742441682482933760,
  "created_at" : "2016-06-13 20:27:48 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Hinde",
      "screen_name" : "elizabeth_hinde",
      "indices" : [ 124, 140 ],
      "id_str" : "2383117290",
      "id" : 2383117290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/NQCGNYcfhx",
      "expanded_url" : "https:\/\/elizabethhinde.com\/2016\/05\/31\/mr-lemov-meet-madeline-hunter-and-many-others-who-discovered-the-same-things-and-gave-credit-where-credit-was-due\/",
      "display_url" : "elizabethhinde.com\/2016\/05\/31\/mr-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742445213747187712",
  "text" : "Mr. LeMov, Meet Madeline Hunter \u2013 And Many Others Who Discovered the Same Things (and Gave Cre\u2026 https:\/\/t.co\/NQCGNYcfhx via @elizabeth_hinde",
  "id" : 742445213747187712,
  "created_at" : "2016-06-13 19:55:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 116, 131 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/eLyCqouqf0",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-the-relevance-of-the-academic-vocabulary-list-avl",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742443929430335489",
  "text" : "RT @AnthonyTeacher: Research Bites: The Relevance of the Academic Vocabulary List (AVL) https:\/\/t.co\/eLyCqouqf0 via @AnthonyTeacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AnthonyTeacher",
        "screen_name" : "AnthonyTeacher",
        "indices" : [ 96, 111 ],
        "id_str" : "285614027",
        "id" : 285614027
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/eLyCqouqf0",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-the-relevance-of-the-academic-vocabulary-list-avl",
        "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742441682482933760",
    "text" : "Research Bites: The Relevance of the Academic Vocabulary List (AVL) https:\/\/t.co\/eLyCqouqf0 via @AnthonyTeacher",
    "id" : 742441682482933760,
    "created_at" : "2016-06-13 19:41:05 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 742443929430335489,
  "created_at" : "2016-06-13 19:50:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742368947249381376",
  "geo" : { },
  "id_str" : "742372506628173825",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hey no worries, nah not really enjoyed Welsh win on Sat \uD83D\uDE03",
  "id" : 742372506628173825,
  "in_reply_to_status_id" : 742368947249381376,
  "created_at" : "2016-06-13 15:06:12 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "indices" : [ 53, 63 ],
      "id_str" : "742333546421846016",
      "id" : 742333546421846016
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 92, 101 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBLTchat",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gmLeq3I16f",
      "expanded_url" : "http:\/\/tbltchat.wordpress.com\/",
      "display_url" : "tbltchat.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "742368577894940672",
  "text" : "RT @getgreatenglish: So, no dilly dallying. I set up @TBLT_chat #TBLTchat upon a query from @ashowski. Website up at https:\/\/t.co\/gmLeq3I16\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TBLTchat",
        "screen_name" : "TBLT_chat",
        "indices" : [ 32, 42 ],
        "id_str" : "742333546421846016",
        "id" : 742333546421846016
      }, {
        "name" : "Anthony Ash FRSA",
        "screen_name" : "Ashowski",
        "indices" : [ 71, 80 ],
        "id_str" : "316596356",
        "id" : 316596356
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TBLTchat",
        "indices" : [ 43, 52 ]
      }, {
        "text" : "ELT",
        "indices" : [ 120, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/gmLeq3I16f",
        "expanded_url" : "http:\/\/tbltchat.wordpress.com\/",
        "display_url" : "tbltchat.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "742338124060069889",
    "text" : "So, no dilly dallying. I set up @TBLT_chat #TBLTchat upon a query from @ashowski. Website up at https:\/\/t.co\/gmLeq3I16f #ELT",
    "id" : 742338124060069889,
    "created_at" : "2016-06-13 12:49:35 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 742368577894940672,
  "created_at" : "2016-06-13 14:50:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marion Nao",
      "screen_name" : "LinguaNao",
      "indices" : [ 0, 10 ],
      "id_str" : "2844937438",
      "id" : 2844937438
    }, {
      "name" : "EconomicTimes",
      "screen_name" : "EconomicTimes",
      "indices" : [ 11, 25 ],
      "id_str" : "39743812",
      "id" : 39743812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/wCoNvo9Jtb",
      "expanded_url" : "http:\/\/david-crystal.blogspot.fr\/2016\/06\/on-reported-death-of-full-stop-period.html?m=1",
      "display_url" : "david-crystal.blogspot.fr\/2016\/06\/on-rep\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "742266424568221696",
  "geo" : { },
  "id_str" : "742278143537467392",
  "in_reply_to_user_id" : 2844937438,
  "text" : "@LinguaNao @EconomicTimes although he did not actually say what report thinks he said : \/ https:\/\/t.co\/wCoNvo9Jtb",
  "id" : 742278143537467392,
  "in_reply_to_status_id" : 742266424568221696,
  "created_at" : "2016-06-13 08:51:14 +0000",
  "in_reply_to_screen_name" : "LinguaNao",
  "in_reply_to_user_id_str" : "2844937438",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phonetics Lab",
      "screen_name" : "PhoneticsLab",
      "indices" : [ 3, 16 ],
      "id_str" : "584312439",
      "id" : 584312439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/u1EXtkEMgC",
      "expanded_url" : "http:\/\/www.metronews.ca\/news\/vancouver\/2016\/06\/09\/ubc-use-ultrasound-to-teach-cantonese-language.html",
      "display_url" : "metronews.ca\/news\/vancouver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742275741925158912",
  "text" : "RT @PhoneticsLab: UBC researchers use ultrasound technology to teach Cantonese https:\/\/t.co\/u1EXtkEMgC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/u1EXtkEMgC",
        "expanded_url" : "http:\/\/www.metronews.ca\/news\/vancouver\/2016\/06\/09\/ubc-use-ultrasound-to-teach-cantonese-language.html",
        "display_url" : "metronews.ca\/news\/vancouver\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742272407717744640",
    "text" : "UBC researchers use ultrasound technology to teach Cantonese https:\/\/t.co\/u1EXtkEMgC",
    "id" : 742272407717744640,
    "created_at" : "2016-06-13 08:28:27 +0000",
    "user" : {
      "name" : "Phonetics Lab",
      "screen_name" : "PhoneticsLab",
      "protected" : false,
      "id_str" : "584312439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2855984505\/bd524b602cecccafbbd6aff01ba9d9e6_normal.jpeg",
      "id" : 584312439,
      "verified" : false
    }
  },
  "id" : 742275741925158912,
  "created_at" : "2016-06-13 08:41:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 76, 87 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/tSyRm3AI4F",
      "expanded_url" : "https:\/\/elt-resourceful.com\/2016\/06\/08\/why-do-cats-miaow-a-free-downloadable-lesson\/",
      "display_url" : "elt-resourceful.com\/2016\/06\/08\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742066858682122240",
  "text" : "Why do cats miaow? : a free downloadable lesson https:\/\/t.co\/tSyRm3AI4F via @teflerinha",
  "id" : 742066858682122240,
  "created_at" : "2016-06-12 18:51:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whatonomy",
      "screen_name" : "whatonomy",
      "indices" : [ 0, 10 ],
      "id_str" : "360454490",
      "id" : 360454490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741694391904030720",
  "geo" : { },
  "id_str" : "742065425530359808",
  "in_reply_to_user_id" : 360454490,
  "text" : "@whatonomy my pleasure yr post had me smiling : )",
  "id" : 742065425530359808,
  "in_reply_to_status_id" : 741694391904030720,
  "created_at" : "2016-06-12 18:45:59 +0000",
  "in_reply_to_screen_name" : "whatonomy",
  "in_reply_to_user_id_str" : "360454490",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 58, 74 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/FjfGGZ86IA",
      "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2016\/06\/12\/materials-writing-etude-op-1\/",
      "display_url" : "eltgeek.wordpress.com\/2016\/06\/12\/mat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742065163604525056",
  "text" : "Materials writing \u00C9tude op. 1 https:\/\/t.co\/FjfGGZ86IA via @wordpressdotcom",
  "id" : 742065163604525056,
  "created_at" : "2016-06-12 18:44:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whatonomy",
      "screen_name" : "whatonomy",
      "indices" : [ 60, 70 ],
      "id_str" : "360454490",
      "id" : 360454490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/wq0g5zTUs0",
      "expanded_url" : "https:\/\/whatonomy.wordpress.com\/2016\/06\/11\/teacher-upstanding-episode-5\/",
      "display_url" : "whatonomy.wordpress.com\/2016\/06\/11\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741692405401985024",
  "text" : "Teacher, Upstanding - Episode 5 https:\/\/t.co\/wq0g5zTUs0 via @whatonomy",
  "id" : 741692405401985024,
  "created_at" : "2016-06-11 18:03:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Has Avrat",
      "screen_name" : "hasavrat",
      "indices" : [ 3, 12 ],
      "id_str" : "277930075",
      "id" : 277930075
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hasavrat\/status\/741687761409839106\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/PMh8XfPcar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CksBEygXEAAyA1O.jpg",
      "id_str" : "741687745421185024",
      "id" : 741687745421185024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CksBEygXEAAyA1O.jpg",
      "sizes" : [ {
        "h" : 848,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 601
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/PMh8XfPcar"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741691107155804160",
  "text" : "RT @hasavrat: This. Is. Excellent. https:\/\/t.co\/PMh8XfPcar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hasavrat\/status\/741687761409839106\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/PMh8XfPcar",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CksBEygXEAAyA1O.jpg",
        "id_str" : "741687745421185024",
        "id" : 741687745421185024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CksBEygXEAAyA1O.jpg",
        "sizes" : [ {
          "h" : 848,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 848,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 848,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/PMh8XfPcar"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741687761409839106",
    "text" : "This. Is. Excellent. https:\/\/t.co\/PMh8XfPcar",
    "id" : 741687761409839106,
    "created_at" : "2016-06-11 17:45:16 +0000",
    "user" : {
      "name" : "Has Avrat",
      "screen_name" : "hasavrat",
      "protected" : false,
      "id_str" : "277930075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729743927037808640\/im0azbLy_normal.jpg",
      "id" : 277930075,
      "verified" : false
    }
  },
  "id" : 741691107155804160,
  "created_at" : "2016-06-11 17:58:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    }, {
      "name" : "Laura Bailey",
      "screen_name" : "linguistlaura",
      "indices" : [ 15, 29 ],
      "id_str" : "380265356",
      "id" : 380265356
    }, {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 30, 42 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/bfcNtOblXi",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/700298649880801281",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "741573286446964736",
  "geo" : { },
  "id_str" : "741622367781289984",
  "in_reply_to_user_id" : 380265356,
  "text" : "@Glenn_Hadikin @linguistlaura @LanguageLog did someone say Pullum meme? https:\/\/t.co\/bfcNtOblXi : )",
  "id" : 741622367781289984,
  "in_reply_to_status_id" : 741573286446964736,
  "created_at" : "2016-06-11 13:25:25 +0000",
  "in_reply_to_screen_name" : "linguistlaura",
  "in_reply_to_user_id_str" : "380265356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 3, 14 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/AJBEo0egA4",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/08\/corpusmooc-16",
      "display_url" : "corpling4efl.wordpress.com\/2016\/06\/08\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741286383935979521",
  "text" : "RT @Za_Maikeru: corpusMOOC \u201916 https:\/\/t.co\/AJBEo0egA4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/AJBEo0egA4",
        "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/08\/corpusmooc-16",
        "display_url" : "corpling4efl.wordpress.com\/2016\/06\/08\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740410133331730437",
    "text" : "corpusMOOC \u201916 https:\/\/t.co\/AJBEo0egA4",
    "id" : 740410133331730437,
    "created_at" : "2016-06-08 05:08:26 +0000",
    "user" : {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "protected" : false,
      "id_str" : "703598479944208384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714776497257578496\/rmJMMadQ_normal.jpg",
      "id" : 703598479944208384,
      "verified" : false
    }
  },
  "id" : 741286383935979521,
  "created_at" : "2016-06-10 15:10:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/dXmEdTUZRA",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/820-how-the-press-hides-the-global-crimes-of-the-west-corporate-media-coverage-of-chad.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740918052510945281",
  "text" : "RT @medialens: This excellent guest media alert from Richard Keeble may open your eyes on Chad https:\/\/t.co\/dXmEdTUZRA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/dXmEdTUZRA",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/820-how-the-press-hides-the-global-crimes-of-the-west-corporate-media-coverage-of-chad.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740910329497067520",
    "text" : "This excellent guest media alert from Richard Keeble may open your eyes on Chad https:\/\/t.co\/dXmEdTUZRA",
    "id" : 740910329497067520,
    "created_at" : "2016-06-09 14:16:02 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 740918052510945281,
  "created_at" : "2016-06-09 14:46:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    }, {
      "name" : "Giulia",
      "screen_name" : "wanderingELT",
      "indices" : [ 16, 29 ],
      "id_str" : "494920237",
      "id" : 494920237
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 30, 46 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Kate",
      "screen_name" : "KateLloyd05",
      "indices" : [ 47, 59 ],
      "id_str" : "71482132",
      "id" : 71482132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elcthat",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740917163528163328",
  "geo" : { },
  "id_str" : "740917350078283776",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas @wanderingELT @getgreatenglish @KateLloyd05 i hear some people call that the internet dunno cld be wrong #elcthat",
  "id" : 740917350078283776,
  "in_reply_to_status_id" : 740917163528163328,
  "created_at" : "2016-06-09 14:43:56 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Kate",
      "screen_name" : "KateLloyd05",
      "indices" : [ 17, 29 ],
      "id_str" : "71482132",
      "id" : 71482132
    }, {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 30, 45 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740894382719537152",
  "geo" : { },
  "id_str" : "740914514523262977",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @KateLloyd05 @angelos_bollas an FBschool built-out from their walled-up infrastructure #eltchat",
  "id" : 740914514523262977,
  "in_reply_to_status_id" : 740894382719537152,
  "created_at" : "2016-06-09 14:32:40 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "indices" : [ 3, 14 ],
      "id_str" : "16042794",
      "id" : 16042794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/d62sBChDuD",
      "expanded_url" : "http:\/\/trib.al\/diGKCN1",
      "display_url" : "trib.al\/diGKCN1"
    } ]
  },
  "geo" : { },
  "id_str" : "740913536289886208",
  "text" : "RT @GuardianUS: The Standford rape case: a white privilege cake with vanilla frosting on top https:\/\/t.co\/d62sBChDuD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/d62sBChDuD",
        "expanded_url" : "http:\/\/trib.al\/diGKCN1",
        "display_url" : "trib.al\/diGKCN1"
      } ]
    },
    "geo" : { },
    "id_str" : "740910972123156484",
    "text" : "The Standford rape case: a white privilege cake with vanilla frosting on top https:\/\/t.co\/d62sBChDuD",
    "id" : 740910972123156484,
    "created_at" : "2016-06-09 14:18:35 +0000",
    "user" : {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "protected" : false,
      "id_str" : "16042794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743073930827698176\/MawT7psS_normal.jpg",
      "id" : 16042794,
      "verified" : true
    }
  },
  "id" : 740913536289886208,
  "created_at" : "2016-06-09 14:28:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate",
      "screen_name" : "KateLloyd05",
      "indices" : [ 0, 12 ],
      "id_str" : "71482132",
      "id" : 71482132
    }, {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 13, 28 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740888724498583552",
  "geo" : { },
  "id_str" : "740891100609712128",
  "in_reply_to_user_id" : 71482132,
  "text" : "@KateLloyd05 @angelos_bollas to what extent r those \"student universes\" created by students vs created by non-students? #eltchat",
  "id" : 740891100609712128,
  "in_reply_to_status_id" : 740888724498583552,
  "created_at" : "2016-06-09 12:59:38 +0000",
  "in_reply_to_screen_name" : "KateLloyd05",
  "in_reply_to_user_id_str" : "71482132",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 103, 114 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Fbn5VRU9xl",
      "expanded_url" : "https:\/\/ioelondonblog.wordpress.com\/2016\/06\/09\/he-white-paper-market-principles-simplistically-applied-simply-wont-work\/",
      "display_url" : "ioelondonblog.wordpress.com\/2016\/06\/09\/he-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740888355580334081",
  "text" : "HE White Paper: market principles simplistically applied simply won\u2019t work https:\/\/t.co\/Fbn5VRU9xl via @IOE_London",
  "id" : 740888355580334081,
  "created_at" : "2016-06-09 12:48:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740872362380435456",
  "geo" : { },
  "id_str" : "740878790704791552",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas the \"reality\" you referred to in initial tweet is not a given natural state of things, was what i was responding to",
  "id" : 740878790704791552,
  "in_reply_to_status_id" : 740872362380435456,
  "created_at" : "2016-06-09 12:10:43 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/uhNQbA1BtI",
      "expanded_url" : "https:\/\/www.unite4education.org\/global-response\/bridge-international-academies-adds-fear-and-intimidation-to-its-business-strategy\/?platform=hootsuite",
      "display_url" : "unite4education.org\/global-respons\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "740872362380435456",
  "geo" : { },
  "id_str" : "740877858072109057",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas e.g. \"Bridge forces families to pay for inadequate scripted lessons read from tablets.\" https:\/\/t.co\/uhNQbA1BtI #eltchat",
  "id" : 740877858072109057,
  "in_reply_to_status_id" : 740872362380435456,
  "created_at" : "2016-06-09 12:07:00 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740863050488684544",
  "geo" : { },
  "id_str" : "740868375837048832",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas who is creating that reality? for what purposes? and by what means? #eltchat",
  "id" : 740868375837048832,
  "in_reply_to_status_id" : 740863050488684544,
  "created_at" : "2016-06-09 11:29:20 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740806537464123392",
  "geo" : { },
  "id_str" : "740806716279947265",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thx, my pleasure : )",
  "id" : 740806716279947265,
  "in_reply_to_status_id" : 740806537464123392,
  "created_at" : "2016-06-09 07:24:19 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Underwood",
      "screen_name" : "joshuau",
      "indices" : [ 3, 11 ],
      "id_str" : "88037336",
      "id" : 88037336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LearnerLanguage",
      "indices" : [ 13, 29 ]
    }, {
      "text" : "CorpusLinguistics",
      "indices" : [ 32, 50 ]
    }, {
      "text" : "MobileLearning",
      "indices" : [ 53, 68 ]
    }, {
      "text" : "MALL",
      "indices" : [ 138, 139 ]
    }, {
      "text" : "EdTech",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/inp6RhrTPl",
      "expanded_url" : "http:\/\/www.tellop.eu\/tell-op-workshop\/",
      "display_url" : "tellop.eu\/tell-op-worksh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740805251201142789",
  "text" : "RT @joshuau: #LearnerLanguage + #CorpusLinguistics + #MobileLearning sounds like a great idea, pity not to get to: https:\/\/t.co\/inp6RhrTPl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LearnerLanguage",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "CorpusLinguistics",
        "indices" : [ 19, 37 ]
      }, {
        "text" : "MobileLearning",
        "indices" : [ 40, 55 ]
      }, {
        "text" : "MALL",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "EdTech",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/inp6RhrTPl",
        "expanded_url" : "http:\/\/www.tellop.eu\/tell-op-workshop\/",
        "display_url" : "tellop.eu\/tell-op-worksh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739151183466598403",
    "text" : "#LearnerLanguage + #CorpusLinguistics + #MobileLearning sounds like a great idea, pity not to get to: https:\/\/t.co\/inp6RhrTPl #MALL #EdTech",
    "id" : 739151183466598403,
    "created_at" : "2016-06-04 17:45:49 +0000",
    "user" : {
      "name" : "Joshua Underwood",
      "screen_name" : "joshuau",
      "protected" : false,
      "id_str" : "88037336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000263900896\/2896ef298d72ea9c05c34d2682988be1_normal.jpeg",
      "id" : 88037336,
      "verified" : false
    }
  },
  "id" : 740805251201142789,
  "created_at" : "2016-06-09 07:18:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "indices" : [ 82, 93 ],
      "id_str" : "402209787",
      "id" : 402209787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/te5bqYO4ak",
      "expanded_url" : "https:\/\/patthomson.net\/2016\/06\/09\/things-to-do-during-your-phd-develop-an-application\/",
      "display_url" : "patthomson.net\/2016\/06\/09\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740802666180268032",
  "text" : "things to do during your PhD - develop an application https:\/\/t.co\/te5bqYO4ak via @ThomsonPat #corpuslinguistics",
  "id" : 740802666180268032,
  "created_at" : "2016-06-09 07:08:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/xmQ8JF3jHW",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics\/",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740639608401170432",
  "text" : "RT @TonyMcEnery: The #corpusMOOC is back on the 26th September. Sign up now! https:\/\/t.co\/xmQ8JF3jHW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/xmQ8JF3jHW",
        "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics\/",
        "display_url" : "futurelearn.com\/courses\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740555462144319488",
    "text" : "The #corpusMOOC is back on the 26th September. Sign up now! https:\/\/t.co\/xmQ8JF3jHW",
    "id" : 740555462144319488,
    "created_at" : "2016-06-08 14:45:55 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 740639608401170432,
  "created_at" : "2016-06-08 20:20:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 0, 9 ],
      "id_str" : "13533482",
      "id" : 13533482
    }, {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 10, 19 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 20, 36 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740637153588314112",
  "geo" : { },
  "id_str" : "740638474349510660",
  "in_reply_to_user_id" : 13533482,
  "text" : "@whippler @Liam_ELT @getgreatenglish a good one though needs mobile friendly version",
  "id" : 740638474349510660,
  "in_reply_to_status_id" : 740637153588314112,
  "created_at" : "2016-06-08 20:15:47 +0000",
  "in_reply_to_screen_name" : "whippler",
  "in_reply_to_user_id_str" : "13533482",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 0, 9 ],
      "id_str" : "13533482",
      "id" : 13533482
    }, {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 10, 19 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 20, 36 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/bOk9OJgvRI",
      "expanded_url" : "http:\/\/smu-facweb.smu.ca\/~s0949176\/sammy\/",
      "display_url" : "smu-facweb.smu.ca\/~s0949176\/samm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "740634860008681473",
  "geo" : { },
  "id_str" : "740635902985265153",
  "in_reply_to_user_id" : 13533482,
  "text" : "@whippler @Liam_ELT @getgreatenglish this one is neat if u haven't seen it already https:\/\/t.co\/bOk9OJgvRI",
  "id" : 740635902985265153,
  "in_reply_to_status_id" : 740634860008681473,
  "created_at" : "2016-06-08 20:05:34 +0000",
  "in_reply_to_screen_name" : "whippler",
  "in_reply_to_user_id_str" : "13533482",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil McMillan",
      "screen_name" : "neil_mcm",
      "indices" : [ 0, 9 ],
      "id_str" : "60425505",
      "id" : 60425505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740635016498188288",
  "geo" : { },
  "id_str" : "740635490957856768",
  "in_reply_to_user_id" : 60425505,
  "text" : "@neil_mcm if i had any funds would put it on a ouija startup : 0",
  "id" : 740635490957856768,
  "in_reply_to_status_id" : 740635016498188288,
  "created_at" : "2016-06-08 20:03:56 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9gqYp3VUF1",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=69753",
      "display_url" : "tm.durusau.net\/?p=69753"
    } ]
  },
  "geo" : { },
  "id_str" : "740631286851723264",
  "text" : "Before specifying criteria for success or even understanding problem, a cultist announces approach that will succeed https:\/\/t.co\/9gqYp3VUF1",
  "id" : 740631286851723264,
  "created_at" : "2016-06-08 19:47:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/740628889639260160\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/5MrdKA6FHJ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ckc99RnXAAA2Q_r.jpg",
      "id_str" : "740628786635538432",
      "id" : 740628786635538432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ckc99RnXAAA2Q_r.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/5MrdKA6FHJ"
    } ],
    "hashtags" : [ {
      "text" : "frictionlesslearning",
      "indices" : [ 57, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740628889639260160",
  "text" : "another term that needs to be kicked into the long grass #frictionlesslearning https:\/\/t.co\/5MrdKA6FHJ",
  "id" : 740628889639260160,
  "created_at" : "2016-06-08 19:37:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Owen",
      "screen_name" : "ArrantPedantry",
      "indices" : [ 0, 15 ],
      "id_str" : "348284120",
      "id" : 348284120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/vkDWlo3vo7",
      "expanded_url" : "http:\/\/www.mtlblog.com\/2016\/05\/dont-read-this-article-si-tes-pas-bilingue\/",
      "display_url" : "mtlblog.com\/2016\/05\/dont-r\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "740353996380999680",
  "geo" : { },
  "id_str" : "740401155558244352",
  "in_reply_to_user_id" : 348284120,
  "text" : "@ArrantPedantry avez-vous read this? \uD83D\uDE02 https:\/\/t.co\/vkDWlo3vo7",
  "id" : 740401155558244352,
  "in_reply_to_status_id" : 740353996380999680,
  "created_at" : "2016-06-08 04:32:46 +0000",
  "in_reply_to_screen_name" : "ArrantPedantry",
  "in_reply_to_user_id_str" : "348284120",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Astra Taylor",
      "screen_name" : "astradisastra",
      "indices" : [ 3, 17 ],
      "id_str" : "376991410",
      "id" : 376991410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/6xsAcuG7p8",
      "expanded_url" : "http:\/\/blog.debtcollective.org\/whos-afraid-of-occupy-hbos-john-oliver-erases-debt-resistance\/",
      "display_url" : "blog.debtcollective.org\/whos-afraid-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740299560686346240",
  "text" : "RT @astradisastra: Cool John Oliver show erased debt on TV. Not cool they erased Rolling Jubilee to avoid OWS association. \nhttps:\/\/t.co\/6x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/6xsAcuG7p8",
        "expanded_url" : "http:\/\/blog.debtcollective.org\/whos-afraid-of-occupy-hbos-john-oliver-erases-debt-resistance\/",
        "display_url" : "blog.debtcollective.org\/whos-afraid-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739932475271618560",
    "text" : "Cool John Oliver show erased debt on TV. Not cool they erased Rolling Jubilee to avoid OWS association. \nhttps:\/\/t.co\/6xsAcuG7p8",
    "id" : 739932475271618560,
    "created_at" : "2016-06-06 21:30:24 +0000",
    "user" : {
      "name" : "Astra Taylor",
      "screen_name" : "astradisastra",
      "protected" : false,
      "id_str" : "376991410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529728141275582465\/Fzn9EQzY_normal.png",
      "id" : 376991410,
      "verified" : false
    }
  },
  "id" : 740299560686346240,
  "created_at" : "2016-06-07 21:49:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yutaka Ishii (\u77F3\u4E95\u96C4\u9686)",
      "screen_name" : "yishii_0207",
      "indices" : [ 3, 15 ],
      "id_str" : "171376048",
      "id" : 171376048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "https:\/\/t.co\/b5K67vrGcZ",
      "expanded_url" : "http:\/\/www.llt.msu.edu\/issues\/june2016\/v20n2.pdf#page=121",
      "display_url" : "llt.msu.edu\/issues\/june201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740227772040220673",
  "text" : "RT @yishii_0207: Chapelle., &amp; Voss. (2016). 20 years of technology and language assessment in Language Learning &amp; Technology.\n\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/b5K67vrGcZ",
        "expanded_url" : "http:\/\/www.llt.msu.edu\/issues\/june2016\/v20n2.pdf#page=121",
        "display_url" : "llt.msu.edu\/issues\/june201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740052838596763648",
    "text" : "Chapelle., &amp; Voss. (2016). 20 years of technology and language assessment in Language Learning &amp; Technology.\n\nhttps:\/\/t.co\/b5K67vrGcZ [pdf]",
    "id" : 740052838596763648,
    "created_at" : "2016-06-07 05:28:40 +0000",
    "user" : {
      "name" : "Yutaka Ishii (\u77F3\u4E95\u96C4\u9686)",
      "screen_name" : "yishii_0207",
      "protected" : false,
      "id_str" : "171376048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1333995742\/CIMG2225_normal.JPG",
      "id" : 171376048,
      "verified" : false
    }
  },
  "id" : 740227772040220673,
  "created_at" : "2016-06-07 17:03:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Guild",
      "screen_name" : "teflguild",
      "indices" : [ 3, 13 ],
      "id_str" : "732157129818316802",
      "id" : 732157129818316802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Pv9qt5XLcd",
      "expanded_url" : "http:\/\/gu.com\/p\/4kj93\/stw",
      "display_url" : "gu.com\/p\/4kj93\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "740202126501105664",
  "text" : "RT @teflguild: Mike Ashley has pocketed millions from treating people like battery hens | Aditya Chakrabortty https:\/\/t.co\/Pv9qt5XLcd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/Pv9qt5XLcd",
        "expanded_url" : "http:\/\/gu.com\/p\/4kj93\/stw",
        "display_url" : "gu.com\/p\/4kj93\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "740197113024372736",
    "text" : "Mike Ashley has pocketed millions from treating people like battery hens | Aditya Chakrabortty https:\/\/t.co\/Pv9qt5XLcd",
    "id" : 740197113024372736,
    "created_at" : "2016-06-07 15:01:58 +0000",
    "user" : {
      "name" : "TEFL Guild",
      "screen_name" : "teflguild",
      "protected" : false,
      "id_str" : "732157129818316802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738337519469744128\/m5UrSeot_normal.jpg",
      "id" : 732157129818316802,
      "verified" : false
    }
  },
  "id" : 740202126501105664,
  "created_at" : "2016-06-07 15:21:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 0, 14 ],
      "id_str" : "48459936",
      "id" : 48459936
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 15, 23 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740190308017790976",
  "geo" : { },
  "id_str" : "740195781412589569",
  "in_reply_to_user_id" : 48459936,
  "text" : "@lousylinguist @grvsmth indeed unsurprisingly given sources",
  "id" : 740195781412589569,
  "in_reply_to_status_id" : 740190308017790976,
  "created_at" : "2016-06-07 14:56:41 +0000",
  "in_reply_to_screen_name" : "lousylinguist",
  "in_reply_to_user_id_str" : "48459936",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTL Blog",
      "screen_name" : "mtlblog",
      "indices" : [ 73, 81 ],
      "id_str" : "811533451",
      "id" : 811533451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/vkDWlo3vo7",
      "expanded_url" : "http:\/\/www.mtlblog.com\/2016\/05\/dont-read-this-article-si-tes-pas-bilingue\/",
      "display_url" : "mtlblog.com\/2016\/05\/dont-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740154508043530240",
  "text" : "Don\u2019t Read This Article Si T\u2019es Pas Bilingue https:\/\/t.co\/vkDWlo3vo7 via @MTLBlog",
  "id" : 740154508043530240,
  "created_at" : "2016-06-07 12:12:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 3, 14 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/WAvxzKgbgM",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/07\/why-use-corpora",
      "display_url" : "corpling4efl.wordpress.com\/2016\/06\/07\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740130657247039488",
  "text" : "RT @Za_Maikeru: Why use corpora? https:\/\/t.co\/WAvxzKgbgM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/WAvxzKgbgM",
        "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/07\/why-use-corpora",
        "display_url" : "corpling4efl.wordpress.com\/2016\/06\/07\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740023077140992001",
    "text" : "Why use corpora? https:\/\/t.co\/WAvxzKgbgM",
    "id" : 740023077140992001,
    "created_at" : "2016-06-07 03:30:25 +0000",
    "user" : {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "protected" : false,
      "id_str" : "703598479944208384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714776497257578496\/rmJMMadQ_normal.jpg",
      "id" : 703598479944208384,
      "verified" : false
    }
  },
  "id" : 740130657247039488,
  "created_at" : "2016-06-07 10:37:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudie Graner",
      "screen_name" : "thespreadingoak",
      "indices" : [ 0, 16 ],
      "id_str" : "22363581",
      "id" : 22363581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739796601749700608",
  "geo" : { },
  "id_str" : "740128772029046784",
  "in_reply_to_user_id" : 22363581,
  "text" : "@thespreadingoak yes who is accountable when such systems go wrong?",
  "id" : 740128772029046784,
  "in_reply_to_status_id" : 739796601749700608,
  "created_at" : "2016-06-07 10:30:24 +0000",
  "in_reply_to_screen_name" : "thespreadingoak",
  "in_reply_to_user_id_str" : "22363581",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 49, 65 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/bY7kNqCRBJ",
      "expanded_url" : "https:\/\/corplinguistics.wordpress.com\/2016\/06\/05\/poetry-v-not-poetry\/",
      "display_url" : "corplinguistics.wordpress.com\/2016\/06\/05\/poe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739571559648657408",
  "text" : "Poetry v. not-poetry https:\/\/t.co\/bY7kNqCRBJ via @wordpressdotcom",
  "id" : 739571559648657408,
  "created_at" : "2016-06-05 21:36:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jemele Hill",
      "screen_name" : "jemelehill",
      "indices" : [ 3, 14 ],
      "id_str" : "35586563",
      "id" : 35586563
    }, {
      "name" : "Lawrence Ross",
      "screen_name" : "alpha1906",
      "indices" : [ 41, 51 ],
      "id_str" : "15871416",
      "id" : 15871416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/pVZTmLdr96",
      "expanded_url" : "http:\/\/bit.ly\/1PbWYQH",
      "display_url" : "bit.ly\/1PbWYQH"
    } ]
  },
  "geo" : { },
  "id_str" : "739552194136055809",
  "text" : "RT @jemelehill: Terrific piece on Ali by @alpha1906: Let's not forget the Ali that made America uncomfortable https:\/\/t.co\/pVZTmLdr96",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lawrence Ross",
        "screen_name" : "alpha1906",
        "indices" : [ 25, 35 ],
        "id_str" : "15871416",
        "id" : 15871416
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/pVZTmLdr96",
        "expanded_url" : "http:\/\/bit.ly\/1PbWYQH",
        "display_url" : "bit.ly\/1PbWYQH"
      } ]
    },
    "geo" : { },
    "id_str" : "739153991679025152",
    "text" : "Terrific piece on Ali by @alpha1906: Let's not forget the Ali that made America uncomfortable https:\/\/t.co\/pVZTmLdr96",
    "id" : 739153991679025152,
    "created_at" : "2016-06-04 17:56:59 +0000",
    "user" : {
      "name" : "Jemele Hill",
      "screen_name" : "jemelehill",
      "protected" : false,
      "id_str" : "35586563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633792288855072768\/hpnyS2yT_normal.jpg",
      "id" : 35586563,
      "verified" : true
    }
  },
  "id" : 739552194136055809,
  "created_at" : "2016-06-05 20:19:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaolin Fantastic",
      "screen_name" : "Eddrickation",
      "indices" : [ 3, 16 ],
      "id_str" : "990448478",
      "id" : 990448478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/InPaar0yjU",
      "expanded_url" : "https:\/\/twitter.com\/LeBatardShow\/status\/739106826160115713",
      "display_url" : "twitter.com\/LeBatardShow\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739550613848109056",
  "text" : "RT @Eddrickation: \uD83D\uDCAF\uD83D\uDCAF\uD83D\uDCAF https:\/\/t.co\/InPaar0yjU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/InPaar0yjU",
        "expanded_url" : "https:\/\/twitter.com\/LeBatardShow\/status\/739106826160115713",
        "display_url" : "twitter.com\/LeBatardShow\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739188465581969408",
    "text" : "\uD83D\uDCAF\uD83D\uDCAF\uD83D\uDCAF https:\/\/t.co\/InPaar0yjU",
    "id" : 739188465581969408,
    "created_at" : "2016-06-04 20:13:58 +0000",
    "user" : {
      "name" : "Shaolin Fantastic",
      "screen_name" : "Eddrickation",
      "protected" : false,
      "id_str" : "990448478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722598000464240641\/WMPcY73K_normal.jpg",
      "id" : 990448478,
      "verified" : false
    }
  },
  "id" : 739550613848109056,
  "created_at" : "2016-06-05 20:13:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "indices" : [ 3, 16 ],
      "id_str" : "141530833",
      "id" : 141530833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Yout0eA2JV",
      "expanded_url" : "http:\/\/bit.ly\/1r8kt73",
      "display_url" : "bit.ly\/1r8kt73"
    } ]
  },
  "geo" : { },
  "id_str" : "739444786222923777",
  "text" : "RT @iatefl_ltsig: \"Is technology helping Ss develop their skills or is it simply distracting them from learning?\" Blog Debate!!!!  https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/Yout0eA2JV",
        "expanded_url" : "http:\/\/bit.ly\/1r8kt73",
        "display_url" : "bit.ly\/1r8kt73"
      } ]
    },
    "geo" : { },
    "id_str" : "739440234539188224",
    "text" : "\"Is technology helping Ss develop their skills or is it simply distracting them from learning?\" Blog Debate!!!!  https:\/\/t.co\/Yout0eA2JV",
    "id" : 739440234539188224,
    "created_at" : "2016-06-05 12:54:24 +0000",
    "user" : {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "protected" : false,
      "id_str" : "141530833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3559398421\/c33454189d56b57c68d3bfadec038dcb_normal.jpeg",
      "id" : 141530833,
      "verified" : false
    }
  },
  "id" : 739444786222923777,
  "created_at" : "2016-06-05 13:12:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/oYTcOzOTKK",
      "expanded_url" : "http:\/\/tinyletter.com\/audreywatters\/letters\/hewn-no-164",
      "display_url" : "tinyletter.com\/audreywatters\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739439102626516992",
  "text" : "RT @audreywatters: HEWN, No. 164 https:\/\/t.co\/oYTcOzOTKK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/oYTcOzOTKK",
        "expanded_url" : "http:\/\/tinyletter.com\/audreywatters\/letters\/hewn-no-164",
        "display_url" : "tinyletter.com\/audreywatters\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739279602871209985",
    "text" : "HEWN, No. 164 https:\/\/t.co\/oYTcOzOTKK",
    "id" : 739279602871209985,
    "created_at" : "2016-06-05 02:16:07 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 739439102626516992,
  "created_at" : "2016-06-05 12:49:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 15, 21 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aral\/status\/738742334477733888\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/o0Uc6nGZZ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkCKO40WkAECK0T.png",
      "id_str" : "738742327263531009",
      "id" : 738742327263531009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkCKO40WkAECK0T.png",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/o0Uc6nGZZ1"
    } ],
    "hashtags" : [ {
      "text" : "NoDEAL",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/czK0t048Ui",
      "expanded_url" : "https:\/\/better.fyi\/spotlight\/wired.com\/",
      "display_url" : "better.fyi\/spotlight\/wire\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739431635196780548",
  "text" : "RT @aral: Dear @wired,\n\nWe\u2019re blocking your content blocker blocker.\n\nYour move.\n\nhttps:\/\/t.co\/czK0t048Ui\n\n#NoDEAL https:\/\/t.co\/o0Uc6nGZZ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 5, 11 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aral\/status\/738742334477733888\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/o0Uc6nGZZ1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkCKO40WkAECK0T.png",
        "id_str" : "738742327263531009",
        "id" : 738742327263531009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkCKO40WkAECK0T.png",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/o0Uc6nGZZ1"
      } ],
      "hashtags" : [ {
        "text" : "NoDEAL",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/czK0t048Ui",
        "expanded_url" : "https:\/\/better.fyi\/spotlight\/wired.com\/",
        "display_url" : "better.fyi\/spotlight\/wire\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738742334477733888",
    "text" : "Dear @wired,\n\nWe\u2019re blocking your content blocker blocker.\n\nYour move.\n\nhttps:\/\/t.co\/czK0t048Ui\n\n#NoDEAL https:\/\/t.co\/o0Uc6nGZZ1",
    "id" : 738742334477733888,
    "created_at" : "2016-06-03 14:41:12 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 739431635196780548,
  "created_at" : "2016-06-05 12:20:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/08CWFifpWd",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/why-does-english-spread-in-global-academia\/",
      "display_url" : "languageonthemove.com\/why-does-engli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739409980563050496",
  "text" : "Why does English spread in global academia? https:\/\/t.co\/08CWFifpWd",
  "id" : 739409980563050496,
  "created_at" : "2016-06-05 10:54:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie C",
      "screen_name" : "timedingtable",
      "indices" : [ 3, 17 ],
      "id_str" : "2500889389",
      "id" : 2500889389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/VZkXmCPrWi",
      "expanded_url" : "http:\/\/tinyurl.com\/h35nxh2",
      "display_url" : "tinyurl.com\/h35nxh2"
    } ]
  },
  "geo" : { },
  "id_str" : "739069146395205632",
  "text" : "RT @timedingtable: A new blog post: https:\/\/t.co\/VZkXmCPrWi 'To muddle or not' - reflections on a relative clause lesson #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 102, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/VZkXmCPrWi",
        "expanded_url" : "http:\/\/tinyurl.com\/h35nxh2",
        "display_url" : "tinyurl.com\/h35nxh2"
      } ]
    },
    "geo" : { },
    "id_str" : "739065388881743873",
    "text" : "A new blog post: https:\/\/t.co\/VZkXmCPrWi 'To muddle or not' - reflections on a relative clause lesson #elt",
    "id" : 739065388881743873,
    "created_at" : "2016-06-04 12:04:54 +0000",
    "user" : {
      "name" : "Jamie C",
      "screen_name" : "timedingtable",
      "protected" : false,
      "id_str" : "2500889389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719853143031283712\/5q8BaLN2_normal.jpg",
      "id" : 2500889389,
      "verified" : false
    }
  },
  "id" : 739069146395205632,
  "created_at" : "2016-06-04 12:19:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738431897139843076",
  "geo" : { },
  "id_str" : "739018479085465600",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules it's available on sci-hub.cc",
  "id" : 739018479085465600,
  "in_reply_to_status_id" : 738431897139843076,
  "created_at" : "2016-06-04 08:58:30 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLitCritGuy",
      "screen_name" : "TheLitCritGuy",
      "indices" : [ 3, 17 ],
      "id_str" : "464620194",
      "id" : 464620194
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheLitCritGuy\/status\/738730995009093632\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qTR5QoLWuH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkB_7EYWEAA0-_q.jpg",
      "id_str" : "738730991653621760",
      "id" : 738730991653621760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkB_7EYWEAA0-_q.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 676
      } ],
      "display_url" : "pic.twitter.com\/qTR5QoLWuH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739016909232934912",
  "text" : "RT @TheLitCritGuy: Two things: \n1. Non-fiction writers have won the Nobel prize for literature \n2. Richard Dawkins is a moron. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheLitCritGuy\/status\/738730995009093632\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/qTR5QoLWuH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkB_7EYWEAA0-_q.jpg",
        "id_str" : "738730991653621760",
        "id" : 738730991653621760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkB_7EYWEAA0-_q.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 676
        } ],
        "display_url" : "pic.twitter.com\/qTR5QoLWuH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738730995009093632",
    "text" : "Two things: \n1. Non-fiction writers have won the Nobel prize for literature \n2. Richard Dawkins is a moron. https:\/\/t.co\/qTR5QoLWuH",
    "id" : 738730995009093632,
    "created_at" : "2016-06-03 13:56:08 +0000",
    "user" : {
      "name" : "TheLitCritGuy",
      "screen_name" : "TheLitCritGuy",
      "protected" : false,
      "id_str" : "464620194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749934528320372740\/Kp6yoRfI_normal.jpg",
      "id" : 464620194,
      "verified" : false
    }
  },
  "id" : 739016909232934912,
  "created_at" : "2016-06-04 08:52:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Younge",
      "screen_name" : "garyyounge",
      "indices" : [ 3, 14 ],
      "id_str" : "149272318",
      "id" : 149272318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "https:\/\/t.co\/9ouXvJRJrk",
      "expanded_url" : "http:\/\/bit.ly\/1WzSon8",
      "display_url" : "bit.ly\/1WzSon8"
    } ]
  },
  "geo" : { },
  "id_str" : "739001749034422272",
  "text" : "RT @garyyounge: Muhammad Ali's significance transcends sport to race, politics &amp; foreign policy. Kevin Mitchell &amp; I on Ali's life https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/9ouXvJRJrk",
        "expanded_url" : "http:\/\/bit.ly\/1WzSon8",
        "display_url" : "bit.ly\/1WzSon8"
      } ]
    },
    "geo" : { },
    "id_str" : "738983853344227328",
    "text" : "Muhammad Ali's significance transcends sport to race, politics &amp; foreign policy. Kevin Mitchell &amp; I on Ali's life https:\/\/t.co\/9ouXvJRJrk",
    "id" : 738983853344227328,
    "created_at" : "2016-06-04 06:40:54 +0000",
    "user" : {
      "name" : "Gary Younge",
      "screen_name" : "garyyounge",
      "protected" : false,
      "id_str" : "149272318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/939207630\/Garycz_normal.gif",
      "id" : 149272318,
      "verified" : true
    }
  },
  "id" : 739001749034422272,
  "created_at" : "2016-06-04 07:52:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Raff",
      "screen_name" : "JenniferRaff",
      "indices" : [ 73, 86 ],
      "id_str" : "102417054",
      "id" : 102417054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/HkXwE91DtH",
      "expanded_url" : "https:\/\/violentmetaphors.com\/2016\/06\/03\/how-to-flunk-out-of-the-university-of-google\/",
      "display_url" : "violentmetaphors.com\/2016\/06\/03\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738997885157675008",
  "text" : "How to flunk out of the University of Google https:\/\/t.co\/HkXwE91DtH via @jenniferraff",
  "id" : 738997885157675008,
  "created_at" : "2016-06-04 07:36:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 11, 17 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 18, 27 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738693652419993600",
  "geo" : { },
  "id_str" : "738720281171218432",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB @ebefl @chiasuan translanguaging is what the cool kids are into believe : )",
  "id" : 738720281171218432,
  "in_reply_to_status_id" : 738693652419993600,
  "created_at" : "2016-06-03 13:13:34 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben nazer",
      "screen_name" : "BenCanTeach",
      "indices" : [ 0, 12 ],
      "id_str" : "729405603873951745",
      "id" : 729405603873951745
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 13, 24 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738662066224005121",
  "in_reply_to_user_id" : 729405603873951745,
  "text" : "@BenCanTeach @leoselivan shld work from KWIC search option?",
  "id" : 738662066224005121,
  "created_at" : "2016-06-03 09:22:14 +0000",
  "in_reply_to_screen_name" : "BenCanTeach",
  "in_reply_to_user_id_str" : "729405603873951745",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 3, 14 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/XUfhxt9Hxz",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/03\/frequency-lists-in-pre-reading-activities",
      "display_url" : "corpling4efl.wordpress.com\/2016\/06\/03\/fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738659721494835200",
  "text" : "RT @Za_Maikeru: Frequency lists in pre-reading\u00A0activities https:\/\/t.co\/XUfhxt9Hxz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/XUfhxt9Hxz",
        "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/06\/03\/frequency-lists-in-pre-reading-activities",
        "display_url" : "corpling4efl.wordpress.com\/2016\/06\/03\/fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738643872142659584",
    "text" : "Frequency lists in pre-reading\u00A0activities https:\/\/t.co\/XUfhxt9Hxz",
    "id" : 738643872142659584,
    "created_at" : "2016-06-03 08:09:57 +0000",
    "user" : {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "protected" : false,
      "id_str" : "703598479944208384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714776497257578496\/rmJMMadQ_normal.jpg",
      "id" : 703598479944208384,
      "verified" : false
    }
  },
  "id" : 738659721494835200,
  "created_at" : "2016-06-03 09:12:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Nu8NcYLQOe",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2016\/5\/30\/10648\/6035",
      "display_url" : "eurotrib.com\/story\/2016\/5\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738612667657510912",
  "text" : "France on Strike https:\/\/t.co\/Nu8NcYLQOe",
  "id" : 738612667657510912,
  "created_at" : "2016-06-03 06:05:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vimeo",
      "screen_name" : "Vimeo",
      "indices" : [ 70, 76 ],
      "id_str" : "14718218",
      "id" : 14718218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/tUL47Nb4zN",
      "expanded_url" : "https:\/\/vimeo.com\/164225449?ref=tw-share",
      "display_url" : "vimeo.com\/164225449?ref=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738609493970321408",
  "text" : "Prevent strategy \"2. Professor Mark McGovan -Edge Hill University\" on @Vimeo https:\/\/t.co\/tUL47Nb4zN",
  "id" : 738609493970321408,
  "created_at" : "2016-06-03 05:53:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738460754425356291",
  "text" : "apparently people still use the made up phrase \"thought leaders\" in 2016 without smirking",
  "id" : 738460754425356291,
  "created_at" : "2016-06-02 20:02:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "indices" : [ 3, 19 ],
      "id_str" : "3437858853",
      "id" : 3437858853
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 21, 29 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toryelectionfraud",
      "indices" : [ 55, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738458332806144001",
  "text" : "RT @neolib_takedown: @BBCNews Why aren't you reporting #toryelectionfraud?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 0, 8 ],
        "id_str" : "612473",
        "id" : 612473
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "toryelectionfraud",
        "indices" : [ 34, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738399202045272064",
    "in_reply_to_user_id" : 612473,
    "text" : "@BBCNews Why aren't you reporting #toryelectionfraud?",
    "id" : 738399202045272064,
    "created_at" : "2016-06-02 15:57:43 +0000",
    "in_reply_to_screen_name" : "BBCNews",
    "in_reply_to_user_id_str" : "612473",
    "user" : {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "protected" : false,
      "id_str" : "3437858853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635797071396798464\/rD8NlTWp_normal.png",
      "id" : 3437858853,
      "verified" : false
    }
  },
  "id" : 738458332806144001,
  "created_at" : "2016-06-02 19:52:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "indices" : [ 3, 19 ],
      "id_str" : "3307929149",
      "id" : 3307929149
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 41, 50 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/738443712947232768\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/G5viOjEoRW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj96oJLWgAAPJhO.jpg",
      "id_str" : "738443693988937728",
      "id" : 738443693988937728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj96oJLWgAAPJhO.jpg",
      "sizes" : [ {
        "h" : 549,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2249,
        "resize" : "fit",
        "w" : 1394
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/G5viOjEoRW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/sz7k3GdglP",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/jun\/02\/can-we-see-jeremy-corbyns-smile-in-slow-mo?utm_content=buffere2469&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738448430788403200",
  "text" : "RT @JeremyCorbyn4PM: Great letter in the @guardian \nhttps:\/\/t.co\/sz7k3GdglP https:\/\/t.co\/G5viOjEoRW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 20, 29 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/738443712947232768\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/G5viOjEoRW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj96oJLWgAAPJhO.jpg",
        "id_str" : "738443693988937728",
        "id" : 738443693988937728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj96oJLWgAAPJhO.jpg",
        "sizes" : [ {
          "h" : 549,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1652,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2249,
          "resize" : "fit",
          "w" : 1394
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/G5viOjEoRW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/sz7k3GdglP",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/jun\/02\/can-we-see-jeremy-corbyns-smile-in-slow-mo?utm_content=buffere2469&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
        "display_url" : "theguardian.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738443712947232768",
    "text" : "Great letter in the @guardian \nhttps:\/\/t.co\/sz7k3GdglP https:\/\/t.co\/G5viOjEoRW",
    "id" : 738443712947232768,
    "created_at" : "2016-06-02 18:54:35 +0000",
    "user" : {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "protected" : false,
      "id_str" : "3307929149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746982653350445056\/UHNiRVhu_normal.jpg",
      "id" : 3307929149,
      "verified" : false
    }
  },
  "id" : 738448430788403200,
  "created_at" : "2016-06-02 19:13:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 43, 59 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/UIlwlufyWa",
      "expanded_url" : "https:\/\/elliot-murphy.com\/2016\/06\/02\/disarm-ucl-2-0\/",
      "display_url" : "elliot-murphy.com\/2016\/06\/02\/dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738430634113310720",
  "text" : "Disarm UCL 2.0 https:\/\/t.co\/UIlwlufyWa via @wordpressdotcom",
  "id" : 738430634113310720,
  "created_at" : "2016-06-02 18:02:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738386783575085056",
  "geo" : { },
  "id_str" : "738391918338580480",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway it's all greek to me : )",
  "id" : 738391918338580480,
  "in_reply_to_status_id" : 738386783575085056,
  "created_at" : "2016-06-02 15:28:46 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris stolz",
      "screen_name" : "srstolz",
      "indices" : [ 0, 8 ],
      "id_str" : "27029718",
      "id" : 27029718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/NIU73ZNq0O",
      "expanded_url" : "http:\/\/mentalfloss.com\/article\/78823\/quran-memorizers-who-dont-speak-arabic-learn-grammar-statistics-alone#",
      "display_url" : "mentalfloss.com\/article\/78823\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "738150380861722626",
  "geo" : { },
  "id_str" : "738375949633343488",
  "in_reply_to_user_id" : 27029718,
  "text" : "@srstolz possibly &amp; \"acquirement\" speed can be + by teaching; length of learning Arabic gramm via implicit means? https:\/\/t.co\/NIU73ZNq0O",
  "id" : 738375949633343488,
  "in_reply_to_status_id" : 738150380861722626,
  "created_at" : "2016-06-02 14:25:19 +0000",
  "in_reply_to_screen_name" : "srstolz",
  "in_reply_to_user_id_str" : "27029718",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738364056713764865",
  "geo" : { },
  "id_str" : "738372221408792577",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr hi sorry what list?",
  "id" : 738372221408792577,
  "in_reply_to_status_id" : 738364056713764865,
  "created_at" : "2016-06-02 14:10:30 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/738371540476166145\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/xXzxmQwPZK",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cj844pNWEAQ5-m1.jpg",
      "id_str" : "738371409697705988",
      "id" : 738371409697705988,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cj844pNWEAQ5-m1.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/xXzxmQwPZK"
    } ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 20, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738371540476166145",
  "text" : "Ali G does COCA pop #corpuslinguistics https:\/\/t.co\/xXzxmQwPZK",
  "id" : 738371540476166145,
  "created_at" : "2016-06-02 14:07:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Howells",
      "screen_name" : "willhowells",
      "indices" : [ 3, 15 ],
      "id_str" : "4075431",
      "id" : 4075431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738354560075436032",
  "text" : "RT @willhowells: First they came for the dickheads, and I did not speak out because I was not a dickhead.\n\nAnd it turned out to be lovely.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738345464135815168",
    "text" : "First they came for the dickheads, and I did not speak out because I was not a dickhead.\n\nAnd it turned out to be lovely. The end.",
    "id" : 738345464135815168,
    "created_at" : "2016-06-02 12:24:11 +0000",
    "user" : {
      "name" : "Will Howells",
      "screen_name" : "willhowells",
      "protected" : false,
      "id_str" : "4075431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762706011203465216\/emchDH37_normal.jpg",
      "id" : 4075431,
      "verified" : false
    }
  },
  "id" : 738354560075436032,
  "created_at" : "2016-06-02 13:00:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/F1r37FwjDN",
      "expanded_url" : "https:\/\/twitter.com\/IHWorld\/status\/737972200737787904",
      "display_url" : "twitter.com\/IHWorld\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738354214762598400",
  "text" : "#languagetrivia https:\/\/t.co\/F1r37FwjDN",
  "id" : 738354214762598400,
  "created_at" : "2016-06-02 12:58:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 73, 89 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/lQSrdxbf60",
      "expanded_url" : "https:\/\/codeactsineducation.wordpress.com\/2016\/06\/02\/critical-questions-for-big-data-in-education\/",
      "display_url" : "codeactsineducation.wordpress.com\/2016\/06\/02\/cri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738352144236064768",
  "text" : "Critical questions for big data in education https:\/\/t.co\/lQSrdxbf60 via @wordpressdotcom",
  "id" : 738352144236064768,
  "created_at" : "2016-06-02 12:50:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738333046118699008",
  "geo" : { },
  "id_str" : "738349038790168578",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin a good simple story is very seductive!",
  "id" : 738349038790168578,
  "in_reply_to_status_id" : 738333046118699008,
  "created_at" : "2016-06-02 12:38:23 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "indices" : [ 3, 15 ],
      "id_str" : "14409265",
      "id" : 14409265
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidjbland\/status\/725119174368976897\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/FTPg4KnFDT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
      "id_str" : "725119173387386880",
      "id" : 725119173387386880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1174
      } ],
      "display_url" : "pic.twitter.com\/FTPg4KnFDT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738311575195516928",
  "text" : "RT @davidjbland: I've analyzed the Silicon Valley Bot Startup trend and created a handy venn diagram to help explain it. https:\/\/t.co\/FTPg4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/davidjbland\/status\/725119174368976897\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/FTPg4KnFDT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
        "id_str" : "725119173387386880",
        "id" : 725119173387386880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1174
        } ],
        "display_url" : "pic.twitter.com\/FTPg4KnFDT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725119174368976897",
    "text" : "I've analyzed the Silicon Valley Bot Startup trend and created a handy venn diagram to help explain it. https:\/\/t.co\/FTPg4KnFDT",
    "id" : 725119174368976897,
    "created_at" : "2016-04-27 00:27:37 +0000",
    "user" : {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "protected" : false,
      "id_str" : "14409265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755842954015547392\/v10U6DEy_normal.jpg",
      "id" : 14409265,
      "verified" : false
    }
  },
  "id" : 738311575195516928,
  "created_at" : "2016-06-02 10:09:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyona Medelyan",
      "screen_name" : "zelandiya",
      "indices" : [ 0, 10 ],
      "id_str" : "35714839",
      "id" : 35714839
    }, {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 11, 22 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738275543083323392",
  "geo" : { },
  "id_str" : "738296249414254592",
  "in_reply_to_user_id" : 35714839,
  "text" : "@zelandiya @gdlinguist i guess that is a good quote if you like fishing : )",
  "id" : 738296249414254592,
  "in_reply_to_status_id" : 738275543083323392,
  "created_at" : "2016-06-02 09:08:37 +0000",
  "in_reply_to_screen_name" : "zelandiya",
  "in_reply_to_user_id_str" : "35714839",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]