Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/t22Z6qNAsE",
      "expanded_url" : "https:\/\/zcomm.org\/znetarticle\/the-fight-for-15-shakes-awake-the-u-s-labor-movement\/",
      "display_url" : "zcomm.org\/znetarticle\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539169504438550529",
  "text" : "The Fight for $15 Shakes Awake the U.S. Labor Movement https:\/\/t.co\/t22Z6qNAsE",
  "id" : 539169504438550529,
  "created_at" : "2014-11-30 21:30:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ht6Vpxunze",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1417066060.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539056612426928128",
  "text" : "Russian leaders to visit Ferguson, hand out cookies, tell demonstrators \"we are with you\" http:\/\/t.co\/ht6Vpxunze",
  "id" : 539056612426928128,
  "created_at" : "2014-11-30 14:01:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/T1tLVLp14w",
      "expanded_url" : "http:\/\/youtu.be\/1OGIJE8AzqM",
      "display_url" : "youtu.be\/1OGIJE8AzqM"
    } ]
  },
  "geo" : { },
  "id_str" : "539048803349721088",
  "text" : "In Conversation with Noam Chomsky - A British Academy event: http:\/\/t.co\/T1tLVLp14w via @YouTube",
  "id" : 539048803349721088,
  "created_at" : "2014-11-30 13:30:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 75, 85 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/6JJxqfmXHX",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-8l",
      "display_url" : "wp.me\/p3sNrs-8l"
    } ]
  },
  "geo" : { },
  "id_str" : "539002062478905344",
  "text" : "Verbal questions, Visual answers | An apptivity http:\/\/t.co\/6JJxqfmXHX via @adi_rajan",
  "id" : 539002062478905344,
  "created_at" : "2014-11-30 10:24:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/mUyCrdbSf0",
      "expanded_url" : "http:\/\/buff.ly\/1CudQjM",
      "display_url" : "buff.ly\/1CudQjM"
    } ]
  },
  "geo" : { },
  "id_str" : "539001866475298818",
  "text" : "RT @leoselivan: Fresh off the blog press: Learners' use of collocations: more insights from the research | Leoxicon http:\/\/t.co\/mUyCrdbSf0 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesol",
        "indices" : [ 123, 129 ]
      }, {
        "text" : "tefl",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/mUyCrdbSf0",
        "expanded_url" : "http:\/\/buff.ly\/1CudQjM",
        "display_url" : "buff.ly\/1CudQjM"
      } ]
    },
    "geo" : { },
    "id_str" : "538993338008215552",
    "text" : "Fresh off the blog press: Learners' use of collocations: more insights from the research | Leoxicon http:\/\/t.co\/mUyCrdbSf0 #tesol #tefl",
    "id" : 538993338008215552,
    "created_at" : "2014-11-30 09:50:00 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 539001866475298818,
  "created_at" : "2014-11-30 10:23:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 108, 116 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538835450245685248",
  "text" : "\"By keeping the students away from comprehension...allowed them to experience a very different way of being\"@gbiesta Freeing Teaching...",
  "id" : 538835450245685248,
  "created_at" : "2014-11-29 23:22:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theevilempirestrikesback",
      "indices" : [ 60, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/UwTMeS0VIn",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1417254239.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538825150876372992",
  "text" : "Russian belligerence knows no bounds http:\/\/t.co\/UwTMeS0VIn #theevilempirestrikesback",
  "id" : 538825150876372992,
  "created_at" : "2014-11-29 22:41:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 103, 119 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/4ihaHhJT1P",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-4zP",
      "display_url" : "wp.me\/p2KE8s-4zP"
    } ]
  },
  "geo" : { },
  "id_str" : "538816147596902400",
  "text" : "On balance, have corpora had a good or bad influence on teaching materials? http:\/\/t.co\/4ihaHhJT1P via @wordpressdotcom",
  "id" : 538816147596902400,
  "created_at" : "2014-11-29 22:05:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EU",
      "indices" : [ 84, 87 ]
    }, {
      "text" : "Google",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "censorship",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/AKcjnMj3nN",
      "expanded_url" : "http:\/\/ow.ly\/F3Bo7",
      "display_url" : "ow.ly\/F3Bo7"
    } ]
  },
  "geo" : { },
  "id_str" : "538790821693501441",
  "text" : "RT @patrickDurusau: 505 Million Internet Censors and Growing (EU) - Web Magna Carta #EU #Google #censorship http:\/\/t.co\/AKcjnMj3nN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EU",
        "indices" : [ 64, 67 ]
      }, {
        "text" : "Google",
        "indices" : [ 68, 75 ]
      }, {
        "text" : "censorship",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/AKcjnMj3nN",
        "expanded_url" : "http:\/\/ow.ly\/F3Bo7",
        "display_url" : "ow.ly\/F3Bo7"
      } ]
    },
    "geo" : { },
    "id_str" : "538516512429318144",
    "text" : "505 Million Internet Censors and Growing (EU) - Web Magna Carta #EU #Google #censorship http:\/\/t.co\/AKcjnMj3nN",
    "id" : 538516512429318144,
    "created_at" : "2014-11-29 02:15:16 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 538790821693501441,
  "created_at" : "2014-11-29 20:25:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 60, 71 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/SQkBdn5NEK",
      "expanded_url" : "http:\/\/wp.me\/p2aFDK-OR",
      "display_url" : "wp.me\/p2aFDK-OR"
    } ]
  },
  "geo" : { },
  "id_str" : "538780998117236736",
  "text" : "How not to do a research project http:\/\/t.co\/SQkBdn5NEK via @AchilleasK",
  "id" : 538780998117236736,
  "created_at" : "2014-11-29 19:46:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corpus",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "esl",
      "indices" : [ 67, 71 ]
    }, {
      "text" : "tefl",
      "indices" : [ 72, 77 ]
    }, {
      "text" : "FLlanguage",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/OTMBtgk7zf",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-QT",
      "display_url" : "wp.me\/pgHyE-QT"
    } ]
  },
  "geo" : { },
  "id_str" : "538719918800134144",
  "text" : "A 2nd tipple of the TED #Corpus Search Engine #corpusmooc #eltchat #esl #tefl #FLlanguage http:\/\/t.co\/OTMBtgk7zf",
  "id" : 538719918800134144,
  "created_at" : "2014-11-29 15:43:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 100, 109 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/6YPcRzNZOH",
      "expanded_url" : "http:\/\/gu.com\/p\/43kb6\/tw",
      "display_url" : "gu.com\/p\/43kb6\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "538438289108123648",
  "text" : "It isn\u2019t Facebook that feeds terror. It\u2019s war and tyranny | Seumas Milne http:\/\/t.co\/6YPcRzNZOH via @guardian",
  "id" : 538438289108123648,
  "created_at" : "2014-11-28 21:04:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Rosenfelt",
      "screen_name" : "rachelrosenfelt",
      "indices" : [ 3, 19 ],
      "id_str" : "16007812",
      "id" : 16007812
    }, {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 76, 88 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rachelrosenfelt\/status\/538415826748334080\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/T2GfqYX3of",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3jWVbFCcAAv-9s.png",
      "id_str" : "538415819005259776",
      "id" : 538415819005259776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3jWVbFCcAAv-9s.png",
      "sizes" : [ {
        "h" : 133,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 975
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 975
      } ],
      "display_url" : "pic.twitter.com\/T2GfqYX3of"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/eVC3Rtf9xs",
      "expanded_url" : "http:\/\/thenewinquiry.com\/features\/black-friday-or-the-circulation-of-commodities\/",
      "display_url" : "thenewinquiry.com\/features\/black\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538416616925822976",
  "text" : "RT @rachelrosenfelt: These data visualizations of Alibaba's dark economy by @sam_lavigne are fucking incredible: http:\/\/t.co\/eVC3Rtf9xs htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Lavigne",
        "screen_name" : "sam_lavigne",
        "indices" : [ 55, 67 ],
        "id_str" : "6428702",
        "id" : 6428702
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rachelrosenfelt\/status\/538415826748334080\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/T2GfqYX3of",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3jWVbFCcAAv-9s.png",
        "id_str" : "538415819005259776",
        "id" : 538415819005259776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3jWVbFCcAAv-9s.png",
        "sizes" : [ {
          "h" : 133,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 975
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 975
        } ],
        "display_url" : "pic.twitter.com\/T2GfqYX3of"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/eVC3Rtf9xs",
        "expanded_url" : "http:\/\/thenewinquiry.com\/features\/black-friday-or-the-circulation-of-commodities\/",
        "display_url" : "thenewinquiry.com\/features\/black\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538415826748334080",
    "text" : "These data visualizations of Alibaba's dark economy by @sam_lavigne are fucking incredible: http:\/\/t.co\/eVC3Rtf9xs http:\/\/t.co\/T2GfqYX3of",
    "id" : 538415826748334080,
    "created_at" : "2014-11-28 19:35:11 +0000",
    "user" : {
      "name" : "Rachel Rosenfelt",
      "screen_name" : "rachelrosenfelt",
      "protected" : false,
      "id_str" : "16007812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659486795206291456\/Tx-shuwW_normal.jpg",
      "id" : 16007812,
      "verified" : false
    }
  },
  "id" : 538416616925822976,
  "created_at" : "2014-11-28 19:38:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berlin LW GAS",
      "screen_name" : "Berlin_LW_Gas",
      "indices" : [ 0, 14 ],
      "id_str" : "2828000594",
      "id" : 2828000594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537587324767330304",
  "geo" : { },
  "id_str" : "538415362594070528",
  "in_reply_to_user_id" : 2828000594,
  "text" : "@Berlin_LW_Gas True, trouble is majority of employers not interested in great pedagogy :\/",
  "id" : 538415362594070528,
  "in_reply_to_status_id" : 537587324767330304,
  "created_at" : "2014-11-28 19:33:20 +0000",
  "in_reply_to_screen_name" : "Berlin_LW_Gas",
  "in_reply_to_user_id_str" : "2828000594",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/xAY2lzVQnq",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007%2Fs11217-014-9454-z",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538302969222283264",
  "text" : "RT @gbiesta: new paper: \u2018Freeing teaching from learning\u2019 http:\/\/t.co\/xAY2lzVQnq e-mail me for a copy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/xAY2lzVQnq",
        "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007%2Fs11217-014-9454-z",
        "display_url" : "link.springer.com\/article\/10.100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "536369144690536448",
    "text" : "new paper: \u2018Freeing teaching from learning\u2019 http:\/\/t.co\/xAY2lzVQnq e-mail me for a copy",
    "id" : 536369144690536448,
    "created_at" : "2014-11-23 04:02:24 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 538302969222283264,
  "created_at" : "2014-11-28 12:06:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoichiro Hasebe",
      "screen_name" : "yohasebe",
      "indices" : [ 48, 57 ],
      "id_str" : "41918876",
      "id" : 41918876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Ig7SvUPtMV",
      "expanded_url" : "http:\/\/yohasebe.com\/wp\/archives\/4226",
      "display_url" : "yohasebe.com\/wp\/archives\/42\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538097835871588352",
  "text" : "for fans of TED #corpus search engine developer @yohasebe shows how to get utube to play yr search term immediately http:\/\/t.co\/Ig7SvUPtMV",
  "id" : 538097835871588352,
  "created_at" : "2014-11-27 22:31:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/gXZfApciXh",
      "expanded_url" : "http:\/\/bit.ly\/1vnFDw4",
      "display_url" : "bit.ly\/1vnFDw4"
    } ]
  },
  "geo" : { },
  "id_str" : "537965178462437377",
  "text" : "RT @heatherfro: monolingual wikipedia corpora: now available for 23 languages! http:\/\/t.co\/gXZfApciXh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/gXZfApciXh",
        "expanded_url" : "http:\/\/bit.ly\/1vnFDw4",
        "display_url" : "bit.ly\/1vnFDw4"
      } ]
    },
    "geo" : { },
    "id_str" : "537944823584784384",
    "text" : "monolingual wikipedia corpora: now available for 23 languages! http:\/\/t.co\/gXZfApciXh",
    "id" : 537944823584784384,
    "created_at" : "2014-11-27 12:23:35 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 537965178462437377,
  "created_at" : "2014-11-27 13:44:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 11, 22 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/OoZFWGdlSD",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2014\/11\/14\/a-tipple-of-the-ted-corpus-search-engine\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/11\/14\/a-t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "537728142928920576",
  "geo" : { },
  "id_str" : "537732487313510402",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @teflerinha hey Kyle you may like this https:\/\/t.co\/OoZFWGdlSD",
  "id" : 537732487313510402,
  "in_reply_to_status_id" : 537728142928920576,
  "created_at" : "2014-11-26 22:19:50 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 44, 57 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/365pOHJ8S4",
      "expanded_url" : "http:\/\/wp.me\/p28iGT-141",
      "display_url" : "wp.me\/p28iGT-141"
    } ]
  },
  "geo" : { },
  "id_str" : "537684880977444864",
  "text" : "Riots and Reason http:\/\/t.co\/365pOHJ8S4 via @tressiemcphd",
  "id" : 537684880977444864,
  "created_at" : "2014-11-26 19:10:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 76, 89 ],
      "id_str" : "74177226",
      "id" : 74177226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/OTFBVrDw7u",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-gd",
      "display_url" : "wp.me\/p2e2Wf-gd"
    } ]
  },
  "geo" : { },
  "id_str" : "537682579194118145",
  "text" : "RT @teflerinha: Decoding skills for listening: a collection of useful links @oupeltglobal http:\/\/t.co\/OTFBVrDw7u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oxford ELT",
        "screen_name" : "OUPELTGlobal",
        "indices" : [ 60, 73 ],
        "id_str" : "74177226",
        "id" : 74177226
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/OTFBVrDw7u",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-gd",
        "display_url" : "wp.me\/p2e2Wf-gd"
      } ]
    },
    "geo" : { },
    "id_str" : "537672477464608768",
    "text" : "Decoding skills for listening: a collection of useful links @oupeltglobal http:\/\/t.co\/OTFBVrDw7u",
    "id" : 537672477464608768,
    "created_at" : "2014-11-26 18:21:22 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 537682579194118145,
  "created_at" : "2014-11-26 19:01:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/1kkT05kK0Z",
      "expanded_url" : "http:\/\/www.phrasalverbdemon.com\/corpus.htm",
      "display_url" : "phrasalverbdemon.com\/corpus.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "537651839702147072",
  "in_reply_to_user_id" : 87405828,
  "text" : "@phrasalvrbdemon hi i was wondering what corpus u r using for http:\/\/t.co\/1kkT05kK0Z ? thx",
  "id" : 537651839702147072,
  "created_at" : "2014-11-26 16:59:22 +0000",
  "in_reply_to_screen_name" : "phrasalverbdmon",
  "in_reply_to_user_id_str" : "87405828",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537585334188384259",
  "geo" : { },
  "id_str" : "537596427476930560",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim hi sure soz cld not really participate",
  "id" : 537596427476930560,
  "in_reply_to_status_id" : 537585334188384259,
  "created_at" : "2014-11-26 13:19:11 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/9ykAP5V20o",
      "expanded_url" : "http:\/\/www.phrasalverbdemon.com\/teachers.htm",
      "display_url" : "phrasalverbdemon.com\/teachers.htm"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1kkT05kK0Z",
      "expanded_url" : "http:\/\/www.phrasalverbdemon.com\/corpus.htm",
      "display_url" : "phrasalverbdemon.com\/corpus.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "537585172116688896",
  "text" : "#eltchat hi all this has some good advice http:\/\/t.co\/9ykAP5V20o as well as a great corpus search tool http:\/\/t.co\/1kkT05kK0Z",
  "id" : 537585172116688896,
  "created_at" : "2014-11-26 12:34:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 56, 72 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/h6rZsqidnX",
      "expanded_url" : "http:\/\/wp.me\/p1frMc-Rl",
      "display_url" : "wp.me\/p1frMc-Rl"
    } ]
  },
  "geo" : { },
  "id_str" : "537579896730419201",
  "text" : "Countability - grammar codes http:\/\/t.co\/h6rZsqidnX via @wordpressdotcom",
  "id" : 537579896730419201,
  "created_at" : "2014-11-26 12:13:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/gCA0Dzp0ek",
      "expanded_url" : "http:\/\/www.thoughtleader.co.za\/jasonhickel\/2014\/11\/24\/the-death-of-international-development\/",
      "display_url" : "thoughtleader.co.za\/jasonhickel\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537365311461142528",
  "text" : "The death of international development | Thought Leader http:\/\/t.co\/gCA0Dzp0ek",
  "id" : 537365311461142528,
  "created_at" : "2014-11-25 22:00:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "indices" : [ 87, 96 ],
      "id_str" : "2222993041",
      "id" : 2222993041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/8LO5sFhqP0",
      "expanded_url" : "http:\/\/wp.me\/p3RMIO-c4",
      "display_url" : "wp.me\/p3RMIO-c4"
    } ]
  },
  "geo" : { },
  "id_str" : "537287762940940289",
  "text" : "Teaching techniques: 'Borrowing' (\/z\/ from Mexican Spanish) http:\/\/t.co\/8LO5sFhqP0 via @ELF_Pron",
  "id" : 537287762940940289,
  "created_at" : "2014-11-25 16:52:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/RZhoWWLK77",
      "expanded_url" : "https:\/\/elfaproject.wordpress.com\/2014\/11\/25\/adventures-in-correcting-the-semi-scientific-record\/",
      "display_url" : "elfaproject.wordpress.com\/2014\/11\/25\/adv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537277642161270784",
  "text" : "RT @GeoffreyJordan: Ray Carey cares about the truth: Adventures in correcting the (semi-)scientific record https:\/\/t.co\/RZhoWWLK77",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/RZhoWWLK77",
        "expanded_url" : "https:\/\/elfaproject.wordpress.com\/2014\/11\/25\/adventures-in-correcting-the-semi-scientific-record\/",
        "display_url" : "elfaproject.wordpress.com\/2014\/11\/25\/adv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537246331874840576",
    "text" : "Ray Carey cares about the truth: Adventures in correcting the (semi-)scientific record https:\/\/t.co\/RZhoWWLK77",
    "id" : 537246331874840576,
    "created_at" : "2014-11-25 14:08:01 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 537277642161270784,
  "created_at" : "2014-11-25 16:12:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537131043246325760",
  "text" : "RT @evgenymorozov: Yes, you can understand technology by learning how to code. Just like you can understand understand capitalism by learni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetymail.com\" rel=\"nofollow\"\u003Etweetymail\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "536951933953933313",
    "text" : "Yes, you can understand technology by learning how to code. Just like you can understand understand capitalism by learning how to trade.",
    "id" : 536951933953933313,
    "created_at" : "2014-11-24 18:38:11 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 537131043246325760,
  "created_at" : "2014-11-25 06:29:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 3, 15 ],
      "id_str" : "533125583",
      "id" : 533125583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/DUUMORBVSX",
      "expanded_url" : "http:\/\/wp.me\/p2uWUJ-8b",
      "display_url" : "wp.me\/p2uWUJ-8b"
    } ]
  },
  "geo" : { },
  "id_str" : "536900037025218560",
  "text" : "RT @teahorvatic: Week 4 of Corpus Linguistics course - summary http:\/\/t.co\/DUUMORBVSX #corpusMOOC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 69, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/DUUMORBVSX",
        "expanded_url" : "http:\/\/wp.me\/p2uWUJ-8b",
        "display_url" : "wp.me\/p2uWUJ-8b"
      } ]
    },
    "geo" : { },
    "id_str" : "536889921043062784",
    "text" : "Week 4 of Corpus Linguistics course - summary http:\/\/t.co\/DUUMORBVSX #corpusMOOC",
    "id" : 536889921043062784,
    "created_at" : "2014-11-24 14:31:46 +0000",
    "user" : {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "protected" : false,
      "id_str" : "533125583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363766953\/qFdM59R9_normal",
      "id" : 533125583,
      "verified" : false
    }
  },
  "id" : 536900037025218560,
  "created_at" : "2014-11-24 15:11:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marion Odell",
      "screen_name" : "MarionOdell",
      "indices" : [ 0, 12 ],
      "id_str" : "312225910",
      "id" : 312225910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536891086925733889",
  "geo" : { },
  "id_str" : "536896930165817345",
  "in_reply_to_user_id" : 312225910,
  "text" : "@MarionOdell great :)",
  "id" : 536896930165817345,
  "in_reply_to_status_id" : 536891086925733889,
  "created_at" : "2014-11-24 14:59:37 +0000",
  "in_reply_to_screen_name" : "MarionOdell",
  "in_reply_to_user_id_str" : "312225910",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marion Odell",
      "screen_name" : "MarionOdell",
      "indices" : [ 0, 12 ],
      "id_str" : "312225910",
      "id" : 312225910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536888767412715520",
  "geo" : { },
  "id_str" : "536890749791768576",
  "in_reply_to_user_id" : 312225910,
  "text" : "@MarionOdell hi do you have a write up of how u are using this? have only used it as straightforward quiz. thx",
  "id" : 536890749791768576,
  "in_reply_to_status_id" : 536888767412715520,
  "created_at" : "2014-11-24 14:35:04 +0000",
  "in_reply_to_screen_name" : "MarionOdell",
  "in_reply_to_user_id_str" : "312225910",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536884217515220993",
  "geo" : { },
  "id_str" : "536884860796039168",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hehe yeah doing a poster leaves much more time to see presentations",
  "id" : 536884860796039168,
  "in_reply_to_status_id" : 536884217515220993,
  "created_at" : "2014-11-24 14:11:40 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELE@UoM",
      "screen_name" : "ELE_UoM",
      "indices" : [ 3, 11 ],
      "id_str" : "706330457",
      "id" : 706330457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/7N3f4wnjNC",
      "expanded_url" : "http:\/\/www.technologyreview.com\/view\/532776\/linguistic-mapping-reveals-how-word-meanings-sometimes-change-overnight\/",
      "display_url" : "technologyreview.com\/view\/532776\/li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536883900254257152",
  "text" : "RT @ELE_UoM: Linguistic mapping reveals how word meanings sometimes change overnight: http:\/\/t.co\/7N3f4wnjNC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/7N3f4wnjNC",
        "expanded_url" : "http:\/\/www.technologyreview.com\/view\/532776\/linguistic-mapping-reveals-how-word-meanings-sometimes-change-overnight\/",
        "display_url" : "technologyreview.com\/view\/532776\/li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "536880602570817536",
    "text" : "Linguistic mapping reveals how word meanings sometimes change overnight: http:\/\/t.co\/7N3f4wnjNC",
    "id" : 536880602570817536,
    "created_at" : "2014-11-24 13:54:45 +0000",
    "user" : {
      "name" : "ELE@UoM",
      "screen_name" : "ELE_UoM",
      "protected" : false,
      "id_str" : "706330457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000573053754\/f049aace3fcf8d6eb0a2e3cee2a8bf42_normal.jpeg",
      "id" : 706330457,
      "verified" : false
    }
  },
  "id" : 536883900254257152,
  "created_at" : "2014-11-24 14:07:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536867779844919296",
  "geo" : { },
  "id_str" : "536883793878339584",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona congratulations!  hmm well re TESOLFr thx though maybe over-egging that one a bit i think :)",
  "id" : 536883793878339584,
  "in_reply_to_status_id" : 536867779844919296,
  "created_at" : "2014-11-24 14:07:25 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536861798583263232",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hi thanks for the two shares :) hope your soutenance went well?",
  "id" : 536861798583263232,
  "created_at" : "2014-11-24 12:40:01 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Aaron Naparstek",
      "screen_name" : "Naparstek",
      "indices" : [ 132, 140 ],
      "id_str" : "16129534",
      "id" : 16129534
    }, {
      "name" : "David Bowie",
      "screen_name" : "sociolx",
      "indices" : [ 139, 140 ],
      "id_str" : "597160060",
      "id" : 597160060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/HSW1TgfLpy",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/11\/the-positional-neutralization-of-marion-barry\/",
      "display_url" : "grieve-smith.com\/blog\/2014\/11\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536791677693075456",
  "text" : "RT @grvsmth: New post: The positional neutralization of Marion Barry, or Mary and Barry, or marionberry\u2026 http:\/\/t.co\/HSW1TgfLpy h\/t @Napars\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron Naparstek",
        "screen_name" : "Naparstek",
        "indices" : [ 119, 129 ],
        "id_str" : "16129534",
        "id" : 16129534
      }, {
        "name" : "David Bowie",
        "screen_name" : "sociolx",
        "indices" : [ 130, 138 ],
        "id_str" : "597160060",
        "id" : 597160060
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/HSW1TgfLpy",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/11\/the-positional-neutralization-of-marion-barry\/",
        "display_url" : "grieve-smith.com\/blog\/2014\/11\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "536760322422751232",
    "text" : "New post: The positional neutralization of Marion Barry, or Mary and Barry, or marionberry\u2026 http:\/\/t.co\/HSW1TgfLpy h\/t @Naparstek @sociolx",
    "id" : 536760322422751232,
    "created_at" : "2014-11-24 05:56:48 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 536791677693075456,
  "created_at" : "2014-11-24 08:01:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 0, 12 ],
      "id_str" : "273375532",
      "id" : 273375532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535824754205540354",
  "geo" : { },
  "id_str" : "536628586007265281",
  "in_reply_to_user_id" : 273375532,
  "text" : "@FryRsquared hmm dunno is this a \"ladder of evolution\" fallacy as described by Pinker?",
  "id" : 536628586007265281,
  "in_reply_to_status_id" : 535824754205540354,
  "created_at" : "2014-11-23 21:13:19 +0000",
  "in_reply_to_screen_name" : "FryRsquared",
  "in_reply_to_user_id_str" : "273375532",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536190554313220096",
  "geo" : { },
  "id_str" : "536260116451164160",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu great :) enjoy the knees-up",
  "id" : 536260116451164160,
  "in_reply_to_status_id" : 536190554313220096,
  "created_at" : "2014-11-22 20:49:09 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 54, 62 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/cZODLhlkJr",
      "expanded_url" : "http:\/\/blog.slb.coop\/2014\/11\/22\/international-tefl-survey\/",
      "display_url" : "blog.slb.coop\/2014\/11\/22\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536257397405147137",
  "text" : "International TEFL Survey  http:\/\/t.co\/cZODLhlkJr via @SLBCoop",
  "id" : 536257397405147137,
  "created_at" : "2014-11-22 20:38:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "JALT2016",
      "screen_name" : "JALTConference",
      "indices" : [ 13, 28 ],
      "id_str" : "362350959",
      "id" : 362350959
    }, {
      "name" : "Eventifier",
      "screen_name" : "Eventifier",
      "indices" : [ 29, 40 ],
      "id_str" : "574476599",
      "id" : 574476599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536188426265972736",
  "geo" : { },
  "id_str" : "536189432983195648",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu @JALTConference @Eventifier nice, i noticed about 8 corpus related talks if u go to any do write it up Peter :)",
  "id" : 536189432983195648,
  "in_reply_to_status_id" : 536188426265972736,
  "created_at" : "2014-11-22 16:08:17 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/7LM6F4nFtC",
      "expanded_url" : "http:\/\/ojs.ub.gu.se\/ojs\/index.php\/njes\/article\/viewFile\/652\/603",
      "display_url" : "ojs.ub.gu.se\/ojs\/index.php\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535591094965116930",
  "geo" : { },
  "id_str" : "535595862848966656",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall to do with existential\/dummy there, as well? apparently called frozen there's http:\/\/t.co\/7LM6F4nFtC",
  "id" : 535595862848966656,
  "in_reply_to_status_id" : 535591094965116930,
  "created_at" : "2014-11-21 00:49:39 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535586776958517248",
  "geo" : { },
  "id_str" : "535588572884389888",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall seems there is interesting interaction with contracted form v non contracted form in coca byu",
  "id" : 535588572884389888,
  "in_reply_to_status_id" : 535586776958517248,
  "created_at" : "2014-11-21 00:20:41 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 3, 11 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "edchat",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9jCXw2bQhW",
      "expanded_url" : "http:\/\/blog.slb.coop\/2014\/11\/20\/joining-cooperativa-de-serveis-linguistics-de-barcelona\/",
      "display_url" : "blog.slb.coop\/2014\/11\/20\/joi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535562412314087424",
  "text" : "RT @SLBCoop: Why I Joined Cooperativa de Serveis Ling\u00FC\u00EDstics de Barcelona http:\/\/t.co\/9jCXw2bQhW #ELT #edchat #TEFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "edchat",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/9jCXw2bQhW",
        "expanded_url" : "http:\/\/blog.slb.coop\/2014\/11\/20\/joining-cooperativa-de-serveis-linguistics-de-barcelona\/",
        "display_url" : "blog.slb.coop\/2014\/11\/20\/joi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535559836843261952",
    "text" : "Why I Joined Cooperativa de Serveis Ling\u00FC\u00EDstics de Barcelona http:\/\/t.co\/9jCXw2bQhW #ELT #edchat #TEFL",
    "id" : 535559836843261952,
    "created_at" : "2014-11-20 22:26:29 +0000",
    "user" : {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "protected" : false,
      "id_str" : "2365399801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705151471386546176\/ECVLcba-_normal.jpg",
      "id" : 2365399801,
      "verified" : false
    }
  },
  "id" : 535562412314087424,
  "created_at" : "2014-11-20 22:36:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535511421002711042",
  "geo" : { },
  "id_str" : "535532375938437120",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan hmm from a jam to a pickle :\/ Victoria Boobyer's latest comment is very eye opening about places like Vietnam",
  "id" : 535532375938437120,
  "in_reply_to_status_id" : 535511421002711042,
  "created_at" : "2014-11-20 20:37:22 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "indices" : [ 3, 18 ],
      "id_str" : "2665944684",
      "id" : 2665944684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/UVhFJwhSgK",
      "expanded_url" : "http:\/\/edtechconcerns.podomatic.com\/entry\/2014-11-17T12_38_33-08_00",
      "display_url" : "edtechconcerns.podomatic.com\/entry\/2014-11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535370142566584320",
  "text" : "RT @edtechconcerns: Have you listened to the new episode of our podcast - where do computers go to die? http:\/\/t.co\/UVhFJwhSgK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/UVhFJwhSgK",
        "expanded_url" : "http:\/\/edtechconcerns.podomatic.com\/entry\/2014-11-17T12_38_33-08_00",
        "display_url" : "edtechconcerns.podomatic.com\/entry\/2014-11-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534812331390545921",
    "text" : "Have you listened to the new episode of our podcast - where do computers go to die? http:\/\/t.co\/UVhFJwhSgK",
    "id" : 534812331390545921,
    "created_at" : "2014-11-18 20:56:10 +0000",
    "user" : {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "protected" : false,
      "id_str" : "2665944684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494409099807715329\/p9ew0Ir4_normal.jpeg",
      "id" : 2665944684,
      "verified" : false
    }
  },
  "id" : 535370142566584320,
  "created_at" : "2014-11-20 09:52:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 3, 14 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/nznuqhscTu",
      "expanded_url" : "http:\/\/SprachenNetz.org",
      "display_url" : "SprachenNetz.org"
    }, {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/tci8anvYua",
      "expanded_url" : "http:\/\/www.sprachennetz.org\/2014\/11\/language-training-in-companies-why-when-who-and-how\/",
      "display_url" : "sprachennetz.org\/2014\/11\/langua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535364072053956608",
  "text" : "RT @evanfrendo: http:\/\/t.co\/nznuqhscTu \u2013 Language training in companies: why, when, who and how? http:\/\/t.co\/tci8anvYua #besig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/nznuqhscTu",
        "expanded_url" : "http:\/\/SprachenNetz.org",
        "display_url" : "SprachenNetz.org"
      }, {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/tci8anvYua",
        "expanded_url" : "http:\/\/www.sprachennetz.org\/2014\/11\/language-training-in-companies-why-when-who-and-how\/",
        "display_url" : "sprachennetz.org\/2014\/11\/langua\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535361348981370881",
    "text" : "http:\/\/t.co\/nznuqhscTu \u2013 Language training in companies: why, when, who and how? http:\/\/t.co\/tci8anvYua #besig",
    "id" : 535361348981370881,
    "created_at" : "2014-11-20 09:17:46 +0000",
    "user" : {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "protected" : false,
      "id_str" : "17589664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267172323\/Evan_Frendo_normal.jpg",
      "id" : 17589664,
      "verified" : false
    }
  },
  "id" : 535364072053956608,
  "created_at" : "2014-11-20 09:28:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535172546581508096",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona good luck :)",
  "id" : 535172546581508096,
  "created_at" : "2014-11-19 20:47:32 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "changeinELT",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3d8668DLh5",
      "expanded_url" : "http:\/\/libcom.org\/blog\/angry-language-brigade",
      "display_url" : "libcom.org\/blog\/angry-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535110962979012608",
  "text" : "http:\/\/t.co\/3d8668DLh5 good blog on working conditions to keep an eye on #changeinELT",
  "id" : 535110962979012608,
  "created_at" : "2014-11-19 16:42:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ICAL TEFL",
      "screen_name" : "ICALTEFL",
      "indices" : [ 3, 12 ],
      "id_str" : "61521432",
      "id" : 61521432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tefl",
      "indices" : [ 143, 144 ]
    }, {
      "text" : "uk",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/VfaOokXfDN",
      "expanded_url" : "http:\/\/ow.ly\/ExysT",
      "display_url" : "ow.ly\/ExysT"
    } ]
  },
  "geo" : { },
  "id_str" : "535109504401436672",
  "text" : "RT @ICALTEFL: TEFL News: sham freelance contracts are illegal in UK TEFL schools - find out more &amp; shop your school\n http:\/\/t.co\/VfaOokXfDN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tefl",
        "indices" : [ 133, 138 ]
      }, {
        "text" : "uk",
        "indices" : [ 139, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/VfaOokXfDN",
        "expanded_url" : "http:\/\/ow.ly\/ExysT",
        "display_url" : "ow.ly\/ExysT"
      } ]
    },
    "geo" : { },
    "id_str" : "535107390652579840",
    "text" : "TEFL News: sham freelance contracts are illegal in UK TEFL schools - find out more &amp; shop your school\n http:\/\/t.co\/VfaOokXfDN  - #tefl #uk",
    "id" : 535107390652579840,
    "created_at" : "2014-11-19 16:28:38 +0000",
    "user" : {
      "name" : "ICAL TEFL",
      "screen_name" : "ICALTEFL",
      "protected" : false,
      "id_str" : "61521432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692751348631277568\/g92s6Cug_normal.jpg",
      "id" : 61521432,
      "verified" : false
    }
  },
  "id" : 535109504401436672,
  "created_at" : "2014-11-19 16:37:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 0, 8 ],
      "id_str" : "258401804",
      "id" : 258401804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535073794587906048",
  "text" : "@sjeason be interested in what you may find",
  "id" : 535073794587906048,
  "created_at" : "2014-11-19 14:15:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535072351386611712",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler ta for share Anne, that's a funky upside down thing u got going, howydothat?",
  "id" : 535072351386611712,
  "created_at" : "2014-11-19 14:09:24 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "Lexicon Valley",
      "screen_name" : "lexiconvalley",
      "indices" : [ 74, 88 ],
      "id_str" : "351299373",
      "id" : 351299373
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/SCH3bmJGY1",
      "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1VwwynA",
      "display_url" : "tmblr.co\/ZuWOEv1VwwynA"
    } ]
  },
  "in_reply_to_status_id_str" : "534851115054280705",
  "geo" : { },
  "id_str" : "534945449330102272",
  "in_reply_to_user_id" : 857291268,
  "text" : "RT @AllThingsLing Why Swearing Is Just Like Saying \u201CPlease\u201D (Sort Of) via @lexiconvalley http:\/\/t.co\/SCH3bmJGY1 #corpusmooc",
  "id" : 534945449330102272,
  "in_reply_to_status_id" : 534851115054280705,
  "created_at" : "2014-11-19 05:45:08 +0000",
  "in_reply_to_screen_name" : "AllThingsLing",
  "in_reply_to_user_id_str" : "857291268",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/xEIW3XiDUv",
      "expanded_url" : "http:\/\/chrisblattman.com\/2014\/11\/17\/positions-philosophy-science\/",
      "display_url" : "chrisblattman.com\/2014\/11\/17\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534944037245952000",
  "text" : "Positions in the philosophy of science http:\/\/t.co\/xEIW3XiDUv",
  "id" : 534944037245952000,
  "created_at" : "2014-11-19 05:39:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 16, 34 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/kPHmyOGfS0",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/1p9BUSBtW2b",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534842602613669889",
  "text" : "digging up some #corpuslinguistics tweets #corpusmooc https:\/\/t.co\/kPHmyOGfS0",
  "id" : 534842602613669889,
  "created_at" : "2014-11-18 22:56:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gFnAkbdYel",
      "expanded_url" : "http:\/\/bit.ly\/1yhZMnv",
      "display_url" : "bit.ly\/1yhZMnv"
    } ]
  },
  "geo" : { },
  "id_str" : "534830678207385602",
  "text" : "RT @CraigMurrayOrg: It Is Racist To Be Worried About Immigration: The wealthy right-winger Yvette Cooper has just been on televisi... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/gFnAkbdYel",
        "expanded_url" : "http:\/\/bit.ly\/1yhZMnv",
        "display_url" : "bit.ly\/1yhZMnv"
      } ]
    },
    "geo" : { },
    "id_str" : "534685918469160960",
    "text" : "It Is Racist To Be Worried About Immigration: The wealthy right-winger Yvette Cooper has just been on televisi... http:\/\/t.co\/gFnAkbdYel",
    "id" : 534685918469160960,
    "created_at" : "2014-11-18 12:33:51 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 534830678207385602,
  "created_at" : "2014-11-18 22:09:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 130, 140 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/vMT0P5U814",
      "expanded_url" : "http:\/\/theconversation.com\/stop-snapping-selfies-and-start-vaping-its-the-word-of-the-year-34370",
      "display_url" : "theconversation.com\/stop-snapping-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534750409370640384",
  "text" : "RT @lovermob: My response to 'vape' as Word of the Year 2014: \"Stop snapping selfies and start vaping\" http:\/\/t.co\/vMT0P5U814 via @Conversa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Conversation",
        "screen_name" : "ConversationUK",
        "indices" : [ 116, 131 ],
        "id_str" : "1241258612",
        "id" : 1241258612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/vMT0P5U814",
        "expanded_url" : "http:\/\/theconversation.com\/stop-snapping-selfies-and-start-vaping-its-the-word-of-the-year-34370",
        "display_url" : "theconversation.com\/stop-snapping-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534703971638603777",
    "text" : "My response to 'vape' as Word of the Year 2014: \"Stop snapping selfies and start vaping\" http:\/\/t.co\/vMT0P5U814 via @ConversationUK",
    "id" : 534703971638603777,
    "created_at" : "2014-11-18 13:45:35 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 534750409370640384,
  "created_at" : "2014-11-18 16:50:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534700231955189760",
  "geo" : { },
  "id_str" : "534747124165246976",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ah yeah doh thx :)",
  "id" : 534747124165246976,
  "in_reply_to_status_id" : 534700231955189760,
  "created_at" : "2014-11-18 16:37:04 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CPU WARS",
      "screen_name" : "CPUWARS",
      "indices" : [ 0, 8 ],
      "id_str" : "399064670",
      "id" : 399064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534684089476218880",
  "geo" : { },
  "id_str" : "534685038554939392",
  "in_reply_to_user_id" : 399064670,
  "text" : "@CPUWARS ok thx will keep that in mind",
  "id" : 534685038554939392,
  "in_reply_to_status_id" : 534684089476218880,
  "created_at" : "2014-11-18 12:30:21 +0000",
  "in_reply_to_screen_name" : "CPUWARS",
  "in_reply_to_user_id_str" : "399064670",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CPU WARS",
      "screen_name" : "CPUWARS",
      "indices" : [ 0, 8 ],
      "id_str" : "399064670",
      "id" : 399064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534678998371295232",
  "geo" : { },
  "id_str" : "534680949074964481",
  "in_reply_to_user_id" : 399064670,
  "text" : "@CPUWARS for sure :) ordered dynamic duo as original pack kinda worn out!",
  "id" : 534680949074964481,
  "in_reply_to_status_id" : 534678998371295232,
  "created_at" : "2014-11-18 12:14:06 +0000",
  "in_reply_to_screen_name" : "CPUWARS",
  "in_reply_to_user_id_str" : "399064670",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 0, 12 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534674245042077697",
  "geo" : { },
  "id_str" : "534674910099304448",
  "in_reply_to_user_id" : 1334451956,
  "text" : "@chuechebueb never met them before so at least they had an excuse :)  have a good 'un",
  "id" : 534674910099304448,
  "in_reply_to_status_id" : 534674245042077697,
  "created_at" : "2014-11-18 11:50:07 +0000",
  "in_reply_to_screen_name" : "chuechebueb",
  "in_reply_to_user_id_str" : "1334451956",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 0, 12 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534672789115273217",
  "geo" : { },
  "id_str" : "534673900849094656",
  "in_reply_to_user_id" : 1334451956,
  "text" : "@chuechebueb um well got mistaken for Pete Sharma and Rakesh Bhanot ;)",
  "id" : 534673900849094656,
  "in_reply_to_status_id" : 534672789115273217,
  "created_at" : "2014-11-18 11:46:06 +0000",
  "in_reply_to_screen_name" : "chuechebueb",
  "in_reply_to_user_id_str" : "1334451956",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CPU WARS",
      "screen_name" : "CPUWARS",
      "indices" : [ 5, 13 ],
      "id_str" : "399064670",
      "id" : 399064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/b7itLYMBCZ",
      "expanded_url" : "http:\/\/eu.cpuwarsthegame.com\/shop\/volume-2",
      "display_url" : "eu.cpuwarsthegame.com\/shop\/volume-2"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/ctgbvIniuY",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/02\/11\/cpu",
      "display_url" : "eflnotes.wordpress.com\/2013\/02\/11\/cpu"
    } ]
  },
  "geo" : { },
  "id_str" : "534671907023777794",
  "text" : "woot @CPUWARS vol 2 is out http:\/\/t.co\/b7itLYMBCZ with booster cards nice! &amp; backward compat vol1, read use in class http:\/\/t.co\/ctgbvIniuY",
  "id" : 534671907023777794,
  "created_at" : "2014-11-18 11:38:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/SeBVztH3wv",
      "expanded_url" : "http:\/\/tachesdesens.blogspot.com\/2014\/11\/give-me-money.html?spref=tw",
      "display_url" : "tachesdesens.blogspot.com\/2014\/11\/give-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534662029823311872",
  "text" : "touches of sense...: Give me money. http:\/\/t.co\/SeBVztH3wv",
  "id" : 534662029823311872,
  "created_at" : "2014-11-18 10:58:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 0, 12 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 94, 105 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ZrpsZyVpKi",
      "expanded_url" : "http:\/\/resig.weebly.com\/blog\/17-30-november-article-discussion-managing-innovation-in-english-language-education-a-research-agenda-language-teaching-471-92-110",
      "display_url" : "resig.weebly.com\/blog\/17-30-nov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534652953937051648",
  "in_reply_to_user_id" : 335823604,
  "text" : "@IATEFLResig discussion on innovation started http:\/\/t.co\/ZrpsZyVpKi maybe of interest recent #eltchinwag #keltchat",
  "id" : 534652953937051648,
  "created_at" : "2014-11-18 10:22:52 +0000",
  "in_reply_to_screen_name" : "IATEFLResig",
  "in_reply_to_user_id_str" : "335823604",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "videogrep",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 99, 110 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/plqzf0TkO4",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/09\/26\/easy-micro-listenings\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/09\/26\/eas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534646257554563072",
  "text" : "quick update of #videogrep and micro-listenings http:\/\/t.co\/plqzf0TkO4 maybe of interest to recent #eltchinwag &amp; #keltchat",
  "id" : 534646257554563072,
  "created_at" : "2014-11-18 09:56:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534632735051378688",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras hi thank you for RT, hope u enjoyed paris :)",
  "id" : 534632735051378688,
  "created_at" : "2014-11-18 09:02:31 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CORPUSMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/ZhW6HDsMGl",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1CR",
      "display_url" : "wp.me\/p39dN1-1CR"
    } ]
  },
  "geo" : { },
  "id_str" : "534617341808877568",
  "text" : "RT @drbexl: #CORPUSMOOC: Week 8: A Swearing\u00A0Extravaganza http:\/\/t.co\/ZhW6HDsMGl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CORPUSMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/ZhW6HDsMGl",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1CR",
        "display_url" : "wp.me\/p39dN1-1CR"
      } ]
    },
    "geo" : { },
    "id_str" : "534353715608555520",
    "text" : "#CORPUSMOOC: Week 8: A Swearing\u00A0Extravaganza http:\/\/t.co\/ZhW6HDsMGl",
    "id" : 534353715608555520,
    "created_at" : "2014-11-17 14:33:48 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 534617341808877568,
  "created_at" : "2014-11-18 08:01:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/uV6YdoK4IG",
      "expanded_url" : "http:\/\/skell.sketchengine.co.uk",
      "display_url" : "skell.sketchengine.co.uk"
    }, {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/QGWZhsFFgJ",
      "expanded_url" : "http:\/\/bit.ly\/aboutskell",
      "display_url" : "bit.ly\/aboutskell"
    } ]
  },
  "geo" : { },
  "id_str" : "534485530474708992",
  "text" : "RT @SketchEngine: SkELL: Sketch Engine for Language Learning. For students &amp; teachers and for free! http:\/\/t.co\/uV6YdoK4IG more info http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/uV6YdoK4IG",
        "expanded_url" : "http:\/\/skell.sketchengine.co.uk",
        "display_url" : "skell.sketchengine.co.uk"
      }, {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/QGWZhsFFgJ",
        "expanded_url" : "http:\/\/bit.ly\/aboutskell",
        "display_url" : "bit.ly\/aboutskell"
      } ]
    },
    "geo" : { },
    "id_str" : "534367716514480129",
    "text" : "SkELL: Sketch Engine for Language Learning. For students &amp; teachers and for free! http:\/\/t.co\/uV6YdoK4IG more info http:\/\/t.co\/QGWZhsFFgJ",
    "id" : 534367716514480129,
    "created_at" : "2014-11-17 15:29:26 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 534485530474708992,
  "created_at" : "2014-11-17 23:17:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 16, 23 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtheword",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/7eDu47hLj1",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/07\/02\/just-the-word-alternatives-function-or-how-to-introduce-concordances-to-your-students\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/07\/02\/jus\u2026"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/mx1EEDw866",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/10\/21\/interview-with-phil-edmonds-from-just-the-word-com\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/10\/21\/int\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534460111381868545",
  "geo" : { },
  "id_str" : "534461328359186434",
  "in_reply_to_user_id" : 116954342,
  "text" : "@cellointensive @EdLaur have post on #justtheword http:\/\/t.co\/7eDu47hLj1 and interview with developer http:\/\/t.co\/mx1EEDw866 #eltchinwag",
  "id" : 534461328359186434,
  "in_reply_to_status_id" : 534460111381868545,
  "created_at" : "2014-11-17 21:41:25 +0000",
  "in_reply_to_screen_name" : "LJ_Tyrrell",
  "in_reply_to_user_id_str" : "116954342",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534460745267027970",
  "text" : "#eltchinwag thx all",
  "id" : 534460745267027970,
  "created_at" : "2014-11-17 21:39:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 20, 27 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 28, 39 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534460698857078784",
  "text" : "RT @cellointensive: @EdLaur @ELTIreland we'll see.. I'm not anti-tech, I just don't know if apps are better\/faster\/easier than what I do no\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Edwards",
        "screen_name" : "EdLaur",
        "indices" : [ 0, 7 ],
        "id_str" : "1834826917",
        "id" : 1834826917
      }, {
        "name" : "ELT IRELAND",
        "screen_name" : "ELTIreland",
        "indices" : [ 8, 19 ],
        "id_str" : "2289260958",
        "id" : 2289260958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchinwag",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "534460041680924673",
    "geo" : { },
    "id_str" : "534460409341018112",
    "in_reply_to_user_id" : 1834826917,
    "text" : "@EdLaur @ELTIreland we'll see.. I'm not anti-tech, I just don't know if apps are better\/faster\/easier than what I do now.. #eltchinwag",
    "id" : 534460409341018112,
    "in_reply_to_status_id" : 534460041680924673,
    "created_at" : "2014-11-17 21:37:46 +0000",
    "in_reply_to_screen_name" : "EdLaur",
    "in_reply_to_user_id_str" : "1834826917",
    "user" : {
      "name" : "Call me, Ishmael",
      "screen_name" : "LJ_Tyrrell",
      "protected" : false,
      "id_str" : "116954342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682965149880336388\/-8iBt5YV_normal.jpg",
      "id" : 116954342,
      "verified" : false
    }
  },
  "id" : 534460698857078784,
  "created_at" : "2014-11-17 21:38:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Call me, Ishmael",
      "screen_name" : "cellointensive",
      "indices" : [ 3, 18 ],
      "id_str" : "116954342",
      "id" : 116954342
    }, {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 20, 28 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 29, 36 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 37, 45 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534456690750808064",
  "text" : "RT @cellointensive: @LahiffP @EdLaur @ITLegge True.. but do they help us to teach them anything? Are they more effective for learning? #elt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Lahiff",
        "screen_name" : "LahiffP",
        "indices" : [ 0, 8 ],
        "id_str" : "279078759",
        "id" : 279078759
      }, {
        "name" : "Laura Edwards",
        "screen_name" : "EdLaur",
        "indices" : [ 9, 16 ],
        "id_str" : "1834826917",
        "id" : 1834826917
      }, {
        "name" : "Helen Legge",
        "screen_name" : "ITLegge",
        "indices" : [ 17, 25 ],
        "id_str" : "2201561838",
        "id" : 2201561838
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchinwag",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "534455554463510528",
    "geo" : { },
    "id_str" : "534456049424957442",
    "in_reply_to_user_id" : 279078759,
    "text" : "@LahiffP @EdLaur @ITLegge True.. but do they help us to teach them anything? Are they more effective for learning? #eltchinwag",
    "id" : 534456049424957442,
    "in_reply_to_status_id" : 534455554463510528,
    "created_at" : "2014-11-17 21:20:26 +0000",
    "in_reply_to_screen_name" : "LahiffP",
    "in_reply_to_user_id_str" : "279078759",
    "user" : {
      "name" : "Call me, Ishmael",
      "screen_name" : "LJ_Tyrrell",
      "protected" : false,
      "id_str" : "116954342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682965149880336388\/-8iBt5YV_normal.jpg",
      "id" : 116954342,
      "verified" : false
    }
  },
  "id" : 534456690750808064,
  "created_at" : "2014-11-17 21:22:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apps4efl",
      "indices" : [ 16, 25 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/xmVIyYABO8",
      "expanded_url" : "http:\/\/www.apps4efl.com\/",
      "display_url" : "apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "534452253890183168",
  "text" : "have showed sts #apps4efl http:\/\/t.co\/xmVIyYABO8 in particular sentence builder, got good reactions to it #eltchinwag",
  "id" : 534452253890183168,
  "created_at" : "2014-11-17 21:05:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 0, 8 ],
      "id_str" : "279078759",
      "id" : 279078759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/plqzf0TkO4",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/09\/26\/easy-micro-listenings\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/09\/26\/eas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534449038670983168",
  "geo" : { },
  "id_str" : "534450137398247424",
  "in_reply_to_user_id" : 279078759,
  "text" : "@LahiffP here is a post on it http:\/\/t.co\/plqzf0TkO4 #eltchinwag @cellointensive",
  "id" : 534450137398247424,
  "in_reply_to_status_id" : 534449038670983168,
  "created_at" : "2014-11-17 20:56:57 +0000",
  "in_reply_to_screen_name" : "LahiffP",
  "in_reply_to_user_id_str" : "279078759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 0, 8 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 9, 17 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534449038670983168",
  "geo" : { },
  "id_str" : "534449661961314304",
  "in_reply_to_user_id" : 279078759,
  "text" : "@LahiffP @ITLegge dunno what is Croak?",
  "id" : 534449661961314304,
  "in_reply_to_status_id" : 534449038670983168,
  "created_at" : "2014-11-17 20:55:03 +0000",
  "in_reply_to_screen_name" : "LahiffP",
  "in_reply_to_user_id_str" : "279078759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534448732587433984",
  "geo" : { },
  "id_str" : "534449578960228352",
  "in_reply_to_user_id" : 116954342,
  "text" : "@cellointensive it's like Honey I shrunk my student.. :)",
  "id" : 534449578960228352,
  "in_reply_to_status_id" : 534448732587433984,
  "created_at" : "2014-11-17 20:54:43 +0000",
  "in_reply_to_screen_name" : "LJ_Tyrrell",
  "in_reply_to_user_id_str" : "116954342",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/plqzf0TkO4",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/09\/26\/easy-micro-listenings\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/09\/26\/eas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534448460381306880",
  "geo" : { },
  "id_str" : "534449227796344832",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge have used it in 1to1 classes &amp; so allows tailor listenings based on student interest u can read more here http:\/\/t.co\/plqzf0TkO4",
  "id" : 534449227796344832,
  "in_reply_to_status_id" : 534448460381306880,
  "created_at" : "2014-11-17 20:53:20 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "videogrep",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534447902593396737",
  "text" : "#eltchinwag hi all, one of my most recent &amp; fav programs is #videogrep to make micro-listenings",
  "id" : 534447902593396737,
  "created_at" : "2014-11-17 20:48:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyscot",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/S6xX3lHLso",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/11\/defending-old-formulas-establishment.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/11\/defend\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534445352867622913",
  "text" : "RT @johnwhilley: Defending old formulas - the establishment-left keeping real radicalism in its box http:\/\/t.co\/S6xX3lHLso #indyscot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyscot",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/S6xX3lHLso",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/11\/defending-old-formulas-establishment.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/11\/defend\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534397176395612160",
    "text" : "Defending old formulas - the establishment-left keeping real radicalism in its box http:\/\/t.co\/S6xX3lHLso #indyscot",
    "id" : 534397176395612160,
    "created_at" : "2014-11-17 17:26:30 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 534445352867622913,
  "created_at" : "2014-11-17 20:37:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "indices" : [ 3, 18 ],
      "id_str" : "186543637",
      "id" : 186543637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/5t9x4v5Zyz",
      "expanded_url" : "http:\/\/nastyageinrikh.blogspot.com\/2014\/11\/my-experience-with-language-schools-in_16.html?spref=tw",
      "display_url" : "nastyageinrikh.blogspot.com\/2014\/11\/my-exp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534433013560786944",
  "text" : "RT @nastyageinrikh: My experience with language schools in Russia: Part II http:\/\/t.co\/5t9x4v5Zyz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/5t9x4v5Zyz",
        "expanded_url" : "http:\/\/nastyageinrikh.blogspot.com\/2014\/11\/my-experience-with-language-schools-in_16.html?spref=tw",
        "display_url" : "nastyageinrikh.blogspot.com\/2014\/11\/my-exp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534417706200465409",
    "text" : "My experience with language schools in Russia: Part II http:\/\/t.co\/5t9x4v5Zyz",
    "id" : 534417706200465409,
    "created_at" : "2014-11-17 18:48:04 +0000",
    "user" : {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "protected" : false,
      "id_str" : "186543637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512265956534415361\/h5IEpCPu_normal.jpeg",
      "id" : 186543637,
      "verified" : false
    }
  },
  "id" : 534433013560786944,
  "created_at" : "2014-11-17 19:48:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534432924226301952",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter cheers for sharing post John :)",
  "id" : 534432924226301952,
  "created_at" : "2014-11-17 19:48:33 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Piergiovanni",
      "screen_name" : "chocolat3b",
      "indices" : [ 3, 14 ],
      "id_str" : "56192984",
      "id" : 56192984
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PirateBox",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Y4i6KhuoiJ",
      "expanded_url" : "http:\/\/iamarf.org\/pagine-utili-per-il-laboratorio-loptis\/scheda-piratebox\/",
      "display_url" : "iamarf.org\/pagine-utili-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534432512186257409",
  "text" : "RT @chocolat3b: La #PirateBox nelle scuole.\nIl progetto qui http:\/\/t.co\/Y4i6KhuoiJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PirateBox",
        "indices" : [ 3, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Y4i6KhuoiJ",
        "expanded_url" : "http:\/\/iamarf.org\/pagine-utili-per-il-laboratorio-loptis\/scheda-piratebox\/",
        "display_url" : "iamarf.org\/pagine-utili-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "533657218038890496",
    "text" : "La #PirateBox nelle scuole.\nIl progetto qui http:\/\/t.co\/Y4i6KhuoiJ",
    "id" : 533657218038890496,
    "created_at" : "2014-11-15 16:26:10 +0000",
    "user" : {
      "name" : "Luca Piergiovanni",
      "screen_name" : "chocolat3b",
      "protected" : false,
      "id_str" : "56192984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682601956880302080\/ucKh48So_normal.jpg",
      "id" : 56192984,
      "verified" : false
    }
  },
  "id" : 534432512186257409,
  "created_at" : "2014-11-17 19:46:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfrance",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "tesolfr",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "piratebox",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/GFrVvAxjOS",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-PZ",
      "display_url" : "wp.me\/pgHyE-PZ"
    } ]
  },
  "geo" : { },
  "id_str" : "534402765254963201",
  "text" : "TESOL France 2014 - thoughts, poster, handout and links #tesolfrance #tesolfr #piratebox http:\/\/t.co\/GFrVvAxjOS",
  "id" : 534402765254963201,
  "created_at" : "2014-11-17 17:48:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 111, 122 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/C9U8wxJLHJ",
      "expanded_url" : "http:\/\/wp.me\/p5jIIo-1X",
      "display_url" : "wp.me\/p5jIIo-1X"
    } ]
  },
  "geo" : { },
  "id_str" : "534061923931680768",
  "text" : "Using the Corpus in First-Year Writing: Combining Top-down and bottom-up approaches http:\/\/t.co\/C9U8wxJLHJ via @esl_robert",
  "id" : 534061923931680768,
  "created_at" : "2014-11-16 19:14:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "indices" : [ 3, 13 ],
      "id_str" : "54518314",
      "id" : 54518314
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "elt",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "esl",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/75D1aVu6fA",
      "expanded_url" : "http:\/\/bit.ly\/1y8mQoy",
      "display_url" : "bit.ly\/1y8mQoy"
    } ]
  },
  "geo" : { },
  "id_str" : "534060475739541504",
  "text" : "RT @sarah_SKB: How language learners can benefit from corpora, or not http:\/\/t.co\/75D1aVu6fA #efl #elt #esl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 78, 82 ]
      }, {
        "text" : "elt",
        "indices" : [ 83, 87 ]
      }, {
        "text" : "esl",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/75D1aVu6fA",
        "expanded_url" : "http:\/\/bit.ly\/1y8mQoy",
        "display_url" : "bit.ly\/1y8mQoy"
      } ]
    },
    "geo" : { },
    "id_str" : "534056926414651392",
    "text" : "How language learners can benefit from corpora, or not http:\/\/t.co\/75D1aVu6fA #efl #elt #esl",
    "id" : 534056926414651392,
    "created_at" : "2014-11-16 18:54:28 +0000",
    "user" : {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "protected" : false,
      "id_str" : "54518314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588366145771675649\/KkEbcMKN_normal.jpg",
      "id" : 54518314,
      "verified" : false
    }
  },
  "id" : 534060475739541504,
  "created_at" : "2014-11-16 19:08:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "indices" : [ 3, 13 ],
      "id_str" : "54518314",
      "id" : 54518314
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 65, 69 ]
    }, {
      "text" : "elt",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "esl",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/wGCzncXg5m",
      "expanded_url" : "http:\/\/bit.ly\/1tYpnNL",
      "display_url" : "bit.ly\/1tYpnNL"
    } ]
  },
  "geo" : { },
  "id_str" : "534060459914063872",
  "text" : "RT @sarah_SKB: Grammatical creativity in the writing of advanced #efl learners http:\/\/t.co\/wGCzncXg5m #elt #esl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 50, 54 ]
      }, {
        "text" : "elt",
        "indices" : [ 87, 91 ]
      }, {
        "text" : "esl",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/wGCzncXg5m",
        "expanded_url" : "http:\/\/bit.ly\/1tYpnNL",
        "display_url" : "bit.ly\/1tYpnNL"
      } ]
    },
    "geo" : { },
    "id_str" : "534053140081831938",
    "text" : "Grammatical creativity in the writing of advanced #efl learners http:\/\/t.co\/wGCzncXg5m #elt #esl",
    "id" : 534053140081831938,
    "created_at" : "2014-11-16 18:39:25 +0000",
    "user" : {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "protected" : false,
      "id_str" : "54518314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588366145771675649\/KkEbcMKN_normal.jpg",
      "id" : 54518314,
      "verified" : false
    }
  },
  "id" : 534060459914063872,
  "created_at" : "2014-11-16 19:08:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Colin",
      "screen_name" : "Catherine_Colin",
      "indices" : [ 0, 16 ],
      "id_str" : "324881798",
      "id" : 324881798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534014428711104512",
  "geo" : { },
  "id_str" : "534036700759339008",
  "in_reply_to_user_id" : 324881798,
  "text" : "@Catherine_Colin i can recommend his templates &amp; advice :)",
  "id" : 534036700759339008,
  "in_reply_to_status_id" : 534014428711104512,
  "created_at" : "2014-11-16 17:34:06 +0000",
  "in_reply_to_screen_name" : "Catherine_Colin",
  "in_reply_to_user_id_str" : "324881798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 52, 63 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533996336824479744",
  "geo" : { },
  "id_str" : "534027305123717121",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell hi Ela thx for the news! :) shoutout to @kevchanwow for grt feedback on initial poster, have a safe trip back home Ela",
  "id" : 534027305123717121,
  "in_reply_to_status_id" : 533996336824479744,
  "created_at" : "2014-11-16 16:56:45 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/533955257278025728\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/7V2qf1141t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2j9egLIAAAfaew.jpg",
      "id_str" : "533955256317902848",
      "id" : 533955256317902848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2j9egLIAAAfaew.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7V2qf1141t"
    } ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "tesolfrance",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533955257278025728",
  "text" : "English Teaching Survey of trainers in France #tesolfr #tesolfrance http:\/\/t.co\/7V2qf1141t",
  "id" : 533955257278025728,
  "created_at" : "2014-11-16 12:10:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/niXpFhhVg5",
      "expanded_url" : "http:\/\/youtu.be\/ZqDt2isALig?list=PLopNvIwb2dEXB56Ye3c0rFR3TtjQ1UF8z",
      "display_url" : "youtu.be\/ZqDt2isALig?li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533890984476942337",
  "text" : "RT @i_narrator: First &amp; Second Language Acquisition - Marjo Mitsutomi &amp; Minna Kirjavainen: http:\/\/t.co\/niXpFhhVg5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/niXpFhhVg5",
        "expanded_url" : "http:\/\/youtu.be\/ZqDt2isALig?list=PLopNvIwb2dEXB56Ye3c0rFR3TtjQ1UF8z",
        "display_url" : "youtu.be\/ZqDt2isALig?li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "533809769446768641",
    "text" : "First &amp; Second Language Acquisition - Marjo Mitsutomi &amp; Minna Kirjavainen: http:\/\/t.co\/niXpFhhVg5",
    "id" : 533809769446768641,
    "created_at" : "2014-11-16 02:32:21 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 533890984476942337,
  "created_at" : "2014-11-16 07:55:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UK",
      "indices" : [ 77, 80 ]
    }, {
      "text" : "censorship",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/WIPZlINQh9",
      "expanded_url" : "http:\/\/ow.ly\/EkWTR",
      "display_url" : "ow.ly\/EkWTR"
    } ]
  },
  "geo" : { },
  "id_str" : "533887024487337984",
  "text" : "RT @patrickDurusau: UK to stop its citizens seeing extremist material online #UK #censorship http:\/\/t.co\/WIPZlINQh9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UK",
        "indices" : [ 57, 60 ]
      }, {
        "text" : "censorship",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/WIPZlINQh9",
        "expanded_url" : "http:\/\/ow.ly\/EkWTR",
        "display_url" : "ow.ly\/EkWTR"
      } ]
    },
    "geo" : { },
    "id_str" : "533816798643503105",
    "text" : "UK to stop its citizens seeing extremist material online #UK #censorship http:\/\/t.co\/WIPZlINQh9",
    "id" : 533816798643503105,
    "created_at" : "2014-11-16 03:00:17 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 533887024487337984,
  "created_at" : "2014-11-16 07:39:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 67, 77 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/AZ9Wf5CXeF",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-7X",
      "display_url" : "wp.me\/p3sNrs-7X"
    } ]
  },
  "geo" : { },
  "id_str" : "533886439662972928",
  "text" : "55% 38% 7% - Busting the Mehrabian myth http:\/\/t.co\/AZ9Wf5CXeF via @adi_rajan",
  "id" : 533886439662972928,
  "created_at" : "2014-11-16 07:37:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Lp1aU4IL79",
      "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1VhFHTM",
      "display_url" : "tmblr.co\/ZuWOEv1VhFHTM"
    } ]
  },
  "geo" : { },
  "id_str" : "533886190744006656",
  "text" : "RT @AllThingsLing: The Dangerous Ambiguity of Prepositions, explained as a scene from an action movie. Awesome. http:\/\/t.co\/Lp1aU4IL79",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Lp1aU4IL79",
        "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1VhFHTM",
        "display_url" : "tmblr.co\/ZuWOEv1VhFHTM"
      } ]
    },
    "geo" : { },
    "id_str" : "533764042989797376",
    "text" : "The Dangerous Ambiguity of Prepositions, explained as a scene from an action movie. Awesome. http:\/\/t.co\/Lp1aU4IL79",
    "id" : 533764042989797376,
    "created_at" : "2014-11-15 23:30:39 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 533886190744006656,
  "created_at" : "2014-11-16 07:36:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/XOpYdwBGdA",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1416077409.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533751807617425408",
  "text" : "Snowmail...Putin in a huff...short email to Cathy Newman http:\/\/t.co\/XOpYdwBGdA",
  "id" : 533751807617425408,
  "created_at" : "2014-11-15 22:42:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/533576826950811648\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Ue30STbBs9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2elS6iCQAAXsKi.jpg",
      "id_str" : "533576825234931712",
      "id" : 533576825234931712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2elS6iCQAAXsKi.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ue30STbBs9"
    } ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "tesolfrance",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533576826950811648",
  "text" : "Recurring grammar points in TOEIC #tesolfr #tesolfrance Miles Craven http:\/\/t.co\/Ue30STbBs9",
  "id" : 533576826950811648,
  "created_at" : "2014-11-15 11:06:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "indices" : [ 3, 12 ],
      "id_str" : "21451640",
      "id" : 21451640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/mQUcg55uqn",
      "expanded_url" : "http:\/\/davidwrightlinguist.wordpress.com\/",
      "display_url" : "davidwrightlinguist.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "533530513504751616",
  "text" : "RT @WrightDW: I did a blog post. A quick #corpus analysis: When did Dapper Laughs become a 'character'? \n\nhttp:\/\/t.co\/mQUcg55uqn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/mQUcg55uqn",
        "expanded_url" : "http:\/\/davidwrightlinguist.wordpress.com\/",
        "display_url" : "davidwrightlinguist.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "533347862588170240",
    "text" : "I did a blog post. A quick #corpus analysis: When did Dapper Laughs become a 'character'? \n\nhttp:\/\/t.co\/mQUcg55uqn",
    "id" : 533347862588170240,
    "created_at" : "2014-11-14 19:56:54 +0000",
    "user" : {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "protected" : false,
      "id_str" : "21451640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640879905828413441\/nAGX4y8Z_normal.jpg",
      "id" : 21451640,
      "verified" : false
    }
  },
  "id" : 533530513504751616,
  "created_at" : "2014-11-15 08:02:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533300922139828225",
  "geo" : { },
  "id_str" : "533352083538608128",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako cheers for sharing Marie :)",
  "id" : 533352083538608128,
  "in_reply_to_status_id" : 533300922139828225,
  "created_at" : "2014-11-14 20:13:40 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533279006913597441",
  "geo" : { },
  "id_str" : "533351765895553024",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword sure, an exciting development :)",
  "id" : 533351765895553024,
  "in_reply_to_status_id" : 533279006913597441,
  "created_at" : "2014-11-14 20:12:24 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533351557199585281",
  "text" : "Krashen paraphrase: Hyland, Swales great work but can't teach it, compelling comp input great work but don't ask me how to teach it #tesolfr",
  "id" : 533351557199585281,
  "created_at" : "2014-11-14 20:11:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hack Education",
      "screen_name" : "hackeducation",
      "indices" : [ 69, 83 ],
      "id_str" : "149029700",
      "id" : 149029700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/UPY9ybwcO1",
      "expanded_url" : "http:\/\/hackeducation.com\/2014\/11\/13\/convivial-tools-in-an-age-of-surveillance\/",
      "display_url" : "hackeducation.com\/2014\/11\/13\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533260184253001729",
  "text" : "Convivial Tools in an Age of Surveillance http:\/\/t.co\/UPY9ybwcO1 via @hackeducation",
  "id" : 533260184253001729,
  "created_at" : "2014-11-14 14:08:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Driver",
      "screen_name" : "Paul_Driver",
      "indices" : [ 3, 15 ],
      "id_str" : "21322269",
      "id" : 21322269
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 98, 105 ]
    }, {
      "text" : "mlearning",
      "indices" : [ 106, 116 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "ltsig",
      "indices" : [ 126, 132 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 133, 140 ]
    }, {
      "text" : "IATEFL_ltsig",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/t7PxcqujHl",
      "expanded_url" : "http:\/\/www.digitalv.net",
      "display_url" : "digitalv.net"
    } ]
  },
  "geo" : { },
  "id_str" : "533256874691657728",
  "text" : "RT @Paul_Driver: Just started this up. Take a peek. Feedback very welcome: http:\/\/t.co\/t7PxcqujHl #edtech #mlearning #eltchat #ltsig #iatef\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "mlearning",
        "indices" : [ 89, 99 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 100, 108 ]
      }, {
        "text" : "ltsig",
        "indices" : [ 109, 115 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 116, 123 ]
      }, {
        "text" : "IATEFL_ltsig",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/t7PxcqujHl",
        "expanded_url" : "http:\/\/www.digitalv.net",
        "display_url" : "digitalv.net"
      } ]
    },
    "geo" : { },
    "id_str" : "533227068159692800",
    "text" : "Just started this up. Take a peek. Feedback very welcome: http:\/\/t.co\/t7PxcqujHl #edtech #mlearning #eltchat #ltsig #iatefl #IATEFL_ltsig",
    "id" : 533227068159692800,
    "created_at" : "2014-11-14 11:56:54 +0000",
    "user" : {
      "name" : "Paul Driver",
      "screen_name" : "Paul_Driver",
      "protected" : false,
      "id_str" : "21322269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1916561694\/228183_1524899301611_1808508082_900722_969551_n_normal.jpg",
      "id" : 21322269,
      "verified" : false
    }
  },
  "id" : 533256874691657728,
  "created_at" : "2014-11-14 13:55:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 3, 16 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/bsPet1CL8n",
      "expanded_url" : "http:\/\/wp.me\/p3Amm5-at",
      "display_url" : "wp.me\/p3Amm5-at"
    } ]
  },
  "geo" : { },
  "id_str" : "533249288042999808",
  "text" : "RT @SpeechEvents: New on Media Dictionary of Sociolinguistics: Cookie Monster and dialect: http:\/\/t.co\/bsPet1CL8n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/bsPet1CL8n",
        "expanded_url" : "http:\/\/wp.me\/p3Amm5-at",
        "display_url" : "wp.me\/p3Amm5-at"
      } ]
    },
    "geo" : { },
    "id_str" : "533239047070953472",
    "text" : "New on Media Dictionary of Sociolinguistics: Cookie Monster and dialect: http:\/\/t.co\/bsPet1CL8n",
    "id" : 533239047070953472,
    "created_at" : "2014-11-14 12:44:30 +0000",
    "user" : {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "protected" : false,
      "id_str" : "1468444922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3729332116\/c5daff60aafa706dfbacc59efc00bcf8_normal.jpeg",
      "id" : 1468444922,
      "verified" : false
    }
  },
  "id" : 533249288042999808,
  "created_at" : "2014-11-14 13:25:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/d9DziZcwKP",
      "expanded_url" : "http:\/\/mailman.uib.no\/public\/corpora\/2014-November\/021450.html",
      "display_url" : "mailman.uib.no\/public\/corpora\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533231871195631617",
  "text" : "heads up looks what's coming soon http:\/\/t.co\/d9DziZcwKP #CorpusMOOC very nice :)",
  "id" : 533231871195631617,
  "created_at" : "2014-11-14 12:15:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Week",
      "screen_name" : "TheWeek",
      "indices" : [ 56, 64 ],
      "id_str" : "16439471",
      "id" : 16439471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/bkntdeJzcv",
      "expanded_url" : "http:\/\/theweek.com\/article\/index\/271817\/why-so-strangely-yoda-speaks",
      "display_url" : "theweek.com\/article\/index\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533133670450610177",
  "text" : "Why so strangely Yoda speaks http:\/\/t.co\/bkntdeJzcv via @TheWeek",
  "id" : 533133670450610177,
  "created_at" : "2014-11-14 05:45:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tefl",
      "indices" : [ 64, 69 ]
    }, {
      "text" : "esl",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "elt",
      "indices" : [ 75, 79 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "CorpusMOOC",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/qUuzWnIF83",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/11\/14\/a-tipple-of-the-ted-corpus-search-engine\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/11\/14\/a-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533043064999514112",
  "text" : "A tipple of the TED Corpus Search Engine http:\/\/t.co\/qUuzWnIF83 #tefl #esl #elt #eltchat #CorpusMOOC",
  "id" : 533043064999514112,
  "created_at" : "2014-11-13 23:45:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 28, 35 ]
    }, {
      "text" : "piratebox",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "elt",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "edu",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "ESL",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/zR9HjmdDjS",
      "expanded_url" : "http:\/\/wp.me\/p59670-AW",
      "display_url" : "wp.me\/p59670-AW"
    } ]
  },
  "geo" : { },
  "id_str" : "532991563530784768",
  "text" : "RT @josipa74: decentralised #edtech - #piratebox! http:\/\/t.co\/zR9HjmdDjS Share files w\/ your learners without internet! #elt #edu #ESL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "piratebox",
        "indices" : [ 24, 34 ]
      }, {
        "text" : "elt",
        "indices" : [ 106, 110 ]
      }, {
        "text" : "edu",
        "indices" : [ 111, 115 ]
      }, {
        "text" : "ESL",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/zR9HjmdDjS",
        "expanded_url" : "http:\/\/wp.me\/p59670-AW",
        "display_url" : "wp.me\/p59670-AW"
      } ]
    },
    "geo" : { },
    "id_str" : "532935087596519424",
    "text" : "decentralised #edtech - #piratebox! http:\/\/t.co\/zR9HjmdDjS Share files w\/ your learners without internet! #elt #edu #ESL",
    "id" : 532935087596519424,
    "created_at" : "2014-11-13 16:36:41 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 532991563530784768,
  "created_at" : "2014-11-13 20:21:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "indices" : [ 0, 15 ],
      "id_str" : "186543637",
      "id" : 186543637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532804107166576640",
  "geo" : { },
  "id_str" : "532885714795790337",
  "in_reply_to_user_id" : 186543637,
  "text" : "@nastyageinrikh pleasure looking fwd to part 2 :)",
  "id" : 532885714795790337,
  "in_reply_to_status_id" : 532804107166576640,
  "created_at" : "2014-11-13 13:20:29 +0000",
  "in_reply_to_screen_name" : "nastyageinrikh",
  "in_reply_to_user_id_str" : "186543637",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 96, 105 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/UNBzwDFL4F",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-4Q",
      "display_url" : "wp.me\/p28EmH-4Q"
    } ]
  },
  "geo" : { },
  "id_str" : "532882400645103617",
  "text" : "Easy listening: getting started with audio in the language classroom http:\/\/t.co\/UNBzwDFL4F via @whyshona",
  "id" : 532882400645103617,
  "created_at" : "2014-11-13 13:07:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Econsultancy",
      "screen_name" : "Econsultancy",
      "indices" : [ 0, 13 ],
      "id_str" : "11833202",
      "id" : 11833202
    }, {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 14, 21 ],
      "id_str" : "190569306",
      "id" : 190569306
    }, {
      "name" : "Alastair Campbell",
      "screen_name" : "campbellclaret",
      "indices" : [ 22, 37 ],
      "id_str" : "19644592",
      "id" : 19644592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532830741173133312",
  "geo" : { },
  "id_str" : "532833631816134656",
  "in_reply_to_user_id" : 11833202,
  "text" : "@Econsultancy @WordLo @campbellclaret seems people still feel we have lots to learn from dodgy dossier experts",
  "id" : 532833631816134656,
  "in_reply_to_status_id" : 532830741173133312,
  "created_at" : "2014-11-13 09:53:32 +0000",
  "in_reply_to_screen_name" : "Econsultancy",
  "in_reply_to_user_id_str" : "11833202",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/mrethZybYX",
      "expanded_url" : "http:\/\/ow.ly\/DVrSJ",
      "display_url" : "ow.ly\/DVrSJ"
    } ]
  },
  "geo" : { },
  "id_str" : "532644027406233600",
  "text" : "RT @umasslinguistic: Links between grammar, rhythm explored by researchers http:\/\/t.co\/mrethZybYX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/mrethZybYX",
        "expanded_url" : "http:\/\/ow.ly\/DVrSJ",
        "display_url" : "ow.ly\/DVrSJ"
      } ]
    },
    "geo" : { },
    "id_str" : "532636542423273474",
    "text" : "Links between grammar, rhythm explored by researchers http:\/\/t.co\/mrethZybYX",
    "id" : 532636542423273474,
    "created_at" : "2014-11-12 20:50:22 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 532644027406233600,
  "created_at" : "2014-11-12 21:20:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 105, 117 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/CF8TLgNVg5",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-8q6",
      "display_url" : "wp.me\/p1U04a-8q6"
    } ]
  },
  "geo" : { },
  "id_str" : "532640657144180736",
  "text" : "See Channel 4 News economics editor get angry on camera over criminal bankers http:\/\/t.co\/CF8TLgNVg5 via @ThomasPride",
  "id" : 532640657144180736,
  "created_at" : "2014-11-12 21:06:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 75, 88 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/X5IyY5pY6j",
      "expanded_url" : "http:\/\/wp.me\/p3Amm5-9e",
      "display_url" : "wp.me\/p3Amm5-9e"
    } ]
  },
  "geo" : { },
  "id_str" : "532639779569934336",
  "text" : "Ghostbusters, \"linguistics,\" and \"anthropology\" http:\/\/t.co\/X5IyY5pY6j via @speechevents",
  "id" : 532639779569934336,
  "created_at" : "2014-11-12 21:03:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nastya",
      "screen_name" : "nastyageinrikh",
      "indices" : [ 16, 31 ],
      "id_str" : "186543637",
      "id" : 186543637
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "changeinELT",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "eltrant",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/a3zPQ9KVw7",
      "expanded_url" : "http:\/\/ow.ly\/E1WRI",
      "display_url" : "ow.ly\/E1WRI"
    } ]
  },
  "geo" : { },
  "id_str" : "532634033822629888",
  "text" : "#changeinELT RT @nastyageinrikh Blog update: My experience with language schools in Russia: Part 1 http:\/\/t.co\/a3zPQ9KVw7  #eltrant",
  "id" : 532634033822629888,
  "created_at" : "2014-11-12 20:40:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532612888335515648",
  "geo" : { },
  "id_str" : "532615039690485760",
  "in_reply_to_user_id" : 24046458,
  "text" : "@eltstat damn handdone in this day and age :)",
  "id" : 532615039690485760,
  "in_reply_to_status_id" : 532612888335515648,
  "created_at" : "2014-11-12 19:24:55 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532549263273000961",
  "geo" : { },
  "id_str" : "532612291771240448",
  "in_reply_to_user_id" : 24046458,
  "text" : "@eltstat great :) those animations r funky how dya do them?",
  "id" : 532612291771240448,
  "in_reply_to_status_id" : 532549263273000961,
  "created_at" : "2014-11-12 19:14:00 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532499227704692736",
  "geo" : { },
  "id_str" : "532533234312429568",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim hi sorry could not join hope u had a good chat :)",
  "id" : 532533234312429568,
  "in_reply_to_status_id" : 532499227704692736,
  "created_at" : "2014-11-12 13:59:51 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 66, 78 ],
      "id_str" : "70341872",
      "id" : 70341872
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 119, 129 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KG7aFkdTPn",
      "expanded_url" : "http:\/\/shar.es\/10Va4r",
      "display_url" : "shar.es\/10Va4r"
    } ]
  },
  "geo" : { },
  "id_str" : "532449382000762880",
  "text" : "RT @HancockMcDonald: Priming for Listening: Annie McDonald's talk @TESOLFrance - a preview: http:\/\/t.co\/KG7aFkdTPn via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TESOL France",
        "screen_name" : "TESOLFrance",
        "indices" : [ 45, 57 ],
        "id_str" : "70341872",
        "id" : 70341872
      }, {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 98, 108 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/KG7aFkdTPn",
        "expanded_url" : "http:\/\/shar.es\/10Va4r",
        "display_url" : "shar.es\/10Va4r"
      } ]
    },
    "geo" : { },
    "id_str" : "532439698216460288",
    "text" : "Priming for Listening: Annie McDonald's talk @TESOLFrance - a preview: http:\/\/t.co\/KG7aFkdTPn via @sharethis",
    "id" : 532439698216460288,
    "created_at" : "2014-11-12 07:48:10 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 532449382000762880,
  "created_at" : "2014-11-12 08:26:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Russell Brand",
      "screen_name" : "rustyrockets",
      "indices" : [ 104, 117 ],
      "id_str" : "19562228",
      "id" : 19562228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/PCS3pnJthZ",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/780-russell-brand-s-revolution.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532274715671666688",
  "text" : "RT @medialens: Media Alert: Russell Brand's 'Revolution' - Part 1, 'The Fun Bus' http:\/\/t.co\/PCS3pnJthZ @rustyrockets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russell Brand",
        "screen_name" : "rustyrockets",
        "indices" : [ 89, 102 ],
        "id_str" : "19562228",
        "id" : 19562228
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/PCS3pnJthZ",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/780-russell-brand-s-revolution.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532195225507487744",
    "text" : "Media Alert: Russell Brand's 'Revolution' - Part 1, 'The Fun Bus' http:\/\/t.co\/PCS3pnJthZ @rustyrockets",
    "id" : 532195225507487744,
    "created_at" : "2014-11-11 15:36:44 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 532274715671666688,
  "created_at" : "2014-11-11 20:52:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 3, 15 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 123, 132 ]
    }, {
      "text" : "eslchat",
      "indices" : [ 133, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Zpe6tcGBtN",
      "expanded_url" : "https:\/\/vimeo.com\/111524581",
      "display_url" : "vimeo.com\/111524581"
    } ]
  },
  "geo" : { },
  "id_str" : "532169436313444352",
  "text" : "RT @paul_sensei: WikiCloze: 5 million English listening and reading activities at your fingertips! https:\/\/t.co\/Zpe6tcGBtN #langchat #eslch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "eslchat",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "efl",
        "indices" : [ 125, 129 ]
      }, {
        "text" : "tefl",
        "indices" : [ 130, 135 ]
      }, {
        "text" : "esl",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Zpe6tcGBtN",
        "expanded_url" : "https:\/\/vimeo.com\/111524581",
        "display_url" : "vimeo.com\/111524581"
      } ]
    },
    "geo" : { },
    "id_str" : "532167519780368384",
    "text" : "WikiCloze: 5 million English listening and reading activities at your fingertips! https:\/\/t.co\/Zpe6tcGBtN #langchat #eslchat #efl #tefl #esl",
    "id" : 532167519780368384,
    "created_at" : "2014-11-11 13:46:38 +0000",
    "user" : {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "protected" : false,
      "id_str" : "176429301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666950419248259073\/T7XVTUac_normal.jpg",
      "id" : 176429301,
      "verified" : false
    }
  },
  "id" : 532169436313444352,
  "created_at" : "2014-11-11 13:54:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 49, 64 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/utjrIbTbD8",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-10S",
      "display_url" : "wp.me\/p3qkCB-10S"
    } ]
  },
  "geo" : { },
  "id_str" : "532166642604593152",
  "text" : "Don't call me Shirley http:\/\/t.co\/utjrIbTbD8 via @GeoffreyJordan",
  "id" : 532166642604593152,
  "created_at" : "2014-11-11 13:43:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Simpson",
      "screen_name" : "pevansimpson",
      "indices" : [ 0, 13 ],
      "id_str" : "230954247",
      "id" : 230954247
    }, {
      "name" : "Stephanie Fuccio",
      "screen_name" : "stephfuccio",
      "indices" : [ 14, 26 ],
      "id_str" : "153349145",
      "id" : 153349145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532126500196069376",
  "geo" : { },
  "id_str" : "532162500092252160",
  "in_reply_to_user_id" : 230954247,
  "text" : "@pevansimpson @stephfuccio interesting just one niggle from opening shots and interviewees maybe better called UK English 3.0 :)",
  "id" : 532162500092252160,
  "in_reply_to_status_id" : 532126500196069376,
  "created_at" : "2014-11-11 13:26:41 +0000",
  "in_reply_to_screen_name" : "pevansimpson",
  "in_reply_to_user_id_str" : "230954247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 16, 24 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 25, 36 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532156057951682560",
  "geo" : { },
  "id_str" : "532161382981312512",
  "in_reply_to_user_id" : 116954342,
  "text" : "@cellointensive @LahiffP @ELTIreland aye i guess it was a RT click slip?",
  "id" : 532161382981312512,
  "in_reply_to_status_id" : 532156057951682560,
  "created_at" : "2014-11-11 13:22:15 +0000",
  "in_reply_to_screen_name" : "LJ_Tyrrell",
  "in_reply_to_user_id_str" : "116954342",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532112660188651520",
  "geo" : { },
  "id_str" : "532147679078670336",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland what event r u referring to?",
  "id" : 532147679078670336,
  "in_reply_to_status_id" : 532112660188651520,
  "created_at" : "2014-11-11 12:27:48 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 3, 15 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Luke Alexander",
      "screen_name" : "lukeealexander",
      "indices" : [ 79, 94 ],
      "id_str" : "33176182",
      "id" : 33176182
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "edtech",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/vIEbP5TvKz",
      "expanded_url" : "http:\/\/lukeealexander.tumblr.com\/post\/102331100364\/interobjectivity-theres-an-app-for-that",
      "display_url" : "lukeealexander.tumblr.com\/post\/102331100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532101236372545536",
  "text" : "RT @SophiaKhan4: Interobjectivity - there's an app for that: excellent post by @lukeealexander http:\/\/t.co\/vIEbP5TvKz #AusELT #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Alexander",
        "screen_name" : "lukeealexander",
        "indices" : [ 62, 77 ],
        "id_str" : "33176182",
        "id" : 33176182
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AusELT",
        "indices" : [ 101, 108 ]
      }, {
        "text" : "edtech",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/vIEbP5TvKz",
        "expanded_url" : "http:\/\/lukeealexander.tumblr.com\/post\/102331100364\/interobjectivity-theres-an-app-for-that",
        "display_url" : "lukeealexander.tumblr.com\/post\/102331100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532058223348428800",
    "text" : "Interobjectivity - there's an app for that: excellent post by @lukeealexander http:\/\/t.co\/vIEbP5TvKz #AusELT #edtech",
    "id" : 532058223348428800,
    "created_at" : "2014-11-11 06:32:20 +0000",
    "user" : {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "protected" : false,
      "id_str" : "351390617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1494743995\/soph_normal.JPG",
      "id" : 351390617,
      "verified" : false
    }
  },
  "id" : 532101236372545536,
  "created_at" : "2014-11-11 09:23:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532099597163053056",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland  um this is from 2013",
  "id" : 532099597163053056,
  "created_at" : "2014-11-11 09:16:44 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531933804269944832",
  "geo" : { },
  "id_str" : "531934368525471744",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab sure though it may uncomfort a fluentist :)",
  "id" : 531934368525471744,
  "in_reply_to_status_id" : 531933804269944832,
  "created_at" : "2014-11-10 22:20:10 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531918743623180289",
  "geo" : { },
  "id_str" : "531930469148135424",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT my pleasure :)",
  "id" : 531930469148135424,
  "in_reply_to_status_id" : 531918743623180289,
  "created_at" : "2014-11-10 22:04:41 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 85, 97 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/esV6cVcf0l",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/jan08\/idea.htm",
      "display_url" : "hltmag.co.uk\/jan08\/idea.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "531928869100462080",
  "geo" : { },
  "id_str" : "531930283000725506",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas a very relevant link imo on creativity in learner grammar shared by @TonyMcEnery on #corpusmooc http:\/\/t.co\/esV6cVcf0l",
  "id" : 531930283000725506,
  "in_reply_to_status_id" : 531928869100462080,
  "created_at" : "2014-11-10 22:03:56 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "indices" : [ 0, 15 ],
      "id_str" : "2665944684",
      "id" : 2665944684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531904373807665152",
  "geo" : { },
  "id_str" : "531916536198725632",
  "in_reply_to_user_id" : 2665944684,
  "text" : "@edtechconcerns thanks lookin fwd to part 2 :)",
  "id" : 531916536198725632,
  "in_reply_to_status_id" : 531904373807665152,
  "created_at" : "2014-11-10 21:09:19 +0000",
  "in_reply_to_screen_name" : "edtechconcerns",
  "in_reply_to_user_id_str" : "2665944684",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/esXQKyhkvd",
      "expanded_url" : "http:\/\/www.richmondshare.com.br\/giving-feedback-on-writing\/",
      "display_url" : "richmondshare.com.br\/giving-feedbac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531915846638391296",
  "text" : "RT @luizotavioELT: Ten tips to help you give feedback on writing http:\/\/t.co\/esXQKyhkvd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/esXQKyhkvd",
        "expanded_url" : "http:\/\/www.richmondshare.com.br\/giving-feedback-on-writing\/",
        "display_url" : "richmondshare.com.br\/giving-feedbac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531884513425518592",
    "text" : "Ten tips to help you give feedback on writing http:\/\/t.co\/esXQKyhkvd",
    "id" : 531884513425518592,
    "created_at" : "2014-11-10 19:02:04 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 531915846638391296,
  "created_at" : "2014-11-10 21:06:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/rYRXI7r5jh",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/education\/education-news\/education-secretary-nicky-morgan-tells-teenagers-if-you-want-a-job-drop-humanities-9852316.html",
      "display_url" : "independent.co.uk\/news\/education\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531901262431019010",
  "text" : "RT @pchallinor: We want technicians, not thinkers http:\/\/t.co\/rYRXI7r5jh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/rYRXI7r5jh",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/education\/education-news\/education-secretary-nicky-morgan-tells-teenagers-if-you-want-a-job-drop-humanities-9852316.html",
        "display_url" : "independent.co.uk\/news\/education\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531895948059090944",
    "text" : "We want technicians, not thinkers http:\/\/t.co\/rYRXI7r5jh",
    "id" : 531895948059090944,
    "created_at" : "2014-11-10 19:47:30 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 531901262431019010,
  "created_at" : "2014-11-10 20:08:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "BBC",
      "screen_name" : "BBC",
      "indices" : [ 18, 22 ],
      "id_str" : "19701628",
      "id" : 19701628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hGpIIqgTD9",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-29992023",
      "display_url" : "bbc.co.uk\/news\/uk-299920\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531900882246709248",
  "text" : "RT @johnwhilley: .@BBC report 'cosy' Thatcher-Reagan phone call over Grenada invasion without a mention of illegality or human cost http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC",
        "screen_name" : "BBC",
        "indices" : [ 1, 5 ],
        "id_str" : "19701628",
        "id" : 19701628
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hGpIIqgTD9",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-29992023",
        "display_url" : "bbc.co.uk\/news\/uk-299920\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531881640231190528",
    "text" : ".@BBC report 'cosy' Thatcher-Reagan phone call over Grenada invasion without a mention of illegality or human cost http:\/\/t.co\/hGpIIqgTD9",
    "id" : 531881640231190528,
    "created_at" : "2014-11-10 18:50:39 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 531900882246709248,
  "created_at" : "2014-11-10 20:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 118, 131 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/mRYkVIi48A",
      "expanded_url" : "http:\/\/wp.me\/p28iGT-13V",
      "display_url" : "wp.me\/p28iGT-13V"
    } ]
  },
  "geo" : { },
  "id_str" : "531896949364895744",
  "text" : "Ask Not What Your Country Can Do For You but What Coursera Can Do For Your Country, Part 1 http:\/\/t.co\/mRYkVIi48A via @tressiemcphd",
  "id" : 531896949364895744,
  "created_at" : "2014-11-10 19:51:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 3, 14 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/LRbK3XIYzY",
      "expanded_url" : "http:\/\/repoole.wordpress.com",
      "display_url" : "repoole.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "531872166728695808",
  "text" : "RT @esl_robert: Visit my blog at http:\/\/t.co\/LRbK3XIYzY.  Posts will focus on my research interests in corpus linguistics, ecolinguistics, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/LRbK3XIYzY",
        "expanded_url" : "http:\/\/repoole.wordpress.com",
        "display_url" : "repoole.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "531869560933453825",
    "text" : "Visit my blog at http:\/\/t.co\/LRbK3XIYzY.  Posts will focus on my research interests in corpus linguistics, ecolinguistics, &amp; L2 writing.",
    "id" : 531869560933453825,
    "created_at" : "2014-11-10 18:02:39 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 531872166728695808,
  "created_at" : "2014-11-10 18:13:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Pepper magazine",
      "screen_name" : "RedPeppermag",
      "indices" : [ 3, 16 ],
      "id_str" : "20451618",
      "id" : 20451618
    }, {
      "name" : "Russell Brand",
      "screen_name" : "rustyrockets",
      "indices" : [ 86, 99 ],
      "id_str" : "19562228",
      "id" : 19562228
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Parklife",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/IboAndSOMW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0dAFbpk9_GM",
      "display_url" : "youtube.com\/watch?v=0dAFbp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531861675390296064",
  "text" : "RT @RedPeppermag: Russell Brand\u2019s response to #Parklife jibes https:\/\/t.co\/IboAndSOMW @rustyrockets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russell Brand",
        "screen_name" : "rustyrockets",
        "indices" : [ 68, 81 ],
        "id_str" : "19562228",
        "id" : 19562228
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Parklife",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/IboAndSOMW",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0dAFbpk9_GM",
        "display_url" : "youtube.com\/watch?v=0dAFbp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531818540303917056",
    "text" : "Russell Brand\u2019s response to #Parklife jibes https:\/\/t.co\/IboAndSOMW @rustyrockets",
    "id" : 531818540303917056,
    "created_at" : "2014-11-10 14:39:55 +0000",
    "user" : {
      "name" : "Red Pepper magazine",
      "screen_name" : "RedPeppermag",
      "protected" : false,
      "id_str" : "20451618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363310402\/5k7q22q7dwkdmlw4zcg6_normal.png",
      "id" : 20451618,
      "verified" : false
    }
  },
  "id" : 531861675390296064,
  "created_at" : "2014-11-10 17:31:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531841872830808064",
  "geo" : { },
  "id_str" : "531847678490345473",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei ok will check when see my student on fri",
  "id" : 531847678490345473,
  "in_reply_to_status_id" : 531841872830808064,
  "created_at" : "2014-11-10 16:35:42 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531832175235055617",
  "geo" : { },
  "id_str" : "531832279883337729",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters me too before RTing :)",
  "id" : 531832279883337729,
  "in_reply_to_status_id" : 531832175235055617,
  "created_at" : "2014-11-10 15:34:31 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "indices" : [ 15, 30 ],
      "id_str" : "2665944684",
      "id" : 2665944684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531827210810691585",
  "geo" : { },
  "id_str" : "531831655963820032",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters @edtechconcerns hmm not uploaded yet?",
  "id" : 531831655963820032,
  "in_reply_to_status_id" : 531827210810691585,
  "created_at" : "2014-11-10 15:32:02 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "government",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "security",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/NRgp6VU7Ap",
      "expanded_url" : "http:\/\/ow.ly\/E2nCz",
      "display_url" : "ow.ly\/E2nCz"
    } ]
  },
  "geo" : { },
  "id_str" : "531830879208108032",
  "text" : "RT @patrickDurusau: Almost Everything in \u201CDr. Strangelove\u201D Was True #privacy #government #security http:\/\/t.co\/NRgp6VU7Ap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 48, 56 ]
      }, {
        "text" : "government",
        "indices" : [ 57, 68 ]
      }, {
        "text" : "security",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/NRgp6VU7Ap",
        "expanded_url" : "http:\/\/ow.ly\/E2nCz",
        "display_url" : "ow.ly\/E2nCz"
      } ]
    },
    "geo" : { },
    "id_str" : "531642591746740224",
    "text" : "Almost Everything in \u201CDr. Strangelove\u201D Was True #privacy #government #security http:\/\/t.co\/NRgp6VU7Ap",
    "id" : 531642591746740224,
    "created_at" : "2014-11-10 03:00:45 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 531830879208108032,
  "created_at" : "2014-11-10 15:28:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "indices" : [ 32, 47 ],
      "id_str" : "2665944684",
      "id" : 2665944684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/whQNpgCB9c",
      "expanded_url" : "http:\/\/www.ltsig.org.uk\/ltgisigevent\/?p=28",
      "display_url" : "ltsig.org.uk\/ltgisigevent\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531830743694323713",
  "text" : "RT @audreywatters: Episode 3 of @edtechconcerns is now available (featuring an interview with me) http:\/\/t.co\/whQNpgCB9c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "edtechconcerns",
        "screen_name" : "edtechconcerns",
        "indices" : [ 13, 28 ],
        "id_str" : "2665944684",
        "id" : 2665944684
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/whQNpgCB9c",
        "expanded_url" : "http:\/\/www.ltsig.org.uk\/ltgisigevent\/?p=28",
        "display_url" : "ltsig.org.uk\/ltgisigevent\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531827210810691585",
    "text" : "Episode 3 of @edtechconcerns is now available (featuring an interview with me) http:\/\/t.co\/whQNpgCB9c",
    "id" : 531827210810691585,
    "created_at" : "2014-11-10 15:14:22 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 531830743694323713,
  "created_at" : "2014-11-10 15:28:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531803355115708418",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei hi paul like new features in sentence builder, there still seems to be an issue with sound files - desktop, firefox, corp LAN",
  "id" : 531803355115708418,
  "created_at" : "2014-11-10 13:39:34 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL Direct",
      "screen_name" : "TESOLDirect",
      "indices" : [ 3, 15 ],
      "id_str" : "1171415774",
      "id" : 1171415774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/nwrVVidlAK",
      "expanded_url" : "http:\/\/gu.com\/p\/42nhb\/stw",
      "display_url" : "gu.com\/p\/42nhb\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "531796618946027520",
  "text" : "RT @TESOLDirect: Most language students unable to do more than understand basic phrases http:\/\/t.co\/nwrVVidlAK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/nwrVVidlAK",
        "expanded_url" : "http:\/\/gu.com\/p\/42nhb\/stw",
        "display_url" : "gu.com\/p\/42nhb\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "531795954114904065",
    "text" : "Most language students unable to do more than understand basic phrases http:\/\/t.co\/nwrVVidlAK",
    "id" : 531795954114904065,
    "created_at" : "2014-11-10 13:10:10 +0000",
    "user" : {
      "name" : "TESOL Direct",
      "screen_name" : "TESOLDirect",
      "protected" : false,
      "id_str" : "1171415774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3243338273\/6394617829be68239dfd255d6c8746b4_normal.jpeg",
      "id" : 1171415774,
      "verified" : false
    }
  },
  "id" : 531796618946027520,
  "created_at" : "2014-11-10 13:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMooc",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/jjvCiQ7s45",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1Cr",
      "display_url" : "wp.me\/p39dN1-1Cr"
    } ]
  },
  "geo" : { },
  "id_str" : "531795786661900289",
  "text" : "RT @drbexl: #CorpusMooc: Week 6\u00A0Notes http:\/\/t.co\/jjvCiQ7s45",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMooc",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/jjvCiQ7s45",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1Cr",
        "display_url" : "wp.me\/p39dN1-1Cr"
      } ]
    },
    "geo" : { },
    "id_str" : "531774758556168192",
    "text" : "#CorpusMooc: Week 6\u00A0Notes http:\/\/t.co\/jjvCiQ7s45",
    "id" : 531774758556168192,
    "created_at" : "2014-11-10 11:45:57 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 531795786661900289,
  "created_at" : "2014-11-10 13:09:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MFL@ShottonHall",
      "screen_name" : "ShottonHallMFL",
      "indices" : [ 0, 15 ],
      "id_str" : "2234458941",
      "id" : 2234458941
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531772610275966976",
  "geo" : { },
  "id_str" : "531773723767214080",
  "in_reply_to_user_id" : 2234458941,
  "text" : "@ShottonHallMFL @covunidel sure, #piratebox for dodgy net connection, concerns about cloud based privacy and number of other benefits",
  "id" : 531773723767214080,
  "in_reply_to_status_id" : 531772610275966976,
  "created_at" : "2014-11-10 11:41:50 +0000",
  "in_reply_to_screen_name" : "ShottonHallMFL",
  "in_reply_to_user_id_str" : "2234458941",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "Chronicle",
      "screen_name" : "chronicle",
      "indices" : [ 12, 22 ],
      "id_str" : "12413032",
      "id" : 12413032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/531762491035246592\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HZbgpbx1OD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2EzKi2IIAA_1at.png",
      "id_str" : "531762487251968000",
      "id" : 531762487251968000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2EzKi2IIAA_1at.png",
      "sizes" : [ {
        "h" : 677,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1102
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HZbgpbx1OD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Wr2F5IsOkX",
      "expanded_url" : "http:\/\/www.teachingenglish.org.uk\/article\/language-testing-looking-back-looking-forward",
      "display_url" : "teachingenglish.org.uk\/article\/langua\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "531737889290608641",
  "geo" : { },
  "id_str" : "531762491035246592",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga @chronicle compare earlier quizzes e.g. CPE quiz 1913 from great talk on testing http:\/\/t.co\/Wr2F5IsOkX http:\/\/t.co\/HZbgpbx1OD",
  "id" : 531762491035246592,
  "in_reply_to_status_id" : 531737889290608641,
  "created_at" : "2014-11-10 10:57:12 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Price",
      "screen_name" : "fionaljp",
      "indices" : [ 0, 9 ],
      "id_str" : "251372057",
      "id" : 251372057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531533028267671553",
  "geo" : { },
  "id_str" : "531741718434308096",
  "in_reply_to_user_id" : 251372057,
  "text" : "@fionaljp likewise :)",
  "id" : 531741718434308096,
  "in_reply_to_status_id" : 531533028267671553,
  "created_at" : "2014-11-10 09:34:39 +0000",
  "in_reply_to_screen_name" : "fionaljp",
  "in_reply_to_user_id_str" : "251372057",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Deacon",
      "screen_name" : "MichaelPDeacon",
      "indices" : [ 3, 18 ],
      "id_str" : "506486097",
      "id" : 506486097
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MichaelPDeacon\/status\/531456174034788353\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TkLQwUBjow",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2AckCECUAAOsjJ.jpg",
      "id_str" : "531456161384386560",
      "id" : 531456161384386560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2AckCECUAAOsjJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 886
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 886
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TkLQwUBjow"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531577053460856832",
  "text" : "RT @MichaelPDeacon: Ukip fans attacking me re the new party I've launched, Ukep. Typical Establishment response - they're running scared ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MichaelPDeacon\/status\/531456174034788353\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/TkLQwUBjow",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2AckCECUAAOsjJ.jpg",
        "id_str" : "531456161384386560",
        "id" : 531456161384386560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2AckCECUAAOsjJ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 886
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 886
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TkLQwUBjow"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531456174034788353",
    "text" : "Ukip fans attacking me re the new party I've launched, Ukep. Typical Establishment response - they're running scared http:\/\/t.co\/TkLQwUBjow",
    "id" : 531456174034788353,
    "created_at" : "2014-11-09 14:40:00 +0000",
    "user" : {
      "name" : "Michael Deacon",
      "screen_name" : "MichaelPDeacon",
      "protected" : false,
      "id_str" : "506486097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658404648626339840\/bznQiT5w_normal.jpg",
      "id" : 506486097,
      "verified" : true
    }
  },
  "id" : 531577053460856832,
  "created_at" : "2014-11-09 22:40:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagamine, T.",
      "screen_name" : "nagamine_73",
      "indices" : [ 126, 138 ],
      "id_str" : "2450110776",
      "id" : 2450110776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/WbWlZ3F230",
      "expanded_url" : "http:\/\/youtu.be\/h-8np2EKrEM",
      "display_url" : "youtu.be\/h-8np2EKrEM"
    } ]
  },
  "geo" : { },
  "id_str" : "531538984477138944",
  "text" : "Research writing: Constructing community &amp; negotiating identity by Prof. Ken Hyland, Sept 2014 http:\/\/t.co\/WbWlZ3F230 h\/t @nagamine_73",
  "id" : 531538984477138944,
  "created_at" : "2014-11-09 20:09:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531505116143452160",
  "text" : "@IreneVoulgaris :) ta",
  "id" : 531505116143452160,
  "created_at" : "2014-11-09 17:54:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Price",
      "screen_name" : "fionaljp",
      "indices" : [ 3, 12 ],
      "id_str" : "251372057",
      "id" : 251372057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Xy23Rg64K2",
      "expanded_url" : "http:\/\/fionaljp.blogspot.com\/2014\/11\/a-winning-combination-frazeit-phraseum.html?spref=tw",
      "display_url" : "fionaljp.blogspot.com\/2014\/11\/a-winn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531504500599959554",
  "text" : "RT @fionaljp: fionaljp: A winning combination: Fraze.it &amp; Phraseum http:\/\/t.co\/Xy23Rg64K2 #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/Xy23Rg64K2",
        "expanded_url" : "http:\/\/fionaljp.blogspot.com\/2014\/11\/a-winning-combination-frazeit-phraseum.html?spref=tw",
        "display_url" : "fionaljp.blogspot.com\/2014\/11\/a-winn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531420433891864576",
    "text" : "fionaljp: A winning combination: Fraze.it &amp; Phraseum http:\/\/t.co\/Xy23Rg64K2 #eltchat",
    "id" : 531420433891864576,
    "created_at" : "2014-11-09 12:17:59 +0000",
    "user" : {
      "name" : "Fiona Price",
      "screen_name" : "fionaljp",
      "protected" : false,
      "id_str" : "251372057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428829940193050624\/_Jdev9OK_normal.jpeg",
      "id" : 251372057,
      "verified" : false
    }
  },
  "id" : 531504500599959554,
  "created_at" : "2014-11-09 17:52:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "TDSIG",
      "screen_name" : "tdsig",
      "indices" : [ 30, 36 ],
      "id_str" : "105883895",
      "id" : 105883895
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 77, 92 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 93, 100 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/JwHbwUit9z",
      "expanded_url" : "http:\/\/tdsig.org\/interviews\/",
      "display_url" : "tdsig.org\/interviews\/"
    } ]
  },
  "geo" : { },
  "id_str" : "531477749878501376",
  "text" : "RT @_divyamadhavan: Check out @tdsig 's new page http:\/\/t.co\/JwHbwUit9z with @thornburyscott #IATEFL #eltchat #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TDSIG",
        "screen_name" : "tdsig",
        "indices" : [ 10, 16 ],
        "id_str" : "105883895",
        "id" : 105883895
      }, {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 57, 72 ],
        "id_str" : "23090474",
        "id" : 23090474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "elt",
        "indices" : [ 90, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/JwHbwUit9z",
        "expanded_url" : "http:\/\/tdsig.org\/interviews\/",
        "display_url" : "tdsig.org\/interviews\/"
      } ]
    },
    "geo" : { },
    "id_str" : "530775030750519296",
    "text" : "Check out @tdsig 's new page http:\/\/t.co\/JwHbwUit9z with @thornburyscott #IATEFL #eltchat #elt",
    "id" : 530775030750519296,
    "created_at" : "2014-11-07 17:33:23 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 531477749878501376,
  "created_at" : "2014-11-09 16:05:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 103, 115 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 3, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531462141094924290",
  "text" : "on #corpusmooc  there's some great links being shared, any chance of compliing them automatically from @FutureLearn system?",
  "id" : 531462141094924290,
  "created_at" : "2014-11-09 15:03:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 17, 33 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ipF9pvVtLb",
      "expanded_url" : "http:\/\/teacherofesol.wordpress.com\/eap-study-skills\/",
      "display_url" : "teacherofesol.wordpress.com\/eap-study-skil\u2026"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/L9ZejlbEwN",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/114679086713772400315",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "531290696326840320",
  "geo" : { },
  "id_str" : "531459480371073025",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons @yearinthelifeof hi recently discovered @IreneVoulgaris blog http:\/\/t.co\/ipF9pvVtLb, also #tleap https:\/\/t.co\/L9ZejlbEwN",
  "id" : 531459480371073025,
  "in_reply_to_status_id" : 531290696326840320,
  "created_at" : "2014-11-09 14:53:08 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/DCIQoP04s9",
      "expanded_url" : "http:\/\/engineeringasaforeignlanguage.blogspot.com\/2014\/11\/world-changing-ideas-summit.html?spref=tw",
      "display_url" : "\u2026eeringasaforeignlanguage.blogspot.com\/2014\/11\/world-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531204297556361216",
  "text" : "Teaching English to Engineers: World-changing ideas summit http:\/\/t.co\/DCIQoP04s9",
  "id" : 531204297556361216,
  "created_at" : "2014-11-08 21:59:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/7yMPfD8oVJ",
      "expanded_url" : "http:\/\/noglory.org\/index.php\/articles\/369-good-for-the-killing-business-how-the-world-s-biggest-arms-dealers-exploit-poppy-day#.VF6JmWhkAx8.twitter",
      "display_url" : "noglory.org\/index.php\/arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531195164425850880",
  "text" : "Good for the killing business: How the world's biggest arms dealers exploit poppy day: http:\/\/t.co\/7yMPfD8oVJ",
  "id" : 531195164425850880,
  "created_at" : "2014-11-08 21:22:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531170416015212544",
  "text" : "@IreneVoulgaris hi sure thx, just checked a bit of yr blog it is great :)",
  "id" : 531170416015212544,
  "created_at" : "2014-11-08 19:44:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McKenzie",
      "screen_name" : "ScottMcKenzie27",
      "indices" : [ 0, 16 ],
      "id_str" : "367881445",
      "id" : 367881445
    }, {
      "name" : "David Fife",
      "screen_name" : "DavidFifeVP",
      "indices" : [ 17, 29 ],
      "id_str" : "595062333",
      "id" : 595062333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530723148707430400",
  "geo" : { },
  "id_str" : "530756266164240384",
  "in_reply_to_user_id" : 367881445,
  "text" : "@ScottMcKenzie27 @DavidFifeVP is that a current quote?",
  "id" : 530756266164240384,
  "in_reply_to_status_id" : 530723148707430400,
  "created_at" : "2014-11-07 16:18:49 +0000",
  "in_reply_to_screen_name" : "ScottMcKenzie27",
  "in_reply_to_user_id_str" : "367881445",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MFL@ShottonHall",
      "screen_name" : "ShottonHallMFL",
      "indices" : [ 0, 15 ],
      "id_str" : "2234458941",
      "id" : 2234458941
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530650859823431680",
  "geo" : { },
  "id_str" : "530753926669553664",
  "in_reply_to_user_id" : 2234458941,
  "text" : "@ShottonHallMFL @covunidel hi, an alternative (for any byo device with a web browser) is to use #piratebox",
  "id" : 530753926669553664,
  "in_reply_to_status_id" : 530650859823431680,
  "created_at" : "2014-11-07 16:09:31 +0000",
  "in_reply_to_screen_name" : "ShottonHallMFL",
  "in_reply_to_user_id_str" : "2234458941",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 3, 19 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Tekh",
      "screen_name" : "Tekhnologic",
      "indices" : [ 64, 76 ],
      "id_str" : "1336152278",
      "id" : 1336152278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "edtech",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/XioO7IrQRY",
      "expanded_url" : "http:\/\/ow.ly\/DWMKF",
      "display_url" : "ow.ly\/DWMKF"
    } ]
  },
  "geo" : { },
  "id_str" : "530502615449489408",
  "text" : "RT @theteacherjames: Interesting ways to use Google Ngrams, via @tekhnologic: http:\/\/t.co\/XioO7IrQRY #eltchat #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tekh",
        "screen_name" : "Tekhnologic",
        "indices" : [ 43, 55 ],
        "id_str" : "1336152278",
        "id" : 1336152278
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "edtech",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/XioO7IrQRY",
        "expanded_url" : "http:\/\/ow.ly\/DWMKF",
        "display_url" : "ow.ly\/DWMKF"
      } ]
    },
    "geo" : { },
    "id_str" : "530501989487357952",
    "text" : "Interesting ways to use Google Ngrams, via @tekhnologic: http:\/\/t.co\/XioO7IrQRY #eltchat #edtech",
    "id" : 530501989487357952,
    "created_at" : "2014-11-06 23:28:25 +0000",
    "user" : {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "protected" : false,
      "id_str" : "71746265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595367704090939392\/nJCWaI_Z_normal.jpg",
      "id" : 71746265,
      "verified" : false
    }
  },
  "id" : 530502615449489408,
  "created_at" : "2014-11-06 23:30:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/bpUGE2gFwj",
      "expanded_url" : "http:\/\/youtu.be\/zAz4UoFWIfM",
      "display_url" : "youtu.be\/zAz4UoFWIfM"
    } ]
  },
  "geo" : { },
  "id_str" : "530501754417184768",
  "text" : "How Do We Deal With Police Violence? Russell Brand The Trews (E184): http:\/\/t.co\/bpUGE2gFwj via @YouTube",
  "id" : 530501754417184768,
  "created_at" : "2014-11-06 23:27:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/G23EZhwU36",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/gCXF8UNqhAb",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530487266159128576",
  "text" : "10 people polled Are you enjoying the #corpusmooc? https:\/\/t.co\/G23EZhwU36",
  "id" : 530487266159128576,
  "created_at" : "2014-11-06 22:29:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530479540867719168",
  "geo" : { },
  "id_str" : "530481869465595904",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall then cambridge english does need to add such a qualification :)",
  "id" : 530481869465595904,
  "in_reply_to_status_id" : 530479540867719168,
  "created_at" : "2014-11-06 22:08:28 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530475845115457537",
  "geo" : { },
  "id_str" : "530477086482640896",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall i certainly have less need to shake the toner or unblock rollers since using #piratebox on my phone :)",
  "id" : 530477086482640896,
  "in_reply_to_status_id" : 530475845115457537,
  "created_at" : "2014-11-06 21:49:27 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/Jzr7xZFkjM",
      "expanded_url" : "http:\/\/wp.me\/p2crcD-PN",
      "display_url" : "wp.me\/p2crcD-PN"
    } ]
  },
  "geo" : { },
  "id_str" : "530473885892763648",
  "text" : "Prevention is better than cure: http:\/\/t.co\/Jzr7xZFkjM via @TheSecretStoic",
  "id" : 530473885892763648,
  "created_at" : "2014-11-06 21:36:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "indices" : [ 3, 12 ],
      "id_str" : "47862165",
      "id" : 47862165
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/530466124249698304\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/Lm4mrkompo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yYHxXIIAA0mHa.jpg",
      "id_str" : "530466115399720960",
      "id" : 530466115399720960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yYHxXIIAA0mHa.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/Lm4mrkompo"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/530466124249698304\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/Lm4mrkompo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yYIJrIMAAcCok.jpg",
      "id_str" : "530466121926062080",
      "id" : 530466121926062080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yYIJrIMAAcCok.jpg",
      "sizes" : [ {
        "h" : 769,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 769,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 769,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Lm4mrkompo"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/530466124249698304\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/Lm4mrkompo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yYIOcIIAA1WRz.jpg",
      "id_str" : "530466123205320704",
      "id" : 530466123205320704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yYIOcIIAA1WRz.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 819
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 819
      } ],
      "display_url" : "pic.twitter.com\/Lm4mrkompo"
    } ],
    "hashtags" : [ {
      "text" : "RemiFraisse",
      "indices" : [ 79, 91 ]
    }, {
      "text" : "Blocus",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/uwxmcVxDqR",
      "expanded_url" : "http:\/\/revolution-news.com\/french-students-barricade-20-paris-schools-protesting-killing-of-remi-fraisse\/",
      "display_url" : "revolution-news.com\/french-student\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530470956524142592",
  "text" : "RT @NewsRevo: French Students Barricade 20 Paris Schools Protesting Killing of #RemiFraisse | #Blocus http:\/\/t.co\/uwxmcVxDqR http:\/\/t.co\/Lm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/530466124249698304\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Lm4mrkompo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yYHxXIIAA0mHa.jpg",
        "id_str" : "530466115399720960",
        "id" : 530466115399720960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yYHxXIIAA0mHa.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/Lm4mrkompo"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/530466124249698304\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Lm4mrkompo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yYIJrIMAAcCok.jpg",
        "id_str" : "530466121926062080",
        "id" : 530466121926062080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yYIJrIMAAcCok.jpg",
        "sizes" : [ {
          "h" : 769,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 769,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 769,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Lm4mrkompo"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/530466124249698304\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Lm4mrkompo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yYIOcIIAA1WRz.jpg",
        "id_str" : "530466123205320704",
        "id" : 530466123205320704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yYIOcIIAA1WRz.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 819
        } ],
        "display_url" : "pic.twitter.com\/Lm4mrkompo"
      } ],
      "hashtags" : [ {
        "text" : "RemiFraisse",
        "indices" : [ 65, 77 ]
      }, {
        "text" : "Blocus",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/uwxmcVxDqR",
        "expanded_url" : "http:\/\/revolution-news.com\/french-students-barricade-20-paris-schools-protesting-killing-of-remi-fraisse\/",
        "display_url" : "revolution-news.com\/french-student\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530466124249698304",
    "text" : "French Students Barricade 20 Paris Schools Protesting Killing of #RemiFraisse | #Blocus http:\/\/t.co\/uwxmcVxDqR http:\/\/t.co\/Lm4mrkompo",
    "id" : 530466124249698304,
    "created_at" : "2014-11-06 21:05:54 +0000",
    "user" : {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "protected" : false,
      "id_str" : "47862165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573963111272570880\/lpNfTgyM_normal.jpeg",
      "id" : 47862165,
      "verified" : false
    }
  },
  "id" : 530470956524142592,
  "created_at" : "2014-11-06 21:25:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Cambridge English",
      "screen_name" : "CambridgeEng",
      "indices" : [ 13, 26 ],
      "id_str" : "43073357",
      "id" : 43073357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530432926471553024",
  "geo" : { },
  "id_str" : "530459780176166912",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @CambridgeEng hehe, or use #piratebox to keep those xerox blues at bay :)",
  "id" : 530459780176166912,
  "in_reply_to_status_id" : 530432926471553024,
  "created_at" : "2014-11-06 20:40:41 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AEnsslin",
      "screen_name" : "AstridEnsslin",
      "indices" : [ 3, 17 ],
      "id_str" : "14054390",
      "id" : 14054390
    }, {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "indices" : [ 48, 63 ],
      "id_str" : "2340183050",
      "id" : 2340183050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/SuyStuu9Qj",
      "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/abs\/10.3366\/cor.2014.0057",
      "display_url" : "euppublishing.com\/doi\/abs\/10.336\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530331587486175232",
  "text" : "RT @AstridEnsslin: Our 'What's Hard in German?' @CorporaJournal article is out - Open Access! http:\/\/t.co\/SuyStuu9Qj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Corpora Journal",
        "screen_name" : "CorporaJournal",
        "indices" : [ 29, 44 ],
        "id_str" : "2340183050",
        "id" : 2340183050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/SuyStuu9Qj",
        "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/abs\/10.3366\/cor.2014.0057",
        "display_url" : "euppublishing.com\/doi\/abs\/10.336\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530329718235873280",
    "text" : "Our 'What's Hard in German?' @CorporaJournal article is out - Open Access! http:\/\/t.co\/SuyStuu9Qj",
    "id" : 530329718235873280,
    "created_at" : "2014-11-06 12:03:52 +0000",
    "user" : {
      "name" : "AEnsslin",
      "screen_name" : "AstridEnsslin",
      "protected" : false,
      "id_str" : "14054390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471950931890671616\/5KvJdyc9_normal.jpeg",
      "id" : 14054390,
      "verified" : false
    }
  },
  "id" : 530331587486175232,
  "created_at" : "2014-11-06 12:11:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "C\u00E9sar C\u00F3rcoles",
      "screen_name" : "chechar",
      "indices" : [ 12, 20 ],
      "id_str" : "457733",
      "id" : 457733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ds106",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/iXW8CdZgWd",
      "expanded_url" : "http:\/\/crmbl.co\/1x60nvl",
      "display_url" : "crmbl.co\/1x60nvl"
    } ]
  },
  "geo" : { },
  "id_str" : "530327750624948225",
  "text" : "RT @cogdog: @chechar HOLY BLEEP! Crumbles is addictive. http:\/\/t.co\/iXW8CdZgWd #ds106",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C\u00E9sar C\u00F3rcoles",
        "screen_name" : "chechar",
        "indices" : [ 0, 8 ],
        "id_str" : "457733",
        "id" : 457733
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ds106",
        "indices" : [ 67, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/iXW8CdZgWd",
        "expanded_url" : "http:\/\/crmbl.co\/1x60nvl",
        "display_url" : "crmbl.co\/1x60nvl"
      } ]
    },
    "in_reply_to_status_id_str" : "530272476350406658",
    "geo" : { },
    "id_str" : "530275159286874112",
    "in_reply_to_user_id" : 457733,
    "text" : "@chechar HOLY BLEEP! Crumbles is addictive. http:\/\/t.co\/iXW8CdZgWd #ds106",
    "id" : 530275159286874112,
    "in_reply_to_status_id" : 530272476350406658,
    "created_at" : "2014-11-06 08:27:04 +0000",
    "in_reply_to_screen_name" : "chechar",
    "in_reply_to_user_id_str" : "457733",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 530327750624948225,
  "created_at" : "2014-11-06 11:56:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 3, 16 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 78, 90 ],
      "id_str" : "319110295",
      "id" : 319110295
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 91, 106 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/uwSycev27h",
      "expanded_url" : "http:\/\/mjobx.com\/fw93CA",
      "display_url" : "mjobx.com\/fw93CA"
    } ]
  },
  "geo" : { },
  "id_str" : "530283552110563328",
  "text" : "RT @ClaireDembry: Great job available on my team: Senior ELT Research Manager @CambridgeUP @CambridgeUPELT #jobs http:\/\/t.co\/uwSycev27h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 60, 72 ],
        "id_str" : "319110295",
        "id" : 319110295
      }, {
        "name" : "Cambridge ELT",
        "screen_name" : "CambridgeUPELT",
        "indices" : [ 73, 88 ],
        "id_str" : "73107903",
        "id" : 73107903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/uwSycev27h",
        "expanded_url" : "http:\/\/mjobx.com\/fw93CA",
        "display_url" : "mjobx.com\/fw93CA"
      } ]
    },
    "geo" : { },
    "id_str" : "530283147565748226",
    "text" : "Great job available on my team: Senior ELT Research Manager @CambridgeUP @CambridgeUPELT #jobs http:\/\/t.co\/uwSycev27h",
    "id" : 530283147565748226,
    "created_at" : "2014-11-06 08:58:49 +0000",
    "user" : {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "protected" : true,
      "id_str" : "2396240628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478990308630601728\/6zc6XHld_normal.jpeg",
      "id" : 2396240628,
      "verified" : false
    }
  },
  "id" : 530283552110563328,
  "created_at" : "2014-11-06 09:00:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "indices" : [ 3, 18 ],
      "id_str" : "2665944684",
      "id" : 2665944684
    }, {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 51, 63 ],
      "id_str" : "142598896",
      "id" : 142598896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 126, 133 ]
    }, {
      "text" : "iatetl",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "auselt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/cb92lHJwPO",
      "expanded_url" : "http:\/\/www.ltsig.org.uk\/ltgisigevent\/?p=105",
      "display_url" : "ltsig.org.uk\/ltgisigevent\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530281799386427392",
  "text" : "RT @edtechconcerns: Episode 2 - the second part of @Neil_Selwyn interview is now ready for download at http:\/\/t.co\/cb92lHJwPO #edtech #iate\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Selwyn",
        "screen_name" : "Neil_Selwyn",
        "indices" : [ 31, 43 ],
        "id_str" : "142598896",
        "id" : 142598896
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "iatetl",
        "indices" : [ 114, 121 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 122, 130 ]
      }, {
        "text" : "auselt",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/cb92lHJwPO",
        "expanded_url" : "http:\/\/www.ltsig.org.uk\/ltgisigevent\/?p=105",
        "display_url" : "ltsig.org.uk\/ltgisigevent\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530280878019469312",
    "text" : "Episode 2 - the second part of @Neil_Selwyn interview is now ready for download at http:\/\/t.co\/cb92lHJwPO #edtech #iatetl #eltchat #auselt",
    "id" : 530280878019469312,
    "created_at" : "2014-11-06 08:49:48 +0000",
    "user" : {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "protected" : false,
      "id_str" : "2665944684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494409099807715329\/p9ew0Ir4_normal.jpeg",
      "id" : 2665944684,
      "verified" : false
    }
  },
  "id" : 530281799386427392,
  "created_at" : "2014-11-06 08:53:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 139, 140 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/Li0a4KBLew",
      "expanded_url" : "http:\/\/shar.es\/10x8gT",
      "display_url" : "shar.es\/10x8gT"
    } ]
  },
  "geo" : { },
  "id_str" : "530275351910694913",
  "text" : "RT @HancockMcDonald: What makes L2 listening difficult? Not so much the hard words but the easy ones you don't recognize:  http:\/\/t.co\/Li0a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 129, 139 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/Li0a4KBLew",
        "expanded_url" : "http:\/\/shar.es\/10x8gT",
        "display_url" : "shar.es\/10x8gT"
      } ]
    },
    "geo" : { },
    "id_str" : "530268054874103808",
    "text" : "What makes L2 listening difficult? Not so much the hard words but the easy ones you don't recognize:  http:\/\/t.co\/Li0a4KBLew via @sharethis",
    "id" : 530268054874103808,
    "created_at" : "2014-11-06 07:58:50 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 530275351910694913,
  "created_at" : "2014-11-06 08:27:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 7, 23 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/qMftOylUqm",
      "expanded_url" : "https:\/\/www.academia.edu\/519570\/The_vocabulary_performance_of_native_and_non-native_speakers_and_its_relationship_to_learning_style",
      "display_url" : "academia.edu\/519570\/The_voc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "530268194456756224",
  "geo" : { },
  "id_str" : "530274072706703360",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @michaelegriffin Russ any work evaluating Skehan's work on learning styles? reading this interesting paper https:\/\/t.co\/qMftOylUqm",
  "id" : 530274072706703360,
  "in_reply_to_status_id" : 530268194456756224,
  "created_at" : "2014-11-06 08:22:45 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 75, 88 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/sngCk7TGIo",
      "expanded_url" : "http:\/\/wp.me\/p28iGT-13S",
      "display_url" : "wp.me\/p28iGT-13S"
    } ]
  },
  "geo" : { },
  "id_str" : "530263288840331265",
  "text" : "The Rebirth of Cool: Trust, Tech, and Dystopias http:\/\/t.co\/sngCk7TGIo via @tressiemcphd",
  "id" : 530263288840331265,
  "created_at" : "2014-11-06 07:39:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5F4G0yngQN",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#tagant",
      "display_url" : "laurenceanthony.net\/software.html#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530181169929662464",
  "text" : "RT @antlabjp: Just released TagAnt 1.1.1 for Windows, Macintosh, and now *Linux*. A few small bug fixes included, too. Get it here: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/5F4G0yngQN",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#tagant",
        "display_url" : "laurenceanthony.net\/software.html#\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530161135450738688",
    "text" : "Just released TagAnt 1.1.1 for Windows, Macintosh, and now *Linux*. A few small bug fixes included, too. Get it here: http:\/\/t.co\/5F4G0yngQN",
    "id" : 530161135450738688,
    "created_at" : "2014-11-06 00:53:59 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 530181169929662464,
  "created_at" : "2014-11-06 02:13:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530038837557608448",
  "geo" : { },
  "id_str" : "530048719094558721",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 #piratebox for android much easier to setup but not as feature rich as openwrt setup",
  "id" : 530048719094558721,
  "in_reply_to_status_id" : 530038837557608448,
  "created_at" : "2014-11-05 17:27:17 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530021002193825792",
  "geo" : { },
  "id_str" : "530026319187550209",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler the macmillan collocation dictionary might be an option for paper based not got it (yet) but great by all accounts",
  "id" : 530026319187550209,
  "in_reply_to_status_id" : 530021002193825792,
  "created_at" : "2014-11-05 15:58:16 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GcMJptQHwK",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/09\/12\/cutting-your-piratebox-jib\/#comment-1806",
      "display_url" : "eflnotes.wordpress.com\/2014\/09\/12\/cut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530024146743615488",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 did u manage to edit #piratebox files? if not some more info in comment on my blog http:\/\/t.co\/GcMJptQHwK",
  "id" : 530024146743615488,
  "created_at" : "2014-11-05 15:49:38 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 77, 92 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "TBLT",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/sjmLek1Iy2",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-10t",
      "display_url" : "wp.me\/p3qkCB-10t"
    } ]
  },
  "geo" : { },
  "id_str" : "530006950776684544",
  "text" : "RT @Natashetta: Three quick notes related to TBLT http:\/\/t.co\/sjmLek1Iy2 via @GeoffreyJordan #elt #TBLT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 61, 76 ],
        "id_str" : "334332424",
        "id" : 334332424
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "TBLT",
        "indices" : [ 82, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/sjmLek1Iy2",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-10t",
        "display_url" : "wp.me\/p3qkCB-10t"
      } ]
    },
    "geo" : { },
    "id_str" : "530000866950918145",
    "text" : "Three quick notes related to TBLT http:\/\/t.co\/sjmLek1Iy2 via @GeoffreyJordan #elt #TBLT",
    "id" : 530000866950918145,
    "created_at" : "2014-11-05 14:17:08 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 530006950776684544,
  "created_at" : "2014-11-05 14:41:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GlobaLang",
      "screen_name" : "GlobaLangMtl",
      "indices" : [ 3, 16 ],
      "id_str" : "856482139",
      "id" : 856482139
    }, {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 19, 22 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YQUkwpajyR",
      "expanded_url" : "http:\/\/qz.com\/291533",
      "display_url" : "qz.com\/291533"
    } ]
  },
  "geo" : { },
  "id_str" : "529981785372106752",
  "text" : "RT @GlobaLangMtl: \"@qz: This is how liberals and conservatives insult each other http:\/\/t.co\/YQUkwpajyR\" #corpusMOOC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quartz",
        "screen_name" : "qz",
        "indices" : [ 1, 4 ],
        "id_str" : "573918122",
        "id" : 573918122
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 87, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/YQUkwpajyR",
        "expanded_url" : "http:\/\/qz.com\/291533",
        "display_url" : "qz.com\/291533"
      } ]
    },
    "geo" : { },
    "id_str" : "529967330940694529",
    "text" : "\"@qz: This is how liberals and conservatives insult each other http:\/\/t.co\/YQUkwpajyR\" #corpusMOOC",
    "id" : 529967330940694529,
    "created_at" : "2014-11-05 12:03:52 +0000",
    "user" : {
      "name" : "GlobaLang",
      "screen_name" : "GlobaLangMtl",
      "protected" : false,
      "id_str" : "856482139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831040598740993\/UhqVb1BY_normal.jpeg",
      "id" : 856482139,
      "verified" : false
    }
  },
  "id" : 529981785372106752,
  "created_at" : "2014-11-05 13:01:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TuDnPj63MZ",
      "expanded_url" : "http:\/\/hackeducation.com\/2014\/11\/04\/programmed-instruction-versus-the-programmable-web",
      "display_url" : "hackeducation.com\/2014\/11\/04\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529966459980890113",
  "text" : "RT @audreywatters: Transcript from the talk I gave tonight at Pepperdine\u2026 \"The Future of Education: Programmed or Programmable\" http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/TuDnPj63MZ",
        "expanded_url" : "http:\/\/hackeducation.com\/2014\/11\/04\/programmed-instruction-versus-the-programmable-web",
        "display_url" : "hackeducation.com\/2014\/11\/04\/pro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529855269858074624",
    "text" : "Transcript from the talk I gave tonight at Pepperdine\u2026 \"The Future of Education: Programmed or Programmable\" http:\/\/t.co\/TuDnPj63MZ",
    "id" : 529855269858074624,
    "created_at" : "2014-11-05 04:38:35 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 529966459980890113,
  "created_at" : "2014-11-05 12:00:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CORPUSMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/wLgYo1qsXL",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1Ce",
      "display_url" : "wp.me\/p39dN1-1Ce"
    } ]
  },
  "geo" : { },
  "id_str" : "529877725570674689",
  "text" : "RT @drbexl: #CORPUSMOOC Week 5\u00A0(Notes) http:\/\/t.co\/wLgYo1qsXL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CORPUSMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/wLgYo1qsXL",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1Ce",
        "display_url" : "wp.me\/p39dN1-1Ce"
      } ]
    },
    "geo" : { },
    "id_str" : "529676215695572992",
    "text" : "#CORPUSMOOC Week 5\u00A0(Notes) http:\/\/t.co\/wLgYo1qsXL",
    "id" : 529676215695572992,
    "created_at" : "2014-11-04 16:47:05 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 529877725570674689,
  "created_at" : "2014-11-05 06:07:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CORPUSMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/KFb0yzQxPG",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1Ck",
      "display_url" : "wp.me\/p39dN1-1Ck"
    } ]
  },
  "geo" : { },
  "id_str" : "529877549162434561",
  "text" : "RT @drbexl: #CORPUSMOOC Week 6\u00A0(Notes) http:\/\/t.co\/KFb0yzQxPG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CORPUSMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/KFb0yzQxPG",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1Ck",
        "display_url" : "wp.me\/p39dN1-1Ck"
      } ]
    },
    "geo" : { },
    "id_str" : "529693957341466624",
    "text" : "#CORPUSMOOC Week 6\u00A0(Notes) http:\/\/t.co\/KFb0yzQxPG",
    "id" : 529693957341466624,
    "created_at" : "2014-11-04 17:57:35 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 529877549162434561,
  "created_at" : "2014-11-05 06:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 16, 26 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/oaRwc6jFri",
      "expanded_url" : "https:\/\/webmaker.org\/en-US\/appmaker",
      "display_url" : "webmaker.org\/en-US\/appmaker"
    } ]
  },
  "in_reply_to_status_id_str" : "529867773988462592",
  "geo" : { },
  "id_str" : "529871048322609152",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @ELTwriter you could also try mozilla tools e.g. https:\/\/t.co\/oaRwc6jFri",
  "id" : 529871048322609152,
  "in_reply_to_status_id" : 529867773988462592,
  "created_at" : "2014-11-05 05:41:17 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 0, 10 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529769091326701568",
  "geo" : { },
  "id_str" : "529776616520429569",
  "in_reply_to_user_id" : 2882870444,
  "text" : "@TEFLology well it's not a \"big\" error the newspapers made but if u want to be pedantic like me :)",
  "id" : 529776616520429569,
  "in_reply_to_status_id" : 529769091326701568,
  "created_at" : "2014-11-04 23:26:02 +0000",
  "in_reply_to_screen_name" : "TEFLology",
  "in_reply_to_user_id_str" : "2882870444",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESRC",
      "screen_name" : "ESRC",
      "indices" : [ 15, 20 ],
      "id_str" : "19393236",
      "id" : 19393236
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 21, 37 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esrcfestival",
      "indices" : [ 38, 51 ]
    }, {
      "text" : "corpusMOOC",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/QimEsTYPkn",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/4SRV69P79eM",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529768997475323904",
  "text" : "quick notes on @ESRC @CorpusSocialSci #esrcfestival https:\/\/t.co\/QimEsTYPkn #corpusMOOC",
  "id" : 529768997475323904,
  "created_at" : "2014-11-04 22:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive Elsmore",
      "screen_name" : "CliveSir",
      "indices" : [ 3, 12 ],
      "id_str" : "100746717",
      "id" : 100746717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchatie",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "edchat",
      "indices" : [ 123, 130 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 131, 140 ]
    }, {
      "text" : "aussieED",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/3xeE8mtmq3",
      "expanded_url" : "http:\/\/theplf.org\/wp\/category\/plfstudentblog\/",
      "display_url" : "theplf.org\/wp\/category\/pl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529740439113711617",
  "text" : "RT @CliveSir: Does anyone have time to comment on the latest blogs of these young people?\nhttp:\/\/t.co\/3xeE8mtmq3 #edchatie #edchat #ukedcha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchatie",
        "indices" : [ 99, 108 ]
      }, {
        "text" : "edchat",
        "indices" : [ 109, 116 ]
      }, {
        "text" : "ukedchat",
        "indices" : [ 117, 126 ]
      }, {
        "text" : "aussieED",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/3xeE8mtmq3",
        "expanded_url" : "http:\/\/theplf.org\/wp\/category\/plfstudentblog\/",
        "display_url" : "theplf.org\/wp\/category\/pl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529739710563090433",
    "text" : "Does anyone have time to comment on the latest blogs of these young people?\nhttp:\/\/t.co\/3xeE8mtmq3 #edchatie #edchat #ukedchat #aussieED",
    "id" : 529739710563090433,
    "created_at" : "2014-11-04 20:59:23 +0000",
    "user" : {
      "name" : "Clive Elsmore",
      "screen_name" : "CliveSir",
      "protected" : false,
      "id_str" : "100746717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680077570520526848\/ajzqcfNX_normal.jpg",
      "id" : 100746717,
      "verified" : false
    }
  },
  "id" : 529740439113711617,
  "created_at" : "2014-11-04 21:02:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529734804309569537",
  "text" : "RT @CorpusSocialSci: Language learning corpus used in this study will eventually be available for teachers to use #CorpusMOOC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMOOC",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529693668413026304",
    "text" : "Language learning corpus used in this study will eventually be available for teachers to use #CorpusMOOC",
    "id" : 529693668413026304,
    "created_at" : "2014-11-04 17:56:26 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 529734804309569537,
  "created_at" : "2014-11-04 20:39:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 0, 10 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529613884894609409",
  "geo" : { },
  "id_str" : "529680087948722176",
  "in_reply_to_user_id" : 2882870444,
  "text" : "@TEFLology hi re podcast ep10 the figure for marvellous (155)  is raw frequency the normalised freq is 38.4 per million",
  "id" : 529680087948722176,
  "in_reply_to_status_id" : 529613884894609409,
  "created_at" : "2014-11-04 17:02:28 +0000",
  "in_reply_to_screen_name" : "TEFLology",
  "in_reply_to_user_id_str" : "2882870444",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529677992096960514",
  "geo" : { },
  "id_str" : "529679670925864960",
  "in_reply_to_user_id" : 24046458,
  "text" : "@eltstat ok thanks got it :)",
  "id" : 529679670925864960,
  "in_reply_to_status_id" : 529677992096960514,
  "created_at" : "2014-11-04 17:00:49 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter McColl",
      "screen_name" : "PeterMcColl",
      "indices" : [ 3, 15 ],
      "id_str" : "22799312",
      "id" : 22799312
    }, {
      "name" : "Andy Wightman MSP",
      "screen_name" : "andywightman",
      "indices" : [ 104, 117 ],
      "id_str" : "194364678",
      "id" : 194364678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/dgnnFFjSxb",
      "expanded_url" : "http:\/\/www.andywightman.com\/?p=3960",
      "display_url" : "andywightman.com\/?p=3960"
    } ]
  },
  "geo" : { },
  "id_str" : "529642693073567744",
  "text" : "RT @PeterMcColl: The excellent blog on Griff Rhys Jones' mansion tax moaning: http:\/\/t.co\/dgnnFFjSxb by @andywightman has been picked up by\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Wightman MSP",
        "screen_name" : "andywightman",
        "indices" : [ 87, 100 ],
        "id_str" : "194364678",
        "id" : 194364678
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/dgnnFFjSxb",
        "expanded_url" : "http:\/\/www.andywightman.com\/?p=3960",
        "display_url" : "andywightman.com\/?p=3960"
      } ]
    },
    "geo" : { },
    "id_str" : "529640808774123520",
    "text" : "The excellent blog on Griff Rhys Jones' mansion tax moaning: http:\/\/t.co\/dgnnFFjSxb by @andywightman has been picked up by the Guardian",
    "id" : 529640808774123520,
    "created_at" : "2014-11-04 14:26:23 +0000",
    "user" : {
      "name" : "Peter McColl",
      "screen_name" : "PeterMcColl",
      "protected" : false,
      "id_str" : "22799312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684770211032072192\/jP2i9Zov_normal.jpg",
      "id" : 22799312,
      "verified" : false
    }
  },
  "id" : 529642693073567744,
  "created_at" : "2014-11-04 14:33:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Arnott",
      "screen_name" : "PeterArnottGlas",
      "indices" : [ 3, 19 ],
      "id_str" : "2396520638",
      "id" : 2396520638
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PeterArnottGlas\/status\/528985647798042625\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/s6GLO9GklQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1dVpIYIgAAapUQ.jpg",
      "id_str" : "528985646351024128",
      "id" : 528985646351024128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1dVpIYIgAAapUQ.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/s6GLO9GklQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529642625411084288",
  "text" : "RT @PeterArnottGlas: This is not honouring the dead, it is controlling the present. This is not remembrance, this is the thought police. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PeterArnottGlas\/status\/528985647798042625\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/s6GLO9GklQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1dVpIYIgAAapUQ.jpg",
        "id_str" : "528985646351024128",
        "id" : 528985646351024128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1dVpIYIgAAapUQ.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/s6GLO9GklQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528985647798042625",
    "text" : "This is not honouring the dead, it is controlling the present. This is not remembrance, this is the thought police. http:\/\/t.co\/s6GLO9GklQ",
    "id" : 528985647798042625,
    "created_at" : "2014-11-02 19:03:01 +0000",
    "user" : {
      "name" : "Peter Arnott",
      "screen_name" : "PeterArnottGlas",
      "protected" : false,
      "id_str" : "2396520638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616378516557426688\/13l5FkzJ_normal.jpg",
      "id" : 2396520638,
      "verified" : false
    }
  },
  "id" : 529642625411084288,
  "created_at" : "2014-11-04 14:33:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    }, {
      "name" : "Corpusbaalsig",
      "screen_name" : "corpusbaalsig",
      "indices" : [ 38, 52 ],
      "id_str" : "2741766716",
      "id" : 2741766716
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/N7FILfJT8e",
      "expanded_url" : "http:\/\/www.baal.org.uk\/sig_corp_ling.html",
      "display_url" : "baal.org.uk\/sig_corp_ling.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529639808877228032",
  "text" : "RT @duygucandarli: Looking forward to @corpusbaalsig's workshop 'An intro. to advanced corpus visualization tools'. #corpuslinguistics http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Corpusbaalsig",
        "screen_name" : "corpusbaalsig",
        "indices" : [ 19, 33 ],
        "id_str" : "2741766716",
        "id" : 2741766716
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 97, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/N7FILfJT8e",
        "expanded_url" : "http:\/\/www.baal.org.uk\/sig_corp_ling.html",
        "display_url" : "baal.org.uk\/sig_corp_ling.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529629167231729664",
    "text" : "Looking forward to @corpusbaalsig's workshop 'An intro. to advanced corpus visualization tools'. #corpuslinguistics http:\/\/t.co\/N7FILfJT8e",
    "id" : 529629167231729664,
    "created_at" : "2014-11-04 13:40:08 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 529639808877228032,
  "created_at" : "2014-11-04 14:22:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529639127650942978",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin uknowwhatimean mike? :)",
  "id" : 529639127650942978,
  "created_at" : "2014-11-04 14:19:42 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529638264140206080",
  "text" : "some people don't seem to get social media management :\/",
  "id" : 529638264140206080,
  "created_at" : "2014-11-04 14:16:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528935993202987010",
  "geo" : { },
  "id_str" : "529617300832665600",
  "in_reply_to_user_id" : 24046458,
  "text" : "@eltstat hi tried to comment but don't think comment got through?",
  "id" : 529617300832665600,
  "in_reply_to_status_id" : 528935993202987010,
  "created_at" : "2014-11-04 12:52:58 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 99, 115 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/C1aNvXtKDL",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-4I",
      "display_url" : "wp.me\/p28EmH-4I"
    } ]
  },
  "geo" : { },
  "id_str" : "529610363411505152",
  "text" : "Interactive whiteboards in foreign language education: the story so far http:\/\/t.co\/C1aNvXtKDL via @wordpressdotcom",
  "id" : 529610363411505152,
  "created_at" : "2014-11-04 12:25:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "ESRC",
      "screen_name" : "ESRC",
      "indices" : [ 134, 139 ],
      "id_str" : "19393236",
      "id" : 19393236
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 139, 140 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/D8jvfpJkWU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=hF_fl95tiSk",
      "display_url" : "youtube.com\/watch?v=hF_fl9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529606671044460544",
  "text" : "RT @HardieResearch: \"Language Matters: Communication, Culture, and Society (#corpusMOOC)\" also streamed here: https:\/\/t.co\/D8jvfpJkWU @ESRC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ESRC",
        "screen_name" : "ESRC",
        "indices" : [ 114, 119 ],
        "id_str" : "19393236",
        "id" : 19393236
      }, {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 120, 136 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 56, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/D8jvfpJkWU",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=hF_fl95tiSk",
        "display_url" : "youtube.com\/watch?v=hF_fl9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529554183251558400",
    "text" : "\"Language Matters: Communication, Culture, and Society (#corpusMOOC)\" also streamed here: https:\/\/t.co\/D8jvfpJkWU @ESRC @CorpusSocialSci",
    "id" : 529554183251558400,
    "created_at" : "2014-11-04 08:42:10 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 529606671044460544,
  "created_at" : "2014-11-04 12:10:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529518654749442048",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE thx for RT visual aid, how r u finding #corpusmooc?",
  "id" : 529518654749442048,
  "created_at" : "2014-11-04 06:20:59 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/529439233770258432\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/DPHHGjgRce",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1jyLS7IAAAJBHT.png",
      "id_str" : "529439232088342528",
      "id" : 529439232088342528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1jyLS7IAAAJBHT.png",
      "sizes" : [ {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DPHHGjgRce"
    } ],
    "hashtags" : [ {
      "text" : "Piratebox",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/oJWKGhe0KZ",
      "expanded_url" : "http:\/\/www.piratebox.cc\/openwrt:diy#upgrade_piratebox",
      "display_url" : "piratebox.cc\/openwrt:diy#up\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529517184784285696",
  "text" : "RT @josipa74: #Piratebox finally up and running! http:\/\/t.co\/oJWKGhe0KZ http:\/\/t.co\/DPHHGjgRce",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/529439233770258432\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/DPHHGjgRce",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1jyLS7IAAAJBHT.png",
        "id_str" : "529439232088342528",
        "id" : 529439232088342528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1jyLS7IAAAJBHT.png",
        "sizes" : [ {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DPHHGjgRce"
      } ],
      "hashtags" : [ {
        "text" : "Piratebox",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/oJWKGhe0KZ",
        "expanded_url" : "http:\/\/www.piratebox.cc\/openwrt:diy#upgrade_piratebox",
        "display_url" : "piratebox.cc\/openwrt:diy#up\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529439233770258432",
    "text" : "#Piratebox finally up and running! http:\/\/t.co\/oJWKGhe0KZ http:\/\/t.co\/DPHHGjgRce",
    "id" : 529439233770258432,
    "created_at" : "2014-11-04 01:05:24 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 529517184784285696,
  "created_at" : "2014-11-04 06:15:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529439233770258432",
  "geo" : { },
  "id_str" : "529516962108678144",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 woot :)",
  "id" : 529516962108678144,
  "in_reply_to_status_id" : 529439233770258432,
  "created_at" : "2014-11-04 06:14:16 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 3, 15 ],
      "id_str" : "533125583",
      "id" : 533125583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/O7MULPrYOA",
      "expanded_url" : "http:\/\/wp.me\/p2uWUJ-7X",
      "display_url" : "wp.me\/p2uWUJ-7X"
    } ]
  },
  "geo" : { },
  "id_str" : "529375333834059776",
  "text" : "RT @teahorvatic: Week 2 of Corpus Linguistics course - summary #corpusMOOC http:\/\/t.co\/O7MULPrYOA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 46, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/O7MULPrYOA",
        "expanded_url" : "http:\/\/wp.me\/p2uWUJ-7X",
        "display_url" : "wp.me\/p2uWUJ-7X"
      } ]
    },
    "geo" : { },
    "id_str" : "529373546095468544",
    "text" : "Week 2 of Corpus Linguistics course - summary #corpusMOOC http:\/\/t.co\/O7MULPrYOA",
    "id" : 529373546095468544,
    "created_at" : "2014-11-03 20:44:23 +0000",
    "user" : {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "protected" : false,
      "id_str" : "533125583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363766953\/qFdM59R9_normal",
      "id" : 533125583,
      "verified" : false
    }
  },
  "id" : 529375333834059776,
  "created_at" : "2014-11-03 20:51:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/qOGFABrWSU",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3327142-collocation-colligation",
      "display_url" : "magic.piktochart.com\/output\/3327142\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529360678872956928",
  "text" : "another simplified visual aid #corpusmooc Collocations &amp; colligations with byu coca links https:\/\/t.co\/qOGFABrWSU",
  "id" : 529360678872956928,
  "created_at" : "2014-11-03 19:53:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "indices" : [ 3, 18 ],
      "id_str" : "2665944684",
      "id" : 2665944684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "Edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/b0b1ynCzlw",
      "expanded_url" : "http:\/\/www.ltsig.org.uk\/ltgisigevent\/?p=23",
      "display_url" : "ltsig.org.uk\/ltgisigevent\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529245479167856640",
  "text" : "RT @edtechconcerns: Episode 1 of the podcast is now live, you can find out how to listen by visiting thew show page http:\/\/t.co\/b0b1ynCzlw \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 119, 126 ]
      }, {
        "text" : "Edtech",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/b0b1ynCzlw",
        "expanded_url" : "http:\/\/www.ltsig.org.uk\/ltgisigevent\/?p=23",
        "display_url" : "ltsig.org.uk\/ltgisigevent\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529192385230950400",
    "text" : "Episode 1 of the podcast is now live, you can find out how to listen by visiting thew show page http:\/\/t.co\/b0b1ynCzlw #IATEFL #Edtech",
    "id" : 529192385230950400,
    "created_at" : "2014-11-03 08:44:31 +0000",
    "user" : {
      "name" : "edtechconcerns",
      "screen_name" : "edtechconcerns",
      "protected" : false,
      "id_str" : "2665944684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494409099807715329\/p9ew0Ir4_normal.jpeg",
      "id" : 2665944684,
      "verified" : false
    }
  },
  "id" : 529245479167856640,
  "created_at" : "2014-11-03 12:15:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian g",
      "screen_name" : "bodhibrian",
      "indices" : [ 3, 14 ],
      "id_str" : "2686106365",
      "id" : 2686106365
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 16, 26 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 27, 39 ],
      "id_str" : "728039605",
      "id" : 728039605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/b4Dekdw9z8",
      "expanded_url" : "http:\/\/www.middle-east-online.com\/english\/?id=68744",
      "display_url" : "middle-east-online.com\/english\/?id=68\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529242400359997440",
  "text" : "RT @bodhibrian: @medialens @NeilClark66 Tunisia expels Bernard Henry Levy \n\u2018Godfather of civil wars in Arab world\u2019\nhttp:\/\/t.co\/b4Dekdw9z8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 0, 10 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "Neil Clark",
        "screen_name" : "NeilClark66",
        "indices" : [ 11, 23 ],
        "id_str" : "728039605",
        "id" : 728039605
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/b4Dekdw9z8",
        "expanded_url" : "http:\/\/www.middle-east-online.com\/english\/?id=68744",
        "display_url" : "middle-east-online.com\/english\/?id=68\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "529190914523414528",
    "geo" : { },
    "id_str" : "529230861141413888",
    "in_reply_to_user_id" : 6531902,
    "text" : "@medialens @NeilClark66 Tunisia expels Bernard Henry Levy \n\u2018Godfather of civil wars in Arab world\u2019\nhttp:\/\/t.co\/b4Dekdw9z8",
    "id" : 529230861141413888,
    "in_reply_to_status_id" : 529190914523414528,
    "created_at" : "2014-11-03 11:17:24 +0000",
    "in_reply_to_screen_name" : "medialens",
    "in_reply_to_user_id_str" : "6531902",
    "user" : {
      "name" : "brian g",
      "screen_name" : "bodhibrian",
      "protected" : false,
      "id_str" : "2686106365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574743504561160193\/soU2ifti_normal.jpeg",
      "id" : 2686106365,
      "verified" : false
    }
  },
  "id" : 529242400359997440,
  "created_at" : "2014-11-03 12:03:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/I02PFNNbWL",
      "expanded_url" : "http:\/\/www.carbonbrief.org\/blog\/2014\/11\/briefing-the-ipcc-synthesis-report-new-and-interesting\/#.VFdfyf9m0YY.twitter",
      "display_url" : "carbonbrief.org\/blog\/2014\/11\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529226098668617728",
  "text" : "Briefing: What's new and interesting in the IPCC synthesis report | Carbon Brief: http:\/\/t.co\/I02PFNNbWL",
  "id" : 529226098668617728,
  "created_at" : "2014-11-03 10:58:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "materialswriting",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/kdDWM40hA8",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-jw",
      "display_url" : "wp.me\/p1RJaO-jw"
    } ]
  },
  "geo" : { },
  "id_str" : "529207163294875649",
  "text" : "RT @NicolaPrentis: Reverse Reading - a quick approach to prepping Conversation classes #ELT #materialswriting http:\/\/t.co\/kdDWM40hA8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 68, 72 ]
      }, {
        "text" : "materialswriting",
        "indices" : [ 73, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/kdDWM40hA8",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-jw",
        "display_url" : "wp.me\/p1RJaO-jw"
      } ]
    },
    "geo" : { },
    "id_str" : "529204041906020352",
    "text" : "Reverse Reading - a quick approach to prepping Conversation classes #ELT #materialswriting http:\/\/t.co\/kdDWM40hA8",
    "id" : 529204041906020352,
    "created_at" : "2014-11-03 09:30:50 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 529207163294875649,
  "created_at" : "2014-11-03 09:43:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 117, 133 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/IzZPtWcF6x",
      "expanded_url" : "http:\/\/wp.me\/p56TGC-22",
      "display_url" : "wp.me\/p56TGC-22"
    } ]
  },
  "geo" : { },
  "id_str" : "528982508205924352",
  "text" : "\u201CBeing Poor is Not Entertainment\u201D: Class Struggles against Poverty Porn - By Imogen Tyler http:\/\/t.co\/IzZPtWcF6x via @wordpressdotcom",
  "id" : 528982508205924352,
  "created_at" : "2014-11-02 18:50:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 81, 97 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/U7YbWKDaDH",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-Zo",
      "display_url" : "wp.me\/p21lsm-Zo"
    } ]
  },
  "geo" : { },
  "id_str" : "528947550561136641",
  "text" : "Teaching listening: Australian accent (a lesson plan) http:\/\/t.co\/U7YbWKDaDH via @wordpressdotcom",
  "id" : 528947550561136641,
  "created_at" : "2014-11-02 16:31:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 0, 11 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/bxSI0xVxsO",
      "expanded_url" : "https:\/\/medium.com\/advice-and-help-in-authoring-a-phd-or-non-fiction\/academic-citation-practices-need-to-be-modernized-6eb2e4a44846?utm_content=buffer212a2&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "medium.com\/advice-and-hel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "528897610535682048",
  "geo" : { },
  "id_str" : "528900184877830144",
  "in_reply_to_user_id" : 134191406,
  "text" : "@AchilleasK another reason to modernise citations https:\/\/t.co\/bxSI0xVxsO",
  "id" : 528900184877830144,
  "in_reply_to_status_id" : 528897610535682048,
  "created_at" : "2014-11-02 13:23:25 +0000",
  "in_reply_to_screen_name" : "AchilleasK",
  "in_reply_to_user_id_str" : "134191406",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/rr7pMQQGlF",
      "expanded_url" : "http:\/\/www.r-bloggers.com\/exploration-of-letter-make-up-of-english-words\/",
      "display_url" : "r-bloggers.com\/exploration-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528891078095958016",
  "text" : "RT @langstat: Exploration of Letter Make Up of English Words | (R news &amp; tutorials) http:\/\/t.co\/rr7pMQQGlF word lengths, frequency and posi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/rr7pMQQGlF",
        "expanded_url" : "http:\/\/www.r-bloggers.com\/exploration-of-letter-make-up-of-english-words\/",
        "display_url" : "r-bloggers.com\/exploration-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528738763925504002",
    "text" : "Exploration of Letter Make Up of English Words | (R news &amp; tutorials) http:\/\/t.co\/rr7pMQQGlF word lengths, frequency and position of letters",
    "id" : 528738763925504002,
    "created_at" : "2014-11-02 02:41:59 +0000",
    "user" : {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "protected" : false,
      "id_str" : "108896452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111159202\/profile_normal.gif",
      "id" : 108896452,
      "verified" : false
    }
  },
  "id" : 528891078095958016,
  "created_at" : "2014-11-02 12:47:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguisticlandscapes",
      "indices" : [ 45, 66 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Tz6fyZno5G",
      "expanded_url" : "http:\/\/davidharbinson.com\/linguistic-landscapes-in-korea-and-wales\/",
      "display_url" : "davidharbinson.com\/linguistic-lan\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2o7ZzY29bq",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.kr\/2014\/11\/domestic-linguistic-landscapes.html?spref=tw",
      "display_url" : "how-i-see-it-now.blogspot.kr\/2014\/11\/domest\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528880583804747776",
  "text" : "RT @michaelegriffin: Wow, two great posts on #linguisticlandscapes in advance of the #keltchat in 10 min. \na) http:\/\/t.co\/Tz6fyZno5G \nb) ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguisticlandscapes",
        "indices" : [ 24, 45 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 64, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Tz6fyZno5G",
        "expanded_url" : "http:\/\/davidharbinson.com\/linguistic-landscapes-in-korea-and-wales\/",
        "display_url" : "davidharbinson.com\/linguistic-lan\u2026"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/2o7ZzY29bq",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.kr\/2014\/11\/domestic-linguistic-landscapes.html?spref=tw",
        "display_url" : "how-i-see-it-now.blogspot.kr\/2014\/11\/domest\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528861457773903873",
    "text" : "Wow, two great posts on #linguisticlandscapes in advance of the #keltchat in 10 min. \na) http:\/\/t.co\/Tz6fyZno5G \nb) http:\/\/t.co\/2o7ZzY29bq",
    "id" : 528861457773903873,
    "created_at" : "2014-11-02 10:49:31 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 528880583804747776,
  "created_at" : "2014-11-02 12:05:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChangeinELT",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528844182782087169",
  "geo" : { },
  "id_str" : "528847059034857472",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson a #ChangeinELT gotta come...gotta be fought...gotta fill-in-the-blanks...",
  "id" : 528847059034857472,
  "in_reply_to_status_id" : 528844182782087169,
  "created_at" : "2014-11-02 09:52:19 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 65, 81 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Jq1oAQAiVo",
      "expanded_url" : "http:\/\/wp.me\/p4lNv-rF",
      "display_url" : "wp.me\/p4lNv-rF"
    } ]
  },
  "geo" : { },
  "id_str" : "528845405207805952",
  "text" : "From Here: MOOCs and Higher Education http:\/\/t.co\/Jq1oAQAiVo via @wordpressdotcom",
  "id" : 528845405207805952,
  "created_at" : "2014-11-02 09:45:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/SpWxp4xVbk",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2014\/11\/fuck-elt-to-hell.html",
      "display_url" : "giaklamata.blogspot.fr\/2014\/11\/fuck-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528843675879895040",
  "text" : "Fuck ELT to Hell http:\/\/t.co\/SpWxp4xVbk",
  "id" : 528843675879895040,
  "created_at" : "2014-11-02 09:38:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 0, 15 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528665624437088256",
  "geo" : { },
  "id_str" : "528669672380846081",
  "in_reply_to_user_id" : 1327355143,
  "text" : "@EvilJoeMcVeigh some nice disclaimers:frequency and recency effects,\"It\u2019s my nonscientific theory that..in part... \" :)",
  "id" : 528669672380846081,
  "in_reply_to_status_id" : 528665624437088256,
  "created_at" : "2014-11-01 22:07:26 +0000",
  "in_reply_to_screen_name" : "EvilJoeMcVeigh",
  "in_reply_to_user_id_str" : "1327355143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Steiner",
      "screen_name" : "tomayac",
      "indices" : [ 3, 11 ],
      "id_str" : "14697496",
      "id" : 14697496
    }, {
      "name" : "Brian Keegan",
      "screen_name" : "bkeegan",
      "indices" : [ 104, 112 ],
      "id_str" : "16629994",
      "id" : 16629994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Bo2Lm9J297",
      "expanded_url" : "https:\/\/adrianshort.org\/unethical-twitter\/",
      "display_url" : "adrianshort.org\/unethical-twit\u2026"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/NWihuiBTOb",
      "expanded_url" : "http:\/\/www.brianckeegan.com\/2014\/10\/my-15-minutes-of-fame-as-a-b-list-gamergate-celebrity\/",
      "display_url" : "brianckeegan.com\/2014\/10\/my-15-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528559528699510784",
  "text" : "RT @tomayac: Unethical uses for public Twitter data - Adrian Short - https:\/\/t.co\/Bo2Lm9J297 (link from @bkeegan's post http:\/\/t.co\/NWihuiB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Keegan",
        "screen_name" : "bkeegan",
        "indices" : [ 91, 99 ],
        "id_str" : "16629994",
        "id" : 16629994
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/Bo2Lm9J297",
        "expanded_url" : "https:\/\/adrianshort.org\/unethical-twitter\/",
        "display_url" : "adrianshort.org\/unethical-twit\u2026"
      }, {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/NWihuiBTOb",
        "expanded_url" : "http:\/\/www.brianckeegan.com\/2014\/10\/my-15-minutes-of-fame-as-a-b-list-gamergate-celebrity\/",
        "display_url" : "brianckeegan.com\/2014\/10\/my-15-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528311433642385408",
    "text" : "Unethical uses for public Twitter data - Adrian Short - https:\/\/t.co\/Bo2Lm9J297 (link from @bkeegan's post http:\/\/t.co\/NWihuiBTOb)",
    "id" : 528311433642385408,
    "created_at" : "2014-10-31 22:23:55 +0000",
    "user" : {
      "name" : "Thomas Steiner",
      "screen_name" : "tomayac",
      "protected" : false,
      "id_str" : "14697496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758412790029750280\/fHw8Dxah_normal.jpg",
      "id" : 14697496,
      "verified" : false
    }
  },
  "id" : 528559528699510784,
  "created_at" : "2014-11-01 14:49:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 122, 138 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6QUmzdO2tR",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-3G",
      "display_url" : "wp.me\/p35kaI-3G"
    } ]
  },
  "geo" : { },
  "id_str" : "528558229945454593",
  "text" : "An Analysis of David Cameron's \"Isil poses a direct and deadly threat to Britain\" letter in T\u2026 http:\/\/t.co\/6QUmzdO2tR via @wordpressdotcom",
  "id" : 528558229945454593,
  "created_at" : "2014-11-01 14:44:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 3, 16 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 52, 65 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beltabelgium",
      "indices" : [ 122, 135 ]
    }, {
      "text" : "webinars",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "esol",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Cn5EEkylrb",
      "expanded_url" : "http:\/\/www.beltabelgium.com\/corpora-in-the-english-classroom-by-johan-strobbe\/",
      "display_url" : "beltabelgium.com\/corpora-in-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528541929659977729",
  "text" : "RT @BELTABelgium: Watch Johan Strobbe's webinar for @BELTABelgium Corpora in the English Classroom http:\/\/t.co\/Cn5EEkylrb #beltabelgium #we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 34, 47 ],
        "id_str" : "884934438",
        "id" : 884934438
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "beltabelgium",
        "indices" : [ 104, 117 ]
      }, {
        "text" : "webinars",
        "indices" : [ 118, 127 ]
      }, {
        "text" : "esol",
        "indices" : [ 128, 133 ]
      }, {
        "text" : "esl",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Cn5EEkylrb",
        "expanded_url" : "http:\/\/www.beltabelgium.com\/corpora-in-the-english-classroom-by-johan-strobbe\/",
        "display_url" : "beltabelgium.com\/corpora-in-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528540278677069825",
    "text" : "Watch Johan Strobbe's webinar for @BELTABelgium Corpora in the English Classroom http:\/\/t.co\/Cn5EEkylrb #beltabelgium #webinars #esol #esl",
    "id" : 528540278677069825,
    "created_at" : "2014-11-01 13:33:16 +0000",
    "user" : {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "protected" : false,
      "id_str" : "884934438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3130800745\/d36391a9857692e6c2aab76d0033ade0_normal.png",
      "id" : 884934438,
      "verified" : false
    }
  },
  "id" : 528541929659977729,
  "created_at" : "2014-11-01 13:39:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]