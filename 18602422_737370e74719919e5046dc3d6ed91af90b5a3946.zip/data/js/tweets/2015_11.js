Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "indices" : [ 3, 16 ],
      "id_str" : "2820709207",
      "id" : 2820709207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/C71dXijwFH",
      "expanded_url" : "https:\/\/debuk.wordpress.com\/2015\/11\/29\/passive-aggressive\/",
      "display_url" : "debuk.wordpress.com\/2015\/11\/29\/pas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671423369066229760",
  "text" : "RT @wordspinster: Language: a feminist guide says the passive can be our friend...https:\/\/t.co\/C71dXijwFH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/C71dXijwFH",
        "expanded_url" : "https:\/\/debuk.wordpress.com\/2015\/11\/29\/passive-aggressive\/",
        "display_url" : "debuk.wordpress.com\/2015\/11\/29\/pas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671080980858470400",
    "text" : "Language: a feminist guide says the passive can be our friend...https:\/\/t.co\/C71dXijwFH",
    "id" : 671080980858470400,
    "created_at" : "2015-11-29 21:39:08 +0000",
    "user" : {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "protected" : false,
      "id_str" : "2820709207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671103881812799488\/n6CtqOqq_normal.jpg",
      "id" : 2820709207,
      "verified" : false
    }
  },
  "id" : 671423369066229760,
  "created_at" : "2015-11-30 20:19:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Dearden",
      "screen_name" : "nickdearden75",
      "indices" : [ 3, 17 ],
      "id_str" : "306756011",
      "id" : 306756011
    }, {
      "name" : "Chuka Umunna",
      "screen_name" : "ChukaUmunna",
      "indices" : [ 77, 89 ],
      "id_str" : "33300246",
      "id" : 33300246
    }, {
      "name" : "Hilary Benn",
      "screen_name" : "hilarybennmp",
      "indices" : [ 90, 103 ],
      "id_str" : "408454349",
      "id" : 408454349
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontBombSyria",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671421124874510337",
  "text" : "RT @nickdearden75: First time I've ever come across warmongers of conscience @ChukaUmunna @hilarybennmp #DontBombSyria",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chuka Umunna",
        "screen_name" : "ChukaUmunna",
        "indices" : [ 58, 70 ],
        "id_str" : "33300246",
        "id" : 33300246
      }, {
        "name" : "Hilary Benn",
        "screen_name" : "hilarybennmp",
        "indices" : [ 71, 84 ],
        "id_str" : "408454349",
        "id" : 408454349
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontBombSyria",
        "indices" : [ 85, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671390831710965761",
    "text" : "First time I've ever come across warmongers of conscience @ChukaUmunna @hilarybennmp #DontBombSyria",
    "id" : 671390831710965761,
    "created_at" : "2015-11-30 18:10:22 +0000",
    "user" : {
      "name" : "Nick Dearden",
      "screen_name" : "nickdearden75",
      "protected" : false,
      "id_str" : "306756011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504738225215537152\/rGl44uyF_normal.jpeg",
      "id" : 306756011,
      "verified" : false
    }
  },
  "id" : 671421124874510337,
  "created_at" : "2015-11-30 20:10:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "People's NHS",
      "screen_name" : "PeoplesNHS",
      "indices" : [ 3, 14 ],
      "id_str" : "2563656001",
      "id" : 2563656001
    }, {
      "name" : "Richard Branson",
      "screen_name" : "richardbranson",
      "indices" : [ 25, 40 ],
      "id_str" : "8161232",
      "id" : 8161232
    }, {
      "name" : "Virgin Care",
      "screen_name" : "VirginCare",
      "indices" : [ 75, 86 ],
      "id_str" : "523083751",
      "id" : 523083751
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PeoplesNHS\/status\/670987097126277122\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/keUrjYrb1Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUqfO5QWIAAk1s7.jpg",
      "id_str" : "669522572854304768",
      "id" : 669522572854304768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUqfO5QWIAAk1s7.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/keUrjYrb1Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5Q40MLCeDv",
      "expanded_url" : "http:\/\/action.peoplesnhs.org\/virgin",
      "display_url" : "action.peoplesnhs.org\/virgin"
    } ]
  },
  "geo" : { },
  "id_str" : "670999270649151488",
  "text" : "RT @PeoplesNHS: Write to @richardbranson and tell him what you think about @Virgincare running NHS services https:\/\/t.co\/5Q40MLCeDv https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Branson",
        "screen_name" : "richardbranson",
        "indices" : [ 9, 24 ],
        "id_str" : "8161232",
        "id" : 8161232
      }, {
        "name" : "Virgin Care",
        "screen_name" : "VirginCare",
        "indices" : [ 59, 70 ],
        "id_str" : "523083751",
        "id" : 523083751
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PeoplesNHS\/status\/670987097126277122\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/keUrjYrb1Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUqfO5QWIAAk1s7.jpg",
        "id_str" : "669522572854304768",
        "id" : 669522572854304768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUqfO5QWIAAk1s7.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/keUrjYrb1Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/5Q40MLCeDv",
        "expanded_url" : "http:\/\/action.peoplesnhs.org\/virgin",
        "display_url" : "action.peoplesnhs.org\/virgin"
      } ]
    },
    "geo" : { },
    "id_str" : "670987097126277122",
    "text" : "Write to @richardbranson and tell him what you think about @Virgincare running NHS services https:\/\/t.co\/5Q40MLCeDv https:\/\/t.co\/keUrjYrb1Z",
    "id" : 670987097126277122,
    "created_at" : "2015-11-29 15:26:04 +0000",
    "user" : {
      "name" : "People's NHS",
      "screen_name" : "PeoplesNHS",
      "protected" : false,
      "id_str" : "2563656001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481431102599356416\/-OZkfINk_normal.jpeg",
      "id" : 2563656001,
      "verified" : false
    }
  },
  "id" : 670999270649151488,
  "created_at" : "2015-11-29 16:14:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 10, 21 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668600381602193408",
  "geo" : { },
  "id_str" : "670753856729518080",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @MattEllman disappointed no more RTS likes perhaps testament to the stubbornly enduring reality distortion field Mitra makes",
  "id" : 670753856729518080,
  "in_reply_to_status_id" : 668600381602193408,
  "created_at" : "2015-11-28 23:59:16 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/FFg5NOiBhn",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/11\/bullies-beaten.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/11\/bullie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670616577956585477",
  "text" : "RT @pchallinor: New mudgeonry: Bullies beaten https:\/\/t.co\/FFg5NOiBhn Shapps not included",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/FFg5NOiBhn",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/11\/bullies-beaten.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/11\/bullie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670610179394805761",
    "text" : "New mudgeonry: Bullies beaten https:\/\/t.co\/FFg5NOiBhn Shapps not included",
    "id" : 670610179394805761,
    "created_at" : "2015-11-28 14:28:20 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 670616577956585477,
  "created_at" : "2015-11-28 14:53:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/662fBe8C01",
      "expanded_url" : "https:\/\/twitter.com\/Ian_Fraser\/status\/670543661491462144",
      "display_url" : "twitter.com\/Ian_Fraser\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670614675906760705",
  "text" : "RT @pchallinor: \"Moderate death for all\" https:\/\/t.co\/662fBe8C01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/662fBe8C01",
        "expanded_url" : "https:\/\/twitter.com\/Ian_Fraser\/status\/670543661491462144",
        "display_url" : "twitter.com\/Ian_Fraser\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670600417110319105",
    "text" : "\"Moderate death for all\" https:\/\/t.co\/662fBe8C01",
    "id" : 670600417110319105,
    "created_at" : "2015-11-28 13:49:33 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 670614675906760705,
  "created_at" : "2015-11-28 14:46:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Research",
      "screen_name" : "CRG_CRM",
      "indices" : [ 3, 11 ],
      "id_str" : "1633453286",
      "id" : 1633453286
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CRG_CRM\/status\/670399320198393856\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/JldSh71BHG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU28oSVWEAEOuM8.png",
      "id_str" : "670399319850225665",
      "id" : 670399319850225665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU28oSVWEAEOuM8.png",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 257
      } ],
      "display_url" : "pic.twitter.com\/JldSh71BHG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/aAE5yuzDAo",
      "expanded_url" : "http:\/\/ow.ly\/VaMmV",
      "display_url" : "ow.ly\/VaMmV"
    } ]
  },
  "geo" : { },
  "id_str" : "670574199593943041",
  "text" : "RT @CRG_CRM: The Dirty War on Syria https:\/\/t.co\/aAE5yuzDAo https:\/\/t.co\/JldSh71BHG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CRG_CRM\/status\/670399320198393856\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/JldSh71BHG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU28oSVWEAEOuM8.png",
        "id_str" : "670399319850225665",
        "id" : 670399319850225665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU28oSVWEAEOuM8.png",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 257
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 257
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 257
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 257
        } ],
        "display_url" : "pic.twitter.com\/JldSh71BHG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/aAE5yuzDAo",
        "expanded_url" : "http:\/\/ow.ly\/VaMmV",
        "display_url" : "ow.ly\/VaMmV"
      } ]
    },
    "geo" : { },
    "id_str" : "670399320198393856",
    "text" : "The Dirty War on Syria https:\/\/t.co\/aAE5yuzDAo https:\/\/t.co\/JldSh71BHG",
    "id" : 670399320198393856,
    "created_at" : "2015-11-28 00:30:28 +0000",
    "user" : {
      "name" : "Global Research",
      "screen_name" : "CRG_CRM",
      "protected" : false,
      "id_str" : "1633453286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000215689056\/240ee570fb33bec15bad367640e67f73_normal.png",
      "id" : 1633453286,
      "verified" : false
    }
  },
  "id" : 670574199593943041,
  "created_at" : "2015-11-28 12:05:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLCR",
      "screen_name" : "clcr_cardiffu",
      "indices" : [ 0, 14 ],
      "id_str" : "403672027",
      "id" : 403672027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670560878337597440",
  "geo" : { },
  "id_str" : "670561485404422144",
  "in_reply_to_user_id" : 403672027,
  "text" : "@clcr_cardiffu ok thx &amp; thx for tweetng conf :)",
  "id" : 670561485404422144,
  "in_reply_to_status_id" : 670560878337597440,
  "created_at" : "2015-11-28 11:14:51 +0000",
  "in_reply_to_screen_name" : "clcr_cardiffu",
  "in_reply_to_user_id_str" : "403672027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLCR",
      "screen_name" : "clcr_cardiffu",
      "indices" : [ 0, 14 ],
      "id_str" : "403672027",
      "id" : 403672027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cls10",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670557432721051648",
  "geo" : { },
  "id_str" : "670559822207651840",
  "in_reply_to_user_id" : 403672027,
  "text" : "@clcr_cardiffu can anyone pass on Q? : ) it's a general method issue as well i guess? #cls10",
  "id" : 670559822207651840,
  "in_reply_to_status_id" : 670557432721051648,
  "created_at" : "2015-11-28 11:08:14 +0000",
  "in_reply_to_screen_name" : "clcr_cardiffu",
  "in_reply_to_user_id_str" : "403672027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Pegg",
      "screen_name" : "EdPegg",
      "indices" : [ 78, 85 ],
      "id_str" : "294186494",
      "id" : 294186494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/3sY3sHwl9Q",
      "expanded_url" : "http:\/\/wp.me\/p6Yg7J-1R",
      "display_url" : "wp.me\/p6Yg7J-1R"
    } ]
  },
  "geo" : { },
  "id_str" : "670559355616542720",
  "text" : "Theories behind Business Linguistics: Speech Acts https:\/\/t.co\/3sY3sHwl9Q via @EdPegg",
  "id" : 670559355616542720,
  "created_at" : "2015-11-28 11:06:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Podant",
      "screen_name" : "ThePodant",
      "indices" : [ 64, 74 ],
      "id_str" : "2439828074",
      "id" : 2439828074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/V4MhpcR9Aa",
      "expanded_url" : "http:\/\/wp.me\/p4bxI2-aN",
      "display_url" : "wp.me\/p4bxI2-aN"
    } ]
  },
  "geo" : { },
  "id_str" : "670559238889058304",
  "text" : "An alternative approach to phonemes https:\/\/t.co\/V4MhpcR9Aa via @ThePodant",
  "id" : 670559238889058304,
  "created_at" : "2015-11-28 11:05:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLCR",
      "screen_name" : "clcr_cardiffu",
      "indices" : [ 0, 14 ],
      "id_str" : "403672027",
      "id" : 403672027
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 59, 68 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cls10",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670547832089280512",
  "geo" : { },
  "id_str" : "670554122660282368",
  "in_reply_to_user_id" : 403672027,
  "text" : "@clcr_cardiffu wndr if possible to incorp in analysis that @guardian suppressed discussion about causes in 1st days after attack? #cls10",
  "id" : 670554122660282368,
  "in_reply_to_status_id" : 670547832089280512,
  "created_at" : "2015-11-28 10:45:35 +0000",
  "in_reply_to_screen_name" : "clcr_cardiffu",
  "in_reply_to_user_id_str" : "403672027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 3, 13 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/RBCJr9Pm75",
      "expanded_url" : "https:\/\/mic.adobeconnect.com\/maalissuesinlinguistics\/",
      "display_url" : "mic.adobeconnect.com\/maalissuesinli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670292697727528961",
  "text" : "RT @TEFLclass: Live now with Randi Reppen on using corpora to inform teaching and materials development. https:\/\/t.co\/RBCJr9Pm75 #corpus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/RBCJr9Pm75",
        "expanded_url" : "https:\/\/mic.adobeconnect.com\/maalissuesinlinguistics\/",
        "display_url" : "mic.adobeconnect.com\/maalissuesinli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670289843113586688",
    "text" : "Live now with Randi Reppen on using corpora to inform teaching and materials development. https:\/\/t.co\/RBCJr9Pm75 #corpus",
    "id" : 670289843113586688,
    "created_at" : "2015-11-27 17:15:26 +0000",
    "user" : {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "protected" : false,
      "id_str" : "469244585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000353527279\/c15d358a877f62d20d0e180a1da73b4c_normal.jpeg",
      "id" : 469244585,
      "verified" : false
    }
  },
  "id" : 670292697727528961,
  "created_at" : "2015-11-27 17:26:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/9H8B8dRQMX",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=65908",
      "display_url" : "tm.durusau.net\/?p=65908"
    } ]
  },
  "geo" : { },
  "id_str" : "670102462645313536",
  "text" : "RT @patrickDurusau: What Should the Media Do When Donald Trump Blatantly Lies? [Try Not Reporting Lies] https:\/\/t.co\/9H8B8dRQMX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/9H8B8dRQMX",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=65908",
        "display_url" : "tm.durusau.net\/?p=65908"
      } ]
    },
    "geo" : { },
    "id_str" : "670046370460471297",
    "text" : "What Should the Media Do When Donald Trump Blatantly Lies? [Try Not Reporting Lies] https:\/\/t.co\/9H8B8dRQMX",
    "id" : 670046370460471297,
    "created_at" : "2015-11-27 01:07:58 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 670102462645313536,
  "created_at" : "2015-11-27 04:50:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/GvArxjEFAb",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2015\/11\/cameron-overreaches-with-70000-claim-nobody-believes\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669982079824887808",
  "text" : "chifekh dalen\nmune mrr\nsocnetlh\nsteh-leh leh-teh\nlla dhei\n70000 in some made up languages for a made up number\nhttps:\/\/t.co\/GvArxjEFAb",
  "id" : 669982079824887808,
  "created_at" : "2015-11-26 20:52:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/669221610830757888\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/wm4actJoKO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmNgkHVEAAF1q9.jpg",
      "id_str" : "669221610230976512",
      "id" : 669221610230976512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmNgkHVEAAF1q9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 641
      } ],
      "display_url" : "pic.twitter.com\/wm4actJoKO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/NUdtttUm69",
      "expanded_url" : "http:\/\/worrydream.com\/ClimateChange\/",
      "display_url" : "worrydream.com\/ClimateChange\/"
    } ]
  },
  "geo" : { },
  "id_str" : "669911603081551872",
  "text" : "RT @worrydream: \u2605 What Can A Technologist Do About Climate Change? (A Personal View)  https:\/\/t.co\/NUdtttUm69 https:\/\/t.co\/wm4actJoKO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/669221610830757888\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/wm4actJoKO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmNgkHVEAAF1q9.jpg",
        "id_str" : "669221610230976512",
        "id" : 669221610230976512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmNgkHVEAAF1q9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 641
        } ],
        "display_url" : "pic.twitter.com\/wm4actJoKO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/NUdtttUm69",
        "expanded_url" : "http:\/\/worrydream.com\/ClimateChange\/",
        "display_url" : "worrydream.com\/ClimateChange\/"
      } ]
    },
    "geo" : { },
    "id_str" : "669221610830757888",
    "text" : "\u2605 What Can A Technologist Do About Climate Change? (A Personal View)  https:\/\/t.co\/NUdtttUm69 https:\/\/t.co\/wm4actJoKO",
    "id" : 669221610830757888,
    "created_at" : "2015-11-24 18:30:40 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 669911603081551872,
  "created_at" : "2015-11-26 16:12:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 66, 74 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/669819849560977408\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/eiwP4xokTB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUutmoRWwAAe9og.jpg",
      "id_str" : "669819848751497216",
      "id" : 669819848751497216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUutmoRWwAAe9og.jpg",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eiwP4xokTB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669832463137533952",
  "text" : "RT @medialens: Cameron makes case for killing more Syrians, while @BBCNews lends a helping hand with picture of scary jihadists. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 51, 59 ],
        "id_str" : "612473",
        "id" : 612473
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/669819849560977408\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/eiwP4xokTB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUutmoRWwAAe9og.jpg",
        "id_str" : "669819848751497216",
        "id" : 669819848751497216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUutmoRWwAAe9og.jpg",
        "sizes" : [ {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/eiwP4xokTB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669819849560977408",
    "text" : "Cameron makes case for killing more Syrians, while @BBCNews lends a helping hand with picture of scary jihadists. https:\/\/t.co\/eiwP4xokTB",
    "id" : 669819849560977408,
    "created_at" : "2015-11-26 10:07:51 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 669832463137533952,
  "created_at" : "2015-11-26 10:57:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 3, 13 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "populism",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ByCyZt5QU0",
      "expanded_url" : "https:\/\/theconversation.com\/right-wing-populism-is-surging-on-both-sides-of-the-atlantic-heres-why-47876",
      "display_url" : "theconversation.com\/right-wing-pop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669826687660654592",
  "text" : "RT @_ctaylor_: On rising right-wing #populism\nhttps:\/\/t.co\/ByCyZt5QU0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "populism",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/ByCyZt5QU0",
        "expanded_url" : "https:\/\/theconversation.com\/right-wing-populism-is-surging-on-both-sides-of-the-atlantic-heres-why-47876",
        "display_url" : "theconversation.com\/right-wing-pop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669823215389319168",
    "text" : "On rising right-wing #populism\nhttps:\/\/t.co\/ByCyZt5QU0",
    "id" : 669823215389319168,
    "created_at" : "2015-11-26 10:21:13 +0000",
    "user" : {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "protected" : false,
      "id_str" : "1428024560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747118162383085568\/dvYEKKWl_normal.jpg",
      "id" : 1428024560,
      "verified" : false
    }
  },
  "id" : 669826687660654592,
  "created_at" : "2015-11-26 10:35:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark McGlashan",
      "screen_name" : "Mark_McGlashan",
      "indices" : [ 3, 18 ],
      "id_str" : "286869902",
      "id" : 286869902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Mark_McGlashan\/status\/669560524544307200\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/2SrqsEIqhO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUrBv5hWwAADcm1.png",
      "id_str" : "669560523256676352",
      "id" : 669560523256676352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUrBv5hWwAADcm1.png",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 528
      } ],
      "display_url" : "pic.twitter.com\/2SrqsEIqhO"
    } ],
    "hashtags" : [ {
      "text" : "spendingreview",
      "indices" : [ 48, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669826243097976832",
  "text" : "RT @Mark_McGlashan: 30 most frequent n-grams in #spendingreview tweets. Tax credits u-turn appears newsworthy. Talk about cuts also freq ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Mark_McGlashan\/status\/669560524544307200\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/2SrqsEIqhO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUrBv5hWwAADcm1.png",
        "id_str" : "669560523256676352",
        "id" : 669560523256676352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUrBv5hWwAADcm1.png",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 528
        } ],
        "display_url" : "pic.twitter.com\/2SrqsEIqhO"
      } ],
      "hashtags" : [ {
        "text" : "spendingreview",
        "indices" : [ 28, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669560524544307200",
    "text" : "30 most frequent n-grams in #spendingreview tweets. Tax credits u-turn appears newsworthy. Talk about cuts also freq https:\/\/t.co\/2SrqsEIqhO",
    "id" : 669560524544307200,
    "created_at" : "2015-11-25 16:57:23 +0000",
    "user" : {
      "name" : "Mark McGlashan",
      "screen_name" : "Mark_McGlashan",
      "protected" : false,
      "id_str" : "286869902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412267890012741632\/_VMPIntl_normal.jpeg",
      "id" : 286869902,
      "verified" : false
    }
  },
  "id" : 669826243097976832,
  "created_at" : "2015-11-26 10:33:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669591784075493376",
  "geo" : { },
  "id_str" : "669817306369912832",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin ah okay for future ref the byu interface has a drop down box for part of speech",
  "id" : 669817306369912832,
  "in_reply_to_status_id" : 669591784075493376,
  "created_at" : "2015-11-26 09:57:45 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 3, 14 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "imageconference",
      "screen_name" : "imageconference",
      "indices" : [ 81, 97 ],
      "id_str" : "1285804915",
      "id" : 1285804915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Technical",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "Image",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "elt",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "tefl",
      "indices" : [ 127, 132 ]
    }, {
      "text" : "tesol",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/e6VuZvGBD8",
      "expanded_url" : "https:\/\/youtu.be\/uQDKaJzYnBE",
      "display_url" : "youtu.be\/uQDKaJzYnBE"
    } ]
  },
  "geo" : { },
  "id_str" : "669814394025586688",
  "text" : "RT @evanfrendo: Exploiting #Technical Drawings at #Image Conference Munich 5 Dec @imageconference https:\/\/t.co\/e6VuZvGBD8 #elt #tefl #tesol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "imageconference",
        "screen_name" : "imageconference",
        "indices" : [ 65, 81 ],
        "id_str" : "1285804915",
        "id" : 1285804915
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Technical",
        "indices" : [ 11, 21 ]
      }, {
        "text" : "Image",
        "indices" : [ 34, 40 ]
      }, {
        "text" : "elt",
        "indices" : [ 106, 110 ]
      }, {
        "text" : "tefl",
        "indices" : [ 111, 116 ]
      }, {
        "text" : "tesol",
        "indices" : [ 117, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/e6VuZvGBD8",
        "expanded_url" : "https:\/\/youtu.be\/uQDKaJzYnBE",
        "display_url" : "youtu.be\/uQDKaJzYnBE"
      } ]
    },
    "geo" : { },
    "id_str" : "669812327714279424",
    "text" : "Exploiting #Technical Drawings at #Image Conference Munich 5 Dec @imageconference https:\/\/t.co\/e6VuZvGBD8 #elt #tefl #tesol",
    "id" : 669812327714279424,
    "created_at" : "2015-11-26 09:37:58 +0000",
    "user" : {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "protected" : false,
      "id_str" : "17589664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267172323\/Evan_Frendo_normal.jpg",
      "id" : 17589664,
      "verified" : false
    }
  },
  "id" : 669814394025586688,
  "created_at" : "2015-11-26 09:46:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/3dVHGuVK0l",
      "expanded_url" : "http:\/\/bbc.in\/1Hd1IqQ",
      "display_url" : "bbc.in\/1Hd1IqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "669808804553428993",
  "text" : "Live from the BBC Radio New Comedy Award 2015 Final, Yuriko Kotani wins the 2015 BBC Radio New Comedy Award https:\/\/t.co\/3dVHGuVK0l",
  "id" : 669808804553428993,
  "created_at" : "2015-11-26 09:23:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 3, 18 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Nj1q5PuH7u",
      "expanded_url" : "http:\/\/goo.gl\/65pJ47",
      "display_url" : "goo.gl\/65pJ47"
    } ]
  },
  "geo" : { },
  "id_str" : "669577523420921857",
  "text" : "RT @JoschiFun2Code: #android app: WSMirror - Web Screen Mirror https:\/\/t.co\/Nj1q5PuH7u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "android",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/Nj1q5PuH7u",
        "expanded_url" : "http:\/\/goo.gl\/65pJ47",
        "display_url" : "goo.gl\/65pJ47"
      } ]
    },
    "geo" : { },
    "id_str" : "669549155514228736",
    "text" : "#android app: WSMirror - Web Screen Mirror https:\/\/t.co\/Nj1q5PuH7u",
    "id" : 669549155514228736,
    "created_at" : "2015-11-25 16:12:12 +0000",
    "user" : {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "protected" : false,
      "id_str" : "2428512869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447798987320356864\/_FsQL523_normal.jpeg",
      "id" : 2428512869,
      "verified" : false
    }
  },
  "id" : 669577523420921857,
  "created_at" : "2015-11-25 18:04:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669572894498926592",
  "geo" : { },
  "id_str" : "669577426113032192",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code thx for a great app :)",
  "id" : 669577426113032192,
  "in_reply_to_status_id" : 669572894498926592,
  "created_at" : "2015-11-25 18:04:33 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669567429132034048",
  "geo" : { },
  "id_str" : "669570810294738945",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code it is working in windows 8 system bloody osx!",
  "id" : 669570810294738945,
  "in_reply_to_status_id" : 669567429132034048,
  "created_at" : "2015-11-25 17:38:15 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669567429132034048",
  "geo" : { },
  "id_str" : "669567976157392896",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code osx 10.11.1, gonna try it on a pc",
  "id" : 669567976157392896,
  "in_reply_to_status_id" : 669567429132034048,
  "created_at" : "2015-11-25 17:27:00 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669565274878799873",
  "geo" : { },
  "id_str" : "669565519067029504",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code it works fine over wifi",
  "id" : 669565519067029504,
  "in_reply_to_status_id" : 669565274878799873,
  "created_at" : "2015-11-25 17:17:14 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669563851386576896",
  "geo" : { },
  "id_str" : "669564465579499520",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code i get that as well with the 1024 port",
  "id" : 669564465579499520,
  "in_reply_to_status_id" : 669563851386576896,
  "created_at" : "2015-11-25 17:13:03 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669562530805739521",
  "geo" : { },
  "id_str" : "669563343565414404",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code it gives me a LAN address but when i try to connect from desktop no luck",
  "id" : 669563343565414404,
  "in_reply_to_status_id" : 669562530805739521,
  "created_at" : "2015-11-25 17:08:35 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669559556771549184",
  "geo" : { },
  "id_str" : "669562074591272960",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code hmm no luck so far with usb tether",
  "id" : 669562074591272960,
  "in_reply_to_status_id" : 669559556771549184,
  "created_at" : "2015-11-25 17:03:33 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669558581918900225",
  "geo" : { },
  "id_str" : "669559087781322752",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code can your app work with usb tethering?",
  "id" : 669559087781322752,
  "in_reply_to_status_id" : 669558581918900225,
  "created_at" : "2015-11-25 16:51:40 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669553214673547265",
  "geo" : { },
  "id_str" : "669555429203156992",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code usually don't have admin rights on computer i want to use :(",
  "id" : 669555429203156992,
  "in_reply_to_status_id" : 669553214673547265,
  "created_at" : "2015-11-25 16:37:08 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Lebedev",
      "screen_name" : "JLebedev_ESL",
      "indices" : [ 61, 74 ],
      "id_str" : "3033094945",
      "id" : 3033094945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/FVyQC4Fdji",
      "expanded_url" : "http:\/\/wp.me\/pjaNC-1hM",
      "display_url" : "wp.me\/pjaNC-1hM"
    } ]
  },
  "geo" : { },
  "id_str" : "669552292534681600",
  "text" : "Beyond Prepositions of Place 101 https:\/\/t.co\/FVyQC4Fdji via @JLebedev_ESL",
  "id" : 669552292534681600,
  "created_at" : "2015-11-25 16:24:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669549155514228736",
  "geo" : { },
  "id_str" : "669550282943160320",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code nice, wld it be possible to add usb network function for when wifi is no good?",
  "id" : 669550282943160320,
  "in_reply_to_status_id" : 669549155514228736,
  "created_at" : "2015-11-25 16:16:41 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Haspelmath",
      "screen_name" : "haspelmath",
      "indices" : [ 3, 14 ],
      "id_str" : "153079285",
      "id" : 153079285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/nMwCWLKcHS",
      "expanded_url" : "http:\/\/babadada.com\/",
      "display_url" : "babadada.com"
    } ]
  },
  "geo" : { },
  "id_str" : "669538016654921728",
  "text" : "RT @haspelmath: Babadada (comparative visual dictionaries) now has over 100 languages: https:\/\/t.co\/nMwCWLKcHS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/nMwCWLKcHS",
        "expanded_url" : "http:\/\/babadada.com\/",
        "display_url" : "babadada.com"
      } ]
    },
    "geo" : { },
    "id_str" : "669534842443419649",
    "text" : "Babadada (comparative visual dictionaries) now has over 100 languages: https:\/\/t.co\/nMwCWLKcHS",
    "id" : 669534842443419649,
    "created_at" : "2015-11-25 15:15:20 +0000",
    "user" : {
      "name" : "Martin Haspelmath",
      "screen_name" : "haspelmath",
      "protected" : false,
      "id_str" : "153079285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619510792\/3inkuzywwtjefhbibuos_normal.jpeg",
      "id" : 153079285,
      "verified" : false
    }
  },
  "id" : 669538016654921728,
  "created_at" : "2015-11-25 15:27:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/dlZRPCRcQm",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/scribbles-elsewhere\/",
      "display_url" : "eflnotes.wordpress.com\/scribbles-else\u2026"
    }, {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Rdi3WWq4fV",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/the-shed\/",
      "display_url" : "eflnotes.wordpress.com\/the-shed\/"
    } ]
  },
  "geo" : { },
  "id_str" : "669534911657824257",
  "text" : "added a couple of new pages to me blog - Scribbles elsewhere https:\/\/t.co\/dlZRPCRcQm \u2026 &amp; The Shed https:\/\/t.co\/Rdi3WWq4fV",
  "id" : 669534911657824257,
  "created_at" : "2015-11-25 15:15:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/fzoklAj4wJ",
      "expanded_url" : "http:\/\/www.carbonbrief.org\/interactive-the-paris-climate-deal",
      "display_url" : "carbonbrief.org\/interactive-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669534299180408833",
  "text" : "Interactive: the Paris climate deal https:\/\/t.co\/fzoklAj4wJ",
  "id" : 669534299180408833,
  "created_at" : "2015-11-25 15:13:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "indices" : [ 0, 10 ],
      "id_str" : "20900313",
      "id" : 20900313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669531658278805504",
  "geo" : { },
  "id_str" : "669532949667307520",
  "in_reply_to_user_id" : 20900313,
  "text" : "@speak2all nice to see this back on :)",
  "id" : 669532949667307520,
  "in_reply_to_status_id" : 669531658278805504,
  "created_at" : "2015-11-25 15:07:49 +0000",
  "in_reply_to_screen_name" : "speak2all",
  "in_reply_to_user_id_str" : "20900313",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669524539395698690",
  "geo" : { },
  "id_str" : "669532584305680384",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt yr welcome, looks like G+ is truely dead to u ; )",
  "id" : 669532584305680384,
  "in_reply_to_status_id" : 669524539395698690,
  "created_at" : "2015-11-25 15:06:22 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/cf1aFFfbAZ",
      "expanded_url" : "http:\/\/shr.gs\/WBLFimB",
      "display_url" : "shr.gs\/WBLFimB"
    } ]
  },
  "geo" : { },
  "id_str" : "669491788458147840",
  "text" : "Andy Murray's nationality reporting 'not linked to success' https:\/\/t.co\/cf1aFFfbAZ #corpuslinguistics",
  "id" : 669491788458147840,
  "created_at" : "2015-11-25 12:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "indices" : [ 3, 16 ],
      "id_str" : "17336372",
      "id" : 17336372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/gIQKxj1Z9k",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2015\/nov\/23\/frankie-boyle-fallout-paris-psychopathic-autopilot",
      "display_url" : "theguardian.com\/world\/2015\/nov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669253046652813313",
  "text" : "RT @frankieboyle: My article from yesterday's Guardian about Paris aftermath \nhttps:\/\/t.co\/gIQKxj1Z9k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/gIQKxj1Z9k",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2015\/nov\/23\/frankie-boyle-fallout-paris-psychopathic-autopilot",
        "display_url" : "theguardian.com\/world\/2015\/nov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669103659310063616",
    "text" : "My article from yesterday's Guardian about Paris aftermath \nhttps:\/\/t.co\/gIQKxj1Z9k",
    "id" : 669103659310063616,
    "created_at" : "2015-11-24 10:41:58 +0000",
    "user" : {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "protected" : false,
      "id_str" : "17336372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743772932892131328\/ZcekAc_1_normal.jpg",
      "id" : 17336372,
      "verified" : true
    }
  },
  "id" : 669253046652813313,
  "created_at" : "2015-11-24 20:35:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669213101347180545",
  "geo" : { },
  "id_str" : "669249482958217217",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin do u you mean you using google searching?",
  "id" : 669249482958217217,
  "in_reply_to_status_id" : 669213101347180545,
  "created_at" : "2015-11-24 20:21:25 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janine Schwab",
      "screen_name" : "janinemschwab",
      "indices" : [ 0, 14 ],
      "id_str" : "3767950337",
      "id" : 3767950337
    }, {
      "name" : "corpusmoocRT",
      "screen_name" : "corpusmoocFav",
      "indices" : [ 15, 29 ],
      "id_str" : "3404478725",
      "id" : 3404478725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669238944362557441",
  "geo" : { },
  "id_str" : "669249269866565632",
  "in_reply_to_user_id" : 3767950337,
  "text" : "@janinemschwab @corpusmoocFav do u have ex of text you want to make readable? u cld post over at G+ CL community? https:\/\/t.co\/gnEFqIeLpA",
  "id" : 669249269866565632,
  "in_reply_to_status_id" : 669238944362557441,
  "created_at" : "2015-11-24 20:20:34 +0000",
  "in_reply_to_screen_name" : "janinemschwab",
  "in_reply_to_user_id_str" : "3767950337",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/WvvDtLqU3l",
      "expanded_url" : "http:\/\/googlesystem.blogspot.com\/2015\/11\/google-star-wars-experience.html?spref=tw",
      "display_url" : "googlesystem.blogspot.com\/2015\/11\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669124025856167936",
  "text" : "Google Operating System: Google Star Wars Experience https:\/\/t.co\/WvvDtLqU3l",
  "id" : 669124025856167936,
  "created_at" : "2015-11-24 12:02:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 77, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/Vqi0uDrMZ5",
      "expanded_url" : "http:\/\/goo.gl\/8SyT85",
      "display_url" : "goo.gl\/8SyT85"
    } ]
  },
  "geo" : { },
  "id_str" : "669108712372613120",
  "text" : "RT @josipa74: The Music Makers and the Money Makers. https:\/\/t.co\/Vqi0uDrMZ5 #efl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 63, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/Vqi0uDrMZ5",
        "expanded_url" : "http:\/\/goo.gl\/8SyT85",
        "display_url" : "goo.gl\/8SyT85"
      } ]
    },
    "geo" : { },
    "id_str" : "669102967287623680",
    "text" : "The Music Makers and the Money Makers. https:\/\/t.co\/Vqi0uDrMZ5 #efl",
    "id" : 669102967287623680,
    "created_at" : "2015-11-24 10:39:13 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 669108712372613120,
  "created_at" : "2015-11-24 11:02:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/wxfRFmVxFG",
      "expanded_url" : "https:\/\/twitter.com\/zaidbenjamin\/status\/669076311739076608",
      "display_url" : "twitter.com\/zaidbenjamin\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669084606520549376",
  "text" : "RT @medialens: 'Our' leaders are now so deranged and out of control, they may even beat climate change to the punch https:\/\/t.co\/wxfRFmVxFG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/wxfRFmVxFG",
        "expanded_url" : "https:\/\/twitter.com\/zaidbenjamin\/status\/669076311739076608",
        "display_url" : "twitter.com\/zaidbenjamin\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669080962802696192",
    "text" : "'Our' leaders are now so deranged and out of control, they may even beat climate change to the punch https:\/\/t.co\/wxfRFmVxFG",
    "id" : 669080962802696192,
    "created_at" : "2015-11-24 09:11:47 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 669084606520549376,
  "created_at" : "2015-11-24 09:26:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669060874003419137",
  "geo" : { },
  "id_str" : "669070667866898432",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet thx for sharing :)",
  "id" : 669070667866898432,
  "in_reply_to_status_id" : 669060874003419137,
  "created_at" : "2015-11-24 08:30:52 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/OHdvA33IbO",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1448328644.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669070456583008256",
  "text" : "&lt;&lt;if u believe in international law shld we not believe it offers protection to regimes we despise?&gt;&gt; https:\/\/t.co\/OHdvA33IbO",
  "id" : 669070456583008256,
  "created_at" : "2015-11-24 08:30:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "esl",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "tefl",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/sCDuKBVjSl",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/11\/24\/learning-vocabulary-through-subs2srs-and-anki",
      "display_url" : "eflnotes.wordpress.com\/2015\/11\/24\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669059035430125568",
  "text" : "Learning vocabulary through subs2srs and Anki #eltchat #esl #tefl https:\/\/t.co\/sCDuKBVjSl",
  "id" : 669059035430125568,
  "created_at" : "2015-11-24 07:44:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "indices" : [ 3, 17 ],
      "id_str" : "43068002",
      "id" : 43068002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfrance",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/Ubbf8dLAQf",
      "expanded_url" : "http:\/\/inyourhands.edublogs.org\/2015\/11\/23\/tesol-france-2015-paris-and-the-english-teachers\/",
      "display_url" : "inyourhands.edublogs.org\/2015\/11\/23\/tes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668924390306877441",
  "text" : "RT @annabooklover: This is my take on the #tesolfrance conference which took place last weekend. Lots of energy and meetings: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesolfrance",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Ubbf8dLAQf",
        "expanded_url" : "http:\/\/inyourhands.edublogs.org\/2015\/11\/23\/tesol-france-2015-paris-and-the-english-teachers\/",
        "display_url" : "inyourhands.edublogs.org\/2015\/11\/23\/tes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668898264096366592",
    "text" : "This is my take on the #tesolfrance conference which took place last weekend. Lots of energy and meetings: https:\/\/t.co\/Ubbf8dLAQf",
    "id" : 668898264096366592,
    "created_at" : "2015-11-23 21:05:48 +0000",
    "user" : {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "protected" : false,
      "id_str" : "43068002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596997287471120384\/OXz9fjzX_normal.jpg",
      "id" : 43068002,
      "verified" : false
    }
  },
  "id" : 668924390306877441,
  "created_at" : "2015-11-23 22:49:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AlannahFitz\/status\/668878509754834945\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/BCfFt96SRx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUhVdb4VAAE-70i.jpg",
      "id_str" : "668878508853100545",
      "id" : 668878508853100545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUhVdb4VAAE-70i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/BCfFt96SRx"
    } ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 83, 87 ]
    }, {
      "text" : "openaccess",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "esl",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Yr7NuUmVtS",
      "expanded_url" : "https:\/\/plus.google.com\/+alannahfitzgerald\/posts\/JSwUT7rUsV9",
      "display_url" : "plus.google.com\/+alannahfitzge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668883217622171649",
  "text" : "RT @AlannahFitz: Bridging Formal and Informal Learning for Second Language Writing #oer #openaccess #esl\u2026 https:\/\/t.co\/Yr7NuUmVtS https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AlannahFitz\/status\/668878509754834945\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/BCfFt96SRx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUhVdb4VAAE-70i.jpg",
        "id_str" : "668878508853100545",
        "id" : 668878508853100545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUhVdb4VAAE-70i.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/BCfFt96SRx"
      } ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 66, 70 ]
      }, {
        "text" : "openaccess",
        "indices" : [ 71, 82 ]
      }, {
        "text" : "esl",
        "indices" : [ 83, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/Yr7NuUmVtS",
        "expanded_url" : "https:\/\/plus.google.com\/+alannahfitzgerald\/posts\/JSwUT7rUsV9",
        "display_url" : "plus.google.com\/+alannahfitzge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668878509754834945",
    "text" : "Bridging Formal and Informal Learning for Second Language Writing #oer #openaccess #esl\u2026 https:\/\/t.co\/Yr7NuUmVtS https:\/\/t.co\/BCfFt96SRx",
    "id" : 668878509754834945,
    "created_at" : "2015-11-23 19:47:18 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 668883217622171649,
  "created_at" : "2015-11-23 20:06:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668874950095331329",
  "geo" : { },
  "id_str" : "668878954812588033",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin what corpus interface are u using?",
  "id" : 668878954812588033,
  "in_reply_to_status_id" : 668874950095331329,
  "created_at" : "2015-11-23 19:49:04 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/3WQh8PAJlk",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=43223399",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "668874852766478337",
  "geo" : { },
  "id_str" : "668877607551803392",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin hi this any good? https:\/\/t.co\/3WQh8PAJlk",
  "id" : 668877607551803392,
  "in_reply_to_status_id" : 668874852766478337,
  "created_at" : "2015-11-23 19:43:43 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Jordan",
      "screen_name" : "GeoffJordan",
      "indices" : [ 59, 71 ],
      "id_str" : "29510765",
      "id" : 29510765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/O6hgjVY0aT",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1pf",
      "display_url" : "wp.me\/p3qkCB-1pf"
    } ]
  },
  "geo" : { },
  "id_str" : "668849248549646336",
  "text" : "The Lexical Approach , Part 13 https:\/\/t.co\/O6hgjVY0aT via @GeoffJordan",
  "id" : 668849248549646336,
  "created_at" : "2015-11-23 17:51:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAttacks",
      "indices" : [ 113, 126 ]
    }, {
      "text" : "BBCbias",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/QAv0mmKjP9",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/11\/liberal-war-media-let-rip-over-paris-is.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/11\/libera\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668840949070635008",
  "text" : "RT @johnwhilley: Liberal war media let rip over Paris, IS and 'defence of civilization'  https:\/\/t.co\/QAv0mmKjP9 #ParisAttacks #BBCbias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAttacks",
        "indices" : [ 96, 109 ]
      }, {
        "text" : "BBCbias",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/QAv0mmKjP9",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/11\/liberal-war-media-let-rip-over-paris-is.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/11\/libera\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668815117933543424",
    "text" : "Liberal war media let rip over Paris, IS and 'defence of civilization'  https:\/\/t.co\/QAv0mmKjP9 #ParisAttacks #BBCbias",
    "id" : 668815117933543424,
    "created_at" : "2015-11-23 15:35:24 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 668840949070635008,
  "created_at" : "2015-11-23 17:18:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LT-Innovate",
      "screen_name" : "LTInnovate",
      "indices" : [ 0, 11 ],
      "id_str" : "414809762",
      "id" : 414809762
    }, {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 12, 19 ],
      "id_str" : "190569306",
      "id" : 190569306
    }, {
      "name" : "Deloitte",
      "screen_name" : "Deloitte",
      "indices" : [ 20, 29 ],
      "id_str" : "8457092",
      "id" : 8457092
    }, {
      "name" : "LT-Accelerate",
      "screen_name" : "LTaccelerate",
      "indices" : [ 30, 43 ],
      "id_str" : "105786101",
      "id" : 105786101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/8W4v2jEYwX",
      "expanded_url" : "http:\/\/www.explainxkcd.com\/wiki\/index.php\/File:dna.png",
      "display_url" : "explainxkcd.com\/wiki\/index.php\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "668754113358884864",
  "geo" : { },
  "id_str" : "668757952946429952",
  "in_reply_to_user_id" : 414809762,
  "text" : "@LTInnovate @WordLo @Deloitte @LTaccelerate maybe he needs to read this https:\/\/t.co\/8W4v2jEYwX ? : )",
  "id" : 668757952946429952,
  "in_reply_to_status_id" : 668754113358884864,
  "created_at" : "2015-11-23 11:48:15 +0000",
  "in_reply_to_screen_name" : "LTInnovate",
  "in_reply_to_user_id_str" : "414809762",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668577600537821184",
  "geo" : { },
  "id_str" : "668578384730025984",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr thx for the shoutout :)",
  "id" : 668578384730025984,
  "in_reply_to_status_id" : 668577600537821184,
  "created_at" : "2015-11-22 23:54:43 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 3, 15 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 17, 26 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Sri6X5zhER",
      "expanded_url" : "http:\/\/bit.ly\/1SdwNLm",
      "display_url" : "bit.ly\/1SdwNLm"
    } ]
  },
  "geo" : { },
  "id_str" : "668578327133818880",
  "text" : "RT @patriciambr: @muranava New in my blog: Create your first corpus and analyze it with AntConc (and related links to explore!) https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Sri6X5zhER",
        "expanded_url" : "http:\/\/bit.ly\/1SdwNLm",
        "display_url" : "bit.ly\/1SdwNLm"
      } ]
    },
    "geo" : { },
    "id_str" : "668577600537821184",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava New in my blog: Create your first corpus and analyze it with AntConc (and related links to explore!) https:\/\/t.co\/Sri6X5zhER",
    "id" : 668577600537821184,
    "created_at" : "2015-11-22 23:51:36 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "protected" : false,
      "id_str" : "35764443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540310171541438464\/YprBqoGt_normal.jpeg",
      "id" : 35764443,
      "verified" : false
    }
  },
  "id" : 668578327133818880,
  "created_at" : "2015-11-22 23:54:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 10, 24 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 25, 31 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/668577829588705281\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/76dxe7KnKC",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUdD_iyWwAEFMyD.png",
      "id_str" : "668577828636639233",
      "id" : 668577828636639233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUdD_iyWwAEFMyD.png",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/76dxe7KnKC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668566942031216640",
  "geo" : { },
  "id_str" : "668577829588705281",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @NicolaPrentis @ebefl https:\/\/t.co\/76dxe7KnKC",
  "id" : 668577829588705281,
  "in_reply_to_status_id" : 668566942031216640,
  "created_at" : "2015-11-22 23:52:30 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grrr",
      "screen_name" : "grrr",
      "indices" : [ 3, 8 ],
      "id_str" : "11028992",
      "id" : 11028992
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/grrr\/status\/667428804193857536\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/oEiS0uBafX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMu9grXIAEOdbp.jpg",
      "id_str" : "667428804059668481",
      "id" : 667428804059668481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMu9grXIAEOdbp.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oEiS0uBafX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668554462345195520",
  "text" : "RT @grrr: Merci Apple, c'est gentil. Apr\u00E8s, si tu pouvais payer tes imp\u00F4ts en France on pourrait payer les policiers. Bisous. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/grrr\/status\/667428804193857536\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/oEiS0uBafX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMu9grXIAEOdbp.jpg",
        "id_str" : "667428804059668481",
        "id" : 667428804059668481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMu9grXIAEOdbp.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oEiS0uBafX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667428804193857536",
    "text" : "Merci Apple, c'est gentil. Apr\u00E8s, si tu pouvais payer tes imp\u00F4ts en France on pourrait payer les policiers. Bisous. https:\/\/t.co\/oEiS0uBafX",
    "id" : 667428804193857536,
    "created_at" : "2015-11-19 19:46:41 +0000",
    "user" : {
      "name" : "grrr",
      "screen_name" : "grrr",
      "protected" : false,
      "id_str" : "11028992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662740810073440256\/4VnDxyP2_normal.jpg",
      "id" : 11028992,
      "verified" : false
    }
  },
  "id" : 668554462345195520,
  "created_at" : "2015-11-22 22:19:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Protective Fences",
      "screen_name" : "PFencesMusic",
      "indices" : [ 3, 16 ],
      "id_str" : "223482081",
      "id" : 223482081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668545951922024448",
  "text" : "RT @PFencesMusic: Cameron: We will defeat ISIS in 14 days.\nBlair: We're 45 minutes from attack.\nThe Kaiser: It will be limited war and over\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668426923102625794",
    "text" : "Cameron: We will defeat ISIS in 14 days.\nBlair: We're 45 minutes from attack.\nThe Kaiser: It will be limited war and over in a month.",
    "id" : 668426923102625794,
    "created_at" : "2015-11-22 13:52:51 +0000",
    "user" : {
      "name" : "Protective Fences",
      "screen_name" : "PFencesMusic",
      "protected" : false,
      "id_str" : "223482081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712707212687368192\/4gUt89Tv_normal.jpg",
      "id" : 223482081,
      "verified" : false
    }
  },
  "id" : 668545951922024448,
  "created_at" : "2015-11-22 21:45:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 29, 38 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/iQ42j1VnDM",
      "expanded_url" : "https:\/\/twitter.com\/aparrish\/lists\/my-bots",
      "display_url" : "twitter.com\/aparrish\/lists\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "668534926719995905",
  "geo" : { },
  "id_str" : "668537044000468992",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle check more bots by @aparrish https:\/\/t.co\/iQ42j1VnDM",
  "id" : 668537044000468992,
  "in_reply_to_status_id" : 668534926719995905,
  "created_at" : "2015-11-22 21:10:26 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deep Question Bot",
      "screen_name" : "deepquestionbot",
      "indices" : [ 50, 66 ],
      "id_str" : "3004664055",
      "id" : 3004664055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinkies",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668533646069014528",
  "text" : "#thinkies Why are fruit good and rarely evil? h\/t @deepquestionbot",
  "id" : 668533646069014528,
  "created_at" : "2015-11-22 20:56:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668525414621552640",
  "geo" : { },
  "id_str" : "668528601285963777",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague oui c'est chouette :)",
  "id" : 668528601285963777,
  "in_reply_to_status_id" : 668525414621552640,
  "created_at" : "2015-11-22 20:36:53 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 75, 91 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/03XjaXCJgv",
      "expanded_url" : "http:\/\/wp.me\/p354NQ-8b",
      "display_url" : "wp.me\/p354NQ-8b"
    } ]
  },
  "geo" : { },
  "id_str" : "668521129921880064",
  "text" : "\u201CJe ne veux pas pain\u201D: Interlanguage as Poetry https:\/\/t.co\/03XjaXCJgv via @wordpressdotcom",
  "id" : 668521129921880064,
  "created_at" : "2015-11-22 20:07:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Rebuffet",
      "screen_name" : "Chris_Rebuffet",
      "indices" : [ 3, 18 ],
      "id_str" : "2504745722",
      "id" : 2504745722
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Chris_Rebuffet\/status\/668484439723417600\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/dB1m6UX5w4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUbvC7VW4AA7rTP.jpg",
      "id_str" : "668484428277145600",
      "id" : 668484428277145600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUbvC7VW4AA7rTP.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dB1m6UX5w4"
    } ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668520373542088704",
  "text" : "RT @Chris_Rebuffet: Sketchnotes from Dan Frost's fab talk on pronunciation &amp; prosody at #Tesolfrance. Lots of inspiration for videos! https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Chris_Rebuffet\/status\/668484439723417600\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/dB1m6UX5w4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUbvC7VW4AA7rTP.jpg",
        "id_str" : "668484428277145600",
        "id" : 668484428277145600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUbvC7VW4AA7rTP.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dB1m6UX5w4"
      } ],
      "hashtags" : [ {
        "text" : "Tesolfrance",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668484439723417600",
    "text" : "Sketchnotes from Dan Frost's fab talk on pronunciation &amp; prosody at #Tesolfrance. Lots of inspiration for videos! https:\/\/t.co\/dB1m6UX5w4",
    "id" : 668484439723417600,
    "created_at" : "2015-11-22 17:41:24 +0000",
    "user" : {
      "name" : "Christina Rebuffet",
      "screen_name" : "Chris_Rebuffet",
      "protected" : false,
      "id_str" : "2504745722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494429265018904577\/6Vso_nYP_normal.jpeg",
      "id" : 2504745722,
      "verified" : false
    }
  },
  "id" : 668520373542088704,
  "created_at" : "2015-11-22 20:04:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/ivASsupKn1",
      "expanded_url" : "http:\/\/follow.education\/2015\/11\/21\/pearson-protested-at-ncte-convention\/",
      "display_url" : "follow.education\/2015\/11\/21\/pea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668439305421987840",
  "text" : "RT @dogtrax: Pearson Protested at NCTE Convention https:\/\/t.co\/ivASsupKn1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/ivASsupKn1",
        "expanded_url" : "http:\/\/follow.education\/2015\/11\/21\/pearson-protested-at-ncte-convention\/",
        "display_url" : "follow.education\/2015\/11\/21\/pea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668438801832919040",
    "text" : "Pearson Protested at NCTE Convention https:\/\/t.co\/ivASsupKn1",
    "id" : 668438801832919040,
    "created_at" : "2015-11-22 14:40:04 +0000",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 668439305421987840,
  "created_at" : "2015-11-22 14:42:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 3, 13 ],
      "id_str" : "87903271",
      "id" : 87903271
    }, {
      "name" : "Tom Bennett",
      "screen_name" : "tombennett71",
      "indices" : [ 52, 65 ],
      "id_str" : "208996041",
      "id" : 208996041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/zH3HZ5F99W",
      "expanded_url" : "http:\/\/www.tes.com.c.tes.ent.platform.sh\/news\/blog\/sole-snake-oil-learning-experience",
      "display_url" : "tes.com.c.tes.ent.platform.sh\/news\/blog\/sole\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668438548756963328",
  "text" : "RT @JamesTheo: SOLE: Snake Oil Learning Experience? @tombennett71 on Sugata Mitra https:\/\/t.co\/zH3HZ5F99W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Bennett",
        "screen_name" : "tombennett71",
        "indices" : [ 37, 50 ],
        "id_str" : "208996041",
        "id" : 208996041
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/zH3HZ5F99W",
        "expanded_url" : "http:\/\/www.tes.com.c.tes.ent.platform.sh\/news\/blog\/sole-snake-oil-learning-experience",
        "display_url" : "tes.com.c.tes.ent.platform.sh\/news\/blog\/sole\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668430413438828544",
    "text" : "SOLE: Snake Oil Learning Experience? @tombennett71 on Sugata Mitra https:\/\/t.co\/zH3HZ5F99W",
    "id" : 668430413438828544,
    "created_at" : "2015-11-22 14:06:44 +0000",
    "user" : {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "protected" : false,
      "id_str" : "87903271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724679297391276033\/Fy8vphs6_normal.jpg",
      "id" : 87903271,
      "verified" : false
    }
  },
  "id" : 668438548756963328,
  "created_at" : "2015-11-22 14:39:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 32, 40 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667981998720483329",
  "geo" : { },
  "id_str" : "668425435085152256",
  "in_reply_to_user_id" : 18602422,
  "text" : "oops that should have been join @taw_sig",
  "id" : 668425435085152256,
  "in_reply_to_status_id" : 667981998720483329,
  "created_at" : "2015-11-22 13:46:57 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Rebuffet",
      "screen_name" : "Chris_Rebuffet",
      "indices" : [ 3, 18 ],
      "id_str" : "2504745722",
      "id" : 2504745722
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Chris_Rebuffet\/status\/668207000610856960\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/lTbQkKQ7WU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUXyudXWoAAusk7.jpg",
      "id_str" : "668206999704870912",
      "id" : 668206999704870912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUXyudXWoAAusk7.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lTbQkKQ7WU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668425181313048576",
  "text" : "RT @Chris_Rebuffet: Just before our talk at the TESOL France conference in Paris, with a colleague I highly respect, Ros Wright! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Chris_Rebuffet\/status\/668207000610856960\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/lTbQkKQ7WU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUXyudXWoAAusk7.jpg",
        "id_str" : "668206999704870912",
        "id" : 668206999704870912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUXyudXWoAAusk7.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lTbQkKQ7WU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668207000610856960",
    "text" : "Just before our talk at the TESOL France conference in Paris, with a colleague I highly respect, Ros Wright! https:\/\/t.co\/lTbQkKQ7WU",
    "id" : 668207000610856960,
    "created_at" : "2015-11-21 23:18:58 +0000",
    "user" : {
      "name" : "Christina Rebuffet",
      "screen_name" : "Chris_Rebuffet",
      "protected" : false,
      "id_str" : "2504745722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494429265018904577\/6Vso_nYP_normal.jpeg",
      "id" : 2504745722,
      "verified" : false
    }
  },
  "id" : 668425181313048576,
  "created_at" : "2015-11-22 13:45:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nddl",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "QuelleHonte",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/M78B2SzZHw",
      "expanded_url" : "http:\/\/www.liberation.fr\/france\/2015\/11\/22\/le-convoi-parti-de-notre-dame-des-landes-pour-la-cop21-bloque-par-la-police_1415277",
      "display_url" : "liberation.fr\/france\/2015\/11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668422782800277505",
  "text" : "RT @JuliuzBeezer: Et voil\u00E0 la r\u00E9pression politique commence : https:\/\/t.co\/M78B2SzZHw  Contre #nddl donc terroriste? #QuelleHonte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nddl",
        "indices" : [ 76, 81 ]
      }, {
        "text" : "QuelleHonte",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/M78B2SzZHw",
        "expanded_url" : "http:\/\/www.liberation.fr\/france\/2015\/11\/22\/le-convoi-parti-de-notre-dame-des-landes-pour-la-cop21-bloque-par-la-police_1415277",
        "display_url" : "liberation.fr\/france\/2015\/11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668421869041803265",
    "text" : "Et voil\u00E0 la r\u00E9pression politique commence : https:\/\/t.co\/M78B2SzZHw  Contre #nddl donc terroriste? #QuelleHonte",
    "id" : 668421869041803265,
    "created_at" : "2015-11-22 13:32:46 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 668422782800277505,
  "created_at" : "2015-11-22 13:36:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fab Englishteacher",
      "screen_name" : "fabenglishteach",
      "indices" : [ 3, 19 ],
      "id_str" : "439299435",
      "id" : 439299435
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668379061945790465",
  "text" : "RT @fabenglishteach: Very happy to be at #Tesolfrance first plenary about to start, I'm on at 18:30!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tesolfrance",
        "indices" : [ 20, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667733526280847360",
    "text" : "Very happy to be at #Tesolfrance first plenary about to start, I'm on at 18:30!",
    "id" : 667733526280847360,
    "created_at" : "2015-11-20 15:57:33 +0000",
    "user" : {
      "name" : "Fab Englishteacher",
      "screen_name" : "fabenglishteach",
      "protected" : false,
      "id_str" : "439299435",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691540822597046272\/pxcaIY-U_normal.jpg",
      "id" : 439299435,
      "verified" : false
    }
  },
  "id" : 668379061945790465,
  "created_at" : "2015-11-22 10:42:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 3, 11 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 90, 105 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668379016878039040",
  "text" : "RT @Ven_VVE: Enjoyed K.Moran's talk @ #Tesolfrance in which she said it was a workshop by @_divyamadhavan that inspired her 2 start doing a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Divya Madhavan",
        "screen_name" : "_divyamadhavan",
        "indices" : [ 77, 92 ],
        "id_str" : "408492806",
        "id" : 408492806
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tesolfrance",
        "indices" : [ 25, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667803214704693248",
    "text" : "Enjoyed K.Moran's talk @ #Tesolfrance in which she said it was a workshop by @_divyamadhavan that inspired her 2 start doing action rsrch.",
    "id" : 667803214704693248,
    "created_at" : "2015-11-20 20:34:28 +0000",
    "user" : {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "protected" : false,
      "id_str" : "270839603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551061595602681856\/KylACR1R_normal.jpeg",
      "id" : 270839603,
      "verified" : false
    }
  },
  "id" : 668379016878039040,
  "created_at" : "2015-11-22 10:42:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 3, 11 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 14, 27 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "indices" : [ 93, 107 ],
      "id_str" : "43068002",
      "id" : 43068002
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Ven_VVE\/status\/668374295542956032\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/HvbsdvDt7w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUaK3IEW4AANLMc.jpg",
      "id_str" : "668374274374295552",
      "id" : 668374274374295552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUaK3IEW4AANLMc.jpg",
      "sizes" : [ {
        "h" : 1461,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HvbsdvDt7w"
    } ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668378959898411008",
  "text" : "RT @Ven_VVE: .@BELTABelgium speakers at #Tesolfrance - thank you for a great conference! \ncc @annabooklover https:\/\/t.co\/HvbsdvDt7w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 1, 14 ],
        "id_str" : "884934438",
        "id" : 884934438
      }, {
        "name" : "Anna Varna",
        "screen_name" : "annabooklover",
        "indices" : [ 80, 94 ],
        "id_str" : "43068002",
        "id" : 43068002
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Ven_VVE\/status\/668374295542956032\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/HvbsdvDt7w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUaK3IEW4AANLMc.jpg",
        "id_str" : "668374274374295552",
        "id" : 668374274374295552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUaK3IEW4AANLMc.jpg",
        "sizes" : [ {
          "h" : 1461,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HvbsdvDt7w"
      } ],
      "hashtags" : [ {
        "text" : "Tesolfrance",
        "indices" : [ 27, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668374295542956032",
    "text" : ".@BELTABelgium speakers at #Tesolfrance - thank you for a great conference! \ncc @annabooklover https:\/\/t.co\/HvbsdvDt7w",
    "id" : 668374295542956032,
    "created_at" : "2015-11-22 10:23:44 +0000",
    "user" : {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "protected" : false,
      "id_str" : "270839603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551061595602681856\/KylACR1R_normal.jpeg",
      "id" : 270839603,
      "verified" : false
    }
  },
  "id" : 668378959898411008,
  "created_at" : "2015-11-22 10:42:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 120, 132 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paris",
      "indices" : [ 17, 23 ]
    }, {
      "text" : "ISIS",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/1xms0RKwyO",
      "expanded_url" : "https:\/\/medium.com\/insurge-intelligence\/europe-is-harbouring-the-islamic-state-s-backers-d24db3a24a40#.6cfnn54nt",
      "display_url" : "medium.com\/insurge-intell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668125471310221313",
  "text" : "RT @johnwhilley: #Paris and #ISIS There's the trite propaganda version for the public, and there's the real, dark truth @NafeezAhmed https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Nafeez Ahmed",
        "screen_name" : "NafeezAhmed",
        "indices" : [ 103, 115 ],
        "id_str" : "110692399",
        "id" : 110692399
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Paris",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "ISIS",
        "indices" : [ 11, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/1xms0RKwyO",
        "expanded_url" : "https:\/\/medium.com\/insurge-intelligence\/europe-is-harbouring-the-islamic-state-s-backers-d24db3a24a40#.6cfnn54nt",
        "display_url" : "medium.com\/insurge-intell\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667793423131394048",
    "text" : "#Paris and #ISIS There's the trite propaganda version for the public, and there's the real, dark truth @NafeezAhmed https:\/\/t.co\/1xms0RKwyO",
    "id" : 667793423131394048,
    "created_at" : "2015-11-20 19:55:33 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 668125471310221313,
  "created_at" : "2015-11-21 17:55:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668076761905831936",
  "geo" : { },
  "id_str" : "668080435214290944",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan hi yes at genres talk at mo and u?",
  "id" : 668080435214290944,
  "in_reply_to_status_id" : 668076761905831936,
  "created_at" : "2015-11-21 14:56:02 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 26, 34 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668059648340176896",
  "geo" : { },
  "id_str" : "668073790233051136",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic @HadaLitim @Sugatam emphasis on the \"arguably\"",
  "id" : 668073790233051136,
  "in_reply_to_status_id" : 668059648340176896,
  "created_at" : "2015-11-21 14:29:38 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imara",
      "screen_name" : "iria_marino",
      "indices" : [ 3, 15 ],
      "id_str" : "43163604",
      "id" : 43163604
    }, {
      "name" : "Re@langues",
      "screen_name" : "Realangues1",
      "indices" : [ 111, 123 ],
      "id_str" : "3328192487",
      "id" : 3328192487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668073323583184896",
  "text" : "RT @iria_marino: Playing with Socrative thanks to Jeremy Levin #Tesolfrance discovering a lot of new things... @Realangues1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Re@langues",
        "screen_name" : "Realangues1",
        "indices" : [ 94, 106 ],
        "id_str" : "3328192487",
        "id" : 3328192487
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tesolfrance",
        "indices" : [ 46, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668021964188033024",
    "text" : "Playing with Socrative thanks to Jeremy Levin #Tesolfrance discovering a lot of new things... @Realangues1",
    "id" : 668021964188033024,
    "created_at" : "2015-11-21 11:03:42 +0000",
    "user" : {
      "name" : "Imara",
      "screen_name" : "iria_marino",
      "protected" : false,
      "id_str" : "43163604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1391031301\/Captura_de_pantalla_2011-06-11_a_las_10.46.43_normal.png",
      "id" : 43163604,
      "verified" : false
    }
  },
  "id" : 668073323583184896,
  "created_at" : "2015-11-21 14:27:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 3, 12 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SueAnnan\/status\/668065109290393600\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/0QrEtY0e24",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVxrU1WsAA9PF6.jpg",
      "id_str" : "668065108875194368",
      "id" : 668065108875194368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVxrU1WsAA9PF6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/0QrEtY0e24"
    } ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668073184755851268",
  "text" : "RT @SueAnnan: Loving Mark Hancock @ #Tesolfrance https:\/\/t.co\/0QrEtY0e24",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SueAnnan\/status\/668065109290393600\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/0QrEtY0e24",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVxrU1WsAA9PF6.jpg",
        "id_str" : "668065108875194368",
        "id" : 668065108875194368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVxrU1WsAA9PF6.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        } ],
        "display_url" : "pic.twitter.com\/0QrEtY0e24"
      } ],
      "hashtags" : [ {
        "text" : "Tesolfrance",
        "indices" : [ 22, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668065109290393600",
    "text" : "Loving Mark Hancock @ #Tesolfrance https:\/\/t.co\/0QrEtY0e24",
    "id" : 668065109290393600,
    "created_at" : "2015-11-21 13:55:08 +0000",
    "user" : {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "protected" : false,
      "id_str" : "136001411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465548526135435264\/NaTsAwLp_normal.jpeg",
      "id" : 136001411,
      "verified" : false
    }
  },
  "id" : 668073184755851268,
  "created_at" : "2015-11-21 14:27:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 21, 37 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/668063750965080064\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/qSBIk9PCiD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVwbXWWEAQ0uPl.jpg",
      "id_str" : "668063735160901636",
      "id" : 668063735160901636,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVwbXWWEAQ0uPl.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1824,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1069,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qSBIk9PCiD"
    } ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668063750965080064",
  "text" : "Tonic stress workout @HancockMcDonald talk #Tesolfrance https:\/\/t.co\/qSBIk9PCiD",
  "id" : 668063750965080064,
  "created_at" : "2015-11-21 13:49:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 34, 50 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/668053715635580928\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/sFWsAKWieb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVnTiXWoAAsV4o.jpg",
      "id_str" : "668053705074319360",
      "id" : 668053705074319360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVnTiXWoAAsV4o.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/sFWsAKWieb"
    } ],
    "hashtags" : [ {
      "text" : "Tesolfrance",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668053715635580928",
  "text" : "Boxset, Minimal pairs on steroids @HancockMcDonald talk #Tesolfrance https:\/\/t.co\/sFWsAKWieb",
  "id" : 668053715635580928,
  "created_at" : "2015-11-21 13:09:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tawsig",
      "screen_name" : "Tawsig",
      "indices" : [ 5, 12 ],
      "id_str" : "1546060946",
      "id" : 1546060946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfrance",
      "indices" : [ 78, 90 ]
    }, {
      "text" : "JALT2015",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/OT3XO9snx6",
      "expanded_url" : "https:\/\/twitter.com\/taw_sig\/status\/662263484047052800",
      "display_url" : "twitter.com\/taw_sig\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667981998720483329",
  "text" : "Join @tawsig to discuss teacher  development in precarious working conditions #tesolfrance #JALT2015  https:\/\/t.co\/OT3XO9snx6",
  "id" : 667981998720483329,
  "created_at" : "2015-11-21 08:24:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Murtaza Hussain",
      "screen_name" : "MazMHussain",
      "indices" : [ 112, 124 ],
      "id_str" : "84816752",
      "id" : 84816752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/k90UWmVaN0",
      "expanded_url" : "http:\/\/interc.pt\/1MXqNlJ",
      "display_url" : "interc.pt\/1MXqNlJ"
    } ]
  },
  "geo" : { },
  "id_str" : "667787263401721856",
  "text" : "Former drone operators say they were \"horrified\" by cruelty of assassination program https:\/\/t.co\/k90UWmVaN0 by @mazmhussain",
  "id" : 667787263401721856,
  "created_at" : "2015-11-20 19:31:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/sEwbklpuZz",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/AmEcrQGE1Ji",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667773883555127296",
  "text" : "#corpusmooc peeps still all to play for in prize draw for Discovering English with SketchEngine https:\/\/t.co\/sEwbklpuZz",
  "id" : 667773883555127296,
  "created_at" : "2015-11-20 18:37:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "indices" : [ 3, 16 ],
      "id_str" : "17336372",
      "id" : 17336372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbcqt",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667481618316140544",
  "text" : "RT @frankieboyle: I've been watching this for 5 minutes and I am now radicalised against the West #bbcqt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bbcqt",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667480714397523968",
    "text" : "I've been watching this for 5 minutes and I am now radicalised against the West #bbcqt",
    "id" : 667480714397523968,
    "created_at" : "2015-11-19 23:12:58 +0000",
    "user" : {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "protected" : false,
      "id_str" : "17336372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743772932892131328\/ZcekAc_1_normal.jpg",
      "id" : 17336372,
      "verified" : true
    }
  },
  "id" : 667481618316140544,
  "created_at" : "2015-11-19 23:16:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 75, 87 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/NlWxUsWjgX",
      "expanded_url" : "http:\/\/wp.me\/p633Ji-3yg",
      "display_url" : "wp.me\/p633Ji-3yg"
    }, {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/H8kBH9sVKQ",
      "expanded_url" : "https:\/\/drive.google.com\/file\/d\/0B7FW2BYaBgeiVk5sRWs2MGNzZkk\/view",
      "display_url" : "drive.google.com\/file\/d\/0B7FW2B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667480541927751680",
  "text" : "BBC caught throwing facts down the memory hole https:\/\/t.co\/NlWxUsWjgX via @OffGuardian audio clip https:\/\/t.co\/H8kBH9sVKQ",
  "id" : 667480541927751680,
  "created_at" : "2015-11-19 23:12:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Vgj22dZyQT",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/hE7fWK7S1ei",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "667475850774913024",
  "geo" : { },
  "id_str" : "667477134865268736",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr grt! started list as well though not been too diligent with it lately some initial links posted here - https:\/\/t.co\/Vgj22dZyQT",
  "id" : 667477134865268736,
  "in_reply_to_status_id" : 667475850774913024,
  "created_at" : "2015-11-19 22:58:44 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEASIG",
      "screen_name" : "iatefl_teasig",
      "indices" : [ 3, 17 ],
      "id_str" : "3432663095",
      "id" : 3432663095
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 19, 26 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/iatefl_teasig\/status\/667379541824925696\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/J51RCioziW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMCKAKVAAQiCST.jpg",
      "id_str" : "667379540646232068",
      "id" : 667379540646232068,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMCKAKVAAQiCST.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J51RCioziW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/TGUZ5LjlXV",
      "expanded_url" : "http:\/\/tea.iatefl.org\/index.php\/upcoming-teasig-events\/",
      "display_url" : "tea.iatefl.org\/index.php\/upco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667382262086959104",
  "text" : "RT @iatefl_teasig: @iatefl TEASIG's upcoming webinar w\/ Tony Green on Dec 02, 2015. Check out our webpage https:\/\/t.co\/TGUZ5LjlXV https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IATEFL Head Office",
        "screen_name" : "iatefl",
        "indices" : [ 0, 7 ],
        "id_str" : "85042286",
        "id" : 85042286
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/iatefl_teasig\/status\/667379541824925696\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/J51RCioziW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMCKAKVAAQiCST.jpg",
        "id_str" : "667379540646232068",
        "id" : 667379540646232068,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMCKAKVAAQiCST.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/J51RCioziW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/TGUZ5LjlXV",
        "expanded_url" : "http:\/\/tea.iatefl.org\/index.php\/upcoming-teasig-events\/",
        "display_url" : "tea.iatefl.org\/index.php\/upco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667379541824925696",
    "in_reply_to_user_id" : 85042286,
    "text" : "@iatefl TEASIG's upcoming webinar w\/ Tony Green on Dec 02, 2015. Check out our webpage https:\/\/t.co\/TGUZ5LjlXV https:\/\/t.co\/J51RCioziW",
    "id" : 667379541824925696,
    "created_at" : "2015-11-19 16:30:56 +0000",
    "in_reply_to_screen_name" : "iatefl",
    "in_reply_to_user_id_str" : "85042286",
    "user" : {
      "name" : "TEASIG",
      "screen_name" : "iatefl_teasig",
      "protected" : false,
      "id_str" : "3432663095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646031057683369984\/28l6sr7Z_normal.png",
      "id" : 3432663095,
      "verified" : false
    }
  },
  "id" : 667382262086959104,
  "created_at" : "2015-11-19 16:41:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/BLuoaxb81x",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/11\/16\/51452\/577",
      "display_url" : "eurotrib.com\/story\/2015\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667376286143225856",
  "text" : "Us and Them https:\/\/t.co\/BLuoaxb81x",
  "id" : 667376286143225856,
  "created_at" : "2015-11-19 16:18:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/0lxpFNWpYb",
      "expanded_url" : "http:\/\/gu.com\/p\/4eaty\/stw",
      "display_url" : "gu.com\/p\/4eaty\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "667338359266766848",
  "text" : "Immigrants' spouses 'must speak English before entering UK' https:\/\/t.co\/0lxpFNWpYb",
  "id" : 667338359266766848,
  "created_at" : "2015-11-19 13:47:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Ames",
      "screen_name" : "MarkAmesExiled",
      "indices" : [ 3, 18 ],
      "id_str" : "38214152",
      "id" : 38214152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4GQvUL7bCc",
      "expanded_url" : "https:\/\/pando.com\/2015\/11\/17\/silicon-valley-vs-civilization\/74f8900459745a06f190d22e99848ac473657b75\/",
      "display_url" : "pando.com\/2015\/11\/17\/sil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667318146181763072",
  "text" : "RT @MarkAmesExiled: My newest: \"Silicon Valley vs Civilization\" on tech billionaires' love affair with Modi as he terrorizes minorities htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4GQvUL7bCc",
        "expanded_url" : "https:\/\/pando.com\/2015\/11\/17\/silicon-valley-vs-civilization\/74f8900459745a06f190d22e99848ac473657b75\/",
        "display_url" : "pando.com\/2015\/11\/17\/sil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666680760565387266",
    "text" : "My newest: \"Silicon Valley vs Civilization\" on tech billionaires' love affair with Modi as he terrorizes minorities https:\/\/t.co\/4GQvUL7bCc",
    "id" : 666680760565387266,
    "created_at" : "2015-11-17 18:14:14 +0000",
    "user" : {
      "name" : "Mark Ames",
      "screen_name" : "MarkAmesExiled",
      "protected" : false,
      "id_str" : "38214152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3372876516\/7630ff2ed18d36bde48bc8f79cbad03f_normal.png",
      "id" : 38214152,
      "verified" : false
    }
  },
  "id" : 667318146181763072,
  "created_at" : "2015-11-19 12:26:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Dale",
      "screen_name" : "joedale",
      "indices" : [ 0, 8 ],
      "id_str" : "5923092",
      "id" : 5923092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667309236179701760",
  "geo" : { },
  "id_str" : "667317298558988289",
  "in_reply_to_user_id" : 5923092,
  "text" : "@joedale no but i think if you use a folder then track can be played in drive i.e. streamed without needing to be downloaded",
  "id" : 667317298558988289,
  "in_reply_to_status_id" : 667309236179701760,
  "created_at" : "2015-11-19 12:23:36 +0000",
  "in_reply_to_screen_name" : "joedale",
  "in_reply_to_user_id_str" : "5923092",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Dale",
      "screen_name" : "joedale",
      "indices" : [ 0, 8 ],
      "id_str" : "5923092",
      "id" : 5923092
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 9, 17 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Huda Hammoud",
      "screen_name" : "hudahammoud",
      "indices" : [ 18, 30 ],
      "id_str" : "17273358",
      "id" : 17273358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667314669141409793",
  "geo" : { },
  "id_str" : "667316743904317440",
  "in_reply_to_user_id" : 5923092,
  "text" : "@joedale @Ven_VVE @hudahammoud good news :)",
  "id" : 667316743904317440,
  "in_reply_to_status_id" : 667314669141409793,
  "created_at" : "2015-11-19 12:21:24 +0000",
  "in_reply_to_screen_name" : "joedale",
  "in_reply_to_user_id_str" : "5923092",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Dale",
      "screen_name" : "joedale",
      "indices" : [ 0, 8 ],
      "id_str" : "5923092",
      "id" : 5923092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667279100403298304",
  "geo" : { },
  "id_str" : "667289735027560448",
  "in_reply_to_user_id" : 5923092,
  "text" : "@joedale hi make a folder that is public then put mp3 in that shld work",
  "id" : 667289735027560448,
  "in_reply_to_status_id" : 667279100403298304,
  "created_at" : "2015-11-19 10:34:05 +0000",
  "in_reply_to_screen_name" : "joedale",
  "in_reply_to_user_id_str" : "5923092",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/OWgbiugMpY",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=65762",
      "display_url" : "tm.durusau.net\/?p=65762"
    } ]
  },
  "geo" : { },
  "id_str" : "667232636046323712",
  "text" : "RT @patrickDurusau: Paris: The Power of Unencrypted Vanilla SMS (Network News: You are now dumber for having heard it) https:\/\/t.co\/OWgbiug\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/OWgbiugMpY",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=65762",
        "display_url" : "tm.durusau.net\/?p=65762"
      } ]
    },
    "geo" : { },
    "id_str" : "667101795743866881",
    "text" : "Paris: The Power of Unencrypted Vanilla SMS (Network News: You are now dumber for having heard it) https:\/\/t.co\/OWgbiugMpY",
    "id" : 667101795743866881,
    "created_at" : "2015-11-18 22:07:16 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 667232636046323712,
  "created_at" : "2015-11-19 06:47:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "FingerTipsEnglish",
      "screen_name" : "Fingertips_eng",
      "indices" : [ 22, 37 ],
      "id_str" : "3481015342",
      "id" : 3481015342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667222100277649408",
  "geo" : { },
  "id_str" : "667225335122014208",
  "in_reply_to_user_id" : 3481015342,
  "text" : "@thisbyanychance tell @Fingertips_eng about Dale cone",
  "id" : 667225335122014208,
  "in_reply_to_status_id" : 667222100277649408,
  "created_at" : "2015-11-19 06:18:10 +0000",
  "in_reply_to_screen_name" : "Fingertips_eng",
  "in_reply_to_user_id_str" : "3481015342",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torben Betts",
      "screen_name" : "TorbenBetts",
      "indices" : [ 3, 15 ],
      "id_str" : "2419986010",
      "id" : 2419986010
    }, {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 40, 52 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8dAJzSGlN6",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/11\/frances-state-violence-10-key-truths.html?m=1",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/11\/france\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667005023356919808",
  "text" : "RT @TorbenBetts: Essential reading from @johnwhilley. He examines the role of French state violence in provoking the Paris atrocity. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Hilley",
        "screen_name" : "johnwhilley",
        "indices" : [ 23, 35 ],
        "id_str" : "223771625",
        "id" : 223771625
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/8dAJzSGlN6",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/11\/frances-state-violence-10-key-truths.html?m=1",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/11\/france\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666987345883865088",
    "text" : "Essential reading from @johnwhilley. He examines the role of French state violence in provoking the Paris atrocity. https:\/\/t.co\/8dAJzSGlN6",
    "id" : 666987345883865088,
    "created_at" : "2015-11-18 14:32:29 +0000",
    "user" : {
      "name" : "Torben Betts",
      "screen_name" : "TorbenBetts",
      "protected" : false,
      "id_str" : "2419986010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721943117222518785\/iPhrAAd0_normal.jpg",
      "id" : 2419986010,
      "verified" : false
    }
  },
  "id" : 667005023356919808,
  "created_at" : "2015-11-18 15:42:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "indices" : [ 97, 106 ],
      "id_str" : "14437914",
      "id" : 14437914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ID7p28aLkv",
      "expanded_url" : "http:\/\/to.pbs.org\/1S2ArYw",
      "display_url" : "to.pbs.org\/1S2ArYw"
    } ]
  },
  "geo" : { },
  "id_str" : "666753407647133696",
  "text" : "Given Internet access, can kids really learn anything by themselves? https:\/\/t.co\/ID7p28aLkv via @NewsHour :\/",
  "id" : 666753407647133696,
  "created_at" : "2015-11-17 23:02:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 3, 14 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/CRvAWm5DQg",
      "expanded_url" : "https:\/\/medium.com\/@alxndghall\/empirical-evidence-that-my-senior-year-was-the-best-ever-c56ecff1fba1",
      "display_url" : "medium.com\/@alxndghall\/em\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666735573739003904",
  "text" : "RT @alxndghall: Playing with some more #corpusMOOC toys! I just published \u201CEmpirical evidence that my senior year was the best ever\u201D https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/CRvAWm5DQg",
        "expanded_url" : "https:\/\/medium.com\/@alxndghall\/empirical-evidence-that-my-senior-year-was-the-best-ever-c56ecff1fba1",
        "display_url" : "medium.com\/@alxndghall\/em\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666501446813151232",
    "text" : "Playing with some more #corpusMOOC toys! I just published \u201CEmpirical evidence that my senior year was the best ever\u201D https:\/\/t.co\/CRvAWm5DQg",
    "id" : 666501446813151232,
    "created_at" : "2015-11-17 06:21:42 +0000",
    "user" : {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "protected" : false,
      "id_str" : "1656929592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695730006287253504\/CVIxnOtE_normal.jpg",
      "id" : 1656929592,
      "verified" : false
    }
  },
  "id" : 666735573739003904,
  "created_at" : "2015-11-17 21:52:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 3, 19 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    }, {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 37, 49 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 65, 73 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 74, 83 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 84, 93 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Yf0gK5Po1A",
      "expanded_url" : "http:\/\/theteflshow.com\/2015\/11\/17\/working-conditions-in-elt",
      "display_url" : "theteflshow.com\/2015\/11\/17\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666592308104724480",
  "text" : "RT @MarekKiczkowiak: this episode of @TheTeflShow might interest @taw_sig @josipa74 @muranava https:\/\/t.co\/Yf0gK5Po1A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The TEFL Show",
        "screen_name" : "TheTeflShow",
        "indices" : [ 16, 28 ],
        "id_str" : "3996937557",
        "id" : 3996937557
      }, {
        "name" : "teachers_as_workers",
        "screen_name" : "taw_sig",
        "indices" : [ 44, 52 ],
        "id_str" : "3152637711",
        "id" : 3152637711
      }, {
        "name" : "paulw",
        "screen_name" : "josipa74",
        "indices" : [ 53, 62 ],
        "id_str" : "134211317",
        "id" : 134211317
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 63, 72 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/Yf0gK5Po1A",
        "expanded_url" : "http:\/\/theteflshow.com\/2015\/11\/17\/working-conditions-in-elt",
        "display_url" : "theteflshow.com\/2015\/11\/17\/wor\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "666551965376098304",
    "geo" : { },
    "id_str" : "666552453240889344",
    "in_reply_to_user_id" : 3996937557,
    "text" : "this episode of @TheTeflShow might interest @taw_sig @josipa74 @muranava https:\/\/t.co\/Yf0gK5Po1A",
    "id" : 666552453240889344,
    "in_reply_to_status_id" : 666551965376098304,
    "created_at" : "2015-11-17 09:44:23 +0000",
    "in_reply_to_screen_name" : "TheTeflShow",
    "in_reply_to_user_id_str" : "3996937557",
    "user" : {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "protected" : false,
      "id_str" : "2561325079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476735541497450498\/KCwdjZhZ_normal.jpeg",
      "id" : 2561325079,
      "verified" : false
    }
  },
  "id" : 666592308104724480,
  "created_at" : "2015-11-17 12:22:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Laura Kuenssberg",
      "screen_name" : "bbclaurak",
      "indices" : [ 20, 30 ],
      "id_str" : "61183568",
      "id" : 61183568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666402094178566144",
  "text" : "RT @medialens: Dear @bbclaurak Please stop implying that compassionate, rational, anti-war arguments supported by millions are fresh in fro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Kuenssberg",
        "screen_name" : "bbclaurak",
        "indices" : [ 5, 15 ],
        "id_str" : "61183568",
        "id" : 61183568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666344646105255936",
    "text" : "Dear @bbclaurak Please stop implying that compassionate, rational, anti-war arguments supported by millions are fresh in from Neptune.",
    "id" : 666344646105255936,
    "created_at" : "2015-11-16 19:58:38 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 666402094178566144,
  "created_at" : "2015-11-16 23:46:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETAS",
      "screen_name" : "ETAS_CH",
      "indices" : [ 0, 8 ],
      "id_str" : "1558541821",
      "id" : 1558541821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666274035165081601",
  "geo" : { },
  "id_str" : "666401080251711488",
  "in_reply_to_user_id" : 1558541821,
  "text" : "@ETAS_CH thanks for sharing much appreciated :)",
  "id" : 666401080251711488,
  "in_reply_to_status_id" : 666274035165081601,
  "created_at" : "2015-11-16 23:42:53 +0000",
  "in_reply_to_screen_name" : "ETAS_CH",
  "in_reply_to_user_id_str" : "1558541821",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 3, 13 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Geraldine Mark",
      "screen_name" : "_GelMark",
      "indices" : [ 66, 75 ],
      "id_str" : "579727372",
      "id" : 579727372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grammar",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "corpus",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/3d78Il4Dtw",
      "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2015\/11\/introducing-english-grammar-profile-2-whats-use-egp\/",
      "display_url" : "cambridge.org\/elt\/blog\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666400994440429568",
  "text" : "RT @TEFLclass: What's the use of English Grammar Profile? Blog #2 @_GelMark https:\/\/t.co\/3d78Il4Dtw #grammar #ELTchat #corpus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geraldine Mark",
        "screen_name" : "_GelMark",
        "indices" : [ 51, 60 ],
        "id_str" : "579727372",
        "id" : 579727372
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grammar",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "corpus",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/3d78Il4Dtw",
        "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2015\/11\/introducing-english-grammar-profile-2-whats-use-egp\/",
        "display_url" : "cambridge.org\/elt\/blog\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666388738809950208",
    "text" : "What's the use of English Grammar Profile? Blog #2 @_GelMark https:\/\/t.co\/3d78Il4Dtw #grammar #ELTchat #corpus",
    "id" : 666388738809950208,
    "created_at" : "2015-11-16 22:53:50 +0000",
    "user" : {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "protected" : false,
      "id_str" : "469244585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000353527279\/c15d358a877f62d20d0e180a1da73b4c_normal.jpeg",
      "id" : 469244585,
      "verified" : false
    }
  },
  "id" : 666400994440429568,
  "created_at" : "2015-11-16 23:42:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666168993699504128",
  "geo" : { },
  "id_str" : "666220510204846081",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 it's ok , folks seem to be carrying on as usual",
  "id" : 666220510204846081,
  "in_reply_to_status_id" : 666168993699504128,
  "created_at" : "2015-11-16 11:45:22 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665926359236141057",
  "geo" : { },
  "id_str" : "665962955037655040",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thanks for sharing Gemma :)",
  "id" : 665962955037655040,
  "in_reply_to_status_id" : 665926359236141057,
  "created_at" : "2015-11-15 18:41:56 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/WiK3h3uGjo",
      "expanded_url" : "http:\/\/tinyurl.com\/q8lh486",
      "display_url" : "tinyurl.com\/q8lh486"
    } ]
  },
  "geo" : { },
  "id_str" : "665961561001996288",
  "text" : "RT @TonyMcEnery: This week's #corpusmooc bonus article: \"What's Hard in German? WHiG: a British learner corpus of German\" https:\/\/t.co\/WiK3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 12, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/WiK3h3uGjo",
        "expanded_url" : "http:\/\/tinyurl.com\/q8lh486",
        "display_url" : "tinyurl.com\/q8lh486"
      } ]
    },
    "geo" : { },
    "id_str" : "665866230771941376",
    "text" : "This week's #corpusmooc bonus article: \"What's Hard in German? WHiG: a British learner corpus of German\" https:\/\/t.co\/WiK3h3uGjo",
    "id" : 665866230771941376,
    "created_at" : "2015-11-15 12:17:35 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 665961561001996288,
  "created_at" : "2015-11-15 18:36:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 96, 112 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/5KWihRKnjI",
      "expanded_url" : "http:\/\/wp.me\/p3c4te-47",
      "display_url" : "wp.me\/p3c4te-47"
    } ]
  },
  "geo" : { },
  "id_str" : "665831457420656644",
  "text" : "Paris, ISIS, and the 'Dangerous Consequences of Hard-Left Policies' https:\/\/t.co\/5KWihRKnjI via @wordpressdotcom",
  "id" : 665831457420656644,
  "created_at" : "2015-11-15 09:59:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665475036216561664",
  "geo" : { },
  "id_str" : "665518114134691840",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thanks Marc how's your Saturday going?",
  "id" : 665518114134691840,
  "in_reply_to_status_id" : 665475036216561664,
  "created_at" : "2015-11-14 13:14:17 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665307103477690368",
  "geo" : { },
  "id_str" : "665312169886547969",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hey Marc thx ok, watching news myself at mo :(",
  "id" : 665312169886547969,
  "in_reply_to_status_id" : 665307103477690368,
  "created_at" : "2015-11-13 23:35:56 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 0, 12 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890190515802113",
  "geo" : { },
  "id_str" : "665267012462059520",
  "in_reply_to_user_id" : 3092999387,
  "text" : "@TEFLCommute i favour dictating exercises when i can, or using #piratebox to share files",
  "id" : 665267012462059520,
  "in_reply_to_status_id" : 664890190515802113,
  "created_at" : "2015-11-13 20:36:30 +0000",
  "in_reply_to_screen_name" : "TEFLCommute",
  "in_reply_to_user_id_str" : "3092999387",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 97, 109 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/noYlYcNPIg",
      "expanded_url" : "http:\/\/wp.me\/p633Ji-3p4",
      "display_url" : "wp.me\/p633Ji-3p4"
    } ]
  },
  "geo" : { },
  "id_str" : "665265321918529536",
  "text" : "The droning of Jihadi John:  another blockbuster for our delectation https:\/\/t.co\/noYlYcNPIg via @OffGuardian",
  "id" : 665265321918529536,
  "created_at" : "2015-11-13 20:29:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/YVfLJDLLJS",
      "expanded_url" : "https:\/\/youtu.be\/-J4yweW-Vfs",
      "display_url" : "youtu.be\/-J4yweW-Vfs"
    } ]
  },
  "geo" : { },
  "id_str" : "665246249260589057",
  "text" : "The iRabbit : \"It's not sheep.\" https:\/\/t.co\/YVfLJDLLJS via @YouTube :)",
  "id" : 665246249260589057,
  "created_at" : "2015-11-13 19:14:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/uFEQBmsDe3",
      "expanded_url" : "https:\/\/youtu.be\/XK81tvYEz3Q",
      "display_url" : "youtu.be\/XK81tvYEz3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "665244417276686336",
  "text" : "The Package: \"I'm in the coffee\" https:\/\/t.co\/uFEQBmsDe3 via @YouTube could be useful for preposition work #eltchat",
  "id" : 665244417276686336,
  "created_at" : "2015-11-13 19:06:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 3, 13 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Geraldine Mark",
      "screen_name" : "_GelMark",
      "indices" : [ 123, 132 ],
      "id_str" : "579727372",
      "id" : 579727372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "grammar",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/G40riDWR2h",
      "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2015\/11\/introducing-english-grammar-profile-1-building-profile\/",
      "display_url" : "cambridge.org\/elt\/blog\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "665126565320200192",
  "text" : "RT @TEFLclass: Introducing+the+English+Grammar+Profile+#1+\u2013+Building+the+profile+ https:\/\/t.co\/G40riDWR2h #corpus #grammar @_GelMark",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geraldine Mark",
        "screen_name" : "_GelMark",
        "indices" : [ 108, 117 ],
        "id_str" : "579727372",
        "id" : 579727372
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "grammar",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/G40riDWR2h",
        "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2015\/11\/introducing-english-grammar-profile-1-building-profile\/",
        "display_url" : "cambridge.org\/elt\/blog\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664925815302410240",
    "text" : "Introducing+the+English+Grammar+Profile+#1+\u2013+Building+the+profile+ https:\/\/t.co\/G40riDWR2h #corpus #grammar @_GelMark",
    "id" : 664925815302410240,
    "created_at" : "2015-11-12 22:00:42 +0000",
    "user" : {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "protected" : false,
      "id_str" : "469244585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000353527279\/c15d358a877f62d20d0e180a1da73b4c_normal.jpeg",
      "id" : 469244585,
      "verified" : false
    }
  },
  "id" : 665126565320200192,
  "created_at" : "2015-11-13 11:18:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Kirk Borne",
      "screen_name" : "KirkDBorne",
      "indices" : [ 104, 115 ],
      "id_str" : "534563976",
      "id" : 534563976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gMIIvairLc",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=65619",
      "display_url" : "tm.durusau.net\/?p=65619"
    } ]
  },
  "geo" : { },
  "id_str" : "665031477625778176",
  "text" : "RT @patrickDurusau: Why Neurons Have Thousands of Synapses! (Quick! Someone Call the EU Brain Project!) @KirkDBorne https:\/\/t.co\/gMIIvairLc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirk Borne",
        "screen_name" : "KirkDBorne",
        "indices" : [ 84, 95 ],
        "id_str" : "534563976",
        "id" : 534563976
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/gMIIvairLc",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=65619",
        "display_url" : "tm.durusau.net\/?p=65619"
      } ]
    },
    "geo" : { },
    "id_str" : "664920407603085313",
    "text" : "Why Neurons Have Thousands of Synapses! (Quick! Someone Call the EU Brain Project!) @KirkDBorne https:\/\/t.co\/gMIIvairLc",
    "id" : 664920407603085313,
    "created_at" : "2015-11-12 21:39:13 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 665031477625778176,
  "created_at" : "2015-11-13 05:00:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Hirst",
      "screen_name" : "psychemedia",
      "indices" : [ 122, 134 ],
      "id_str" : "7129072",
      "id" : 7129072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/HqOQC37TI0",
      "expanded_url" : "http:\/\/wp.me\/p1mEF-3Bd",
      "display_url" : "wp.me\/p1mEF-3Bd"
    } ]
  },
  "geo" : { },
  "id_str" : "665030094713430016",
  "text" : "Are Robots Threatening Jobs or Are We Taking Them Ourselves Through Self-Service Automation?: https:\/\/t.co\/HqOQC37TI0 via @psychemedia",
  "id" : 665030094713430016,
  "created_at" : "2015-11-13 04:55:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Jordan",
      "screen_name" : "GeoffJordan",
      "indices" : [ 59, 71 ],
      "id_str" : "29510765",
      "id" : 29510765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/KqMDdFDKiW",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1oI",
      "display_url" : "wp.me\/p3qkCB-1oI"
    } ]
  },
  "geo" : { },
  "id_str" : "664908699866107904",
  "text" : "A Sketch of a Process Syllabus https:\/\/t.co\/KqMDdFDKiW via @GeoffJordan",
  "id" : 664908699866107904,
  "created_at" : "2015-11-12 20:52:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 81, 92 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/KwrN6PYshu",
      "expanded_url" : "http:\/\/wp.me\/p1wqwD-Ow",
      "display_url" : "wp.me\/p1wqwD-Ow"
    } ]
  },
  "geo" : { },
  "id_str" : "664817684215955456",
  "text" : "Children of the new century: mental health at age 11 https:\/\/t.co\/KwrN6PYshu via @IOE_London",
  "id" : 664817684215955456,
  "created_at" : "2015-11-12 14:51:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 0, 12 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 13, 29 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664653869998170113",
  "geo" : { },
  "id_str" : "664765976853020672",
  "in_reply_to_user_id" : 3092999387,
  "text" : "@TEFLCommute @theteacherjames no mention of alternatives to photocopying? maybe for another podcast? : )",
  "id" : 664765976853020672,
  "in_reply_to_status_id" : 664653869998170113,
  "created_at" : "2015-11-12 11:25:34 +0000",
  "in_reply_to_screen_name" : "TEFLCommute",
  "in_reply_to_user_id_str" : "3092999387",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 3, 14 ],
      "id_str" : "18880320",
      "id" : 18880320
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/664703515999113216\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/B7XItrNrnx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTmAUz7UEAAl3An.jpg",
      "id_str" : "664703515038584832",
      "id" : 664703515038584832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTmAUz7UEAAl3An.jpg",
      "sizes" : [ {
        "h" : 88,
        "resize" : "fit",
        "w" : 290
      }, {
        "h" : 88,
        "resize" : "crop",
        "w" : 88
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 290
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 290
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 290
      } ],
      "display_url" : "pic.twitter.com\/B7XItrNrnx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/D264805CBO",
      "expanded_url" : "http:\/\/us5.campaign-archive1.com\/?u=0e1fd1d8748b2f9e23e41a336&id=f2c7ed71bb&e=3c0165d9e8",
      "display_url" : "us5.campaign-archive1.com\/?u=0e1fd1d8748\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664758742165102592",
  "text" : "RT @chucksandy: View the 1st session of Phillip Kerr's iTDi course free. Last day for free access. Hurry!  https:\/\/t.co\/D264805CBO https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chucksandy\/status\/664703515999113216\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/B7XItrNrnx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTmAUz7UEAAl3An.jpg",
        "id_str" : "664703515038584832",
        "id" : 664703515038584832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTmAUz7UEAAl3An.jpg",
        "sizes" : [ {
          "h" : 88,
          "resize" : "fit",
          "w" : 290
        }, {
          "h" : 88,
          "resize" : "crop",
          "w" : 88
        }, {
          "h" : 88,
          "resize" : "fit",
          "w" : 290
        }, {
          "h" : 88,
          "resize" : "fit",
          "w" : 290
        }, {
          "h" : 88,
          "resize" : "fit",
          "w" : 290
        } ],
        "display_url" : "pic.twitter.com\/B7XItrNrnx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/D264805CBO",
        "expanded_url" : "http:\/\/us5.campaign-archive1.com\/?u=0e1fd1d8748b2f9e23e41a336&id=f2c7ed71bb&e=3c0165d9e8",
        "display_url" : "us5.campaign-archive1.com\/?u=0e1fd1d8748\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664703515999113216",
    "text" : "View the 1st session of Phillip Kerr's iTDi course free. Last day for free access. Hurry!  https:\/\/t.co\/D264805CBO https:\/\/t.co\/B7XItrNrnx",
    "id" : 664703515999113216,
    "created_at" : "2015-11-12 07:17:22 +0000",
    "user" : {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "protected" : false,
      "id_str" : "18880320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620217802465513472\/poN-d2nR_normal.jpg",
      "id" : 18880320,
      "verified" : false
    }
  },
  "id" : 664758742165102592,
  "created_at" : "2015-11-12 10:56:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Hendin",
      "screen_name" : "HendinArts",
      "indices" : [ 86, 97 ],
      "id_str" : "437506421",
      "id" : 437506421
    }, {
      "name" : "BuzzFeed UK",
      "screen_name" : "BuzzFeedUK",
      "indices" : [ 98, 109 ],
      "id_str" : "1068121346",
      "id" : 1068121346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/luEjEMjw5W",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/rebeccahendin\/16-photos-of-jeremy-corbyn-leaving-his-house-this-morning?utm_term=.jmAE1JZKE",
      "display_url" : "buzzfeed.com\/rebeccahendin\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664755886712336384",
  "text" : "16 Photos Of Jeremy Corbyn Leaving His House This Morning https:\/\/t.co\/luEjEMjw5W via @hendinarts @BuzzFeedUK",
  "id" : 664755886712336384,
  "created_at" : "2015-11-12 10:45:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESRC",
      "screen_name" : "ESRC",
      "indices" : [ 1, 6 ],
      "id_str" : "19393236",
      "id" : 19393236
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esrc50",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664460204889739264",
  "geo" : { },
  "id_str" : "664745161214177280",
  "in_reply_to_user_id" : 19393236,
  "text" : ".@ESRC curious a UK org omits the UK Survey of English Usage which predated influenced US Brown corpus? #esrc50",
  "id" : 664745161214177280,
  "in_reply_to_status_id" : 664460204889739264,
  "created_at" : "2015-11-12 10:02:51 +0000",
  "in_reply_to_screen_name" : "ESRC",
  "in_reply_to_user_id_str" : "19393236",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 36, 49 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/OFd3i0dDz5",
      "expanded_url" : "http:\/\/wp.me\/s28iGT-fascism",
      "display_url" : "wp.me\/s28iGT-fascism"
    } ]
  },
  "geo" : { },
  "id_str" : "664709031278321664",
  "text" : "Fascism https:\/\/t.co\/OFd3i0dDz5 via @tressiemcphd",
  "id" : 664709031278321664,
  "created_at" : "2015-11-12 07:39:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664520243306504192",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter thanks a lot for RT :)",
  "id" : 664520243306504192,
  "created_at" : "2015-11-11 19:09:06 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664450059594018816",
  "geo" : { },
  "id_str" : "664520076528386048",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher nice lk fwd to that :)",
  "id" : 664520076528386048,
  "in_reply_to_status_id" : 664450059594018816,
  "created_at" : "2015-11-11 19:08:27 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/xal8KTXshS",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/11\/when-something-or-other-happens-and.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/11\/when-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664519909158821888",
  "text" : "RT @pchallinor: New mudgeonry: When something or other happens and somebody ought to do something about it https:\/\/t.co\/xal8KTXshS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/xal8KTXshS",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/11\/when-something-or-other-happens-and.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/11\/when-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664518109718560769",
    "text" : "New mudgeonry: When something or other happens and somebody ought to do something about it https:\/\/t.co\/xal8KTXshS",
    "id" : 664518109718560769,
    "created_at" : "2015-11-11 19:00:38 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 664519909158821888,
  "created_at" : "2015-11-11 19:07:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 16, 27 ],
      "id_str" : "10052752",
      "id" : 10052752
    }, {
      "name" : "Mark",
      "screen_name" : "mark_arthur",
      "indices" : [ 28, 40 ],
      "id_str" : "21660464",
      "id" : 21660464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664388720225857536",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @daylemajor @mark_arthur thks for the RT guys :)",
  "id" : 664388720225857536,
  "created_at" : "2015-11-11 10:26:29 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Ballad",
      "screen_name" : "Blackballaduk",
      "indices" : [ 3, 17 ],
      "id_str" : "2155058246",
      "id" : 2155058246
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Blackballaduk\/status\/664160131500797952\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/5glDd4knMQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTd20EWWcAEPh-X.png",
      "id_str" : "664130106953199617",
      "id" : 664130106953199617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTd20EWWcAEPh-X.png",
      "sizes" : [ {
        "h" : 78,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 78,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 54,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 78,
        "resize" : "crop",
        "w" : 78
      }, {
        "h" : 78,
        "resize" : "fit",
        "w" : 491
      } ],
      "display_url" : "pic.twitter.com\/5glDd4knMQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/hKkxe8xY7f",
      "expanded_url" : "http:\/\/blkbld.uk\/1L5O9UP",
      "display_url" : "blkbld.uk\/1L5O9UP"
    } ]
  },
  "geo" : { },
  "id_str" : "664388306063466496",
  "text" : "RT @Blackballaduk: This is why Emma Watson's brand on feminism is highly questionable https:\/\/t.co\/hKkxe8xY7f https:\/\/t.co\/5glDd4knMQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Blackballaduk\/status\/664160131500797952\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/5glDd4knMQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTd20EWWcAEPh-X.png",
        "id_str" : "664130106953199617",
        "id" : 664130106953199617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTd20EWWcAEPh-X.png",
        "sizes" : [ {
          "h" : 78,
          "resize" : "fit",
          "w" : 491
        }, {
          "h" : 78,
          "resize" : "fit",
          "w" : 491
        }, {
          "h" : 54,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 78,
          "resize" : "crop",
          "w" : 78
        }, {
          "h" : 78,
          "resize" : "fit",
          "w" : 491
        } ],
        "display_url" : "pic.twitter.com\/5glDd4knMQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/hKkxe8xY7f",
        "expanded_url" : "http:\/\/blkbld.uk\/1L5O9UP",
        "display_url" : "blkbld.uk\/1L5O9UP"
      } ]
    },
    "geo" : { },
    "id_str" : "664160131500797952",
    "text" : "This is why Emma Watson's brand on feminism is highly questionable https:\/\/t.co\/hKkxe8xY7f https:\/\/t.co\/5glDd4knMQ",
    "id" : 664160131500797952,
    "created_at" : "2015-11-10 19:18:09 +0000",
    "user" : {
      "name" : "Black Ballad",
      "screen_name" : "Blackballaduk",
      "protected" : false,
      "id_str" : "2155058246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454985449291804672\/t9UIbf74_normal.jpeg",
      "id" : 2155058246,
      "verified" : false
    }
  },
  "id" : 664388306063466496,
  "created_at" : "2015-11-11 10:24:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 59, 73 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/5oo4p7OBAp",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-luA",
      "display_url" : "wp.me\/p1RJaO-luA"
    } ]
  },
  "geo" : { },
  "id_str" : "664222821741129728",
  "text" : "Equal Pay Day (It's a hashtag) https:\/\/t.co\/5oo4p7OBAp via @NicolaPrentis",
  "id" : 664222821741129728,
  "created_at" : "2015-11-10 23:27:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim O'Connor",
      "screen_name" : "shallowbrigade",
      "indices" : [ 3, 18 ],
      "id_str" : "434636431",
      "id" : 434636431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664210653561921542",
  "text" : "RT @shallowbrigade: Getting owned by Tressie McMillan Cottom is easily the most entertaining thing David Simon has done since season 4.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663981554151129089",
    "text" : "Getting owned by Tressie McMillan Cottom is easily the most entertaining thing David Simon has done since season 4.",
    "id" : 663981554151129089,
    "created_at" : "2015-11-10 07:28:33 +0000",
    "user" : {
      "name" : "Kim O'Connor",
      "screen_name" : "shallowbrigade",
      "protected" : false,
      "id_str" : "434636431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2808798095\/f2643ff62cc282dd5673169e2f2a521a_normal.jpeg",
      "id" : 434636431,
      "verified" : false
    }
  },
  "id" : 664210653561921542,
  "created_at" : "2015-11-10 22:38:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    }, {
      "name" : "Daniel McLaughlin",
      "screen_name" : "mclaughlin",
      "indices" : [ 113, 124 ],
      "id_str" : "11095222",
      "id" : 11095222
    }, {
      "name" : "Ross Goodwin",
      "screen_name" : "rossgoodwin",
      "indices" : [ 129, 140 ],
      "id_str" : "16411813",
      "id" : 16411813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/8bXhvyPMfi",
      "expanded_url" : "http:\/\/fusion.net\/interactive\/213317\/lose-yourself-in-our-massive-searchable-collection-of-candidates-social-media-photos\/",
      "display_url" : "fusion.net\/interactive\/21\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664207243278221312",
  "text" : "RT @sam_lavigne: Every image uploaded by every 2016 presidential candidate, tagged: https:\/\/t.co\/8bXhvyPMfi with @mclaughlin and @rossgoodw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel McLaughlin",
        "screen_name" : "mclaughlin",
        "indices" : [ 96, 107 ],
        "id_str" : "11095222",
        "id" : 11095222
      }, {
        "name" : "Ross Goodwin",
        "screen_name" : "rossgoodwin",
        "indices" : [ 112, 124 ],
        "id_str" : "16411813",
        "id" : 16411813
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/8bXhvyPMfi",
        "expanded_url" : "http:\/\/fusion.net\/interactive\/213317\/lose-yourself-in-our-massive-searchable-collection-of-candidates-social-media-photos\/",
        "display_url" : "fusion.net\/interactive\/21\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664147149660266496",
    "text" : "Every image uploaded by every 2016 presidential candidate, tagged: https:\/\/t.co\/8bXhvyPMfi with @mclaughlin and @rossgoodwin",
    "id" : 664147149660266496,
    "created_at" : "2015-11-10 18:26:34 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 664207243278221312,
  "created_at" : "2015-11-10 22:25:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664204044534181888",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran many thx for the RT Ljiljana :)",
  "id" : 664204044534181888,
  "created_at" : "2015-11-10 22:12:39 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 0, 12 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664045293239971840",
  "geo" : { },
  "id_str" : "664053796675432448",
  "in_reply_to_user_id" : 223771625,
  "text" : "@johnwhilley a great post John thanks",
  "id" : 664053796675432448,
  "in_reply_to_status_id" : 664045293239971840,
  "created_at" : "2015-11-10 12:15:37 +0000",
  "in_reply_to_screen_name" : "johnwhilley",
  "in_reply_to_user_id_str" : "223771625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BDS",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/ZNynx8riIn",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/11\/jk-rowling-and-friends-protecting.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/11\/jk-row\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664051422636437504",
  "text" : "RT @johnwhilley: JK Rowling and friends protecting Israel through fantasy story of 'co-existence' and 'hilltop engagement' https:\/\/t.co\/ZNy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BDS",
        "indices" : [ 130, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/ZNynx8riIn",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/11\/jk-rowling-and-friends-protecting.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/11\/jk-row\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664045293239971840",
    "text" : "JK Rowling and friends protecting Israel through fantasy story of 'co-existence' and 'hilltop engagement' https:\/\/t.co\/ZNynx8riIn #BDS",
    "id" : 664045293239971840,
    "created_at" : "2015-11-10 11:41:49 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 664051422636437504,
  "created_at" : "2015-11-10 12:06:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664049225345441792",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague thanks for the RT :)",
  "id" : 664049225345441792,
  "created_at" : "2015-11-10 11:57:27 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/664048236655738880\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VNIXJkR11E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTcsWh3XAAAkkV1.jpg",
      "id_str" : "664048235619745792",
      "id" : 664048235619745792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTcsWh3XAAAkkV1.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/VNIXJkR11E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664048236655738880",
  "text" : "gd rule thumb fr mst pop reports of Artificial Intelligence think AliG saying AI will remind u reporters mindset :) https:\/\/t.co\/VNIXJkR11E",
  "id" : 664048236655738880,
  "created_at" : "2015-11-10 11:53:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/duygucandarli\/status\/663774638892302338\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/TmI7gear63",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTYzg54W4AAIiEE.jpg",
      "id_str" : "663774635469758464",
      "id" : 663774635469758464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTYzg54W4AAIiEE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TmI7gear63"
    } ],
    "hashtags" : [ {
      "text" : "eap",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ZDk71WjjNz",
      "expanded_url" : "http:\/\/authors.elsevier.com\/a\/1S0Da5FQORIhUs",
      "display_url" : "authors.elsevier.com\/a\/1S0Da5FQORIh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664039377673330688",
  "text" : "RT @duygucandarli: Our paper is out in Journal of English for Academic Purposes! Free access till 29th Dec:https:\/\/t.co\/ZDk71WjjNz #eap htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/duygucandarli\/status\/663774638892302338\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/TmI7gear63",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTYzg54W4AAIiEE.jpg",
        "id_str" : "663774635469758464",
        "id" : 663774635469758464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTYzg54W4AAIiEE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 148,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TmI7gear63"
      } ],
      "hashtags" : [ {
        "text" : "eap",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ZDk71WjjNz",
        "expanded_url" : "http:\/\/authors.elsevier.com\/a\/1S0Da5FQORIhUs",
        "display_url" : "authors.elsevier.com\/a\/1S0Da5FQORIh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663774638892302338",
    "text" : "Our paper is out in Journal of English for Academic Purposes! Free access till 29th Dec:https:\/\/t.co\/ZDk71WjjNz #eap https:\/\/t.co\/TmI7gear63",
    "id" : 663774638892302338,
    "created_at" : "2015-11-09 17:46:20 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 664039377673330688,
  "created_at" : "2015-11-10 11:18:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663855152034549760",
  "geo" : { },
  "id_str" : "663856746889420800",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thanks for the share and comment Marc, appreciated",
  "id" : 663856746889420800,
  "in_reply_to_status_id" : 663855152034549760,
  "created_at" : "2015-11-09 23:12:36 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith Dubois",
      "screen_name" : "judyldubois",
      "indices" : [ 0, 12 ],
      "id_str" : "17035334",
      "id" : 17035334
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 13, 24 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663464035720019969",
  "geo" : { },
  "id_str" : "663845743149621248",
  "in_reply_to_user_id" : 17035334,
  "text" : "@judyldubois @leoselivan a lot of demand for being \"good enough\" writers so hard to sell the read more line",
  "id" : 663845743149621248,
  "in_reply_to_status_id" : 663464035720019969,
  "created_at" : "2015-11-09 22:28:53 +0000",
  "in_reply_to_screen_name" : "judyldubois",
  "in_reply_to_user_id_str" : "17035334",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 15, 26 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 27, 34 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663759024668692480",
  "geo" : { },
  "id_str" : "663840987886854144",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet @eilymurphy @SobejM many thanks for the RT : )",
  "id" : 663840987886854144,
  "in_reply_to_status_id" : 663759024668692480,
  "created_at" : "2015-11-09 22:09:59 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 104, 115 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "elt",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "efl",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "esl",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/MVwdMrjRDU",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/11\/09\/using-byu-wiki-corpus-to-recycle-coursebook-vocabulary-in-a-variety-of-contexts\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/11\/09\/usi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663755094119313408",
  "text" : "Using BYU Wiki corpus to recycle coursebook vocabulary in a variety of contexts https:\/\/t.co\/MVwdMrjRDU #CorpusMOOC #eltchat #elt #efl #esl",
  "id" : 663755094119313408,
  "created_at" : "2015-11-09 16:28:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 3, 14 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/qq6hy5VyN6",
      "expanded_url" : "http:\/\/the-round.com\/?p=1634",
      "display_url" : "the-round.com\/?p=1634"
    } ]
  },
  "geo" : { },
  "id_str" : "663740197339832321",
  "text" : "RT @wetheround: New title out at the round today, 100 Activities for Fast Finishers! \nhttps:\/\/t.co\/qq6hy5VyN6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/qq6hy5VyN6",
        "expanded_url" : "http:\/\/the-round.com\/?p=1634",
        "display_url" : "the-round.com\/?p=1634"
      } ]
    },
    "geo" : { },
    "id_str" : "663623979316420608",
    "text" : "New title out at the round today, 100 Activities for Fast Finishers! \nhttps:\/\/t.co\/qq6hy5VyN6",
    "id" : 663623979316420608,
    "created_at" : "2015-11-09 07:47:40 +0000",
    "user" : {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "protected" : false,
      "id_str" : "281918842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1545068295\/twitter-avatar_normal.jpg",
      "id" : 281918842,
      "verified" : false
    }
  },
  "id" : 663740197339832321,
  "created_at" : "2015-11-09 15:29:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 83, 96 ],
      "id_str" : "19658826",
      "id" : 19658826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/FMsave1dKw",
      "expanded_url" : "https:\/\/www.newscientist.com\/article\/mg22830463-300-uk-surveillance-bill-makes-a-scientific-ass-out-of-the-law\/",
      "display_url" : "newscientist.com\/article\/mg2283\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663688443705344001",
  "text" : "UK surveillance bill makes a scientific ass out of the law https:\/\/t.co\/FMsave1dKw @newscientist",
  "id" : 663688443705344001,
  "created_at" : "2015-11-09 12:03:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/6yGijB9KxE",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1446991777.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663449439361753093",
  "text" : "RT @rosendo_joe: SueC: \"Anyone else struggling with the MSM's 'logic' on the Russian air disaster?\"\nhttps:\/\/t.co\/6yGijB9KxE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/6yGijB9KxE",
        "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1446991777.html",
        "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663402034415149056",
    "text" : "SueC: \"Anyone else struggling with the MSM's 'logic' on the Russian air disaster?\"\nhttps:\/\/t.co\/6yGijB9KxE",
    "id" : 663402034415149056,
    "created_at" : "2015-11-08 17:05:45 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 663449439361753093,
  "created_at" : "2015-11-08 20:14:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 59, 69 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/XtFcqoV8y5",
      "expanded_url" : "http:\/\/wp.me\/p1PBvi-uM",
      "display_url" : "wp.me\/p1PBvi-uM"
    } ]
  },
  "geo" : { },
  "id_str" : "663359652604833793",
  "text" : "The Englishman and the Octopus https:\/\/t.co\/XtFcqoV8y5 via @sam_kriss",
  "id" : 663359652604833793,
  "created_at" : "2015-11-08 14:17:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/luizotavioELT\/status\/663328972613251072\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/iEam302ptZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTSeL01XAAALf1l.jpg",
      "id_str" : "663328971128504320",
      "id" : 663328971128504320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTSeL01XAAALf1l.jpg",
      "sizes" : [ {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/iEam302ptZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/3x9fc0yAU1",
      "expanded_url" : "http:\/\/goo.gl\/xAGBjd",
      "display_url" : "goo.gl\/xAGBjd"
    } ]
  },
  "geo" : { },
  "id_str" : "663359405153480704",
  "text" : "RT @luizotavioELT: James Bond rents a car! \nA video-based lesson for intermediate students.\nhttps:\/\/t.co\/3x9fc0yAU1 https:\/\/t.co\/iEam302ptZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/luizotavioELT\/status\/663328972613251072\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/iEam302ptZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTSeL01XAAALf1l.jpg",
        "id_str" : "663328971128504320",
        "id" : 663328971128504320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTSeL01XAAALf1l.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/iEam302ptZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/3x9fc0yAU1",
        "expanded_url" : "http:\/\/goo.gl\/xAGBjd",
        "display_url" : "goo.gl\/xAGBjd"
      } ]
    },
    "geo" : { },
    "id_str" : "663328972613251072",
    "text" : "James Bond rents a car! \nA video-based lesson for intermediate students.\nhttps:\/\/t.co\/3x9fc0yAU1 https:\/\/t.co\/iEam302ptZ",
    "id" : 663328972613251072,
    "created_at" : "2015-11-08 12:15:25 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 663359405153480704,
  "created_at" : "2015-11-08 14:16:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith Dubois",
      "screen_name" : "judyldubois",
      "indices" : [ 0, 12 ],
      "id_str" : "17035334",
      "id" : 17035334
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 13, 24 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663070294928728064",
  "geo" : { },
  "id_str" : "663359287566196737",
  "in_reply_to_user_id" : 17035334,
  "text" : "@judyldubois @leoselivan hmm possibly thgh many of the reading able graduate\/postgraduate students i have taught may beg to differ ; )",
  "id" : 663359287566196737,
  "in_reply_to_status_id" : 663070294928728064,
  "created_at" : "2015-11-08 14:15:53 +0000",
  "in_reply_to_screen_name" : "judyldubois",
  "in_reply_to_user_id_str" : "17035334",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663078913292169216",
  "geo" : { },
  "id_str" : "663357490000732160",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @leoselivan hi Anthony is that the one u mentioned taking time to get published?",
  "id" : 663357490000732160,
  "in_reply_to_status_id" : 663078913292169216,
  "created_at" : "2015-11-08 14:08:44 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Barbara Anna",
      "screen_name" : "bar_zie",
      "indices" : [ 12, 20 ],
      "id_str" : "2231464708",
      "id" : 2231464708
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 21, 36 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 56, 63 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663052318334656512",
  "geo" : { },
  "id_str" : "663357339181912071",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @bar_zie @AnthonyTeacher thanks for sharing @SobejM post folks :)",
  "id" : 663357339181912071,
  "in_reply_to_status_id" : 663052318334656512,
  "created_at" : "2015-11-08 14:08:08 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662400907175333888",
  "geo" : { },
  "id_str" : "662401412484218881",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall that's write u need a corpus that has been collected over time, BYU-COHA is an option",
  "id" : 662401412484218881,
  "in_reply_to_status_id" : 662400907175333888,
  "created_at" : "2015-11-05 22:49:38 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/u4Nmb77CTT",
      "expanded_url" : "https:\/\/www.sketchengine.co.uk\/trends\/",
      "display_url" : "sketchengine.co.uk\/trends\/"
    } ]
  },
  "in_reply_to_status_id_str" : "662397614600531968",
  "geo" : { },
  "id_str" : "662398371240480769",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall google is yr friend :) apparently only 3 corpora that can do this at the mo https:\/\/t.co\/u4Nmb77CTT",
  "id" : 662398371240480769,
  "in_reply_to_status_id" : 662397614600531968,
  "created_at" : "2015-11-05 22:37:33 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 12, 24 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 25, 37 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Kate Finegan",
      "screen_name" : "kehfinegan",
      "indices" : [ 38, 49 ],
      "id_str" : "3236117203",
      "id" : 3236117203
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 50, 61 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "redacto",
      "screen_name" : "redactoUk",
      "indices" : [ 62, 72 ],
      "id_str" : "4045823794",
      "id" : 4045823794
    }, {
      "name" : "Richard Ingold",
      "screen_name" : "RichardIngold",
      "indices" : [ 73, 87 ],
      "id_str" : "2561140580",
      "id" : 2561140580
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 107, 114 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662389206958915585",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @lexicojules @ELTResearch @kehfinegan @teflerinha @redactoUk @RichardIngold many thx for RTing @SobejM corpus post :)",
  "id" : 662389206958915585,
  "created_at" : "2015-11-05 22:01:08 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662270784287600641",
  "geo" : { },
  "id_str" : "662273754609934336",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu wonder what those Chinese(?) characters mean that is photoshopped when the guy throws off his top?",
  "id" : 662273754609934336,
  "in_reply_to_status_id" : 662270784287600641,
  "created_at" : "2015-11-05 14:22:22 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/C4BjdWSw8p",
      "expanded_url" : "https:\/\/twitter.com\/reubenbond\/status\/662061791497744384",
      "display_url" : "twitter.com\/reubenbond\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662272380782387200",
  "text" : "RT @peterrenshu: Is this some kind of metaphor for Core i7? https:\/\/t.co\/C4BjdWSw8p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/C4BjdWSw8p",
        "expanded_url" : "https:\/\/twitter.com\/reubenbond\/status\/662061791497744384",
        "display_url" : "twitter.com\/reubenbond\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "662270784287600641",
    "text" : "Is this some kind of metaphor for Core i7? https:\/\/t.co\/C4BjdWSw8p",
    "id" : 662270784287600641,
    "created_at" : "2015-11-05 14:10:34 +0000",
    "user" : {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "protected" : false,
      "id_str" : "631949549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390141891\/azxwx57ppddic0hnd26k_normal.jpeg",
      "id" : 631949549,
      "verified" : false
    }
  },
  "id" : 662272380782387200,
  "created_at" : "2015-11-05 14:16:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662270784287600641",
  "geo" : { },
  "id_str" : "662271241487785984",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu hahhahhhahahhahhhhahhahahhhahhaaahhaaaaaaaaa!",
  "id" : 662271241487785984,
  "in_reply_to_status_id" : 662270784287600641,
  "created_at" : "2015-11-05 14:12:23 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662266640688685056",
  "geo" : { },
  "id_str" : "662267033397166080",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas sorry bad attempt at humour ; )",
  "id" : 662267033397166080,
  "in_reply_to_status_id" : 662266640688685056,
  "created_at" : "2015-11-05 13:55:39 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662263444754841600",
  "geo" : { },
  "id_str" : "662265814897283073",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas when they took away the GL keyboard shortcut for lists from my lukewarm RSI hand my e-rage knew no bounds...",
  "id" : 662265814897283073,
  "in_reply_to_status_id" : 662263444754841600,
  "created_at" : "2015-11-05 13:50:49 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/662254465983057920\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/fBpCtXx402",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTDM7WbWsAASW08.png",
      "id_str" : "662254465228124160",
      "id" : 662254465228124160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTDM7WbWsAASW08.png",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1420
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fBpCtXx402"
    } ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662254465983057920",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall for multi-word sketch click on the word not frequency number #corpusmooc https:\/\/t.co\/fBpCtXx402",
  "id" : 662254465983057920,
  "created_at" : "2015-11-05 13:05:43 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/sE2vZNrST1",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1812",
      "display_url" : "cass.lancs.ac.uk\/?p=1812"
    } ]
  },
  "geo" : { },
  "id_str" : "662239666419167232",
  "text" : "RT @CorpusSocialSci: Exciting news about Spoken BNC2014! Applications for early access data grants are now open! Read more and apply here h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/sE2vZNrST1",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1812",
        "display_url" : "cass.lancs.ac.uk\/?p=1812"
      } ]
    },
    "geo" : { },
    "id_str" : "662222374125834240",
    "text" : "Exciting news about Spoken BNC2014! Applications for early access data grants are now open! Read more and apply here https:\/\/t.co\/sE2vZNrST1",
    "id" : 662222374125834240,
    "created_at" : "2015-11-05 10:58:12 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 662239666419167232,
  "created_at" : "2015-11-05 12:06:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/8kPbVJvopY",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/806-bombing-syria.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662239558298374144",
  "text" : "RT @medialens: See if you can spot the bias in these BBC analyses of the US and Russian bombing campaigns in Syria https:\/\/t.co\/8kPbVJvopY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/8kPbVJvopY",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/806-bombing-syria.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "662222542560731136",
    "text" : "See if you can spot the bias in these BBC analyses of the US and Russian bombing campaigns in Syria https:\/\/t.co\/8kPbVJvopY",
    "id" : 662222542560731136,
    "created_at" : "2015-11-05 10:58:52 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 662239558298374144,
  "created_at" : "2015-11-05 12:06:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662228902434070528",
  "geo" : { },
  "id_str" : "662239435480817664",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx for the big up Marc :)",
  "id" : 662239435480817664,
  "in_reply_to_status_id" : 662228902434070528,
  "created_at" : "2015-11-05 12:05:59 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Didau",
      "screen_name" : "LearningSpy",
      "indices" : [ 3, 15 ],
      "id_str" : "146139473",
      "id" : 146139473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/0YdNhbbKi0",
      "expanded_url" : "http:\/\/www.learningspy.co.uk\/assessment\/tests-dont-kill-people\/",
      "display_url" : "learningspy.co.uk\/assessment\/tes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662050529883877378",
  "text" : "RT @LearningSpy: *NEW* Tests don't kill people https:\/\/t.co\/0YdNhbbKi0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/0YdNhbbKi0",
        "expanded_url" : "http:\/\/www.learningspy.co.uk\/assessment\/tests-dont-kill-people\/",
        "display_url" : "learningspy.co.uk\/assessment\/tes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "662043576210202624",
    "text" : "*NEW* Tests don't kill people https:\/\/t.co\/0YdNhbbKi0",
    "id" : 662043576210202624,
    "created_at" : "2015-11-04 23:07:43 +0000",
    "user" : {
      "name" : "David Didau",
      "screen_name" : "LearningSpy",
      "protected" : false,
      "id_str" : "146139473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615485265537290240\/ZLvXrX6N_normal.jpg",
      "id" : 146139473,
      "verified" : false
    }
  },
  "id" : 662050529883877378,
  "created_at" : "2015-11-04 23:35:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vooza",
      "screen_name" : "voozahq",
      "indices" : [ 66, 74 ],
      "id_str" : "524691753",
      "id" : 524691753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/KgH1lHidcL",
      "expanded_url" : "http:\/\/vooza.com\/videos\/honest-business-card-exchange\/",
      "display_url" : "vooza.com\/videos\/honest-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662049468402024448",
  "text" : "Honest Business Card Exchange (Vooza) https:\/\/t.co\/KgH1lHidcL via @VoozaHQ",
  "id" : 662049468402024448,
  "created_at" : "2015-11-04 23:31:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 0, 8 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662033197576921088",
  "in_reply_to_user_id" : 17874544,
  "text" : "@Support hi what happened to the go list shortcut? thx",
  "id" : 662033197576921088,
  "created_at" : "2015-11-04 22:26:28 +0000",
  "in_reply_to_screen_name" : "Support",
  "in_reply_to_user_id_str" : "17874544",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 13, 24 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 25, 32 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661970958631223297",
  "geo" : { },
  "id_str" : "662023841850531840",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @EAPstephen @SobejM good advice from Julie, this way any sts Qs a corpus can help with can be efficiently pulled into a class",
  "id" : 662023841850531840,
  "in_reply_to_status_id" : 661970958631223297,
  "created_at" : "2015-11-04 21:49:18 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661962254875820032",
  "geo" : { },
  "id_str" : "662022905782476800",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @SobejM Steve make sure to have a read of the Frankenberg-Garcia reference at end of Monika's post",
  "id" : 662022905782476800,
  "in_reply_to_status_id" : 661962254875820032,
  "created_at" : "2015-11-04 21:45:35 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/N0VvOH8y5B",
      "expanded_url" : "https:\/\/www.researchgate.net\/publication\/283182059_Writing_academic_English_further_along_the_road._What_is_happening_now_in_EAP_writing_instruction",
      "display_url" : "researchgate.net\/publication\/28\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662022011179409408",
  "text" : "RT @perezparedes: Writing academic English further along the road. What is happening now in EAP writing instruction? C. Tribble  https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/N0VvOH8y5B",
        "expanded_url" : "https:\/\/www.researchgate.net\/publication\/283182059_Writing_academic_English_further_along_the_road._What_is_happening_now_in_EAP_writing_instruction",
        "display_url" : "researchgate.net\/publication\/28\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661852959052079104",
    "text" : "Writing academic English further along the road. What is happening now in EAP writing instruction? C. Tribble  https:\/\/t.co\/N0VvOH8y5B",
    "id" : 661852959052079104,
    "created_at" : "2015-11-04 10:30:16 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 662022011179409408,
  "created_at" : "2015-11-04 21:42:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661939869082648576",
  "geo" : { },
  "id_str" : "661941951286132737",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @SobejM hi Steve good to hear you liked Monika's post; what kinds of things wld u say  overwhelm regarding corpora?",
  "id" : 661941951286132737,
  "in_reply_to_status_id" : 661939869082648576,
  "created_at" : "2015-11-04 16:23:54 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7hjOUa6Dje",
      "expanded_url" : "https:\/\/corpling.uis.georgetown.edu\/cqp\/",
      "display_url" : "corpling.uis.georgetown.edu\/cqp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "661937738413965312",
  "text" : "nice collection of corpora which includes open access ones in CQP and ANNIS interface versions #corpusresources https:\/\/t.co\/7hjOUa6Dje",
  "id" : 661937738413965312,
  "created_at" : "2015-11-04 16:07:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 128, 140 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/h8k4V9nwoP",
      "expanded_url" : "http:\/\/wp.me\/p1ZDGy-my",
      "display_url" : "wp.me\/p1ZDGy-my"
    } ]
  },
  "geo" : { },
  "id_str" : "661916664221577217",
  "text" : "Families, welfare benefits and economic migration: the case of London's early 20th century labour \u2026 https:\/\/t.co\/h8k4V9nwoP via @John__Field",
  "id" : 661916664221577217,
  "created_at" : "2015-11-04 14:43:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 55, 71 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/ajKJjHPQ6m",
      "expanded_url" : "http:\/\/wp.me\/p3V6GR-1Q",
      "display_url" : "wp.me\/p3V6GR-1Q"
    } ]
  },
  "geo" : { },
  "id_str" : "661910486980698113",
  "text" : "Absence of naming choices? https:\/\/t.co\/ajKJjHPQ6m via @wordpressdotcom",
  "id" : 661910486980698113,
  "created_at" : "2015-11-04 14:18:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 17, 29 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661680598109417473",
  "geo" : { },
  "id_str" : "661682304499245056",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @nathanghall if u have an android phone u cld try piratebox for android?",
  "id" : 661682304499245056,
  "in_reply_to_status_id" : 661680598109417473,
  "created_at" : "2015-11-03 23:12:09 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661676500937129984",
  "geo" : { },
  "id_str" : "661678313757401089",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall be interested in any developments you may take :)",
  "id" : 661678313757401089,
  "in_reply_to_status_id" : 661676500937129984,
  "created_at" : "2015-11-03 22:56:18 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 13, 29 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661675717965430784",
  "geo" : { },
  "id_str" : "661676287744974848",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @getgreatenglish neat any conclusions?",
  "id" : 661676287744974848,
  "in_reply_to_status_id" : 661675717965430784,
  "created_at" : "2015-11-03 22:48:15 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 13, 29 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661673765030395904",
  "geo" : { },
  "id_str" : "661675189722341376",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @getgreatenglish anon local networks are an option such as #piratebox",
  "id" : 661675189722341376,
  "in_reply_to_status_id" : 661673765030395904,
  "created_at" : "2015-11-03 22:43:53 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/m1nTrI0w9e",
      "expanded_url" : "http:\/\/lexicoblog.blogspot.fr\/2015\/11\/making-authentic-academic-texts.html",
      "display_url" : "lexicoblog.blogspot.fr\/2015\/11\/making\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661671026191896577",
  "text" : "Making authentic academic texts manageable https:\/\/t.co\/m1nTrI0w9e",
  "id" : 661671026191896577,
  "created_at" : "2015-11-03 22:27:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomson Reuters Fdn",
      "screen_name" : "TR_Foundation",
      "indices" : [ 118, 132 ],
      "id_str" : "295713773",
      "id" : 295713773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/GF5yP0Ej6G",
      "expanded_url" : "http:\/\/www.trust.org\/item\/20151102180455-56chg\/?source=shtw",
      "display_url" : "trust.org\/item\/201511021\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661663810596544512",
  "text" : "INTERVIEW-World ignores calls for inquiry into US bombing of Afghan hospital-charity head https:\/\/t.co\/GF5yP0Ej6G via @TR_Foundation",
  "id" : 661663810596544512,
  "created_at" : "2015-11-03 21:58:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 3, 13 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grammar",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "corpus",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/whEJbsyNO8",
      "expanded_url" : "http:\/\/www.cambridgeenglishteacher.org\/eventdetail\/2187\/introduction-english-grammar-profile",
      "display_url" : "cambridgeenglishteacher.org\/eventdetail\/21\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661660242065956864",
  "text" : "RT @TEFLclass: Free webinar tomorrow - An Introduction to the English Grammar Profile https:\/\/t.co\/whEJbsyNO8 #grammar #corpus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grammar",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "corpus",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/whEJbsyNO8",
        "expanded_url" : "http:\/\/www.cambridgeenglishteacher.org\/eventdetail\/2187\/introduction-english-grammar-profile",
        "display_url" : "cambridgeenglishteacher.org\/eventdetail\/21\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661650686313148416",
    "text" : "Free webinar tomorrow - An Introduction to the English Grammar Profile https:\/\/t.co\/whEJbsyNO8 #grammar #corpus",
    "id" : 661650686313148416,
    "created_at" : "2015-11-03 21:06:31 +0000",
    "user" : {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "protected" : false,
      "id_str" : "469244585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000353527279\/c15d358a877f62d20d0e180a1da73b4c_normal.jpeg",
      "id" : 469244585,
      "verified" : false
    }
  },
  "id" : 661660242065956864,
  "created_at" : "2015-11-03 21:44:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 3, 12 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/EsYNMY0Q3U",
      "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/QMXWD87",
      "display_url" : "surveymonkey.com\/r\/QMXWD87"
    } ]
  },
  "geo" : { },
  "id_str" : "661658071391973376",
  "text" : "RT @perayson: My UG student is interested in how people want to use twitter hash tag searches. Please complete if you have 5 mins: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/EsYNMY0Q3U",
        "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/QMXWD87",
        "display_url" : "surveymonkey.com\/r\/QMXWD87"
      } ]
    },
    "geo" : { },
    "id_str" : "661654654468648960",
    "text" : "My UG student is interested in how people want to use twitter hash tag searches. Please complete if you have 5 mins: https:\/\/t.co\/EsYNMY0Q3U",
    "id" : 661654654468648960,
    "created_at" : "2015-11-03 21:22:17 +0000",
    "user" : {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "protected" : false,
      "id_str" : "263108959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490485533911445505\/BNOoOchF_normal.jpeg",
      "id" : 263108959,
      "verified" : false
    }
  },
  "id" : 661658071391973376,
  "created_at" : "2015-11-03 21:35:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/661433187608997888\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/xCYISZhjxB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS3h-nOWoAAtiY3.jpg",
      "id_str" : "661433186090655744",
      "id" : 661433186090655744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS3h-nOWoAAtiY3.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xCYISZhjxB"
    } ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "esl",
      "indices" : [ 48, 52 ]
    }, {
      "text" : "tefl",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "efl",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "eap",
      "indices" : [ 64, 68 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "esol",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "teachenglish",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661444413848207360",
  "text" : "RT @taw_sig: TaWSIG Aims and Goals: Three. #elt #esl #tefl #efl #eap #iatefl #esol #teachenglish https:\/\/t.co\/xCYISZhjxB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/661433187608997888\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/xCYISZhjxB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS3h-nOWoAAtiY3.jpg",
        "id_str" : "661433186090655744",
        "id" : 661433186090655744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS3h-nOWoAAtiY3.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xCYISZhjxB"
      } ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 30, 34 ]
      }, {
        "text" : "esl",
        "indices" : [ 35, 39 ]
      }, {
        "text" : "tefl",
        "indices" : [ 40, 45 ]
      }, {
        "text" : "efl",
        "indices" : [ 46, 50 ]
      }, {
        "text" : "eap",
        "indices" : [ 51, 55 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "esol",
        "indices" : [ 64, 69 ]
      }, {
        "text" : "teachenglish",
        "indices" : [ 70, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661433187608997888",
    "text" : "TaWSIG Aims and Goals: Three. #elt #esl #tefl #efl #eap #iatefl #esol #teachenglish https:\/\/t.co\/xCYISZhjxB",
    "id" : 661433187608997888,
    "created_at" : "2015-11-03 06:42:15 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 661444413848207360,
  "created_at" : "2015-11-03 07:26:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661434896582230017",
  "geo" : { },
  "id_str" : "661441618453622784",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish that clip always raises a smile",
  "id" : 661441618453622784,
  "in_reply_to_status_id" : 661434896582230017,
  "created_at" : "2015-11-03 07:15:45 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/xGX0V4f8Gr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=QxcCC2g1Ke0",
      "display_url" : "youtube.com\/watch?v=QxcCC2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "661415245819211776",
  "geo" : { },
  "id_str" : "661433114066067456",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish that's right heavy lad : ) https:\/\/t.co\/xGX0V4f8Gr",
  "id" : 661433114066067456,
  "in_reply_to_status_id" : 661415245819211776,
  "created_at" : "2015-11-03 06:41:57 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 3, 14 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    }, {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 34, 47 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DeuQ7qNmt4",
      "expanded_url" : "https:\/\/medium.com\/@alxndghall\/things-i-ve-learned-from-making-my-first-corpus-fcbda2eca94b#.sju5vvj85",
      "display_url" : "medium.com\/@alxndghall\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661251869164072960",
  "text" : "RT @alxndghall: My first exp with @SketchEngine #corpusmooc | I just published \u201CThings I\u2019ve learned from making my first corpus\u201D https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sketch Engine",
        "screen_name" : "SketchEngine",
        "indices" : [ 18, 31 ],
        "id_str" : "841197134",
        "id" : 841197134
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 32, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/DeuQ7qNmt4",
        "expanded_url" : "https:\/\/medium.com\/@alxndghall\/things-i-ve-learned-from-making-my-first-corpus-fcbda2eca94b#.sju5vvj85",
        "display_url" : "medium.com\/@alxndghall\/th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661243937181573120",
    "text" : "My first exp with @SketchEngine #corpusmooc | I just published \u201CThings I\u2019ve learned from making my first corpus\u201D https:\/\/t.co\/DeuQ7qNmt4",
    "id" : 661243937181573120,
    "created_at" : "2015-11-02 18:10:14 +0000",
    "user" : {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "protected" : false,
      "id_str" : "1656929592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695730006287253504\/CVIxnOtE_normal.jpg",
      "id" : 1656929592,
      "verified" : false
    }
  },
  "id" : 661251869164072960,
  "created_at" : "2015-11-02 18:41:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 3, 15 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/patriciambr\/status\/661188568967180290\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/sYdxywGhQM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0Df_SXAAAGfVt.jpg",
      "id_str" : "661188568392597504",
      "id" : 661188568392597504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0Df_SXAAAGfVt.jpg",
      "sizes" : [ {
        "h" : 290,
        "resize" : "fit",
        "w" : 875
      }, {
        "h" : 113,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 875
      } ],
      "display_url" : "pic.twitter.com\/sYdxywGhQM"
    } ],
    "hashtags" : [ {
      "text" : "xl8",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "t9y",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/QFz1yurAGW",
      "expanded_url" : "http:\/\/bit.ly\/1klk7XD",
      "display_url" : "bit.ly\/1klk7XD"
    } ]
  },
  "geo" : { },
  "id_str" : "661247063783514112",
  "text" : "RT @patriciambr: Get to know (and use!) your English corpora: BNC, GloWbE, COCA, COHA and more! #xl8 #t9y https:\/\/t.co\/QFz1yurAGW https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/patriciambr\/status\/661188568967180290\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/sYdxywGhQM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0Df_SXAAAGfVt.jpg",
        "id_str" : "661188568392597504",
        "id" : 661188568392597504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0Df_SXAAAGfVt.jpg",
        "sizes" : [ {
          "h" : 290,
          "resize" : "fit",
          "w" : 875
        }, {
          "h" : 113,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 875
        } ],
        "display_url" : "pic.twitter.com\/sYdxywGhQM"
      } ],
      "hashtags" : [ {
        "text" : "xl8",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "t9y",
        "indices" : [ 84, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/QFz1yurAGW",
        "expanded_url" : "http:\/\/bit.ly\/1klk7XD",
        "display_url" : "bit.ly\/1klk7XD"
      } ]
    },
    "geo" : { },
    "id_str" : "661188568967180290",
    "text" : "Get to know (and use!) your English corpora: BNC, GloWbE, COCA, COHA and more! #xl8 #t9y https:\/\/t.co\/QFz1yurAGW https:\/\/t.co\/sYdxywGhQM",
    "id" : 661188568967180290,
    "created_at" : "2015-11-02 14:30:13 +0000",
    "user" : {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "protected" : false,
      "id_str" : "35764443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540310171541438464\/YprBqoGt_normal.jpeg",
      "id" : 35764443,
      "verified" : false
    }
  },
  "id" : 661247063783514112,
  "created_at" : "2015-11-02 18:22:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/E8sfHd0i4o",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/home-news\/britains-oldest-tree-the-fortingall-yew-is-undergoing-a-sex-change-a6717796.html",
      "display_url" : "independent.co.uk\/news\/uk\/home-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661186417683521536",
  "text" : "RT @pchallinor: Tree defies Germaine Greer https:\/\/t.co\/E8sfHd0i4o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/E8sfHd0i4o",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/home-news\/britains-oldest-tree-the-fortingall-yew-is-undergoing-a-sex-change-a6717796.html",
        "display_url" : "independent.co.uk\/news\/uk\/home-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661183349411725313",
    "text" : "Tree defies Germaine Greer https:\/\/t.co\/E8sfHd0i4o",
    "id" : 661183349411725313,
    "created_at" : "2015-11-02 14:09:29 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 661186417683521536,
  "created_at" : "2015-11-02 14:21:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    }, {
      "name" : "Viola Davis",
      "screen_name" : "violadavis",
      "indices" : [ 37, 48 ],
      "id_str" : "2717254872",
      "id" : 2717254872
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GoddessKerriLyn\/status\/661165869813383168\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/LHzLsIRfw9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSzu2uRWsAAhyt2.png",
      "id_str" : "661165869217787904",
      "id" : 661165869217787904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSzu2uRWsAAhyt2.png",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 459
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 459
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 459
      } ],
      "display_url" : "pic.twitter.com\/LHzLsIRfw9"
    } ],
    "hashtags" : [ {
      "text" : "Intersectional",
      "indices" : [ 69, 84 ]
    }, {
      "text" : "Feminism",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "WhiteFeminism",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/U1AfnB3DoK",
      "expanded_url" : "http:\/\/tiny.cc\/ueli5x",
      "display_url" : "tiny.cc\/ueli5x"
    } ]
  },
  "geo" : { },
  "id_str" : "661169286606647296",
  "text" : "RT @GoddessKerriLyn: The racist line @ViolaDavis spoke about\ndivides #Intersectional #Feminism &amp; #WhiteFeminism\u2122 \nhttps:\/\/t.co\/U1AfnB3DoK h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Viola Davis",
        "screen_name" : "violadavis",
        "indices" : [ 16, 27 ],
        "id_str" : "2717254872",
        "id" : 2717254872
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GoddessKerriLyn\/status\/661165869813383168\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/LHzLsIRfw9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSzu2uRWsAAhyt2.png",
        "id_str" : "661165869217787904",
        "id" : 661165869217787904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSzu2uRWsAAhyt2.png",
        "sizes" : [ {
          "h" : 284,
          "resize" : "fit",
          "w" : 459
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 459
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 459
        } ],
        "display_url" : "pic.twitter.com\/LHzLsIRfw9"
      } ],
      "hashtags" : [ {
        "text" : "Intersectional",
        "indices" : [ 48, 63 ]
      }, {
        "text" : "Feminism",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "WhiteFeminism",
        "indices" : [ 80, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/U1AfnB3DoK",
        "expanded_url" : "http:\/\/tiny.cc\/ueli5x",
        "display_url" : "tiny.cc\/ueli5x"
      } ]
    },
    "geo" : { },
    "id_str" : "661165869813383168",
    "text" : "The racist line @ViolaDavis spoke about\ndivides #Intersectional #Feminism &amp; #WhiteFeminism\u2122 \nhttps:\/\/t.co\/U1AfnB3DoK https:\/\/t.co\/LHzLsIRfw9",
    "id" : 661165869813383168,
    "created_at" : "2015-11-02 13:00:01 +0000",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747125522551844865\/sxnF-hUx_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 661169286606647296,
  "created_at" : "2015-11-02 13:13:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661012568920735744",
  "geo" : { },
  "id_str" : "661151320066433024",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites hi thx are have u used this in any projects?",
  "id" : 661151320066433024,
  "in_reply_to_status_id" : 661012568920735744,
  "created_at" : "2015-11-02 12:02:12 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Kx7VaIqRav",
      "expanded_url" : "http:\/\/bit.ly\/1MBzeJj",
      "display_url" : "bit.ly\/1MBzeJj"
    } ]
  },
  "geo" : { },
  "id_str" : "661145534103728128",
  "text" : "RT @RudyLoock: Revolution?\nEditors and editorial board quit top linguistics journal to protest subscription fees | Inside Higher Ed https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Kx7VaIqRav",
        "expanded_url" : "http:\/\/bit.ly\/1MBzeJj",
        "display_url" : "bit.ly\/1MBzeJj"
      } ]
    },
    "geo" : { },
    "id_str" : "661135396613586944",
    "text" : "Revolution?\nEditors and editorial board quit top linguistics journal to protest subscription fees | Inside Higher Ed https:\/\/t.co\/Kx7VaIqRav",
    "id" : 661135396613586944,
    "created_at" : "2015-11-02 10:58:56 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 661145534103728128,
  "created_at" : "2015-11-02 11:39:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 84, 95 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660819323771056129",
  "geo" : { },
  "id_str" : "660920713562451968",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd imp to ask what is complexity? E.g. acad text are highly compressed as  @JenMac_ESL was tweeting about Biber's findings",
  "id" : 660920713562451968,
  "in_reply_to_status_id" : 660819323771056129,
  "created_at" : "2015-11-01 20:45:52 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660911671398002688",
  "geo" : { },
  "id_str" : "660913296791465988",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d great will have a look thks",
  "id" : 660913296791465988,
  "in_reply_to_status_id" : 660911671398002688,
  "created_at" : "2015-11-01 20:16:23 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]