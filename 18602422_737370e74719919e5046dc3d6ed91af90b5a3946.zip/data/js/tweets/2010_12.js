Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15098061281824768",
  "text" : "Download+YouTube+Captions+-+http:\/\/userscripts.org\/50003 - useful Greasmonkey add-on for downloading already written captions",
  "id" : 15098061281824768,
  "created_at" : "2010-12-15 17:37:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Excellence",
      "screen_name" : "GExcellence",
      "indices" : [ 0, 12 ],
      "id_str" : "176417512",
      "id" : 176417512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14318469780602881",
  "in_reply_to_user_id" : 176417512,
  "text" : "@GExcellence Hi could you fix the download link for your document titled \"Cool Britannia or Boring Brits\", thanks!",
  "id" : 14318469780602881,
  "created_at" : "2010-12-13 13:59:23 +0000",
  "in_reply_to_screen_name" : "GExcellence",
  "in_reply_to_user_id_str" : "176417512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mademoiselle London",
      "screen_name" : "MsMlleLondon",
      "indices" : [ 0, 13 ],
      "id_str" : "148669656",
      "id" : 148669656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12821408811847680",
  "in_reply_to_user_id" : 148669656,
  "text" : "@MsMlleLondon - just read sample pages of your book - gobsmacked! as an English teacher here will be plundering your book for lessons!",
  "id" : 12821408811847680,
  "created_at" : "2010-12-09 10:50:36 +0000",
  "in_reply_to_screen_name" : "MsMlleLondon",
  "in_reply_to_user_id_str" : "148669656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]