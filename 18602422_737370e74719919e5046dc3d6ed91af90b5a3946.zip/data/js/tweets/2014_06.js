Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483661594296332289",
  "geo" : { },
  "id_str" : "483674589734912000",
  "in_reply_to_user_id" : 373715282,
  "text" : "@jorgesetteELT yr welcome nice slides and q's",
  "id" : 483674589734912000,
  "in_reply_to_status_id" : 483661594296332289,
  "created_at" : "2014-06-30 18:13:03 +0000",
  "in_reply_to_screen_name" : "jorgesette7",
  "in_reply_to_user_id_str" : "373715282",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MATISSE",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "teachingenglish",
      "indices" : [ 92, 108 ]
    }, {
      "text" : "art",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/fPBDvsSFUa",
      "expanded_url" : "http:\/\/wp.me\/p4gEKJ-uv",
      "display_url" : "wp.me\/p4gEKJ-uv"
    } ]
  },
  "geo" : { },
  "id_str" : "483654595429019648",
  "text" : "RT @jorgesetteELT: TEACHING ENGLISH WITH #MATISSE http:\/\/t.co\/fPBDvsSFUa via @jorgesetteELT #teachingenglish #art",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MATISSE",
        "indices" : [ 22, 30 ]
      }, {
        "text" : "teachingenglish",
        "indices" : [ 73, 89 ]
      }, {
        "text" : "art",
        "indices" : [ 90, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/fPBDvsSFUa",
        "expanded_url" : "http:\/\/wp.me\/p4gEKJ-uv",
        "display_url" : "wp.me\/p4gEKJ-uv"
      } ]
    },
    "geo" : { },
    "id_str" : "483653055104036864",
    "text" : "TEACHING ENGLISH WITH #MATISSE http:\/\/t.co\/fPBDvsSFUa via @jorgesetteELT #teachingenglish #art",
    "id" : 483653055104036864,
    "created_at" : "2014-06-30 16:47:28 +0000",
    "user" : {
      "name" : "Jorge Sette",
      "screen_name" : "jorgesette7",
      "protected" : false,
      "id_str" : "373715282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000310090773\/68ba02b1bfd98e4f32f49a5cb1eb9548_normal.jpeg",
      "id" : 373715282,
      "verified" : false
    }
  },
  "id" : 483654595429019648,
  "created_at" : "2014-06-30 16:53:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483594048880775169",
  "geo" : { },
  "id_str" : "483614263442161664",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco hehe don't forget a pre-forward plan? :) doh i forgot!",
  "id" : 483614263442161664,
  "in_reply_to_status_id" : 483594048880775169,
  "created_at" : "2014-06-30 14:13:20 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Meyer",
      "screen_name" : "superglaze",
      "indices" : [ 3, 14 ],
      "id_str" : "17310646",
      "id" : 17310646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/NZIUdONpeb",
      "expanded_url" : "http:\/\/gigaom.com\/2014\/06\/30\/the-dark-side-of-io-how-the-u-k-is-making-web-domain-profits-from-a-shady-cold-war-land-deal\/",
      "display_url" : "gigaom.com\/2014\/06\/30\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483612217599086592",
  "text" : "RT @superglaze: The dark side of .io: How the U.K. is making web domain profits from a shady Cold War land deal http:\/\/t.co\/NZIUdONpeb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/NZIUdONpeb",
        "expanded_url" : "http:\/\/gigaom.com\/2014\/06\/30\/the-dark-side-of-io-how-the-u-k-is-making-web-domain-profits-from-a-shady-cold-war-land-deal\/",
        "display_url" : "gigaom.com\/2014\/06\/30\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483580920080109568",
    "text" : "The dark side of .io: How the U.K. is making web domain profits from a shady Cold War land deal http:\/\/t.co\/NZIUdONpeb",
    "id" : 483580920080109568,
    "created_at" : "2014-06-30 12:00:50 +0000",
    "user" : {
      "name" : "David Meyer",
      "screen_name" : "superglaze",
      "protected" : false,
      "id_str" : "17310646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766644517260890112\/7NVYc9N-_normal.jpg",
      "id" : 17310646,
      "verified" : true
    }
  },
  "id" : 483612217599086592,
  "created_at" : "2014-06-30 14:05:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/fajX93ijXS",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/HF8hWXAUZfh",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483569300440367104",
  "text" : "#corpora Q for #corpuslinguistics folks on David Lodge novel Deaf Sentence https:\/\/t.co\/fajX93ijXS",
  "id" : 483569300440367104,
  "created_at" : "2014-06-30 11:14:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon Derczynski",
      "screen_name" : "LeonDerczynski",
      "indices" : [ 3, 18 ],
      "id_str" : "477030336",
      "id" : 477030336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nlproc",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "crowdsourcing",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Vl44Wx4jwd",
      "expanded_url" : "http:\/\/bit.ly\/1mcXCDn",
      "display_url" : "bit.ly\/1mcXCDn"
    } ]
  },
  "geo" : { },
  "id_str" : "483555517475086336",
  "text" : "RT @LeonDerczynski: Crowdsourcing for Corpus Annotation - best practice guidelines. Video talk @ http:\/\/t.co\/Vl44Wx4jwd #nlproc #crowdsourc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nlproc",
        "indices" : [ 100, 107 ]
      }, {
        "text" : "crowdsourcing",
        "indices" : [ 108, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/Vl44Wx4jwd",
        "expanded_url" : "http:\/\/bit.ly\/1mcXCDn",
        "display_url" : "bit.ly\/1mcXCDn"
      } ]
    },
    "geo" : { },
    "id_str" : "483543506586451968",
    "text" : "Crowdsourcing for Corpus Annotation - best practice guidelines. Video talk @ http:\/\/t.co\/Vl44Wx4jwd #nlproc #crowdsourcing",
    "id" : 483543506586451968,
    "created_at" : "2014-06-30 09:32:10 +0000",
    "user" : {
      "name" : "Leon Derczynski",
      "screen_name" : "LeonDerczynski",
      "protected" : false,
      "id_str" : "477030336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720702305356668929\/gasOCK-W_normal.jpg",
      "id" : 477030336,
      "verified" : false
    }
  },
  "id" : 483555517475086336,
  "created_at" : "2014-06-30 10:19:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/u9PdQq3CxR",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1403979658.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483493665969811458",
  "text" : "Join my personal World Cup http:\/\/t.co\/u9PdQq3CxR",
  "id" : 483493665969811458,
  "created_at" : "2014-06-30 06:14:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 80, 96 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/GEB6IoKSvN",
      "expanded_url" : "http:\/\/wp.me\/p1mEF-35c",
      "display_url" : "wp.me\/p1mEF-35c"
    } ]
  },
  "geo" : { },
  "id_str" : "483319134432686080",
  "text" : "It's Not a Watch, It's an Electronic Monitoring Tag: http:\/\/t.co\/GEB6IoKSvN via @wordpressdotcom",
  "id" : 483319134432686080,
  "created_at" : "2014-06-29 18:40:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 57, 71 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QAA2014",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "cetis14",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/YLADLL6zUd",
      "expanded_url" : "http:\/\/youtu.be\/Vo2Q06Cczkk",
      "display_url" : "youtu.be\/Vo2Q06Cczkk"
    } ]
  },
  "geo" : { },
  "id_str" : "482607394191843328",
  "text" : "RT @dkernohan: And #QAA2014 extra credit on MOOCs. Watch @audreywatters at #cetis14 http:\/\/t.co\/YLADLL6zUd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 42, 56 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "QAA2014",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "cetis14",
        "indices" : [ 60, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/YLADLL6zUd",
        "expanded_url" : "http:\/\/youtu.be\/Vo2Q06Cczkk",
        "display_url" : "youtu.be\/Vo2Q06Cczkk"
      } ]
    },
    "geo" : { },
    "id_str" : "482128795101851648",
    "text" : "And #QAA2014 extra credit on MOOCs. Watch @audreywatters at #cetis14 http:\/\/t.co\/YLADLL6zUd",
    "id" : 482128795101851648,
    "created_at" : "2014-06-26 11:50:36 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 482607394191843328,
  "created_at" : "2014-06-27 19:32:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5PVHbROkmH",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/27\/neovictorian-computing-and-the-cult-of-the-lowest-common-denominator\/",
      "display_url" : "hapgood.us\/2014\/06\/27\/neo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482592648294047745",
  "text" : "RT @holden: New Post: NeoVictorian Computing, and the Cult of the Lowest Common Denominator: http:\/\/t.co\/5PVHbROkmH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/5PVHbROkmH",
        "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/27\/neovictorian-computing-and-the-cult-of-the-lowest-common-denominator\/",
        "display_url" : "hapgood.us\/2014\/06\/27\/neo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482590610025500672",
    "text" : "New Post: NeoVictorian Computing, and the Cult of the Lowest Common Denominator: http:\/\/t.co\/5PVHbROkmH",
    "id" : 482590610025500672,
    "created_at" : "2014-06-27 18:25:42 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 482592648294047745,
  "created_at" : "2014-06-27 18:33:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 40, 56 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/0YgVr7ntxK",
      "expanded_url" : "http:\/\/wp.me\/p1Mobn-tb",
      "display_url" : "wp.me\/p1Mobn-tb"
    } ]
  },
  "geo" : { },
  "id_str" : "482565816001368064",
  "text" : "pictogrammar http:\/\/t.co\/0YgVr7ntxK via @wordpressdotcom",
  "id" : 482565816001368064,
  "created_at" : "2014-06-27 16:47:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "indices" : [ 3, 10 ],
      "id_str" : "724473",
      "id" : 724473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/BsqIANF5EA",
      "expanded_url" : "http:\/\/www.labnol.org\/internet\/31-premium-android-apps-available-for-free-on-amazon\/28559\/",
      "display_url" : "labnol.org\/internet\/31-pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482480355329703936",
  "text" : "RT @labnol: 31 Premium Android Apps Available for Free on Amazon http:\/\/t.co\/BsqIANF5EA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/BsqIANF5EA",
        "expanded_url" : "http:\/\/www.labnol.org\/internet\/31-premium-android-apps-available-for-free-on-amazon\/28559\/",
        "display_url" : "labnol.org\/internet\/31-pr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482458337716736000",
    "text" : "31 Premium Android Apps Available for Free on Amazon http:\/\/t.co\/BsqIANF5EA",
    "id" : 482458337716736000,
    "created_at" : "2014-06-27 09:40:06 +0000",
    "user" : {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "protected" : false,
      "id_str" : "724473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641572075321229312\/3f_9iwzr_normal.jpg",
      "id" : 724473,
      "verified" : true
    }
  },
  "id" : 482480355329703936,
  "created_at" : "2014-06-27 11:07:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/XLm5i9noeu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=DkkZ77lnuas",
      "display_url" : "youtube.com\/watch?v=DkkZ77\u2026"
    }, {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/xrGGFXg3yw",
      "expanded_url" : "http:\/\/allthingslinguistic.com",
      "display_url" : "allthingslinguistic.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482416086999371776",
  "text" : "Why nobody ever taught you how to write good https:\/\/t.co\/XLm5i9noeu h\/t http:\/\/t.co\/xrGGFXg3yw",
  "id" : 482416086999371776,
  "created_at" : "2014-06-27 06:52:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 16, 22 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482062922256879617",
  "geo" : { },
  "id_str" : "482064856540266496",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @ebefl the etp article minus the woo talk is interesting so why add it? Word counts? :)",
  "id" : 482064856540266496,
  "in_reply_to_status_id" : 482062922256879617,
  "created_at" : "2014-06-26 07:36:32 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 77, 83 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/AA7ePTSUll",
      "expanded_url" : "http:\/\/malingual.blogspot.com\/2014\/06\/woo-watch.html?spref=tw",
      "display_url" : "malingual.blogspot.com\/2014\/06\/woo-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482064197933883392",
  "text" : "RT @DavidHarbinson: Evidence Based EFL: Woo watch http:\/\/t.co\/AA7ePTSUll via @ebefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 57, 63 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/AA7ePTSUll",
        "expanded_url" : "http:\/\/malingual.blogspot.com\/2014\/06\/woo-watch.html?spref=tw",
        "display_url" : "malingual.blogspot.com\/2014\/06\/woo-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482062922256879617",
    "text" : "Evidence Based EFL: Woo watch http:\/\/t.co\/AA7ePTSUll via @ebefl",
    "id" : 482062922256879617,
    "created_at" : "2014-06-26 07:28:51 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 482064197933883392,
  "created_at" : "2014-06-26 07:33:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CAMELOT",
      "screen_name" : "camelotprojeu",
      "indices" : [ 3, 17 ],
      "id_str" : "2394388639",
      "id" : 2394388639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/0qomowJQ3S",
      "expanded_url" : "http:\/\/camelotproject.eu\/rod-ellis\/",
      "display_url" : "camelotproject.eu\/rod-ellis\/"
    } ]
  },
  "geo" : { },
  "id_str" : "481919307371511808",
  "text" : "RT @camelotprojeu: http:\/\/t.co\/0qomowJQ3S  Rod Ellis: Methodology in Task-Based Language Teaching slides and recording - NB change of url",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/0qomowJQ3S",
        "expanded_url" : "http:\/\/camelotproject.eu\/rod-ellis\/",
        "display_url" : "camelotproject.eu\/rod-ellis\/"
      } ]
    },
    "geo" : { },
    "id_str" : "481914339583348736",
    "text" : "http:\/\/t.co\/0qomowJQ3S  Rod Ellis: Methodology in Task-Based Language Teaching slides and recording - NB change of url",
    "id" : 481914339583348736,
    "created_at" : "2014-06-25 21:38:26 +0000",
    "user" : {
      "name" : "CAMELOT",
      "screen_name" : "camelotprojeu",
      "protected" : false,
      "id_str" : "2394388639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445571101314146304\/yXt94Jws_normal.jpeg",
      "id" : 2394388639,
      "verified" : false
    }
  },
  "id" : 481919307371511808,
  "created_at" : "2014-06-25 21:58:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 86, 102 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/MPFaBnATOE",
      "expanded_url" : "http:\/\/wp.me\/p4lNv-p4",
      "display_url" : "wp.me\/p4lNv-p4"
    } ]
  },
  "geo" : { },
  "id_str" : "481916744328417280",
  "text" : "Higher Education, Technology, and the Corporate University http:\/\/t.co\/MPFaBnATOE via @wordpressdotcom",
  "id" : 481916744328417280,
  "created_at" : "2014-06-25 21:48:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    }, {
      "name" : "UK Uncut",
      "screen_name" : "UKuncut",
      "indices" : [ 139, 140 ],
      "id_str" : "208058457",
      "id" : 208058457
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bigpatmcaleenan\/status\/481492759975849984\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/rqA48uCwz0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6bHLZIAAAyjHv.jpg",
      "id_str" : "481492757794783232",
      "id" : 481492757794783232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6bHLZIAAAyjHv.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/rqA48uCwz0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481878769943474176",
  "text" : "RT @aral: Life, according to BBC:\n\nOne rich baby walking = news.\n\n50,000 impoverished adults walking = not news.\n\nhttps:\/\/t.co\/rqA48uCwz0\n\n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UK Uncut",
        "screen_name" : "UKuncut",
        "indices" : [ 132, 140 ],
        "id_str" : "208058457",
        "id" : 208058457
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bigpatmcaleenan\/status\/481492759975849984\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/rqA48uCwz0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6bHLZIAAAyjHv.jpg",
        "id_str" : "481492757794783232",
        "id" : 481492757794783232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6bHLZIAAAyjHv.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/rqA48uCwz0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481783392753971200",
    "text" : "Life, according to BBC:\n\nOne rich baby walking = news.\n\n50,000 impoverished adults walking = not news.\n\nhttps:\/\/t.co\/rqA48uCwz0\n\nHt @UKuncut",
    "id" : 481783392753971200,
    "created_at" : "2014-06-25 12:58:06 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 481878769943474176,
  "created_at" : "2014-06-25 19:17:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/mwAuFXa3M0",
      "expanded_url" : "http:\/\/www.willardswormholes.com\/?p=24449",
      "display_url" : "willardswormholes.com\/?p=24449"
    } ]
  },
  "geo" : { },
  "id_str" : "481866333391691776",
  "text" : "RT @cogdog: Freaking brilliant: Zeppelin Took My Blues Away (Copyright Infringement Trading Cards?) http:\/\/t.co\/mwAuFXa3M0 compare songs si\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/mwAuFXa3M0",
        "expanded_url" : "http:\/\/www.willardswormholes.com\/?p=24449",
        "display_url" : "willardswormholes.com\/?p=24449"
      } ]
    },
    "geo" : { },
    "id_str" : "481838886172123137",
    "text" : "Freaking brilliant: Zeppelin Took My Blues Away (Copyright Infringement Trading Cards?) http:\/\/t.co\/mwAuFXa3M0 compare songs side by side",
    "id" : 481838886172123137,
    "created_at" : "2014-06-25 16:38:37 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 481866333391691776,
  "created_at" : "2014-06-25 18:27:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian H\u00F6ferle",
      "screen_name" : "Hoeferle",
      "indices" : [ 3, 12 ],
      "id_str" : "23107822",
      "id" : 23107822
    }, {
      "name" : "Tom Gara",
      "screen_name" : "tomgara",
      "indices" : [ 139, 140 ],
      "id_str" : "5845492",
      "id" : 5845492
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dkberman\/status\/481814184347578368\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/uh14am5nnz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq-_cocIcAAdZMb.png",
      "id_str" : "481814183764586496",
      "id" : 481814183764586496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq-_cocIcAAdZMb.png",
      "sizes" : [ {
        "h" : 503,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/uh14am5nnz"
    } ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/vQgZcVfOzA",
      "expanded_url" : "http:\/\/online.wsj.com\/articles\/the-world-rankings-of-flopping-1403660175",
      "display_url" : "online.wsj.com\/articles\/the-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481827317548089344",
  "text" : "RT @Hoeferle: WSJ measured the time #WorldCup teams spend writhing on the ground in fake agony http:\/\/t.co\/vQgZcVfOzA http:\/\/t.co\/uh14am5nn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Gara",
        "screen_name" : "tomgara",
        "indices" : [ 131, 139 ],
        "id_str" : "5845492",
        "id" : 5845492
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dkberman\/status\/481814184347578368\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/uh14am5nnz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq-_cocIcAAdZMb.png",
        "id_str" : "481814183764586496",
        "id" : 481814183764586496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq-_cocIcAAdZMb.png",
        "sizes" : [ {
          "h" : 503,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/uh14am5nnz"
      } ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 22, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/vQgZcVfOzA",
        "expanded_url" : "http:\/\/online.wsj.com\/articles\/the-world-rankings-of-flopping-1403660175",
        "display_url" : "online.wsj.com\/articles\/the-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481818140909654017",
    "text" : "WSJ measured the time #WorldCup teams spend writhing on the ground in fake agony http:\/\/t.co\/vQgZcVfOzA http:\/\/t.co\/uh14am5nnz via @tomgara",
    "id" : 481818140909654017,
    "created_at" : "2014-06-25 15:16:11 +0000",
    "user" : {
      "name" : "Christian H\u00F6ferle",
      "screen_name" : "Hoeferle",
      "protected" : false,
      "id_str" : "23107822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749385180528336896\/OuZgXT-n_normal.jpg",
      "id" : 23107822,
      "verified" : false
    }
  },
  "id" : 481827317548089344,
  "created_at" : "2014-06-25 15:52:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481752377565782016",
  "geo" : { },
  "id_str" : "481825918974189568",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin a colleague vaguely recalled a nightmare involving the bare feet of a well known BizEng video teacher :0",
  "id" : 481825918974189568,
  "in_reply_to_status_id" : 481752377565782016,
  "created_at" : "2014-06-25 15:47:05 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Zf4GXVlTRC",
      "expanded_url" : "http:\/\/bit.ly\/UIMgvg",
      "display_url" : "bit.ly\/UIMgvg"
    } ]
  },
  "geo" : { },
  "id_str" : "481749856630091776",
  "text" : "RT @CraigMurrayOrg: Stinking Hypocrisy: 183 Egyptian political prisoners sentenced to death: international silence. One Australian... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Zf4GXVlTRC",
        "expanded_url" : "http:\/\/bit.ly\/UIMgvg",
        "display_url" : "bit.ly\/UIMgvg"
      } ]
    },
    "geo" : { },
    "id_str" : "481742228490973184",
    "text" : "Stinking Hypocrisy: 183 Egyptian political prisoners sentenced to death: international silence. One Australian... http:\/\/t.co\/Zf4GXVlTRC",
    "id" : 481742228490973184,
    "created_at" : "2014-06-25 10:14:32 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 481749856630091776,
  "created_at" : "2014-06-25 10:44:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/481493233089142784\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/byom6MN9jA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6bi1KIMAAROJI.jpg",
      "id_str" : "481493232862638080",
      "id" : 481493232862638080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6bi1KIMAAROJI.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/byom6MN9jA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/twqpYOeLw5",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/23\/aided-by-books-and-ex-pats-ja.html",
      "display_url" : "boingboing.net\/2014\/06\/23\/aid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481495592997498880",
  "text" : "RT @BoingBoing: With this awesome book, Japanese speakers learn how to swear like an American. Video: ROFL. http:\/\/t.co\/twqpYOeLw5 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/481493233089142784\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/byom6MN9jA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6bi1KIMAAROJI.jpg",
        "id_str" : "481493232862638080",
        "id" : 481493232862638080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6bi1KIMAAROJI.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/byom6MN9jA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/twqpYOeLw5",
        "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/23\/aided-by-books-and-ex-pats-ja.html",
        "display_url" : "boingboing.net\/2014\/06\/23\/aid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481493233089142784",
    "text" : "With this awesome book, Japanese speakers learn how to swear like an American. Video: ROFL. http:\/\/t.co\/twqpYOeLw5 http:\/\/t.co\/byom6MN9jA",
    "id" : 481493233089142784,
    "created_at" : "2014-06-24 17:45:07 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 481495592997498880,
  "created_at" : "2014-06-24 17:54:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "wordnik",
      "screen_name" : "wordnik",
      "indices" : [ 21, 29 ],
      "id_str" : "15863767",
      "id" : 15863767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/pcT5anQ9ac",
      "expanded_url" : "http:\/\/www.theatlantic.com\/entertainment\/archive\/2014\/06\/a-linguist-on-why-redskin-is-racist-patent-overturned\/373198\/",
      "display_url" : "theatlantic.com\/entertainment\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481388958988140544",
  "text" : "RT @TSchnoebelen: RT @wordnik: When Slang Becomes a Slur - Geoffrey Nunberg - The Atlantic http:\/\/t.co\/pcT5anQ9ac",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "wordnik",
        "screen_name" : "wordnik",
        "indices" : [ 3, 11 ],
        "id_str" : "15863767",
        "id" : 15863767
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/pcT5anQ9ac",
        "expanded_url" : "http:\/\/www.theatlantic.com\/entertainment\/archive\/2014\/06\/a-linguist-on-why-redskin-is-racist-patent-overturned\/373198\/",
        "display_url" : "theatlantic.com\/entertainment\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481256692554813443",
    "text" : "RT @wordnik: When Slang Becomes a Slur - Geoffrey Nunberg - The Atlantic http:\/\/t.co\/pcT5anQ9ac",
    "id" : 481256692554813443,
    "created_at" : "2014-06-24 02:05:11 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 481388958988140544,
  "created_at" : "2014-06-24 10:50:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 0, 7 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 8, 24 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 25, 37 ],
      "id_str" : "20425399",
      "id" : 20425399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/9r9VRhIKVF",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Humble_Bundle",
      "display_url" : "en.wikipedia.org\/wiki\/Humble_Bu\u2026"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3K6J3gZBuB",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/List_of_Humble_Bundles",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_H\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "481353586564415488",
  "geo" : { },
  "id_str" : "481363058364022784",
  "in_reply_to_user_id" : 1356363686,
  "text" : "@eltjam @michaelegriffin @nmkrobinson something like humble bundles could be an option? http:\/\/t.co\/9r9VRhIKVF sales http:\/\/t.co\/3K6J3gZBuB",
  "id" : 481363058364022784,
  "in_reply_to_status_id" : 481353586564415488,
  "created_at" : "2014-06-24 09:07:51 +0000",
  "in_reply_to_screen_name" : "eltjam",
  "in_reply_to_user_id_str" : "1356363686",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Dan Meyer",
      "screen_name" : "ddmeyer",
      "indices" : [ 98, 106 ],
      "id_str" : "7198542",
      "id" : 7198542
    }, {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 107, 120 ],
      "id_str" : "10187072",
      "id" : 10187072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/bxJPAyot81",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/23\/why-personalized-learning-fails\/",
      "display_url" : "hapgood.us\/2014\/06\/23\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481185568760799232",
  "text" : "RT @holden: modestly titled new post \"Why Personalized Learning Fails\" http:\/\/t.co\/bxJPAyot81 cc: @ddmeyer @mfeldstein67",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Meyer",
        "screen_name" : "ddmeyer",
        "indices" : [ 86, 94 ],
        "id_str" : "7198542",
        "id" : 7198542
      }, {
        "name" : "Michael Feldstein",
        "screen_name" : "mfeldstein67",
        "indices" : [ 95, 108 ],
        "id_str" : "10187072",
        "id" : 10187072
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/bxJPAyot81",
        "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/23\/why-personalized-learning-fails\/",
        "display_url" : "hapgood.us\/2014\/06\/23\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481160731639832576",
    "text" : "modestly titled new post \"Why Personalized Learning Fails\" http:\/\/t.co\/bxJPAyot81 cc: @ddmeyer @mfeldstein67",
    "id" : 481160731639832576,
    "created_at" : "2014-06-23 19:43:52 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 481185568760799232,
  "created_at" : "2014-06-23 21:22:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Israel",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "Palestine",
      "indices" : [ 127, 137 ]
    }, {
      "text" : "BDS",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/v4mtGfmyOO",
      "expanded_url" : "http:\/\/shar.es\/MgRFD",
      "display_url" : "shar.es\/MgRFD"
    } ]
  },
  "geo" : { },
  "id_str" : "481113039501279232",
  "text" : "RT @Jonathan_K_Cook: My latest: You can\u2019t force-feed occupation to those who hunger for freedom http:\/\/t.co\/v4mtGfmyOO #Israel #Palestine #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Israel",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "Palestine",
        "indices" : [ 106, 116 ]
      }, {
        "text" : "BDS",
        "indices" : [ 117, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/v4mtGfmyOO",
        "expanded_url" : "http:\/\/shar.es\/MgRFD",
        "display_url" : "shar.es\/MgRFD"
      } ]
    },
    "geo" : { },
    "id_str" : "481100308005650433",
    "text" : "My latest: You can\u2019t force-feed occupation to those who hunger for freedom http:\/\/t.co\/v4mtGfmyOO #Israel #Palestine #BDS",
    "id" : 481100308005650433,
    "created_at" : "2014-06-23 15:43:46 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 481113039501279232,
  "created_at" : "2014-06-23 16:34:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerald Morgan",
      "screen_name" : "hsnewsbreak",
      "indices" : [ 69, 81 ],
      "id_str" : "4264515735",
      "id" : 4264515735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/zBW1fR5ItX",
      "expanded_url" : "http:\/\/www.heraldscotland.com\/comment\/columnists\/the-trial-of-tony-blair.24526819",
      "display_url" : "heraldscotland.com\/comment\/column\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481000233573171200",
  "text" : "The trial of Tony Blair | Herald Scotland http:\/\/t.co\/zBW1fR5ItX via @hsnewsbreak",
  "id" : 481000233573171200,
  "created_at" : "2014-06-23 09:06:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/zkbDPyCCvl",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2014\/06\/teacher-i-have-question.html",
      "display_url" : "giaklamata.blogspot.fr\/2014\/06\/teache\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480677485752111104",
  "text" : "Teacher, I have question http:\/\/t.co\/zkbDPyCCvl",
  "id" : 480677485752111104,
  "created_at" : "2014-06-22 11:43:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/h4LdQVLP66",
      "expanded_url" : "http:\/\/worrydream.com\/quotes\/",
      "display_url" : "worrydream.com\/quotes\/"
    } ]
  },
  "in_reply_to_status_id_str" : "480340485165162496",
  "geo" : { },
  "id_str" : "480349312082542592",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson no quotes but suggestion to make RSS feed of quotes page &amp; here's a neat quotes example http:\/\/t.co\/h4LdQVLP66",
  "id" : 480349312082542592,
  "in_reply_to_status_id" : 480340485165162496,
  "created_at" : "2014-06-21 13:59:35 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Causey \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDE80",
      "screen_name" : "treycausey",
      "indices" : [ 0, 11 ],
      "id_str" : "237254045",
      "id" : 237254045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/MVwlHl0UTU",
      "expanded_url" : "http:\/\/levan.cs.washington.edu\/?state=fetchNGrams&concept=teacher",
      "display_url" : "levan.cs.washington.edu\/?state=fetchNG\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "480337764592779266",
  "geo" : { },
  "id_str" : "480346532244639744",
  "in_reply_to_user_id" : 237254045,
  "text" : "@treycausey hmm for teacher first concept is teacher arrested! http:\/\/t.co\/MVwlHl0UTU",
  "id" : 480346532244639744,
  "in_reply_to_status_id" : 480337764592779266,
  "created_at" : "2014-06-21 13:48:32 +0000",
  "in_reply_to_screen_name" : "treycausey",
  "in_reply_to_user_id_str" : "237254045",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Ruth Reichard",
      "screen_name" : "BellaReichard",
      "indices" : [ 0, 14 ],
      "id_str" : "856094984",
      "id" : 856094984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/C5OEvVF31d",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "480244008154058753",
  "geo" : { },
  "id_str" : "480293427339608064",
  "in_reply_to_user_id" : 856094984,
  "text" : "@BellaReichard hi there do consider G+ CL comm https:\/\/t.co\/C5OEvVF31d have a grt conference :)",
  "id" : 480293427339608064,
  "in_reply_to_status_id" : 480244008154058753,
  "created_at" : "2014-06-21 10:17:31 +0000",
  "in_reply_to_screen_name" : "BellaReichard",
  "in_reply_to_user_id_str" : "856094984",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Ruth Reichard",
      "screen_name" : "BellaReichard",
      "indices" : [ 3, 17 ],
      "id_str" : "856094984",
      "id" : 856094984
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baleapcov",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "tleap",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/JK3VL2zeOh",
      "expanded_url" : "https:\/\/www.academia.edu\/7361130\/Concordance_tools_for_international_business_students_-_why_and_how",
      "display_url" : "academia.edu\/7361130\/Concor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480289915436298240",
  "text" : "RT @BellaReichard: #baleapcov #tleap why 1st yr students need to learn concordancing https:\/\/t.co\/JK3VL2zeOh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "baleapcov",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "tleap",
        "indices" : [ 11, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/JK3VL2zeOh",
        "expanded_url" : "https:\/\/www.academia.edu\/7361130\/Concordance_tools_for_international_business_students_-_why_and_how",
        "display_url" : "academia.edu\/7361130\/Concor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480244008154058753",
    "text" : "#baleapcov #tleap why 1st yr students need to learn concordancing https:\/\/t.co\/JK3VL2zeOh",
    "id" : 480244008154058753,
    "created_at" : "2014-06-21 07:01:08 +0000",
    "user" : {
      "name" : "Bella Ruth Reichard",
      "screen_name" : "BellaReichard",
      "protected" : false,
      "id_str" : "856094984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2896070713\/c2155b23702dc2e30f4ea54a69a4b7af_normal.jpeg",
      "id" : 856094984,
      "verified" : false
    }
  },
  "id" : 480289915436298240,
  "created_at" : "2014-06-21 10:03:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PBRu2fL8fc",
      "expanded_url" : "http:\/\/bit.ly\/1nqGcjg",
      "display_url" : "bit.ly\/1nqGcjg"
    } ]
  },
  "geo" : { },
  "id_str" : "480249177541464064",
  "text" : "RT @tornhalves: Our post on discrimination in #ELT TEFL and its links with globalization. A new motto: \"Think global, speak local\" http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 30, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/PBRu2fL8fc",
        "expanded_url" : "http:\/\/bit.ly\/1nqGcjg",
        "display_url" : "bit.ly\/1nqGcjg"
      } ]
    },
    "geo" : { },
    "id_str" : "480224323182264320",
    "text" : "Our post on discrimination in #ELT TEFL and its links with globalization. A new motto: \"Think global, speak local\" http:\/\/t.co\/PBRu2fL8fc",
    "id" : 480224323182264320,
    "created_at" : "2014-06-21 05:42:55 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 480249177541464064,
  "created_at" : "2014-06-21 07:21:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaleapCov",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "oerrh",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "oer",
      "indices" : [ 126, 130 ]
    }, {
      "text" : "tleap",
      "indices" : [ 131, 137 ]
    }, {
      "text" : "openaccess",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Exr90ltI4T",
      "expanded_url" : "http:\/\/lnkd.in\/datQyeY",
      "display_url" : "lnkd.in\/datQyeY"
    } ]
  },
  "geo" : { },
  "id_str" : "480247214699458560",
  "text" : "RT @AlannahFitz: Sharing an Open Methodology 4 Building Domain-Specific Corpora 4EAP http:\/\/t.co\/Exr90ltI4T #BaleapCov #oerrh #oer #tleap #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BaleapCov",
        "indices" : [ 91, 101 ]
      }, {
        "text" : "oerrh",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "oer",
        "indices" : [ 109, 113 ]
      }, {
        "text" : "tleap",
        "indices" : [ 114, 120 ]
      }, {
        "text" : "openaccess",
        "indices" : [ 121, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/Exr90ltI4T",
        "expanded_url" : "http:\/\/lnkd.in\/datQyeY",
        "display_url" : "lnkd.in\/datQyeY"
      } ]
    },
    "geo" : { },
    "id_str" : "480241829862850560",
    "text" : "Sharing an Open Methodology 4 Building Domain-Specific Corpora 4EAP http:\/\/t.co\/Exr90ltI4T #BaleapCov #oerrh #oer #tleap #openaccess",
    "id" : 480241829862850560,
    "created_at" : "2014-06-21 06:52:29 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 480247214699458560,
  "created_at" : "2014-06-21 07:13:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stringnet",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/DxrVG0hCyU",
      "expanded_url" : "http:\/\/www.lexchecker.org",
      "display_url" : "lexchecker.org"
    } ]
  },
  "in_reply_to_status_id_str" : "480243369265082368",
  "geo" : { },
  "id_str" : "480247165449936896",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall have you tried the synonym feature in #stringnet? http:\/\/t.co\/DxrVG0hCyU pretty sweet :)",
  "id" : 480247165449936896,
  "in_reply_to_status_id" : 480243369265082368,
  "created_at" : "2014-06-21 07:13:41 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 3, 18 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facebook",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/OLgJNiB4hj",
      "expanded_url" : "http:\/\/instagram.com\/p\/perFYtKKpe\/",
      "display_url" : "instagram.com\/p\/perFYtKKpe\/"
    } ]
  },
  "geo" : { },
  "id_str" : "480087005641314304",
  "text" : "RT @4tunetellernet: You are seeing that correctly. This photo has not been altered. This place exists. faceboof #facebook\u2026 http:\/\/t.co\/OLgJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "facebook",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/OLgJNiB4hj",
        "expanded_url" : "http:\/\/instagram.com\/p\/perFYtKKpe\/",
        "display_url" : "instagram.com\/p\/perFYtKKpe\/"
      } ]
    },
    "geo" : { },
    "id_str" : "480084649075421184",
    "text" : "You are seeing that correctly. This photo has not been altered. This place exists. faceboof #facebook\u2026 http:\/\/t.co\/OLgJNiB4hj",
    "id" : 480084649075421184,
    "created_at" : "2014-06-20 20:27:54 +0000",
    "user" : {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "protected" : false,
      "id_str" : "467634146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638018712629592065\/i8nHx3y0_normal.png",
      "id" : 467634146,
      "verified" : false
    }
  },
  "id" : 480087005641314304,
  "created_at" : "2014-06-20 20:37:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/480055335395536896\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/zv5acq6vvw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bql_yGbCEAAx0WX.png",
      "id_str" : "480055333985849344",
      "id" : 480055333985849344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bql_yGbCEAAx0WX.png",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 1127
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 73,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zv5acq6vvw"
    } ],
    "hashtags" : [ {
      "text" : "whatnext",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480055335395536896",
  "text" : "unexpected parental playlist1 #whatnext :0 http:\/\/t.co\/zv5acq6vvw",
  "id" : 480055335395536896,
  "created_at" : "2014-06-20 18:31:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 0, 8 ],
      "id_str" : "279078759",
      "id" : 279078759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480009372316495872",
  "in_reply_to_user_id" : 279078759,
  "text" : "@LahiffP thks for RT G+ comm :)",
  "id" : 480009372316495872,
  "created_at" : "2014-06-20 15:28:47 +0000",
  "in_reply_to_screen_name" : "LahiffP",
  "in_reply_to_user_id_str" : "279078759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 3, 19 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 53, 64 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 66, 75 ],
      "id_str" : "238993337",
      "id" : 238993337
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 77, 87 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 89, 98 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 105, 117 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sG8imncAPi",
      "expanded_url" : "http:\/\/ow.ly\/ygc9L",
      "display_url" : "ow.ly\/ygc9L"
    } ]
  },
  "geo" : { },
  "id_str" : "480008769603387394",
  "text" : "RT @theteacherjames: New #ELTchat podcast! Featuring @kevchanwow, @bealer81, @adi_rajan, @MuraNava &amp; @NewbieCELTA http:\/\/t.co\/sG8imncAPi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 32, 43 ],
        "id_str" : "144663117",
        "id" : 144663117
      }, {
        "name" : "Adam Beale",
        "screen_name" : "bealer81",
        "indices" : [ 45, 54 ],
        "id_str" : "238993337",
        "id" : 238993337
      }, {
        "name" : "Adi Rajan",
        "screen_name" : "adi_rajan",
        "indices" : [ 56, 66 ],
        "id_str" : "1011323449",
        "id" : 1011323449
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 68, 77 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Matthew Noble",
        "screen_name" : "NewbieCELTA",
        "indices" : [ 84, 96 ],
        "id_str" : "2311153903",
        "id" : 2311153903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/sG8imncAPi",
        "expanded_url" : "http:\/\/ow.ly\/ygc9L",
        "display_url" : "ow.ly\/ygc9L"
      } ]
    },
    "geo" : { },
    "id_str" : "479984707485331456",
    "text" : "New #ELTchat podcast! Featuring @kevchanwow, @bealer81, @adi_rajan, @MuraNava &amp; @NewbieCELTA http:\/\/t.co\/sG8imncAPi",
    "id" : 479984707485331456,
    "created_at" : "2014-06-20 13:50:46 +0000",
    "user" : {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "protected" : false,
      "id_str" : "71746265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595367704090939392\/nJCWaI_Z_normal.jpg",
      "id" : 71746265,
      "verified" : false
    }
  },
  "id" : 480008769603387394,
  "created_at" : "2014-06-20 15:26:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 12, 19 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 26, 35 ],
      "id_str" : "3362981",
      "id" : 3362981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/A7hKLbpIeI",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/19\/name-based-approaches-to-networks-and-why-they-are-crucial-to-the-personal-web\/#respond",
      "display_url" : "hapgood.us\/2014\/06\/19\/nam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479714476636516352",
  "text" : "RT @holden: @cogdog &amp; @jimgroom this is a partial attempt to explain why \"Where am I?\" is a complex question in SFW: http:\/\/t.co\/A7hKLbpIeI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alan Levine",
        "screen_name" : "cogdog",
        "indices" : [ 0, 7 ],
        "id_str" : "740343",
        "id" : 740343
      }, {
        "name" : "Jim Groom",
        "screen_name" : "jimgroom",
        "indices" : [ 14, 23 ],
        "id_str" : "3362981",
        "id" : 3362981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/A7hKLbpIeI",
        "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/19\/name-based-approaches-to-networks-and-why-they-are-crucial-to-the-personal-web\/#respond",
        "display_url" : "hapgood.us\/2014\/06\/19\/nam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479705180024209408",
    "in_reply_to_user_id" : 740343,
    "text" : "@cogdog &amp; @jimgroom this is a partial attempt to explain why \"Where am I?\" is a complex question in SFW: http:\/\/t.co\/A7hKLbpIeI",
    "id" : 479705180024209408,
    "created_at" : "2014-06-19 19:20:02 +0000",
    "in_reply_to_screen_name" : "cogdog",
    "in_reply_to_user_id_str" : "740343",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 479714476636516352,
  "created_at" : "2014-06-19 19:56:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479364542414483456",
  "geo" : { },
  "id_str" : "479370720343240704",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike lk fwd to it, btw what's the diff btw experimental and exploratory?",
  "id" : 479370720343240704,
  "in_reply_to_status_id" : 479364542414483456,
  "created_at" : "2014-06-18 21:11:00 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Cup Ball",
      "screen_name" : "IAmTheFIFABall",
      "indices" : [ 3, 18 ],
      "id_str" : "2553523830",
      "id" : 2553523830
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Spain",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "siesta",
      "indices" : [ 97, 104 ]
    }, {
      "text" : "WorldCup2014",
      "indices" : [ 135, 144 ]
    }, {
      "text" : "SpainVsChile",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479355741019848705",
  "text" : "RT @IAmTheFIFABall: I'm going to go out on a limb here &amp; say that maybe #Spain just needed a #siesta from their first half siesta. #WorldCu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Spain",
        "indices" : [ 56, 62 ]
      }, {
        "text" : "siesta",
        "indices" : [ 77, 84 ]
      }, {
        "text" : "WorldCup2014",
        "indices" : [ 115, 128 ]
      }, {
        "text" : "SpainVsChile",
        "indices" : [ 129, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479353750365421568",
    "text" : "I'm going to go out on a limb here &amp; say that maybe #Spain just needed a #siesta from their first half siesta. #WorldCup2014 #SpainVsChile",
    "id" : 479353750365421568,
    "created_at" : "2014-06-18 20:03:34 +0000",
    "user" : {
      "name" : "World Cup Ball",
      "screen_name" : "IAmTheFIFABall",
      "protected" : false,
      "id_str" : "2553523830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485062004348944385\/PbPYruqX_normal.jpeg",
      "id" : 2553523830,
      "verified" : false
    }
  },
  "id" : 479355741019848705,
  "created_at" : "2014-06-18 20:11:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/479127763639496704\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Pi4zCv0NJB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqY0KWJCUAAA5fI.png",
      "id_str" : "479127762708353024",
      "id" : 479127762708353024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqY0KWJCUAAA5fI.png",
      "sizes" : [ {
        "h" : 75,
        "resize" : "crop",
        "w" : 75
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 45,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 565
      } ],
      "display_url" : "pic.twitter.com\/Pi4zCv0NJB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479268230285238274",
  "text" : "RT @worrydream: you laugh because you've forgotten how to cry http:\/\/t.co\/Pi4zCv0NJB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/479127763639496704\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/Pi4zCv0NJB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqY0KWJCUAAA5fI.png",
        "id_str" : "479127762708353024",
        "id" : 479127762708353024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqY0KWJCUAAA5fI.png",
        "sizes" : [ {
          "h" : 75,
          "resize" : "crop",
          "w" : 75
        }, {
          "h" : 75,
          "resize" : "fit",
          "w" : 565
        }, {
          "h" : 45,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 75,
          "resize" : "fit",
          "w" : 565
        }, {
          "h" : 75,
          "resize" : "fit",
          "w" : 565
        } ],
        "display_url" : "pic.twitter.com\/Pi4zCv0NJB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479127763639496704",
    "text" : "you laugh because you've forgotten how to cry http:\/\/t.co\/Pi4zCv0NJB",
    "id" : 479127763639496704,
    "created_at" : "2014-06-18 05:05:35 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 479268230285238274,
  "created_at" : "2014-06-18 14:23:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/nDSMxjP3oP",
      "expanded_url" : "http:\/\/bit.ly\/1lvbxnT",
      "display_url" : "bit.ly\/1lvbxnT"
    } ]
  },
  "geo" : { },
  "id_str" : "479267984801013760",
  "text" : "RT @DonaldClark: Talk on 2500 yrs of learning theory (good and bad): then Adaptive, MOOCs and Oculus http:\/\/t.co\/nDSMxjP3oP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/nDSMxjP3oP",
        "expanded_url" : "http:\/\/bit.ly\/1lvbxnT",
        "display_url" : "bit.ly\/1lvbxnT"
      } ]
    },
    "geo" : { },
    "id_str" : "479167770970820608",
    "text" : "Talk on 2500 yrs of learning theory (good and bad): then Adaptive, MOOCs and Oculus http:\/\/t.co\/nDSMxjP3oP",
    "id" : 479167770970820608,
    "created_at" : "2014-06-18 07:44:33 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 479267984801013760,
  "created_at" : "2014-06-18 14:22:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "internetarchive",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/bLerdG1eDP",
      "expanded_url" : "http:\/\/web.archive.org\/web\/20071014024155\/http:\/\/ltsnpsy.york.ac.uk\/ltsnpsych\/easa\/",
      "display_url" : "web.archive.org\/web\/2007101402\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479263100328509440",
  "text" : "#internetarchive fab resource reminding me of my first webpages with an audience of more than 1 http:\/\/t.co\/bLerdG1eDP",
  "id" : 479263100328509440,
  "created_at" : "2014-06-18 14:03:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479262087940931584",
  "text" : "@_FTaylor_ not forgetting making bullet lists :)",
  "id" : 479262087940931584,
  "created_at" : "2014-06-18 13:59:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/4Owiu1etmb",
      "expanded_url" : "http:\/\/wp.me\/sf0PM-lee",
      "display_url" : "wp.me\/sf0PM-lee"
    } ]
  },
  "geo" : { },
  "id_str" : "479254114006990848",
  "text" : "RT @cogdog: CogDogBlogged: My Salad Day[s] of Multimedia CD-ROM Development: LEE http:\/\/t.co\/4Owiu1etmb&lt;-nice edtech archaeology",
  "id" : 479254114006990848,
  "created_at" : "2014-06-18 13:27:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twitter",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "Freedom",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/7JmuibdFOH",
      "expanded_url" : "http:\/\/ow.ly\/y9RFI",
      "display_url" : "ow.ly\/y9RFI"
    } ]
  },
  "geo" : { },
  "id_str" : "479252210950619136",
  "text" : "RT @patrickDurusau: Twitter and Refusing Service #Twitter #Freedom http:\/\/t.co\/7JmuibdFOH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Twitter",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "Freedom",
        "indices" : [ 38, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/7JmuibdFOH",
        "expanded_url" : "http:\/\/ow.ly\/y9RFI",
        "display_url" : "ow.ly\/y9RFI"
      } ]
    },
    "geo" : { },
    "id_str" : "479096312777166848",
    "text" : "Twitter and Refusing Service #Twitter #Freedom http:\/\/t.co\/7JmuibdFOH",
    "id" : 479096312777166848,
    "created_at" : "2014-06-18 03:00:36 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 479252210950619136,
  "created_at" : "2014-06-18 13:20:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 115, 121 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 122, 130 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "MarySousa",
      "screen_name" : "mary28sou",
      "indices" : [ 131, 140 ],
      "id_str" : "16604689",
      "id" : 16604689
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 139, 140 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/OU75EyTsfg",
      "expanded_url" : "http:\/\/wp.me\/P25Kfd-6X",
      "display_url" : "wp.me\/P25Kfd-6X"
    } ]
  },
  "geo" : { },
  "id_str" : "479245535208288256",
  "text" : "RT @michaelegriffin: Using online corpus tools to check intuitions http:\/\/t.co\/OU75EyTsfg (v old post) #ELTchat cc @idc74 @LahiffP @mary28s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Cook",
        "screen_name" : "idc74",
        "indices" : [ 94, 100 ],
        "id_str" : "290521216",
        "id" : 290521216
      }, {
        "name" : "Peter Lahiff",
        "screen_name" : "LahiffP",
        "indices" : [ 101, 109 ],
        "id_str" : "279078759",
        "id" : 279078759
      }, {
        "name" : "MarySousa",
        "screen_name" : "mary28sou",
        "indices" : [ 110, 120 ],
        "id_str" : "16604689",
        "id" : 16604689
      }, {
        "name" : "Adam Beale",
        "screen_name" : "bealer81",
        "indices" : [ 121, 130 ],
        "id_str" : "238993337",
        "id" : 238993337
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 82, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/OU75EyTsfg",
        "expanded_url" : "http:\/\/wp.me\/P25Kfd-6X",
        "display_url" : "wp.me\/P25Kfd-6X"
      } ]
    },
    "geo" : { },
    "id_str" : "479240175642374144",
    "text" : "Using online corpus tools to check intuitions http:\/\/t.co\/OU75EyTsfg (v old post) #ELTchat cc @idc74 @LahiffP @mary28sou @bealer81",
    "id" : 479240175642374144,
    "created_at" : "2014-06-18 12:32:16 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 479245535208288256,
  "created_at" : "2014-06-18 12:53:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 7, 15 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "MarySousa",
      "screen_name" : "mary28sou",
      "indices" : [ 16, 26 ],
      "id_str" : "16604689",
      "id" : 16604689
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 27, 36 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusteaching",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/C5OEvVF31d",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479245324381601792",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 @LahiffP @mary28sou @bealer81 for more #corpusteaching do consider G+ CL https:\/\/t.co\/C5OEvVF31d",
  "id" : 479245324381601792,
  "created_at" : "2014-06-18 12:52:43 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OUwuRRoVDH",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/15\/flipped-classroom-1972-style-and-early-visions-of-the-home-internet\/#comment-10642",
      "display_url" : "hapgood.us\/2014\/06\/15\/fli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478952920248238081",
  "text" : "They all know better until they don\u2019t, andthen the failure is supposed to be some grand show of how \u201Cagile\u201D they are. http:\/\/t.co\/OUwuRRoVDH",
  "id" : 478952920248238081,
  "created_at" : "2014-06-17 17:30:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/U4SQeYYzRp",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2014\/767-blair-bombing-iraq-better-again.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478925542956470273",
  "text" : "RT @medialens: The reality of the US empire, whoever is President, is that the military 'option' is always 'open'. http:\/\/t.co\/U4SQeYYzRp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/U4SQeYYzRp",
        "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2014\/767-blair-bombing-iraq-better-again.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478868618760167424",
    "text" : "The reality of the US empire, whoever is President, is that the military 'option' is always 'open'. http:\/\/t.co\/U4SQeYYzRp",
    "id" : 478868618760167424,
    "created_at" : "2014-06-17 11:55:50 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 478925542956470273,
  "created_at" : "2014-06-17 15:42:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Jamie Keddie",
      "screen_name" : "lessonstream",
      "indices" : [ 26, 39 ],
      "id_str" : "208193561",
      "id" : 208193561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/ZPoPHovJfq",
      "expanded_url" : "http:\/\/videotelling.com\/2014\/06\/interview-with-philip-kerr\/",
      "display_url" : "videotelling.com\/2014\/06\/interv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478896394087202818",
  "text" : "RT @seburnt: Interview of @lessonstream by Philip Kerr on Videotelling http:\/\/t.co\/ZPoPHovJfq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jamie Keddie",
        "screen_name" : "lessonstream",
        "indices" : [ 13, 26 ],
        "id_str" : "208193561",
        "id" : 208193561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ZPoPHovJfq",
        "expanded_url" : "http:\/\/videotelling.com\/2014\/06\/interview-with-philip-kerr\/",
        "display_url" : "videotelling.com\/2014\/06\/interv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478892830505857024",
    "text" : "Interview of @lessonstream by Philip Kerr on Videotelling http:\/\/t.co\/ZPoPHovJfq",
    "id" : 478892830505857024,
    "created_at" : "2014-06-17 13:32:02 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 478896394087202818,
  "created_at" : "2014-06-17 13:46:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 15, 26 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478892737027010560",
  "geo" : { },
  "id_str" : "478894817867743233",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis @steve_muir definitely! i really like what steve is doing with infographics in the lessons",
  "id" : 478894817867743233,
  "in_reply_to_status_id" : 478892737027010560,
  "created_at" : "2014-06-17 13:39:56 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Cup Ball",
      "screen_name" : "IAmTheFIFABall",
      "indices" : [ 3, 18 ],
      "id_str" : "2553523830",
      "id" : 2553523830
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/IAmTheFIFABall\/status\/478659708602290177\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/co6J9O1vbc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSKd6HIgAAGONs.jpg",
      "id_str" : "478659706828128256",
      "id" : 478659706828128256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSKd6HIgAAGONs.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/co6J9O1vbc"
    } ],
    "hashtags" : [ {
      "text" : "vuvuzela",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478891300595695616",
  "text" : "RT @IAmTheFIFABall: Don't miss the #vuvuzela. If I c any1 w\/ 1, I will fly thru the stands &amp; smash it w\/ u on the end of it. #WorldCup http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IAmTheFIFABall\/status\/478659708602290177\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/co6J9O1vbc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSKd6HIgAAGONs.jpg",
        "id_str" : "478659706828128256",
        "id" : 478659706828128256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSKd6HIgAAGONs.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        } ],
        "display_url" : "pic.twitter.com\/co6J9O1vbc"
      } ],
      "hashtags" : [ {
        "text" : "vuvuzela",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "WorldCup",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478659708602290177",
    "text" : "Don't miss the #vuvuzela. If I c any1 w\/ 1, I will fly thru the stands &amp; smash it w\/ u on the end of it. #WorldCup http:\/\/t.co\/co6J9O1vbc",
    "id" : 478659708602290177,
    "created_at" : "2014-06-16 22:05:42 +0000",
    "user" : {
      "name" : "World Cup Ball",
      "screen_name" : "IAmTheFIFABall",
      "protected" : false,
      "id_str" : "2553523830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485062004348944385\/PbPYruqX_normal.jpeg",
      "id" : 2553523830,
      "verified" : false
    }
  },
  "id" : 478891300595695616,
  "created_at" : "2014-06-17 13:25:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Gordon",
      "screen_name" : "AnotherLinguist",
      "indices" : [ 3, 19 ],
      "id_str" : "232957049",
      "id" : 232957049
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 102, 117 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AnotherLinguist\/status\/478714015468634112\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/gePpzuO8Ph",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqS73BTCMAAZkL9.jpg",
      "id_str" : "478714014323585024",
      "id" : 478714014323585024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqS73BTCMAAZkL9.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 814
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 814
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gePpzuO8Ph"
    } ],
    "hashtags" : [ {
      "text" : "TheMoreYouKnow",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478810338172088320",
  "text" : "RT @AnotherLinguist: How not to talk about soccer in AmEng  #TheMoreYouKnow http:\/\/t.co\/gePpzuO8Ph cc @DavidHarbinson",
  "id" : 478810338172088320,
  "created_at" : "2014-06-17 08:04:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 93, 105 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/PLLeydbeXO",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-7pQ",
      "display_url" : "wp.me\/p1U04a-7pQ"
    } ]
  },
  "geo" : { },
  "id_str" : "478806406095593473",
  "text" : "The two surprising NHS surveys the government hopes you don't see http:\/\/t.co\/PLLeydbeXO via @ThomasPride",
  "id" : 478806406095593473,
  "created_at" : "2014-06-17 07:48:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478628540309438464",
  "geo" : { },
  "id_str" : "478651814171398144",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters maybe cross check with item response theory history?",
  "id" : 478651814171398144,
  "in_reply_to_status_id" : 478628540309438464,
  "created_at" : "2014-06-16 21:34:20 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Duane",
      "screen_name" : "MrPaulDuane",
      "indices" : [ 3, 15 ],
      "id_str" : "17675405",
      "id" : 17675405
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MrPaulDuane\/status\/470982203141521409\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/0Pj5i2Gpyu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BolD0UrIMAABtnZ.jpg",
      "id_str" : "470982202218786816",
      "id" : 470982202218786816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BolD0UrIMAABtnZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 447
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 447
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 447
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 297
      } ],
      "display_url" : "pic.twitter.com\/0Pj5i2Gpyu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478611900239192064",
  "text" : "RT @MrPaulDuane: Well *that* went downhill fast. http:\/\/t.co\/0Pj5i2Gpyu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MrPaulDuane\/status\/470982203141521409\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/0Pj5i2Gpyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BolD0UrIMAABtnZ.jpg",
        "id_str" : "470982202218786816",
        "id" : 470982202218786816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BolD0UrIMAABtnZ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 447
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 447
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 447
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 297
        } ],
        "display_url" : "pic.twitter.com\/0Pj5i2Gpyu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470982203141521409",
    "text" : "Well *that* went downhill fast. http:\/\/t.co\/0Pj5i2Gpyu",
    "id" : 470982203141521409,
    "created_at" : "2014-05-26 17:38:02 +0000",
    "user" : {
      "name" : "Paul Duane",
      "screen_name" : "MrPaulDuane",
      "protected" : false,
      "id_str" : "17675405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589125528013119488\/UgUWcrB3_normal.jpg",
      "id" : 17675405,
      "verified" : false
    }
  },
  "id" : 478611900239192064,
  "created_at" : "2014-06-16 18:55:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 88, 102 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/JxfR9D9MnB",
      "expanded_url" : "https:\/\/modernlearners.com\/the-problem-with-personalization\/",
      "display_url" : "modernlearners.com\/the-problem-wi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478609717657628672",
  "text" : "RT @ElkySmith: In depth look at 'personalised learning' and educational technology from @audreywatters https:\/\/t.co\/JxfR9D9MnB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 73, 87 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/JxfR9D9MnB",
        "expanded_url" : "https:\/\/modernlearners.com\/the-problem-with-personalization\/",
        "display_url" : "modernlearners.com\/the-problem-wi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478364024896094210",
    "text" : "In depth look at 'personalised learning' and educational technology from @audreywatters https:\/\/t.co\/JxfR9D9MnB",
    "id" : 478364024896094210,
    "created_at" : "2014-06-16 02:30:45 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 478609717657628672,
  "created_at" : "2014-06-16 18:47:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 16, 22 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/iRDLi2JBPC",
      "expanded_url" : "http:\/\/english.stackexchange.com\/questions\/29971\/is-conversate-a-word",
      "display_url" : "english.stackexchange.com\/questions\/2997\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "478600871819739136",
  "geo" : { },
  "id_str" : "478606100653424640",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @ebefl  it's in the dictionary apparently http:\/\/t.co\/iRDLi2JBPC",
  "id" : 478606100653424640,
  "in_reply_to_status_id" : 478600871819739136,
  "created_at" : "2014-06-16 18:32:41 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 73, 88 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 92, 99 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SLA",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "edtech",
      "indices" : [ 46, 53 ]
    }, {
      "text" : "elt",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Xwx4jE5SQO",
      "expanded_url" : "http:\/\/eltjam.com\/how-could-sla-research-inform-edtech\/",
      "display_url" : "eltjam.com\/how-could-sla-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478598892767162368",
  "text" : "RT @jo_sayers: How could #SLA research inform #edtech? - Great post from @thornburyscott on @eltjam #elt #eltchat http:\/\/t.co\/Xwx4jE5SQO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 58, 73 ],
        "id_str" : "23090474",
        "id" : 23090474
      }, {
        "name" : "ELTjam",
        "screen_name" : "eltjam",
        "indices" : [ 77, 84 ],
        "id_str" : "1356363686",
        "id" : 1356363686
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SLA",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "edtech",
        "indices" : [ 31, 38 ]
      }, {
        "text" : "elt",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Xwx4jE5SQO",
        "expanded_url" : "http:\/\/eltjam.com\/how-could-sla-research-inform-edtech\/",
        "display_url" : "eltjam.com\/how-could-sla-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478581793692864512",
    "text" : "How could #SLA research inform #edtech? - Great post from @thornburyscott on @eltjam #elt #eltchat http:\/\/t.co\/Xwx4jE5SQO",
    "id" : 478581793692864512,
    "created_at" : "2014-06-16 16:56:05 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 478598892767162368,
  "created_at" : "2014-06-16 18:04:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 3, 19 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/bJ5M2E47Iy",
      "expanded_url" : "http:\/\/wp.me\/p2gBMI-8r",
      "display_url" : "wp.me\/p2gBMI-8r"
    } ]
  },
  "geo" : { },
  "id_str" : "478597759717482496",
  "text" : "RT @theteacherjames: TEFL Equity \u2013 A\u00A0Reaction http:\/\/t.co\/bJ5M2E47Iy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/bJ5M2E47Iy",
        "expanded_url" : "http:\/\/wp.me\/p2gBMI-8r",
        "display_url" : "wp.me\/p2gBMI-8r"
      } ]
    },
    "geo" : { },
    "id_str" : "478595187233390592",
    "text" : "TEFL Equity \u2013 A\u00A0Reaction http:\/\/t.co\/bJ5M2E47Iy",
    "id" : 478595187233390592,
    "created_at" : "2014-06-16 17:49:19 +0000",
    "user" : {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "protected" : false,
      "id_str" : "71746265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595367704090939392\/nJCWaI_Z_normal.jpg",
      "id" : 71746265,
      "verified" : false
    }
  },
  "id" : 478597759717482496,
  "created_at" : "2014-06-16 17:59:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XH3UGX8ZrO",
      "expanded_url" : "http:\/\/wp.me\/p2tYU2-ei",
      "display_url" : "wp.me\/p2tYU2-ei"
    } ]
  },
  "geo" : { },
  "id_str" : "478555793428459520",
  "text" : "Free resource: Crazy Animals and Other Activities for Teaching English to Children http:\/\/t.co\/XH3UGX8ZrO via @CLERAatAston",
  "id" : 478555793428459520,
  "created_at" : "2014-06-16 15:12:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "indices" : [ 3, 12 ],
      "id_str" : "34639201",
      "id" : 34639201
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "language",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/D5LdeBuFxs",
      "expanded_url" : "http:\/\/ow.ly\/y55cU",
      "display_url" : "ow.ly\/y55cU"
    } ]
  },
  "geo" : { },
  "id_str" : "478554080017924096",
  "text" : "RT @CALPERPA: WordBanker. A vocabulary learning tool just released as freeware. #language http:\/\/t.co\/D5LdeBuFxs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "language",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/D5LdeBuFxs",
        "expanded_url" : "http:\/\/ow.ly\/y55cU",
        "display_url" : "ow.ly\/y55cU"
      } ]
    },
    "geo" : { },
    "id_str" : "478523637310685184",
    "text" : "WordBanker. A vocabulary learning tool just released as freeware. #language http:\/\/t.co\/D5LdeBuFxs",
    "id" : 478523637310685184,
    "created_at" : "2014-06-16 13:05:00 +0000",
    "user" : {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "protected" : false,
      "id_str" : "34639201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634442828626563073\/ZRmLNoOU_normal.png",
      "id" : 34639201,
      "verified" : false
    }
  },
  "id" : 478554080017924096,
  "created_at" : "2014-06-16 15:05:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 27, 36 ]
    }, {
      "text" : "WorldCup2014",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 144 ],
      "url" : "http:\/\/t.co\/jM7rVUETkR",
      "expanded_url" : "http:\/\/worldcupenglish.co.uk\/football-or-soccer\/",
      "display_url" : "worldcupenglish.co.uk\/football-or-so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478413268759740417",
  "text" : "RT @DavidHarbinson: Online #WorldCup Lesson: Football or Soccer? The difference between American Soccer &amp; British Football http:\/\/t.co\/jM7r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 7, 16 ]
      }, {
        "text" : "WorldCup2014",
        "indices" : [ 130, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/jM7rVUETkR",
        "expanded_url" : "http:\/\/worldcupenglish.co.uk\/football-or-soccer\/",
        "display_url" : "worldcupenglish.co.uk\/football-or-so\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478412294179667968",
    "text" : "Online #WorldCup Lesson: Football or Soccer? The difference between American Soccer &amp; British Football http:\/\/t.co\/jM7rVUETkR #WorldCup2014",
    "id" : 478412294179667968,
    "created_at" : "2014-06-16 05:42:34 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 478413268759740417,
  "created_at" : "2014-06-16 05:46:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/vPP4oN3VnZ",
      "expanded_url" : "http:\/\/www.icge.co.uk\/languagesciencesblog\/?p=77",
      "display_url" : "icge.co.uk\/languagescienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478410061769764866",
  "text" : "Men are from Earth and women are also from Earth http:\/\/t.co\/vPP4oN3VnZ",
  "id" : 478410061769764866,
  "created_at" : "2014-06-16 05:33:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pool",
      "screen_name" : "Timcast",
      "indices" : [ 3, 11 ],
      "id_str" : "27000730",
      "id" : 27000730
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rio",
      "indices" : [ 52, 56 ]
    }, {
      "text" : "ContraACopa",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4iRUwDMGiS",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=fTW1ePYoV7Q#t=11",
      "display_url" : "youtube.com\/watch?v=fTW1eP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478296094750035968",
  "text" : "RT @Timcast: Protests scheduled for 3PM tomorrow in #Rio. #ContraACopa Full: This is why Brazilians are mad at the #WorldCup.  https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Rio",
        "indices" : [ 39, 43 ]
      }, {
        "text" : "ContraACopa",
        "indices" : [ 45, 57 ]
      }, {
        "text" : "WorldCup",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/4iRUwDMGiS",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=fTW1ePYoV7Q#t=11",
        "display_url" : "youtube.com\/watch?v=fTW1eP\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477942769194106880",
    "text" : "Protests scheduled for 3PM tomorrow in #Rio. #ContraACopa Full: This is why Brazilians are mad at the #WorldCup.  https:\/\/t.co\/4iRUwDMGiS",
    "id" : 477942769194106880,
    "created_at" : "2014-06-14 22:36:50 +0000",
    "user" : {
      "name" : "Tim Pool",
      "screen_name" : "Timcast",
      "protected" : false,
      "id_str" : "27000730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502618252473024513\/PNG4xclu_normal.jpeg",
      "id" : 27000730,
      "verified" : true
    }
  },
  "id" : 478296094750035968,
  "created_at" : "2014-06-15 22:00:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/27OFhECBzk",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "478268809489690624",
  "geo" : { },
  "id_str" : "478285311332876288",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo hi u may be interested in G+ CL comm https:\/\/t.co\/27OFhECBzk",
  "id" : 478285311332876288,
  "in_reply_to_status_id" : 478268809489690624,
  "created_at" : "2014-06-15 21:17:58 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 94, 110 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/nd0MGvANwP",
      "expanded_url" : "http:\/\/wp.me\/p354NQ-6f",
      "display_url" : "wp.me\/p354NQ-6f"
    } ]
  },
  "geo" : { },
  "id_str" : "478280991077720064",
  "text" : "A Game of Tongues: Why George R. R. Martin is a Linguist After All http:\/\/t.co\/nd0MGvANwP via @wordpressdotcom",
  "id" : 478280991077720064,
  "created_at" : "2014-06-15 21:00:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478242298757910528",
  "geo" : { },
  "id_str" : "478247165043957761",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons sure let's make things can change! good thanks i c u enjoying the footie or not! france match shld be worth a watch",
  "id" : 478247165043957761,
  "in_reply_to_status_id" : 478242298757910528,
  "created_at" : "2014-06-15 18:46:24 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rKniilM8NL",
      "expanded_url" : "http:\/\/malingual.blogspot.com\/2014\/06\/humble-pie.html?spref=tw",
      "display_url" : "malingual.blogspot.com\/2014\/06\/humble\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478239661266313217",
  "text" : "RT @lexicoloco: Something weird seems to have happened to 'humble'. Great obs. on language change from Evidence Based EFL: Humble Pie http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rKniilM8NL",
        "expanded_url" : "http:\/\/malingual.blogspot.com\/2014\/06\/humble-pie.html?spref=tw",
        "display_url" : "malingual.blogspot.com\/2014\/06\/humble\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478217552946937856",
    "text" : "Something weird seems to have happened to 'humble'. Great obs. on language change from Evidence Based EFL: Humble Pie http:\/\/t.co\/rKniilM8NL",
    "id" : 478217552946937856,
    "created_at" : "2014-06-15 16:48:44 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 478239661266313217,
  "created_at" : "2014-06-15 18:16:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 3, 19 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/9Ev3flyvf9",
      "expanded_url" : "http:\/\/ln.is\/blog.cslbcn.org\/2014\/oXArI",
      "display_url" : "ln.is\/blog.cslbcn.or\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478239507654148096",
  "text" : "RT @designerlessons: Our response to the most recent #ELTChat about respect in #TEFL -Fair Pay &amp;Equal Rights for Teachers. Please share :)\n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ETurn sharing into growth!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTChat",
        "indices" : [ 32, 40 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 58, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/9Ev3flyvf9",
        "expanded_url" : "http:\/\/ln.is\/blog.cslbcn.org\/2014\/oXArI",
        "display_url" : "ln.is\/blog.cslbcn.or\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478229572149075968",
    "text" : "Our response to the most recent #ELTChat about respect in #TEFL -Fair Pay &amp;Equal Rights for Teachers. Please share :)\nhttp:\/\/t.co\/9Ev3flyvf9",
    "id" : 478229572149075968,
    "created_at" : "2014-06-15 17:36:29 +0000",
    "user" : {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "protected" : false,
      "id_str" : "432090149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468158165914501121\/aHVWzkwG_normal.jpeg",
      "id" : 432090149,
      "verified" : false
    }
  },
  "id" : 478239507654148096,
  "created_at" : "2014-06-15 18:15:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/glWqNgGBni",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.com\/2014\/06\/directory-of-anti-teacher-trolls.html?spref=tw",
      "display_url" : "curmudgucation.blogspot.com\/2014\/06\/direct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478194373847306240",
  "text" : "CURMUDGUCATION: Directory of Anti-Teacher Trolls http:\/\/t.co\/glWqNgGBni",
  "id" : 478194373847306240,
  "created_at" : "2014-06-15 15:16:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478137966590967809",
  "text" : "RT @worrydream: How can you call the web a publishing medium when your bookshelf can just vanish? URLs and HTTP are a disaster. Doesn't hav\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "478087637031325697",
    "geo" : { },
    "id_str" : "478087689560797184",
    "in_reply_to_user_id" : 255617445,
    "text" : "How can you call the web a publishing medium when your bookshelf can just vanish? URLs and HTTP are a disaster. Doesn't have to be this way.",
    "id" : 478087689560797184,
    "in_reply_to_status_id" : 478087637031325697,
    "created_at" : "2014-06-15 08:12:42 +0000",
    "in_reply_to_screen_name" : "worrydream",
    "in_reply_to_user_id_str" : "255617445",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 478137966590967809,
  "created_at" : "2014-06-15 11:32:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478107685485682689",
  "geo" : { },
  "id_str" : "478112423917129729",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc ah right thanks",
  "id" : 478112423917129729,
  "in_reply_to_status_id" : 478107685485682689,
  "created_at" : "2014-06-15 09:50:59 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478037586422685696",
  "geo" : { },
  "id_str" : "478095851987169280",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc hi is it possible to output on horizontal format without lemma listing?",
  "id" : 478095851987169280,
  "in_reply_to_status_id" : 478037586422685696,
  "created_at" : "2014-06-15 08:45:08 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 3, 14 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/vkSWOJ3XTB",
      "expanded_url" : "https:\/\/sites.google.com\/site\/casualconcj\/yutiriti-puroguramu\/casualtreetagger",
      "display_url" : "sites.google.com\/site\/casualcon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478095502484176896",
  "text" : "RT @casualconc: TreeTagger\u306E\u30B5\u30A4\u30C8\u30A2\u30C9\u30EC\u30B9\u304C\u5909\u308F\u3063\u3066\u305F\u3088\u3046\u3067\u3001CasualTreeTagger\u3067\u306ETreeTagger\u306E\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u304C\u52D5\u304B\u306A\u304F\u306A\u3063\u3066\u3044\u305F\u306E\u3092\u76F4\u3057\u3066\u307F\u305F\u3002\u5BFE\u5FDC\u306F 10.8 \u4EE5\u964D\u306B\u306A\u308A\u307E\u3057\u305F\u3002https:\/\/t.co\/vkSWOJ3XTB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/vkSWOJ3XTB",
        "expanded_url" : "https:\/\/sites.google.com\/site\/casualconcj\/yutiriti-puroguramu\/casualtreetagger",
        "display_url" : "sites.google.com\/site\/casualcon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478037586422685696",
    "text" : "TreeTagger\u306E\u30B5\u30A4\u30C8\u30A2\u30C9\u30EC\u30B9\u304C\u5909\u308F\u3063\u3066\u305F\u3088\u3046\u3067\u3001CasualTreeTagger\u3067\u306ETreeTagger\u306E\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u304C\u52D5\u304B\u306A\u304F\u306A\u3063\u3066\u3044\u305F\u306E\u3092\u76F4\u3057\u3066\u307F\u305F\u3002\u5BFE\u5FDC\u306F 10.8 \u4EE5\u964D\u306B\u306A\u308A\u307E\u3057\u305F\u3002https:\/\/t.co\/vkSWOJ3XTB",
    "id" : 478037586422685696,
    "created_at" : "2014-06-15 04:53:36 +0000",
    "user" : {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "protected" : false,
      "id_str" : "132412691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819028682\/casualconc_normal.png",
      "id" : 132412691,
      "verified" : false
    }
  },
  "id" : 478095502484176896,
  "created_at" : "2014-06-15 08:43:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JPqXWkvF8L",
      "expanded_url" : "http:\/\/adaptivelearninginelt.wordpress.com\/2014\/06\/14\/boosterism-and-doomsterism\/",
      "display_url" : "adaptivelearninginelt.wordpress.com\/2014\/06\/14\/boo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477934775957983232",
  "text" : "RT @ElkySmith: Boosters &amp; doomsters - a new Adaptive Learning in ELT post by Philip Kerr - recommended reading! http:\/\/t.co\/JPqXWkvF8L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/JPqXWkvF8L",
        "expanded_url" : "http:\/\/adaptivelearninginelt.wordpress.com\/2014\/06\/14\/boosterism-and-doomsterism\/",
        "display_url" : "adaptivelearninginelt.wordpress.com\/2014\/06\/14\/boo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477932834917597184",
    "text" : "Boosters &amp; doomsters - a new Adaptive Learning in ELT post by Philip Kerr - recommended reading! http:\/\/t.co\/JPqXWkvF8L",
    "id" : 477932834917597184,
    "created_at" : "2014-06-14 21:57:22 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 477934775957983232,
  "created_at" : "2014-06-14 22:05:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/EZ4vbq048E",
      "expanded_url" : "http:\/\/sansdeconner.net\/wp-content\/uploads\/2014\/06\/letters_fr_en_mots.png",
      "display_url" : "sansdeconner.net\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477914977391886336",
  "text" : "English letter positions compared with French letter positions http:\/\/t.co\/EZ4vbq048E",
  "id" : 477914977391886336,
  "created_at" : "2014-06-14 20:46:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hhol",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wBlWrVEllx",
      "expanded_url" : "http:\/\/mura.hhol.hapgood.net:3000\/view\/welcome-visitors\/view\/the-hidden-history-of-online-learning\/view\/theorists\/view\/boosters-anti-schoolers-critics-doomsters",
      "display_url" : "mura.hhol.hapgood.net:3000\/view\/welcome-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477910124863180801",
  "text" : "http:\/\/t.co\/wBlWrVEllx #hhol",
  "id" : 477910124863180801,
  "created_at" : "2014-06-14 20:27:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hhol",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0d6j6HYYRR",
      "expanded_url" : "http:\/\/mura.hhol.hapgood.net:3000\/view\/welcome-visitors",
      "display_url" : "mura.hhol.hapgood.net:3000\/view\/welcome-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477820894493298688",
  "text" : "http:\/\/t.co\/0d6j6HYYRR #hhol",
  "id" : 477820894493298688,
  "created_at" : "2014-06-14 14:32:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477801279020728320",
  "geo" : { },
  "id_str" : "477819729877286913",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden great thanks :)",
  "id" : 477819729877286913,
  "in_reply_to_status_id" : 477801279020728320,
  "created_at" : "2014-06-14 14:27:55 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi",
      "screen_name" : "jodi_in_HH",
      "indices" : [ 0, 11 ],
      "id_str" : "727969848",
      "id" : 727969848
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 12, 25 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusteaching",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/C5OEvVF31d",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "477743788543475712",
  "geo" : { },
  "id_str" : "477764914103480320",
  "in_reply_to_user_id" : 727969848,
  "text" : "@jodi_in_HH @iatefl_besig for #corpusteaching consider joining\/checking out G+ community https:\/\/t.co\/C5OEvVF31d",
  "id" : 477764914103480320,
  "in_reply_to_status_id" : 477743788543475712,
  "created_at" : "2014-06-14 10:50:06 +0000",
  "in_reply_to_screen_name" : "jodi_in_HH",
  "in_reply_to_user_id_str" : "727969848",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi",
      "screen_name" : "jodi_in_HH",
      "indices" : [ 3, 14 ],
      "id_str" : "727969848",
      "id" : 727969848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BESIGGraz",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/LIKNNGxLSy",
      "expanded_url" : "http:\/\/www.cs.cmu.edu\/~.\/enron\/",
      "display_url" : "cs.cmu.edu\/~.\/enron\/"
    } ]
  },
  "geo" : { },
  "id_str" : "477764449529769984",
  "text" : "RT @jodi_in_HH: Blown away after finding out about the ENRON email corpus, a collection of 0.5M emails http:\/\/t.co\/LIKNNGxLSy #BESIGGraz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BESIGGraz",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/LIKNNGxLSy",
        "expanded_url" : "http:\/\/www.cs.cmu.edu\/~.\/enron\/",
        "display_url" : "cs.cmu.edu\/~.\/enron\/"
      } ]
    },
    "geo" : { },
    "id_str" : "477743788543475712",
    "text" : "Blown away after finding out about the ENRON email corpus, a collection of 0.5M emails http:\/\/t.co\/LIKNNGxLSy #BESIGGraz",
    "id" : 477743788543475712,
    "created_at" : "2014-06-14 09:26:09 +0000",
    "user" : {
      "name" : "Jodi",
      "screen_name" : "jodi_in_HH",
      "protected" : false,
      "id_str" : "727969848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486968242079285248\/BADGGO4X_normal.jpeg",
      "id" : 727969848,
      "verified" : false
    }
  },
  "id" : 477764449529769984,
  "created_at" : "2014-06-14 10:48:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477596018281037824",
  "geo" : { },
  "id_str" : "477726664383021056",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden nice cheers :)",
  "id" : 477726664383021056,
  "in_reply_to_status_id" : 477596018281037824,
  "created_at" : "2014-06-14 08:18:07 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 0, 7 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477563555446001664",
  "in_reply_to_user_id" : 1912681,
  "text" : "@holden hi there can i get a SFW account? interested in playing with it :)",
  "id" : 477563555446001664,
  "created_at" : "2014-06-13 21:29:58 +0000",
  "in_reply_to_screen_name" : "holden",
  "in_reply_to_user_id_str" : "1912681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Allington",
      "screen_name" : "dr_d_allington",
      "indices" : [ 0, 15 ],
      "id_str" : "1287008022",
      "id" : 1287008022
    }, {
      "name" : "Karim Murji",
      "screen_name" : "km49",
      "indices" : [ 16, 21 ],
      "id_str" : "21514477",
      "id" : 21514477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477519453199286272",
  "geo" : { },
  "id_str" : "477548426297896961",
  "in_reply_to_user_id" : 1287008022,
  "text" : "@dr_d_allington @km49 can't CH4 peeps ever ask decent questions? :\/",
  "id" : 477548426297896961,
  "in_reply_to_status_id" : 477519453199286272,
  "created_at" : "2014-06-13 20:29:51 +0000",
  "in_reply_to_screen_name" : "dr_d_allington",
  "in_reply_to_user_id_str" : "1287008022",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Umut Demirhan",
      "screen_name" : "demirhanumut",
      "indices" : [ 0, 13 ],
      "id_str" : "70658434",
      "id" : 70658434
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 119, 128 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477536974501597185",
  "geo" : { },
  "id_str" : "477538748201439232",
  "in_reply_to_user_id" : 70658434,
  "text" : "@demirhanumut i assume it can run on 64bit OS, i did it in a 32bit winxp virtual machine, maybe u can ask\/confirm with @antlabjp ?",
  "id" : 477538748201439232,
  "in_reply_to_status_id" : 477536974501597185,
  "created_at" : "2014-06-13 19:51:24 +0000",
  "in_reply_to_screen_name" : "demirhanumut",
  "in_reply_to_user_id_str" : "70658434",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Umut Demirhan",
      "screen_name" : "demirhanumut",
      "indices" : [ 0, 13 ],
      "id_str" : "70658434",
      "id" : 70658434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477534917774299136",
  "in_reply_to_user_id" : 70658434,
  "text" : "@demirhanumut thanks for RT :)",
  "id" : 477534917774299136,
  "created_at" : "2014-06-13 19:36:11 +0000",
  "in_reply_to_screen_name" : "demirhanumut",
  "in_reply_to_user_id_str" : "70658434",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/LbivaSnXjm",
      "expanded_url" : "http:\/\/crr.ugent.be\/archives\/1628",
      "display_url" : "crr.ugent.be\/archives\/1628"
    } ]
  },
  "geo" : { },
  "id_str" : "477534794512089089",
  "text" : "Words known by men and women http:\/\/t.co\/LbivaSnXjm",
  "id" : 477534794512089089,
  "created_at" : "2014-06-13 19:35:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MonkeyLearn",
      "screen_name" : "monkeylearn",
      "indices" : [ 3, 15 ],
      "id_str" : "2182812798",
      "id" : 2182812798
    }, {
      "name" : "FIFA World Cup",
      "screen_name" : "FIFAWorldCup",
      "indices" : [ 113, 126 ],
      "id_str" : "138372303",
      "id" : 138372303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TextMining",
      "indices" : [ 24, 35 ]
    }, {
      "text" : "SentimentAnalysis",
      "indices" : [ 40, 58 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/O8mKxKmDfH",
      "expanded_url" : "http:\/\/www.google.com\/trends\/worldcup#\/en-us\/",
      "display_url" : "google.com\/trends\/worldcu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477491445579120640",
  "text" : "RT @monkeylearn: [COOL] #TextMining and #SentimentAnalysis of Google about the #WorldCup: http:\/\/t.co\/O8mKxKmDfH @FIFAWorldCup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FIFA World Cup",
        "screen_name" : "FIFAWorldCup",
        "indices" : [ 96, 109 ],
        "id_str" : "138372303",
        "id" : 138372303
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TextMining",
        "indices" : [ 7, 18 ]
      }, {
        "text" : "SentimentAnalysis",
        "indices" : [ 23, 41 ]
      }, {
        "text" : "WorldCup",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/O8mKxKmDfH",
        "expanded_url" : "http:\/\/www.google.com\/trends\/worldcup#\/en-us\/",
        "display_url" : "google.com\/trends\/worldcu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477489798052323328",
    "text" : "[COOL] #TextMining and #SentimentAnalysis of Google about the #WorldCup: http:\/\/t.co\/O8mKxKmDfH @FIFAWorldCup",
    "id" : 477489798052323328,
    "created_at" : "2014-06-13 16:36:53 +0000",
    "user" : {
      "name" : "MonkeyLearn",
      "screen_name" : "monkeylearn",
      "protected" : false,
      "id_str" : "2182812798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664607819040096258\/S0RRSAeO_normal.png",
      "id" : 2182812798,
      "verified" : false
    }
  },
  "id" : 477491445579120640,
  "created_at" : "2014-06-13 16:43:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 126, 135 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/k4vQnEsd0W",
      "expanded_url" : "http:\/\/gu.com\/p\/3q4km\/tw",
      "display_url" : "gu.com\/p\/3q4km\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "477479112273969152",
  "text" : "Defence officials prepare to fight the poor, activists and minorities (and commies) | Nafeez Ahmed http:\/\/t.co\/k4vQnEsd0W via @guardian",
  "id" : 477479112273969152,
  "created_at" : "2014-06-13 15:54:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "textivate",
      "screen_name" : "textivate",
      "indices" : [ 3, 13 ],
      "id_str" : "757151820",
      "id" : 757151820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 98, 107 ]
    }, {
      "text" : "edtech",
      "indices" : [ 108, 115 ]
    }, {
      "text" : "flteach",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "elearning",
      "indices" : [ 125, 135 ]
    }, {
      "text" : "mfltwitterati",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/iVOmiisYQC",
      "expanded_url" : "http:\/\/textivate.posthaven.com\/guided-slash-scaffolded-translation-activities",
      "display_url" : "textivate.posthaven.com\/guided-slash-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477466962776555520",
  "text" : "RT @textivate: Make your own \"guided translation\" interactive activities:\nhttp:\/\/t.co\/iVOmiisYQC\n\n#langchat\n#edtech\n#flteach\n#elearning\n#mf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "edtech",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "flteach",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "elearning",
        "indices" : [ 110, 120 ]
      }, {
        "text" : "mfltwitterati",
        "indices" : [ 121, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/iVOmiisYQC",
        "expanded_url" : "http:\/\/textivate.posthaven.com\/guided-slash-scaffolded-translation-activities",
        "display_url" : "textivate.posthaven.com\/guided-slash-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477456387908591616",
    "text" : "Make your own \"guided translation\" interactive activities:\nhttp:\/\/t.co\/iVOmiisYQC\n\n#langchat\n#edtech\n#flteach\n#elearning\n#mfltwitterati",
    "id" : 477456387908591616,
    "created_at" : "2014-06-13 14:24:08 +0000",
    "user" : {
      "name" : "textivate",
      "screen_name" : "textivate",
      "protected" : false,
      "id_str" : "757151820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616568320066764800\/rx5tLnzg_normal.png",
      "id" : 757151820,
      "verified" : false
    }
  },
  "id" : 477466962776555520,
  "created_at" : "2014-06-13 15:06:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/A47a8TxTaW",
      "expanded_url" : "http:\/\/bit.ly\/1ud8ekD",
      "display_url" : "bit.ly\/1ud8ekD"
    } ]
  },
  "geo" : { },
  "id_str" : "477462386535047168",
  "text" : "RT @linguisticpulse: Using corpus linguistics to examine \"dog whistle racism\" http:\/\/t.co\/A47a8TxTaW. Is \"dog whistle\" really the best term?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/A47a8TxTaW",
        "expanded_url" : "http:\/\/bit.ly\/1ud8ekD",
        "display_url" : "bit.ly\/1ud8ekD"
      } ]
    },
    "geo" : { },
    "id_str" : "477457781612482561",
    "text" : "Using corpus linguistics to examine \"dog whistle racism\" http:\/\/t.co\/A47a8TxTaW. Is \"dog whistle\" really the best term?",
    "id" : 477457781612482561,
    "created_at" : "2014-06-13 14:29:40 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 477462386535047168,
  "created_at" : "2014-06-13 14:47:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 93, 109 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/HkLiuhYus4",
      "expanded_url" : "http:\/\/wp.me\/p3augf-dY",
      "display_url" : "wp.me\/p3augf-dY"
    } ]
  },
  "geo" : { },
  "id_str" : "477348889649876994",
  "text" : "ELF corpora in the mainstream: notes from the ICAME 35 conference http:\/\/t.co\/HkLiuhYus4 via @wordpressdotcom #corpuslinguistics",
  "id" : 477348889649876994,
  "created_at" : "2014-06-13 07:16:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/QsFo3xLr5k",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/06\/12\/student-curation-in-smallest-federated-wiki\/",
      "display_url" : "hapgood.us\/2014\/06\/12\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477348584929890304",
  "text" : "Student curation in the smallest federated wiki http:\/\/t.co\/QsFo3xLr5k",
  "id" : 477348584929890304,
  "created_at" : "2014-06-13 07:15:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 126, 133 ]
    }, {
      "text" : "besig",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "esp",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "eltindia",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/BLgZVe13z4",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-W8",
      "display_url" : "wp.me\/p21lsm-W8"
    } ]
  },
  "geo" : { },
  "id_str" : "477345838587727872",
  "text" : "RT @adi_rajan: Mining professional forums to supplement a Business English course some examples for IT http:\/\/t.co\/BLgZVe13z4 #corpus #besi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "besig",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "esp",
        "indices" : [ 126, 130 ]
      }, {
        "text" : "eltindia",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/BLgZVe13z4",
        "expanded_url" : "http:\/\/wp.me\/p21lsm-W8",
        "display_url" : "wp.me\/p21lsm-W8"
      } ]
    },
    "geo" : { },
    "id_str" : "477254263991582721",
    "text" : "Mining professional forums to supplement a Business English course some examples for IT http:\/\/t.co\/BLgZVe13z4 #corpus #besig #esp #eltindia",
    "id" : 477254263991582721,
    "created_at" : "2014-06-13 01:00:58 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 477345838587727872,
  "created_at" : "2014-06-13 07:04:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    }, {
      "name" : "everyword",
      "screen_name" : "everyword",
      "indices" : [ 51, 61 ],
      "id_str" : "10729632",
      "id" : 10729632
    }, {
      "name" : "Ruth Spencer",
      "screen_name" : "ruths",
      "indices" : [ 118, 124 ],
      "id_str" : "24200155",
      "id" : 24200155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/C6VOTOnvNY",
      "expanded_url" : "http:\/\/www.theguardian.com\/culture\/2014\/jun\/04\/everyword-twitter-ends-adam-parrish-english-language",
      "display_url" : "theguardian.com\/culture\/2014\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477072475373977600",
  "text" : "RT @Edulang: After seven years and 109,000 tweets, @everyword, one of the internet's most beloved bots, is retiring. (@ruths) : http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "everyword",
        "screen_name" : "everyword",
        "indices" : [ 38, 48 ],
        "id_str" : "10729632",
        "id" : 10729632
      }, {
        "name" : "Ruth Spencer",
        "screen_name" : "ruths",
        "indices" : [ 105, 111 ],
        "id_str" : "24200155",
        "id" : 24200155
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/C6VOTOnvNY",
        "expanded_url" : "http:\/\/www.theguardian.com\/culture\/2014\/jun\/04\/everyword-twitter-ends-adam-parrish-english-language",
        "display_url" : "theguardian.com\/culture\/2014\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477070920184791040",
    "text" : "After seven years and 109,000 tweets, @everyword, one of the internet's most beloved bots, is retiring. (@ruths) : http:\/\/t.co\/C6VOTOnvNY",
    "id" : 477070920184791040,
    "created_at" : "2014-06-12 12:52:25 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 477072475373977600,
  "created_at" : "2014-06-12 12:58:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Jameson",
      "screen_name" : "BarryJamesonELT",
      "indices" : [ 3, 19 ],
      "id_str" : "288933875",
      "id" : 288933875
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 52, 62 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "BESIG",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/BDOWpmo7vM",
      "expanded_url" : "http:\/\/bit.ly\/1q2ZEr2",
      "display_url" : "bit.ly\/1q2ZEr2"
    } ]
  },
  "geo" : { },
  "id_str" : "477062819918405632",
  "text" : "RT @BarryJamesonELT: 10 minutes is all you need. MT @phil3wade: I just made my first ebook for Business English. http:\/\/t.co\/BDOWpmo7vM . #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "phil wade",
        "screen_name" : "phil3wade",
        "indices" : [ 31, 41 ],
        "id_str" : "248864761",
        "id" : 248864761
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "BESIG",
        "indices" : [ 122, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/BDOWpmo7vM",
        "expanded_url" : "http:\/\/bit.ly\/1q2ZEr2",
        "display_url" : "bit.ly\/1q2ZEr2"
      } ]
    },
    "geo" : { },
    "id_str" : "477014616120508417",
    "text" : "10 minutes is all you need. MT @phil3wade: I just made my first ebook for Business English. http:\/\/t.co\/BDOWpmo7vM . #ELT #BESIG",
    "id" : 477014616120508417,
    "created_at" : "2014-06-12 09:08:41 +0000",
    "user" : {
      "name" : "Barry Jameson",
      "screen_name" : "BarryJamesonELT",
      "protected" : false,
      "id_str" : "288933875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694191502734540800\/gdmhSqVZ_normal.jpg",
      "id" : 288933875,
      "verified" : false
    }
  },
  "id" : 477062819918405632,
  "created_at" : "2014-06-12 12:20:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "greg dl",
      "screen_name" : "greg_dl",
      "indices" : [ 0, 8 ],
      "id_str" : "149385569",
      "id" : 149385569
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 9, 24 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 25, 41 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 42, 57 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 67, 79 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477000844538552321",
  "in_reply_to_user_id" : 149385569,
  "text" : "@greg_dl @AnthonyTeacher @michaelegriffin @DavidHarbinson @antlabj @n00rbaizura thanks for RTs and fav of TagAnt post :)",
  "id" : 477000844538552321,
  "created_at" : "2014-06-12 08:13:58 +0000",
  "in_reply_to_screen_name" : "greg_dl",
  "in_reply_to_user_id_str" : "149385569",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DN9KVNYVYx",
      "expanded_url" : "http:\/\/www.richmondshare.com.br\/linguistic-intuition\/",
      "display_url" : "richmondshare.com.br\/linguistic-int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476749891973414912",
  "text" : "RT @luizotavioELT: Feel vs. know: The role of linguistic intuition in the learning process. http:\/\/t.co\/DN9KVNYVYx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/DN9KVNYVYx",
        "expanded_url" : "http:\/\/www.richmondshare.com.br\/linguistic-intuition\/",
        "display_url" : "richmondshare.com.br\/linguistic-int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476615413929746432",
    "text" : "Feel vs. know: The role of linguistic intuition in the learning process. http:\/\/t.co\/DN9KVNYVYx",
    "id" : 476615413929746432,
    "created_at" : "2014-06-11 06:42:24 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 476749891973414912,
  "created_at" : "2014-06-11 15:36:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusteaching",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/igFdQgLPpj",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/C3fUPoMW1V4",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476729869641203712",
  "text" : "Building your own corpus - TagAnt https:\/\/t.co\/igFdQgLPpj #corpusteaching",
  "id" : 476729869641203712,
  "created_at" : "2014-06-11 14:17:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/5g9S4CLLlv",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-PU",
      "display_url" : "wp.me\/p3qkCB-PU"
    } ]
  },
  "geo" : { },
  "id_str" : "476708427570630656",
  "text" : "RT @GeoffreyJordan: A Summary of Krashen\u2019s responses to questions about The Monitor\u00A0Model http:\/\/t.co\/5g9S4CLLlv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/5g9S4CLLlv",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-PU",
        "display_url" : "wp.me\/p3qkCB-PU"
      } ]
    },
    "geo" : { },
    "id_str" : "476696255557423104",
    "text" : "A Summary of Krashen\u2019s responses to questions about The Monitor\u00A0Model http:\/\/t.co\/5g9S4CLLlv",
    "id" : 476696255557423104,
    "created_at" : "2014-06-11 12:03:38 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 476708427570630656,
  "created_at" : "2014-06-11 12:52:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/MIfzi6lJlb",
      "expanded_url" : "http:\/\/the-round.com\/labs\/academic-reading-circles\/",
      "display_url" : "the-round.com\/labs\/academic-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476707542362763264",
  "text" : "RT @seburnt: ARC book is officially forthcoming! http:\/\/t.co\/MIfzi6lJlb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/MIfzi6lJlb",
        "expanded_url" : "http:\/\/the-round.com\/labs\/academic-reading-circles\/",
        "display_url" : "the-round.com\/labs\/academic-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476695716698402817",
    "text" : "ARC book is officially forthcoming! http:\/\/t.co\/MIfzi6lJlb",
    "id" : 476695716698402817,
    "created_at" : "2014-06-11 12:01:30 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 476707542362763264,
  "created_at" : "2014-06-11 12:48:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deeplearning",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476642144988712960",
  "text" : "wonder how long it will take for edtech companies to start promoting #deeplearning in their PR?",
  "id" : 476642144988712960,
  "created_at" : "2014-06-11 08:28:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476588176266756096",
  "geo" : { },
  "id_str" : "476638292793118720",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet yeah of course, though the street has been one way on twitter especially and corporate news generally",
  "id" : 476638292793118720,
  "in_reply_to_status_id" : 476588176266756096,
  "created_at" : "2014-06-11 08:13:19 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 60, 76 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusteaching",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/iNG1HYQcCg",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-VV",
      "display_url" : "wp.me\/p21lsm-VV"
    } ]
  },
  "geo" : { },
  "id_str" : "476632246195986433",
  "text" : "Concordancing forums. The 'why'. http:\/\/t.co\/iNG1HYQcCg via @wordpressdotcom #corpusteaching",
  "id" : 476632246195986433,
  "created_at" : "2014-06-11 07:49:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476507411176767488",
  "geo" : { },
  "id_str" : "476508407768559616",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp don't know have only tried it with yours :)",
  "id" : 476508407768559616,
  "in_reply_to_status_id" : 476507411176767488,
  "created_at" : "2014-06-10 23:37:12 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476489477888966656",
  "geo" : { },
  "id_str" : "476505910425448449",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp fyi about 12mins to tag a 160k word text in a virtual winxp",
  "id" : 476505910425448449,
  "in_reply_to_status_id" : 476489477888966656,
  "created_at" : "2014-06-10 23:27:16 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/476495231102492672\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/6W2oKWkHaZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpzZ4wQIUAAHP9P.png",
      "id_str" : "476495229642887168",
      "id" : 476495229642887168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpzZ4wQIUAAHP9P.png",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6W2oKWkHaZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476489363002773505",
  "geo" : { },
  "id_str" : "476495231102492672",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet cause of course the problem is only putin's ego :\/ http:\/\/t.co\/6W2oKWkHaZ",
  "id" : 476495231102492672,
  "in_reply_to_status_id" : 476489363002773505,
  "created_at" : "2014-06-10 22:44:50 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/be1nrfGM1S",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "476493029101273089",
  "text" : "RT @antlabjp: For anyone who wants a portable standalone freeware POS tagger, I have finally released TagAnt, based on Treetagger: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/be1nrfGM1S",
        "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
        "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "476489477888966656",
    "text" : "For anyone who wants a portable standalone freeware POS tagger, I have finally released TagAnt, based on Treetagger: http:\/\/t.co\/be1nrfGM1S",
    "id" : 476489477888966656,
    "created_at" : "2014-06-10 22:21:58 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 476493029101273089,
  "created_at" : "2014-06-10 22:36:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 61, 77 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 78, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/B8jyOVo73u",
      "expanded_url" : "http:\/\/wp.me\/p2vE3W-4x",
      "display_url" : "wp.me\/p2vE3W-4x"
    } ]
  },
  "geo" : { },
  "id_str" : "476478863938043904",
  "text" : "Mass counts in the World Wide Web http:\/\/t.co\/B8jyOVo73u via @wordpressdotcom #corpuslinguistics",
  "id" : 476478863938043904,
  "created_at" : "2014-06-10 21:39:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476118934211796992",
  "text" : "its 2014 &amp; people r still calling chinese whispers chinese whispers",
  "id" : 476118934211796992,
  "created_at" : "2014-06-09 21:49:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/PQi1hi8hUo",
      "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/pdfplus\/10.3366\/cor.2012.0019",
      "display_url" : "euppublishing.com\/doi\/pdfplus\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476000076108955648",
  "text" : "RT @lexicoloco: Corpora and Coursebooks: destined to be strangers forever? Graham Burton PDF http:\/\/t.co\/PQi1hi8hUo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/PQi1hi8hUo",
        "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/pdfplus\/10.3366\/cor.2012.0019",
        "display_url" : "euppublishing.com\/doi\/pdfplus\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "475950161634795520",
    "text" : "Corpora and Coursebooks: destined to be strangers forever? Graham Burton PDF http:\/\/t.co\/PQi1hi8hUo",
    "id" : 475950161634795520,
    "created_at" : "2014-06-09 10:38:55 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 476000076108955648,
  "created_at" : "2014-06-09 13:57:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0411\u0430\u043B\u0438\u043D\u0433",
      "screen_name" : "websofsubstance",
      "indices" : [ 63, 79 ],
      "id_str" : "235176479",
      "id" : 235176479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/XCRxAcFaFz",
      "expanded_url" : "http:\/\/wp.me\/p3hsrD-nC",
      "display_url" : "wp.me\/p3hsrD-nC"
    } ]
  },
  "geo" : { },
  "id_str" : "475938447681540097",
  "text" : "The code-breakers of Bletchley Park http:\/\/t.co\/XCRxAcFaFz via @websofsubstance",
  "id" : 475938447681540097,
  "created_at" : "2014-06-09 09:52:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edreform",
      "indices" : [ 69, 78 ]
    }, {
      "text" : "iaedfuture",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/gZU5BIRpRc",
      "expanded_url" : "http:\/\/bit.ly\/1hIJPn6",
      "display_url" : "bit.ly\/1hIJPn6"
    } ]
  },
  "geo" : { },
  "id_str" : "475927925892870144",
  "text" : "RT @mcleod: Why Is Bill Gates Making $#!+ Up? http:\/\/t.co\/gZU5BIRpRc #edreform #iaedfuture",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edreform",
        "indices" : [ 57, 66 ]
      }, {
        "text" : "iaedfuture",
        "indices" : [ 67, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/gZU5BIRpRc",
        "expanded_url" : "http:\/\/bit.ly\/1hIJPn6",
        "display_url" : "bit.ly\/1hIJPn6"
      } ]
    },
    "geo" : { },
    "id_str" : "475834725723291648",
    "text" : "Why Is Bill Gates Making $#!+ Up? http:\/\/t.co\/gZU5BIRpRc #edreform #iaedfuture",
    "id" : 475834725723291648,
    "created_at" : "2014-06-09 03:00:13 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 475927925892870144,
  "created_at" : "2014-06-09 09:10:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475741202189680641",
  "text" : "@_FTaylor_ a computer mimicking a human is so much wasted silicon :0",
  "id" : 475741202189680641,
  "created_at" : "2014-06-08 20:48:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "news",
      "indices" : [ 72, 77 ]
    }, {
      "text" : "heuristic",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/edn5jSMtqG",
      "expanded_url" : "http:\/\/ow.ly\/xKro2",
      "display_url" : "ow.ly\/xKro2"
    } ]
  },
  "geo" : { },
  "id_str" : "475626672595939329",
  "text" : "RT @patrickDurusau: A heuristic for sorting science stories in the news #news #heuristic http:\/\/t.co\/edn5jSMtqG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "news",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "heuristic",
        "indices" : [ 58, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/edn5jSMtqG",
        "expanded_url" : "http:\/\/ow.ly\/xKro2",
        "display_url" : "ow.ly\/xKro2"
      } ]
    },
    "geo" : { },
    "id_str" : "475502529514852352",
    "text" : "A heuristic for sorting science stories in the news #news #heuristic http:\/\/t.co\/edn5jSMtqG",
    "id" : 475502529514852352,
    "created_at" : "2014-06-08 05:00:12 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 475626672595939329,
  "created_at" : "2014-06-08 13:13:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475413513347661824",
  "geo" : { },
  "id_str" : "475611883253542912",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher yr welcome, did u get perlconc working in the end?",
  "id" : 475611883253542912,
  "in_reply_to_status_id" : 475413513347661824,
  "created_at" : "2014-06-08 12:14:44 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/eZ5cOmizJd",
      "expanded_url" : "http:\/\/differentefl.blogspot.com\/2014\/06\/informationgap-activities-what-does-it.html?spref=tw",
      "display_url" : "differentefl.blogspot.com\/2014\/06\/inform\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475183997761224704",
  "text" : "A different side of EFL: Information gap activities: what does it take to d... http:\/\/t.co\/eZ5cOmizJd",
  "id" : 475183997761224704,
  "created_at" : "2014-06-07 07:54:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BE",
      "indices" : [ 90, 93 ]
    }, {
      "text" : "ESP",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "besig",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "BESIGGraz",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/SILGbK33qh",
      "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2014\/06\/three-steps-how-to-improve-esp-training.html",
      "display_url" : "businessenglishideas.blogspot.de\/2014\/06\/three-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475179064815550464",
  "text" : "RT @Charlesrei1: New post: 3 Steps for improving ESP training http:\/\/t.co\/SILGbK33qh from #BE to #ESP #besig #BESIGGraz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BE",
        "indices" : [ 73, 76 ]
      }, {
        "text" : "ESP",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "besig",
        "indices" : [ 85, 91 ]
      }, {
        "text" : "BESIGGraz",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/SILGbK33qh",
        "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2014\/06\/three-steps-how-to-improve-esp-training.html",
        "display_url" : "businessenglishideas.blogspot.de\/2014\/06\/three-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474936724309946368",
    "text" : "New post: 3 Steps for improving ESP training http:\/\/t.co\/SILGbK33qh from #BE to #ESP #besig #BESIGGraz",
    "id" : 474936724309946368,
    "created_at" : "2014-06-06 15:31:53 +0000",
    "user" : {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "protected" : false,
      "id_str" : "464454382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461561508057468928\/BA8otRW0_normal.jpeg",
      "id" : 464454382,
      "verified" : false
    }
  },
  "id" : 475179064815550464,
  "created_at" : "2014-06-07 07:34:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dckpiVOeUv",
      "expanded_url" : "http:\/\/worrydream.com\/refs\/Kay%20-%20Powerful%20Ideas%20Need%20Love%20Too.html",
      "display_url" : "worrydream.com\/refs\/Kay%20-%2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474959366672891904",
  "text" : "RT @worrydream: Every time you hear someone mention \"storytelling\", esp. in a journalistic or educational context, go reread this: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/dckpiVOeUv",
        "expanded_url" : "http:\/\/worrydream.com\/refs\/Kay%20-%20Powerful%20Ideas%20Need%20Love%20Too.html",
        "display_url" : "worrydream.com\/refs\/Kay%20-%2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "472450967489609728",
    "text" : "Every time you hear someone mention \"storytelling\", esp. in a journalistic or educational context, go reread this: http:\/\/t.co\/dckpiVOeUv",
    "id" : 472450967489609728,
    "created_at" : "2014-05-30 18:54:23 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 474959366672891904,
  "created_at" : "2014-06-06 17:01:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 0, 12 ],
      "id_str" : "31179355",
      "id" : 31179355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474897672076525568",
  "geo" : { },
  "id_str" : "474908031134990336",
  "in_reply_to_user_id" : 31179355,
  "text" : "@mattledding \/boinggggg\/ rubber arm springing back :)",
  "id" : 474908031134990336,
  "in_reply_to_status_id" : 474897672076525568,
  "created_at" : "2014-06-06 13:37:52 +0000",
  "in_reply_to_screen_name" : "mattledding",
  "in_reply_to_user_id_str" : "31179355",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 3, 15 ],
      "id_str" : "31179355",
      "id" : 31179355
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 17, 28 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 29, 38 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 39, 50 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 51, 64 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ERzYTIZVqn",
      "expanded_url" : "https:\/\/dl.dropboxusercontent.com\/u\/5238321\/heyTiger.pdf",
      "display_url" : "dl.dropboxusercontent.com\/u\/5238321\/heyT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474904185738391552",
  "text" : "RT @mattledding: @evanfrendo @muranava @leoselivan @iatefl_besig OK, rubber arm twisted... Put https:\/\/t.co\/ERzYTIZVqn on the g+ group....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "evanfrendo",
        "screen_name" : "evanfrendo",
        "indices" : [ 0, 11 ],
        "id_str" : "17589664",
        "id" : 17589664
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 12, 21 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 22, 33 ],
        "id_str" : "408365496",
        "id" : 408365496
      }, {
        "name" : "IATEFL BESIG",
        "screen_name" : "iatefl_besig",
        "indices" : [ 34, 47 ],
        "id_str" : "146913655",
        "id" : 146913655
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/ERzYTIZVqn",
        "expanded_url" : "https:\/\/dl.dropboxusercontent.com\/u\/5238321\/heyTiger.pdf",
        "display_url" : "dl.dropboxusercontent.com\/u\/5238321\/heyT\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "474836912947990528",
    "geo" : { },
    "id_str" : "474897672076525568",
    "in_reply_to_user_id" : 17589664,
    "text" : "@evanfrendo @muranava @leoselivan @iatefl_besig OK, rubber arm twisted... Put https:\/\/t.co\/ERzYTIZVqn on the g+ group....",
    "id" : 474897672076525568,
    "in_reply_to_status_id" : 474836912947990528,
    "created_at" : "2014-06-06 12:56:42 +0000",
    "in_reply_to_screen_name" : "evanfrendo",
    "in_reply_to_user_id_str" : "17589664",
    "user" : {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "protected" : false,
      "id_str" : "31179355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1126573271\/mattagotchi_normal.png",
      "id" : 31179355,
      "verified" : false
    }
  },
  "id" : 474904185738391552,
  "created_at" : "2014-06-06 13:22:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "indices" : [ 78, 89 ],
      "id_str" : "2268648355",
      "id" : 2268648355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socrative",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474853204631777280",
  "text" : "a couple of #socrative activities went down very well last class today thx to @HakanS_Elt session yesterday :)",
  "id" : 474853204631777280,
  "created_at" : "2014-06-06 10:00:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/6nltw6HZVS",
      "expanded_url" : "http:\/\/canlloparot.wordpress.com\/2014\/05\/08\/criticisms-of-the-monitor-model\/",
      "display_url" : "canlloparot.wordpress.com\/2014\/05\/08\/cri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474842731295277056",
  "text" : "RT @GeoffreyJordan: Good to see Stephen Krashen has given a detailed reply to my post http:\/\/t.co\/6nltw6HZVS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/6nltw6HZVS",
        "expanded_url" : "http:\/\/canlloparot.wordpress.com\/2014\/05\/08\/criticisms-of-the-monitor-model\/",
        "display_url" : "canlloparot.wordpress.com\/2014\/05\/08\/cri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474827607880785920",
    "text" : "Good to see Stephen Krashen has given a detailed reply to my post http:\/\/t.co\/6nltw6HZVS",
    "id" : 474827607880785920,
    "created_at" : "2014-06-06 08:18:18 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 474842731295277056,
  "created_at" : "2014-06-06 09:18:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 3, 14 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 16, 25 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 26, 37 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 38, 51 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 52, 64 ],
      "id_str" : "31179355",
      "id" : 31179355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/BJeXQOr9S9",
      "expanded_url" : "http:\/\/prezi.com\/gqze5f-xovy9\/enron-little-data-and-the-infinite-monkey-machine\/",
      "display_url" : "prezi.com\/gqze5f-xovy9\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474839876396126208",
  "text" : "RT @evanfrendo: @muranava @leoselivan @iatefl_besig @mattledding the prezi? http:\/\/t.co\/BJeXQOr9S9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 10, 21 ],
        "id_str" : "408365496",
        "id" : 408365496
      }, {
        "name" : "IATEFL BESIG",
        "screen_name" : "iatefl_besig",
        "indices" : [ 22, 35 ],
        "id_str" : "146913655",
        "id" : 146913655
      }, {
        "name" : "matt ledding",
        "screen_name" : "mattledding",
        "indices" : [ 36, 48 ],
        "id_str" : "31179355",
        "id" : 31179355
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/BJeXQOr9S9",
        "expanded_url" : "http:\/\/prezi.com\/gqze5f-xovy9\/enron-little-data-and-the-infinite-monkey-machine\/",
        "display_url" : "prezi.com\/gqze5f-xovy9\/e\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "474834454788448256",
    "geo" : { },
    "id_str" : "474836912947990528",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava @leoselivan @iatefl_besig @mattledding the prezi? http:\/\/t.co\/BJeXQOr9S9",
    "id" : 474836912947990528,
    "in_reply_to_status_id" : 474834454788448256,
    "created_at" : "2014-06-06 08:55:16 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "protected" : false,
      "id_str" : "17589664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267172323\/Evan_Frendo_normal.jpg",
      "id" : 17589664,
      "verified" : false
    }
  },
  "id" : 474839876396126208,
  "created_at" : "2014-06-06 09:07:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 0, 11 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 24, 37 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 38, 50 ],
      "id_str" : "31179355",
      "id" : 31179355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474836912947990528",
  "geo" : { },
  "id_str" : "474837526029828096",
  "in_reply_to_user_id" : 17589664,
  "text" : "@evanfrendo @leoselivan @iatefl_besig @mattledding that's cool he has an even cooler one, he will share  it on G+ comm soonish ;)",
  "id" : 474837526029828096,
  "in_reply_to_status_id" : 474836912947990528,
  "created_at" : "2014-06-06 08:57:42 +0000",
  "in_reply_to_screen_name" : "evanfrendo",
  "in_reply_to_user_id_str" : "17589664",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 12, 25 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 26, 37 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "matt ledding",
      "screen_name" : "mattledding",
      "indices" : [ 73, 85 ],
      "id_str" : "31179355",
      "id" : 31179355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474831468946935809",
  "geo" : { },
  "id_str" : "474834454788448256",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @iatefl_besig @evanfrendo matt has a very cool thing on this @mattledding",
  "id" : 474834454788448256,
  "in_reply_to_status_id" : 474831468946935809,
  "created_at" : "2014-06-06 08:45:30 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 3, 16 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 58, 69 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BESIGGraz",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "bizEnglish",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474833897860378624",
  "text" : "RT @iatefl_besig: Don't miss the #BESIGGraz livestream of @evanfrendo on exploiting the Enron email corpus in the #bizEnglish classroom. Sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "evanfrendo",
        "screen_name" : "evanfrendo",
        "indices" : [ 40, 51 ],
        "id_str" : "17589664",
        "id" : 17589664
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BESIGGraz",
        "indices" : [ 15, 25 ]
      }, {
        "text" : "bizEnglish",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474795977019502592",
    "text" : "Don't miss the #BESIGGraz livestream of @evanfrendo on exploiting the Enron email corpus in the #bizEnglish classroom. Sat 14 Jun 11.15 CEST",
    "id" : 474795977019502592,
    "created_at" : "2014-06-06 06:12:36 +0000",
    "user" : {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "protected" : false,
      "id_str" : "146913655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921734243\/BesigLogoSmall_normal.jpg",
      "id" : 146913655,
      "verified" : false
    }
  },
  "id" : 474833897860378624,
  "created_at" : "2014-06-06 08:43:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "indices" : [ 3, 14 ],
      "id_str" : "2268648355",
      "id" : 2268648355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesometraining",
      "indices" : [ 16, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/dgoL9X2hgv",
      "expanded_url" : "https:\/\/vine.co\/v\/MD76v2gUvPx",
      "display_url" : "vine.co\/v\/MD76v2gUvPx"
    } ]
  },
  "geo" : { },
  "id_str" : "474549848612802560",
  "text" : "RT @HakanS_Elt: #awesometraining https:\/\/t.co\/dgoL9X2hgv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "awesometraining",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/dgoL9X2hgv",
        "expanded_url" : "https:\/\/vine.co\/v\/MD76v2gUvPx",
        "display_url" : "vine.co\/v\/MD76v2gUvPx"
      } ]
    },
    "geo" : { },
    "id_str" : "474549613320736768",
    "text" : "#awesometraining https:\/\/t.co\/dgoL9X2hgv",
    "id" : 474549613320736768,
    "created_at" : "2014-06-05 13:53:39 +0000",
    "user" : {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "protected" : false,
      "id_str" : "2268648355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417600214803828736\/_YgJrApM_normal.jpeg",
      "id" : 2268648355,
      "verified" : false
    }
  },
  "id" : 474549848612802560,
  "created_at" : "2014-06-05 13:54:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 76, 89 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/wQBAsugOfi",
      "expanded_url" : "http:\/\/wp.me\/p1wSAy-z6",
      "display_url" : "wp.me\/p1wSAy-z6"
    } ]
  },
  "geo" : { },
  "id_str" : "474548807880175616",
  "text" : "RT @rosemerebard: Top ten resources for teachers http:\/\/t.co\/wQBAsugOfi via @lizziepinard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzie Pinard",
        "screen_name" : "LizziePinard",
        "indices" : [ 58, 71 ],
        "id_str" : "287093748",
        "id" : 287093748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/wQBAsugOfi",
        "expanded_url" : "http:\/\/wp.me\/p1wSAy-z6",
        "display_url" : "wp.me\/p1wSAy-z6"
      } ]
    },
    "geo" : { },
    "id_str" : "474545656355233793",
    "text" : "Top ten resources for teachers http:\/\/t.co\/wQBAsugOfi via @lizziepinard",
    "id" : 474545656355233793,
    "created_at" : "2014-06-05 13:37:55 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 474548807880175616,
  "created_at" : "2014-06-05 13:50:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "centraleparis",
      "screen_name" : "centraleparis",
      "indices" : [ 26, 40 ],
      "id_str" : "3384225669",
      "id" : 3384225669
    }, {
      "name" : "Julie McDonald",
      "screen_name" : "bedonald",
      "indices" : [ 95, 104 ],
      "id_str" : "72925190",
      "id" : 72925190
    }, {
      "name" : "George Wilson",
      "screen_name" : "GDW82",
      "indices" : [ 105, 111 ],
      "id_str" : "1531690604",
      "id" : 1531690604
    }, {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 112, 124 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    }, {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "indices" : [ 125, 136 ],
      "id_str" : "2268648355",
      "id" : 2268648355
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/474513753745424384\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4Ko1efzrX3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpXPvlUIAAAfqzE.jpg",
      "id_str" : "474513752134778880",
      "id" : 474513752134778880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpXPvlUIAAAfqzE.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4Ko1efzrX3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474548480376332288",
  "text" : "RT @_divyamadhavan: Lunch @centraleparis language department Professional Development Day with @bedonald @GDW82 @chuechebueb @HakanS_Elt ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "centraleparis",
        "screen_name" : "centraleparis",
        "indices" : [ 6, 20 ],
        "id_str" : "3384225669",
        "id" : 3384225669
      }, {
        "name" : "Julie McDonald",
        "screen_name" : "bedonald",
        "indices" : [ 75, 84 ],
        "id_str" : "72925190",
        "id" : 72925190
      }, {
        "name" : "George Wilson",
        "screen_name" : "GDW82",
        "indices" : [ 85, 91 ],
        "id_str" : "1531690604",
        "id" : 1531690604
      }, {
        "name" : "Luca Marchiori",
        "screen_name" : "chuechebueb",
        "indices" : [ 92, 104 ],
        "id_str" : "1334451956",
        "id" : 1334451956
      }, {
        "name" : "Hakan \u015Eent\u00FCrk",
        "screen_name" : "HakanS_Elt",
        "indices" : [ 105, 116 ],
        "id_str" : "2268648355",
        "id" : 2268648355
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/474513753745424384\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/4Ko1efzrX3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpXPvlUIAAAfqzE.jpg",
        "id_str" : "474513752134778880",
        "id" : 474513752134778880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpXPvlUIAAAfqzE.jpg",
        "sizes" : [ {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4Ko1efzrX3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.7652148739, 2.2892484624 ]
    },
    "id_str" : "474513753745424384",
    "text" : "Lunch @centraleparis language department Professional Development Day with @bedonald @GDW82 @chuechebueb @HakanS_Elt http:\/\/t.co\/4Ko1efzrX3",
    "id" : 474513753745424384,
    "created_at" : "2014-06-05 11:31:09 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 474548480376332288,
  "created_at" : "2014-06-05 13:49:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "indices" : [ 3, 14 ],
      "id_str" : "2268648355",
      "id" : 2268648355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesometraining",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/lDDCqpLfq2",
      "expanded_url" : "https:\/\/vine.co\/v\/MD7v7lTZJYI",
      "display_url" : "vine.co\/v\/MD7v7lTZJYI"
    } ]
  },
  "geo" : { },
  "id_str" : "474548246334144512",
  "text" : "RT @HakanS_Elt: Great audience at ECP #awesometraining https:\/\/t.co\/lDDCqpLfq2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "awesometraining",
        "indices" : [ 22, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/lDDCqpLfq2",
        "expanded_url" : "https:\/\/vine.co\/v\/MD7v7lTZJYI",
        "display_url" : "vine.co\/v\/MD7v7lTZJYI"
      } ]
    },
    "geo" : { },
    "id_str" : "474548001697177600",
    "text" : "Great audience at ECP #awesometraining https:\/\/t.co\/lDDCqpLfq2",
    "id" : 474548001697177600,
    "created_at" : "2014-06-05 13:47:14 +0000",
    "user" : {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "protected" : false,
      "id_str" : "2268648355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417600214803828736\/_YgJrApM_normal.jpeg",
      "id" : 2268648355,
      "verified" : false
    }
  },
  "id" : 474548246334144512,
  "created_at" : "2014-06-05 13:48:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/474546241683353600\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/8GSnUXslQo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpXtSoUIEAAjhZa.jpg",
      "id_str" : "474546240072716288",
      "id" : 474546240072716288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpXtSoUIEAAjhZa.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/8GSnUXslQo"
    } ],
    "hashtags" : [ {
      "text" : "awesometraining",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474546652372795392",
  "text" : "RT @_divyamadhavan: #awesometraining http:\/\/t.co\/8GSnUXslQo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/474546241683353600\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/8GSnUXslQo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpXtSoUIEAAjhZa.jpg",
        "id_str" : "474546240072716288",
        "id" : 474546240072716288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpXtSoUIEAAjhZa.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/8GSnUXslQo"
      } ],
      "hashtags" : [ {
        "text" : "awesometraining",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.7652674569, 2.2892551966 ]
    },
    "id_str" : "474546241683353600",
    "text" : "#awesometraining http:\/\/t.co\/8GSnUXslQo",
    "id" : 474546241683353600,
    "created_at" : "2014-06-05 13:40:15 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 474546652372795392,
  "created_at" : "2014-06-05 13:41:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesometraining",
      "indices" : [ 13, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474546085311295488",
  "text" : "How awesome? #awesometraining",
  "id" : 474546085311295488,
  "created_at" : "2014-06-05 13:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "indices" : [ 3, 14 ],
      "id_str" : "2268648355",
      "id" : 2268648355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesometraining",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474545787297628160",
  "text" : "RT @HakanS_Elt: I'm having a great time with some awesome teachers from Ecole Centrale Paris #awesometraining",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "awesometraining",
        "indices" : [ 77, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474545578467414016",
    "text" : "I'm having a great time with some awesome teachers from Ecole Centrale Paris #awesometraining",
    "id" : 474545578467414016,
    "created_at" : "2014-06-05 13:37:37 +0000",
    "user" : {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "HakanS_Elt",
      "protected" : false,
      "id_str" : "2268648355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417600214803828736\/_YgJrApM_normal.jpeg",
      "id" : 2268648355,
      "verified" : false
    }
  },
  "id" : 474545787297628160,
  "created_at" : "2014-06-05 13:38:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uBCA0\uB9AC\uAD7F",
      "screen_name" : "ESLBarry",
      "indices" : [ 3, 12 ],
      "id_str" : "630249484",
      "id" : 630249484
    }, {
      "name" : "PearsonELT",
      "screen_name" : "Pearson_ELT",
      "indices" : [ 41, 53 ],
      "id_str" : "63127949",
      "id" : 63127949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PEroundtable",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474245016916099073",
  "text" : "RT @ESLBarry: Anyone else wondering when @Pearson_ELT will come clean and admit they are pure evil incarnate? #PEroundtable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PearsonELT",
        "screen_name" : "Pearson_ELT",
        "indices" : [ 27, 39 ],
        "id_str" : "63127949",
        "id" : 63127949
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PEroundtable",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474240502007463936",
    "text" : "Anyone else wondering when @Pearson_ELT will come clean and admit they are pure evil incarnate? #PEroundtable",
    "id" : 474240502007463936,
    "created_at" : "2014-06-04 17:25:21 +0000",
    "user" : {
      "name" : "\uBCA0\uB9AC\uAD7F",
      "screen_name" : "ESLBarry",
      "protected" : false,
      "id_str" : "630249484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738333303833382912\/HcVxwtIJ_normal.jpg",
      "id" : 630249484,
      "verified" : false
    }
  },
  "id" : 474245016916099073,
  "created_at" : "2014-06-04 17:43:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PearsonELT",
      "screen_name" : "Pearson_ELT",
      "indices" : [ 1, 13 ],
      "id_str" : "63127949",
      "id" : 63127949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474239816163680256",
  "geo" : { },
  "id_str" : "474242067397636097",
  "in_reply_to_user_id" : 63127949,
  "text" : ".@Pearson_ELT crucially Graddol reported employers wanted either very low skill or very high skill English users",
  "id" : 474242067397636097,
  "in_reply_to_status_id" : 474239816163680256,
  "created_at" : "2014-06-04 17:31:34 +0000",
  "in_reply_to_screen_name" : "Pearson_ELT",
  "in_reply_to_user_id_str" : "63127949",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 3, 15 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "Seth Largo",
      "screen_name" : "SethLargo",
      "indices" : [ 100, 110 ],
      "id_str" : "952289635",
      "id" : 952289635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/UxTZSxsYhJ",
      "expanded_url" : "http:\/\/bit.ly\/1jPAK68",
      "display_url" : "bit.ly\/1jPAK68"
    } ]
  },
  "geo" : { },
  "id_str" : "474207926111199232",
  "text" : "RT @onalifeglug: Very interesting computer-aided textual analysis of Elliot Rodger's manifesto (via @SethLargo) http:\/\/t.co\/UxTZSxsYhJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seth Largo",
        "screen_name" : "SethLargo",
        "indices" : [ 83, 93 ],
        "id_str" : "952289635",
        "id" : 952289635
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/UxTZSxsYhJ",
        "expanded_url" : "http:\/\/bit.ly\/1jPAK68",
        "display_url" : "bit.ly\/1jPAK68"
      } ]
    },
    "geo" : { },
    "id_str" : "474206896954802177",
    "text" : "Very interesting computer-aided textual analysis of Elliot Rodger's manifesto (via @SethLargo) http:\/\/t.co\/UxTZSxsYhJ",
    "id" : 474206896954802177,
    "created_at" : "2014-06-04 15:11:49 +0000",
    "user" : {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "protected" : false,
      "id_str" : "19516039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586664577095622656\/NwBHdlk5_normal.jpg",
      "id" : 19516039,
      "verified" : false
    }
  },
  "id" : 474207926111199232,
  "created_at" : "2014-06-04 15:15:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 13, 28 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474197750876504064",
  "geo" : { },
  "id_str" : "474199105099812864",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @DavidHarbinson google translate says download beautiful and the republic of china, is that correct? :0",
  "id" : 474199105099812864,
  "in_reply_to_status_id" : 474197750876504064,
  "created_at" : "2014-06-04 14:40:51 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "indices" : [ 65, 74 ],
      "id_str" : "2222993041",
      "id" : 2222993041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/kuOo5LzG8U",
      "expanded_url" : "http:\/\/wp.me\/p3RMIO-7d",
      "display_url" : "wp.me\/p3RMIO-7d"
    } ]
  },
  "geo" : { },
  "id_str" : "474159419412865024",
  "text" : "Ten non-native English speaker models http:\/\/t.co\/kuOo5LzG8U via @ELF_Pron",
  "id" : 474159419412865024,
  "created_at" : "2014-06-04 12:03:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 70, 86 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/OCGy2PEVQp",
      "expanded_url" : "http:\/\/wp.me\/p2sloZ-3T",
      "display_url" : "wp.me\/p2sloZ-3T"
    } ]
  },
  "geo" : { },
  "id_str" : "473991652546068480",
  "text" : "Western media on Syria \/ Ukraine elections http:\/\/t.co\/OCGy2PEVQp via @wordpressdotcom",
  "id" : 473991652546068480,
  "created_at" : "2014-06-04 00:56:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uliana Proshina",
      "screen_name" : "MpUliana",
      "indices" : [ 3, 12 ],
      "id_str" : "1382330305",
      "id" : 1382330305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "ELT",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/ZhE0tuDtwL",
      "expanded_url" : "http:\/\/bit.ly\/1kr4rzm",
      "display_url" : "bit.ly\/1kr4rzm"
    } ]
  },
  "geo" : { },
  "id_str" : "473985123730210816",
  "text" : "RT @MpUliana: CUP video: The Corpus as a Resource in Language Teaching http:\/\/t.co\/ZhE0tuDtwL #corpora #ELT #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpora",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "ELT",
        "indices" : [ 89, 93 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/ZhE0tuDtwL",
        "expanded_url" : "http:\/\/bit.ly\/1kr4rzm",
        "display_url" : "bit.ly\/1kr4rzm"
      } ]
    },
    "geo" : { },
    "id_str" : "472092318078869505",
    "text" : "CUP video: The Corpus as a Resource in Language Teaching http:\/\/t.co\/ZhE0tuDtwL #corpora #ELT #eltchat",
    "id" : 472092318078869505,
    "created_at" : "2014-05-29 19:09:14 +0000",
    "user" : {
      "name" : "Uliana Proshina",
      "screen_name" : "MpUliana",
      "protected" : false,
      "id_str" : "1382330305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493598736036417536\/Zab28uXh_normal.jpeg",
      "id" : 1382330305,
      "verified" : false
    }
  },
  "id" : 473985123730210816,
  "created_at" : "2014-06-04 00:30:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/yGs6ysZPMh",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/TawexsWtgC4",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "473922393337892864",
  "geo" : { },
  "id_str" : "473924740856705025",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes sed is very neat here's an ex. using -i and .bak switch https:\/\/t.co\/yGs6ysZPMh",
  "id" : 473924740856705025,
  "in_reply_to_status_id" : 473922393337892864,
  "created_at" : "2014-06-03 20:30:37 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 67, 76 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QUAhkCUhq0",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1228",
      "display_url" : "cass.lancs.ac.uk\/?p=1228"
    } ]
  },
  "geo" : { },
  "id_str" : "473885160782725120",
  "text" : "RT @CorpusSocialSci: Our centre's latest visitor Laurence Anthony (@antlabjp) blogs about \"Coming to CASS to code: The first two months\" ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laurence Anthony",
        "screen_name" : "antlabjp",
        "indices" : [ 46, 55 ],
        "id_str" : "167020390",
        "id" : 167020390
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/QUAhkCUhq0",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1228",
        "display_url" : "cass.lancs.ac.uk\/?p=1228"
      } ]
    },
    "geo" : { },
    "id_str" : "473848557825708033",
    "text" : "Our centre's latest visitor Laurence Anthony (@antlabjp) blogs about \"Coming to CASS to code: The first two months\" http:\/\/t.co\/QUAhkCUhq0",
    "id" : 473848557825708033,
    "created_at" : "2014-06-03 15:27:54 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 473885160782725120,
  "created_at" : "2014-06-03 17:53:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Xerri",
      "screen_name" : "danielxerri",
      "indices" : [ 0, 12 ],
      "id_str" : "144477800",
      "id" : 144477800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473576166805491713",
  "geo" : { },
  "id_str" : "473820178749591552",
  "in_reply_to_user_id" : 144477800,
  "text" : "@danielxerri ok will keep an eye out :)",
  "id" : 473820178749591552,
  "in_reply_to_status_id" : 473576166805491713,
  "created_at" : "2014-06-03 13:35:08 +0000",
  "in_reply_to_screen_name" : "danielxerri",
  "in_reply_to_user_id_str" : "144477800",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Xerri",
      "screen_name" : "danielxerri",
      "indices" : [ 0, 12 ],
      "id_str" : "144477800",
      "id" : 144477800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/xSChsgHZsQ",
      "expanded_url" : "http:\/\/www.danielxerri.com\/uploads\/4\/5\/3\/0\/4530212\/resig_poster.pdf",
      "display_url" : "danielxerri.com\/uploads\/4\/5\/3\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473508610069499904",
  "in_reply_to_user_id" : 144477800,
  "text" : "@danielxerri hi daniel are there any writeups of your poster presentation? http:\/\/t.co\/xSChsgHZsQ",
  "id" : 473508610069499904,
  "created_at" : "2014-06-02 16:57:04 +0000",
  "in_reply_to_screen_name" : "danielxerri",
  "in_reply_to_user_id_str" : "144477800",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 59, 74 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/DAYFMs4qH6",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/kwic-vocabulary-review-activity",
      "display_url" : "anthonyteacher.com\/blog\/kwic-voca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473496798502195200",
  "text" : "KWIC Vocabulary Review Activity http:\/\/t.co\/DAYFMs4qH6 via @AnthonyTeacher",
  "id" : 473496798502195200,
  "created_at" : "2014-06-02 16:10:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 101, 117 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagepolicy",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nDbjmK4UT6",
      "expanded_url" : "http:\/\/wp.me\/p1vRPr-6f",
      "display_url" : "wp.me\/p1vRPr-6f"
    } ]
  },
  "geo" : { },
  "id_str" : "473485298069151745",
  "text" : "RT @duygucandarli: My new blog post - Englishisation of Higher Education: http:\/\/t.co\/nDbjmK4UT6 via @wordpressdotcom #languagepolicy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 82, 98 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "languagepolicy",
        "indices" : [ 99, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/nDbjmK4UT6",
        "expanded_url" : "http:\/\/wp.me\/p1vRPr-6f",
        "display_url" : "wp.me\/p1vRPr-6f"
      } ]
    },
    "geo" : { },
    "id_str" : "473096724840333312",
    "text" : "My new blog post - Englishisation of Higher Education: http:\/\/t.co\/nDbjmK4UT6 via @wordpressdotcom #languagepolicy",
    "id" : 473096724840333312,
    "created_at" : "2014-06-01 13:40:23 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 473485298069151745,
  "created_at" : "2014-06-02 15:24:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 3, 18 ],
      "id_str" : "358143205",
      "id" : 358143205
    }, {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 101, 116 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/caFVVJsv9q",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-3z",
      "display_url" : "wp.me\/p35kaI-3z"
    } ]
  },
  "geo" : { },
  "id_str" : "473439209592987648",
  "text" : "RT @AndrewBrindle2: A look at collocates of 'man up' # corpus linguistics http:\/\/t.co\/caFVVJsv9q via @AndrewBrindle2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Brindle",
        "screen_name" : "AndrewBrindle2",
        "indices" : [ 81, 96 ],
        "id_str" : "358143205",
        "id" : 358143205
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/caFVVJsv9q",
        "expanded_url" : "http:\/\/wp.me\/p35kaI-3z",
        "display_url" : "wp.me\/p35kaI-3z"
      } ]
    },
    "geo" : { },
    "id_str" : "473430670891438080",
    "text" : "A look at collocates of 'man up' # corpus linguistics http:\/\/t.co\/caFVVJsv9q via @AndrewBrindle2",
    "id" : 473430670891438080,
    "created_at" : "2014-06-02 11:47:22 +0000",
    "user" : {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "protected" : false,
      "id_str" : "358143205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3159032513\/6388ad14eee8e221dba33ca6f3186650_normal.jpeg",
      "id" : 358143205,
      "verified" : false
    }
  },
  "id" : 473439209592987648,
  "created_at" : "2014-06-02 12:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 116, 124 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MaWSIG",
      "indices" : [ 98, 105 ]
    }, {
      "text" : "ELT",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "ESL",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/LHnn0TcJLs",
      "expanded_url" : "http:\/\/sco.lt\/54ThE9",
      "display_url" : "sco.lt\/54ThE9"
    } ]
  },
  "geo" : { },
  "id_str" : "473435925834641408",
  "text" : "RT @ELTwriter: loving this CEFR vocab profiler from vocabkitchen makes ELT writing easier this am #MaWSIG #ELT #ESL @scoopit http:\/\/t.co\/LH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scoop.it",
        "screen_name" : "scoopit",
        "indices" : [ 101, 109 ],
        "id_str" : "209484168",
        "id" : 209484168
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MaWSIG",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "ELT",
        "indices" : [ 91, 95 ]
      }, {
        "text" : "ESL",
        "indices" : [ 96, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/LHnn0TcJLs",
        "expanded_url" : "http:\/\/sco.lt\/54ThE9",
        "display_url" : "sco.lt\/54ThE9"
      } ]
    },
    "geo" : { },
    "id_str" : "473430599957762048",
    "text" : "loving this CEFR vocab profiler from vocabkitchen makes ELT writing easier this am #MaWSIG #ELT #ESL @scoopit http:\/\/t.co\/LHnn0TcJLs",
    "id" : 473430599957762048,
    "created_at" : "2014-06-02 11:47:05 +0000",
    "user" : {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "protected" : false,
      "id_str" : "2464809235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460507349728260097\/lvDvuOIE_normal.jpeg",
      "id" : 2464809235,
      "verified" : false
    }
  },
  "id" : 473435925834641408,
  "created_at" : "2014-06-02 12:08:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/j9a4eshUBG",
      "expanded_url" : "http:\/\/pndo.ly\/RNKTcB",
      "display_url" : "pndo.ly\/RNKTcB"
    } ]
  },
  "geo" : { },
  "id_str" : "473430100390985728",
  "text" : "RT @PandoDaily: eBay Shrugged: Pierre Omidyar believes there should be no philanthropy without profit http:\/\/t.co\/j9a4eshUBG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/j9a4eshUBG",
        "expanded_url" : "http:\/\/pndo.ly\/RNKTcB",
        "display_url" : "pndo.ly\/RNKTcB"
      } ]
    },
    "geo" : { },
    "id_str" : "472846019437162496",
    "text" : "eBay Shrugged: Pierre Omidyar believes there should be no philanthropy without profit http:\/\/t.co\/j9a4eshUBG",
    "id" : 472846019437162496,
    "created_at" : "2014-05-31 21:04:10 +0000",
    "user" : {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "protected" : false,
      "id_str" : "419710142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618599793888239616\/cnNK6_VF_normal.png",
      "id" : 419710142,
      "verified" : false
    }
  },
  "id" : 473430100390985728,
  "created_at" : "2014-06-02 11:45:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fumiaki Nishihara",
      "screen_name" : "f_nisihara",
      "indices" : [ 3, 14 ],
      "id_str" : "138904193",
      "id" : 138904193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jsU2ibPcoD",
      "expanded_url" : "http:\/\/www.prooffreader.com\/2014\/05\/graphing-distribution-of-english.html",
      "display_url" : "prooffreader.com\/2014\/05\/graphi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473390739976896512",
  "text" : "RT @f_nisihara: \u82F1\u8A9E\u306E\u6587\u5B57\u304C\u5358\u8A9E\u306E\u3069\u3053\u306B\u73FE\u308C\u308B\u304B\u3092\u30B0\u30E9\u30D5\u306B\u3002 - Graphing the distribution of English letters towards the beginning, middle or end of words http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/jsU2ibPcoD",
        "expanded_url" : "http:\/\/www.prooffreader.com\/2014\/05\/graphing-distribution-of-english.html",
        "display_url" : "prooffreader.com\/2014\/05\/graphi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473241736378974208",
    "text" : "\u82F1\u8A9E\u306E\u6587\u5B57\u304C\u5358\u8A9E\u306E\u3069\u3053\u306B\u73FE\u308C\u308B\u304B\u3092\u30B0\u30E9\u30D5\u306B\u3002 - Graphing the distribution of English letters towards the beginning, middle or end of words http:\/\/t.co\/jsU2ibPcoD",
    "id" : 473241736378974208,
    "created_at" : "2014-06-01 23:16:37 +0000",
    "user" : {
      "name" : "Fumiaki Nishihara",
      "screen_name" : "f_nisihara",
      "protected" : false,
      "id_str" : "138904193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462918112141004801\/cXwoBhir_normal.jpeg",
      "id" : 138904193,
      "verified" : false
    }
  },
  "id" : 473390739976896512,
  "created_at" : "2014-06-02 09:08:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/FMUsFCrTCE",
      "expanded_url" : "http:\/\/downloads.bbc.co.uk\/radio2\/500words\/oup-report.pdf",
      "display_url" : "downloads.bbc.co.uk\/radio2\/500word\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "473376402172289024",
  "geo" : { },
  "id_str" : "473381581747671040",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike there's some interesting analysis of the stories here http:\/\/t.co\/FMUsFCrTCE",
  "id" : 473381581747671040,
  "in_reply_to_status_id" : 473376402172289024,
  "created_at" : "2014-06-02 08:32:18 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/WD8br7MiQZ",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2014\/5\/29\/155324\/271",
      "display_url" : "eurotrib.com\/story\/2014\/5\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473012956926857216",
  "text" : "Counting the MEPs http:\/\/t.co\/WD8br7MiQZ",
  "id" : 473012956926857216,
  "created_at" : "2014-06-01 08:07:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472834209510621186",
  "geo" : { },
  "id_str" : "473012532584910848",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco :)",
  "id" : 473012532584910848,
  "in_reply_to_status_id" : 472834209510621186,
  "created_at" : "2014-06-01 08:05:50 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]