Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weidenbaum",
      "screen_name" : "disquiet",
      "indices" : [ 3, 12 ],
      "id_str" : "6943192",
      "id" : 6943192
    }, {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 109, 124 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XR3q1qCpCm",
      "expanded_url" : "http:\/\/buff.ly\/1ajPNVG",
      "display_url" : "buff.ly\/1ajPNVG"
    } ]
  },
  "geo" : { },
  "id_str" : "351290285222936576",
  "text" : "MT @disquiet If you only have time for one long read about music today, Rick Rubin http:\/\/t.co\/XR3q1qCpCm cc @4tunetellernet",
  "id" : 351290285222936576,
  "created_at" : "2013-06-30 10:45:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/59RZ0GK9kO",
      "expanded_url" : "http:\/\/www.palmsounds.net\/",
      "display_url" : "palmsounds.net"
    } ]
  },
  "geo" : { },
  "id_str" : "351094134683074560",
  "text" : "@harrisonmike you could try searching http:\/\/t.co\/59RZ0GK9kO",
  "id" : 351094134683074560,
  "created_at" : "2013-06-29 21:45:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "jeremy scahill",
      "screen_name" : "jeremyscahill",
      "indices" : [ 92, 106 ],
      "id_str" : "23839835",
      "id" : 23839835
    }, {
      "name" : "Sherry Wolf",
      "screen_name" : "SherryTalksBack",
      "indices" : [ 113, 129 ],
      "id_str" : "188442476",
      "id" : 188442476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 130, 144 ],
      "url" : "http:\/\/t.co\/DlgG1PnRKv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Uulv4ve6RJ8&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=Uulv4v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351093765374611456",
  "text" : "RT @ggreenwald: Here's the speech I gave tonight at the Socialism Conference, with intro by @jeremyscahill &amp; @SherryTalksBack http:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jeremy scahill",
        "screen_name" : "jeremyscahill",
        "indices" : [ 76, 90 ],
        "id_str" : "23839835",
        "id" : 23839835
      }, {
        "name" : "Sherry Wolf",
        "screen_name" : "SherryTalksBack",
        "indices" : [ 97, 113 ],
        "id_str" : "188442476",
        "id" : 188442476
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/DlgG1PnRKv",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Uulv4ve6RJ8&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=Uulv4v\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350833525165015040",
    "text" : "Here's the speech I gave tonight at the Socialism Conference, with intro by @jeremyscahill &amp; @SherryTalksBack http:\/\/t.co\/DlgG1PnRKv",
    "id" : 350833525165015040,
    "created_at" : "2013-06-29 04:30:05 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 351093765374611456,
  "created_at" : "2013-06-29 21:44:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/eUO9HgUzG8",
      "expanded_url" : "http:\/\/mikelev.in\/ux\/",
      "display_url" : "mikelev.in\/ux\/"
    } ]
  },
  "geo" : { },
  "id_str" : "351075016848318464",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel like yr series on cmd line and text analysis, am using levinux http:\/\/t.co\/eUO9HgUzG8 instead of virt mach install ta",
  "id" : 351075016848318464,
  "created_at" : "2013-06-29 20:29:41 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Xerri",
      "screen_name" : "danielxerri",
      "indices" : [ 0, 12 ],
      "id_str" : "144477800",
      "id" : 144477800
    }, {
      "name" : "NATE",
      "screen_name" : "NATEfeed",
      "indices" : [ 13, 22 ],
      "id_str" : "145634249",
      "id" : 145634249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350915600131948544",
  "geo" : { },
  "id_str" : "350917370795139072",
  "in_reply_to_user_id" : 144477800,
  "text" : "@danielxerri @NATEfeed congrats! is it work on poetry in ELT?",
  "id" : 350917370795139072,
  "in_reply_to_status_id" : 350915600131948544,
  "created_at" : "2013-06-29 10:03:15 +0000",
  "in_reply_to_screen_name" : "danielxerri",
  "in_reply_to_user_id_str" : "144477800",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WhoWhatWhy",
      "screen_name" : "whowhatwhy",
      "indices" : [ 3, 14 ],
      "id_str" : "40094447",
      "id" : 40094447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Occupy",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EHS8V3SQox",
      "expanded_url" : "http:\/\/bit.ly\/1aiS3wH",
      "display_url" : "bit.ly\/1aiS3wH"
    } ]
  },
  "geo" : { },
  "id_str" : "350916204451467265",
  "text" : "RT @whowhatwhy: When #Occupy hit Houston, the severe reaction from law enforcement, banking + big oil included an assassination plot: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Occupy",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/EHS8V3SQox",
        "expanded_url" : "http:\/\/bit.ly\/1aiS3wH",
        "display_url" : "bit.ly\/1aiS3wH"
      } ]
    },
    "geo" : { },
    "id_str" : "350812930712940544",
    "text" : "When #Occupy hit Houston, the severe reaction from law enforcement, banking + big oil included an assassination plot: http:\/\/t.co\/EHS8V3SQox",
    "id" : 350812930712940544,
    "created_at" : "2013-06-29 03:08:15 +0000",
    "user" : {
      "name" : "WhoWhatWhy",
      "screen_name" : "whowhatwhy",
      "protected" : false,
      "id_str" : "40094447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657990318214656001\/uuezzM66_normal.jpg",
      "id" : 40094447,
      "verified" : false
    }
  },
  "id" : 350916204451467265,
  "created_at" : "2013-06-29 09:58:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 3, 16 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/prdoUEa86y",
      "expanded_url" : "http:\/\/crayonslookbetterthantheytaste.blogspot.fr\/2013\/06\/what-people-love-to-do.html",
      "display_url" : "\u2026nslookbetterthantheytaste.blogspot.fr\/2013\/06\/what-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350725132035174400",
  "text" : "RT @Timothy_Tate: What People Love To Do http:\/\/t.co\/prdoUEa86y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/prdoUEa86y",
        "expanded_url" : "http:\/\/crayonslookbetterthantheytaste.blogspot.fr\/2013\/06\/what-people-love-to-do.html",
        "display_url" : "\u2026nslookbetterthantheytaste.blogspot.fr\/2013\/06\/what-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350708796873650176",
    "text" : "What People Love To Do http:\/\/t.co\/prdoUEa86y",
    "id" : 350708796873650176,
    "created_at" : "2013-06-28 20:14:27 +0000",
    "user" : {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "protected" : false,
      "id_str" : "1084531170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578723900\/41c4d3a262e0defc1126475c46be261f_normal.jpeg",
      "id" : 1084531170,
      "verified" : false
    }
  },
  "id" : 350725132035174400,
  "created_at" : "2013-06-28 21:19:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    }, {
      "name" : "Daisy Christodoulou",
      "screen_name" : "daisychristo",
      "indices" : [ 65, 78 ],
      "id_str" : "220830660",
      "id" : 220830660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/emOOBzOmnn",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/e-d-hirsch-jr\/a-gamechanging-education-_b_3511679.html",
      "display_url" : "huffingtonpost.com\/e-d-hirsch-jr\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350668211550818305",
  "text" : "RT @DTWillingham: A game-changing book!!\" http:\/\/t.co\/emOOBzOmnn @daisychristo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daisy Christodoulou",
        "screen_name" : "daisychristo",
        "indices" : [ 47, 60 ],
        "id_str" : "220830660",
        "id" : 220830660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/emOOBzOmnn",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/e-d-hirsch-jr\/a-gamechanging-education-_b_3511679.html",
        "display_url" : "huffingtonpost.com\/e-d-hirsch-jr\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350355406222131200",
    "text" : "A game-changing book!!\" http:\/\/t.co\/emOOBzOmnn @daisychristo",
    "id" : 350355406222131200,
    "created_at" : "2013-06-27 20:50:12 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 350668211550818305,
  "created_at" : "2013-06-28 17:33:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/DetzzdNfR1",
      "expanded_url" : "http:\/\/www.zcommunications.org\/obama-retreats-on-snowden-by-mark-weisbrot",
      "display_url" : "zcommunications.org\/obama-retreats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350665410892398593",
  "text" : "Obama retreats on Snowden http:\/\/t.co\/DetzzdNfR1",
  "id" : 350665410892398593,
  "created_at" : "2013-06-28 17:22:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/hCbGxKtie0",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1h1cyg\/whats_the_most_intellectual_joke_you_know\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350658132357296128",
  "text" : "RT @gsiemens: There's a band called 1023MB. They haven't had any gigs yet.\nhttp:\/\/t.co\/hCbGxKtie0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/hCbGxKtie0",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1h1cyg\/whats_the_most_intellectual_joke_you_know\/",
        "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350629567016345600",
    "text" : "There's a band called 1023MB. They haven't had any gigs yet.\nhttp:\/\/t.co\/hCbGxKtie0",
    "id" : 350629567016345600,
    "created_at" : "2013-06-28 14:59:37 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 350658132357296128,
  "created_at" : "2013-06-28 16:53:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/lYeI7YMP97",
      "expanded_url" : "http:\/\/ow.ly\/msXRK",
      "display_url" : "ow.ly\/msXRK"
    } ]
  },
  "geo" : { },
  "id_str" : "350649964906553345",
  "text" : "RT @medialens: New media alert: Snowden, Surveillance And The Secret State http:\/\/t.co\/lYeI7YMP97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/lYeI7YMP97",
        "expanded_url" : "http:\/\/ow.ly\/msXRK",
        "display_url" : "ow.ly\/msXRK"
      } ]
    },
    "geo" : { },
    "id_str" : "350588100919046144",
    "text" : "New media alert: Snowden, Surveillance And The Secret State http:\/\/t.co\/lYeI7YMP97",
    "id" : 350588100919046144,
    "created_at" : "2013-06-28 12:14:51 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 350649964906553345,
  "created_at" : "2013-06-28 16:20:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "indices" : [ 0, 12 ],
      "id_str" : "18225967",
      "id" : 18225967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/JuqlvDxCxy",
      "expanded_url" : "http:\/\/youtu.be\/maZOy3ep0e8",
      "display_url" : "youtu.be\/maZOy3ep0e8"
    } ]
  },
  "geo" : { },
  "id_str" : "350647216186204163",
  "in_reply_to_user_id" : 18225967,
  "text" : "@akirathedon ft. Footsie and Big Narstie  Games For The Thrones http:\/\/t.co\/JuqlvDxCxy &lt; top tune tide me over till new season :)",
  "id" : 350647216186204163,
  "created_at" : "2013-06-28 16:09:45 +0000",
  "in_reply_to_screen_name" : "akirathedon",
  "in_reply_to_user_id_str" : "18225967",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/0PhkPE4RJR",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MFArNyjerTY",
      "display_url" : "youtube.com\/watch?v=MFArNy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350627686839885825",
  "text" : "learned some new idioms - skin in the game, ducks and drakes - Anglo Irish Bank tapes - https:\/\/t.co\/0PhkPE4RJR",
  "id" : 350627686839885825,
  "created_at" : "2013-06-28 14:52:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Gijs Hillenius",
      "screen_name" : "Sjig",
      "indices" : [ 17, 22 ],
      "id_str" : "9769712",
      "id" : 9769712
    }, {
      "name" : "April",
      "screen_name" : "aprilorg",
      "indices" : [ 96, 105 ],
      "id_str" : "48363178",
      "id" : 48363178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "joinup",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "openscot",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BPI1iI9l1G",
      "expanded_url" : "https:\/\/joinup.ec.europa.eu\/community\/osor\/news\/french-parliament-says-free-software-priority-education",
      "display_url" : "joinup.ec.europa.eu\/community\/osor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350571316870524929",
  "text" : "RT @mhawksey: RT @Sjig: French parliament says free software is a priority in education #joinup @aprilorg https:\/\/t.co\/BPI1iI9l1G &lt;#openscot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gijs Hillenius",
        "screen_name" : "Sjig",
        "indices" : [ 3, 8 ],
        "id_str" : "9769712",
        "id" : 9769712
      }, {
        "name" : "April",
        "screen_name" : "aprilorg",
        "indices" : [ 82, 91 ],
        "id_str" : "48363178",
        "id" : 48363178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "joinup",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "openscot",
        "indices" : [ 120, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/BPI1iI9l1G",
        "expanded_url" : "https:\/\/joinup.ec.europa.eu\/community\/osor\/news\/french-parliament-says-free-software-priority-education",
        "display_url" : "joinup.ec.europa.eu\/community\/osor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350568172526649345",
    "text" : "RT @Sjig: French parliament says free software is a priority in education #joinup @aprilorg https:\/\/t.co\/BPI1iI9l1G &lt;#openscot",
    "id" : 350568172526649345,
    "created_at" : "2013-06-28 10:55:40 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 350571316870524929,
  "created_at" : "2013-06-28 11:08:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/hCbGxKtie0",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1h1cyg\/whats_the_most_intellectual_joke_you_know\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350559931730116608",
  "text" : "RT @gsiemens: Can spend hours here: What's the most intellectual joke you know? http:\/\/t.co\/hCbGxKtie0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/hCbGxKtie0",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1h1cyg\/whats_the_most_intellectual_joke_you_know\/",
        "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350521730688757760",
    "text" : "Can spend hours here: What's the most intellectual joke you know? http:\/\/t.co\/hCbGxKtie0",
    "id" : 350521730688757760,
    "created_at" : "2013-06-28 07:51:07 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 350559931730116608,
  "created_at" : "2013-06-28 10:22:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Phil Keegan",
      "screen_name" : "PhilKeegan66",
      "indices" : [ 11, 24 ],
      "id_str" : "919161703",
      "id" : 919161703
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 25, 31 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/AUciAE2JS1",
      "expanded_url" : "http:\/\/books.google.com\/ngrams\/graph?content=learning+styles%2Cstyles%2C+learning&year_start=1800&year_end=2000&corpus=15&smoothing=3&share=",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "350339323746467840",
  "geo" : { },
  "id_str" : "350346250694049792",
  "in_reply_to_user_id" : 18602422,
  "text" : "@jo_sayers @PhilKeegan66 @EBEFL http:\/\/t.co\/AUciAE2JS1",
  "id" : 350346250694049792,
  "in_reply_to_status_id" : 350339323746467840,
  "created_at" : "2013-06-27 20:13:49 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Trip Kirkpatrick",
      "screen_name" : "triplingual",
      "indices" : [ 67, 79 ],
      "id_str" : "128196131",
      "id" : 128196131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/pxLYfc3Xce",
      "expanded_url" : "http:\/\/bit.ly\/10YmW6u",
      "display_url" : "bit.ly\/10YmW6u"
    } ]
  },
  "geo" : { },
  "id_str" : "350342522582745089",
  "text" : "RT @heatherfro: universities on github http:\/\/t.co\/pxLYfc3Xce (via @triplingual)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trip Kirkpatrick",
        "screen_name" : "triplingual",
        "indices" : [ 51, 63 ],
        "id_str" : "128196131",
        "id" : 128196131
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/pxLYfc3Xce",
        "expanded_url" : "http:\/\/bit.ly\/10YmW6u",
        "display_url" : "bit.ly\/10YmW6u"
      } ]
    },
    "geo" : { },
    "id_str" : "350228216251822080",
    "text" : "universities on github http:\/\/t.co\/pxLYfc3Xce (via @triplingual)",
    "id" : 350228216251822080,
    "created_at" : "2013-06-27 12:24:48 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 350342522582745089,
  "created_at" : "2013-06-27 19:59:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Phil Keegan",
      "screen_name" : "PhilKeegan66",
      "indices" : [ 11, 24 ],
      "id_str" : "919161703",
      "id" : 919161703
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 25, 31 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350334690500161537",
  "geo" : { },
  "id_str" : "350339323746467840",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @PhilKeegan66 @EBEFL more contrast ;)",
  "id" : 350339323746467840,
  "in_reply_to_status_id" : 350334690500161537,
  "created_at" : "2013-06-27 19:46:18 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/K3FOplCANA",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/education\/2013\/jun\/27\/teachers-strike-one-day-walkout",
      "display_url" : "guardian.co.uk\/education\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350213242192281600",
  "text" : "Thousands of teachers join one-day strike http:\/\/t.co\/K3FOplCANA",
  "id" : 350213242192281600,
  "created_at" : "2013-06-27 11:25:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Tim Ferriss",
      "screen_name" : "tferriss",
      "indices" : [ 48, 57 ],
      "id_str" : "11740902",
      "id" : 11740902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/UnROtGnktj",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-FA",
      "display_url" : "wp.me\/p2hCXG-FA"
    } ]
  },
  "geo" : { },
  "id_str" : "350212254328819712",
  "text" : "RT @MrChrisJWilson: Here we go, Picking a fight @tferriss \"Get Language quick scheme\" my short response. #eltchat http:\/\/t.co\/UnROtGnktj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Ferriss",
        "screen_name" : "tferriss",
        "indices" : [ 28, 37 ],
        "id_str" : "11740902",
        "id" : 11740902
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/UnROtGnktj",
        "expanded_url" : "http:\/\/wp.me\/p2hCXG-FA",
        "display_url" : "wp.me\/p2hCXG-FA"
      } ]
    },
    "geo" : { },
    "id_str" : "350204416651034625",
    "text" : "Here we go, Picking a fight @tferriss \"Get Language quick scheme\" my short response. #eltchat http:\/\/t.co\/UnROtGnktj",
    "id" : 350204416651034625,
    "created_at" : "2013-06-27 10:50:14 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 350212254328819712,
  "created_at" : "2013-06-27 11:21:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Sue Gardner",
      "screen_name" : "SuePGardner",
      "indices" : [ 16, 28 ],
      "id_str" : "151774839",
      "id" : 151774839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9h3ZpBFARm",
      "expanded_url" : "http:\/\/wp.me\/pZNtT-rN",
      "display_url" : "wp.me\/pZNtT-rN"
    } ]
  },
  "geo" : { },
  "id_str" : "350199575375654912",
  "text" : "RT @KateMfD: RT @SuePGardner: The war for the free and open internet -- and how we are losing it http:\/\/t.co\/9h3ZpBFARm &lt; relevant also to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sue Gardner",
        "screen_name" : "SuePGardner",
        "indices" : [ 3, 15 ],
        "id_str" : "151774839",
        "id" : 151774839
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/9h3ZpBFARm",
        "expanded_url" : "http:\/\/wp.me\/pZNtT-rN",
        "display_url" : "wp.me\/pZNtT-rN"
      } ]
    },
    "geo" : { },
    "id_str" : "350109407138422784",
    "text" : "RT @SuePGardner: The war for the free and open internet -- and how we are losing it http:\/\/t.co\/9h3ZpBFARm &lt; relevant also to open education",
    "id" : 350109407138422784,
    "created_at" : "2013-06-27 04:32:42 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 350199575375654912,
  "created_at" : "2013-06-27 10:30:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "GIPHY",
      "screen_name" : "giphy",
      "indices" : [ 110, 116 ],
      "id_str" : "1020383864",
      "id" : 1020383864
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ds106",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/30AiKk7JbR",
      "expanded_url" : "http:\/\/gph.is\/YBem7n",
      "display_url" : "gph.is\/YBem7n"
    } ]
  },
  "geo" : { },
  "id_str" : "350196748616073216",
  "text" : "RT @cogdog: Uh oh, this is going to be #ds106 huge Giphy- a search engine for GIFs http:\/\/t.co\/30AiKk7JbR via @giphy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GIPHY",
        "screen_name" : "giphy",
        "indices" : [ 98, 104 ],
        "id_str" : "1020383864",
        "id" : 1020383864
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ds106",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/30AiKk7JbR",
        "expanded_url" : "http:\/\/gph.is\/YBem7n",
        "display_url" : "gph.is\/YBem7n"
      } ]
    },
    "geo" : { },
    "id_str" : "349990586364862465",
    "text" : "Uh oh, this is going to be #ds106 huge Giphy- a search engine for GIFs http:\/\/t.co\/30AiKk7JbR via @giphy",
    "id" : 349990586364862465,
    "created_at" : "2013-06-26 20:40:32 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 350196748616073216,
  "created_at" : "2013-06-27 10:19:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/b7JvSg2mXF",
      "expanded_url" : "http:\/\/bit.ly\/19EtYxh",
      "display_url" : "bit.ly\/19EtYxh"
    } ]
  },
  "geo" : { },
  "id_str" : "350195575767052288",
  "text" : "RT @wiobyrne: Pew Research: Younger folks are reading books, using libraries after all #edchat http:\/\/t.co\/b7JvSg2mXF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/b7JvSg2mXF",
        "expanded_url" : "http:\/\/bit.ly\/19EtYxh",
        "display_url" : "bit.ly\/19EtYxh"
      } ]
    },
    "geo" : { },
    "id_str" : "350193031703568384",
    "text" : "Pew Research: Younger folks are reading books, using libraries after all #edchat http:\/\/t.co\/b7JvSg2mXF",
    "id" : 350193031703568384,
    "created_at" : "2013-06-27 10:04:59 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 350195575767052288,
  "created_at" : "2013-06-27 10:15:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350193692360978433",
  "geo" : { },
  "id_str" : "350194405145182208",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman a great article slightly less entertaining to read w\/o the jeffrey archer of ELT paragraph ;)",
  "id" : 350194405145182208,
  "in_reply_to_status_id" : 350193692360978433,
  "created_at" : "2013-06-27 10:10:27 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/kaB3XlsjQR",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/business-22688596",
      "display_url" : "bbc.co.uk\/news\/business-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350189837539741698",
  "text" : "RT @TonyMcEnery: Mapping children's chances - a thought provoking set of maps: http:\/\/t.co\/kaB3XlsjQR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/kaB3XlsjQR",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/business-22688596",
        "display_url" : "bbc.co.uk\/news\/business-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350153358696398848",
    "text" : "Mapping children's chances - a thought provoking set of maps: http:\/\/t.co\/kaB3XlsjQR",
    "id" : 350153358696398848,
    "created_at" : "2013-06-27 07:27:20 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 350189837539741698,
  "created_at" : "2013-06-27 09:52:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YekRqp4DUv",
      "expanded_url" : "http:\/\/bit.ly\/136xOiJ",
      "display_url" : "bit.ly\/136xOiJ"
    } ]
  },
  "geo" : { },
  "id_str" : "350026182613405699",
  "text" : "RT @CraigMurrayOrg: Pandering to Racism: Here in Ghana people are stunned by the announcement that a bond of \u00A33,000 will have to b... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/YekRqp4DUv",
        "expanded_url" : "http:\/\/bit.ly\/136xOiJ",
        "display_url" : "bit.ly\/136xOiJ"
      } ]
    },
    "geo" : { },
    "id_str" : "349889299459743745",
    "text" : "Pandering to Racism: Here in Ghana people are stunned by the announcement that a bond of \u00A33,000 will have to b... http:\/\/t.co\/YekRqp4DUv",
    "id" : 349889299459743745,
    "created_at" : "2013-06-26 13:58:04 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 350026182613405699,
  "created_at" : "2013-06-26 23:01:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/3vfm60DzMb",
      "expanded_url" : "https:\/\/juergenkurtz.wordpress.com\/2013\/06\/05\/the-dortmund-historical-corpus-of-classroom-english-dohcce\/",
      "display_url" : "juergenkurtz.wordpress.com\/2013\/06\/05\/the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "349983836408516608",
  "geo" : { },
  "id_str" : "349985447579107328",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C there's some int analysis projects e.g. The Dortmund Historical Corpus of Classroom English https:\/\/t.co\/3vfm60DzMb #eltchat",
  "id" : 349985447579107328,
  "in_reply_to_status_id" : 349983836408516608,
  "created_at" : "2013-06-26 20:20:07 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 100, 116 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/WxGsnmiyqJ",
      "expanded_url" : "http:\/\/wp.me\/p3kgbw-jU",
      "display_url" : "wp.me\/p3kgbw-jU"
    } ]
  },
  "geo" : { },
  "id_str" : "349849195097751553",
  "text" : "a speaking activity on degree modifiers (comparatives and superlatives): http:\/\/t.co\/WxGsnmiyqJ via @wordpressdotcom",
  "id" : 349849195097751553,
  "created_at" : "2013-06-26 11:18:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349644285878091777",
  "geo" : { },
  "id_str" : "349651484989861888",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell need to get some more popcorn! :)",
  "id" : 349651484989861888,
  "in_reply_to_status_id" : 349644285878091777,
  "created_at" : "2013-06-25 22:13:04 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arika Okrent",
      "screen_name" : "arikaokrent",
      "indices" : [ 3, 15 ],
      "id_str" : "47226743",
      "id" : 47226743
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 139, 140 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/7QzNTzLnYF",
      "expanded_url" : "http:\/\/shar.es\/xOThA",
      "display_url" : "shar.es\/xOThA"
    } ]
  },
  "geo" : { },
  "id_str" : "349635712531959808",
  "text" : "RT @arikaokrent: Corpus linguists sees what we can't. 4 Changes to English So Subtle We Hardly Notice They're Happening http:\/\/t.co\/7QzNTzL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 130, 140 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/7QzNTzLnYF",
        "expanded_url" : "http:\/\/shar.es\/xOThA",
        "display_url" : "shar.es\/xOThA"
      } ]
    },
    "geo" : { },
    "id_str" : "349607841507704832",
    "text" : "Corpus linguists sees what we can't. 4 Changes to English So Subtle We Hardly Notice They're Happening http:\/\/t.co\/7QzNTzLnYF via @sharethis",
    "id" : 349607841507704832,
    "created_at" : "2013-06-25 19:19:39 +0000",
    "user" : {
      "name" : "Arika Okrent",
      "screen_name" : "arikaokrent",
      "protected" : false,
      "id_str" : "47226743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501813553200779264\/_JlNpDLs_normal.jpeg",
      "id" : 47226743,
      "verified" : true
    }
  },
  "id" : 349635712531959808,
  "created_at" : "2013-06-25 21:10:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Vaughan Bell",
      "screen_name" : "vaughanbell",
      "indices" : [ 120, 132 ],
      "id_str" : "20542737",
      "id" : 20542737
    }, {
      "name" : "Michael Cavaretta",
      "screen_name" : "mjcavaretta",
      "indices" : [ 133, 140 ],
      "id_str" : "38670441",
      "id" : 38670441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/sgW521LXlt",
      "expanded_url" : "http:\/\/ow.ly\/1Y0ptH",
      "display_url" : "ow.ly\/1Y0ptH"
    } ]
  },
  "geo" : { },
  "id_str" : "349591926288297984",
  "text" : "RT @TSchnoebelen: \"Where's my talking robot?\" Artificial intelligence is already all around you: http:\/\/t.co\/sgW521LXlt @vaughanbell @mjcav\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vaughan Bell",
        "screen_name" : "vaughanbell",
        "indices" : [ 102, 114 ],
        "id_str" : "20542737",
        "id" : 20542737
      }, {
        "name" : "Michael Cavaretta",
        "screen_name" : "mjcavaretta",
        "indices" : [ 115, 127 ],
        "id_str" : "38670441",
        "id" : 38670441
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/sgW521LXlt",
        "expanded_url" : "http:\/\/ow.ly\/1Y0ptH",
        "display_url" : "ow.ly\/1Y0ptH"
      } ]
    },
    "geo" : { },
    "id_str" : "349568959676284928",
    "text" : "\"Where's my talking robot?\" Artificial intelligence is already all around you: http:\/\/t.co\/sgW521LXlt @vaughanbell @mjcavaretta",
    "id" : 349568959676284928,
    "created_at" : "2013-06-25 16:45:09 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 349591926288297984,
  "created_at" : "2013-06-25 18:16:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "NSA PRISM",
      "screen_name" : "NSA_PRISMbot",
      "indices" : [ 23, 36 ],
      "id_str" : "1539693919",
      "id" : 1539693919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349588743054835712",
  "text" : "RT @samplereality: The @NSA_PRISMbot is an experiment in \"speculative surveillance.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NSA PRISM",
        "screen_name" : "NSA_PRISMbot",
        "indices" : [ 4, 17 ],
        "id_str" : "1539693919",
        "id" : 1539693919
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349524379778035713",
    "text" : "The @NSA_PRISMbot is an experiment in \"speculative surveillance.\"",
    "id" : 349524379778035713,
    "created_at" : "2013-06-25 13:48:00 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 349588743054835712,
  "created_at" : "2013-06-25 18:03:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349506057271390211",
  "text" : "@harrisonmike sound! am interested in online teaching so will follow yr project with grt interest, will also fill in yr survey asap",
  "id" : 349506057271390211,
  "created_at" : "2013-06-25 12:35:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/KKaLV5Jbdr",
      "expanded_url" : "https:\/\/www.wsws.org\/en\/articles\/2013\/06\/25\/infr-j25.html",
      "display_url" : "wsws.org\/en\/articles\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349466598370840577",
  "text" : "The NSA\u2019s cyber-surveillance technology:\nInfrastructure of a police state https:\/\/t.co\/KKaLV5Jbdr",
  "id" : 349466598370840577,
  "created_at" : "2013-06-25 09:58:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 3, 14 ],
      "id_str" : "90695737",
      "id" : 90695737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cdnelt",
      "indices" : [ 94, 101 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 102, 110 ]
    }, {
      "text" : "auselt",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "eltindia",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/UCtBRndACb",
      "expanded_url" : "http:\/\/www.yorksj.ac.uk\/changing-englishes\/changing-englishes.aspx",
      "display_url" : "yorksj.ac.uk\/changing-engli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349454293738340352",
  "text" : "RT @yvetteinmb: Changing Englishes: An Interactive Course for Teachers http:\/\/t.co\/UCtBRndACb #cdnelt #eltchat #auselt #eltindia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cdnelt",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 86, 94 ]
      }, {
        "text" : "auselt",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "eltindia",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/UCtBRndACb",
        "expanded_url" : "http:\/\/www.yorksj.ac.uk\/changing-englishes\/changing-englishes.aspx",
        "display_url" : "yorksj.ac.uk\/changing-engli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349363678241505281",
    "text" : "Changing Englishes: An Interactive Course for Teachers http:\/\/t.co\/UCtBRndACb #cdnelt #eltchat #auselt #eltindia",
    "id" : 349363678241505281,
    "created_at" : "2013-06-25 03:09:26 +0000",
    "user" : {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "protected" : false,
      "id_str" : "90695737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557709684782542848\/F-hkOiI5_normal.jpeg",
      "id" : 90695737,
      "verified" : false
    }
  },
  "id" : 349454293738340352,
  "created_at" : "2013-06-25 09:09:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349310395988713472",
  "geo" : { },
  "id_str" : "349447531048087553",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman thanks for sharing matthew :)",
  "id" : 349447531048087553,
  "in_reply_to_status_id" : 349310395988713472,
  "created_at" : "2013-06-25 08:42:38 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/RMG2wOzAUP",
      "expanded_url" : "https:\/\/posthegemony.wordpress.com\/2013\/06\/24\/warwick-university-ltd\/",
      "display_url" : "posthegemony.wordpress.com\/2013\/06\/24\/war\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349446967526572032",
  "text" : "Warwick University Ltd https:\/\/t.co\/RMG2wOzAUP",
  "id" : 349446967526572032,
  "created_at" : "2013-06-25 08:40:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gXNLP6bqv2",
      "expanded_url" : "http:\/\/givememydata.com\/",
      "display_url" : "givememydata.com"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/c8pE7yZTDl",
      "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/06\/fun-with-facebook-in-neo4j_19.html",
      "display_url" : "blog.neo4j.org\/2013\/06\/fun-wi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349210540322721793",
  "text" : "for any mark zuckerberg website users nifty tool to d\/l your data http:\/\/t.co\/gXNLP6bqv2 HT http:\/\/t.co\/c8pE7yZTDl",
  "id" : 349210540322721793,
  "created_at" : "2013-06-24 17:00:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Sheila MacNeill",
      "screen_name" : "sheilmcn",
      "indices" : [ 17, 26 ],
      "id_str" : "4013641",
      "id" : 4013641
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 111, 120 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ddj",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/GQnCmdba4n",
      "expanded_url" : "http:\/\/gu.com\/p\/3gm4n\/tw",
      "display_url" : "gu.com\/p\/3gm4n\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "349151861791666176",
  "text" : "RT @mhawksey: RT @sheilmcn: don't underestimate the extraordinary power of metadata http:\/\/t.co\/GQnCmdba4n via @guardian &lt; #ddj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sheila MacNeill",
        "screen_name" : "sheilmcn",
        "indices" : [ 3, 12 ],
        "id_str" : "4013641",
        "id" : 4013641
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 97, 106 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ddj",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/GQnCmdba4n",
        "expanded_url" : "http:\/\/gu.com\/p\/3gm4n\/tw",
        "display_url" : "gu.com\/p\/3gm4n\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "349054775788183552",
    "text" : "RT @sheilmcn: don't underestimate the extraordinary power of metadata http:\/\/t.co\/GQnCmdba4n via @guardian &lt; #ddj",
    "id" : 349054775788183552,
    "created_at" : "2013-06-24 06:41:58 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 349151861791666176,
  "created_at" : "2013-06-24 13:07:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/Vl8zpYutFm",
      "expanded_url" : "http:\/\/youtu.be\/wHldbXh42vo",
      "display_url" : "youtu.be\/wHldbXh42vo"
    } ]
  },
  "geo" : { },
  "id_str" : "349136165233905664",
  "text" : "Interview #16 Deepa Naik Trenton Oldfield: http:\/\/t.co\/Vl8zpYutFm via @youtube",
  "id" : 349136165233905664,
  "created_at" : "2013-06-24 12:05:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/hCLzwjCJNN",
      "expanded_url" : "http:\/\/www.comicsenglish.com\/",
      "display_url" : "comicsenglish.com"
    }, {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/fVnmB5CLIL",
      "expanded_url" : "http:\/\/engineeringasaforeignlanguage.blogspot.com\/",
      "display_url" : "\u2026eeringasaforeignlanguage.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "349126613935484929",
  "text" : "grt site &gt;Comics English http:\/\/t.co\/hCLzwjCJNN HT \nhttp:\/\/t.co\/fVnmB5CLIL  #eltchat",
  "id" : 349126613935484929,
  "created_at" : "2013-06-24 11:27:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0424\u0438\u043B\u0430\u0442\u043E\u0432a \u042D\u043B\u0435\u043E\u043D\u043E\u0440\u0430",
      "screen_name" : "redorgreenpen",
      "indices" : [ 98, 112 ],
      "id_str" : "2814154033",
      "id" : 2814154033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/nJuHTLfK6Z",
      "expanded_url" : "http:\/\/wp.me\/p2zYmj-1Sq",
      "display_url" : "wp.me\/p2zYmj-1Sq"
    } ]
  },
  "geo" : { },
  "id_str" : "349121100329918464",
  "text" : "Things not to say to trainee teachers #1: \"just focus on the learning\" http:\/\/t.co\/nJuHTLfK6Z via @redorgreenpen",
  "id" : 349121100329918464,
  "created_at" : "2013-06-24 11:05:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 125, 140 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/wD44Xou7P5",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-1F",
      "display_url" : "wp.me\/p35kaI-1F"
    } ]
  },
  "geo" : { },
  "id_str" : "349115371476889601",
  "text" : "Obviously: The Week Bin Laden Died A Corpus Linguistic Study of an Evaluation Strategy Employed \u2026 http:\/\/t.co\/wD44Xou7P5 via @AndrewBrindle2",
  "id" : 349115371476889601,
  "created_at" : "2013-06-24 10:42:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 0, 15 ],
      "id_str" : "15143478",
      "id" : 15143478
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 16, 29 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/3t5Dz3qup6",
      "expanded_url" : "https:\/\/www.xkcd.com\/1227\/",
      "display_url" : "xkcd.com\/1227\/"
    } ]
  },
  "in_reply_to_status_id_str" : "348782758660829184",
  "geo" : { },
  "id_str" : "349112509548068864",
  "in_reply_to_user_id" : 15143478,
  "text" : "@RichardDawkins @perezparedes this xkcd seems appropriate https:\/\/t.co\/3t5Dz3qup6 ;)",
  "id" : 349112509548068864,
  "in_reply_to_status_id" : 348782758660829184,
  "created_at" : "2013-06-24 10:31:23 +0000",
  "in_reply_to_screen_name" : "RichardDawkins",
  "in_reply_to_user_id_str" : "15143478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/fCzOuj685C",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/06\/22\/no-iste13",
      "display_url" : "hackeducation.com\/2013\/06\/22\/no-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348837000301912065",
  "text" : "RT @audreywatters: On (Not) Missing ISTE 2013 http:\/\/t.co\/fCzOuj685C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/fCzOuj685C",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/06\/22\/no-iste13",
        "display_url" : "hackeducation.com\/2013\/06\/22\/no-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "348814936887144450",
    "text" : "On (Not) Missing ISTE 2013 http:\/\/t.co\/fCzOuj685C",
    "id" : 348814936887144450,
    "created_at" : "2013-06-23 14:48:56 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 348837000301912065,
  "created_at" : "2013-06-23 16:16:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "people's assembly",
      "screen_name" : "peopleassembly",
      "indices" : [ 55, 70 ],
      "id_str" : "177630380",
      "id" : 177630380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeoplesAssembly",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/oIC3UBzXuj",
      "expanded_url" : "http:\/\/thepeoplesassembly.org.uk\/",
      "display_url" : "thepeoplesassembly.org.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "348466619091148803",
  "text" : "Francesca Martinez speaking now http:\/\/t.co\/oIC3UBzXuj @peopleassembly #PeoplesAssembly",
  "id" : 348466619091148803,
  "created_at" : "2013-06-22 15:44:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "people's assembly",
      "screen_name" : "peopleassembly",
      "indices" : [ 63, 78 ],
      "id_str" : "177630380",
      "id" : 177630380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeoplesAssembly",
      "indices" : [ 79, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/oIC3UBzXuj",
      "expanded_url" : "http:\/\/thepeoplesassembly.org.uk\/",
      "display_url" : "thepeoplesassembly.org.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "348438613656215553",
  "in_reply_to_user_id" : 177630380,
  "text" : "Ken Loach  speaking now (Lecture Hall) http:\/\/t.co\/oIC3UBzXuj \n@peopleassembly #PeoplesAssembly",
  "id" : 348438613656215553,
  "created_at" : "2013-06-22 13:53:33 +0000",
  "in_reply_to_screen_name" : "peopleassembly",
  "in_reply_to_user_id_str" : "177630380",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 3, 14 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/opL0M1Vj6R",
      "expanded_url" : "http:\/\/www.iatefl.org\/membership-information\/iatefl-webinars",
      "display_url" : "iatefl.org\/membership-inf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348437404002160640",
  "text" : "RT @bethcagnol: In 15 minutes (16:00 CET) tune in to watch Penny Ur's webinar. \u2018Using higher order thinking skills\u2019. \nhttp:\/\/t.co\/opL0M1Vj6R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/opL0M1Vj6R",
        "expanded_url" : "http:\/\/www.iatefl.org\/membership-information\/iatefl-webinars",
        "display_url" : "iatefl.org\/membership-inf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "348436170662895616",
    "text" : "In 15 minutes (16:00 CET) tune in to watch Penny Ur's webinar. \u2018Using higher order thinking skills\u2019. \nhttp:\/\/t.co\/opL0M1Vj6R",
    "id" : 348436170662895616,
    "created_at" : "2013-06-22 13:43:51 +0000",
    "user" : {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "protected" : false,
      "id_str" : "27641720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425969412265373696\/jdqAse11_normal.jpeg",
      "id" : 27641720,
      "verified" : false
    }
  },
  "id" : 348437404002160640,
  "created_at" : "2013-06-22 13:48:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 12, 20 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348420501657509890",
  "geo" : { },
  "id_str" : "348428940160946176",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @scoopit the problem of automatic curation, this post seems to have copied pasted wikipedia entry and British Council entry",
  "id" : 348428940160946176,
  "in_reply_to_status_id" : 348420501657509890,
  "created_at" : "2013-06-22 13:15:07 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348404536848834560",
  "text" : "@EBEFL great! and congrats, it is somewhat like going off to the shops ;) don't forget the milk!",
  "id" : 348404536848834560,
  "created_at" : "2013-06-22 11:38:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eHDDZsN9pV",
      "expanded_url" : "http:\/\/www.globalresearch.ca\/racism-and-institutionalised-discrimination-how-israeli-apartheid-is-coming-unstuck\/5339890",
      "display_url" : "globalresearch.ca\/racism-and-ins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348403122751803393",
  "text" : "RT @johnwhilley: Jonathan Cook with a penetrating piece on Israeli apartheid and Netanyahu's fears of being exposed.http:\/\/t.co\/eHDDZsN9pV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/eHDDZsN9pV",
        "expanded_url" : "http:\/\/www.globalresearch.ca\/racism-and-institutionalised-discrimination-how-israeli-apartheid-is-coming-unstuck\/5339890",
        "display_url" : "globalresearch.ca\/racism-and-ins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "348355216854376448",
    "text" : "Jonathan Cook with a penetrating piece on Israeli apartheid and Netanyahu's fears of being exposed.http:\/\/t.co\/eHDDZsN9pV",
    "id" : 348355216854376448,
    "created_at" : "2013-06-22 08:22:10 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 348403122751803393,
  "created_at" : "2013-06-22 11:32:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 3, 15 ],
      "id_str" : "65045121",
      "id" : 65045121
    }, {
      "name" : "People's Assembly",
      "screen_name" : "pplsassembly",
      "indices" : [ 43, 56 ],
      "id_str" : "1247478108",
      "id" : 1247478108
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeoplesAssembly",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/AeTX0z53iG",
      "expanded_url" : "http:\/\/www.thepeoplesassembly.org.uk",
      "display_url" : "thepeoplesassembly.org.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "348401516526321664",
  "text" : "RT @OwenJones84: If you want to follow the @pplsassembly today, follow #PeoplesAssembly or watch the live streaming on http:\/\/t.co\/AeTX0z53\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "People's Assembly",
        "screen_name" : "pplsassembly",
        "indices" : [ 26, 39 ],
        "id_str" : "1247478108",
        "id" : 1247478108
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PeoplesAssembly",
        "indices" : [ 54, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/AeTX0z53iG",
        "expanded_url" : "http:\/\/www.thepeoplesassembly.org.uk",
        "display_url" : "thepeoplesassembly.org.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "348349107196289025",
    "text" : "If you want to follow the @pplsassembly today, follow #PeoplesAssembly or watch the live streaming on http:\/\/t.co\/AeTX0z53iG. Boom.",
    "id" : 348349107196289025,
    "created_at" : "2013-06-22 07:57:53 +0000",
    "user" : {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "protected" : false,
      "id_str" : "65045121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681493332678291457\/swHdHJNr_normal.jpg",
      "id" : 65045121,
      "verified" : true
    }
  },
  "id" : 348401516526321664,
  "created_at" : "2013-06-22 11:26:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Peter Tatchell",
      "screen_name" : "PeterTatchell",
      "indices" : [ 11, 25 ],
      "id_str" : "31135856",
      "id" : 31135856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nonsensewords",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348392235072622593",
  "geo" : { },
  "id_str" : "348394385676845056",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @PeterTatchell muslims killing muslims in a civil war is as descriptive as men killing men in a civil war #nonsensewords",
  "id" : 348394385676845056,
  "in_reply_to_status_id" : 348392235072622593,
  "created_at" : "2013-06-22 10:57:49 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/FD8fKybF2Z",
      "expanded_url" : "http:\/\/xrepublic.tv\/node\/3893",
      "display_url" : "xrepublic.tv\/node\/3893"
    } ]
  },
  "geo" : { },
  "id_str" : "348197007657144321",
  "text" : "Telling it like it is Obama in Ireland http:\/\/t.co\/FD8fKybF2Z",
  "id" : 348197007657144321,
  "created_at" : "2013-06-21 21:53:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "Black Sabbath Fans",
      "screen_name" : "blacksabbathweb",
      "indices" : [ 16, 32 ],
      "id_str" : "1544674646",
      "id" : 1544674646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348189363865268224",
  "geo" : { },
  "id_str" : "348195722904084480",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet @blacksabbathweb sweet changeup at 6:20 :)",
  "id" : 348195722904084480,
  "in_reply_to_status_id" : 348189363865268224,
  "created_at" : "2013-06-21 21:48:24 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "culture",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HWDOrZfK62",
      "expanded_url" : "http:\/\/www.etprofessional.com\/Seeing_the_world_the_English_way__Teaching_English_Or_teaching_English_culture_81022.aspx",
      "display_url" : "etprofessional.com\/Seeing_the_wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348149210757083137",
  "text" : "RT @chiasuan: Just posted: Can we teach English without teaching the 'culture of English'?\nWhat does that even mean?\n\nhttp:\/\/t.co\/HWDOrZfK6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "culture",
        "indices" : [ 127, 135 ]
      }, {
        "text" : "efl",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/HWDOrZfK62",
        "expanded_url" : "http:\/\/www.etprofessional.com\/Seeing_the_world_the_English_way__Teaching_English_Or_teaching_English_culture_81022.aspx",
        "display_url" : "etprofessional.com\/Seeing_the_wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347310735124230144",
    "text" : "Just posted: Can we teach English without teaching the 'culture of English'?\nWhat does that even mean?\n\nhttp:\/\/t.co\/HWDOrZfK62 #culture #efl",
    "id" : 347310735124230144,
    "created_at" : "2013-06-19 11:11:46 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 348149210757083137,
  "created_at" : "2013-06-21 18:43:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/9R67MkmlEN",
      "expanded_url" : "http:\/\/doyouspeaktouriste.fr\/Guide_DoYouSpeakTouriste.pdf",
      "display_url" : "doyouspeaktouriste.fr\/Guide_DoYouSpe\u2026"
    }, {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/q2cnnlfG0F",
      "expanded_url" : "http:\/\/domsmflpage.blogspot.com\/2013\/06\/do-you-speak-touriste.html",
      "display_url" : "domsmflpage.blogspot.com\/2013\/06\/do-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348145001705918466",
  "text" : "interesting paris tourist stats and descriptors http:\/\/t.co\/9R67MkmlEN HT http:\/\/t.co\/q2cnnlfG0F",
  "id" : 348145001705918466,
  "created_at" : "2013-06-21 18:26:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 118, 130 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/wctQoAxfZc",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-4ML",
      "display_url" : "wp.me\/p1U04a-4ML"
    } ]
  },
  "geo" : { },
  "id_str" : "348139214933749760",
  "text" : "ATOS call police on Labour councillor after he tries to accompany claimants to assessments http:\/\/t.co\/wctQoAxfZc via @ThomasPride",
  "id" : 348139214933749760,
  "created_at" : "2013-06-21 18:03:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348108440519979010",
  "geo" : { },
  "id_str" : "348116154658729984",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac no rain just piss :)",
  "id" : 348116154658729984,
  "in_reply_to_status_id" : 348108440519979010,
  "created_at" : "2013-06-21 16:32:13 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/2CX5qqJIms",
      "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/06\/17\/no-lexical-syllabus-part-1-pre-setting-or-not\/",
      "display_url" : "blog.westminster.ac.uk\/celt\/2013\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347977679259181057",
  "text" : "\u00BB No lexical syllabus? Part 1: pre-setting or not Centre for English Learning and Teaching http:\/\/t.co\/2CX5qqJIms",
  "id" : 347977679259181057,
  "created_at" : "2013-06-21 07:21:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowcangotosleep",
      "indices" : [ 32, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347855506968309760",
  "geo" : { },
  "id_str" : "347860213329690625",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava woot installs fine :) #nowcangotosleep",
  "id" : 347860213329690625,
  "in_reply_to_status_id" : 347855506968309760,
  "created_at" : "2013-06-20 23:35:12 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/347855506968309760\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/4wkfLh1ZeY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNPUvZZCcAAI-TM.png",
      "id_str" : "347855506972504064",
      "id" : 347855506972504064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNPUvZZCcAAI-TM.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 721
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 721
      } ],
      "display_url" : "pic.twitter.com\/4wkfLh1ZeY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347855506968309760",
  "text" : "not too bad in terms of compile time, now to test! http:\/\/t.co\/4wkfLh1ZeY",
  "id" : 347855506968309760,
  "created_at" : "2013-06-20 23:16:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "edrethink",
      "indices" : [ 3, 13 ],
      "id_str" : "3057524486",
      "id" : 3057524486
    }, {
      "name" : "George Couros",
      "screen_name" : "gcouros",
      "indices" : [ 85, 93 ],
      "id_str" : "18368680",
      "id" : 18368680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/uV0km3KzSJ",
      "expanded_url" : "http:\/\/bit.ly\/197tKlF",
      "display_url" : "bit.ly\/197tKlF"
    } ]
  },
  "geo" : { },
  "id_str" : "347847847682646016",
  "text" : "RT @edrethink: Principal of Change: Movie Trailer Learning http:\/\/t.co\/uV0km3KzSJ by @gcouros",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Couros",
        "screen_name" : "gcouros",
        "indices" : [ 70, 78 ],
        "id_str" : "18368680",
        "id" : 18368680
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/uV0km3KzSJ",
        "expanded_url" : "http:\/\/bit.ly\/197tKlF",
        "display_url" : "bit.ly\/197tKlF"
      } ]
    },
    "geo" : { },
    "id_str" : "347845061763026945",
    "text" : "Principal of Change: Movie Trailer Learning http:\/\/t.co\/uV0km3KzSJ by @gcouros",
    "id" : 347845061763026945,
    "created_at" : "2013-06-20 22:35:00 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 347847847682646016,
  "created_at" : "2013-06-20 22:46:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fingerscrossed",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347839820149706752",
  "text" : "very exciting 1st time compiling my phone rom from source, how's yr thursday evening? :) #fingerscrossed",
  "id" : 347839820149706752,
  "created_at" : "2013-06-20 22:14:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 12, 18 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "Alexis Tatjes",
      "screen_name" : "lexiloco",
      "indices" : [ 19, 28 ],
      "id_str" : "17665779",
      "id" : 17665779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347502026772586496",
  "geo" : { },
  "id_str" : "347504444121964544",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @idc74 @lexiloco works out about 10%",
  "id" : 347504444121964544,
  "in_reply_to_status_id" : 347502026772586496,
  "created_at" : "2013-06-20 00:01:30 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 12, 18 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/v4vk8VzTeB",
      "expanded_url" : "http:\/\/www.talkstats.com\/showthread.php\/146-Binomial-Probabilities",
      "display_url" : "talkstats.com\/showthread.php\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347444833713020929",
  "geo" : { },
  "id_str" : "347497905655009281",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @idc74 http:\/\/t.co\/v4vk8VzTeB",
  "id" : 347497905655009281,
  "in_reply_to_status_id" : 347444833713020929,
  "created_at" : "2013-06-19 23:35:31 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/NrCaxv3IIR",
      "expanded_url" : "http:\/\/bit.ly\/16dD2as",
      "display_url" : "bit.ly\/16dD2as"
    } ]
  },
  "geo" : { },
  "id_str" : "347104586852605954",
  "text" : "RT @TESOLacademic: Innovations in learning technologies for English language teaching New British Council publication http:\/\/t.co\/NrCaxv3IIR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/NrCaxv3IIR",
        "expanded_url" : "http:\/\/bit.ly\/16dD2as",
        "display_url" : "bit.ly\/16dD2as"
      } ]
    },
    "geo" : { },
    "id_str" : "346976027060338688",
    "text" : "Innovations in learning technologies for English language teaching New British Council publication http:\/\/t.co\/NrCaxv3IIR",
    "id" : 346976027060338688,
    "created_at" : "2013-06-18 13:01:46 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 347104586852605954,
  "created_at" : "2013-06-18 21:32:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 82, 98 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/NaZjJKx4UG",
      "expanded_url" : "http:\/\/wp.me\/p31zUY-7s",
      "display_url" : "wp.me\/p31zUY-7s"
    } ]
  },
  "geo" : { },
  "id_str" : "347083390299807745",
  "text" : "How knowledge is being detached from skills in English http:\/\/t.co\/NaZjJKx4UG via @wordpressdotcom",
  "id" : 347083390299807745,
  "created_at" : "2013-06-18 20:08:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 98, 105 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/0gzyOdY1y3",
      "expanded_url" : "http:\/\/bit.ly\/11sXKQu",
      "display_url" : "bit.ly\/11sXKQu"
    } ]
  },
  "geo" : { },
  "id_str" : "346656892820529152",
  "text" : "RT @DTWillingham: Willingham blog: What type of learning is most natural? \nhttp:\/\/t.co\/0gzyOdY1y3 #edchat #ukedchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 80, 87 ]
      }, {
        "text" : "ukedchat",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/0gzyOdY1y3",
        "expanded_url" : "http:\/\/bit.ly\/11sXKQu",
        "display_url" : "bit.ly\/11sXKQu"
      } ]
    },
    "geo" : { },
    "id_str" : "346635693373661188",
    "text" : "Willingham blog: What type of learning is most natural? \nhttp:\/\/t.co\/0gzyOdY1y3 #edchat #ukedchat",
    "id" : 346635693373661188,
    "created_at" : "2013-06-17 14:29:24 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 346656892820529152,
  "created_at" : "2013-06-17 15:53:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "indices" : [ 3, 15 ],
      "id_str" : "241288268",
      "id" : 241288268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/701hnjBivu",
      "expanded_url" : "http:\/\/www.newsunspun.org\/article\/syrian-conflict-biases-on-international-involvement-in-the-uk-media",
      "display_url" : "newsunspun.org\/article\/syrian\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346606071466557441",
  "text" : "RT @news_unspun: Some analysis of BBC news and Guardian reporting on international involvement in the #Syria conflict: http:\/\/t.co\/701hnjBi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 85, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/701hnjBivu",
        "expanded_url" : "http:\/\/www.newsunspun.org\/article\/syrian-conflict-biases-on-international-involvement-in-the-uk-media",
        "display_url" : "newsunspun.org\/article\/syrian\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "346564947171500032",
    "text" : "Some analysis of BBC news and Guardian reporting on international involvement in the #Syria conflict: http:\/\/t.co\/701hnjBivu",
    "id" : 346564947171500032,
    "created_at" : "2013-06-17 09:48:16 +0000",
    "user" : {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "protected" : false,
      "id_str" : "241288268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3176838178\/fa7f886ef014ca0437d5dc800dc9163e_normal.png",
      "id" : 241288268,
      "verified" : false
    }
  },
  "id" : 346606071466557441,
  "created_at" : "2013-06-17 12:31:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/8E5y9w3aAh",
      "expanded_url" : "http:\/\/goo.gl\/CU1w0",
      "display_url" : "goo.gl\/CU1w0"
    } ]
  },
  "geo" : { },
  "id_str" : "346564315668684800",
  "text" : "RT @Edulang: Are Schools Getting a Big Enough Bang for Their Education Technology Buck? by Ulrich Bosser: http:\/\/t.co\/8E5y9w3aAh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/8E5y9w3aAh",
        "expanded_url" : "http:\/\/goo.gl\/CU1w0",
        "display_url" : "goo.gl\/CU1w0"
      } ]
    },
    "geo" : { },
    "id_str" : "346138525030305793",
    "text" : "Are Schools Getting a Big Enough Bang for Their Education Technology Buck? by Ulrich Bosser: http:\/\/t.co\/8E5y9w3aAh",
    "id" : 346138525030305793,
    "created_at" : "2013-06-16 05:33:49 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 346564315668684800,
  "created_at" : "2013-06-17 09:45:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 3, 18 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uPpOMJa5sW",
      "expanded_url" : "http:\/\/teachertrainingunplugged.com\/dodgy\/",
      "display_url" : "teachertrainingunplugged.com\/dodgy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "346396907771408385",
  "text" : "RT @LjiljanaHavran: Very interesting and useful lesson about the passive - dogs, disasters and dodgy grammar rules - teaching the passive h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/uPpOMJa5sW",
        "expanded_url" : "http:\/\/teachertrainingunplugged.com\/dodgy\/",
        "display_url" : "teachertrainingunplugged.com\/dodgy\/"
      } ]
    },
    "geo" : { },
    "id_str" : "346385400304119808",
    "text" : "Very interesting and useful lesson about the passive - dogs, disasters and dodgy grammar rules - teaching the passive http:\/\/t.co\/uPpOMJa5sW",
    "id" : 346385400304119808,
    "created_at" : "2013-06-16 21:54:49 +0000",
    "user" : {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "protected" : false,
      "id_str" : "1395825290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729054439496159232\/58roonKM_normal.jpg",
      "id" : 1395825290,
      "verified" : false
    }
  },
  "id" : 346396907771408385,
  "created_at" : "2013-06-16 22:40:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 105, 121 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/RgAugCl5kB",
      "expanded_url" : "http:\/\/wp.me\/p32IOl-85",
      "display_url" : "wp.me\/p32IOl-85"
    } ]
  },
  "geo" : { },
  "id_str" : "346387869264400384",
  "text" : "What a linguist does on Father's Day: Humor, gender roles, and greeting cards http:\/\/t.co\/RgAugCl5kB via @wordpressdotcom",
  "id" : 346387869264400384,
  "created_at" : "2013-06-16 22:04:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/lKNyojTMgW",
      "expanded_url" : "http:\/\/wp.me\/p31zUY-76",
      "display_url" : "wp.me\/p31zUY-76"
    } ]
  },
  "geo" : { },
  "id_str" : "345921467067797506",
  "text" : "Which ideas are damaging education? http:\/\/t.co\/lKNyojTMgW via @wordpressdotcom",
  "id" : 345921467067797506,
  "created_at" : "2013-06-15 15:11:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Trish McCluskey",
      "screen_name" : "trilia",
      "indices" : [ 131, 138 ],
      "id_str" : "25624211",
      "id" : 25624211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/zNRhX7kl7P",
      "expanded_url" : "http:\/\/bit.ly\/11fF7Tl",
      "display_url" : "bit.ly\/11fF7Tl"
    } ]
  },
  "geo" : { },
  "id_str" : "345869297958125568",
  "text" : "RT @KateMfD: \"An entire body of knowledge is being forgotten or suppressed.\" Why #edtech needs Friere. http:\/\/t.co\/zNRhX7kl7P (via @trilia)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trish McCluskey",
        "screen_name" : "trilia",
        "indices" : [ 118, 125 ],
        "id_str" : "25624211",
        "id" : 25624211
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/zNRhX7kl7P",
        "expanded_url" : "http:\/\/bit.ly\/11fF7Tl",
        "display_url" : "bit.ly\/11fF7Tl"
      } ]
    },
    "geo" : { },
    "id_str" : "345859882194448384",
    "text" : "\"An entire body of knowledge is being forgotten or suppressed.\" Why #edtech needs Friere. http:\/\/t.co\/zNRhX7kl7P (via @trilia)",
    "id" : 345859882194448384,
    "created_at" : "2013-06-15 11:06:36 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 345869297958125568,
  "created_at" : "2013-06-15 11:44:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Peterson",
      "screen_name" : "NetPeterson",
      "indices" : [ 3, 15 ],
      "id_str" : "1260571208",
      "id" : 1260571208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zPjUiiZjAe",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article35274.htm",
      "display_url" : "informationclearinghouse.info\/article35274.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345548290651193344",
  "text" : "RT @NetPeterson: Video: \"What A Drone Can See From 17,000 Feet,\" PBS\/Information Clearinghouse, http:\/\/t.co\/zPjUiiZjAe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/zPjUiiZjAe",
        "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article35274.htm",
        "display_url" : "informationclearinghouse.info\/article35274.h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "345537863158489088",
    "text" : "Video: \"What A Drone Can See From 17,000 Feet,\" PBS\/Information Clearinghouse, http:\/\/t.co\/zPjUiiZjAe",
    "id" : 345537863158489088,
    "created_at" : "2013-06-14 13:47:01 +0000",
    "user" : {
      "name" : "David Peterson",
      "screen_name" : "NetPeterson",
      "protected" : false,
      "id_str" : "1260571208",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_1_normal.png",
      "id" : 1260571208,
      "verified" : false
    }
  },
  "id" : 345548290651193344,
  "created_at" : "2013-06-14 14:28:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345544951926513664",
  "text" : "@MattHalsdorff haha ! hoping to catch evan frendo's sess,",
  "id" : 345544951926513664,
  "created_at" : "2013-06-14 14:15:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345540818687373312",
  "geo" : { },
  "id_str" : "345541427327012864",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson does one migrating blog make a summer? :)",
  "id" : 345541427327012864,
  "in_reply_to_status_id" : 345540818687373312,
  "created_at" : "2013-06-14 14:01:10 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FofHPEQG46",
      "expanded_url" : "http:\/\/bit.ly\/12t2XN3",
      "display_url" : "bit.ly\/12t2XN3"
    } ]
  },
  "geo" : { },
  "id_str" : "345519245741920258",
  "text" : "RT @CraigMurrayOrg: Preparing to Bomb Syria: Quite simply I do not believe the US, UK and French government\u2019s assertion that the S... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/FofHPEQG46",
        "expanded_url" : "http:\/\/bit.ly\/12t2XN3",
        "display_url" : "bit.ly\/12t2XN3"
      } ]
    },
    "geo" : { },
    "id_str" : "345512732734398464",
    "text" : "Preparing to Bomb Syria: Quite simply I do not believe the US, UK and French government\u2019s assertion that the S... http:\/\/t.co\/FofHPEQG46",
    "id" : 345512732734398464,
    "created_at" : "2013-06-14 12:07:09 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 345519245741920258,
  "created_at" : "2013-06-14 12:33:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2bQge5u1fE",
      "expanded_url" : "http:\/\/elt-resourceful.com\/2013\/06\/07\/teacher-echo-teacher-echo-helpful-or-greedy-and-controlling\/#comment-3145",
      "display_url" : "elt-resourceful.com\/2013\/06\/07\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345498323169456128",
  "text" : "RT @teflerinha: Thanks for some really interesting comments on my blog post on Teacher echo http:\/\/t.co\/2bQge5u1fE incl one that's a post i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/2bQge5u1fE",
        "expanded_url" : "http:\/\/elt-resourceful.com\/2013\/06\/07\/teacher-echo-teacher-echo-helpful-or-greedy-and-controlling\/#comment-3145",
        "display_url" : "elt-resourceful.com\/2013\/06\/07\/tea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "345494868317065217",
    "text" : "Thanks for some really interesting comments on my blog post on Teacher echo http:\/\/t.co\/2bQge5u1fE incl one that's a post in itself!",
    "id" : 345494868317065217,
    "created_at" : "2013-06-14 10:56:10 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 345498323169456128,
  "created_at" : "2013-06-14 11:09:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/xuGiXNBV66",
      "expanded_url" : "http:\/\/wp.me\/p33cOf-48",
      "display_url" : "wp.me\/p33cOf-48"
    } ]
  },
  "geo" : { },
  "id_str" : "345496270242193409",
  "text" : "Top 10 places to watch BESIG Online 2013 http:\/\/t.co\/xuGiXNBV66 via @MattHalsdorff",
  "id" : 345496270242193409,
  "created_at" : "2013-06-14 11:01:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/TUu7H8CBbX",
      "expanded_url" : "http:\/\/ow.ly\/lZeMV",
      "display_url" : "ow.ly\/lZeMV"
    } ]
  },
  "geo" : { },
  "id_str" : "345300777272745984",
  "text" : "RT @medialens: Latest alert: 'Limited But Persuasive' Evidence - Syria, Sarin, Libya, Lies http:\/\/t.co\/TUu7H8CBbX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/TUu7H8CBbX",
        "expanded_url" : "http:\/\/ow.ly\/lZeMV",
        "display_url" : "ow.ly\/lZeMV"
      } ]
    },
    "geo" : { },
    "id_str" : "345096162270904320",
    "text" : "Latest alert: 'Limited But Persuasive' Evidence - Syria, Sarin, Libya, Lies http:\/\/t.co\/TUu7H8CBbX",
    "id" : 345096162270904320,
    "created_at" : "2013-06-13 08:31:51 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 345300777272745984,
  "created_at" : "2013-06-13 22:04:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ZwIHRDbQMx",
      "expanded_url" : "http:\/\/joelgrus.com\/2013\/06\/09\/post-prism-data-science-venn-diagram\/",
      "display_url" : "joelgrus.com\/2013\/06\/09\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345208972007063552",
  "text" : "Post-prism Data Science Venn Diagram http:\/\/t.co\/ZwIHRDbQMx",
  "id" : 345208972007063552,
  "created_at" : "2013-06-13 16:00:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "010-8575-6630",
      "screen_name" : "djnada",
      "indices" : [ 0, 7 ],
      "id_str" : "2271666128",
      "id" : 2271666128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345187944660865024",
  "geo" : { },
  "id_str" : "345188257178480640",
  "in_reply_to_user_id" : 15663328,
  "text" : "@djnada great find :) do they mean organic? free-range?",
  "id" : 345188257178480640,
  "in_reply_to_status_id" : 345187944660865024,
  "created_at" : "2013-06-13 14:37:48 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345186895392800768",
  "geo" : { },
  "id_str" : "345187690913873922",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco yes and very few people run home slowly :) bnc does give - thinking that the man was mad, ran quickly home",
  "id" : 345187690913873922,
  "in_reply_to_status_id" : 345186895392800768,
  "created_at" : "2013-06-13 14:35:33 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 12, 18 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 19, 34 ],
      "id_str" : "22779473",
      "id" : 22779473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/IOO6W7Ua9Q",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/glowbe\/?c=glowbe&q=23765404",
      "display_url" : "corpus2.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "345179477191565312",
  "geo" : { },
  "id_str" : "345184824320987136",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @idc74 @ELTExperiences is it also the clash btw quick and run? e.g. crying and fast more freq http:\/\/t.co\/IOO6W7Ua9Q",
  "id" : 345184824320987136,
  "in_reply_to_status_id" : 345179477191565312,
  "created_at" : "2013-06-13 14:24:10 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345172931585925120",
  "geo" : { },
  "id_str" : "345176083085262849",
  "in_reply_to_user_id" : 228747458,
  "text" : "@AlexSWalsh hehe tasty trolling there :)",
  "id" : 345176083085262849,
  "in_reply_to_status_id" : 345172931585925120,
  "created_at" : "2013-06-13 13:49:25 +0000",
  "in_reply_to_screen_name" : "AlexSRWalsh",
  "in_reply_to_user_id_str" : "228747458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jhvWuvUEjt",
      "expanded_url" : "http:\/\/www.alienteachers.com\/1\/post\/2013\/06\/blogs-never-before-have-so-many-peoplewith-so-little-to-saysaid-so-muchto-so-few.html",
      "display_url" : "alienteachers.com\/1\/post\/2013\/06\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345174576025714691",
  "text" : "RT @AlexSWalsh: Blogs\u00A0-\u00A0never before have so many people,\u00A0with so little to say,\u00A0said so much,\u00A0to so few\u00A0\u00A0 - AlienTeachers #eltchat http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/jhvWuvUEjt",
        "expanded_url" : "http:\/\/www.alienteachers.com\/1\/post\/2013\/06\/blogs-never-before-have-so-many-peoplewith-so-little-to-saysaid-so-muchto-so-few.html",
        "display_url" : "alienteachers.com\/1\/post\/2013\/06\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "345172931585925120",
    "text" : "Blogs\u00A0-\u00A0never before have so many people,\u00A0with so little to say,\u00A0said so much,\u00A0to so few\u00A0\u00A0 - AlienTeachers #eltchat http:\/\/t.co\/jhvWuvUEjt",
    "id" : 345172931585925120,
    "created_at" : "2013-06-13 13:36:54 +0000",
    "user" : {
      "name" : "Alex Walsh",
      "screen_name" : "AlexSRWalsh",
      "protected" : false,
      "id_str" : "228747458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738934802355617793\/veV8228l_normal.jpg",
      "id" : 228747458,
      "verified" : false
    }
  },
  "id" : 345174576025714691,
  "created_at" : "2013-06-13 13:43:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 7, 18 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 19, 34 ],
      "id_str" : "22779473",
      "id" : 22779473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345140502141751296",
  "geo" : { },
  "id_str" : "345171539920056321",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 @lexicoloco @ELTExperiences he ran quickly home? does adverb modifiy ran, home, or ran home?",
  "id" : 345171539920056321,
  "in_reply_to_status_id" : 345140502141751296,
  "created_at" : "2013-06-13 13:31:22 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/NxPlZjiVpS",
      "expanded_url" : "http:\/\/bit.ly\/1a7gtrk",
      "display_url" : "bit.ly\/1a7gtrk"
    } ]
  },
  "geo" : { },
  "id_str" : "345165666791329792",
  "text" : "RT @mcleod: Rebirth of the Teaching Machine through the Seduction of Data Analytics: This Time It's Personal http:\/\/t.co\/NxPlZjiVpS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/NxPlZjiVpS",
        "expanded_url" : "http:\/\/bit.ly\/1a7gtrk",
        "display_url" : "bit.ly\/1a7gtrk"
      } ]
    },
    "geo" : { },
    "id_str" : "345156141615030272",
    "text" : "Rebirth of the Teaching Machine through the Seduction of Data Analytics: This Time It's Personal http:\/\/t.co\/NxPlZjiVpS",
    "id" : 345156141615030272,
    "created_at" : "2013-06-13 12:30:11 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 345165666791329792,
  "created_at" : "2013-06-13 13:08:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 3, 18 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/17aE5i9Amm",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2013\/06\/12\/twitter_analytics_tool_lets_you_see_which_tweets_your_followers_are_actually.html?utm_source=tw&utm_medium=sm&utm_campaign=button_chunky",
      "display_url" : "slate.com\/blogs\/future_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345164673433337856",
  "text" : "RT @markwarschauer: Now Twitter Lets You See Which of Your Tweets People Are Actually Clicking http:\/\/t.co\/17aE5i9Amm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/17aE5i9Amm",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2013\/06\/12\/twitter_analytics_tool_lets_you_see_which_tweets_your_followers_are_actually.html?utm_source=tw&utm_medium=sm&utm_campaign=button_chunky",
        "display_url" : "slate.com\/blogs\/future_t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "345127092314333184",
    "text" : "Now Twitter Lets You See Which of Your Tweets People Are Actually Clicking http:\/\/t.co\/17aE5i9Amm",
    "id" : 345127092314333184,
    "created_at" : "2013-06-13 10:34:45 +0000",
    "user" : {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "protected" : false,
      "id_str" : "17316060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535141210432622592\/ZXqkNrhW_normal.jpeg",
      "id" : 17316060,
      "verified" : false
    }
  },
  "id" : 345164673433337856,
  "created_at" : "2013-06-13 13:04:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/56RfQjqnMy",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.fr\/2013\/06\/reading-comprehension-just-as-good.html#.UbnB8OB08sk.twitter",
      "display_url" : "bps-research-digest.blogspot.fr\/2013\/06\/readin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345163542317649921",
  "text" : "Reading comprehension just as good using a Kindle as with paper http:\/\/t.co\/56RfQjqnMy",
  "id" : 345163542317649921,
  "created_at" : "2013-06-13 12:59:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eduardo Santos",
      "screen_name" : "eltbakery",
      "indices" : [ 3, 13 ],
      "id_str" : "99758036",
      "id" : 99758036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 77, 81 ]
    }, {
      "text" : "besig",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "tefl",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/9nc7YilFHV",
      "expanded_url" : "http:\/\/eltbakery.edublogs.org\/business-english\/lesson-plans\/",
      "display_url" : "eltbakery.edublogs.org\/business-engli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345092952844017664",
  "text" : "RT @eltbakery: 5 Ready-made lessons for 1-2-1 and Business English students. #elt #besig #tefl http:\/\/t.co\/9nc7YilFHV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 62, 66 ]
      }, {
        "text" : "besig",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "tefl",
        "indices" : [ 74, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/9nc7YilFHV",
        "expanded_url" : "http:\/\/eltbakery.edublogs.org\/business-english\/lesson-plans\/",
        "display_url" : "eltbakery.edublogs.org\/business-engli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "345031590621093888",
    "text" : "5 Ready-made lessons for 1-2-1 and Business English students. #elt #besig #tefl http:\/\/t.co\/9nc7YilFHV",
    "id" : 345031590621093888,
    "created_at" : "2013-06-13 04:15:16 +0000",
    "user" : {
      "name" : "Eduardo Santos",
      "screen_name" : "eltbakery",
      "protected" : false,
      "id_str" : "99758036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2896880230\/f61ee2ea1b64aa49a24915c3859546bf_normal.png",
      "id" : 99758036,
      "verified" : false
    }
  },
  "id" : 345092952844017664,
  "created_at" : "2013-06-13 08:19:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/vAtTmV3IZk",
      "expanded_url" : "http:\/\/bit.ly\/18vV4cT",
      "display_url" : "bit.ly\/18vV4cT"
    } ]
  },
  "geo" : { },
  "id_str" : "344937404630704128",
  "text" : "RT @CraigMurrayOrg: New post: Pre-emptive Policing http:\/\/t.co\/vAtTmV3IZk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/vAtTmV3IZk",
        "expanded_url" : "http:\/\/bit.ly\/18vV4cT",
        "display_url" : "bit.ly\/18vV4cT"
      } ]
    },
    "geo" : { },
    "id_str" : "344733738573389824",
    "text" : "New post: Pre-emptive Policing http:\/\/t.co\/vAtTmV3IZk",
    "id" : 344733738573389824,
    "created_at" : "2013-06-12 08:31:42 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 344937404630704128,
  "created_at" : "2013-06-12 22:01:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "Mike Pennisi",
      "screen_name" : "JugglinMike",
      "indices" : [ 122, 134 ],
      "id_str" : "320950358",
      "id" : 320950358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/wwf3A6ELWq",
      "expanded_url" : "http:\/\/I.there.is.a.tool.th\/at\/lets\/you\/ma",
      "display_url" : "I.there.is.a.tool.th\/at\/lets\/you\/ma"
    }, {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/aimCwSBRTu",
      "expanded_url" : "http:\/\/long.and.annoying.tw\/eets\/that\/have",
      "display_url" : "long.and.annoying.tw\/eets\/that\/have"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hu05RhC6Mo",
      "expanded_url" : "http:\/\/of.verbosity.but.ar\/e\/not\/very\/rea",
      "display_url" : "of.verbosity.but.ar\/e\/not\/very\/rea"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/buvTkJV1ha",
      "expanded_url" : "http:\/\/jugglinmike.github.io\/nitwit\/",
      "display_url" : "jugglinmike.github.io\/nitwit\/"
    } ]
  },
  "geo" : { },
  "id_str" : "344905901825724416",
  "text" : "RT @tinysubversions: FY http:\/\/t.co\/wwf3A6ELWq ke http:\/\/t.co\/aimCwSBRTu a lot http:\/\/t.co\/hu05RhC6Mo dable  : niTwit, by @jugglinMike: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Pennisi",
        "screen_name" : "JugglinMike",
        "indices" : [ 101, 113 ],
        "id_str" : "320950358",
        "id" : 320950358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 3, 25 ],
        "url" : "http:\/\/t.co\/wwf3A6ELWq",
        "expanded_url" : "http:\/\/I.there.is.a.tool.th\/at\/lets\/you\/ma",
        "display_url" : "I.there.is.a.tool.th\/at\/lets\/you\/ma"
      }, {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/aimCwSBRTu",
        "expanded_url" : "http:\/\/long.and.annoying.tw\/eets\/that\/have",
        "display_url" : "long.and.annoying.tw\/eets\/that\/have"
      }, {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/hu05RhC6Mo",
        "expanded_url" : "http:\/\/of.verbosity.but.ar\/e\/not\/very\/rea",
        "display_url" : "of.verbosity.but.ar\/e\/not\/very\/rea"
      }, {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/buvTkJV1ha",
        "expanded_url" : "http:\/\/jugglinmike.github.io\/nitwit\/",
        "display_url" : "jugglinmike.github.io\/nitwit\/"
      } ]
    },
    "geo" : { },
    "id_str" : "344881730949353473",
    "text" : "FY http:\/\/t.co\/wwf3A6ELWq ke http:\/\/t.co\/aimCwSBRTu a lot http:\/\/t.co\/hu05RhC6Mo dable  : niTwit, by @jugglinMike: http:\/\/t.co\/buvTkJV1ha",
    "id" : 344881730949353473,
    "created_at" : "2013-06-12 18:19:46 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 344905901825724416,
  "created_at" : "2013-06-12 19:55:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ela13",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/waklwtmsCO",
      "expanded_url" : "http:\/\/bit.ly\/15X1VHp",
      "display_url" : "bit.ly\/15X1VHp"
    } ]
  },
  "geo" : { },
  "id_str" : "344904770529660928",
  "text" : "RT @DonaldClark: E-learning Africa; 7 new narratives, amazing event #ela13 http:\/\/t.co\/waklwtmsCO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ela13",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/waklwtmsCO",
        "expanded_url" : "http:\/\/bit.ly\/15X1VHp",
        "display_url" : "bit.ly\/15X1VHp"
      } ]
    },
    "geo" : { },
    "id_str" : "344847706608504832",
    "text" : "E-learning Africa; 7 new narratives, amazing event #ela13 http:\/\/t.co\/waklwtmsCO",
    "id" : 344847706608504832,
    "created_at" : "2013-06-12 16:04:34 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 344904770529660928,
  "created_at" : "2013-06-12 19:51:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 3, 11 ],
      "id_str" : "189578708",
      "id" : 189578708
    }, {
      "name" : "Cecilia Lemos",
      "screen_name" : "CeciELT",
      "indices" : [ 39, 47 ],
      "id_str" : "164527997",
      "id" : 164527997
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 49, 58 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    }, {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 60, 69 ],
      "id_str" : "130975050",
      "id" : 130975050
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 71, 82 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Katy Davies",
      "screen_name" : "katysdavies",
      "indices" : [ 84, 96 ],
      "id_str" : "2919479375",
      "id" : 2919479375
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 103, 118 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/oOVuKcWReF",
      "expanded_url" : "http:\/\/ow.ly\/lXSWV",
      "display_url" : "ow.ly\/lXSWV"
    } ]
  },
  "geo" : { },
  "id_str" : "344899059561136128",
  "text" : "RT @ELTchat: New #ELTchat podcast with @CeciELT, @Wiktor_K, @bcnpaul1, @vickyloras, @KatysDavies &amp; @MrChrisJWilson! http:\/\/t.co\/oOVuKcWReF \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cecilia Lemos",
        "screen_name" : "CeciELT",
        "indices" : [ 26, 34 ],
        "id_str" : "164527997",
        "id" : 164527997
      }, {
        "name" : "Wiktorkompe",
        "screen_name" : "wiktor_k",
        "indices" : [ 36, 45 ],
        "id_str" : "733704413383168000",
        "id" : 733704413383168000
      }, {
        "name" : "paul braddock",
        "screen_name" : "bcnpaul1",
        "indices" : [ 47, 56 ],
        "id_str" : "130975050",
        "id" : 130975050
      }, {
        "name" : "Vicky Loras",
        "screen_name" : "vickyloras",
        "indices" : [ 58, 69 ],
        "id_str" : "95957241",
        "id" : 95957241
      }, {
        "name" : "Katy Davies",
        "screen_name" : "katysdavies",
        "indices" : [ 71, 83 ],
        "id_str" : "2919479375",
        "id" : 2919479375
      }, {
        "name" : "Christopher Wilson",
        "screen_name" : "MrChrisJWilson",
        "indices" : [ 90, 105 ],
        "id_str" : "20760283",
        "id" : 20760283
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/oOVuKcWReF",
        "expanded_url" : "http:\/\/ow.ly\/lXSWV",
        "display_url" : "ow.ly\/lXSWV"
      } ]
    },
    "geo" : { },
    "id_str" : "344855449042030592",
    "text" : "New #ELTchat podcast with @CeciELT, @Wiktor_K, @bcnpaul1, @vickyloras, @KatysDavies &amp; @MrChrisJWilson! http:\/\/t.co\/oOVuKcWReF - out now!",
    "id" : 344855449042030592,
    "created_at" : "2013-06-12 16:35:20 +0000",
    "user" : {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "protected" : false,
      "id_str" : "189578708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1277101025\/eltchat1_normal.jpg",
      "id" : 189578708,
      "verified" : false
    }
  },
  "id" : 344899059561136128,
  "created_at" : "2013-06-12 19:28:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/GhcLeH9L89",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/06\/11\/data-tracking-and-teaching-machines\/",
      "display_url" : "hackeducation.com\/2013\/06\/11\/dat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344816246535094273",
  "text" : "RT @audreywatters: Data, Surveillance, and Teaching Machines http:\/\/t.co\/GhcLeH9L89",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/GhcLeH9L89",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/06\/11\/data-tracking-and-teaching-machines\/",
        "display_url" : "hackeducation.com\/2013\/06\/11\/dat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344618121417601024",
    "text" : "Data, Surveillance, and Teaching Machines http:\/\/t.co\/GhcLeH9L89",
    "id" : 344618121417601024,
    "created_at" : "2013-06-12 00:52:17 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 344816246535094273,
  "created_at" : "2013-06-12 13:59:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 61, 77 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/Xu3dzRiQgf",
      "expanded_url" : "http:\/\/wp.me\/p3kgbw-iY",
      "display_url" : "wp.me\/p3kgbw-iY"
    } ]
  },
  "geo" : { },
  "id_str" : "344810901318291457",
  "text" : "working with newspapers in class: http:\/\/t.co\/Xu3dzRiQgf via @wordpressdotcom",
  "id" : 344810901318291457,
  "created_at" : "2013-06-12 13:38:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344730111628689410",
  "geo" : { },
  "id_str" : "344791355534499841",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers sweet :)",
  "id" : 344791355534499841,
  "in_reply_to_status_id" : 344730111628689410,
  "created_at" : "2013-06-12 12:20:39 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 125, 140 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/u6ob8rrN5V",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-1u",
      "display_url" : "wp.me\/p35kaI-1u"
    } ]
  },
  "geo" : { },
  "id_str" : "344775988799995905",
  "text" : "\"open and honest debate\" A Corpus Linguistic Analysis of a White House Press Briefing during the\u2026 http:\/\/t.co\/u6ob8rrN5V via @AndrewBrindle2",
  "id" : 344775988799995905,
  "created_at" : "2013-06-12 11:19:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim McCormick",
      "screen_name" : "tmccormick",
      "indices" : [ 3, 14 ],
      "id_str" : "21759817",
      "id" : 21759817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/NAnsPvR4i1",
      "expanded_url" : "http:\/\/bit.ly\/ZAWbSF",
      "display_url" : "bit.ly\/ZAWbSF"
    } ]
  },
  "geo" : { },
  "id_str" : "344559946047832064",
  "text" : "RT @tmccormick: beyond Open Access: public needs technical, legal, &amp; *conceptual* access to scholarship. http:\/\/t.co\/NAnsPvR4i1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/NAnsPvR4i1",
        "expanded_url" : "http:\/\/bit.ly\/ZAWbSF",
        "display_url" : "bit.ly\/ZAWbSF"
      } ]
    },
    "geo" : { },
    "id_str" : "344537652814569475",
    "text" : "beyond Open Access: public needs technical, legal, &amp; *conceptual* access to scholarship. http:\/\/t.co\/NAnsPvR4i1",
    "id" : 344537652814569475,
    "created_at" : "2013-06-11 19:32:32 +0000",
    "user" : {
      "name" : "Tim McCormick",
      "screen_name" : "tmccormick",
      "protected" : false,
      "id_str" : "21759817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412284775127216128\/Zdhf4I0t_normal.jpeg",
      "id" : 21759817,
      "verified" : false
    }
  },
  "id" : 344559946047832064,
  "created_at" : "2013-06-11 21:01:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowden",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/I93DlTBtdy",
      "expanded_url" : "http:\/\/www.cryptogon.com\/?p=1588",
      "display_url" : "cryptogon.com\/?p=1588"
    } ]
  },
  "geo" : { },
  "id_str" : "344553806178168832",
  "text" : "The diagram showed splitters, glass prisms that split signals from each network into two identical copies. http:\/\/t.co\/I93DlTBtdy #snowden",
  "id" : 344553806178168832,
  "created_at" : "2013-06-11 20:36:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "AmIRite Bot",
      "screen_name" : "AmIRiteBot",
      "indices" : [ 52, 63 ],
      "id_str" : "1505391505",
      "id" : 1505391505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344538363472248832",
  "text" : "RT @tinysubversions: I have made a new thing called @AmIRiteBot. It tells bad jokes based on US Twitter trending topics.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmIRite Bot",
        "screen_name" : "AmIRiteBot",
        "indices" : [ 31, 42 ],
        "id_str" : "1505391505",
        "id" : 1505391505
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344517550836707328",
    "text" : "I have made a new thing called @AmIRiteBot. It tells bad jokes based on US Twitter trending topics.",
    "id" : 344517550836707328,
    "created_at" : "2013-06-11 18:12:39 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 344538363472248832,
  "created_at" : "2013-06-11 19:35:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "esol",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "tefl",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/nMMVMi7Xlc",
      "expanded_url" : "http:\/\/www.tesolacademic.org\/keynotesnew.htm#831333953",
      "display_url" : "tesolacademic.org\/keynotesnew.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344537657545728001",
  "text" : "RT @TESOLacademic: #elt #esol #tefl #keltchat Prof Lynch has some interesting insights into SL Listening - Keynote (WMV) talk is free http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "esol",
        "indices" : [ 5, 10 ]
      }, {
        "text" : "tefl",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/nMMVMi7Xlc",
        "expanded_url" : "http:\/\/www.tesolacademic.org\/keynotesnew.htm#831333953",
        "display_url" : "tesolacademic.org\/keynotesnew.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344444381287288834",
    "text" : "#elt #esol #tefl #keltchat Prof Lynch has some interesting insights into SL Listening - Keynote (WMV) talk is free http:\/\/t.co\/nMMVMi7Xlc",
    "id" : 344444381287288834,
    "created_at" : "2013-06-11 13:21:54 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 344537657545728001,
  "created_at" : "2013-06-11 19:32:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/KgSCWTkNDt",
      "expanded_url" : "http:\/\/wp.me\/p2svM7-12U",
      "display_url" : "wp.me\/p2svM7-12U"
    } ]
  },
  "geo" : { },
  "id_str" : "344422182845296641",
  "text" : "A new direction or the way back home?: Grammar in interaction: http:\/\/t.co\/KgSCWTkNDt via @leakygrammar",
  "id" : 344422182845296641,
  "created_at" : "2013-06-11 11:53:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/EieVtHvoCV",
      "expanded_url" : "http:\/\/www.nakedcapitalism.com\/2013\/06\/edward-snowden-makes-himself-an-even-bigger-problem-to-the-officialdom.html",
      "display_url" : "nakedcapitalism.com\/2013\/06\/edward\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344363714583097344",
  "text" : "Edward Snowden Makes Himself an Even Bigger Problem to the Officialdom\nhttp:\/\/t.co\/EieVtHvoCV",
  "id" : 344363714583097344,
  "created_at" : "2013-06-11 08:01:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 58, 67 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/QZjEpH8aew",
      "expanded_url" : "http:\/\/annehodgson.de\/2013\/06\/10\/when-you-become-a-whistleblower\/",
      "display_url" : "annehodgson.de\/2013\/06\/10\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344127282400600065",
  "text" : "When you become a whistleblower http:\/\/t.co\/QZjEpH8aew by @annehodg",
  "id" : 344127282400600065,
  "created_at" : "2013-06-10 16:21:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ebnvo30FMz",
      "expanded_url" : "http:\/\/bit.ly\/12emuR0",
      "display_url" : "bit.ly\/12emuR0"
    } ]
  },
  "geo" : { },
  "id_str" : "344120889656360960",
  "text" : "RT @CraigMurrayOrg: New post: The Omniscient State http:\/\/t.co\/ebnvo30FMz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/ebnvo30FMz",
        "expanded_url" : "http:\/\/bit.ly\/12emuR0",
        "display_url" : "bit.ly\/12emuR0"
      } ]
    },
    "geo" : { },
    "id_str" : "344003696457302017",
    "text" : "New post: The Omniscient State http:\/\/t.co\/ebnvo30FMz",
    "id" : 344003696457302017,
    "created_at" : "2013-06-10 08:10:47 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 344120889656360960,
  "created_at" : "2013-06-10 15:56:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344019432013697024",
  "geo" : { },
  "id_str" : "344100206100484096",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro case could be made that the less institutional higher education the more high stakes whistleblowing? e.g. Mordechai Vanunu",
  "id" : 344100206100484096,
  "in_reply_to_status_id" : 344019432013697024,
  "created_at" : "2013-06-10 14:34:16 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowden",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/pL3SyD4RL3",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/world\/2013\/jun\/09\/edward-snowden-nsa-whistleblower-surveillance?guni=Network%20front:network-front%20full-width-1%20bento-box:Bento%20box:Position1",
      "display_url" : "guardian.co.uk\/world\/2013\/jun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343831983727710210",
  "text" : "bravo and good luck!&gt;&gt;'I don't want to live in a society that does these sort of things' #snowden http:\/\/t.co\/pL3SyD4RL3",
  "id" : 343831983727710210,
  "created_at" : "2013-06-09 20:48:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Jameson",
      "screen_name" : "BarryJamesonELT",
      "indices" : [ 0, 16 ],
      "id_str" : "288933875",
      "id" : 288933875
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 17, 32 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/mNCLWnq9te",
      "expanded_url" : "http:\/\/zeega.com\/51b4650f902414c92e000010",
      "display_url" : "zeega.com\/51b4650f902414\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "343661840116621312",
  "geo" : { },
  "id_str" : "343729005339475968",
  "in_reply_to_user_id" : 288933875,
  "text" : "@BarryJamesonELT @thornburyscott A great disturbance...http:\/\/t.co\/mNCLWnq9te",
  "id" : 343729005339475968,
  "in_reply_to_status_id" : 343661840116621312,
  "created_at" : "2013-06-09 13:59:15 +0000",
  "in_reply_to_screen_name" : "BarryJamesonELT",
  "in_reply_to_user_id_str" : "288933875",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 62, 70 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imageconference",
      "indices" : [ 42, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/YeNdpYe6Gg",
      "expanded_url" : "http:\/\/studios.amazon.com\/storyteller",
      "display_url" : "studios.amazon.com\/storyteller"
    } ]
  },
  "geo" : { },
  "id_str" : "343380886743547904",
  "text" : "Amazon Storyteller http:\/\/t.co\/YeNdpYe6Gg #imageconference HT @dogtrax",
  "id" : 343380886743547904,
  "created_at" : "2013-06-08 14:55:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/dKsJcdyC9h",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/113805781354857011278\/posts\/4Knphqj7FDJ",
      "display_url" : "plus.google.com\/u\/0\/1138057813\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "343134861248319490",
  "geo" : { },
  "id_str" : "343136081006448640",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth haha i wish, we do have a tabby though. saw it 1st on Page, Brin &amp; Schmidt's site https:\/\/t.co\/dKsJcdyC9h",
  "id" : 343136081006448640,
  "in_reply_to_status_id" : 343134861248319490,
  "created_at" : "2013-06-07 22:43:11 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Zeega",
      "screen_name" : "Zeega",
      "indices" : [ 9, 15 ],
      "id_str" : "356158929",
      "id" : 356158929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343132895176704000",
  "geo" : { },
  "id_str" : "343134322917793793",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @Zeega there's no debating with the demand high cat! :)",
  "id" : 343134322917793793,
  "in_reply_to_status_id" : 343132895176704000,
  "created_at" : "2013-06-07 22:36:12 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343132943570567169",
  "text" : "RT @audreywatters: My Twitter stream is full of NSA-related outrage. On Facebook, nada.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342796388654002176",
    "text" : "My Twitter stream is full of NSA-related outrage. On Facebook, nada.",
    "id" : 342796388654002176,
    "created_at" : "2013-06-07 00:13:22 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 343132943570567169,
  "created_at" : "2013-06-07 22:30:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Education",
      "screen_name" : "bbceducation",
      "indices" : [ 16, 29 ],
      "id_str" : "621563",
      "id" : 621563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/9zOE6WKs80",
      "expanded_url" : "http:\/\/www.estyn.gov.uk\/download\/publication\/253944.6\/developing-literacy-skills-using-digital-technology\/",
      "display_url" : "estyn.gov.uk\/download\/publi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "343025673750867969",
  "geo" : { },
  "id_str" : "343115626384084992",
  "in_reply_to_user_id" : 1289037060,
  "text" : "@researchED2013 @bbceducation \"digital\" is sexier than \"systematic planning\" http:\/\/t.co\/9zOE6WKs80 :\/",
  "id" : 343115626384084992,
  "in_reply_to_status_id" : 343025673750867969,
  "created_at" : "2013-06-07 21:21:54 +0000",
  "in_reply_to_screen_name" : "researchED1",
  "in_reply_to_user_id_str" : "1289037060",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/cTUw1T4VRU",
      "expanded_url" : "http:\/\/tinyurl.com\/m4ec8nd",
      "display_url" : "tinyurl.com\/m4ec8nd"
    } ]
  },
  "geo" : { },
  "id_str" : "343105482686337025",
  "text" : "RT @medialens: Imagine if this BBC journalist had 'acquired' and tweeted a comparable pic after killing of US ambassador in Libya http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/cTUw1T4VRU",
        "expanded_url" : "http:\/\/tinyurl.com\/m4ec8nd",
        "display_url" : "tinyurl.com\/m4ec8nd"
      } ]
    },
    "geo" : { },
    "id_str" : "343032924603551744",
    "text" : "Imagine if this BBC journalist had 'acquired' and tweeted a comparable pic after killing of US ambassador in Libya http:\/\/t.co\/cTUw1T4VRU",
    "id" : 343032924603551744,
    "created_at" : "2013-06-07 15:53:17 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 343105482686337025,
  "created_at" : "2013-06-07 20:41:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeega",
      "screen_name" : "Zeega",
      "indices" : [ 46, 52 ],
      "id_str" : "356158929",
      "id" : 356158929
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dhelt",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "demandhighelt",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/3AW4EsOJgn",
      "expanded_url" : "http:\/\/zeega.com\/51b1ee5d902414631a000003",
      "display_url" : "zeega.com\/51b1ee5d902414\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343016433141297152",
  "text" : "Demand high... http:\/\/t.co\/3AW4EsOJgn made w\/ @zeega #dhelt #demandhighelt",
  "id" : 343016433141297152,
  "created_at" : "2013-06-07 14:47:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 0, 8 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 9, 20 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342939374985572352",
  "geo" : { },
  "id_str" : "342941192717234176",
  "in_reply_to_user_id" : 13307352,
  "text" : "@dogtrax @dajbelshaw this is one of the most honest, rational accounts i have read on \"digital literacies\"!",
  "id" : 342941192717234176,
  "in_reply_to_status_id" : 342939374985572352,
  "created_at" : "2013-06-07 09:48:46 +0000",
  "in_reply_to_screen_name" : "dogtrax",
  "in_reply_to_user_id_str" : "13307352",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 45, 56 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "literacies",
      "indices" : [ 124, 135 ]
    }, {
      "text" : "nwp",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ekq1ofuAOs",
      "expanded_url" : "http:\/\/journal.ilta.ie\/2013\/05\/21\/zen-and-the-art-of-digital-literacies\/",
      "display_url" : "journal.ilta.ie\/2013\/05\/21\/zen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342940055897255936",
  "text" : "RT @dogtrax: Thoughtful piece (as always) by @dajbelshaw on grappling w\/ideas of digital literacies. http:\/\/t.co\/ekq1ofuAOs #literacies #nwp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Doug Belshaw",
        "screen_name" : "dajbelshaw",
        "indices" : [ 32, 43 ],
        "id_str" : "764365",
        "id" : 764365
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "literacies",
        "indices" : [ 111, 122 ]
      }, {
        "text" : "nwp",
        "indices" : [ 123, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/ekq1ofuAOs",
        "expanded_url" : "http:\/\/journal.ilta.ie\/2013\/05\/21\/zen-and-the-art-of-digital-literacies\/",
        "display_url" : "journal.ilta.ie\/2013\/05\/21\/zen\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "342217579064070144",
    "geo" : { },
    "id_str" : "342939374985572352",
    "in_reply_to_user_id" : 764365,
    "text" : "Thoughtful piece (as always) by @dajbelshaw on grappling w\/ideas of digital literacies. http:\/\/t.co\/ekq1ofuAOs #literacies #nwp",
    "id" : 342939374985572352,
    "in_reply_to_status_id" : 342217579064070144,
    "created_at" : "2013-06-07 09:41:33 +0000",
    "in_reply_to_screen_name" : "dajbelshaw",
    "in_reply_to_user_id_str" : "764365",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 342940055897255936,
  "created_at" : "2013-06-07 09:44:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/KOn983S2wy",
      "expanded_url" : "http:\/\/tomtesol.com\/blog\/2013\/06\/noplanning-experiments-in-teaching-writing-5\/",
      "display_url" : "tomtesol.com\/blog\/2013\/06\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342934405146349568",
  "text" : "Noplan: Experiments in Teaching Writing #5: http:\/\/t.co\/KOn983S2wy",
  "id" : 342934405146349568,
  "created_at" : "2013-06-07 09:21:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342784023078240256",
  "geo" : { },
  "id_str" : "342785336205778944",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro i am constantly surprised by institutional behaviours! :\/",
  "id" : 342785336205778944,
  "in_reply_to_status_id" : 342784023078240256,
  "created_at" : "2013-06-06 23:29:27 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342773296988819456",
  "geo" : { },
  "id_str" : "342783475419607040",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro tech coms informing and consenting vs public lack of informed consent :\/",
  "id" : 342783475419607040,
  "in_reply_to_status_id" : 342773296988819456,
  "created_at" : "2013-06-06 23:22:03 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZkMhcr8fJr",
      "expanded_url" : "http:\/\/m.washingtonpost.com\/investigations\/us-intelligence-mining-data-from-nine-us-internet-companies-in-broad-secret-program\/2013\/06\/06\/3a0c0da8-cebf-11e2-8845-d970ccb04497_story.html",
      "display_url" : "m.washingtonpost.com\/investigations\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342781588901339138",
  "text" : "RT @audreywatters: Apple, Google, Skype, Microsoft, YouTube all part of a govt data mining program. enjoy that ed-tech revolution, eh? http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ZkMhcr8fJr",
        "expanded_url" : "http:\/\/m.washingtonpost.com\/investigations\/us-intelligence-mining-data-from-nine-us-internet-companies-in-broad-secret-program\/2013\/06\/06\/3a0c0da8-cebf-11e2-8845-d970ccb04497_story.html",
        "display_url" : "m.washingtonpost.com\/investigations\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342764125232955392",
    "text" : "Apple, Google, Skype, Microsoft, YouTube all part of a govt data mining program. enjoy that ed-tech revolution, eh? http:\/\/t.co\/ZkMhcr8fJr",
    "id" : 342764125232955392,
    "created_at" : "2013-06-06 22:05:10 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 342781588901339138,
  "created_at" : "2013-06-06 23:14:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342723443868966912",
  "geo" : { },
  "id_str" : "342737378697416704",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets a bit of both? they make highlight some int things e.g the tax avoidance issue",
  "id" : 342737378697416704,
  "in_reply_to_status_id" : 342723443868966912,
  "created_at" : "2013-06-06 20:18:53 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "indices" : [ 3, 11 ],
      "id_str" : "11322822",
      "id" : 11322822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/o3APdV4br1",
      "expanded_url" : "http:\/\/chronicle.com\/article\/I-Dont-Like-Teaching-There\/139623\/?viewMobile=0",
      "display_url" : "chronicle.com\/article\/I-Dont\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342668624135340032",
  "text" : "RT @pkittle: Can you be a good teacher if you secretly dislike teaching?  http:\/\/t.co\/o3APdV4br1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/o3APdV4br1",
        "expanded_url" : "http:\/\/chronicle.com\/article\/I-Dont-Like-Teaching-There\/139623\/?viewMobile=0",
        "display_url" : "chronicle.com\/article\/I-Dont\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342641114664275969",
    "text" : "Can you be a good teacher if you secretly dislike teaching?  http:\/\/t.co\/o3APdV4br1",
    "id" : 342641114664275969,
    "created_at" : "2013-06-06 13:56:22 +0000",
    "user" : {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "protected" : false,
      "id_str" : "11322822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3092425785\/f39243edb590b4e470ff385be8f436a6_normal.png",
      "id" : 11322822,
      "verified" : false
    }
  },
  "id" : 342668624135340032,
  "created_at" : "2013-06-06 15:45:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 3, 15 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/4wucw5Zb0t",
      "expanded_url" : "http:\/\/www.thelocal.fr\/20130606\/paris-student-left-brain-dead-by-far-right-attack",
      "display_url" : "thelocal.fr\/20130606\/paris\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342650643011469312",
  "text" : "RT @OwenJones84: Remember Cl\u00E9ment M\u00E9ric, an 18-year-old anti-fascist activist left brain dead by far-right thugs in Paris. http:\/\/t.co\/4wuc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/4wucw5Zb0t",
        "expanded_url" : "http:\/\/www.thelocal.fr\/20130606\/paris-student-left-brain-dead-by-far-right-attack",
        "display_url" : "thelocal.fr\/20130606\/paris\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342593726142631936",
    "text" : "Remember Cl\u00E9ment M\u00E9ric, an 18-year-old anti-fascist activist left brain dead by far-right thugs in Paris. http:\/\/t.co\/4wucw5Zb0t RIP.",
    "id" : 342593726142631936,
    "created_at" : "2013-06-06 10:48:04 +0000",
    "user" : {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "protected" : false,
      "id_str" : "65045121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681493332678291457\/swHdHJNr_normal.jpg",
      "id" : 65045121,
      "verified" : true
    }
  },
  "id" : 342650643011469312,
  "created_at" : "2013-06-06 14:34:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/FAot9jS2bQ",
      "expanded_url" : "http:\/\/dlvr.it\/3TJYwh",
      "display_url" : "dlvr.it\/3TJYwh"
    } ]
  },
  "geo" : { },
  "id_str" : "342496638012620800",
  "text" : "RT @DonaldClark: Negroponte hacks off Africa http:\/\/t.co\/FAot9jS2bQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/FAot9jS2bQ",
        "expanded_url" : "http:\/\/dlvr.it\/3TJYwh",
        "display_url" : "dlvr.it\/3TJYwh"
      } ]
    },
    "geo" : { },
    "id_str" : "342369436302442496",
    "text" : "Negroponte hacks off Africa http:\/\/t.co\/FAot9jS2bQ",
    "id" : 342369436302442496,
    "created_at" : "2013-06-05 19:56:49 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 342496638012620800,
  "created_at" : "2013-06-06 04:22:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 89, 105 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 106, 124 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/aU8915wFYP",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-Fr",
      "display_url" : "wp.me\/pbMLY-Fr"
    } ]
  },
  "geo" : { },
  "id_str" : "342400676825006082",
  "text" : "The Dortmund Historical Corpus of Classroom English (DOHCCE)  http:\/\/t.co\/aU8915wFYP via @wordpressdotcom #corpuslinguistics #eltchat",
  "id" : 342400676825006082,
  "created_at" : "2013-06-05 22:00:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342330118758363137",
  "geo" : { },
  "id_str" : "342339611076485120",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard okay i see thx, analysing teaching\/learning dynamic is difficult!",
  "id" : 342339611076485120,
  "in_reply_to_status_id" : 342330118758363137,
  "created_at" : "2013-06-05 17:58:18 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 100, 116 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/fFMDMgbzV2",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-Fj",
      "display_url" : "wp.me\/pbMLY-Fj"
    } ]
  },
  "geo" : { },
  "id_str" : "342308071294521344",
  "text" : "New Journal: Children's Literature in English Language Education (CLELE) http:\/\/t.co\/fFMDMgbzV2 via @wordpressdotcom",
  "id" : 342308071294521344,
  "created_at" : "2013-06-05 15:52:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "indices" : [ 3, 11 ],
      "id_str" : "11322822",
      "id" : 11322822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/a1SkIm9EQN",
      "expanded_url" : "http:\/\/chronicle.com\/blogs\/linguafranca\/2013\/06\/05\/when-fizzling-was-taboo\/?cid=at&utm_source=at&utm_medium=en",
      "display_url" : "chronicle.com\/blogs\/linguafr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342306077586632704",
  "text" : "RT @pkittle: You have probably been a fizzled all your life without knowing it. Or are the feisty type? Anne Curzan explains:  http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/a1SkIm9EQN",
        "expanded_url" : "http:\/\/chronicle.com\/blogs\/linguafranca\/2013\/06\/05\/when-fizzling-was-taboo\/?cid=at&utm_source=at&utm_medium=en",
        "display_url" : "chronicle.com\/blogs\/linguafr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342304448548315137",
    "text" : "You have probably been a fizzled all your life without knowing it. Or are the feisty type? Anne Curzan explains:  http:\/\/t.co\/a1SkIm9EQN",
    "id" : 342304448548315137,
    "created_at" : "2013-06-05 15:38:34 +0000",
    "user" : {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "protected" : false,
      "id_str" : "11322822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3092425785\/f39243edb590b4e470ff385be8f436a6_normal.png",
      "id" : 11322822,
      "verified" : false
    }
  },
  "id" : 342306077586632704,
  "created_at" : "2013-06-05 15:45:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342249770544410624",
  "text" : "thanks all :) #eltchat",
  "id" : 342249770544410624,
  "created_at" : "2013-06-05 12:01:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342245623975796736",
  "text" : "Q fr anyone works with young lrnrs to adults, how does plans differ between age groups? less\/ more structured? #eltchat",
  "id" : 342245623975796736,
  "created_at" : "2013-06-05 11:44:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 11, 23 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342243907960188929",
  "geo" : { },
  "id_str" : "342244307593486337",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @Shaunwilden indeed! likewise with a 'good' plan :) #eltchat",
  "id" : 342244307593486337,
  "in_reply_to_status_id" : 342243907960188929,
  "created_at" : "2013-06-05 11:39:36 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342243220392120320",
  "geo" : { },
  "id_str" : "342243379683418112",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden or accept the mess ;) #eltchat",
  "id" : 342243379683418112,
  "in_reply_to_status_id" : 342243220392120320,
  "created_at" : "2013-06-05 11:35:54 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342242786575278081",
  "geo" : { },
  "id_str" : "342243084341489664",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden in the sense that learning research shows learning is very messy? #eltchat",
  "id" : 342243084341489664,
  "in_reply_to_status_id" : 342242786575278081,
  "created_at" : "2013-06-05 11:34:44 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342242667004043265",
  "text" : "notion of planning and notions of syllabus , both problematic in language learning? #eltchat",
  "id" : 342242667004043265,
  "created_at" : "2013-06-05 11:33:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/bEFpjmirzt",
      "expanded_url" : "http:\/\/authenticteaching.wordpress.com\/2013\/06\/04\/learners-internal-syllabus\/",
      "display_url" : "authenticteaching.wordpress.com\/2013\/06\/04\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342241576292065280",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard latest post is an amusing vignette on lesson planning blindness http:\/\/t.co\/bEFpjmirzt  #eltchat",
  "id" : 342241576292065280,
  "created_at" : "2013-06-05 11:28:44 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342236723184562176",
  "text" : "lurky lurky #eltchat",
  "id" : 342236723184562176,
  "created_at" : "2013-06-05 11:09:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kDUvyoZgVI",
      "expanded_url" : "http:\/\/themonkeycage.org\/2013\/06\/01\/a-breakout-role-for-twitter-extensive-use-of-social-media-in-the-absence-of-traditional-media-by-turks-in-turkish-in-taksim-square-protests\/http:\/\/themonkeycage.org\/2013\/06\/01\/a-breakout-role-for-twitter-extensive-use-of-social-media-in-the-absence-of-traditional-media-by-turks-in-turkish-in-taksim-square-protests\/",
      "display_url" : "themonkeycage.org\/2013\/06\/01\/a-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342235368952832000",
  "text" : "RT @lousylinguist: Interesting study about social media and Turkey protests - 90% of all geolocated tweets are coming from within Turkey ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/kDUvyoZgVI",
        "expanded_url" : "http:\/\/themonkeycage.org\/2013\/06\/01\/a-breakout-role-for-twitter-extensive-use-of-social-media-in-the-absence-of-traditional-media-by-turks-in-turkish-in-taksim-square-protests\/http:\/\/themonkeycage.org\/2013\/06\/01\/a-breakout-role-for-twitter-extensive-use-of-social-media-in-the-absence-of-traditional-media-by-turks-in-turkish-in-taksim-square-protests\/",
        "display_url" : "themonkeycage.org\/2013\/06\/01\/a-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342111878639652864",
    "text" : "Interesting study about social media and Turkey protests - 90% of all geolocated tweets are coming from within Turkey http:\/\/t.co\/kDUvyoZgVI",
    "id" : 342111878639652864,
    "created_at" : "2013-06-05 02:53:22 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 342235368952832000,
  "created_at" : "2013-06-05 11:04:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 3, 14 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/kLHpDo3qLT",
      "expanded_url" : "http:\/\/www.xda-developers.com\/android\/say-sayonara-to-the-play-store-part-1\/",
      "display_url" : "xda-developers.com\/android\/say-sa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342232558374891520",
  "text" : "RT @dajbelshaw: Inspired by this article on xdadevelopers to try an Android phone with F-Droid instead of the Play Store: http:\/\/t.co\/kLHpD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/kLHpDo3qLT",
        "expanded_url" : "http:\/\/www.xda-developers.com\/android\/say-sayonara-to-the-play-store-part-1\/",
        "display_url" : "xda-developers.com\/android\/say-sa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342007814962696192",
    "text" : "Inspired by this article on xdadevelopers to try an Android phone with F-Droid instead of the Play Store: http:\/\/t.co\/kLHpDo3qLT",
    "id" : 342007814962696192,
    "created_at" : "2013-06-04 19:59:51 +0000",
    "user" : {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "protected" : false,
      "id_str" : "764365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699881076026687488\/Ga5TBJ0g_normal.jpg",
      "id" : 764365,
      "verified" : false
    }
  },
  "id" : 342232558374891520,
  "created_at" : "2013-06-05 10:52:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "indices" : [ 3, 16 ],
      "id_str" : "141530833",
      "id" : 141530833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/R27ajPHhys",
      "expanded_url" : "http:\/\/bit.ly\/11ftHKx",
      "display_url" : "bit.ly\/11ftHKx"
    } ]
  },
  "geo" : { },
  "id_str" : "342230175263633409",
  "text" : "RT @iatefl_ltsig: If you can't be at the image conference in person then watch online http:\/\/t.co\/R27ajPHhys #IATEFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/R27ajPHhys",
        "expanded_url" : "http:\/\/bit.ly\/11ftHKx",
        "display_url" : "bit.ly\/11ftHKx"
      } ]
    },
    "geo" : { },
    "id_str" : "342211161242079232",
    "text" : "If you can't be at the image conference in person then watch online http:\/\/t.co\/R27ajPHhys #IATEFL",
    "id" : 342211161242079232,
    "created_at" : "2013-06-05 09:27:53 +0000",
    "user" : {
      "name" : "IATEFL LTSIG",
      "screen_name" : "iatefl_ltsig",
      "protected" : false,
      "id_str" : "141530833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3559398421\/c33454189d56b57c68d3bfadec038dcb_normal.jpeg",
      "id" : 141530833,
      "verified" : false
    }
  },
  "id" : 342230175263633409,
  "created_at" : "2013-06-05 10:43:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "Olivia Lavelle",
      "screen_name" : "tilghborne",
      "indices" : [ 16, 27 ],
      "id_str" : "1476792397",
      "id" : 1476792397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341910889668157440",
  "geo" : { },
  "id_str" : "342230004924567552",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet @tilghborne nice! olivia made them herself?",
  "id" : 342230004924567552,
  "in_reply_to_status_id" : 341910889668157440,
  "created_at" : "2013-06-05 10:42:46 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342167444045049856",
  "geo" : { },
  "id_str" : "342229390601641985",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac great top!",
  "id" : 342229390601641985,
  "in_reply_to_status_id" : 342167444045049856,
  "created_at" : "2013-06-05 10:40:19 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 116, 127 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/imI2iXXauO",
      "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/06\/05\/teach-the-web-constructive-criticism-web-literacy-skills-proposal\/#.Ua8JqJPxTfE.twitter",
      "display_url" : "dogtrax.edublogs.org\/2013\/06\/05\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342220117188415488",
  "text" : "RT @dogtrax: Teach the Web Constructive Criticism: Web Literacy Skills Proposal http:\/\/t.co\/imI2iXXauO #teachtheweb @dajbelshaw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Doug Belshaw",
        "screen_name" : "dajbelshaw",
        "indices" : [ 103, 114 ],
        "id_str" : "764365",
        "id" : 764365
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtheweb",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/imI2iXXauO",
        "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/06\/05\/teach-the-web-constructive-criticism-web-literacy-skills-proposal\/#.Ua8JqJPxTfE.twitter",
        "display_url" : "dogtrax.edublogs.org\/2013\/06\/05\/tea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342216869824040960",
    "text" : "Teach the Web Constructive Criticism: Web Literacy Skills Proposal http:\/\/t.co\/imI2iXXauO #teachtheweb @dajbelshaw",
    "id" : 342216869824040960,
    "created_at" : "2013-06-05 09:50:34 +0000",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 342220117188415488,
  "created_at" : "2013-06-05 10:03:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 92, 104 ]
    }, {
      "text" : "elt",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/1BjNf90TzO",
      "expanded_url" : "http:\/\/bit.ly\/112IS9N",
      "display_url" : "bit.ly\/112IS9N"
    } ]
  },
  "geo" : { },
  "id_str" : "342217551352307712",
  "text" : "RT @CELTtraining: Summaries and comments complete on lexical conference. See you next year? #lexconf2013 #elt  http:\/\/t.co\/1BjNf90TzO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 74, 86 ]
      }, {
        "text" : "elt",
        "indices" : [ 87, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/1BjNf90TzO",
        "expanded_url" : "http:\/\/bit.ly\/112IS9N",
        "display_url" : "bit.ly\/112IS9N"
      } ]
    },
    "geo" : { },
    "id_str" : "342215257881706496",
    "text" : "Summaries and comments complete on lexical conference. See you next year? #lexconf2013 #elt  http:\/\/t.co\/1BjNf90TzO",
    "id" : 342215257881706496,
    "created_at" : "2013-06-05 09:44:10 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 342217551352307712,
  "created_at" : "2013-06-05 09:53:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342163309312749568",
  "geo" : { },
  "id_str" : "342184645250674688",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg commafeed worth a look",
  "id" : 342184645250674688,
  "in_reply_to_status_id" : 342163309312749568,
  "created_at" : "2013-06-05 07:42:31 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/lH1TE9M9Is",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2013\/jun\/04\/us-disaster-race-noam-chomsky",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342057929828077570",
  "text" : "Noam Chomsky How to destroy the future http:\/\/t.co\/lH1TE9M9Is",
  "id" : 342057929828077570,
  "created_at" : "2013-06-04 23:19:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antoine Besnehard",
      "screen_name" : "Languages2_0",
      "indices" : [ 0, 13 ],
      "id_str" : "28194214",
      "id" : 28194214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341906201669406721",
  "geo" : { },
  "id_str" : "342051093049655298",
  "in_reply_to_user_id" : 28194214,
  "text" : "@Languages2_0 ah dac, merci bien",
  "id" : 342051093049655298,
  "in_reply_to_status_id" : 341906201669406721,
  "created_at" : "2013-06-04 22:51:50 +0000",
  "in_reply_to_screen_name" : "Languages2_0",
  "in_reply_to_user_id_str" : "28194214",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    }, {
      "name" : "Ben Rimes",
      "screen_name" : "techsavvyed",
      "indices" : [ 67, 79 ],
      "id_str" : "11144032",
      "id" : 11144032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/0NIlFyPp9G",
      "expanded_url" : "http:\/\/bit.ly\/134GORh",
      "display_url" : "bit.ly\/134GORh"
    } ]
  },
  "geo" : { },
  "id_str" : "342047299159080960",
  "text" : "RT @mcleod: My Growing Concerns About Mainstream Education Blogs | @techsavvyed http:\/\/t.co\/0NIlFyPp9G Still love this post! #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Rimes",
        "screen_name" : "techsavvyed",
        "indices" : [ 55, 67 ],
        "id_str" : "11144032",
        "id" : 11144032
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/0NIlFyPp9G",
        "expanded_url" : "http:\/\/bit.ly\/134GORh",
        "display_url" : "bit.ly\/134GORh"
      } ]
    },
    "geo" : { },
    "id_str" : "342038127457751040",
    "text" : "My Growing Concerns About Mainstream Education Blogs | @techsavvyed http:\/\/t.co\/0NIlFyPp9G Still love this post! #edtech",
    "id" : 342038127457751040,
    "created_at" : "2013-06-04 22:00:19 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 342047299159080960,
  "created_at" : "2013-06-04 22:36:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 53, 61 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/FqP53M2s8P",
      "expanded_url" : "http:\/\/youtu.be\/PJkHwulsac4",
      "display_url" : "youtu.be\/PJkHwulsac4"
    } ]
  },
  "geo" : { },
  "id_str" : "341892570646999041",
  "text" : "Tetris Printer Algorithm: http:\/\/t.co\/FqP53M2s8P via @youtube",
  "id" : 341892570646999041,
  "created_at" : "2013-06-04 12:21:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/z3bJBlM3JU",
      "expanded_url" : "http:\/\/opensourceecology.org\/gvcs.php",
      "display_url" : "opensourceecology.org\/gvcs.php"
    } ]
  },
  "geo" : { },
  "id_str" : "341889761352511488",
  "text" : "Global Village Construction Set\nhttp:\/\/t.co\/z3bJBlM3JU&gt;potential engineering english lesson",
  "id" : 341889761352511488,
  "created_at" : "2013-06-04 12:10:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antoine Besnehard",
      "screen_name" : "Languages2_0",
      "indices" : [ 0, 13 ],
      "id_str" : "28194214",
      "id" : 28194214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/kViHKK2Rzq",
      "expanded_url" : "http:\/\/tice.det.fundp.ac.be\/clarolex\/index.php?category=lang",
      "display_url" : "tice.det.fundp.ac.be\/clarolex\/index\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "341860126619209729",
  "geo" : { },
  "id_str" : "341884269255344128",
  "in_reply_to_user_id" : 28194214,
  "text" : "@Languages2_0 merci, je n'ai trouv\u00E9 que - http:\/\/t.co\/kViHKK2Rzq, avez vous des liens?",
  "id" : 341884269255344128,
  "in_reply_to_status_id" : 341860126619209729,
  "created_at" : "2013-06-04 11:48:56 +0000",
  "in_reply_to_screen_name" : "Languages2_0",
  "in_reply_to_user_id_str" : "28194214",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/7NaME3uneC",
      "expanded_url" : "http:\/\/wp.me\/p2svM7-11I",
      "display_url" : "wp.me\/p2svM7-11I"
    } ]
  },
  "geo" : { },
  "id_str" : "341880591119155201",
  "text" : "Gesturecraft: J\u00FCrgen Streeck on the manufacturing of gesture: http:\/\/t.co\/7NaME3uneC via @leakygrammar",
  "id" : 341880591119155201,
  "created_at" : "2013-06-04 11:34:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 77, 87 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/6u6Mcjs1YF",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1370338894.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341855654878781441",
  "text" : "Edward Abbey on 'the problem of evil institutions' http:\/\/t.co\/6u6Mcjs1YF ht @medialens",
  "id" : 341855654878781441,
  "created_at" : "2013-06-04 09:55:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/U5KIHG3RfY",
      "expanded_url" : "http:\/\/www.comres.co.uk\/polls\/Iraqi_death_toll_survey_June_2013.pdf",
      "display_url" : "comres.co.uk\/polls\/Iraqi_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341839946191106048",
  "text" : "as compelling as you can get about power of modern media to hide the facts about war deaths http:\/\/t.co\/U5KIHG3RfY",
  "id" : 341839946191106048,
  "created_at" : "2013-06-04 08:52:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "indices" : [ 71, 78 ],
      "id_str" : "749992082",
      "id" : 749992082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WN2FBri0rP",
      "expanded_url" : "http:\/\/ow.ly\/lxXhg",
      "display_url" : "ow.ly\/lxXhg"
    } ]
  },
  "geo" : { },
  "id_str" : "341809145302888448",
  "text" : "RT @TSchnoebelen: RT @pimsleurtweets: \u200FInteresting number-crunching RT @idibon Which languages are shaping the world's economies?: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Idibon",
        "screen_name" : "idibon",
        "indices" : [ 53, 60 ],
        "id_str" : "749992082",
        "id" : 749992082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/WN2FBri0rP",
        "expanded_url" : "http:\/\/ow.ly\/lxXhg",
        "display_url" : "ow.ly\/lxXhg"
      } ]
    },
    "geo" : { },
    "id_str" : "341688347909042177",
    "text" : "RT @pimsleurtweets: \u200FInteresting number-crunching RT @idibon Which languages are shaping the world's economies?: http:\/\/t.co\/WN2FBri0rP",
    "id" : 341688347909042177,
    "created_at" : "2013-06-03 22:50:25 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 341809145302888448,
  "created_at" : "2013-06-04 06:50:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 74, 90 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/CeC6pUnbQG",
      "expanded_url" : "http:\/\/wp.me\/p32IOl-6B",
      "display_url" : "wp.me\/p32IOl-6B"
    } ]
  },
  "geo" : { },
  "id_str" : "341730174359965696",
  "text" : "On the 'F' bomb: Feminism's \"branding problem\" http:\/\/t.co\/CeC6pUnbQG via @wordpressdotcom",
  "id" : 341730174359965696,
  "created_at" : "2013-06-04 01:36:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 103, 118 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/bpp0ktwZGf",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-n4",
      "display_url" : "wp.me\/p3qkCB-n4"
    } ]
  },
  "geo" : { },
  "id_str" : "341711937454874625",
  "text" : "get yr popcorn ready &gt;&gt;Why do an MA in Applied Linguistics and TESOL? http:\/\/t.co\/bpp0ktwZGf via @GeoffreyJordan",
  "id" : 341711937454874625,
  "created_at" : "2013-06-04 00:24:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Poetics",
      "screen_name" : "GooglePoetics",
      "indices" : [ 3, 17 ],
      "id_str" : "912570883",
      "id" : 912570883
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GooglePoetics\/status\/341668561183444993\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/SivXecpc0N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL3ZvwSCEAA9wPN.png",
      "id_str" : "341668561187639296",
      "id" : 341668561187639296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL3ZvwSCEAA9wPN.png",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 120,
        "resize" : "crop",
        "w" : 120
      }, {
        "h" : 70,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SivXecpc0N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341694946174173185",
  "text" : "RT @GooglePoetics: I only have two friends\nI only have two wisdom teeth\nI only have two hdmi inputs\nI only have two things in this world ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GooglePoetics\/status\/341668561183444993\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/SivXecpc0N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BL3ZvwSCEAA9wPN.png",
        "id_str" : "341668561187639296",
        "id" : 341668561187639296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL3ZvwSCEAA9wPN.png",
        "sizes" : [ {
          "h" : 120,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 120,
          "resize" : "crop",
          "w" : 120
        }, {
          "h" : 70,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SivXecpc0N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341668561183444993",
    "text" : "I only have two friends\nI only have two wisdom teeth\nI only have two hdmi inputs\nI only have two things in this world http:\/\/t.co\/SivXecpc0N",
    "id" : 341668561183444993,
    "created_at" : "2013-06-03 21:31:47 +0000",
    "user" : {
      "name" : "Google Poetics",
      "screen_name" : "GooglePoetics",
      "protected" : false,
      "id_str" : "912570883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000152236311\/e364d2a13dab35a8b65c9decf71ae134_normal.jpeg",
      "id" : 912570883,
      "verified" : false
    }
  },
  "id" : 341694946174173185,
  "created_at" : "2013-06-03 23:16:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341648545797001216",
  "geo" : { },
  "id_str" : "341656458523471872",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt for sure #eapchat",
  "id" : 341656458523471872,
  "in_reply_to_status_id" : 341648545797001216,
  "created_at" : "2013-06-03 20:43:42 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341654073830952960",
  "geo" : { },
  "id_str" : "341656333747097601",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt haha thems the twitter breaks! cheers all #eapchat",
  "id" : 341656333747097601,
  "in_reply_to_status_id" : 341654073830952960,
  "created_at" : "2013-06-03 20:43:12 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Giffen",
      "screen_name" : "GlennGi",
      "indices" : [ 0, 8 ],
      "id_str" : "1354660710",
      "id" : 1354660710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341648355828576257",
  "geo" : { },
  "id_str" : "341655581284769792",
  "in_reply_to_user_id" : 1354660710,
  "text" : "@GlennGi do you know of any public free learner corpora?",
  "id" : 341655581284769792,
  "in_reply_to_status_id" : 341648355828576257,
  "created_at" : "2013-06-03 20:40:12 +0000",
  "in_reply_to_screen_name" : "GlennGi",
  "in_reply_to_user_id_str" : "1354660710",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341651579692277760",
  "text" : "the more i play with duolingo and read about how it works more i like it #eapchat",
  "id" : 341651579692277760,
  "created_at" : "2013-06-03 20:24:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Giffen",
      "screen_name" : "GlennGi",
      "indices" : [ 0, 8 ],
      "id_str" : "1354660710",
      "id" : 1354660710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341647772547702784",
  "in_reply_to_user_id" : 1354660710,
  "text" : "@GlennGi i vaguely recall a recent story about urban dictionary being cited in a court case #eapchat",
  "id" : 341647772547702784,
  "created_at" : "2013-06-03 20:09:11 +0000",
  "in_reply_to_screen_name" : "GlennGi",
  "in_reply_to_user_id_str" : "1354660710",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341647002536407040",
  "text" : "learner corpora are definitely interesting, if only to save you time once it's compiled :) #eapchat",
  "id" : 341647002536407040,
  "created_at" : "2013-06-03 20:06:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Giffen",
      "screen_name" : "GlennGi",
      "indices" : [ 0, 8 ],
      "id_str" : "1354660710",
      "id" : 1354660710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341645057499226112",
  "geo" : { },
  "id_str" : "341645407392243712",
  "in_reply_to_user_id" : 1354660710,
  "text" : "@GlennGi no but it is on my todo list! have you? #eapchat",
  "id" : 341645407392243712,
  "in_reply_to_status_id" : 341645057499226112,
  "created_at" : "2013-06-03 19:59:47 +0000",
  "in_reply_to_screen_name" : "GlennGi",
  "in_reply_to_user_id_str" : "1354660710",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341644871649603585",
  "text" : "@EBEFL does it come with a money back guarantee? :)",
  "id" : 341644871649603585,
  "created_at" : "2013-06-03 19:57:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burr Settles",
      "screen_name" : "burrsettles",
      "indices" : [ 52, 64 ],
      "id_str" : "125822301",
      "id" : 125822301
    }, {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 68, 77 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 78, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/IvjKuhOwuz",
      "expanded_url" : "http:\/\/wp.me\/p2UMFz-7J",
      "display_url" : "wp.me\/p2UMFz-7J"
    } ]
  },
  "geo" : { },
  "id_str" : "341643891751124993",
  "text" : "On \"Geek\" Versus \"Nerd\" http:\/\/t.co\/IvjKuhOwuz  via @burrsettles ht @wiobyrne #corpuslinguistics",
  "id" : 341643891751124993,
  "created_at" : "2013-06-03 19:53:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341638035408056320",
  "geo" : { },
  "id_str" : "341639410233798657",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt i vaguely recall you doing student blogging before, is this a development of that? #eapchat",
  "id" : 341639410233798657,
  "in_reply_to_status_id" : 341638035408056320,
  "created_at" : "2013-06-03 19:35:57 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/xAqPaMtjfb",
      "expanded_url" : "http:\/\/en.pons.eu\/",
      "display_url" : "en.pons.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "341638405576335360",
  "text" : "correct link http:\/\/t.co\/xAqPaMtjfb #eapchat",
  "id" : 341638405576335360,
  "created_at" : "2013-06-03 19:31:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/eOl6xem5AP",
      "expanded_url" : "http:\/\/en.pons.eu\/,not",
      "display_url" : "en.pons.eu\/,not"
    } ]
  },
  "geo" : { },
  "id_str" : "341638078156390400",
  "text" : "there is the pons dictionnary http:\/\/t.co\/eOl6xem5AP used it yet but their vocab trainer tool seems interesting #eapchat",
  "id" : 341638078156390400,
  "created_at" : "2013-06-03 19:30:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/aUX0mNQmsx",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/04\/27\/stringnet-exploring-will-suit-you\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/04\/27\/str\u2026"
    }, {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/VrmGJzUFhQ",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/05\/21\/paper-machines-look-ma-no-concordance-lines\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/05\/21\/pap\u2026"
    }, {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/FnRfXFHvfB",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/05\/30\/dictionnaire-cobra-a-striking-corpus-based-tool\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/05\/30\/dic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341636745915404289",
  "text" : "stringnet http:\/\/t.co\/aUX0mNQmsx, papermachines http:\/\/t.co\/VrmGJzUFhQ, cobra http:\/\/t.co\/FnRfXFHvfB #eapchat",
  "id" : 341636745915404289,
  "created_at" : "2013-06-03 19:25:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341636598267527168",
  "text" : "apologies for blogalanche links coming up but they explain how i used them as well as links to tools :) #eapchat",
  "id" : 341636598267527168,
  "created_at" : "2013-06-03 19:24:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341634787104133120",
  "text" : "recently i have used stringnet, papermachines and dictionnaire cobra - corpus based tools #eapchat",
  "id" : 341634787104133120,
  "created_at" : "2013-06-03 19:17:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341633889229484034",
  "text" : "hi tyson, am about but lurking #eapchat",
  "id" : 341633889229484034,
  "created_at" : "2013-06-03 19:14:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 3, 18 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/RctULl73v4",
      "expanded_url" : "http:\/\/www.ambientinsight.com\/Resources\/Documents\/AmbientInsight-2011-2016-Worldwide-Digital-English-Language-Learning-Market-Overview.pdf",
      "display_url" : "ambientinsight.com\/Resources\/Docu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341552085956956160",
  "text" : "RT @markwarschauer: The Worldwide Market for Digital English Language Learning Products and Services: 2011-2016 http:\/\/t.co\/RctULl73v4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/RctULl73v4",
        "expanded_url" : "http:\/\/www.ambientinsight.com\/Resources\/Documents\/AmbientInsight-2011-2016-Worldwide-Digital-English-Language-Learning-Market-Overview.pdf",
        "display_url" : "ambientinsight.com\/Resources\/Docu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "341551642463834112",
    "text" : "The Worldwide Market for Digital English Language Learning Products and Services: 2011-2016 http:\/\/t.co\/RctULl73v4",
    "id" : 341551642463834112,
    "created_at" : "2013-06-03 13:47:11 +0000",
    "user" : {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "protected" : false,
      "id_str" : "17316060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535141210432622592\/ZXqkNrhW_normal.jpeg",
      "id" : 17316060,
      "verified" : false
    }
  },
  "id" : 341552085956956160,
  "created_at" : "2013-06-03 13:48:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/uH7F6ysibF",
      "expanded_url" : "http:\/\/nyr.kr\/12wgShi",
      "display_url" : "nyr.kr\/12wgShi"
    } ]
  },
  "geo" : { },
  "id_str" : "341551476788822016",
  "text" : "RT @heatherfro: The curse of reading and forgetting http:\/\/t.co\/uH7F6ysibF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/uH7F6ysibF",
        "expanded_url" : "http:\/\/nyr.kr\/12wgShi",
        "display_url" : "nyr.kr\/12wgShi"
      } ]
    },
    "geo" : { },
    "id_str" : "341483432947363842",
    "text" : "The curse of reading and forgetting http:\/\/t.co\/uH7F6ysibF",
    "id" : 341483432947363842,
    "created_at" : "2013-06-03 09:16:09 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 341551476788822016,
  "created_at" : "2013-06-03 13:46:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/dtqozzD9bV",
      "expanded_url" : "http:\/\/fourc.ca\/diary-toscon13\/?utm_source=rss&utm_medium=rss&utm_campaign=diary-toscon13",
      "display_url" : "fourc.ca\/diary-toscon13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341265890920243200",
  "text" : "Diary of a conference chair http:\/\/t.co\/dtqozzD9bV",
  "id" : 341265890920243200,
  "created_at" : "2013-06-02 18:51:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 106, 114 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/go1jTTSIDv",
      "expanded_url" : "http:\/\/www.google.com\/campaigns\/gonegoogle\/masters-demo\/index.html",
      "display_url" : "google.com\/campaigns\/gone\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341237249494622208",
  "text" : "write along with Poe, Dickenson, Dostoyevsky, Nietizche, Shakespeare, Dickens http:\/\/t.co\/go1jTTSIDv \u2026 ht @dogtrax #eltchat",
  "id" : 341237249494622208,
  "created_at" : "2013-06-02 16:57:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Huseyin Kishi",
      "screen_name" : "huseyinkishi",
      "indices" : [ 137, 140 ],
      "id_str" : "214993076",
      "id" : 214993076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Izhv9C4rD4",
      "expanded_url" : "http:\/\/tinyurl.com\/mq63s83",
      "display_url" : "tinyurl.com\/mq63s83"
    } ]
  },
  "geo" : { },
  "id_str" : "341216156125900800",
  "text" : "RT @medialens: Chomsky interview: 9:25 has the first capture on film of the sound of an interviewer's ego popping http:\/\/t.co\/Izhv9C4rD4 @h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huseyin Kishi",
        "screen_name" : "huseyinkishi",
        "indices" : [ 122, 135 ],
        "id_str" : "214993076",
        "id" : 214993076
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Izhv9C4rD4",
        "expanded_url" : "http:\/\/tinyurl.com\/mq63s83",
        "display_url" : "tinyurl.com\/mq63s83"
      } ]
    },
    "geo" : { },
    "id_str" : "341149039225618432",
    "text" : "Chomsky interview: 9:25 has the first capture on film of the sound of an interviewer's ego popping http:\/\/t.co\/Izhv9C4rD4 @huseyinkishi",
    "id" : 341149039225618432,
    "created_at" : "2013-06-02 11:07:23 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 341216156125900800,
  "created_at" : "2013-06-02 15:34:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/NSrxePVe1d",
      "expanded_url" : "http:\/\/bit.ly\/14k0Vua",
      "display_url" : "bit.ly\/14k0Vua"
    } ]
  },
  "geo" : { },
  "id_str" : "341207379175682048",
  "text" : "RT @CraigMurrayOrg: Talking Turkey: To simply say \u201Cprotestors good, government bad\u201D in Turkey is a symptom of the Blair delusion, ... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/NSrxePVe1d",
        "expanded_url" : "http:\/\/bit.ly\/14k0Vua",
        "display_url" : "bit.ly\/14k0Vua"
      } ]
    },
    "geo" : { },
    "id_str" : "341081886220775424",
    "text" : "Talking Turkey: To simply say \u201Cprotestors good, government bad\u201D in Turkey is a symptom of the Blair delusion, ... http:\/\/t.co\/NSrxePVe1d",
    "id" : 341081886220775424,
    "created_at" : "2013-06-02 06:40:33 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 341207379175682048,
  "created_at" : "2013-06-02 14:59:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/MFdwZDjw0n",
      "expanded_url" : "http:\/\/skrashen.blogspot.com\/2013\/06\/common-cores-claims-are-false.html?spref=tw",
      "display_url" : "skrashen.blogspot.com\/2013\/06\/common\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341130956608004097",
  "text" : "SKrashen: Common core's claims are false http:\/\/t.co\/MFdwZDjw0n",
  "id" : 341130956608004097,
  "created_at" : "2013-06-02 09:55:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 45, 61 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/3OuYTADBwM",
      "expanded_url" : "http:\/\/wp.me\/p1tYEb-Fs",
      "display_url" : "wp.me\/p1tYEb-Fs"
    } ]
  },
  "geo" : { },
  "id_str" : "341129521266839552",
  "text" : "Business as usual http:\/\/t.co\/3OuYTADBwM via @wordpressdotcom",
  "id" : 341129521266839552,
  "created_at" : "2013-06-02 09:49:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 3, 14 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "Christos Pasialis",
      "screen_name" : "ChristosPas",
      "indices" : [ 19, 31 ],
      "id_str" : "28839985",
      "id" : 28839985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "efl",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "education",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ezYr2KGPVO",
      "expanded_url" : "http:\/\/www.truth-out.org\/opinion\/item\/16651-noam-chomsky-on-democracy-and-education-in-the-21st-century-and-beyond",
      "display_url" : "truth-out.org\/opinion\/item\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341118987054231552",
  "text" : "RT @mattellman: RT @ChristosPas Chomsky on Democracy and Education in the 21st Century http:\/\/t.co\/ezYr2KGPVO #edchat #ukedchat #efl #educa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christos Pasialis",
        "screen_name" : "ChristosPas",
        "indices" : [ 3, 15 ],
        "id_str" : "28839985",
        "id" : 28839985
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 94, 101 ]
      }, {
        "text" : "ukedchat",
        "indices" : [ 102, 111 ]
      }, {
        "text" : "efl",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "education",
        "indices" : [ 117, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/ezYr2KGPVO",
        "expanded_url" : "http:\/\/www.truth-out.org\/opinion\/item\/16651-noam-chomsky-on-democracy-and-education-in-the-21st-century-and-beyond",
        "display_url" : "truth-out.org\/opinion\/item\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "341113246499094528",
    "text" : "RT @ChristosPas Chomsky on Democracy and Education in the 21st Century http:\/\/t.co\/ezYr2KGPVO #edchat #ukedchat #efl #education",
    "id" : 341113246499094528,
    "created_at" : "2013-06-02 08:45:10 +0000",
    "user" : {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "protected" : false,
      "id_str" : "394987109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1615371192\/classpic_normal.jpg",
      "id" : 394987109,
      "verified" : false
    }
  },
  "id" : 341118987054231552,
  "created_at" : "2013-06-02 09:07:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "tefl",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KzHidrfPtO",
      "expanded_url" : "http:\/\/bit.ly\/11LvNYC",
      "display_url" : "bit.ly\/11LvNYC"
    } ]
  },
  "geo" : { },
  "id_str" : "340952811552518144",
  "text" : "RT @leoselivan: New blog post\/rant: SLA research: still in the shackles of traditional grammar? | Leoxicon  http:\/\/t.co\/KzHidrfPtO #elt #te\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "tefl",
        "indices" : [ 120, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/KzHidrfPtO",
        "expanded_url" : "http:\/\/bit.ly\/11LvNYC",
        "display_url" : "bit.ly\/11LvNYC"
      } ]
    },
    "geo" : { },
    "id_str" : "340929308711350273",
    "text" : "New blog post\/rant: SLA research: still in the shackles of traditional grammar? | Leoxicon  http:\/\/t.co\/KzHidrfPtO #elt #tefl",
    "id" : 340929308711350273,
    "created_at" : "2013-06-01 20:34:16 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 340952811552518144,
  "created_at" : "2013-06-01 22:07:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benenden",
      "screen_name" : "benendenhealth",
      "indices" : [ 0, 15 ],
      "id_str" : "3130937097",
      "id" : 3130937097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340826453115551745",
  "geo" : { },
  "id_str" : "340829926561300481",
  "in_reply_to_user_id" : 68386855,
  "text" : "@benendenhealth thx,  was survey done only online?",
  "id" : 340829926561300481,
  "in_reply_to_status_id" : 340826453115551745,
  "created_at" : "2013-06-01 13:59:21 +0000",
  "in_reply_to_screen_name" : "BenendenUK",
  "in_reply_to_user_id_str" : "68386855",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Ealasaid Munro",
      "screen_name" : "Ealasaidmunro",
      "indices" : [ 139, 140 ],
      "id_str" : "248853294",
      "id" : 248853294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/egPXDNjAI3",
      "expanded_url" : "http:\/\/bit.ly\/19tnpyq",
      "display_url" : "bit.ly\/19tnpyq"
    } ]
  },
  "geo" : { },
  "id_str" : "340822299030716417",
  "text" : "RT @heatherfro: tracking anti-Muslim prejudice and\/or Islamophobia on Twitter, featuring some word frequencies: http:\/\/t.co\/egPXDNjAI3 via \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ealasaid Munro",
        "screen_name" : "Ealasaidmunro",
        "indices" : [ 123, 137 ],
        "id_str" : "248853294",
        "id" : 248853294
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/egPXDNjAI3",
        "expanded_url" : "http:\/\/bit.ly\/19tnpyq",
        "display_url" : "bit.ly\/19tnpyq"
      } ]
    },
    "geo" : { },
    "id_str" : "340501476067659776",
    "text" : "tracking anti-Muslim prejudice and\/or Islamophobia on Twitter, featuring some word frequencies: http:\/\/t.co\/egPXDNjAI3 via @ealasaidmunro",
    "id" : 340501476067659776,
    "created_at" : "2013-05-31 16:14:12 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 340822299030716417,
  "created_at" : "2013-06-01 13:29:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Axel Bruns",
      "screen_name" : "snurb_dot_info",
      "indices" : [ 29, 44 ],
      "id_str" : "78807415",
      "id" : 78807415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socmed",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/GoiiVtUs8V",
      "expanded_url" : "http:\/\/ow.ly\/1WXKPV",
      "display_url" : "ow.ly\/1WXKPV"
    } ]
  },
  "geo" : { },
  "id_str" : "340822096026419200",
  "text" : "RT @amyaishab: Love these RT @snurb_dot_info: Wow - some beautiful visualisations of geotagged tweets on the Twitter Blog: http:\/\/t.co\/Goii\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Axel Bruns",
        "screen_name" : "snurb_dot_info",
        "indices" : [ 14, 29 ],
        "id_str" : "78807415",
        "id" : 78807415
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socmed",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/GoiiVtUs8V",
        "expanded_url" : "http:\/\/ow.ly\/1WXKPV",
        "display_url" : "ow.ly\/1WXKPV"
      } ]
    },
    "geo" : { },
    "id_str" : "340776940296339457",
    "text" : "Love these RT @snurb_dot_info: Wow - some beautiful visualisations of geotagged tweets on the Twitter Blog: http:\/\/t.co\/GoiiVtUs8V #socmed",
    "id" : 340776940296339457,
    "created_at" : "2013-06-01 10:28:48 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 340822096026419200,
  "created_at" : "2013-06-01 13:28:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benenden",
      "screen_name" : "benendenhealth",
      "indices" : [ 0, 15 ],
      "id_str" : "3130937097",
      "id" : 3130937097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340449826460291073",
  "geo" : { },
  "id_str" : "340803404802691073",
  "in_reply_to_user_id" : 68386855,
  "text" : "@benendenhealth hi do you have any details about yr recent study? e.g. how did you collect 'throwaway' phrases?",
  "id" : 340803404802691073,
  "in_reply_to_status_id" : 340449826460291073,
  "created_at" : "2013-06-01 12:13:58 +0000",
  "in_reply_to_screen_name" : "BenendenUK",
  "in_reply_to_user_id_str" : "68386855",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/v1RLsxb4fA",
      "expanded_url" : "http:\/\/tinyurl.com\/oyxkpm4",
      "display_url" : "tinyurl.com\/oyxkpm4"
    } ]
  },
  "geo" : { },
  "id_str" : "340590110464671744",
  "text" : "RT @medialens: Iraq poll: 59% of UK public estimate deaths below 10,000 http:\/\/t.co\/v1RLsxb4fA Real figure likely 1,000,000.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/v1RLsxb4fA",
        "expanded_url" : "http:\/\/tinyurl.com\/oyxkpm4",
        "display_url" : "tinyurl.com\/oyxkpm4"
      } ]
    },
    "geo" : { },
    "id_str" : "340115306716491777",
    "text" : "Iraq poll: 59% of UK public estimate deaths below 10,000 http:\/\/t.co\/v1RLsxb4fA Real figure likely 1,000,000.",
    "id" : 340115306716491777,
    "created_at" : "2013-05-30 14:39:42 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 340590110464671744,
  "created_at" : "2013-05-31 22:06:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]