Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 3, 15 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 17, 26 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/pfBCAySrUQ",
      "expanded_url" : "http:\/\/bit.ly\/1Qe0VGY",
      "display_url" : "bit.ly\/1Qe0VGY"
    } ]
  },
  "geo" : { },
  "id_str" : "704296124035817472",
  "text" : "RT @patriciambr: @muranava My blog 2 anniversary double book raffle on terminology and translation https:\/\/t.co\/pfBCAySrUQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/pfBCAySrUQ",
        "expanded_url" : "http:\/\/bit.ly\/1Qe0VGY",
        "display_url" : "bit.ly\/1Qe0VGY"
      } ]
    },
    "geo" : { },
    "id_str" : "704057622329225217",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava My blog 2 anniversary double book raffle on terminology and translation https:\/\/t.co\/pfBCAySrUQ",
    "id" : 704057622329225217,
    "created_at" : "2016-02-28 21:36:32 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "protected" : false,
      "id_str" : "35764443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540310171541438464\/YprBqoGt_normal.jpeg",
      "id" : 35764443,
      "verified" : false
    }
  },
  "id" : 704296124035817472,
  "created_at" : "2016-02-29 13:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 10, 21 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703719947738836992",
  "geo" : { },
  "id_str" : "703943755255189505",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @MattEllman thx for the RT :)",
  "id" : 703943755255189505,
  "in_reply_to_status_id" : 703719947738836992,
  "created_at" : "2016-02-28 14:04:04 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anabel Fern\u00E1ndez",
      "screen_name" : "dimodeca",
      "indices" : [ 0, 9 ],
      "id_str" : "1235503316",
      "id" : 1235503316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703927213540904960",
  "geo" : { },
  "id_str" : "703943577030811649",
  "in_reply_to_user_id" : 1235503316,
  "text" : "@dimodeca thanks for sharing :)",
  "id" : 703943577030811649,
  "in_reply_to_status_id" : 703927213540904960,
  "created_at" : "2016-02-28 14:03:22 +0000",
  "in_reply_to_screen_name" : "dimodeca",
  "in_reply_to_user_id_str" : "1235503316",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/o0exPWqIDh",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/feb\/28\/silicon-valley-basic-income",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703943554784215040",
  "text" : "RT @evgenymorozov: My latest: \"Silicon Valley talks a good game on \u2018basic income\u2019, but its words are empty\" https:\/\/t.co\/o0exPWqIDh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/o0exPWqIDh",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/feb\/28\/silicon-valley-basic-income",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703742794817523715",
    "text" : "My latest: \"Silicon Valley talks a good game on \u2018basic income\u2019, but its words are empty\" https:\/\/t.co\/o0exPWqIDh",
    "id" : 703742794817523715,
    "created_at" : "2016-02-28 00:45:31 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 703943554784215040,
  "created_at" : "2016-02-28 14:03:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Kirk",
      "screen_name" : "stiivkirk",
      "indices" : [ 0, 10 ],
      "id_str" : "69068757",
      "id" : 69068757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703907552418013185",
  "geo" : { },
  "id_str" : "703933104063381505",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiivkirk  ah very true thx",
  "id" : 703933104063381505,
  "in_reply_to_status_id" : 703907552418013185,
  "created_at" : "2016-02-28 13:21:45 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Mari Yamauchi",
      "screen_name" : "m_yam",
      "indices" : [ 10, 16 ],
      "id_str" : "21755807",
      "id" : 21755807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703719947738836992",
  "geo" : { },
  "id_str" : "703904570632753152",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @m_yam thanks for sharing :)",
  "id" : 703904570632753152,
  "in_reply_to_status_id" : 703719947738836992,
  "created_at" : "2016-02-28 11:28:22 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703893573918392320",
  "geo" : { },
  "id_str" : "703904006209454080",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin thanks Sandy :)",
  "id" : 703904006209454080,
  "in_reply_to_status_id" : 703893573918392320,
  "created_at" : "2016-02-28 11:26:07 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 13, 24 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Steve Kirk",
      "screen_name" : "stiivkirk",
      "indices" : [ 25, 35 ],
      "id_str" : "69068757",
      "id" : 69068757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703595503158689793",
  "geo" : { },
  "id_str" : "703903788801892352",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @lexicoj0hn @stiivkirk what does the slide mean?",
  "id" : 703903788801892352,
  "in_reply_to_status_id" : 703595503158689793,
  "created_at" : "2016-02-28 11:25:15 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 10, 17 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703850759016706048",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @SobejM thanks Monika any comments welcome : )",
  "id" : 703850759016706048,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-28 07:54:32 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703849360207949829",
  "geo" : { },
  "id_str" : "703849545449365507",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ha : )",
  "id" : 703849545449365507,
  "in_reply_to_status_id" : 703849360207949829,
  "created_at" : "2016-02-28 07:49:43 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703719947738836992",
  "geo" : { },
  "id_str" : "703849073711804416",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish thx Marc : )",
  "id" : 703849073711804416,
  "in_reply_to_status_id" : 703719947738836992,
  "created_at" : "2016-02-28 07:47:50 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 78, 88 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703825479426375680",
  "geo" : { },
  "id_str" : "703848868098670592",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha cheers Hana, i just corrected mistake for name of corpus thanks to @RudyLoock",
  "id" : 703848868098670592,
  "in_reply_to_status_id" : 703825479426375680,
  "created_at" : "2016-02-28 07:47:01 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703844073094803456",
  "geo" : { },
  "id_str" : "703848327327002628",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock doh! thanks!",
  "id" : 703848327327002628,
  "in_reply_to_status_id" : 703844073094803456,
  "created_at" : "2016-02-28 07:44:52 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Jam.es Reilly",
      "screen_name" : "jamreilly",
      "indices" : [ 10, 20 ],
      "id_str" : "19358349",
      "id" : 19358349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703730232121921536",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @jamreilly thanks for the like James, any thoughts welcome : )",
  "id" : 703730232121921536,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-27 23:55:36 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703722467307556864",
  "geo" : { },
  "id_str" : "703729482537046017",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers Anne : )",
  "id" : 703729482537046017,
  "in_reply_to_status_id" : 703722467307556864,
  "created_at" : "2016-02-27 23:52:37 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 0, 10 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703722125669093376",
  "geo" : { },
  "id_str" : "703729443865501696",
  "in_reply_to_user_id" : 295968758,
  "text" : "@nakanotim thanks : )",
  "id" : 703729443865501696,
  "in_reply_to_status_id" : 703722125669093376,
  "created_at" : "2016-02-27 23:52:28 +0000",
  "in_reply_to_screen_name" : "nakanotim",
  "in_reply_to_user_id_str" : "295968758",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 11, 23 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "The Times of London",
      "screen_name" : "thetimes",
      "indices" : [ 24, 33 ],
      "id_str" : "6107422",
      "id" : 6107422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703581362398371840",
  "geo" : { },
  "id_str" : "703729261115531264",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @rosendo_joe @thetimes uh oh i think i am a comical ollie enabler :\/",
  "id" : 703729261115531264,
  "in_reply_to_status_id" : 703581362398371840,
  "created_at" : "2016-02-27 23:51:45 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 10, 20 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703721084009500673",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @nakanotim cheers for RT Tim, any comments welcome : )",
  "id" : 703721084009500673,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-27 23:19:15 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703710811529699328",
  "geo" : { },
  "id_str" : "703720607381364736",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne : )",
  "id" : 703720607381364736,
  "in_reply_to_status_id" : 703710811529699328,
  "created_at" : "2016-02-27 23:17:21 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/703719947738836992\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/9wqLM2XV9f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcQdkBYVIAAcfqb.jpg",
      "id_str" : "703719946459619328",
      "id" : 703719946459619328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcQdkBYVIAAcfqb.jpg",
      "sizes" : [ {
        "h" : 75,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9wqLM2XV9f"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "efl",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "esl",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "tesol",
      "indices" : [ 64, 70 ]
    }, {
      "text" : "tefl",
      "indices" : [ 71, 76 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/BwgE5krNhF",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/02\/28\/moncq-and-fresh-make-do-collocations",
      "display_url" : "eflnotes.wordpress.com\/2016\/02\/28\/mon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703719947738836992",
  "text" : "Moncq and \"fresh\" make &amp; do collocations #eltchat #efl #esl #tesol #tefl #eltchinwag\u2026 https:\/\/t.co\/BwgE5krNhF https:\/\/t.co\/9wqLM2XV9f",
  "id" : 703719947738836992,
  "created_at" : "2016-02-27 23:14:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 10, 21 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703699508920721410",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @lexicoj0hn thanks for the like John : ) any thoughts on ebook welcome!",
  "id" : 703699508920721410,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-27 21:53:31 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/d8DmAAnUFP",
      "expanded_url" : "http:\/\/corpus.byu.edu\/upcoming.asp",
      "display_url" : "corpus.byu.edu\/upcoming.asp"
    } ]
  },
  "in_reply_to_status_id_str" : "703697259544719360",
  "geo" : { },
  "id_str" : "703698737303064576",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish happening in May \"a cleaner, more intuitive  search interface\" https:\/\/t.co\/d8DmAAnUFP be interesting to see",
  "id" : 703698737303064576,
  "in_reply_to_status_id" : 703697259544719360,
  "created_at" : "2016-02-27 21:50:27 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703695629684383744",
  "geo" : { },
  "id_str" : "703696507036368896",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish good to hear about the going; top Smaswords, haha, as i said read it before the interface changes : )",
  "id" : 703696507036368896,
  "in_reply_to_status_id" : 703695629684383744,
  "created_at" : "2016-02-27 21:41:35 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703694626100740096",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish thanks Marc, how's the Massachusetts going? : )",
  "id" : 703694626100740096,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-27 21:34:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "indices" : [ 0, 13 ],
      "id_str" : "381086898",
      "id" : 381086898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/khdEIJaIc8",
      "expanded_url" : "http:\/\/www.skylight-to-english.co.uk\/skylight\/",
      "display_url" : "skylight-to-english.co.uk\/skylight\/"
    } ]
  },
  "in_reply_to_status_id_str" : "703691442917654532",
  "geo" : { },
  "id_str" : "703692151922814976",
  "in_reply_to_user_id" : 381086898,
  "text" : "@e_d_driscoll not used phrasesinenglish for ages need to see what's changed; have u tried skylight? https:\/\/t.co\/khdEIJaIc8",
  "id" : 703692151922814976,
  "in_reply_to_status_id" : 703691442917654532,
  "created_at" : "2016-02-27 21:24:17 +0000",
  "in_reply_to_screen_name" : "e_d_driscoll",
  "in_reply_to_user_id_str" : "381086898",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703640556430336001",
  "geo" : { },
  "id_str" : "703690967958822913",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway it is nice mointor corpus, i think the slow server was when i was testing the new collocation feature",
  "id" : 703690967958822913,
  "in_reply_to_status_id" : 703640556430336001,
  "created_at" : "2016-02-27 21:19:35 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/YPAF31FCC5",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/703636962729656320",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703690619097649152",
  "text" : "RT @eilymurphy: Thanks for these practical examples of COCA use Mura - great stuff! https:\/\/t.co\/YPAF31FCC5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/YPAF31FCC5",
        "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/703636962729656320",
        "display_url" : "twitter.com\/muranava\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703643171620790274",
    "text" : "Thanks for these practical examples of COCA use Mura - great stuff! https:\/\/t.co\/YPAF31FCC5",
    "id" : 703643171620790274,
    "created_at" : "2016-02-27 18:09:39 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 703690619097649152,
  "created_at" : "2016-02-27 21:18:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 10, 22 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "indices" : [ 23, 36 ],
      "id_str" : "381086898",
      "id" : 381086898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703690045807566848",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @lexicojules @e_d_driscoll thanks for the likes : ) any feedback welcome!",
  "id" : 703690045807566848,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-27 21:15:55 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 22, 29 ],
      "id_str" : "704177088",
      "id" : 704177088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/YfnJUzxEom",
      "expanded_url" : "https:\/\/creativespeaking.wordpress.com\/league-of-explorers\/",
      "display_url" : "creativespeaking.wordpress.com\/league-of-expl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703689337318338561",
  "text" : "RT @getgreatenglish: .@dBr_wn My students and I enjoyed playing a modified version of League of Explorers today. https:\/\/t.co\/YfnJUzxEom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Brown",
        "screen_name" : "dBr_wn",
        "indices" : [ 1, 8 ],
        "id_str" : "704177088",
        "id" : 704177088
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/YfnJUzxEom",
        "expanded_url" : "https:\/\/creativespeaking.wordpress.com\/league-of-explorers\/",
        "display_url" : "creativespeaking.wordpress.com\/league-of-expl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703480390749523968",
    "text" : ".@dBr_wn My students and I enjoyed playing a modified version of League of Explorers today. https:\/\/t.co\/YfnJUzxEom",
    "id" : 703480390749523968,
    "created_at" : "2016-02-27 07:22:49 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 703689337318338561,
  "created_at" : "2016-02-27 21:13:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 139, 140 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/JVXUPkCKFX",
      "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/618387",
      "display_url" : "smashwords.com\/books\/view\/618\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703688759053832192",
  "text" : "RT @RudyLoock: Vs cherchez des id\u00E9es d'activit\u00E9s linguistiques simples \u00E0 mettre en place en utilisant des #corpus?\n\u27A1\uFE0F https:\/\/t.co\/JVXUPkCK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 131, 140 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/JVXUPkCKFX",
        "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/618387",
        "display_url" : "smashwords.com\/books\/view\/618\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703645387190620160",
    "text" : "Vs cherchez des id\u00E9es d'activit\u00E9s linguistiques simples \u00E0 mettre en place en utilisant des #corpus?\n\u27A1\uFE0F https:\/\/t.co\/JVXUPkCKFX par @muranava",
    "id" : 703645387190620160,
    "created_at" : "2016-02-27 18:18:28 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 703688759053832192,
  "created_at" : "2016-02-27 21:10:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 10, 19 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 20, 33 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 34, 43 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703636962729656320",
  "geo" : { },
  "id_str" : "703688654447845377",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @GemmaELT @tesolmatthew @heyboyle many thanks for RT! be interested in any comments : )",
  "id" : 703688654447845377,
  "in_reply_to_status_id" : 703636962729656320,
  "created_at" : "2016-02-27 21:10:23 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703645387190620160",
  "geo" : { },
  "id_str" : "703688191270846464",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock n'hesitez pas \u00E0 me faire des suggestions : )",
  "id" : 703688191270846464,
  "in_reply_to_status_id" : 703645387190620160,
  "created_at" : "2016-02-27 21:08:33 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703644178979397632",
  "geo" : { },
  "id_str" : "703687929604886528",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock thanks Rudy : )",
  "id" : 703687929604886528,
  "in_reply_to_status_id" : 703644178979397632,
  "created_at" : "2016-02-27 21:07:30 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703643171620790274",
  "geo" : { },
  "id_str" : "703687022121263104",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thanks Eily any comments welcome for a revised version : )",
  "id" : 703687022121263104,
  "in_reply_to_status_id" : 703643171620790274,
  "created_at" : "2016-02-27 21:03:54 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 100, 113 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703591831980802048",
  "geo" : { },
  "id_str" : "703637288685854720",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne hope your training is going well, not caught up yet on your experiences on @tesolmatthew blog",
  "id" : 703637288685854720,
  "in_reply_to_status_id" : 703591831980802048,
  "created_at" : "2016-02-27 17:46:17 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703630010335305732",
  "geo" : { },
  "id_str" : "703637084041560064",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thx have used this though server seems a bit slow?",
  "id" : 703637084041560064,
  "in_reply_to_status_id" : 703630010335305732,
  "created_at" : "2016-02-27 17:45:28 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "EFL",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "esl",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "tesol",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "auselt",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/LxCThE4Wv7",
      "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/618387",
      "display_url" : "smashwords.com\/books\/view\/618\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703636962729656320",
  "text" : "Quick cups of COCA ebook https:\/\/t.co\/LxCThE4Wv7 #eltchat #EFL #esl #tesol #eltchinwag #auselt read it before the interface changes : )",
  "id" : 703636962729656320,
  "created_at" : "2016-02-27 17:44:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 10, 18 ],
      "id_str" : "279078759",
      "id" : 279078759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703525396730519552",
  "geo" : { },
  "id_str" : "703533733920575488",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski @LahiffP ill have some o de demon perspective : )",
  "id" : 703533733920575488,
  "in_reply_to_status_id" : 703525396730519552,
  "created_at" : "2016-02-27 10:54:47 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Canary",
      "screen_name" : "TheCanarySays",
      "indices" : [ 113, 127 ],
      "id_str" : "3314289248",
      "id" : 3314289248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/zRDQAR0diz",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/02\/25\/establishment-media-just-went-full-panic-mode-corbyns-victory-pmqs\/",
      "display_url" : "thecanary.co\/2016\/02\/25\/est\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703509545583247360",
  "text" : "The establishment media just went into full panic mode over Corbyn\u2019s victory at PMQs https:\/\/t.co\/zRDQAR0diz via @thecanarysays",
  "id" : 703509545583247360,
  "created_at" : "2016-02-27 09:18:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/md1oOMWUvC",
      "expanded_url" : "https:\/\/elliotmurphyblog.wordpress.com\/2016\/01\/16\/review-why-only-us-by-berwick-and-chomsky",
      "display_url" : "elliotmurphyblog.wordpress.com\/2016\/01\/16\/rev\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "703449493883248641",
  "geo" : { },
  "id_str" : "703505538575962112",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl did you read this one? https:\/\/t.co\/md1oOMWUvC",
  "id" : 703505538575962112,
  "in_reply_to_status_id" : 703449493883248641,
  "created_at" : "2016-02-27 09:02:45 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 0, 7 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/703335744992051202\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/IfFFCXKIm1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcLAId-WAAEL5GK.jpg",
      "id_str" : "703335743540822017",
      "id" : 703335743540822017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcLAId-WAAEL5GK.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IfFFCXKIm1"
    } ],
    "hashtags" : [ {
      "text" : "LXDforELT",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703270457022279680",
  "geo" : { },
  "id_str" : "703335744992051202",
  "in_reply_to_user_id" : 18602422,
  "text" : "@eltjam #LXDforELT kids these days... https:\/\/t.co\/IfFFCXKIm1",
  "id" : 703335744992051202,
  "in_reply_to_status_id" : 703270457022279680,
  "created_at" : "2016-02-26 21:48:03 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 29, 36 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/703270457022279680\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/WxLZl8xd5p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcKEwPPWwAEmG4G.jpg",
      "id_str" : "703270456082743297",
      "id" : 703270456082743297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcKEwPPWwAEmG4G.jpg",
      "sizes" : [ {
        "h" : 1331,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 1331,
        "resize" : "fit",
        "w" : 1011
      } ],
      "display_url" : "pic.twitter.com\/WxLZl8xd5p"
    } ],
    "hashtags" : [ {
      "text" : "LXDforELT",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703270457022279680",
  "text" : "edtech denialism? #LXDforELT @eltjam https:\/\/t.co\/WxLZl8xd5p",
  "id" : 703270457022279680,
  "created_at" : "2016-02-26 17:28:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 0, 11 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    }, {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 12, 27 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 28, 36 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "Innovate ELT",
      "screen_name" : "InnovateELT",
      "indices" : [ 37, 49 ],
      "id_str" : "2890575449",
      "id" : 2890575449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703233920737878016",
  "geo" : { },
  "id_str" : "703241306496212993",
  "in_reply_to_user_id" : 3217729433,
  "text" : "@TeflEquity @myles_klynhout @taw_sig @InnovateELT did u ever release the data you collected on students view?",
  "id" : 703241306496212993,
  "in_reply_to_status_id" : 703233920737878016,
  "created_at" : "2016-02-26 15:32:47 +0000",
  "in_reply_to_screen_name" : "TeflEquity",
  "in_reply_to_user_id_str" : "3217729433",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/F1PHQn0MgH",
      "expanded_url" : "http:\/\/elttalkbingo.englishup.me\/newcard.html",
      "display_url" : "elttalkbingo.englishup.me\/newcard.html"
    } ]
  },
  "in_reply_to_status_id_str" : "703232832014041088",
  "geo" : { },
  "id_str" : "703236700840005634",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha have you played ELTTalk Bingo? https:\/\/t.co\/F1PHQn0MgH : )",
  "id" : 703236700840005634,
  "in_reply_to_status_id" : 703232832014041088,
  "created_at" : "2016-02-26 15:14:29 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INSIDER",
      "screen_name" : "thisisinsider",
      "indices" : [ 3, 17 ],
      "id_str" : "3226282347",
      "id" : 3226282347
    }, {
      "name" : "Simone Giertz",
      "screen_name" : "SimoneGiertz",
      "indices" : [ 20, 33 ],
      "id_str" : "897861037",
      "id" : 897861037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/tpihVHAVQy",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/22be0110-7b62-489b-9e3b-b03ba207ad35",
      "display_url" : "amp.twimg.com\/v\/22be0110-7b6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703155547848122369",
  "text" : "RT @thisisinsider: .@simonegiertz is really good at making really bad robots\nhttps:\/\/t.co\/tpihVHAVQy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simone Giertz",
        "screen_name" : "SimoneGiertz",
        "indices" : [ 1, 14 ],
        "id_str" : "897861037",
        "id" : 897861037
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/tpihVHAVQy",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/22be0110-7b62-489b-9e3b-b03ba207ad35",
        "display_url" : "amp.twimg.com\/v\/22be0110-7b6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702892833162670081",
    "text" : ".@simonegiertz is really good at making really bad robots\nhttps:\/\/t.co\/tpihVHAVQy",
    "id" : 702892833162670081,
    "created_at" : "2016-02-25 16:28:05 +0000",
    "user" : {
      "name" : "INSIDER",
      "screen_name" : "thisisinsider",
      "protected" : false,
      "id_str" : "3226282347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755852886400077825\/G1p62uZ8_normal.jpg",
      "id" : 3226282347,
      "verified" : false
    }
  },
  "id" : 703155547848122369,
  "created_at" : "2016-02-26 09:52:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/a0HeXeoddP",
      "expanded_url" : "https:\/\/youtu.be\/expvIY6KQOA",
      "display_url" : "youtu.be\/expvIY6KQOA"
    } ]
  },
  "geo" : { },
  "id_str" : "702969428347068418",
  "text" : "SunVox + Oscilloscope: Silence Artifacts (by NightRadio) https:\/\/t.co\/a0HeXeoddP via @YouTube",
  "id" : 702969428347068418,
  "created_at" : "2016-02-25 21:32:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 9, 21 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 22, 29 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702962456004599808",
  "geo" : { },
  "id_str" : "702962847060508672",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge @nmkrobinson @eltjam gotta admit it was slick : )",
  "id" : 702962847060508672,
  "in_reply_to_status_id" : 702962456004599808,
  "created_at" : "2016-02-25 21:06:17 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 54, 70 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/Y7QNlAILYm",
      "expanded_url" : "http:\/\/hapgood.us\/2016\/02\/25\/the-tragedy-of-the-stream\/",
      "display_url" : "hapgood.us\/2016\/02\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702961957989695488",
  "text" : "The Tragedy of the\u00A0Stream https:\/\/t.co\/Y7QNlAILYm via @wordpressdotcom",
  "id" : 702961957989695488,
  "created_at" : "2016-02-25 21:02:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LXDforELT",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702957574484787201",
  "text" : "blooper on the behaviourism section #LXDforELT",
  "id" : 702957574484787201,
  "created_at" : "2016-02-25 20:45:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702910187410096128",
  "geo" : { },
  "id_str" : "702919970292948992",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters a solution in search of a problem?",
  "id" : 702919970292948992,
  "in_reply_to_status_id" : 702910187410096128,
  "created_at" : "2016-02-25 18:15:55 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Naismith",
      "screen_name" : "BenNaismithELT",
      "indices" : [ 0, 15 ],
      "id_str" : "305248493",
      "id" : 305248493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702916541667409920",
  "geo" : { },
  "id_str" : "702917782963355648",
  "in_reply_to_user_id" : 305248493,
  "text" : "@BenNaismithELT would need to filter the wiki-corpus more",
  "id" : 702917782963355648,
  "in_reply_to_status_id" : 702916541667409920,
  "created_at" : "2016-02-25 18:07:13 +0000",
  "in_reply_to_screen_name" : "BenNaismithELT",
  "in_reply_to_user_id_str" : "305248493",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Naismith",
      "screen_name" : "BenNaismithELT",
      "indices" : [ 0, 15 ],
      "id_str" : "305248493",
      "id" : 305248493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702904456191434752",
  "geo" : { },
  "id_str" : "702915120888995840",
  "in_reply_to_user_id" : 305248493,
  "text" : "@BenNaismithELT yeah cld do do u have particular thing in mind?",
  "id" : 702915120888995840,
  "in_reply_to_status_id" : 702904456191434752,
  "created_at" : "2016-02-25 17:56:39 +0000",
  "in_reply_to_screen_name" : "BenNaismithELT",
  "in_reply_to_user_id_str" : "305248493",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 0, 13 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/6pGwdTjsdc",
      "expanded_url" : "https:\/\/www.academia.edu\/16716002\/MonoconcEsy",
      "display_url" : "academia.edu\/16716002\/Monoc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702491139723694081",
  "geo" : { },
  "id_str" : "702914341499244544",
  "in_reply_to_user_id" : 702925903,
  "text" : "@WatchedPotts MonoconcEsy worth a mention for beginner &amp; windows users https:\/\/t.co\/6pGwdTjsdc",
  "id" : 702914341499244544,
  "in_reply_to_status_id" : 702491139723694081,
  "created_at" : "2016-02-25 17:53:33 +0000",
  "in_reply_to_screen_name" : "WatchedPotts",
  "in_reply_to_user_id_str" : "702925903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will McCulloch",
      "screen_name" : "EnglishHamburg",
      "indices" : [ 0, 15 ],
      "id_str" : "387245091",
      "id" : 387245091
    }, {
      "name" : "Shanthi Streat",
      "screen_name" : "ShanthiStreat",
      "indices" : [ 16, 30 ],
      "id_str" : "2159433601",
      "id" : 2159433601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/7td3tgxhcI",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/WEkZ58hxZ9G",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702871748476342273",
  "geo" : { },
  "id_str" : "702873600416747521",
  "in_reply_to_user_id" : 387245091,
  "text" : "@EnglishHamburg @ShanthiStreat be interesting to see check frequencies of idioms e.g. https:\/\/t.co\/7td3tgxhcI",
  "id" : 702873600416747521,
  "in_reply_to_status_id" : 702871748476342273,
  "created_at" : "2016-02-25 15:11:39 +0000",
  "in_reply_to_screen_name" : "EnglishHamburg",
  "in_reply_to_user_id_str" : "387245091",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 9, 15 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 16, 27 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 71, 79 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/GsA4lB3tmZ",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/09\/categorizing-people\/",
      "display_url" : "grieve-smith.com\/blog\/2013\/09\/c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702831237438775296",
  "geo" : { },
  "id_str" : "702832589070065669",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @ebefl @EAPstephen category fight! https:\/\/t.co\/GsA4lB3tmZ cc @grvsmth",
  "id" : 702832589070065669,
  "in_reply_to_status_id" : 702831237438775296,
  "created_at" : "2016-02-25 12:28:41 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Labosonic",
      "screen_name" : "labosonic",
      "indices" : [ 3, 13 ],
      "id_str" : "64446570",
      "id" : 64446570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OnVautMieuxQueCa",
      "indices" : [ 39, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/AZQAAMaNuB",
      "expanded_url" : "http:\/\/bit.ly\/1p5Esmr",
      "display_url" : "bit.ly\/1p5Esmr"
    } ]
  },
  "geo" : { },
  "id_str" : "702801703658254336",
  "text" : "RT @labosonic: Hey twitter, t'as vu le #OnVautMieuxQueCa ?  https:\/\/t.co\/AZQAAMaNuB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/choqok.gnufolks.org\/\" rel=\"nofollow\"\u003EKubuntu Choqok\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OnVautMieuxQueCa",
        "indices" : [ 24, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/AZQAAMaNuB",
        "expanded_url" : "http:\/\/bit.ly\/1p5Esmr",
        "display_url" : "bit.ly\/1p5Esmr"
      } ]
    },
    "geo" : { },
    "id_str" : "702621958584803330",
    "text" : "Hey twitter, t'as vu le #OnVautMieuxQueCa ?  https:\/\/t.co\/AZQAAMaNuB",
    "id" : 702621958584803330,
    "created_at" : "2016-02-24 22:31:43 +0000",
    "user" : {
      "name" : "Labosonic",
      "screen_name" : "labosonic",
      "protected" : false,
      "id_str" : "64446570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731183837368221696\/CM809NKC_normal.jpg",
      "id" : 64446570,
      "verified" : false
    }
  },
  "id" : 702801703658254336,
  "created_at" : "2016-02-25 10:25:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagamine, T.",
      "screen_name" : "nagamine_73",
      "indices" : [ 0, 12 ],
      "id_str" : "2450110776",
      "id" : 2450110776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/TKFdKT4xTA",
      "expanded_url" : "http:\/\/www.icge.co.uk\/languagesciencesblog\/?p=1084",
      "display_url" : "icge.co.uk\/languagescienc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702776118089089025",
  "geo" : { },
  "id_str" : "702778153484296192",
  "in_reply_to_user_id" : 2450110776,
  "text" : "@nagamine_73 no e.g. https:\/\/t.co\/TKFdKT4xTA",
  "id" : 702778153484296192,
  "in_reply_to_status_id" : 702776118089089025,
  "created_at" : "2016-02-25 08:52:23 +0000",
  "in_reply_to_screen_name" : "nagamine_73",
  "in_reply_to_user_id_str" : "2450110776",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Davies",
      "screen_name" : "davies_will",
      "indices" : [ 0, 12 ],
      "id_str" : "821730835",
      "id" : 821730835
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 13, 23 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702767857675927552",
  "geo" : { },
  "id_str" : "702768160299225088",
  "in_reply_to_user_id" : 821730835,
  "text" : "@davies_will @ElkySmith lol you'll have to explain that to my dad then a retired chemist who moans about \"opportunists\" when he was working",
  "id" : 702768160299225088,
  "in_reply_to_status_id" : 702767857675927552,
  "created_at" : "2016-02-25 08:12:40 +0000",
  "in_reply_to_screen_name" : "davies_will",
  "in_reply_to_user_id_str" : "821730835",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Davies",
      "screen_name" : "davies_will",
      "indices" : [ 0, 12 ],
      "id_str" : "821730835",
      "id" : 821730835
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 13, 23 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702766338629046273",
  "geo" : { },
  "id_str" : "702767762763083776",
  "in_reply_to_user_id" : 821730835,
  "text" : "@davies_will @ElkySmith it's always been this way no?",
  "id" : 702767762763083776,
  "in_reply_to_status_id" : 702766338629046273,
  "created_at" : "2016-02-25 08:11:06 +0000",
  "in_reply_to_screen_name" : "davies_will",
  "in_reply_to_user_id_str" : "821730835",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/NJSZLRkeQJ",
      "expanded_url" : "https:\/\/theconversation.com\/computer-thinks-youre-dumb-automated-essay-grading-in-the-world-of-moocs-13321",
      "display_url" : "theconversation.com\/computer-think\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702765581443932160",
  "text" : "RT @langstat: Computer thinks you're dumb: automated essay grading in the world of MOOCs https:\/\/t.co\/NJSZLRkeQJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/NJSZLRkeQJ",
        "expanded_url" : "https:\/\/theconversation.com\/computer-thinks-youre-dumb-automated-essay-grading-in-the-world-of-moocs-13321",
        "display_url" : "theconversation.com\/computer-think\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702650616997244928",
    "text" : "Computer thinks you're dumb: automated essay grading in the world of MOOCs https:\/\/t.co\/NJSZLRkeQJ",
    "id" : 702650616997244928,
    "created_at" : "2016-02-25 00:25:36 +0000",
    "user" : {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "protected" : false,
      "id_str" : "108896452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111159202\/profile_normal.gif",
      "id" : 108896452,
      "verified" : false
    }
  },
  "id" : 702765581443932160,
  "created_at" : "2016-02-25 08:02:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Naismith",
      "screen_name" : "BenNaismithELT",
      "indices" : [ 0, 15 ],
      "id_str" : "305248493",
      "id" : 305248493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702764199248789504",
  "in_reply_to_user_id" : 305248493,
  "text" : "@BenNaismithELT thanks for sharing BYU-WIKI post : )",
  "id" : 702764199248789504,
  "created_at" : "2016-02-25 07:56:56 +0000",
  "in_reply_to_screen_name" : "BenNaismithELT",
  "in_reply_to_user_id_str" : "305248493",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 7, 16 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/KRtL0VjL7k",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/9oqQ7draSuW",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702745054926999552",
  "geo" : { },
  "id_str" : "702764095796334592",
  "in_reply_to_user_id" : 121063600,
  "text" : "thanks @whyshona  for h\/t, people can still get original paper from following links here https:\/\/t.co\/KRtL0VjL7k",
  "id" : 702764095796334592,
  "in_reply_to_status_id" : 702745054926999552,
  "created_at" : "2016-02-25 07:56:31 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAEL SLLAT",
      "screen_name" : "LAELSLLAT",
      "indices" : [ 0, 10 ],
      "id_str" : "2779067742",
      "id" : 2779067742
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 11, 20 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702494427932184576",
  "geo" : { },
  "id_str" : "702638596533198848",
  "in_reply_to_user_id" : 2779067742,
  "text" : "@LAELSLLAT @antlabjp hi any slides available? thx",
  "id" : 702638596533198848,
  "in_reply_to_status_id" : 702494427932184576,
  "created_at" : "2016-02-24 23:37:50 +0000",
  "in_reply_to_screen_name" : "LAELSLLAT",
  "in_reply_to_user_id_str" : "2779067742",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "indices" : [ 0, 15 ],
      "id_str" : "2340183050",
      "id" : 2340183050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702603836754681860",
  "geo" : { },
  "id_str" : "702604223951867905",
  "in_reply_to_user_id" : 2340183050,
  "text" : "@CorporaJournal many happy RTs of the day : )",
  "id" : 702604223951867905,
  "in_reply_to_status_id" : 702603836754681860,
  "created_at" : "2016-02-24 21:21:15 +0000",
  "in_reply_to_screen_name" : "CorporaJournal",
  "in_reply_to_user_id_str" : "2340183050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pkxT04NeQF",
      "expanded_url" : "http:\/\/cup.linguistlist.org\/journals\/a-comparison-of-the-effectiveness-of-efl-students-use-of-dictionaries-and-an-online-corpus-for-the-enhancement-of-revision-skills\/",
      "display_url" : "cup.linguistlist.org\/journals\/a-com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702599101721014272",
  "text" : "A comparison of the effectiveness of EFL students\u2019 use of dictionaries &amp; an online corpus for...revision\u00A0skills https:\/\/t.co\/pkxT04NeQF",
  "id" : 702599101721014272,
  "created_at" : "2016-02-24 21:00:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702552651968483329",
  "geo" : { },
  "id_str" : "702598058559840258",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheers Leo gotta work that phrase into my blog somehow : )",
  "id" : 702598058559840258,
  "in_reply_to_status_id" : 702552651968483329,
  "created_at" : "2016-02-24 20:56:45 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702558770887593984",
  "geo" : { },
  "id_str" : "702597924195332097",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher they do some sort of course for subs? i initially tried to use it for PHaVE way back did not have all verbs maybe cld now",
  "id" : 702597924195332097,
  "in_reply_to_status_id" : 702558770887593984,
  "created_at" : "2016-02-24 20:56:13 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702533155882995713",
  "geo" : { },
  "id_str" : "702535794049880064",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague there's the web app",
  "id" : 702535794049880064,
  "in_reply_to_status_id" : 702533155882995713,
  "created_at" : "2016-02-24 16:49:20 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 16, 31 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/RXS4ybrO75",
      "expanded_url" : "https:\/\/goo.gl\/EV1JR5",
      "display_url" : "goo.gl\/EV1JR5"
    } ]
  },
  "in_reply_to_status_id_str" : "702530890522632192",
  "geo" : { },
  "id_str" : "702532368184303620",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague @AnthonyTeacher there was this as well https:\/\/t.co\/RXS4ybrO75",
  "id" : 702532368184303620,
  "in_reply_to_status_id" : 702530890522632192,
  "created_at" : "2016-02-24 16:35:43 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/702520649772883969\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/HgVWgmnmlK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_aztjWoAAi-B9.png",
      "id_str" : "702520648829149184",
      "id" : 702520648829149184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_aztjWoAAi-B9.png",
      "sizes" : [ {
        "h" : 265,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 701
      } ],
      "display_url" : "pic.twitter.com\/HgVWgmnmlK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/irR986o5V4",
      "expanded_url" : "http:\/\/nbviewer.jupyter.org\/gist\/yoavg\/d76121dfde2618422139",
      "display_url" : "nbviewer.jupyter.org\/gist\/yoavg\/d76\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702520649772883969",
  "text" : "Get your own Mitra (or any person) Speech Maker &amp; save yourself time - https:\/\/t.co\/irR986o5V4 https:\/\/t.co\/HgVWgmnmlK",
  "id" : 702520649772883969,
  "created_at" : "2016-02-24 15:49:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702477818966482944",
  "geo" : { },
  "id_str" : "702516825133879298",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher yr welcome nice activity for playphrase; still not had chance to use site yet",
  "id" : 702516825133879298,
  "in_reply_to_status_id" : 702477818966482944,
  "created_at" : "2016-02-24 15:33:57 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 22, 31 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 43, 59 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/Ex2uOhHZy7",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2016-02-24\/why-blair-is-baffled-by-sanders-and-corbyn\/",
      "display_url" : "jonathan-cook.net\/blog\/2016-02-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702443193154084868",
  "text" : "RT @medialens: Former @guardian journalist @Jonathan_K_Cook on the paper's 'deep affinity' with war criminal Tony Blair. https:\/\/t.co\/Ex2uO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 7, 16 ],
        "id_str" : "87818409",
        "id" : 87818409
      }, {
        "name" : "Jonathan Cook",
        "screen_name" : "Jonathan_K_Cook",
        "indices" : [ 28, 44 ],
        "id_str" : "2459644405",
        "id" : 2459644405
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/Ex2uOhHZy7",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2016-02-24\/why-blair-is-baffled-by-sanders-and-corbyn\/",
        "display_url" : "jonathan-cook.net\/blog\/2016-02-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702425128039292928",
    "text" : "Former @guardian journalist @Jonathan_K_Cook on the paper's 'deep affinity' with war criminal Tony Blair. https:\/\/t.co\/Ex2uOhHZy7",
    "id" : 702425128039292928,
    "created_at" : "2016-02-24 09:29:35 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 702443193154084868,
  "created_at" : "2016-02-24 10:41:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702379710534328320",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura hi Noor thx for RT PHaVE dictionary for android : ) hope u r doing good",
  "id" : 702379710534328320,
  "created_at" : "2016-02-24 06:29:07 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TSchnoebelen\/status\/702269263051100161\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7gz7S18M9Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb72LHrW8AAgodh.jpg",
      "id_str" : "702269262816276480",
      "id" : 702269262816276480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb72LHrW8AAgodh.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 2134
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/7gz7S18M9Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702269665981104131",
  "text" : "RT @TSchnoebelen: Mantra in collocates, a poem:\nBecome became\nRepeating repeated\nRepeat chanting\nRepeats Republicans https:\/\/t.co\/7gz7S18M9Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TSchnoebelen\/status\/702269263051100161\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/7gz7S18M9Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb72LHrW8AAgodh.jpg",
        "id_str" : "702269262816276480",
        "id" : 702269262816276480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb72LHrW8AAgodh.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 2134
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 124,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/7gz7S18M9Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702269263051100161",
    "text" : "Mantra in collocates, a poem:\nBecome became\nRepeating repeated\nRepeat chanting\nRepeats Republicans https:\/\/t.co\/7gz7S18M9Y",
    "id" : 702269263051100161,
    "created_at" : "2016-02-23 23:10:14 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 702269665981104131,
  "created_at" : "2016-02-23 23:11:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702264876283072513",
  "text" : "RT @aral: Modern life\u2026 wondering who\u2019s going to fuck things up worse: the dick in the suit or the douchebag in the t-shirt.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702051690133004288",
    "text" : "Modern life\u2026 wondering who\u2019s going to fuck things up worse: the dick in the suit or the douchebag in the t-shirt.",
    "id" : 702051690133004288,
    "created_at" : "2016-02-23 08:45:41 +0000",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 702264876283072513,
  "created_at" : "2016-02-23 22:52:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/lFaSIaJ38D",
      "expanded_url" : "https:\/\/twitter.com\/CBSNews\/status\/702126941399343104",
      "display_url" : "twitter.com\/CBSNews\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702264563069296641",
  "text" : "RT @Snowden: BREAKING: Rich man favors central authority. https:\/\/t.co\/lFaSIaJ38D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/lFaSIaJ38D",
        "expanded_url" : "https:\/\/twitter.com\/CBSNews\/status\/702126941399343104",
        "display_url" : "twitter.com\/CBSNews\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702156141644668928",
    "text" : "BREAKING: Rich man favors central authority. https:\/\/t.co\/lFaSIaJ38D",
    "id" : 702156141644668928,
    "created_at" : "2016-02-23 15:40:44 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 702264563069296641,
  "created_at" : "2016-02-23 22:51:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/LO7aM4Z0j4",
      "expanded_url" : "https:\/\/chroniclevitae.com\/news\/1301-academic-waste",
      "display_url" : "chroniclevitae.com\/news\/1301-acad\u2026"
    }, {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/GZ2R8CqDHE",
      "expanded_url" : "https:\/\/athens.indymedia.org\/media\/old\/how_the_university_works.pdf",
      "display_url" : "athens.indymedia.org\/media\/old\/how_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702247303055286272",
  "text" : "RT @taw_sig: Academic Waste https:\/\/t.co\/LO7aM4Z0j4\nHow the university works [pdf] https:\/\/t.co\/GZ2R8CqDHE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/LO7aM4Z0j4",
        "expanded_url" : "https:\/\/chroniclevitae.com\/news\/1301-academic-waste",
        "display_url" : "chroniclevitae.com\/news\/1301-acad\u2026"
      }, {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/GZ2R8CqDHE",
        "expanded_url" : "https:\/\/athens.indymedia.org\/media\/old\/how_the_university_works.pdf",
        "display_url" : "athens.indymedia.org\/media\/old\/how_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702246748635398144",
    "text" : "Academic Waste https:\/\/t.co\/LO7aM4Z0j4\nHow the university works [pdf] https:\/\/t.co\/GZ2R8CqDHE",
    "id" : 702246748635398144,
    "created_at" : "2016-02-23 21:40:46 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 702247303055286272,
  "created_at" : "2016-02-23 21:42:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702236255069872128",
  "geo" : { },
  "id_str" : "702244972578398208",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thx! that would be a great comment on the play store ; )",
  "id" : 702244972578398208,
  "in_reply_to_status_id" : 702236255069872128,
  "created_at" : "2016-02-23 21:33:43 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702225319986651136",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thx for RT of PHaVE dictionary : )",
  "id" : 702225319986651136,
  "created_at" : "2016-02-23 20:15:37 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702179552991248385",
  "geo" : { },
  "id_str" : "702218270305292288",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM hi Monika that's great thanks, if u get any feedback on itbe interested to know : )",
  "id" : 702218270305292288,
  "in_reply_to_status_id" : 702179552991248385,
  "created_at" : "2016-02-23 19:47:36 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 71, 86 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/odsxjgNMGt",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/playphrase-me-and-listening-discrimination",
      "display_url" : "anthonyteacher.com\/blog\/playphras\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702163891594334209",
  "text" : "PlayPhrase.me and Listening Discrimination https:\/\/t.co\/odsxjgNMGt via @AnthonyTeacher",
  "id" : 702163891594334209,
  "created_at" : "2016-02-23 16:11:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/702135112398413828\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/XYszXl5Dvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb58KfZW4AADO-b.png",
      "id_str" : "702135111584768000",
      "id" : 702135111584768000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb58KfZW4AADO-b.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/XYszXl5Dvs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/1x6xhYZfvV",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=me.englishup.phave_dictionary&hl=en",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702135112398413828",
  "text" : "nice to see PHaVE dictionary android past 50 installs : ) https:\/\/t.co\/1x6xhYZfvV https:\/\/t.co\/XYszXl5Dvs",
  "id" : 702135112398413828,
  "created_at" : "2016-02-23 14:17:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702127361043668992",
  "geo" : { },
  "id_str" : "702129390537285632",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp hi will slides be available after?",
  "id" : 702129390537285632,
  "in_reply_to_status_id" : 702127361043668992,
  "created_at" : "2016-02-23 13:54:26 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 3, 15 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "flteach",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "efl",
      "indices" : [ 112, 116 ]
    }, {
      "text" : "tesl",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "esl",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "edtech",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/53dGngJ1SX",
      "expanded_url" : "http:\/\/www.paulsensei.com\/index.php\/2016\/02\/23\/the-rocky-road-to-lms-web-app-integration\/",
      "display_url" : "paulsensei.com\/index.php\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702111351901126656",
  "text" : "RT @paul_sensei: The rocky road to LMS web app integration: https:\/\/t.co\/53dGngJ1SX #langchat #flteach #eltchat #efl #tesl #esl #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "flteach",
        "indices" : [ 77, 85 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 86, 94 ]
      }, {
        "text" : "efl",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "tesl",
        "indices" : [ 100, 105 ]
      }, {
        "text" : "esl",
        "indices" : [ 106, 110 ]
      }, {
        "text" : "edtech",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/53dGngJ1SX",
        "expanded_url" : "http:\/\/www.paulsensei.com\/index.php\/2016\/02\/23\/the-rocky-road-to-lms-web-app-integration\/",
        "display_url" : "paulsensei.com\/index.php\/2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702093382521237505",
    "text" : "The rocky road to LMS web app integration: https:\/\/t.co\/53dGngJ1SX #langchat #flteach #eltchat #efl #tesl #esl #edtech",
    "id" : 702093382521237505,
    "created_at" : "2016-02-23 11:31:21 +0000",
    "user" : {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "protected" : false,
      "id_str" : "176429301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666950419248259073\/T7XVTUac_normal.jpg",
      "id" : 176429301,
      "verified" : false
    }
  },
  "id" : 702111351901126656,
  "created_at" : "2016-02-23 12:42:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Lyon-Jones",
      "screen_name" : "esolcourses",
      "indices" : [ 0, 12 ],
      "id_str" : "34321100",
      "id" : 34321100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702041324229410816",
  "geo" : { },
  "id_str" : "702111237497348097",
  "in_reply_to_user_id" : 34321100,
  "text" : "@esolcourses thanks lovely to hear :)",
  "id" : 702111237497348097,
  "in_reply_to_status_id" : 702041324229410816,
  "created_at" : "2016-02-23 12:42:18 +0000",
  "in_reply_to_screen_name" : "esolcourses",
  "in_reply_to_user_id_str" : "34321100",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/9OYNszkVPp",
      "expanded_url" : "http:\/\/blog.edtechie.net\/higher-ed\/the-non-uberization-of-education\/",
      "display_url" : "blog.edtechie.net\/higher-ed\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702025734798311424",
  "text" : "The non-Uberization of education https:\/\/t.co\/9OYNszkVPp",
  "id" : 702025734798311424,
  "created_at" : "2016-02-23 07:02:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702016809814384640",
  "geo" : { },
  "id_str" : "702019857953509376",
  "in_reply_to_user_id" : 18602422,
  "text" : "@usage_based shame no new entries since 2014",
  "id" : 702019857953509376,
  "in_reply_to_status_id" : 702016809814384640,
  "created_at" : "2016-02-23 06:39:11 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702018869695676417",
  "geo" : { },
  "id_str" : "702019257526255617",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish :( i'mma put apple version on hold too much hassle for now",
  "id" : 702019257526255617,
  "in_reply_to_status_id" : 702018869695676417,
  "created_at" : "2016-02-23 06:36:48 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Crumpler",
      "screen_name" : "adaptivelearnin",
      "indices" : [ 0, 16 ],
      "id_str" : "296256838",
      "id" : 296256838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702014468855898112",
  "geo" : { },
  "id_str" : "702019066832285696",
  "in_reply_to_user_id" : 296256838,
  "text" : "@adaptivelearnin thanks for sharing post : )",
  "id" : 702019066832285696,
  "in_reply_to_status_id" : 702014468855898112,
  "created_at" : "2016-02-23 06:36:03 +0000",
  "in_reply_to_screen_name" : "adaptivelearnin",
  "in_reply_to_user_id_str" : "296256838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701947225706921984",
  "geo" : { },
  "id_str" : "702017900912185344",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish cheers Marc : )",
  "id" : 702017900912185344,
  "in_reply_to_status_id" : 701947225706921984,
  "created_at" : "2016-02-23 06:31:25 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702009878093508609",
  "geo" : { },
  "id_str" : "702016809814384640",
  "in_reply_to_user_id" : 1479290418,
  "text" : "@usage_based NICE website thanks",
  "id" : 702016809814384640,
  "in_reply_to_status_id" : 702009878093508609,
  "created_at" : "2016-02-23 06:27:04 +0000",
  "in_reply_to_screen_name" : "usage_based",
  "in_reply_to_user_id_str" : "1479290418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IsraeliApartheidWeek",
      "indices" : [ 39, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/WkKxhVmsBO",
      "expanded_url" : "https:\/\/twitter.com\/AsaWinstanley\/status\/701820005760049152",
      "display_url" : "twitter.com\/AsaWinstanley\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701911939396583424",
  "text" : "RT @johnwhilley: Great articulation of #IsraeliApartheidWeek ad action. https:\/\/t.co\/WkKxhVmsBO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IsraeliApartheidWeek",
        "indices" : [ 22, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/WkKxhVmsBO",
        "expanded_url" : "https:\/\/twitter.com\/AsaWinstanley\/status\/701820005760049152",
        "display_url" : "twitter.com\/AsaWinstanley\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701909565890232321",
    "text" : "Great articulation of #IsraeliApartheidWeek ad action. https:\/\/t.co\/WkKxhVmsBO",
    "id" : 701909565890232321,
    "created_at" : "2016-02-22 23:20:56 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 701911939396583424,
  "created_at" : "2016-02-22 23:30:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701895144619044864",
  "geo" : { },
  "id_str" : "701900304636321795",
  "in_reply_to_user_id" : 18602422,
  "text" : "@antlabjp oh the helpfile says yes so i guess it is still uploading?",
  "id" : 701900304636321795,
  "in_reply_to_status_id" : 701895144619044864,
  "created_at" : "2016-02-22 22:44:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Lyon-Jones",
      "screen_name" : "esolcourses",
      "indices" : [ 0, 12 ],
      "id_str" : "34321100",
      "id" : 34321100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701896795769741312",
  "in_reply_to_user_id" : 34321100,
  "text" : "@esolcourses thx for RT of BYU-Wikipedia post Sue : )",
  "id" : 701896795769741312,
  "created_at" : "2016-02-22 22:30:11 +0000",
  "in_reply_to_screen_name" : "esolcourses",
  "in_reply_to_user_id_str" : "34321100",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/S86cmPKhcp",
      "expanded_url" : "https:\/\/momentssnippetsspirals.files.wordpress.com\/2016\/02\/dt-willingham-2.jpg?w=1101&h=524",
      "display_url" : "\u2026tssnippetsspirals.files.wordpress.com\/2016\/02\/dt-wil\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701892272091049984",
  "geo" : { },
  "id_str" : "701896609131589634",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith there's a nice image to help with bullshit https:\/\/t.co\/S86cmPKhcp",
  "id" : 701896609131589634,
  "in_reply_to_status_id" : 701892272091049984,
  "created_at" : "2016-02-22 22:29:26 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701890198049832960",
  "geo" : { },
  "id_str" : "701895144619044864",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp great thx will there be OSX version?",
  "id" : 701895144619044864,
  "in_reply_to_status_id" : 701890198049832960,
  "created_at" : "2016-02-22 22:23:37 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701883152415981570",
  "geo" : { },
  "id_str" : "701895008371286016",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thanks for kind words Gemma if u use graphics let me know : )",
  "id" : 701895008371286016,
  "in_reply_to_status_id" : 701883152415981570,
  "created_at" : "2016-02-22 22:23:05 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/UJzeluTx5M",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2012\/04\/01\/no-phishing-here\/",
      "display_url" : "eflnotes.wordpress.com\/2012\/04\/01\/no-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701861662739996672",
  "geo" : { },
  "id_str" : "701862285346742279",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew this might be of use https:\/\/t.co\/UJzeluTx5M",
  "id" : 701862285346742279,
  "in_reply_to_status_id" : 701861662739996672,
  "created_at" : "2016-02-22 20:13:03 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/U3aphtPLKH",
      "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/feb\/22\/queen-makes-dogs-dinner-of-corgi-hierarchy",
      "display_url" : "theguardian.com\/uk-news\/2016\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701848627191406592",
  "text" : "RT @pchallinor: Oh god this is just too too too fucking fascinating to even READ https:\/\/t.co\/U3aphtPLKH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/U3aphtPLKH",
        "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/feb\/22\/queen-makes-dogs-dinner-of-corgi-hierarchy",
        "display_url" : "theguardian.com\/uk-news\/2016\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701847817371983872",
    "text" : "Oh god this is just too too too fucking fascinating to even READ https:\/\/t.co\/U3aphtPLKH",
    "id" : 701847817371983872,
    "created_at" : "2016-02-22 19:15:34 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 701848627191406592,
  "created_at" : "2016-02-22 19:18:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 1, 15 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Roxane Harrison",
      "screen_name" : "roxaneharrison",
      "indices" : [ 16, 31 ],
      "id_str" : "267494842",
      "id" : 267494842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ORNOvxu6Oo",
      "expanded_url" : "http:\/\/files.flarn.org.uk\/formulaicity.mp4",
      "display_url" : "files.flarn.org.uk\/formulaicity.m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701845380208656384",
  "geo" : { },
  "id_str" : "701847407332605953",
  "in_reply_to_user_id" : 43409552,
  "text" : ".@TESOLacademic @roxaneharrison psycholinguistic reality of corpus frequencies for L2 learners? F Myles audio https:\/\/t.co\/ORNOvxu6Oo",
  "id" : 701847407332605953,
  "in_reply_to_status_id" : 701845380208656384,
  "created_at" : "2016-02-22 19:13:56 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 38, 47 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 48, 58 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 59, 71 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701830188640956416",
  "geo" : { },
  "id_str" : "701839661178740736",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet thanks for auto RT ; ) @GemmaELT @RudyLoock @ELTResearch thx for manual RT : )",
  "id" : 701839661178740736,
  "in_reply_to_status_id" : 701830188640956416,
  "created_at" : "2016-02-22 18:43:09 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701837481298231298",
  "geo" : { },
  "id_str" : "701839310455230465",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch good question guess need to ask ielts bods? do you think such tasks are reflective of actual lang use?",
  "id" : 701839310455230465,
  "in_reply_to_status_id" : 701837481298231298,
  "created_at" : "2016-02-22 18:41:45 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701831782623268864",
  "geo" : { },
  "id_str" : "701833661361078273",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp am F5ing your site : )",
  "id" : 701833661361078273,
  "in_reply_to_status_id" : 701831782623268864,
  "created_at" : "2016-02-22 18:19:18 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "esl",
      "indices" : [ 66, 70 ]
    }, {
      "text" : "tesol",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "tefl",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "esol",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Z4cCRZOefx",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/02\/22\/using-byu-wikipedia-corpus-to-answer-genre-related-questions",
      "display_url" : "eflnotes.wordpress.com\/2016\/02\/22\/usi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701828680184541184",
  "text" : "Using BYU-Wikipedia corpus to answer genre related questions #elt #esl #tesol #tefl #esol #eltchat https:\/\/t.co\/Z4cCRZOefx",
  "id" : 701828680184541184,
  "created_at" : "2016-02-22 17:59:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 15, 27 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701827902380363777",
  "text" : "RT @ElkySmith: @DonaldClark Would it be appropriate to mention that you're a 'non-executive director' of the tech company involved in this \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald Clark",
        "screen_name" : "DonaldClark",
        "indices" : [ 0, 12 ],
        "id_str" : "1632891",
        "id" : 1632891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "700664043418169345",
    "geo" : { },
    "id_str" : "700931543196241920",
    "in_reply_to_user_id" : 1632891,
    "text" : "@DonaldClark Would it be appropriate to mention that you're a 'non-executive director' of the tech company involved in this trial?",
    "id" : 700931543196241920,
    "in_reply_to_status_id" : 700664043418169345,
    "created_at" : "2016-02-20 06:34:37 +0000",
    "in_reply_to_screen_name" : "DonaldClark",
    "in_reply_to_user_id_str" : "1632891",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 701827902380363777,
  "created_at" : "2016-02-22 17:56:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 34, 46 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701826465277595648",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith did you get blocked by @DonaldClark ?",
  "id" : 701826465277595648,
  "created_at" : "2016-02-22 17:50:43 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701746687354789888",
  "text" : "BYU-COCA status should be changed from free-ware to nag-ware? ; )",
  "id" : 701746687354789888,
  "created_at" : "2016-02-22 12:33:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 15, 27 ],
      "id_str" : "1632891",
      "id" : 1632891
    }, {
      "name" : "Neil Canham",
      "screen_name" : "NeilCanham",
      "indices" : [ 28, 39 ],
      "id_str" : "15179383",
      "id" : 15179383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701742813961183235",
  "text" : "RT @ElkySmith: @DonaldClark @NeilCanham What about when you do have the company name up as with the post about CogBooks, Arizona University\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald Clark",
        "screen_name" : "DonaldClark",
        "indices" : [ 0, 12 ],
        "id_str" : "1632891",
        "id" : 1632891
      }, {
        "name" : "Neil Canham",
        "screen_name" : "NeilCanham",
        "indices" : [ 13, 24 ],
        "id_str" : "15179383",
        "id" : 15179383
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "701479170971451393",
    "geo" : { },
    "id_str" : "701741843252314112",
    "in_reply_to_user_id" : 1632891,
    "text" : "@DonaldClark @NeilCanham What about when you do have the company name up as with the post about CogBooks, Arizona University and AI?",
    "id" : 701741843252314112,
    "in_reply_to_status_id" : 701479170971451393,
    "created_at" : "2016-02-22 12:14:27 +0000",
    "in_reply_to_screen_name" : "DonaldClark",
    "in_reply_to_user_id_str" : "1632891",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 701742813961183235,
  "created_at" : "2016-02-22 12:18:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Canham",
      "screen_name" : "NeilCanham",
      "indices" : [ 3, 14 ],
      "id_str" : "15179383",
      "id" : 15179383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VR",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/T46bgDeIag",
      "expanded_url" : "https:\/\/twitter.com\/DonaldClark\/status\/701462749595959297",
      "display_url" : "twitter.com\/DonaldClark\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701742576743936001",
  "text" : "RT @NeilCanham: This kind of psychobabble hype can only lead to disillusionment #VR https:\/\/t.co\/T46bgDeIag",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VR",
        "indices" : [ 64, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/T46bgDeIag",
        "expanded_url" : "https:\/\/twitter.com\/DonaldClark\/status\/701462749595959297",
        "display_url" : "twitter.com\/DonaldClark\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701474546537394176",
    "text" : "This kind of psychobabble hype can only lead to disillusionment #VR https:\/\/t.co\/T46bgDeIag",
    "id" : 701474546537394176,
    "created_at" : "2016-02-21 18:32:19 +0000",
    "user" : {
      "name" : "Neil Canham",
      "screen_name" : "NeilCanham",
      "protected" : false,
      "id_str" : "15179383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705002345034354688\/gxOp3DNl_normal.jpg",
      "id" : 15179383,
      "verified" : false
    }
  },
  "id" : 701742576743936001,
  "created_at" : "2016-02-22 12:17:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ORNOvxu6Oo",
      "expanded_url" : "http:\/\/files.flarn.org.uk\/formulaicity.mp4",
      "display_url" : "files.flarn.org.uk\/formulaicity.m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701741595750699008",
  "text" : "Audio recording F Myles The psycholinguistic construct of formulaicity in second language learners https:\/\/t.co\/ORNOvxu6Oo h\/t FLaRN",
  "id" : 701741595750699008,
  "created_at" : "2016-02-22 12:13:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Leys",
      "screen_name" : "BrunoLeys",
      "indices" : [ 0, 10 ],
      "id_str" : "19535265",
      "id" : 19535265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701733321169092610",
  "geo" : { },
  "id_str" : "701738822057508865",
  "in_reply_to_user_id" : 19535265,
  "text" : "@BrunoLeys not necessarily phonetic transcription but would try make use of phonological pathway as well as visual (as u mention in article)",
  "id" : 701738822057508865,
  "in_reply_to_status_id" : 701733321169092610,
  "created_at" : "2016-02-22 12:02:27 +0000",
  "in_reply_to_screen_name" : "BrunoLeys",
  "in_reply_to_user_id_str" : "19535265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/G6oqkG1oWu",
      "expanded_url" : "https:\/\/twitter.com\/BrunoLeys\/status\/701726163593465856",
      "display_url" : "twitter.com\/BrunoLeys\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701732748441075712",
  "text" : "hi what wld u recommended to annotate for pron? https:\/\/t.co\/G6oqkG1oWu",
  "id" : 701732748441075712,
  "created_at" : "2016-02-22 11:38:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/eP6qybFJc0",
      "expanded_url" : "http:\/\/www.vox.com\/a\/teens",
      "display_url" : "vox.com\/a\/teens"
    } ]
  },
  "in_reply_to_status_id_str" : "701707511083069441",
  "geo" : { },
  "id_str" : "701724956921569280",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish nice post did you see this? https:\/\/t.co\/eP6qybFJc0",
  "id" : 701724956921569280,
  "in_reply_to_status_id" : 701707511083069441,
  "created_at" : "2016-02-22 11:07:21 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Masters Of TESOL",
      "screen_name" : "motcast",
      "indices" : [ 0, 8 ],
      "id_str" : "2859583682",
      "id" : 2859583682
    }, {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 9, 21 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 22, 32 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 33, 49 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 50, 66 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 67, 79 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    }, {
      "name" : "Tea with BVP",
      "screen_name" : "teawithbvp",
      "indices" : [ 80, 91 ],
      "id_str" : "3677657782",
      "id" : 3677657782
    }, {
      "name" : "TheMinimalPair",
      "screen_name" : "TheMinimalPair",
      "indices" : [ 92, 107 ],
      "id_str" : "2302251163",
      "id" : 2302251163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701599168452624384",
  "geo" : { },
  "id_str" : "701723160341831680",
  "in_reply_to_user_id" : 2859583682,
  "text" : "@motcast @TheTeflShow @TEFLology @theteacherjames @michaelegriffin @TEFLCommute @teawithbvp @TheMinimalPair bingo game?",
  "id" : 701723160341831680,
  "in_reply_to_status_id" : 701599168452624384,
  "created_at" : "2016-02-22 11:00:13 +0000",
  "in_reply_to_screen_name" : "motcast",
  "in_reply_to_user_id_str" : "2859583682",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701712095017103361",
  "geo" : { },
  "id_str" : "701722787271024640",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach i think the problem is worse nowadays as a lot of that book advice is repeated on online sources which students use",
  "id" : 701722787271024640,
  "in_reply_to_status_id" : 701712095017103361,
  "created_at" : "2016-02-22 10:58:44 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben White",
      "screen_name" : "benabyad",
      "indices" : [ 3, 12 ],
      "id_str" : "248670810",
      "id" : 248670810
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/benabyad\/status\/701703189859532801\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/jB8yQPa5pN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbzzVR1XIAAwy5J.jpg",
      "id_str" : "701703188852973568",
      "id" : 701703188852973568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbzzVR1XIAAwy5J.jpg",
      "sizes" : [ {
        "h" : 539,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/jB8yQPa5pN"
    } ],
    "hashtags" : [ {
      "text" : "IsraeliApartheidWeek",
      "indices" : [ 103, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701722556349472768",
  "text" : "RT @benabyad: Posters in support of Palestinian rights have appeared on the London Underground to mark #IsraeliApartheidWeek https:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/benabyad\/status\/701703189859532801\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/jB8yQPa5pN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbzzVR1XIAAwy5J.jpg",
        "id_str" : "701703188852973568",
        "id" : 701703188852973568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbzzVR1XIAAwy5J.jpg",
        "sizes" : [ {
          "h" : 539,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/jB8yQPa5pN"
      } ],
      "hashtags" : [ {
        "text" : "IsraeliApartheidWeek",
        "indices" : [ 89, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701703189859532801",
    "text" : "Posters in support of Palestinian rights have appeared on the London Underground to mark #IsraeliApartheidWeek https:\/\/t.co\/jB8yQPa5pN",
    "id" : 701703189859532801,
    "created_at" : "2016-02-22 09:40:52 +0000",
    "user" : {
      "name" : "Ben White",
      "screen_name" : "benabyad",
      "protected" : false,
      "id_str" : "248670810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504918766799433728\/zKd13LLy_normal.jpeg",
      "id" : 248670810,
      "verified" : false
    }
  },
  "id" : 701722556349472768,
  "created_at" : "2016-02-22 10:57:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701533452290674689",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach thanks for sharing passive post be interested to hear if the graphics are of any use : )",
  "id" : 701533452290674689,
  "created_at" : "2016-02-21 22:26:23 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 31, 47 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 121, 130 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/701509227655860224\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Zrn9rk906f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbxC7L1WIAANxd2.jpg",
      "id_str" : "701509226519207936",
      "id" : 701509226519207936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbxC7L1WIAANxd2.jpg",
      "sizes" : [ {
        "h" : 287,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/Zrn9rk906f"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/r60QbImpiu",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2016-02-21\/the-deeper-truths-journalists-are-blind-to\/",
      "display_url" : "jonathan-cook.net\/blog\/2016-02-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701533223545868288",
  "text" : "RT @medialens: Crucial post by @Jonathan_K_Cook on 'The deeper truths journalists are blind to'. https:\/\/t.co\/r60QbImpiu @guardian https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Cook",
        "screen_name" : "Jonathan_K_Cook",
        "indices" : [ 16, 32 ],
        "id_str" : "2459644405",
        "id" : 2459644405
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 106, 115 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/701509227655860224\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Zrn9rk906f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbxC7L1WIAANxd2.jpg",
        "id_str" : "701509226519207936",
        "id" : 701509226519207936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbxC7L1WIAANxd2.jpg",
        "sizes" : [ {
          "h" : 287,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/Zrn9rk906f"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/r60QbImpiu",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2016-02-21\/the-deeper-truths-journalists-are-blind-to\/",
        "display_url" : "jonathan-cook.net\/blog\/2016-02-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701509227655860224",
    "text" : "Crucial post by @Jonathan_K_Cook on 'The deeper truths journalists are blind to'. https:\/\/t.co\/r60QbImpiu @guardian https:\/\/t.co\/Zrn9rk906f",
    "id" : 701509227655860224,
    "created_at" : "2016-02-21 20:50:07 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 701533223545868288,
  "created_at" : "2016-02-21 22:25:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 3, 13 ],
      "id_str" : "237842162",
      "id" : 237842162
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrClaireH\/status\/701477069688070144\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7MV4JJzMhA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbwlrFjWwAAShbY.jpg",
      "id_str" : "701477064118026240",
      "id" : 701477064118026240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbwlrFjWwAAShbY.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/7MV4JJzMhA"
    } ],
    "hashtags" : [ {
      "text" : "FireAnt",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "FireAnt",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701527193915158529",
  "text" : "RT @DrClaireH: Fun #FireAnt facts: #FireAnt works with more than social media data. Any well-formatted JSON, CSV, etc should work. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrClaireH\/status\/701477069688070144\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/7MV4JJzMhA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbwlrFjWwAAShbY.jpg",
        "id_str" : "701477064118026240",
        "id" : 701477064118026240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbwlrFjWwAAShbY.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/7MV4JJzMhA"
      } ],
      "hashtags" : [ {
        "text" : "FireAnt",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "FireAnt",
        "indices" : [ 20, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701477069688070144",
    "text" : "Fun #FireAnt facts: #FireAnt works with more than social media data. Any well-formatted JSON, CSV, etc should work. https:\/\/t.co\/7MV4JJzMhA",
    "id" : 701477069688070144,
    "created_at" : "2016-02-21 18:42:20 +0000",
    "user" : {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "protected" : false,
      "id_str" : "237842162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744470254177390592\/ZhYTy0JE_normal.jpg",
      "id" : 237842162,
      "verified" : false
    }
  },
  "id" : 701527193915158529,
  "created_at" : "2016-02-21 22:01:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 12, 25 ],
      "id_str" : "20932918",
      "id" : 20932918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701465458554359809",
  "geo" : { },
  "id_str" : "701500541248139264",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @blairteacher many thanks for sharing this post, if u use the graphics do let me know",
  "id" : 701500541248139264,
  "in_reply_to_status_id" : 701465458554359809,
  "created_at" : "2016-02-21 20:15:36 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 0, 9 ],
      "id_str" : "13533482",
      "id" : 13533482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701453672367136771",
  "geo" : { },
  "id_str" : "701463803213512704",
  "in_reply_to_user_id" : 13533482,
  "text" : "@whippler cheers : )",
  "id" : 701463803213512704,
  "in_reply_to_status_id" : 701453672367136771,
  "created_at" : "2016-02-21 17:49:37 +0000",
  "in_reply_to_screen_name" : "whippler",
  "in_reply_to_user_id_str" : "13533482",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/0yU6ed5eVp",
      "expanded_url" : "http:\/\/www.lognostics.co.uk\/varga\/",
      "display_url" : "lognostics.co.uk\/varga\/"
    } ]
  },
  "geo" : { },
  "id_str" : "701440130154938369",
  "text" : "Paul Meara's Vocabulary Acquisition Research Group Archive updated https:\/\/t.co\/0yU6ed5eVp h\/t Lexical Studies Newsletter",
  "id" : 701440130154938369,
  "created_at" : "2016-02-21 16:15:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 94, 110 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ilh1cAB5Js",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-1cJ",
      "display_url" : "wp.me\/p4E5tZ-1cJ"
    } ]
  },
  "geo" : { },
  "id_str" : "701437081264984064",
  "text" : "Six things I tried out this year which truly enhanced my teaching https:\/\/t.co\/ilh1cAB5Js via @gianfrancocont9",
  "id" : 701437081264984064,
  "created_at" : "2016-02-21 16:03:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corpus",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/E4QTb3NeF8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=sCLgRTlxG0Y",
      "display_url" : "youtube.com\/watch?v=sCLgRT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701398182828384257",
  "text" : "RT @adi_rajan: Neat video on using the #Corpus of Contemporary American English. Love the little Beyonce snippet. https:\/\/t.co\/E4QTb3NeF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corpus",
        "indices" : [ 24, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/E4QTb3NeF8",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=sCLgRTlxG0Y",
        "display_url" : "youtube.com\/watch?v=sCLgRT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701396458960850944",
    "text" : "Neat video on using the #Corpus of Contemporary American English. Love the little Beyonce snippet. https:\/\/t.co\/E4QTb3NeF8",
    "id" : 701396458960850944,
    "created_at" : "2016-02-21 13:22:01 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 701398182828384257,
  "created_at" : "2016-02-21 13:28:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 15, 31 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 32, 48 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Roib Mac Cathmhaoil",
      "screen_name" : "robmccaul",
      "indices" : [ 49, 59 ],
      "id_str" : "65910130",
      "id" : 65910130
    }, {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "indices" : [ 60, 69 ],
      "id_str" : "25624708",
      "id" : 25624708
    }, {
      "name" : "Tawsig",
      "screen_name" : "Tawsig",
      "indices" : [ 110, 117 ],
      "id_str" : "1546060946",
      "id" : 1546060946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701395709422080000",
  "text" : "RT @HadaLitim: @MarekKiczkowiak @getgreatenglish @robmccaul @skrashen Maybe because teaching is so badly paid @Tawsig so Ts can barely get \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marek Kiczkowiak",
        "screen_name" : "MarekKiczkowiak",
        "indices" : [ 0, 16 ],
        "id_str" : "2561325079",
        "id" : 2561325079
      }, {
        "name" : "Marc Jones",
        "screen_name" : "getgreatenglish",
        "indices" : [ 17, 33 ],
        "id_str" : "2273617656",
        "id" : 2273617656
      }, {
        "name" : "Roib Mac Cathmhaoil",
        "screen_name" : "robmccaul",
        "indices" : [ 34, 44 ],
        "id_str" : "65910130",
        "id" : 65910130
      }, {
        "name" : "Stephen Krashen",
        "screen_name" : "skrashen",
        "indices" : [ 45, 54 ],
        "id_str" : "25624708",
        "id" : 25624708
      }, {
        "name" : "Tawsig",
        "screen_name" : "Tawsig",
        "indices" : [ 95, 102 ],
        "id_str" : "1546060946",
        "id" : 1546060946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "701391441059250176",
    "geo" : { },
    "id_str" : "701393011368980485",
    "in_reply_to_user_id" : 2561325079,
    "text" : "@MarekKiczkowiak @getgreatenglish @robmccaul @skrashen Maybe because teaching is so badly paid @Tawsig so Ts can barely get by on a P\/T wage",
    "id" : 701393011368980485,
    "in_reply_to_status_id" : 701391441059250176,
    "created_at" : "2016-02-21 13:08:19 +0000",
    "in_reply_to_screen_name" : "MarekKiczkowiak",
    "in_reply_to_user_id_str" : "2561325079",
    "user" : {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "protected" : false,
      "id_str" : "44631065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729282562783326209\/2tQuUs5L_normal.jpg",
      "id" : 44631065,
      "verified" : false
    }
  },
  "id" : 701395709422080000,
  "created_at" : "2016-02-21 13:19:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cazique of Poyais",
      "screen_name" : "distantcities",
      "indices" : [ 3, 17 ],
      "id_str" : "87536790",
      "id" : 87536790
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/distantcities\/status\/701165269834735617\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/37J5TDQhaz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsKC_dWEAAryZ9.jpg",
      "id_str" : "701165213496774656",
      "id" : 701165213496774656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsKC_dWEAAryZ9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 367
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 367
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 367
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 367
      } ],
      "display_url" : "pic.twitter.com\/37J5TDQhaz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701383503955501056",
  "text" : "RT @distantcities: \"I have lent Baron Harkonnen three battalions of my Sardaukar terror commandos to retake Arrakis.\" https:\/\/t.co\/37J5TDQh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/distantcities\/status\/701165269834735617\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/37J5TDQhaz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsKC_dWEAAryZ9.jpg",
        "id_str" : "701165213496774656",
        "id" : 701165213496774656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsKC_dWEAAryZ9.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 367
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 367
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 367
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 367
        } ],
        "display_url" : "pic.twitter.com\/37J5TDQhaz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701165269834735617",
    "text" : "\"I have lent Baron Harkonnen three battalions of my Sardaukar terror commandos to retake Arrakis.\" https:\/\/t.co\/37J5TDQhaz",
    "id" : 701165269834735617,
    "created_at" : "2016-02-20 22:03:22 +0000",
    "user" : {
      "name" : "Cazique of Poyais",
      "screen_name" : "distantcities",
      "protected" : false,
      "id_str" : "87536790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700121050848296961\/INVU5Y_N_normal.jpg",
      "id" : 87536790,
      "verified" : false
    }
  },
  "id" : 701383503955501056,
  "created_at" : "2016-02-21 12:30:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HancockMcDonald\/status\/701378666119487488\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/aMsQmta4cZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbvMLgjWAAAr8p1.jpg",
      "id_str" : "701378665075048448",
      "id" : 701378665075048448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbvMLgjWAAAr8p1.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 649
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1108
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2219,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 368
      } ],
      "display_url" : "pic.twitter.com\/aMsQmta4cZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/kUhXGsh4L7",
      "expanded_url" : "http:\/\/hancockmcdonald.com\/materials",
      "display_url" : "hancockmcdonald.com\/materials"
    } ]
  },
  "geo" : { },
  "id_str" : "701380604856823808",
  "text" : "RT @HancockMcDonald: Mark: since I published this last year, made illustrated, phonics and American versions, see https:\/\/t.co\/kUhXGsh4L7 h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HancockMcDonald\/status\/701378666119487488\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/aMsQmta4cZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbvMLgjWAAAr8p1.jpg",
        "id_str" : "701378665075048448",
        "id" : 701378665075048448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbvMLgjWAAAr8p1.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1108
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2219,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 368
        } ],
        "display_url" : "pic.twitter.com\/aMsQmta4cZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/kUhXGsh4L7",
        "expanded_url" : "http:\/\/hancockmcdonald.com\/materials",
        "display_url" : "hancockmcdonald.com\/materials"
      } ]
    },
    "geo" : { },
    "id_str" : "701378666119487488",
    "text" : "Mark: since I published this last year, made illustrated, phonics and American versions, see https:\/\/t.co\/kUhXGsh4L7 https:\/\/t.co\/aMsQmta4cZ",
    "id" : 701378666119487488,
    "created_at" : "2016-02-21 12:11:19 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 701380604856823808,
  "created_at" : "2016-02-21 12:19:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 0, 9 ],
      "id_str" : "13533482",
      "id" : 13533482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/XmME9pEG7z",
      "expanded_url" : "https:\/\/eflnotes.files.wordpress.com\/2015\/09\/tdsig-article.pdf",
      "display_url" : "eflnotes.files.wordpress.com\/2015\/09\/tdsig-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701373569566187520",
  "geo" : { },
  "id_str" : "701374267456413696",
  "in_reply_to_user_id" : 13533482,
  "text" : "@whippler thx but just remixing someone else's code really have you read this (pdf)? https:\/\/t.co\/XmME9pEG7z",
  "id" : 701374267456413696,
  "in_reply_to_status_id" : 701373569566187520,
  "created_at" : "2016-02-21 11:53:50 +0000",
  "in_reply_to_screen_name" : "whippler",
  "in_reply_to_user_id_str" : "13533482",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roib Mac Cathmhaoil",
      "screen_name" : "robmccaul",
      "indices" : [ 0, 10 ],
      "id_str" : "65910130",
      "id" : 65910130
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 11, 21 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 22, 32 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    }, {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 33, 49 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 50, 61 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701368878560100352",
  "geo" : { },
  "id_str" : "701370050729668608",
  "in_reply_to_user_id" : 65910130,
  "text" : "@robmccaul @nakanotim @TEFLology @MarekKiczkowiak @leoselivan two words sci-hub",
  "id" : 701370050729668608,
  "in_reply_to_status_id" : 701368878560100352,
  "created_at" : "2016-02-21 11:37:05 +0000",
  "in_reply_to_screen_name" : "robmccaul",
  "in_reply_to_user_id_str" : "65910130",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B. Whipple",
      "screen_name" : "whippler",
      "indices" : [ 0, 9 ],
      "id_str" : "13533482",
      "id" : 13533482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701347847690698752",
  "geo" : { },
  "id_str" : "701365139103154176",
  "in_reply_to_user_id" : 13533482,
  "text" : "@whippler hi sorry forgot to update share feature will work now!",
  "id" : 701365139103154176,
  "in_reply_to_status_id" : 701347847690698752,
  "created_at" : "2016-02-21 11:17:34 +0000",
  "in_reply_to_screen_name" : "whippler",
  "in_reply_to_user_id_str" : "13533482",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/5N02V2i6wU",
      "expanded_url" : "http:\/\/mondoweiss.net\/2016\/02\/chomsky-and-his-critics\/",
      "display_url" : "mondoweiss.net\/2016\/02\/chomsk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701167348288458756",
  "text" : "RT @johnwhilley: Chomsky and his critics https:\/\/t.co\/5N02V2i6wU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/5N02V2i6wU",
        "expanded_url" : "http:\/\/mondoweiss.net\/2016\/02\/chomsky-and-his-critics\/",
        "display_url" : "mondoweiss.net\/2016\/02\/chomsk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701163529177591810",
    "text" : "Chomsky and his critics https:\/\/t.co\/5N02V2i6wU",
    "id" : 701163529177591810,
    "created_at" : "2016-02-20 21:56:27 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 701167348288458756,
  "created_at" : "2016-02-20 22:11:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 72, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701119312464056322",
  "text" : "TOEIC-Ass 1\nTOEIC-Ass 2\nRaging TOEFL\nIELTS Fidelity\nX-Men: First BULATS\n#makeamovieTESL",
  "id" : 701119312464056322,
  "created_at" : "2016-02-20 19:00:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700779928585957377",
  "geo" : { },
  "id_str" : "701106916089528322",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT conicidence? i think not. must be the temple of bloom's occult powers : )",
  "id" : 701106916089528322,
  "in_reply_to_status_id" : 700779928585957377,
  "created_at" : "2016-02-20 18:11:29 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701106435980189696",
  "text" : "V for Vygotsky\nTwilight Zone of Proximal Development\n#makeamovieTESL",
  "id" : 701106435980189696,
  "created_at" : "2016-02-20 18:09:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 107, 117 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/rvplXLsJgZ",
      "expanded_url" : "https:\/\/shar.es\/14SRYX",
      "display_url" : "shar.es\/14SRYX"
    } ]
  },
  "geo" : { },
  "id_str" : "701056077748682752",
  "text" : "Black Struggle Is Not a Sound Bite: Why I Refused to Meet With President Obama https:\/\/t.co\/rvplXLsJgZ via @sharethis",
  "id" : 701056077748682752,
  "created_at" : "2016-02-20 14:49:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701051643438231554",
  "geo" : { },
  "id_str" : "701052457812676609",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark it is what it is?",
  "id" : 701052457812676609,
  "in_reply_to_status_id" : 701051643438231554,
  "created_at" : "2016-02-20 14:35:05 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 0, 15 ],
      "id_str" : "83207734",
      "id" : 83207734
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 16, 23 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701052329374720004",
  "in_reply_to_user_id" : 83207734,
  "text" : "@dreadnought001 @SobejM thks for RTs of Passives Post : )",
  "id" : 701052329374720004,
  "created_at" : "2016-02-20 14:34:34 +0000",
  "in_reply_to_screen_name" : "dreadnought001",
  "in_reply_to_user_id_str" : "83207734",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 3, 17 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/V7xAkZsiXW",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/700942040285192192",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701049509216960517",
  "text" : "RT @SnoozeInBrief: Person criticises passive voice while using passive voice (and getting its name wrong), episode eleventy billion https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/V7xAkZsiXW",
        "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/700942040285192192",
        "display_url" : "twitter.com\/muranava\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701004732488355841",
    "text" : "Person criticises passive voice while using passive voice (and getting its name wrong), episode eleventy billion https:\/\/t.co\/V7xAkZsiXW",
    "id" : 701004732488355841,
    "created_at" : "2016-02-20 11:25:26 +0000",
    "user" : {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "protected" : false,
      "id_str" : "82947233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748108494319063040\/5zXTqDqs_normal.jpg",
      "id" : 82947233,
      "verified" : false
    }
  },
  "id" : 701049509216960517,
  "created_at" : "2016-02-20 14:23:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 0, 14 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701004732488355841",
  "geo" : { },
  "id_str" : "701049479743541248",
  "in_reply_to_user_id" : 82947233,
  "text" : "@SnoozeInBrief whew thanks can say hit spike due to you and not comical ollie : )",
  "id" : 701049479743541248,
  "in_reply_to_status_id" : 701004732488355841,
  "created_at" : "2016-02-20 14:23:15 +0000",
  "in_reply_to_screen_name" : "SnoozeInBrief",
  "in_reply_to_user_id_str" : "82947233",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT Assoc Berlin",
      "screen_name" : "eltabb",
      "indices" : [ 76, 83 ],
      "id_str" : "18966557",
      "id" : 18966557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTIRL16",
      "indices" : [ 58, 67 ]
    }, {
      "text" : "MaWSIG",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/F1PHQn0MgH",
      "expanded_url" : "http:\/\/elttalkbingo.englishup.me\/newcard.html",
      "display_url" : "elttalkbingo.englishup.me\/newcard.html"
    } ]
  },
  "geo" : { },
  "id_str" : "701049165770584069",
  "text" : "pass some time with ELTtalk bingo https:\/\/t.co\/F1PHQn0MgH #ELTIRL16 #MaWSIG @eltabb : )",
  "id" : 701049165770584069,
  "created_at" : "2016-02-20 14:22:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "indices" : [ 0, 14 ],
      "id_str" : "1239302874",
      "id" : 1239302874
    }, {
      "name" : "ActiveHistory.co.uk",
      "screen_name" : "activehistory",
      "indices" : [ 49, 63 ],
      "id_str" : "36014276",
      "id" : 36014276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701001083615838208",
  "in_reply_to_user_id" : 1239302874,
  "text" : "@LessonToolbox oh dear \"scapegoating Shah\" maybe @activehistory needs to do a bit more active history reading",
  "id" : 701001083615838208,
  "created_at" : "2016-02-20 11:10:56 +0000",
  "in_reply_to_screen_name" : "LessonToolbox",
  "in_reply_to_user_id_str" : "1239302874",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 23, 29 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 79, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/cpZoVNSMUD",
      "expanded_url" : "https:\/\/github.com\/magnusnissel\/birdbody",
      "display_url" : "github.com\/magnusnissel\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700994612362682369",
  "text" : "interesting project by @u203d gui for tweet collection https:\/\/t.co\/cpZoVNSMUD #corpusresources",
  "id" : 700994612362682369,
  "created_at" : "2016-02-20 10:45:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 0, 12 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 13, 23 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 24, 40 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 41, 57 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 58, 70 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    }, {
      "name" : "Masters Of TESOL",
      "screen_name" : "motcast",
      "indices" : [ 71, 79 ],
      "id_str" : "2859583682",
      "id" : 2859583682
    }, {
      "name" : "Tea with BVP",
      "screen_name" : "teawithbvp",
      "indices" : [ 80, 91 ],
      "id_str" : "3677657782",
      "id" : 3677657782
    }, {
      "name" : "TheMinimalPair",
      "screen_name" : "TheMinimalPair",
      "indices" : [ 92, 107 ],
      "id_str" : "2302251163",
      "id" : 2302251163
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/700986062789877760\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/6cDhSGKmSy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbpnG_OW0AA7IVX.jpg",
      "id_str" : "700986061758058496",
      "id" : 700986061758058496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbpnG_OW0AA7IVX.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/6cDhSGKmSy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700858708285333504",
  "geo" : { },
  "id_str" : "700986062789877760",
  "in_reply_to_user_id" : 3996937557,
  "text" : "@TheTeflShow @TEFLology @theteacherjames @michaelegriffin @TEFLCommute @motcast @teawithbvp @TheMinimalPair points? https:\/\/t.co\/6cDhSGKmSy",
  "id" : 700986062789877760,
  "in_reply_to_status_id" : 700858708285333504,
  "created_at" : "2016-02-20 10:11:15 +0000",
  "in_reply_to_screen_name" : "TheTeflShow",
  "in_reply_to_user_id_str" : "3996937557",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 16, 26 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/700942040285192192\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/IoO8LPHo7M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbo_EjYW4AA_mSk.png",
      "id_str" : "700942039458963456",
      "id" : 700942039458963456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbo_EjYW4AA_mSk.png",
      "sizes" : [ {
        "h" : 433,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 525
      } ],
      "display_url" : "pic.twitter.com\/IoO8LPHo7M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/GjRB30bUae",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/02\/18\/impassive-pullum-on-passives\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/02\/18\/imp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700942040285192192",
  "text" : "even the mighty @medialens falls to the passive clause obsession; let Pullum school you https:\/\/t.co\/GjRB30bUae https:\/\/t.co\/IoO8LPHo7M",
  "id" : 700942040285192192,
  "created_at" : "2016-02-20 07:16:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 11, 19 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700624498249236480",
  "geo" : { },
  "id_str" : "700940075031523328",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @BBCNews erm nothing wrong with use of passive here as Venezuela is topic of interest but very true about angle of report",
  "id" : 700940075031523328,
  "in_reply_to_status_id" : 700624498249236480,
  "created_at" : "2016-02-20 07:08:31 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 11, 23 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700931543196241920",
  "geo" : { },
  "id_str" : "700936570543718400",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @DonaldClark that's interesting",
  "id" : 700936570543718400,
  "in_reply_to_status_id" : 700931543196241920,
  "created_at" : "2016-02-20 06:54:35 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700775304374030336",
  "text" : "Indiana Jones &amp; the Temple of Bloom's Taxonomy #makeamovieTESL",
  "id" : 700775304374030336,
  "created_at" : "2016-02-19 20:13:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700772358332649472",
  "text" : "Some like it HigherOrderThinking\nHigherOrderThinking Fuzz\nHigherOrderThinking Tub Time Machine\n#makeamovieTESL",
  "id" : 700772358332649472,
  "created_at" : "2016-02-19 20:02:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 27, 40 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/NJXJ6igzRF",
      "expanded_url" : "https:\/\/medium.com\/@neuroecology\/punctuation-in-novels-8f316d542ec4#.dl6q3h5aw",
      "display_url" : "medium.com\/@neuroecology\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700763529305989120",
  "text" : "\u201CPunctuation in novels\u201D by @neuroecology https:\/\/t.co\/NJXJ6igzRF",
  "id" : 700763529305989120,
  "created_at" : "2016-02-19 19:26:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700760822948110337",
  "text" : "Computer Labyrinth #makeamovieTESL",
  "id" : 700760822948110337,
  "created_at" : "2016-02-19 19:16:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 20, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700759334221848576",
  "text" : "Casafillintheblanca #makeamovieTESL",
  "id" : 700759334221848576,
  "created_at" : "2016-02-19 19:10:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 75, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700758500977152001",
  "text" : "Steve Cuisenaire Rods\nHammer of the Cuisenaire Rods\nCity of Cuisenaire Rod\n#makeamovieTESL",
  "id" : 700758500977152001,
  "created_at" : "2016-02-19 19:07:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 17, 33 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 62, 72 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    }, {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 73, 85 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    }, {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 86, 98 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    }, {
      "name" : "Masters Of TESOL",
      "screen_name" : "motcast",
      "indices" : [ 99, 107 ],
      "id_str" : "2859583682",
      "id" : 2859583682
    }, {
      "name" : "Tea with BVP",
      "screen_name" : "teawithbvp",
      "indices" : [ 108, 119 ],
      "id_str" : "3677657782",
      "id" : 3677657782
    }, {
      "name" : "TheMinimalPair",
      "screen_name" : "TheMinimalPair",
      "indices" : [ 120, 135 ],
      "id_str" : "2302251163",
      "id" : 2302251163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700734082402091008",
  "geo" : { },
  "id_str" : "700741863964147712",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @michaelegriffin this could escalate quickly @TEFLology @TheTeflShow @TEFLCommute @motcast @teawithbvp @TheMinimalPair",
  "id" : 700741863964147712,
  "in_reply_to_status_id" : 700734082402091008,
  "created_at" : "2016-02-19 18:00:54 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vanessa beeley",
      "screen_name" : "VanessaBeeley",
      "indices" : [ 122, 136 ],
      "id_str" : "956171191",
      "id" : 956171191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/XTauW5ZDRV",
      "expanded_url" : "http:\/\/wp.me\/p5351I-1MQ",
      "display_url" : "wp.me\/p5351I-1MQ"
    } ]
  },
  "geo" : { },
  "id_str" : "700721201967026176",
  "text" : "Propagandist Robert Ford Goes For Round Two With Syria Researcher Vanessa Beeley \u2026 And Loses! https:\/\/t.co\/XTauW5ZDRV via @VanessaBeeley",
  "id" : 700721201967026176,
  "created_at" : "2016-02-19 16:38:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700705304023928836",
  "geo" : { },
  "id_str" : "700717274806689792",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin this is something that can be arranged surely : )",
  "id" : 700717274806689792,
  "in_reply_to_status_id" : 700705304023928836,
  "created_at" : "2016-02-19 16:23:11 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/NIFPZHiLJW",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/02\/one-does-not-bomb-wog-only-to-help-his.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/02\/one-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700696204586254336",
  "text" : "RT @pchallinor: New mudgeonry: One does not bomb a wog only to help his children https:\/\/t.co\/NIFPZHiLJW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/NIFPZHiLJW",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/02\/one-does-not-bomb-wog-only-to-help-his.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/02\/one-do\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700695745427480576",
    "text" : "New mudgeonry: One does not bomb a wog only to help his children https:\/\/t.co\/NIFPZHiLJW",
    "id" : 700695745427480576,
    "created_at" : "2016-02-19 14:57:38 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 700696204586254336,
  "created_at" : "2016-02-19 14:59:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700690531366494208",
  "geo" : { },
  "id_str" : "700691038709506048",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish man tell Massachusetts they can wait ; )",
  "id" : 700691038709506048,
  "in_reply_to_status_id" : 700690531366494208,
  "created_at" : "2016-02-19 14:38:56 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700679753200640001",
  "geo" : { },
  "id_str" : "700689965080907776",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx any luck on your end with different device?",
  "id" : 700689965080907776,
  "in_reply_to_status_id" : 700679753200640001,
  "created_at" : "2016-02-19 14:34:40 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 101, 112 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/xVwQWkUZAh",
      "expanded_url" : "http:\/\/wp.me\/p1wqwD-VR",
      "display_url" : "wp.me\/p1wqwD-VR"
    } ]
  },
  "geo" : { },
  "id_str" : "700689753411178498",
  "text" : "How shift to computer-based tests could shake up PISA education rankings https:\/\/t.co\/xVwQWkUZAh via @IOE_London",
  "id" : 700689753411178498,
  "created_at" : "2016-02-19 14:33:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 13, 29 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700682311616978945",
  "geo" : { },
  "id_str" : "700684450703626240",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @getgreatenglish more opportunities in 121 classes; echoes of the direct instruction vs discovery learning debates?",
  "id" : 700684450703626240,
  "in_reply_to_status_id" : 700682311616978945,
  "created_at" : "2016-02-19 14:12:45 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700681766315511810",
  "geo" : { },
  "id_str" : "700682128497840130",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark kk thxs",
  "id" : 700682128497840130,
  "in_reply_to_status_id" : 700681766315511810,
  "created_at" : "2016-02-19 14:03:32 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700679557309837314",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hey Marc thx for RTing request : )",
  "id" : 700679557309837314,
  "created_at" : "2016-02-19 13:53:19 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700675515061895170",
  "geo" : { },
  "id_str" : "700679332792930304",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark your post seems to be making it more than \"it is what it is\"; is there more info one can follow up on these results?",
  "id" : 700679332792930304,
  "in_reply_to_status_id" : 700675515061895170,
  "created_at" : "2016-02-19 13:52:25 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700676530842652673",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy hi Eily thx for RT of testing request, should have added please RT doh!",
  "id" : 700676530842652673,
  "created_at" : "2016-02-19 13:41:17 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700664043418169345",
  "geo" : { },
  "id_str" : "700674388186701824",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark how \"powerful\" could these results be if there are (seemingly) no controls?",
  "id" : 700674388186701824,
  "in_reply_to_status_id" : 700664043418169345,
  "created_at" : "2016-02-19 13:32:46 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700665510950645761",
  "text" : "looking for some to test app &amp; who can sideload apple .ipa file on their device, thx",
  "id" : 700665510950645761,
  "created_at" : "2016-02-19 12:57:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700432785710977024",
  "text" : "Galaxy Webquest #makeamovieTESL",
  "id" : 700432785710977024,
  "created_at" : "2016-02-18 21:32:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 21, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700431673402462208",
  "text" : "L.A.D Max: Fury Noam #makeamovieTESL",
  "id" : 700431673402462208,
  "created_at" : "2016-02-18 21:28:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700430762210959360",
  "text" : "The Good, The L.A.D. and the Ugly #makeamovieTESL",
  "id" : 700430762210959360,
  "created_at" : "2016-02-18 21:24:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700429867293220864",
  "text" : "Inflection #makeamovieTESL",
  "id" : 700429867293220864,
  "created_at" : "2016-02-18 21:21:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 12, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700428108575481858",
  "text" : "Grammarlins #makeamovieTESL",
  "id" : 700428108575481858,
  "created_at" : "2016-02-18 21:14:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700421994790129665",
  "text" : "Paranormal Warmer Activity #makeamovieTESL",
  "id" : 700421994790129665,
  "created_at" : "2016-02-18 20:49:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 70, 86 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/SxFHz8OBzM",
      "expanded_url" : "http:\/\/hapgood.us\/2016\/02\/18\/why-learning-cant-be-like-a-video-game\/",
      "display_url" : "hapgood.us\/2016\/02\/18\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700420129939709952",
  "text" : "Why Learning Can\u2019t Be \u201CLike a Video\u00A0Game\u201D https:\/\/t.co\/SxFHz8OBzM via @wordpressdotcom",
  "id" : 700420129939709952,
  "created_at" : "2016-02-18 20:42:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700419501440032768",
  "text" : "Midnight Run On Sentence #makeamovieTESL",
  "id" : 700419501440032768,
  "created_at" : "2016-02-18 20:39:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 12, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700417277955567616",
  "text" : "Cape Copier #makeamovieTESL",
  "id" : 700417277955567616,
  "created_at" : "2016-02-18 20:31:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Cohen",
      "screen_name" : "JaneCohenEFL",
      "indices" : [ 3, 16 ],
      "id_str" : "705261589",
      "id" : 705261589
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 33, 44 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 70, 78 ],
      "id_str" : "189578708",
      "id" : 189578708
    }, {
      "name" : "Julie Bytheway",
      "screen_name" : "JulieBTW",
      "indices" : [ 79, 88 ],
      "id_str" : "24023185",
      "id" : 24023185
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 89, 100 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/8W9zNLftq0",
      "expanded_url" : "https:\/\/twitter.com\/miguecordi\/status\/700334745943543808",
      "display_url" : "twitter.com\/miguecordi\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700412425384886272",
  "text" : "RT @JaneCohenEFL: Gr8 article by @leoselivan 'well + worth + reading' @ELTchat @JulieBTW @hughdellar  https:\/\/t.co\/8W9zNLftq0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 15, 26 ],
        "id_str" : "408365496",
        "id" : 408365496
      }, {
        "name" : "#ELTchat",
        "screen_name" : "ELTchat",
        "indices" : [ 52, 60 ],
        "id_str" : "189578708",
        "id" : 189578708
      }, {
        "name" : "Julie Bytheway",
        "screen_name" : "JulieBTW",
        "indices" : [ 61, 70 ],
        "id_str" : "24023185",
        "id" : 24023185
      }, {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 71, 82 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/8W9zNLftq0",
        "expanded_url" : "https:\/\/twitter.com\/miguecordi\/status\/700334745943543808",
        "display_url" : "twitter.com\/miguecordi\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700382997929947136",
    "text" : "Gr8 article by @leoselivan 'well + worth + reading' @ELTchat @JulieBTW @hughdellar  https:\/\/t.co\/8W9zNLftq0",
    "id" : 700382997929947136,
    "created_at" : "2016-02-18 18:14:53 +0000",
    "user" : {
      "name" : "Jane Cohen",
      "screen_name" : "JaneCohenEFL",
      "protected" : false,
      "id_str" : "705261589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2412523271\/0OB8bPaG_normal",
      "id" : 705261589,
      "verified" : false
    }
  },
  "id" : 700412425384886272,
  "created_at" : "2016-02-18 20:11:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700411649983959041",
  "geo" : { },
  "id_str" : "700412304316370944",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yep it's live someone tweeted it earlier",
  "id" : 700412304316370944,
  "in_reply_to_status_id" : 700411649983959041,
  "created_at" : "2016-02-18 20:11:21 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700405629006016514",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan i like the corpus connaisseur collocation : ) thanks for plugging my blog",
  "id" : 700405629006016514,
  "created_at" : "2016-02-18 19:44:49 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 3, 13 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HotPotatoesSuite",
      "indices" : [ 99, 116 ]
    }, {
      "text" : "anglais",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "englishlearner",
      "indices" : [ 126, 141 ]
    }, {
      "text" : "verbs",
      "indices" : [ 143, 144 ]
    }, {
      "text" : "efl",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/zKsU8ezpwl",
      "expanded_url" : "http:\/\/www.english-studies.org\/ex_pages\/hot_potatoes\/concordance\/conc_see_watch_look.html",
      "display_url" : "english-studies.org\/ex_pages\/hot_p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700377546177847300",
  "text" : "RT @curvedway: Exercises based on Concordance Lines \nLOOK, SEE &amp; WATCH\nhttps:\/\/t.co\/zKsU8ezpwl #HotPotatoesSuite #anglais #englishlearner #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HotPotatoesSuite",
        "indices" : [ 84, 101 ]
      }, {
        "text" : "anglais",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "englishlearner",
        "indices" : [ 111, 126 ]
      }, {
        "text" : "verbs",
        "indices" : [ 127, 133 ]
      }, {
        "text" : "efl",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/zKsU8ezpwl",
        "expanded_url" : "http:\/\/www.english-studies.org\/ex_pages\/hot_potatoes\/concordance\/conc_see_watch_look.html",
        "display_url" : "english-studies.org\/ex_pages\/hot_p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700374394846236676",
    "text" : "Exercises based on Concordance Lines \nLOOK, SEE &amp; WATCH\nhttps:\/\/t.co\/zKsU8ezpwl #HotPotatoesSuite #anglais #englishlearner #verbs #efl",
    "id" : 700374394846236676,
    "created_at" : "2016-02-18 17:40:42 +0000",
    "user" : {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "protected" : false,
      "id_str" : "124707247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439859868434837505\/-h531G_i_normal.jpeg",
      "id" : 124707247,
      "verified" : false
    }
  },
  "id" : 700377546177847300,
  "created_at" : "2016-02-18 17:53:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/SbnqrQwqt5",
      "expanded_url" : "http:\/\/hackeducation.com\/2016\/02\/17\/amazon-oer",
      "display_url" : "hackeducation.com\/2016\/02\/17\/ama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700355786325807104",
  "text" : "RT @audreywatters: Amazon's Plans for OER https:\/\/t.co\/SbnqrQwqt5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/SbnqrQwqt5",
        "expanded_url" : "http:\/\/hackeducation.com\/2016\/02\/17\/amazon-oer",
        "display_url" : "hackeducation.com\/2016\/02\/17\/ama\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700141642443943936",
    "text" : "Amazon's Plans for OER https:\/\/t.co\/SbnqrQwqt5",
    "id" : 700141642443943936,
    "created_at" : "2016-02-18 02:15:50 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 700355786325807104,
  "created_at" : "2016-02-18 16:26:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 0, 14 ],
      "id_str" : "118014141",
      "id" : 118014141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700314728208408576",
  "geo" : { },
  "id_str" : "700315988714221568",
  "in_reply_to_user_id" : 118014141,
  "text" : "@alexanderding LOL by \"acknowledgement\" they must mean doffing the cap in gratitide not the kind of ack made in the post, parody comment?",
  "id" : 700315988714221568,
  "in_reply_to_status_id" : 700314728208408576,
  "created_at" : "2016-02-18 13:48:37 +0000",
  "in_reply_to_screen_name" : "alexanderding",
  "in_reply_to_user_id_str" : "118014141",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Lyon-Jones",
      "screen_name" : "esolcourses",
      "indices" : [ 0, 12 ],
      "id_str" : "34321100",
      "id" : 34321100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700312569031094272",
  "geo" : { },
  "id_str" : "700313148855873537",
  "in_reply_to_user_id" : 34321100,
  "text" : "@esolcourses i don't see this ending very soon : )",
  "id" : 700313148855873537,
  "in_reply_to_status_id" : 700312569031094272,
  "created_at" : "2016-02-18 13:37:20 +0000",
  "in_reply_to_screen_name" : "esolcourses",
  "in_reply_to_user_id_str" : "34321100",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 17, 32 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700307678887673856",
  "geo" : { },
  "id_str" : "700312717907857408",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @MrChrisJWilson that sounds interesting Marc have you written about that?",
  "id" : 700312717907857408,
  "in_reply_to_status_id" : 700307678887673856,
  "created_at" : "2016-02-18 13:35:37 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 15, 21 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700312283260526592",
  "geo" : { },
  "id_str" : "700312547283574784",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @idc74 if you want",
  "id" : 700312547283574784,
  "in_reply_to_status_id" : 700312283260526592,
  "created_at" : "2016-02-18 13:34:57 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 26, 32 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700310599738257408",
  "geo" : { },
  "id_str" : "700311423780573184",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @HadaLitim @idc74 value to Amazon not interesting (to me); 2 types of teacher claim ignores discourse on OER",
  "id" : 700311423780573184,
  "in_reply_to_status_id" : 700310599738257408,
  "created_at" : "2016-02-18 13:30:29 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 26, 32 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700308879184367616",
  "geo" : { },
  "id_str" : "700309675120685056",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @HadaLitim @idc74 i thought we were discussing whether this would work educationally? 2 yrs no adaptation just folding",
  "id" : 700309675120685056,
  "in_reply_to_status_id" : 700308879184367616,
  "created_at" : "2016-02-18 13:23:32 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 15, 21 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700308075270557696",
  "geo" : { },
  "id_str" : "700308282674642944",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @idc74 does that mean you taking the bet? : )",
  "id" : 700308282674642944,
  "in_reply_to_status_id" : 700308075270557696,
  "created_at" : "2016-02-18 13:18:00 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 15, 21 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700306728789921792",
  "geo" : { },
  "id_str" : "700307106088534017",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @idc74 let's take a bet? will it Amazon thing still be up in 2 years time? : )",
  "id" : 700307106088534017,
  "in_reply_to_status_id" : 700306728789921792,
  "created_at" : "2016-02-18 13:13:19 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 15, 21 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700304768871358464",
  "geo" : { },
  "id_str" : "700305988696539137",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @idc74 not seen any evidence contrary to the two arguments against Amazon marketplace working in the link i posted previously",
  "id" : 700305988696539137,
  "in_reply_to_status_id" : 700304768871358464,
  "created_at" : "2016-02-18 13:08:53 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 17, 23 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 39, 54 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700191771515432960",
  "geo" : { },
  "id_str" : "700304805860929536",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @ebefl is the suspect @GeoffreyJordan? : )",
  "id" : 700304805860929536,
  "in_reply_to_status_id" : 700191771515432960,
  "created_at" : "2016-02-18 13:04:11 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700304207061114883",
  "geo" : { },
  "id_str" : "700304454445359104",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson #makeamovieTESL ; )",
  "id" : 700304454445359104,
  "in_reply_to_status_id" : 700304207061114883,
  "created_at" : "2016-02-18 13:02:47 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/700298649880801281\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/rT83aPae5G",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cbf16QZUkAA6qJI.jpg",
      "id_str" : "700298648261791744",
      "id" : 700298648261791744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cbf16QZUkAA6qJI.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/rT83aPae5G"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "tesl",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "esl",
      "indices" : [ 44, 48 ]
    }, {
      "text" : "tefl",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 55, 66 ]
    }, {
      "text" : "auselt",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/GjRB30tv1M",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/02\/18\/impassive-pullum-on-passives\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/02\/18\/imp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700298649880801281",
  "text" : "Impassive Pullum on Passives #eltchat #tesl #esl #tefl #eltchinwag #auselt #keltchat https:\/\/t.co\/GjRB30tv1M https:\/\/t.co\/rT83aPae5G",
  "id" : 700298649880801281,
  "created_at" : "2016-02-18 12:39:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 7, 21 ],
      "id_str" : "31697976",
      "id" : 31697976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700297180150697984",
  "geo" : { },
  "id_str" : "700297883854249984",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 @pressfuturist haven't we all? : ) the point is most times teachers are compelled to adapt to their contexts",
  "id" : 700297883854249984,
  "in_reply_to_status_id" : 700297180150697984,
  "created_at" : "2016-02-18 12:36:41 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 15, 21 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700296847273955328",
  "geo" : { },
  "id_str" : "700297194075779072",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @idc74 yes and books are portable local copies not centralised copies",
  "id" : 700297194075779072,
  "in_reply_to_status_id" : 700296847273955328,
  "created_at" : "2016-02-18 12:33:56 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 0, 14 ],
      "id_str" : "31697976",
      "id" : 31697976
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 15, 21 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700295038853652480",
  "geo" : { },
  "id_str" : "700296527332446208",
  "in_reply_to_user_id" : 31697976,
  "text" : "@pressfuturist @idc74 you will need to be a \"productive\" teacher to adapt resources u get off Amazon",
  "id" : 700296527332446208,
  "in_reply_to_status_id" : 700295038853652480,
  "created_at" : "2016-02-18 12:31:17 +0000",
  "in_reply_to_screen_name" : "pressfuturist",
  "in_reply_to_user_id_str" : "31697976",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 7, 21 ],
      "id_str" : "31697976",
      "id" : 31697976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700290320425185281",
  "geo" : { },
  "id_str" : "700294197857759232",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 @pressfuturist the former : ) for sure work for the latter but won't be argument for public consumption",
  "id" : 700294197857759232,
  "in_reply_to_status_id" : 700290320425185281,
  "created_at" : "2016-02-18 12:22:02 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "pressfuturist",
      "screen_name" : "pressfuturist",
      "indices" : [ 7, 21 ],
      "id_str" : "31697976",
      "id" : 31697976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/UE1sWF2TVB",
      "expanded_url" : "http:\/\/hapgood.us\/2016\/02\/16\/amazon-oer-and-soundcloud\/",
      "display_url" : "hapgood.us\/2016\/02\/16\/ama\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "700287962945294336",
  "geo" : { },
  "id_str" : "700289006538518528",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 @pressfuturist u cld read this to see why it won't work https:\/\/t.co\/UE1sWF2TVB",
  "id" : 700289006538518528,
  "in_reply_to_status_id" : 700287962945294336,
  "created_at" : "2016-02-18 12:01:24 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700280500234149889",
  "geo" : { },
  "id_str" : "700282409141534720",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran nice to hear thx :)",
  "id" : 700282409141534720,
  "in_reply_to_status_id" : 700280500234149889,
  "created_at" : "2016-02-18 11:35:11 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700280228812189696",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran cheers for RTing Real Rules of Passives Ljiljana : )",
  "id" : 700280228812189696,
  "created_at" : "2016-02-18 11:26:31 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700278406651387904",
  "geo" : { },
  "id_str" : "700279933206204416",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish well it's a Pullum production really I just repackaged it : )",
  "id" : 700279933206204416,
  "in_reply_to_status_id" : 700278406651387904,
  "created_at" : "2016-02-18 11:25:21 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700254318675550209",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish cheers for the Real Rules for Passives RT Marc : )",
  "id" : 700254318675550209,
  "created_at" : "2016-02-18 09:43:34 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700250339992322055",
  "geo" : { },
  "id_str" : "700254146939768832",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet thx for sharing : )",
  "id" : 700254146939768832,
  "in_reply_to_status_id" : 700250339992322055,
  "created_at" : "2016-02-18 09:42:53 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Action Movie ESL",
      "screen_name" : "actionmovieesl",
      "indices" : [ 3, 18 ],
      "id_str" : "4924499054",
      "id" : 4924499054
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/actionmovieesl\/status\/700227572085317633\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/tnOQ3WhvSU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cbe1PnKUYAAFB4t.jpg",
      "id_str" : "700227546894327808",
      "id" : 700227546894327808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cbe1PnKUYAAFB4t.jpg",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 139,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/tnOQ3WhvSU"
    } ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 33, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700245359583481856",
  "text" : "RT @actionmovieesl: When another #ESL teacher wants to use the computer lab at the same time as you https:\/\/t.co\/tnOQ3WhvSU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/actionmovieesl\/status\/700227572085317633\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/tnOQ3WhvSU",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cbe1PnKUYAAFB4t.jpg",
        "id_str" : "700227546894327808",
        "id" : 700227546894327808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cbe1PnKUYAAFB4t.jpg",
        "sizes" : [ {
          "h" : 204,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 139,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/tnOQ3WhvSU"
      } ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 13, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700227572085317633",
    "text" : "When another #ESL teacher wants to use the computer lab at the same time as you https:\/\/t.co\/tnOQ3WhvSU",
    "id" : 700227572085317633,
    "created_at" : "2016-02-18 07:57:17 +0000",
    "user" : {
      "name" : "Action Movie ESL",
      "screen_name" : "actionmovieesl",
      "protected" : false,
      "id_str" : "4924499054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700224622025842689\/0cL11h9O_normal.jpg",
      "id" : 4924499054,
      "verified" : false
    }
  },
  "id" : 700245359583481856,
  "created_at" : "2016-02-18 09:07:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/700244858846502912\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/4qX8jcgiXi",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbfEzBuWEAAwzu9.jpg",
      "id_str" : "700244647994593280",
      "id" : 700244647994593280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbfEzBuWEAAwzu9.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/4qX8jcgiXi"
    } ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 57, 68 ]
    }, {
      "text" : "auselt",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "esl",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "tesl",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "efl",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "tefl",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/1rQUQ3PMxt",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/11348664-real-rules-for-passives",
      "display_url" : "magic.piktochart.com\/output\/1134866\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700244858846502912",
  "text" : "Real Rules for Passives https:\/\/t.co\/1rQUQ3PMxt #ELTchat #eltchinwag #auselt #keltchat #esl #tesl #efl #tefl https:\/\/t.co\/4qX8jcgiXi",
  "id" : 700244858846502912,
  "created_at" : "2016-02-18 09:05:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 3, 17 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/QlRAVJDRaG",
      "expanded_url" : "https:\/\/twitter.com\/MrMoonUnity\/status\/700038675434967040",
      "display_url" : "twitter.com\/MrMoonUnity\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700226455276556288",
  "text" : "RT @englishbanana: Great diagram! https:\/\/t.co\/QlRAVJDRaG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/QlRAVJDRaG",
        "expanded_url" : "https:\/\/twitter.com\/MrMoonUnity\/status\/700038675434967040",
        "display_url" : "twitter.com\/MrMoonUnity\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700223335968456704",
    "text" : "Great diagram! https:\/\/t.co\/QlRAVJDRaG",
    "id" : 700223335968456704,
    "created_at" : "2016-02-18 07:40:27 +0000",
    "user" : {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "protected" : false,
      "id_str" : "1065987680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764226005410119680\/BvWYndUC_normal.jpg",
      "id" : 1065987680,
      "verified" : false
    }
  },
  "id" : 700226455276556288,
  "created_at" : "2016-02-18 07:52:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 0, 14 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700223335968456704",
  "geo" : { },
  "id_str" : "700224941803884544",
  "in_reply_to_user_id" : 1065987680,
  "text" : "@englishbanana does this mean we may be waiting to discover 2 more Shakespeares? Romance-Suicide-Supernatural; Suicide-Supernatural? : )",
  "id" : 700224941803884544,
  "in_reply_to_status_id" : 700223335968456704,
  "created_at" : "2016-02-18 07:46:50 +0000",
  "in_reply_to_screen_name" : "englishbanana",
  "in_reply_to_user_id_str" : "1065987680",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicki Blake",
      "screen_name" : "Penultimate_K",
      "indices" : [ 0, 14 ],
      "id_str" : "586596459",
      "id" : 586596459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700178070930468866",
  "geo" : { },
  "id_str" : "700218055511699456",
  "in_reply_to_user_id" : 586596459,
  "text" : "@Penultimate_K thanks : )",
  "id" : 700218055511699456,
  "in_reply_to_status_id" : 700178070930468866,
  "created_at" : "2016-02-18 07:19:28 +0000",
  "in_reply_to_screen_name" : "Penultimate_K",
  "in_reply_to_user_id_str" : "586596459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700120831872147456",
  "text" : "Enter the Dipthong #makeamovieTESL",
  "id" : 700120831872147456,
  "created_at" : "2016-02-18 00:53:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 14, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700120589034483713",
  "text" : "King Dipthong #makeamovieTESL",
  "id" : 700120589034483713,
  "created_at" : "2016-02-18 00:52:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700116725078106113",
  "text" : "Coursebook Back in Anger #makeamovieTESL",
  "id" : 700116725078106113,
  "created_at" : "2016-02-18 00:36:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700115442258616322",
  "text" : "Worksheet the Fockers #makeamovieTESL",
  "id" : 700115442258616322,
  "created_at" : "2016-02-18 00:31:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700114718816669700",
  "text" : "glottal sTop Gun #makeamovieTESL",
  "id" : 700114718816669700,
  "created_at" : "2016-02-18 00:28:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 21, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700113409342308353",
  "text" : "Headway Scissorhands #makeamovieTESL",
  "id" : 700113409342308353,
  "created_at" : "2016-02-18 00:23:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 14, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700112758109573120",
  "text" : "Eraserheadway #makeamovieTESL",
  "id" : 700112758109573120,
  "created_at" : "2016-02-18 00:21:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700112391447715840",
  "text" : "Wild at Phonemic Chart #makeamovieTESL",
  "id" : 700112391447715840,
  "created_at" : "2016-02-18 00:19:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700110934463922176",
  "text" : "Accent Horizon #makeamovieTESL",
  "id" : 700110934463922176,
  "created_at" : "2016-02-18 00:13:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 8, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700109491480719361",
  "text" : "Conunan #makeamovieTESL",
  "id" : 700109491480719361,
  "created_at" : "2016-02-18 00:08:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700108732223660034",
  "text" : "Look Who's Teacher Talking #makeamovieTESL",
  "id" : 700108732223660034,
  "created_at" : "2016-02-18 00:05:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700107791403524096",
  "text" : "Thinking Time Bandits #makeamovieTESL",
  "id" : 700107791403524096,
  "created_at" : "2016-02-18 00:01:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700101382611800064",
  "geo" : { },
  "id_str" : "700102723308490752",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan : )",
  "id" : 700102723308490752,
  "in_reply_to_status_id" : 700101382611800064,
  "created_at" : "2016-02-17 23:41:11 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 18, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700102482970681345",
  "text" : "Wordlists of Fury #makeamovieTESL",
  "id" : 700102482970681345,
  "created_at" : "2016-02-17 23:40:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700098920358264832",
  "text" : "Basic Intake #makeamovieTESL",
  "id" : 700098920358264832,
  "created_at" : "2016-02-17 23:26:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700096635976687616",
  "text" : "Schwa Wars #makeamovieTESL",
  "id" : 700096635976687616,
  "created_at" : "2016-02-17 23:16:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700076946277928960",
  "text" : "RT @pchallinor: I'm not really a grammar Nazi; more a flawed but conscience-stricken and devilishly handsome grammar Abwehr agent.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700076280511885313",
    "text" : "I'm not really a grammar Nazi; more a flawed but conscience-stricken and devilishly handsome grammar Abwehr agent.",
    "id" : 700076280511885313,
    "created_at" : "2016-02-17 21:56:06 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 700076946277928960,
  "created_at" : "2016-02-17 21:58:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 31, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700075014519963648",
  "text" : "Little Glottal Stop of Horrors #makeamovieTESL",
  "id" : 700075014519963648,
  "created_at" : "2016-02-17 21:51:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stock Photo Memes",
      "screen_name" : "StockPhotReacts",
      "indices" : [ 3, 19 ],
      "id_str" : "3394205602",
      "id" : 3394205602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/RsaWszdfZz",
      "expanded_url" : "http:\/\/twitter.com\/aspexit\/status\/689864320927338497\/photo\/1",
      "display_url" : "pic.twitter.com\/RsaWszdfZz"
    } ]
  },
  "geo" : { },
  "id_str" : "700069818381307905",
  "text" : "RT @StockPhotReacts: When your salad keeps making jokes https:\/\/t.co\/RsaWszdfZz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/RsaWszdfZz",
        "expanded_url" : "http:\/\/twitter.com\/aspexit\/status\/689864320927338497\/photo\/1",
        "display_url" : "pic.twitter.com\/RsaWszdfZz"
      } ]
    },
    "geo" : { },
    "id_str" : "695356408246611972",
    "text" : "When your salad keeps making jokes https:\/\/t.co\/RsaWszdfZz",
    "id" : 695356408246611972,
    "created_at" : "2016-02-04 21:21:01 +0000",
    "user" : {
      "name" : "Stock Photo Memes",
      "screen_name" : "StockPhotReacts",
      "protected" : false,
      "id_str" : "3394205602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676496806646272000\/k2hLF7zz_normal.jpg",
      "id" : 3394205602,
      "verified" : false
    }
  },
  "id" : 700069818381307905,
  "created_at" : "2016-02-17 21:30:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700057872487550976",
  "text" : "Pacific Skim\nCatch me if you Scan\n#makeamovieTESL",
  "id" : 700057872487550976,
  "created_at" : "2016-02-17 20:42:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700051138393956352",
  "geo" : { },
  "id_str" : "700055798530121732",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim yeah this one was a bit tricky doesn't work as well as other but another excuse for that gif : )",
  "id" : 700055798530121732,
  "in_reply_to_status_id" : 700051138393956352,
  "created_at" : "2016-02-17 20:34:43 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 0, 13 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "Chris O\u017C\u00F3g",
      "screen_name" : "ChrisOzog",
      "indices" : [ 14, 24 ],
      "id_str" : "79192243",
      "id" : 79192243
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 25, 41 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700048999517179904",
  "geo" : { },
  "id_str" : "700055513539674112",
  "in_reply_to_user_id" : 2814555865,
  "text" : "@carol_goodey @ChrisOzog @michaelegriffin The Graded Gun #makeamovieTESL",
  "id" : 700055513539674112,
  "in_reply_to_status_id" : 700048999517179904,
  "created_at" : "2016-02-17 20:33:35 +0000",
  "in_reply_to_screen_name" : "carol_goodey",
  "in_reply_to_user_id_str" : "2814555865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/700041403431284736\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/cJJnk1R5R7",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbcLMJaXEAE2npk.jpg",
      "id_str" : "700040570392219649",
      "id" : 700040570392219649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbcLMJaXEAE2npk.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/cJJnk1R5R7"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "auselt",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "esl",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "tefl",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "tesl",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/3twyX3QpA3",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/11330239-allegations-against-passives",
      "display_url" : "magic.piktochart.com\/output\/1133023\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700041403431284736",
  "text" : "Allegations against Passives https:\/\/t.co\/3twyX3QpA3 #eltchat #eltchinwag #auselt #keltchat #esl #tefl #tesl https:\/\/t.co\/cJJnk1R5R7",
  "id" : 700041403431284736,
  "created_at" : "2016-02-17 19:37:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 3, 17 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ck2Z663UFb",
      "expanded_url" : "https:\/\/chuffed.org\/project\/the-hands-up-project",
      "display_url" : "chuffed.org\/project\/the-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699994906287276032",
  "text" : "RT @nickbilbrough: I'm chuffed that I've finally got my crowdfunding project up and running. Please support it at....https:\/\/t.co\/ck2Z663UFb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/ck2Z663UFb",
        "expanded_url" : "https:\/\/chuffed.org\/project\/the-hands-up-project",
        "display_url" : "chuffed.org\/project\/the-ha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699992674481344517",
    "text" : "I'm chuffed that I've finally got my crowdfunding project up and running. Please support it at....https:\/\/t.co\/ck2Z663UFb",
    "id" : 699992674481344517,
    "created_at" : "2016-02-17 16:23:53 +0000",
    "user" : {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "protected" : false,
      "id_str" : "273391079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705302580944117760\/4q5JmOoa_normal.jpg",
      "id" : 273391079,
      "verified" : false
    }
  },
  "id" : 699994906287276032,
  "created_at" : "2016-02-17 16:32:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 20, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699993224698597376",
  "text" : "The Sound of Rubric #makeamovieTESL",
  "id" : 699993224698597376,
  "created_at" : "2016-02-17 16:26:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699977877366972416",
  "text" : "The ELFphant Man #makeamovieTESL",
  "id" : 699977877366972416,
  "created_at" : "2016-02-17 15:25:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699975518188367872",
  "text" : "Drop Dead Corpus #makeamovieTESL",
  "id" : 699975518188367872,
  "created_at" : "2016-02-17 15:15:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699972150246006784",
  "geo" : { },
  "id_str" : "699972610692685825",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 often wish a lesson bearing UFO would come to the rescue!",
  "id" : 699972610692685825,
  "in_reply_to_status_id" : 699972150246006784,
  "created_at" : "2016-02-17 15:04:09 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699971449726103553",
  "text" : "Honey I Chunk The Kids #makeamovieTESL",
  "id" : 699971449726103553,
  "created_at" : "2016-02-17 14:59:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699967665201410048",
  "text" : "The Sixth Tense #makeamovieTESL",
  "id" : 699967665201410048,
  "created_at" : "2016-02-17 14:44:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699966163514761216",
  "text" : "Transwarmers #makeamovieTESL",
  "id" : 699966163514761216,
  "created_at" : "2016-02-17 14:38:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699963176348184577",
  "text" : "Fluency on the Bounty #makeamovieTESL",
  "id" : 699963176348184577,
  "created_at" : "2016-02-17 14:26:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699962114115551232",
  "text" : "Good Drill Hunting #makeamovieTESL",
  "id" : 699962114115551232,
  "created_at" : "2016-02-17 14:22:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 3, 14 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MotionChart",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "splitinfinitive",
      "indices" : [ 61, 77 ]
    }, {
      "text" : "R",
      "indices" : [ 83, 85 ]
    }, {
      "text" : "googleVis",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LLRIQRtBjK",
      "expanded_url" : "http:\/\/rpubs.com\/gdlinguist\/153634",
      "display_url" : "rpubs.com\/gdlinguist\/153\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699908980164947968",
  "text" : "RT @gdlinguist: How to make a #MotionChart of Captain Kirk\u2019s #splitinfinitive with #R and #googleVis based on COHA https:\/\/t.co\/LLRIQRtBjK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MotionChart",
        "indices" : [ 14, 26 ]
      }, {
        "text" : "splitinfinitive",
        "indices" : [ 45, 61 ]
      }, {
        "text" : "R",
        "indices" : [ 67, 69 ]
      }, {
        "text" : "googleVis",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/LLRIQRtBjK",
        "expanded_url" : "http:\/\/rpubs.com\/gdlinguist\/153634",
        "display_url" : "rpubs.com\/gdlinguist\/153\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699882158689746944",
    "text" : "How to make a #MotionChart of Captain Kirk\u2019s #splitinfinitive with #R and #googleVis based on COHA https:\/\/t.co\/LLRIQRtBjK",
    "id" : 699882158689746944,
    "created_at" : "2016-02-17 09:04:44 +0000",
    "user" : {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "protected" : false,
      "id_str" : "4901184795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698131603168563200\/n6PZzu5f_normal.jpg",
      "id" : 4901184795,
      "verified" : false
    }
  },
  "id" : 699908980164947968,
  "created_at" : "2016-02-17 10:51:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699905823489814528",
  "geo" : { },
  "id_str" : "699906279192584192",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard hi Rose just check  #makeamovieTESL",
  "id" : 699906279192584192,
  "in_reply_to_status_id" : 699905823489814528,
  "created_at" : "2016-02-17 10:40:35 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/p5VXAl2WY5",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1891",
      "display_url" : "cass.lancs.ac.uk\/?p=1891"
    } ]
  },
  "geo" : { },
  "id_str" : "699905434065510400",
  "text" : "RT @CorpusSocialSci: Our Trinity Lancaster Corpus team are finding successful strategies that learners taking tests can use! Read more: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/p5VXAl2WY5",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1891",
        "display_url" : "cass.lancs.ac.uk\/?p=1891"
      } ]
    },
    "geo" : { },
    "id_str" : "699901025164066816",
    "text" : "Our Trinity Lancaster Corpus team are finding successful strategies that learners taking tests can use! Read more: https:\/\/t.co\/p5VXAl2WY5",
    "id" : 699901025164066816,
    "created_at" : "2016-02-17 10:19:42 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 699905434065510400,
  "created_at" : "2016-02-17 10:37:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 16, 26 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeamovieTESL",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699878372290199552",
  "geo" : { },
  "id_str" : "699879322421694464",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan @TEFLology hi Geoff it's the #makeamovieTESL ref Harmergeddon",
  "id" : 699879322421694464,
  "in_reply_to_status_id" : 699878372290199552,
  "created_at" : "2016-02-17 08:53:28 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 0, 10 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 19, 34 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699835190537916416",
  "geo" : { },
  "id_str" : "699849254655959040",
  "in_reply_to_user_id" : 2882870444,
  "text" : "@TEFLology one for @GeoffreyJordan : )",
  "id" : 699849254655959040,
  "in_reply_to_status_id" : 699835190537916416,
  "created_at" : "2016-02-17 06:53:59 +0000",
  "in_reply_to_screen_name" : "TEFLology",
  "in_reply_to_user_id_str" : "2882870444",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelenCaple",
      "screen_name" : "Medlec",
      "indices" : [ 0, 7 ],
      "id_str" : "312482361",
      "id" : 312482361
    }, {
      "name" : "Monika Bednarek",
      "screen_name" : "Corpusling",
      "indices" : [ 8, 19 ],
      "id_str" : "2208665992",
      "id" : 2208665992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/uoivsWyVo2",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/Nrd2KwKMoXu",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699645390153506816",
  "geo" : { },
  "id_str" : "699744364910743552",
  "in_reply_to_user_id" : 312482361,
  "text" : "@Medlec @Corpusling thx great resource, my very rapid review https:\/\/t.co\/uoivsWyVo2",
  "id" : 699744364910743552,
  "in_reply_to_status_id" : 699645390153506816,
  "created_at" : "2016-02-16 23:57:11 +0000",
  "in_reply_to_screen_name" : "Medlec",
  "in_reply_to_user_id_str" : "312482361",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DeadpoolMovie",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699707209605840898",
  "text" : "funniest opening credits seen in a while in #DeadpoolMovie : )",
  "id" : 699707209605840898,
  "created_at" : "2016-02-16 21:29:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Nelson",
      "screen_name" : "RyanJohnNelson",
      "indices" : [ 3, 18 ],
      "id_str" : "284183389",
      "id" : 284183389
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RyanJohnNelson\/status\/699540114876297218\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/AqeqxIJ68u",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVBjErXEAA1wMG.jpg",
      "id_str" : "699537387932815360",
      "id" : 699537387932815360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVBjErXEAA1wMG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/AqeqxIJ68u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699705902635610112",
  "text" : "RT @RyanJohnNelson: That Ferrero Rocher can rotate like gears is probably the most important thing I've learned today. https:\/\/t.co\/AqeqxIJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RyanJohnNelson\/status\/699540114876297218\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/AqeqxIJ68u",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVBjErXEAA1wMG.jpg",
        "id_str" : "699537387932815360",
        "id" : 699537387932815360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVBjErXEAA1wMG.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/AqeqxIJ68u"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699540114876297218",
    "text" : "That Ferrero Rocher can rotate like gears is probably the most important thing I've learned today. https:\/\/t.co\/AqeqxIJ68u",
    "id" : 699540114876297218,
    "created_at" : "2016-02-16 10:25:34 +0000",
    "user" : {
      "name" : "Ryan Nelson",
      "screen_name" : "RyanJohnNelson",
      "protected" : false,
      "id_str" : "284183389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755774011796287488\/B_HTAsW2_normal.jpg",
      "id" : 284183389,
      "verified" : false
    }
  },
  "id" : 699705902635610112,
  "created_at" : "2016-02-16 21:24:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/699701335550259200\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fvjJ8WkCFp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXWp_mWwAAQ7OO.png",
      "id_str" : "699701334061268992",
      "id" : 699701334061268992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXWp_mWwAAQ7OO.png",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fvjJ8WkCFp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/1BXSil5QAF",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "699701335550259200",
  "text" : "nice to see this user trend for https:\/\/t.co\/1BXSil5QAF though not reached heights of 2015 yet : ) https:\/\/t.co\/fvjJ8WkCFp",
  "id" : 699701335550259200,
  "created_at" : "2016-02-16 21:06:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 0, 15 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Z8MmMGwNv5",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=45195268",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699692749096935424",
  "geo" : { },
  "id_str" : "699700114827407360",
  "in_reply_to_user_id" : 501629829,
  "text" : "@ETprofessional i tend to slippery; irish seem to tend to slippy https:\/\/t.co\/Z8MmMGwNv5",
  "id" : 699700114827407360,
  "in_reply_to_status_id" : 699692749096935424,
  "created_at" : "2016-02-16 21:01:21 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 56, 72 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/UE1sWF2TVB",
      "expanded_url" : "http:\/\/hapgood.us\/2016\/02\/16\/amazon-oer-and-soundcloud\/",
      "display_url" : "hapgood.us\/2016\/02\/16\/ama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699691950409129984",
  "text" : "Amazon, OER, and\u00A0SoundCloud https:\/\/t.co\/UE1sWF2TVB via @wordpressdotcom",
  "id" : 699691950409129984,
  "created_at" : "2016-02-16 20:28:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699596762902712321",
  "geo" : { },
  "id_str" : "699690954907873280",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish you'll know next time Geoff fires up a blog or guest post : )",
  "id" : 699690954907873280,
  "in_reply_to_status_id" : 699596762902712321,
  "created_at" : "2016-02-16 20:24:57 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/5KHQIDtuqr",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/02\/not-just-piece-of-paper.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/02\/not-ju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699688152924102656",
  "text" : "RT @pchallinor: New mudgeonry: Not just a piece of paper https:\/\/t.co\/5KHQIDtuqr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/5KHQIDtuqr",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/02\/not-just-piece-of-paper.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/02\/not-ju\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699682827550531584",
    "text" : "New mudgeonry: Not just a piece of paper https:\/\/t.co\/5KHQIDtuqr",
    "id" : 699682827550531584,
    "created_at" : "2016-02-16 19:52:40 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 699688152924102656,
  "created_at" : "2016-02-16 20:13:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/699682326851231744\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/8Aucr0NCG6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbXFWPDW4AEz8e5.jpg",
      "id_str" : "699682302914387969",
      "id" : 699682302914387969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbXFWPDW4AEz8e5.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/8Aucr0NCG6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699681034946899968",
  "geo" : { },
  "id_str" : "699682326851231744",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim nice to hear thanks, some may say it was just an excuse to do this gif : ) https:\/\/t.co\/8Aucr0NCG6",
  "id" : 699682326851231744,
  "in_reply_to_status_id" : 699681034946899968,
  "created_at" : "2016-02-16 19:50:40 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699674291873431552",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim hi Hada thx for sharing types of passives : )",
  "id" : 699674291873431552,
  "created_at" : "2016-02-16 19:18:45 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Eisenstein",
      "screen_name" : "jacobeisenstein",
      "indices" : [ 3, 19 ],
      "id_str" : "102708234",
      "id" : 102708234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/PKWiEFAuM4",
      "expanded_url" : "http:\/\/arstechnica.co.uk\/security\/2016\/02\/the-nsas-skynet-program-may-be-killing-thousands-of-innocent-people\/",
      "display_url" : "arstechnica.co.uk\/security\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699674151989207040",
  "text" : "RT @jacobeisenstein: NSA's terrorist classifier: 80 features, nonlinear decision function, six positive labeled examples. https:\/\/t.co\/PKWi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/PKWiEFAuM4",
        "expanded_url" : "http:\/\/arstechnica.co.uk\/security\/2016\/02\/the-nsas-skynet-program-may-be-killing-thousands-of-innocent-people\/",
        "display_url" : "arstechnica.co.uk\/security\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699656702266908672",
    "text" : "NSA's terrorist classifier: 80 features, nonlinear decision function, six positive labeled examples. https:\/\/t.co\/PKWiEFAuM4",
    "id" : 699656702266908672,
    "created_at" : "2016-02-16 18:08:51 +0000",
    "user" : {
      "name" : "Jacob Eisenstein",
      "screen_name" : "jacobeisenstein",
      "protected" : false,
      "id_str" : "102708234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1587457408\/monkey_on_bike_normal.jpg",
      "id" : 102708234,
      "verified" : false
    }
  },
  "id" : 699674151989207040,
  "created_at" : "2016-02-16 19:18:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelenCaple",
      "screen_name" : "Medlec",
      "indices" : [ 3, 10 ],
      "id_str" : "312482361",
      "id" : 312482361
    }, {
      "name" : "Monika Bednarek",
      "screen_name" : "Corpusling",
      "indices" : [ 12, 23 ],
      "id_str" : "2208665992",
      "id" : 2208665992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/si7lJoloN1",
      "expanded_url" : "http:\/\/www.monikabednarek.com\/7.html",
      "display_url" : "monikabednarek.com\/7.html"
    } ]
  },
  "geo" : { },
  "id_str" : "699673009364340737",
  "text" : "RT @Medlec: @Corpusling just made me try out her new online #corpus ling resource. Very useful. Link to it from her website. https:\/\/t.co\/s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monika Bednarek",
        "screen_name" : "Corpusling",
        "indices" : [ 0, 11 ],
        "id_str" : "2208665992",
        "id" : 2208665992
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/si7lJoloN1",
        "expanded_url" : "http:\/\/www.monikabednarek.com\/7.html",
        "display_url" : "monikabednarek.com\/7.html"
      } ]
    },
    "geo" : { },
    "id_str" : "699645390153506816",
    "in_reply_to_user_id" : 2208665992,
    "text" : "@Corpusling just made me try out her new online #corpus ling resource. Very useful. Link to it from her website. https:\/\/t.co\/si7lJoloN1",
    "id" : 699645390153506816,
    "created_at" : "2016-02-16 17:23:54 +0000",
    "in_reply_to_screen_name" : "Corpusling",
    "in_reply_to_user_id_str" : "2208665992",
    "user" : {
      "name" : "HelenCaple",
      "screen_name" : "Medlec",
      "protected" : false,
      "id_str" : "312482361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000762232629\/48839c279d6a9d941939843793f0880e_normal.jpeg",
      "id" : 312482361,
      "verified" : false
    }
  },
  "id" : 699673009364340737,
  "created_at" : "2016-02-16 19:13:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 17, 28 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 29, 44 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699588199887167489",
  "geo" : { },
  "id_str" : "699589070717108224",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @leoselivan @GeoffreyJordan outside of big websites u manually archive ;)",
  "id" : 699589070717108224,
  "in_reply_to_status_id" : 699588199887167489,
  "created_at" : "2016-02-16 13:40:06 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Watson",
      "screen_name" : "SteveWatson10",
      "indices" : [ 89, 103 ],
      "id_str" : "135269213",
      "id" : 135269213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/iSKWx7rctJ",
      "expanded_url" : "http:\/\/wp.me\/p4x9Il-mv",
      "display_url" : "wp.me\/p4x9Il-mv"
    } ]
  },
  "geo" : { },
  "id_str" : "699575349970083840",
  "text" : "Educational innovation: debunking the public vs private myth https:\/\/t.co\/iSKWx7rctJ via @SteveWatson10",
  "id" : 699575349970083840,
  "created_at" : "2016-02-16 12:45:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 0, 13 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699548037279051776",
  "geo" : { },
  "id_str" : "699574088600256512",
  "in_reply_to_user_id" : 2248486418,
  "text" : "@ZhenyaDnipro hi yes that's the one. Yeah guess it may be useful for pd",
  "id" : 699574088600256512,
  "in_reply_to_status_id" : 699548037279051776,
  "created_at" : "2016-02-16 12:40:34 +0000",
  "in_reply_to_screen_name" : "ZhenyaDnipro",
  "in_reply_to_user_id_str" : "2248486418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/KuThe8nPdV",
      "expanded_url" : "http:\/\/literacyblog.blogspot.fr\/2016\/02\/the-ill-conceived-idea-of-regular-and.html",
      "display_url" : "literacyblog.blogspot.fr\/2016\/02\/the-il\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699544920990867456",
  "text" : "The ill-conceived idea of 'regular and 'irregular' spelling https:\/\/t.co\/KuThe8nPdV",
  "id" : 699544920990867456,
  "created_at" : "2016-02-16 10:44:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 0, 13 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699449896995266560",
  "geo" : { },
  "id_str" : "699542908622528512",
  "in_reply_to_user_id" : 2248486418,
  "text" : "@ZhenyaDnipro Harry Potter and the Methods of Rationality a fanfic which is very very good",
  "id" : 699542908622528512,
  "in_reply_to_status_id" : 699449896995266560,
  "created_at" : "2016-02-16 10:36:40 +0000",
  "in_reply_to_screen_name" : "ZhenyaDnipro",
  "in_reply_to_user_id_str" : "2248486418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/2mfw7I2zgQ",
      "expanded_url" : "http:\/\/disq.us\/97xx45",
      "display_url" : "disq.us\/97xx45"
    } ]
  },
  "geo" : { },
  "id_str" : "699484104404967424",
  "text" : "Everyone\u2019s offended these\u00A0days https:\/\/t.co\/2mfw7I2zgQ",
  "id" : 699484104404967424,
  "created_at" : "2016-02-16 06:43:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle East Eye",
      "screen_name" : "MiddleEastEye",
      "indices" : [ 88, 102 ],
      "id_str" : "2373735295",
      "id" : 2373735295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/jPLnJA9lQO",
      "expanded_url" : "https:\/\/shar.es\/14zrwE",
      "display_url" : "shar.es\/14zrwE"
    } ]
  },
  "geo" : { },
  "id_str" : "699354641184718848",
  "text" : "Saudi war for Yemen oil pipeline is empowering al-Qaeda, IS https:\/\/t.co\/jPLnJA9lQO via @MiddleEastEye",
  "id" : 699354641184718848,
  "created_at" : "2016-02-15 22:08:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Causey \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDE80",
      "screen_name" : "treycausey",
      "indices" : [ 3, 14 ],
      "id_str" : "237254045",
      "id" : 237254045
    }, {
      "name" : "Yanir Seroussi",
      "screen_name" : "yanirseroussi",
      "indices" : [ 143, 144 ],
      "id_str" : "3375193274",
      "id" : 3375193274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/l0GVfvSJaA",
      "expanded_url" : "http:\/\/wp.me\/p4grjq-nT",
      "display_url" : "wp.me\/p4grjq-nT"
    } ]
  },
  "geo" : { },
  "id_str" : "699330264909148160",
  "text" : "RT @treycausey: Why you should stop worrying about deep learning &amp; deepen your understanding of causality instead https:\/\/t.co\/l0GVfvSJaA v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yanir Seroussi",
        "screen_name" : "yanirseroussi",
        "indices" : [ 130, 144 ],
        "id_str" : "3375193274",
        "id" : 3375193274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/l0GVfvSJaA",
        "expanded_url" : "http:\/\/wp.me\/p4grjq-nT",
        "display_url" : "wp.me\/p4grjq-nT"
      } ]
    },
    "geo" : { },
    "id_str" : "699318688256622592",
    "text" : "Why you should stop worrying about deep learning &amp; deepen your understanding of causality instead https:\/\/t.co\/l0GVfvSJaA via @yanirseroussi",
    "id" : 699318688256622592,
    "created_at" : "2016-02-15 19:45:42 +0000",
    "user" : {
      "name" : "Trey Causey \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDE80",
      "screen_name" : "treycausey",
      "protected" : false,
      "id_str" : "237254045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765551721548361728\/PXzxVxij_normal.jpg",
      "id" : 237254045,
      "verified" : false
    }
  },
  "id" : 699330264909148160,
  "created_at" : "2016-02-15 20:31:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/699325763171045381\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/b7PqnXd9kx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbSAuZ6WwAEjADz.jpg",
      "id_str" : "699325376867254273",
      "id" : 699325376867254273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbSAuZ6WwAEjADz.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/b7PqnXd9kx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/uzE50CQUTd",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/11246858-types-of-passives",
      "display_url" : "magic.piktochart.com\/output\/1124685\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699325763171045381",
  "text" : "the receiver of the action?!! Pullum syas don't be a Jeremy Hunt - Types of Passives https:\/\/t.co\/uzE50CQUTd https:\/\/t.co\/b7PqnXd9kx",
  "id" : 699325763171045381,
  "created_at" : "2016-02-15 20:13:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699299635257413632",
  "geo" : { },
  "id_str" : "699325268784193537",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr okay thx : )",
  "id" : 699325268784193537,
  "in_reply_to_status_id" : 699299635257413632,
  "created_at" : "2016-02-15 20:11:51 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699295000824299520",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr hi commented on BootCat post but seem comment is stil stuck in moderation?",
  "id" : 699295000824299520,
  "created_at" : "2016-02-15 18:11:35 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699006978430017536",
  "geo" : { },
  "id_str" : "699282502943449089",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet hi thanks for sharing : )",
  "id" : 699282502943449089,
  "in_reply_to_status_id" : 699006978430017536,
  "created_at" : "2016-02-15 17:21:55 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 10, 20 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "BYU",
      "screen_name" : "BYU",
      "indices" : [ 21, 25 ],
      "id_str" : "17600950",
      "id" : 17600950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699133754246369280",
  "geo" : { },
  "id_str" : "699155131527467008",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap @RudyLoock @BYU that's a meta-genre no? : )",
  "id" : 699155131527467008,
  "in_reply_to_status_id" : 699133754246369280,
  "created_at" : "2016-02-15 08:55:47 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "BYU",
      "screen_name" : "BYU",
      "indices" : [ 70, 74 ],
      "id_str" : "17600950",
      "id" : 17600950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/699128840812105728\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8W6TQX8RuR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbPN9i7WcAAFqwN.jpg",
      "id_str" : "699128824404013056",
      "id" : 699128824404013056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbPN9i7WcAAFqwN.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/8W6TQX8RuR"
    } ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 15, 31 ]
    }, {
      "text" : "exciting",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/cCsgKUQqLu",
      "expanded_url" : "http:\/\/corpus.byu.edu\/upcoming.asp",
      "display_url" : "corpus.byu.edu\/upcoming.asp"
    } ]
  },
  "geo" : { },
  "id_str" : "699131777630261248",
  "text" : "RT @RudyLoock: #corpusresources: 2 new corpora and a new interface on @BYU website by May 2016!\nhttps:\/\/t.co\/cCsgKUQqLu #exciting https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BYU",
        "screen_name" : "BYU",
        "indices" : [ 55, 59 ],
        "id_str" : "17600950",
        "id" : 17600950
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/699128840812105728\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/8W6TQX8RuR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbPN9i7WcAAFqwN.jpg",
        "id_str" : "699128824404013056",
        "id" : 699128824404013056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbPN9i7WcAAFqwN.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/8W6TQX8RuR"
      } ],
      "hashtags" : [ {
        "text" : "corpusresources",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "exciting",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/cCsgKUQqLu",
        "expanded_url" : "http:\/\/corpus.byu.edu\/upcoming.asp",
        "display_url" : "corpus.byu.edu\/upcoming.asp"
      } ]
    },
    "geo" : { },
    "id_str" : "699128840812105728",
    "text" : "#corpusresources: 2 new corpora and a new interface on @BYU website by May 2016!\nhttps:\/\/t.co\/cCsgKUQqLu #exciting https:\/\/t.co\/8W6TQX8RuR",
    "id" : 699128840812105728,
    "created_at" : "2016-02-15 07:11:19 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 699131777630261248,
  "created_at" : "2016-02-15 07:22:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/K1oeNlX4ny",
      "expanded_url" : "https:\/\/alternativetransport.wordpress.com\/2015\/05\/05\/34\/",
      "display_url" : "alternativetransport.wordpress.com\/2015\/05\/05\/34\/"
    } ]
  },
  "in_reply_to_status_id_str" : "699072165157609472",
  "geo" : { },
  "id_str" : "699122779032047616",
  "in_reply_to_user_id" : 394987109,
  "text" : "@MattEllman @leoselivan there's an updated version here https:\/\/t.co\/K1oeNlX4ny",
  "id" : 699122779032047616,
  "in_reply_to_status_id" : 699072165157609472,
  "created_at" : "2016-02-15 06:47:14 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/BPZAI98jFi",
      "expanded_url" : "http:\/\/englishspeechservices.com\/words-of-the-week\/great-testes-of-america\/",
      "display_url" : "englishspeechservices.com\/words-of-the-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699009455715966976",
  "text" : "Great testes of America https:\/\/t.co\/BPZAI98jFi",
  "id" : 699009455715966976,
  "created_at" : "2016-02-14 23:16:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 42, 50 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "auselt",
      "indices" : [ 63, 70 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 71, 80 ]
    }, {
      "text" : "efl",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "tefl",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "elt",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "esl",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/uzE50CQUTd",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/11246858-types-of-passives",
      "display_url" : "magic.piktochart.com\/output\/1124685\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699006178882355200",
  "text" : "Types of Passives https:\/\/t.co\/uzE50CQUTd #ELTchat #eltchinwag #auselt #keltchat #efl #tefl #elt #esl",
  "id" : 699006178882355200,
  "created_at" : "2016-02-14 23:03:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suz",
      "screen_name" : "150phrasalverbs",
      "indices" : [ 0, 16 ],
      "id_str" : "4880840267",
      "id" : 4880840267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "695910233441443840",
  "geo" : { },
  "id_str" : "698972760048058369",
  "in_reply_to_user_id" : 4880840267,
  "text" : "@150phrasalverbs hi there you may find the PHaVE dictionary useful on your adventure : ) https:\/\/t.co\/feVV1F8lKr",
  "id" : 698972760048058369,
  "in_reply_to_status_id" : 695910233441443840,
  "created_at" : "2016-02-14 20:51:06 +0000",
  "in_reply_to_screen_name" : "150phrasalverbs",
  "in_reply_to_user_id_str" : "4880840267",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C-SPAN Video Library",
      "screen_name" : "cspanvl",
      "indices" : [ 71, 79 ],
      "id_str" : "62807483",
      "id" : 62807483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/nEKyEAFYQ3",
      "expanded_url" : "http:\/\/www.c-span.org\/video\/?324248-2\/russian-foreign-minister-lavrov-munich-security-conference",
      "display_url" : "c-span.org\/video\/?324248-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698925973744521216",
  "text" : "Watching Russian Foreign Minister Lavrov at Munich Security Conference @CSPANVL https:\/\/t.co\/nEKyEAFYQ3",
  "id" : 698925973744521216,
  "created_at" : "2016-02-14 17:45:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/uu5r1hfc9a",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/DMwWJbqL2Aa",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698921454696587266",
  "text" : "COCA search terms for clauses https:\/\/t.co\/uu5r1hfc9a",
  "id" : 698921454696587266,
  "created_at" : "2016-02-14 17:27:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 12, 26 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698869495574695937",
  "geo" : { },
  "id_str" : "698897964656414720",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga @Glenn_Hadikin seen Everyone says they\u2019re doing it but not many people really r &amp; those that r doing it r doing it very poorly",
  "id" : 698897964656414720,
  "in_reply_to_status_id" : 698869495574695937,
  "created_at" : "2016-02-14 15:53:54 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 3, 15 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 81, 88 ],
      "id_str" : "64643056",
      "id" : 64643056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ermSoYQRLV",
      "expanded_url" : "http:\/\/bit.ly\/1TcWnmb",
      "display_url" : "bit.ly\/1TcWnmb"
    } ]
  },
  "geo" : { },
  "id_str" : "698505562636607488",
  "text" : "RT @NeilClark66: Bombing Plagiarism - And why it\u2019s taking place- my latest piece @RT_com OpEdge #Syria  https:\/\/t.co\/ermSoYQRLV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RT",
        "screen_name" : "RT_com",
        "indices" : [ 64, 71 ],
        "id_str" : "64643056",
        "id" : 64643056
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 79, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ermSoYQRLV",
        "expanded_url" : "http:\/\/bit.ly\/1TcWnmb",
        "display_url" : "bit.ly\/1TcWnmb"
      } ]
    },
    "geo" : { },
    "id_str" : "698253291956936705",
    "text" : "Bombing Plagiarism - And why it\u2019s taking place- my latest piece @RT_com OpEdge #Syria  https:\/\/t.co\/ermSoYQRLV",
    "id" : 698253291956936705,
    "created_at" : "2016-02-12 21:12:12 +0000",
    "user" : {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "protected" : false,
      "id_str" : "728039605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451450991\/neil_clark_normal.png",
      "id" : 728039605,
      "verified" : false
    }
  },
  "id" : 698505562636607488,
  "created_at" : "2016-02-13 13:54:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698444125998288896",
  "geo" : { },
  "id_str" : "698445164721864704",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist great thxs :)",
  "id" : 698445164721864704,
  "in_reply_to_status_id" : 698444125998288896,
  "created_at" : "2016-02-13 09:54:38 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/7Zucy1IbXt",
      "expanded_url" : "http:\/\/wp.me\/p7186F-g9",
      "display_url" : "wp.me\/p7186F-g9"
    } ]
  },
  "geo" : { },
  "id_str" : "698444093282713600",
  "text" : "And the moral of the story is....? https:\/\/t.co\/7Zucy1IbXt via @wordpressdotcom",
  "id" : 698444093282713600,
  "created_at" : "2016-02-13 09:50:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698434732527370240",
  "geo" : { },
  "id_str" : "698443142270488576",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist  hi any chance u can detail how u extracted data?",
  "id" : 698443142270488576,
  "in_reply_to_status_id" : 698434732527370240,
  "created_at" : "2016-02-13 09:46:36 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 3, 14 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "splitinfinitive",
      "indices" : [ 42, 58 ]
    }, {
      "text" : "motionchart",
      "indices" : [ 103, 115 ]
    }, {
      "text" : "googlevis",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/PgkfxRoaIi",
      "expanded_url" : "http:\/\/www2.univ-paris8.fr\/desagulier\/home\/split_chart.html",
      "display_url" : "www2.univ-paris8.fr\/desagulier\/hom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698276829208145920",
  "text" : "RT @gdlinguist: Did Captain Kirk make the #splitinfinitive popular? Let us find out with a custom made #motionchart #googlevis https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "splitinfinitive",
        "indices" : [ 26, 42 ]
      }, {
        "text" : "motionchart",
        "indices" : [ 87, 99 ]
      }, {
        "text" : "googlevis",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/PgkfxRoaIi",
        "expanded_url" : "http:\/\/www2.univ-paris8.fr\/desagulier\/home\/split_chart.html",
        "display_url" : "www2.univ-paris8.fr\/desagulier\/hom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698274103594246144",
    "text" : "Did Captain Kirk make the #splitinfinitive popular? Let us find out with a custom made #motionchart #googlevis https:\/\/t.co\/PgkfxRoaIi",
    "id" : 698274103594246144,
    "created_at" : "2016-02-12 22:34:54 +0000",
    "user" : {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "protected" : false,
      "id_str" : "4901184795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698131603168563200\/n6PZzu5f_normal.jpg",
      "id" : 4901184795,
      "verified" : false
    }
  },
  "id" : 698276829208145920,
  "created_at" : "2016-02-12 22:45:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 17, 31 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 32, 44 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698218168314171394",
  "geo" : { },
  "id_str" : "698227723420966912",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @NicolaPrentis @TEFLCommute will look fwd to it : )",
  "id" : 698227723420966912,
  "in_reply_to_status_id" : 698218168314171394,
  "created_at" : "2016-02-12 19:30:36 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 3, 18 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 55, 64 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/UCRpYvChDM",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3327142-collocation-colligation#.VrxYA6duBZc.twitter",
      "display_url" : "magic.piktochart.com\/output\/3327142\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698197136983355392",
  "text" : "RT @LjiljanaHavran: Thanks for this useful infographic @muranava &gt;  Collocation-colligation https:\/\/t.co\/UCRpYvChDM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 35, 44 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/UCRpYvChDM",
        "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3327142-collocation-colligation#.VrxYA6duBZc.twitter",
        "display_url" : "magic.piktochart.com\/output\/3327142\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697720073373552640",
    "text" : "Thanks for this useful infographic @muranava &gt;  Collocation-colligation https:\/\/t.co\/UCRpYvChDM",
    "id" : 697720073373552640,
    "created_at" : "2016-02-11 09:53:23 +0000",
    "user" : {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "protected" : false,
      "id_str" : "1395825290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729054439496159232\/58roonKM_normal.jpg",
      "id" : 1395825290,
      "verified" : false
    }
  },
  "id" : 698197136983355392,
  "created_at" : "2016-02-12 17:29:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697723032090058753",
  "geo" : { },
  "id_str" : "698196807441129472",
  "in_reply_to_user_id" : 3083991707,
  "text" : "@linkstoenglish hi thx for the HT : )",
  "id" : 698196807441129472,
  "in_reply_to_status_id" : 697723032090058753,
  "created_at" : "2016-02-12 17:27:45 +0000",
  "in_reply_to_screen_name" : "linkstoenglish",
  "in_reply_to_user_id_str" : "3083991707",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697942784469237764",
  "geo" : { },
  "id_str" : "698118592794136576",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp ok thanks will look out for it",
  "id" : 698118592794136576,
  "in_reply_to_status_id" : 697942784469237764,
  "created_at" : "2016-02-12 12:16:57 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697893159926435842",
  "geo" : { },
  "id_str" : "697894520420179969",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn with increasing open source stuff out there i think some tinkering is worthwhile",
  "id" : 697894520420179969,
  "in_reply_to_status_id" : 697893159926435842,
  "created_at" : "2016-02-11 21:26:34 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/0XPORdiSwd",
      "expanded_url" : "http:\/\/www.bloomberg.com\/graphics\/2016-who-marries-whom\/",
      "display_url" : "bloomberg.com\/graphics\/2016-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697893371247988736",
  "text" : "This Chart Shows Who Marries CEOs, Doctors, Chefs, and Janitors https:\/\/t.co\/0XPORdiSwd",
  "id" : 697893371247988736,
  "created_at" : "2016-02-11 21:22:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ykp1l2Mzdr",
      "expanded_url" : "http:\/\/www.cbc.ca\/1.3443697",
      "display_url" : "cbc.ca\/1.3443697"
    } ]
  },
  "geo" : { },
  "id_str" : "697889709062823936",
  "text" : "Gravitational waves discovery 'opening a window on the universe' https:\/\/t.co\/ykp1l2Mzdr",
  "id" : 697889709062823936,
  "created_at" : "2016-02-11 21:07:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/lDLVP1JZG3",
      "expanded_url" : "http:\/\/www.clearerthinking.org\/#!This-comic-shows-how-selfdriving-cars-may-face-complicated-moral-issues\/c1toj\/56b9185e0cf2dc1600ea461e",
      "display_url" : "clearerthinking.org\/#!This-comic-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697888484221194242",
  "text" : "This comic shows how self-driving cars may face complicated moral issues\n https:\/\/t.co\/lDLVP1JZG3",
  "id" : 697888484221194242,
  "created_at" : "2016-02-11 21:02:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 3, 14 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 131, 140 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Padlet",
      "indices" : [ 16, 23 ]
    }, {
      "text" : "CorpusLinguistics",
      "indices" : [ 43, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/YRvaFNiZeQ",
      "expanded_url" : "http:\/\/padlet.com\/john_x_williams\/y7v657kn6p3o",
      "display_url" : "padlet.com\/john_x_william\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697883339697582080",
  "text" : "RT @lexicoj0hn: #Padlet with my notes from #CorpusLinguistics &amp; Statistics event @ UoBham, 11\/02\/16 https:\/\/t.co\/YRvaFNiZeQ  . @antlabjp ex\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laurence Anthony",
        "screen_name" : "antlabjp",
        "indices" : [ 115, 124 ],
        "id_str" : "167020390",
        "id" : 167020390
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Padlet",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "CorpusLinguistics",
        "indices" : [ 27, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/YRvaFNiZeQ",
        "expanded_url" : "http:\/\/padlet.com\/john_x_williams\/y7v657kn6p3o",
        "display_url" : "padlet.com\/john_x_william\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697877518318235648",
    "text" : "#Padlet with my notes from #CorpusLinguistics &amp; Statistics event @ UoBham, 11\/02\/16 https:\/\/t.co\/YRvaFNiZeQ  . @antlabjp excellent as ever.",
    "id" : 697877518318235648,
    "created_at" : "2016-02-11 20:19:00 +0000",
    "user" : {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "protected" : false,
      "id_str" : "4008981801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710135773476032516\/BNqiKR1y_normal.jpg",
      "id" : 4008981801,
      "verified" : false
    }
  },
  "id" : 697883339697582080,
  "created_at" : "2016-02-11 20:42:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697879457709821952",
  "geo" : { },
  "id_str" : "697879748769398784",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague hi Kamila thanks was aware of Merlin project but not checked it in a while so thanks for this :)",
  "id" : 697879748769398784,
  "in_reply_to_status_id" : 697879457709821952,
  "created_at" : "2016-02-11 20:27:52 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 12, 21 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697877518318235648",
  "geo" : { },
  "id_str" : "697879035204997121",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn @antlabjp was a middle way mentioned e.g. tinkering with other people's code?",
  "id" : 697879035204997121,
  "in_reply_to_status_id" : 697877518318235648,
  "created_at" : "2016-02-11 20:25:02 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697720073373552640",
  "geo" : { },
  "id_str" : "697720585674219520",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran nice to hear it is useful thx : )",
  "id" : 697720585674219520,
  "in_reply_to_status_id" : 697720073373552640,
  "created_at" : "2016-02-11 09:55:25 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 13, 28 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697719564562472960",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr @LjiljanaHavran many thanks for RTing CL news post  : )",
  "id" : 697719564562472960,
  "created_at" : "2016-02-11 09:51:21 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697717409831133186",
  "geo" : { },
  "id_str" : "697718849907646464",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis i know the feeling &amp; this is well done venn diagram (others take note) is illuminating",
  "id" : 697718849907646464,
  "in_reply_to_status_id" : 697717409831133186,
  "created_at" : "2016-02-11 09:48:31 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/697716786347827201\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/4LKKvfYflF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca7Jq87WAAA8IFq.png",
      "id_str" : "697716732035727360",
      "id" : 697716732035727360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca7Jq87WAAA8IFq.png",
      "sizes" : [ {
        "h" : 347,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 509
      } ],
      "display_url" : "pic.twitter.com\/4LKKvfYflF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/BY0ZHC3ARk",
      "expanded_url" : "http:\/\/theweek.com\/articles\/465818\/handy-guide-homophones-homonyms-homographs",
      "display_url" : "theweek.com\/articles\/46581\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697716786347827201",
  "text" : "hi @NicolaPrentis have you seen this article on homophones, nyms &amp; graphs? https:\/\/t.co\/BY0ZHC3ARk https:\/\/t.co\/4LKKvfYflF",
  "id" : 697716786347827201,
  "created_at" : "2016-02-11 09:40:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/3QVGVPRmPj",
      "expanded_url" : "http:\/\/sci-hub.io\/",
      "display_url" : "sci-hub.io"
    } ]
  },
  "geo" : { },
  "id_str" : "697697384881483776",
  "text" : "oh https:\/\/t.co\/3QVGVPRmPj live long &amp; prosper till all papers are free",
  "id" : 697697384881483776,
  "created_at" : "2016-02-11 08:23:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 3, 15 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 17, 26 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/o5ifSwSZG2",
      "expanded_url" : "http:\/\/inmyownterms.com\/recommended-free-courses-and-other-useful-information\/",
      "display_url" : "inmyownterms.com\/recommended-fr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697685605384323072",
  "text" : "RT @patriciambr: @muranava My blog post on courses and useful information in which i mention your latest news on CL https:\/\/t.co\/o5ifSwSZG2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/o5ifSwSZG2",
        "expanded_url" : "http:\/\/inmyownterms.com\/recommended-free-courses-and-other-useful-information\/",
        "display_url" : "inmyownterms.com\/recommended-fr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697620674337120257",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava My blog post on courses and useful information in which i mention your latest news on CL https:\/\/t.co\/o5ifSwSZG2",
    "id" : 697620674337120257,
    "created_at" : "2016-02-11 03:18:24 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "protected" : false,
      "id_str" : "35764443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540310171541438464\/YprBqoGt_normal.jpeg",
      "id" : 35764443,
      "verified" : false
    }
  },
  "id" : 697685605384323072,
  "created_at" : "2016-02-11 07:36:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697445717313511424",
  "geo" : { },
  "id_str" : "697453307539951616",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp good luck! will the slides be available after?",
  "id" : 697453307539951616,
  "in_reply_to_status_id" : 697445717313511424,
  "created_at" : "2016-02-10 16:13:21 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 0, 11 ],
      "id_str" : "281361233",
      "id" : 281361233
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 12, 24 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697440295315701760",
  "in_reply_to_user_id" : 281361233,
  "text" : "@i_narrator @ELTResearch thanks for the RTs : )",
  "id" : 697440295315701760,
  "created_at" : "2016-02-10 15:21:38 +0000",
  "in_reply_to_screen_name" : "i_narrator",
  "in_reply_to_user_id_str" : "281361233",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 0, 9 ],
      "id_str" : "6257282",
      "id" : 6257282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697439517406584833",
  "geo" : { },
  "id_str" : "697440113995997184",
  "in_reply_to_user_id" : 6257282,
  "text" : "@trieloff with a mouse mat bat? : )",
  "id" : 697440113995997184,
  "in_reply_to_status_id" : 697439517406584833,
  "created_at" : "2016-02-10 15:20:55 +0000",
  "in_reply_to_screen_name" : "trieloff",
  "in_reply_to_user_id_str" : "6257282",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 7, 17 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 18, 34 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697401692741095424",
  "text" : "thanks @nakanotim @MichaelChesnut2 for the RT and like, hope your week is going well",
  "id" : 697401692741095424,
  "created_at" : "2016-02-10 12:48:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Pasquale",
      "screen_name" : "FrankPasquale",
      "indices" : [ 3, 17 ],
      "id_str" : "371017223",
      "id" : 371017223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/v7HnPtlgZO",
      "expanded_url" : "http:\/\/blog.p2pfoundation.net\/how-silicon-valley-elites-are-driving-california-to-a-new-feudalism\/2013\/10\/28",
      "display_url" : "blog.p2pfoundation.net\/how-silicon-va\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697401415489212416",
  "text" : "RT @FrankPasquale: A handful of companies \"dominate an information economy that is increasingly oligopolistic\u201D https:\/\/t.co\/v7HnPtlgZO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/v7HnPtlgZO",
        "expanded_url" : "http:\/\/blog.p2pfoundation.net\/how-silicon-valley-elites-are-driving-california-to-a-new-feudalism\/2013\/10\/28",
        "display_url" : "blog.p2pfoundation.net\/how-silicon-va\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697397619048505344",
    "text" : "A handful of companies \"dominate an information economy that is increasingly oligopolistic\u201D https:\/\/t.co\/v7HnPtlgZO",
    "id" : 697397619048505344,
    "created_at" : "2016-02-10 12:32:04 +0000",
    "user" : {
      "name" : "Frank Pasquale",
      "screen_name" : "FrankPasquale",
      "protected" : false,
      "id_str" : "371017223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1536587347\/Dove__2__normal.jpg",
      "id" : 371017223,
      "verified" : false
    }
  },
  "id" : 697401415489212416,
  "created_at" : "2016-02-10 12:47:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/iJcFSQjdn9",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/02\/10\/corpus-linguistics-community-news-6\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/02\/10\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697397105850101761",
  "text" : "Corpus linguistics community news 6 https:\/\/t.co\/iJcFSQjdn9",
  "id" : 697397105850101761,
  "created_at" : "2016-02-10 12:30:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697378773747036160",
  "geo" : { },
  "id_str" : "697382188774465536",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur good idea, might try to work it with piratebox chat feature",
  "id" : 697382188774465536,
  "in_reply_to_status_id" : 697378773747036160,
  "created_at" : "2016-02-10 11:30:45 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Ingold",
      "screen_name" : "RichardIngold",
      "indices" : [ 3, 17 ],
      "id_str" : "2561140580",
      "id" : 2561140580
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "ELT",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "EAP",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8Xcbya0tLB",
      "expanded_url" : "https:\/\/twitter.com\/annabellelukin\/status\/697306588307021824",
      "display_url" : "twitter.com\/annabellelukin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697380661737422848",
  "text" : "RT @RichardIngold: One of the best explanations of nominalisation I've ever read. #AusELT #TESOL #ELT #EAP  https:\/\/t.co\/8Xcbya0tLB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AusELT",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 71, 77 ]
      }, {
        "text" : "ELT",
        "indices" : [ 78, 82 ]
      }, {
        "text" : "EAP",
        "indices" : [ 83, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/8Xcbya0tLB",
        "expanded_url" : "https:\/\/twitter.com\/annabellelukin\/status\/697306588307021824",
        "display_url" : "twitter.com\/annabellelukin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697333402748321792",
    "text" : "One of the best explanations of nominalisation I've ever read. #AusELT #TESOL #ELT #EAP  https:\/\/t.co\/8Xcbya0tLB",
    "id" : 697333402748321792,
    "created_at" : "2016-02-10 08:16:53 +0000",
    "user" : {
      "name" : "Richard Ingold",
      "screen_name" : "RichardIngold",
      "protected" : false,
      "id_str" : "2561140580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696892637639389184\/eJUne2Nh_normal.jpg",
      "id" : 2561140580,
      "verified" : false
    }
  },
  "id" : 697380661737422848,
  "created_at" : "2016-02-10 11:24:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697192964431417344",
  "geo" : { },
  "id_str" : "697347226008481792",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur yr welcome using a backchannel watching a vid is an interesting idea",
  "id" : 697347226008481792,
  "in_reply_to_status_id" : 697192964431417344,
  "created_at" : "2016-02-10 09:11:49 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 3, 10 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EdLaur\/status\/697187004027527169\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/TYb037mMOE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cazn4pUUcAE4dmq.jpg",
      "id_str" : "697187002685353985",
      "id" : 697187002685353985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cazn4pUUcAE4dmq.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/TYb037mMOE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/ql9UWK0oTH",
      "expanded_url" : "http:\/\/grownupenglish.com\/using-chat-tools-in-face-to-face-elt\/",
      "display_url" : "grownupenglish.com\/using-chat-too\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697189920004300800",
  "text" : "RT @EdLaur: Why I\u2019m using Chat tools in face-to-face\u00A0ELT https:\/\/t.co\/ql9UWK0oTH https:\/\/t.co\/TYb037mMOE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EdLaur\/status\/697187004027527169\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/TYb037mMOE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cazn4pUUcAE4dmq.jpg",
        "id_str" : "697187002685353985",
        "id" : 697187002685353985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cazn4pUUcAE4dmq.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/TYb037mMOE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/ql9UWK0oTH",
        "expanded_url" : "http:\/\/grownupenglish.com\/using-chat-tools-in-face-to-face-elt\/",
        "display_url" : "grownupenglish.com\/using-chat-too\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697187004027527169",
    "text" : "Why I\u2019m using Chat tools in face-to-face\u00A0ELT https:\/\/t.co\/ql9UWK0oTH https:\/\/t.co\/TYb037mMOE",
    "id" : 697187004027527169,
    "created_at" : "2016-02-09 22:35:09 +0000",
    "user" : {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "protected" : false,
      "id_str" : "1834826917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440196993265053696\/AW_iOVA2_normal.jpeg",
      "id" : 1834826917,
      "verified" : false
    }
  },
  "id" : 697189920004300800,
  "created_at" : "2016-02-09 22:46:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/697157364286414849\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/OB5RiCftgk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CazM7ZFW4AAGOvo.jpg",
      "id_str" : "697157363053289472",
      "id" : 697157363053289472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CazM7ZFW4AAGOvo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 807,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 807,
        "resize" : "fit",
        "w" : 605
      } ],
      "display_url" : "pic.twitter.com\/OB5RiCftgk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697157364286414849",
  "text" : "in case you missed it here is the most popular sink amongst people i imagine to follow https:\/\/t.co\/OB5RiCftgk",
  "id" : 697157364286414849,
  "created_at" : "2016-02-09 20:37:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/BIj7LuEo6r",
      "expanded_url" : "https:\/\/medium.com\/identity-education-and-power\/identity-power-and-education-s-algorithms-a766527bb6cd#.7zqkn4fep",
      "display_url" : "medium.com\/identity-educa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697132799875227649",
  "text" : "RT @audreywatters: Identity, Power, and Education\u2019s Algorithms https:\/\/t.co\/BIj7LuEo6r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/BIj7LuEo6r",
        "expanded_url" : "https:\/\/medium.com\/identity-education-and-power\/identity-power-and-education-s-algorithms-a766527bb6cd#.7zqkn4fep",
        "display_url" : "medium.com\/identity-educa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697131093078585344",
    "text" : "Identity, Power, and Education\u2019s Algorithms https:\/\/t.co\/BIj7LuEo6r",
    "id" : 697131093078585344,
    "created_at" : "2016-02-09 18:52:59 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 697132799875227649,
  "created_at" : "2016-02-09 18:59:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 3, 15 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/paul_sensei\/status\/696674538587713537\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XP978KE00a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CasVzPrUsAE_6Gc.png",
      "id_str" : "696674537484627969",
      "id" : 696674537484627969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CasVzPrUsAE_6Gc.png",
      "sizes" : [ {
        "h" : 1062,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 1062,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XP978KE00a"
    } ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "flteach",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "efl",
      "indices" : [ 117, 121 ]
    }, {
      "text" : "tesl",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "esl",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/CA3tQ1Vlqz",
      "expanded_url" : "http:\/\/mangamaker.apps4efl.com",
      "display_url" : "mangamaker.apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "697129564477222912",
  "text" : "RT @paul_sensei: Easily make engaging manga-style dialogues with https:\/\/t.co\/CA3tQ1Vlqz #langchat #flteach #eltchat #efl #tesl #esl https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/paul_sensei\/status\/696674538587713537\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/XP978KE00a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CasVzPrUsAE_6Gc.png",
        "id_str" : "696674537484627969",
        "id" : 696674537484627969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CasVzPrUsAE_6Gc.png",
        "sizes" : [ {
          "h" : 1062,
          "resize" : "fit",
          "w" : 755
        }, {
          "h" : 1062,
          "resize" : "fit",
          "w" : 755
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 844,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XP978KE00a"
      } ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 72, 81 ]
      }, {
        "text" : "flteach",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 91, 99 ]
      }, {
        "text" : "efl",
        "indices" : [ 100, 104 ]
      }, {
        "text" : "tesl",
        "indices" : [ 105, 110 ]
      }, {
        "text" : "esl",
        "indices" : [ 111, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/CA3tQ1Vlqz",
        "expanded_url" : "http:\/\/mangamaker.apps4efl.com",
        "display_url" : "mangamaker.apps4efl.com"
      } ]
    },
    "geo" : { },
    "id_str" : "696674538587713537",
    "text" : "Easily make engaging manga-style dialogues with https:\/\/t.co\/CA3tQ1Vlqz #langchat #flteach #eltchat #efl #tesl #esl https:\/\/t.co\/XP978KE00a",
    "id" : 696674538587713537,
    "created_at" : "2016-02-08 12:38:48 +0000",
    "user" : {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "protected" : false,
      "id_str" : "176429301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666950419248259073\/T7XVTUac_normal.jpg",
      "id" : 176429301,
      "verified" : false
    }
  },
  "id" : 697129564477222912,
  "created_at" : "2016-02-09 18:46:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danah boyd",
      "screen_name" : "zephoria",
      "indices" : [ 39, 48 ],
      "id_str" : "633",
      "id" : 633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/a7g5peAYEx",
      "expanded_url" : "https:\/\/points.datasociety.net\/it-s-not-cyberspace-anymore-55c659025e97#.luz0vrlif",
      "display_url" : "points.datasociety.net\/it-s-not-cyber\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697124787311742976",
  "text" : "A Big Dose of AI-induced Hype and Fear @zephoria https:\/\/t.co\/a7g5peAYEx",
  "id" : 697124787311742976,
  "created_at" : "2016-02-09 18:27:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "indices" : [ 3, 11 ],
      "id_str" : "6146692",
      "id" : 6146692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/HRsw5aiV6K",
      "expanded_url" : "http:\/\/kaylinwalker.com\/text-mining-south-park\/",
      "display_url" : "kaylinwalker.com\/text-mining-so\u2026"
    }, {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/xlId7ALFAX",
      "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/697048007469039617",
      "display_url" : "twitter.com\/randal_olson\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697120603648745472",
  "text" : "RT @arnicas: Source: https:\/\/t.co\/HRsw5aiV6K https:\/\/t.co\/xlId7ALFAX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/HRsw5aiV6K",
        "expanded_url" : "http:\/\/kaylinwalker.com\/text-mining-south-park\/",
        "display_url" : "kaylinwalker.com\/text-mining-so\u2026"
      }, {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/xlId7ALFAX",
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/697048007469039617",
        "display_url" : "twitter.com\/randal_olson\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697059902699601922",
    "text" : "Source: https:\/\/t.co\/HRsw5aiV6K https:\/\/t.co\/xlId7ALFAX",
    "id" : 697059902699601922,
    "created_at" : "2016-02-09 14:10:06 +0000",
    "user" : {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "protected" : false,
      "id_str" : "6146692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53142956\/Saw-whet_Owl_10_normal.jpg",
      "id" : 6146692,
      "verified" : false
    }
  },
  "id" : 697120603648745472,
  "created_at" : "2016-02-09 18:11:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophie O'Rourke",
      "screen_name" : "sophie_orourke",
      "indices" : [ 0, 15 ],
      "id_str" : "249649115",
      "id" : 249649115
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 16, 23 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Beyonce",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697027413872668672",
  "geo" : { },
  "id_str" : "697036953276043264",
  "in_reply_to_user_id" : 249649115,
  "text" : "@sophie_orourke @eltjam I don't think #Beyonce would be impressed by the coordination of that Venn diagram formation : )",
  "id" : 697036953276043264,
  "in_reply_to_status_id" : 697027413872668672,
  "created_at" : "2016-02-09 12:38:54 +0000",
  "in_reply_to_screen_name" : "sophie_orourke",
  "in_reply_to_user_id_str" : "249649115",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 0, 7 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Sophie O'Rourke",
      "screen_name" : "sophie_orourke",
      "indices" : [ 8, 23 ],
      "id_str" : "249649115",
      "id" : 249649115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697011179605069824",
  "geo" : { },
  "id_str" : "697019093212360705",
  "in_reply_to_user_id" : 1356363686,
  "text" : "@eltjam @sophie_orourke shame about the impossible 4 circle venn diagram ; )",
  "id" : 697019093212360705,
  "in_reply_to_status_id" : 697011179605069824,
  "created_at" : "2016-02-09 11:27:56 +0000",
  "in_reply_to_screen_name" : "eltjam",
  "in_reply_to_user_id_str" : "1356363686",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Kohn",
      "screen_name" : "sallykohn",
      "indices" : [ 3, 13 ],
      "id_str" : "18978610",
      "id" : 18978610
    }, {
      "name" : "Awesomely Luvvie",
      "screen_name" : "Luvvie",
      "indices" : [ 68, 75 ],
      "id_str" : "16254381",
      "id" : 16254381
    }, {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 79, 87 ],
      "id_str" : "31239408",
      "id" : 31239408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Formation",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XCQTAYRoKI",
      "expanded_url" : "http:\/\/www.awesomelyluvvie.com\/2016\/02\/beyonce-formation.html",
      "display_url" : "awesomelyluvvie.com\/2016\/02\/beyonc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696779410473623552",
  "text" : "RT @sallykohn: \"Her field of f*cks is barren\" \u2014 If you haven't read @Luvvie on @Beyonce's #Formation video, you're doing it wrong.  https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Awesomely Luvvie",
        "screen_name" : "Luvvie",
        "indices" : [ 53, 60 ],
        "id_str" : "16254381",
        "id" : 16254381
      }, {
        "name" : "BEYONC\u00C9",
        "screen_name" : "Beyonce",
        "indices" : [ 64, 72 ],
        "id_str" : "31239408",
        "id" : 31239408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Formation",
        "indices" : [ 75, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XCQTAYRoKI",
        "expanded_url" : "http:\/\/www.awesomelyluvvie.com\/2016\/02\/beyonce-formation.html",
        "display_url" : "awesomelyluvvie.com\/2016\/02\/beyonc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "696711735206670337",
    "text" : "\"Her field of f*cks is barren\" \u2014 If you haven't read @Luvvie on @Beyonce's #Formation video, you're doing it wrong.  https:\/\/t.co\/XCQTAYRoKI",
    "id" : 696711735206670337,
    "created_at" : "2016-02-08 15:06:36 +0000",
    "user" : {
      "name" : "Sally Kohn",
      "screen_name" : "sallykohn",
      "protected" : false,
      "id_str" : "18978610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743038494725918721\/gPViRCLD_normal.jpg",
      "id" : 18978610,
      "verified" : true
    }
  },
  "id" : 696779410473623552,
  "created_at" : "2016-02-08 19:35:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696756713127546880",
  "geo" : { },
  "id_str" : "696759673806917632",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark wonder if google has machine learning to avoid paying its taxes?",
  "id" : 696759673806917632,
  "in_reply_to_status_id" : 696756713127546880,
  "created_at" : "2016-02-08 18:17:06 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696745234915532800",
  "geo" : { },
  "id_str" : "696752811938336768",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne hi the solyant dick vid seems borked?",
  "id" : 696752811938336768,
  "in_reply_to_status_id" : 696745234915532800,
  "created_at" : "2016-02-08 17:49:50 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/gLp2aj0uzi",
      "expanded_url" : "http:\/\/motherboard.vice.com\/read\/inside-the-stupid-shit-no-one-needs-terrible-ideas-hackathon",
      "display_url" : "motherboard.vice.com\/read\/inside-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696748946157395968",
  "text" : "RT @sam_lavigne: Inside the Stupid Shit No One Needs &amp; Terrible Ideas Hackathon | Motherboard https:\/\/t.co\/gLp2aj0uzi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/gLp2aj0uzi",
        "expanded_url" : "http:\/\/motherboard.vice.com\/read\/inside-the-stupid-shit-no-one-needs-terrible-ideas-hackathon",
        "display_url" : "motherboard.vice.com\/read\/inside-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "696745234915532800",
    "text" : "Inside the Stupid Shit No One Needs &amp; Terrible Ideas Hackathon | Motherboard https:\/\/t.co\/gLp2aj0uzi",
    "id" : 696745234915532800,
    "created_at" : "2016-02-08 17:19:43 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 696748946157395968,
  "created_at" : "2016-02-08 17:34:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/6G7MXblHWp",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=R0WDCYcUJ4o",
      "display_url" : "youtube.com\/watch?v=R0WDCY\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "696375690795577344",
  "geo" : { },
  "id_str" : "696379068887994368",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth this lady sure knows about special places in hell https:\/\/t.co\/6G7MXblHWp",
  "id" : 696379068887994368,
  "in_reply_to_status_id" : 696375690795577344,
  "created_at" : "2016-02-07 17:04:42 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viktor Klang",
      "screen_name" : "viktorklang",
      "indices" : [ 3, 15 ],
      "id_str" : "52061552",
      "id" : 52061552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696268149289832448",
  "text" : "RT @viktorklang: The Machine Learning will continue until revenue improves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696020872428187648",
    "text" : "The Machine Learning will continue until revenue improves.",
    "id" : 696020872428187648,
    "created_at" : "2016-02-06 17:21:22 +0000",
    "user" : {
      "name" : "Viktor Klang",
      "screen_name" : "viktorklang",
      "protected" : false,
      "id_str" : "52061552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601510347497836544\/irhBO-bs_normal.png",
      "id" : 52061552,
      "verified" : false
    }
  },
  "id" : 696268149289832448,
  "created_at" : "2016-02-07 09:43:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Zirin",
      "screen_name" : "EdgeofSports",
      "indices" : [ 3, 16 ],
      "id_str" : "50684256",
      "id" : 50684256
    }, {
      "name" : "Dave Zirin",
      "screen_name" : "EdgeofSports",
      "indices" : [ 40, 53 ],
      "id_str" : "50684256",
      "id" : 50684256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/1vDw4oLllB",
      "expanded_url" : "https:\/\/soundcloud.com\/edgeofsports\/chomskybowl",
      "display_url" : "soundcloud.com\/edgeofsports\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695991987753893889",
  "text" : "RT @EdgeofSports: It's here! The latest @EdgeofSports Podcast featuring the first ever full-length sports interview with Noam Chomsky! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave Zirin",
        "screen_name" : "EdgeofSports",
        "indices" : [ 22, 35 ],
        "id_str" : "50684256",
        "id" : 50684256
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1vDw4oLllB",
        "expanded_url" : "https:\/\/soundcloud.com\/edgeofsports\/chomskybowl",
        "display_url" : "soundcloud.com\/edgeofsports\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695061918868971522",
    "text" : "It's here! The latest @EdgeofSports Podcast featuring the first ever full-length sports interview with Noam Chomsky! https:\/\/t.co\/1vDw4oLllB",
    "id" : 695061918868971522,
    "created_at" : "2016-02-04 01:50:49 +0000",
    "user" : {
      "name" : "Dave Zirin",
      "screen_name" : "EdgeofSports",
      "protected" : false,
      "id_str" : "50684256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661951777890304002\/7MyavGh__normal.jpg",
      "id" : 50684256,
      "verified" : true
    }
  },
  "id" : 695991987753893889,
  "created_at" : "2016-02-06 15:26:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Starkey",
      "screen_name" : "tstarkey1212",
      "indices" : [ 0, 13 ],
      "id_str" : "533583624",
      "id" : 533583624
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 14, 26 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695929259819470849",
  "geo" : { },
  "id_str" : "695948361149587456",
  "in_reply_to_user_id" : 533583624,
  "text" : "@tstarkey1212 @DonaldClark me too also lk fwd to the AI systems which will take up negotiating with the new gen of consumer students",
  "id" : 695948361149587456,
  "in_reply_to_status_id" : 695929259819470849,
  "created_at" : "2016-02-06 12:33:14 +0000",
  "in_reply_to_screen_name" : "tstarkey1212",
  "in_reply_to_user_id_str" : "533583624",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Assange",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "unwgad",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/AKiTmP8VL5",
      "expanded_url" : "https:\/\/shar.es\/14owlp",
      "display_url" : "shar.es\/14owlp"
    } ]
  },
  "geo" : { },
  "id_str" : "695905591110275072",
  "text" : "RT @Jonathan_K_Cook: My latest: Lies about UN body threaten not just Julian Assange https:\/\/t.co\/AKiTmP8VL5 #Assange #unwgad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Assange",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "unwgad",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/AKiTmP8VL5",
        "expanded_url" : "https:\/\/shar.es\/14owlp",
        "display_url" : "shar.es\/14owlp"
      } ]
    },
    "geo" : { },
    "id_str" : "695741764947288066",
    "text" : "My latest: Lies about UN body threaten not just Julian Assange https:\/\/t.co\/AKiTmP8VL5 #Assange #unwgad",
    "id" : 695741764947288066,
    "created_at" : "2016-02-05 22:52:17 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 695905591110275072,
  "created_at" : "2016-02-06 09:43:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 43, 53 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 57, 66 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Bg0Li6rNU9",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/812-rebranding-the-conquistadors-as-social-justice-warriors-the-guardian-corporate-sponsorship-and-branded-content.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695270838405353472",
  "text" : "RT @johnwhilley: Truly damning exposure by @medialens of @guardian's crawlingly-defended 'branded content' and corporate partnerships https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 26, 36 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 40, 49 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Bg0Li6rNU9",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/812-rebranding-the-conquistadors-as-social-justice-warriors-the-guardian-corporate-sponsorship-and-branded-content.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695254728612126721",
    "text" : "Truly damning exposure by @medialens of @guardian's crawlingly-defended 'branded content' and corporate partnerships https:\/\/t.co\/Bg0Li6rNU9",
    "id" : 695254728612126721,
    "created_at" : "2016-02-04 14:36:59 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 695270838405353472,
  "created_at" : "2016-02-04 15:41:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sweetnam",
      "screen_name" : "GetIntoEnglish",
      "indices" : [ 0, 15 ],
      "id_str" : "108946483",
      "id" : 108946483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694841191507058688",
  "geo" : { },
  "id_str" : "694931980140548097",
  "in_reply_to_user_id" : 108946483,
  "text" : "@GetIntoEnglish if we agree Cleese story is not ex of \"a cultural war\" what are?",
  "id" : 694931980140548097,
  "in_reply_to_status_id" : 694841191507058688,
  "created_at" : "2016-02-03 17:14:29 +0000",
  "in_reply_to_screen_name" : "GetIntoEnglish",
  "in_reply_to_user_id_str" : "108946483",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694711094896648196",
  "geo" : { },
  "id_str" : "694785675317637121",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr hi Patricia that's great though i don't deserve any shout-outs for antconc : )",
  "id" : 694785675317637121,
  "in_reply_to_status_id" : 694711094896648196,
  "created_at" : "2016-02-03 07:33:08 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sweetnam",
      "screen_name" : "GetIntoEnglish",
      "indices" : [ 0, 15 ],
      "id_str" : "108946483",
      "id" : 108946483
    }, {
      "name" : "The Telegraph",
      "screen_name" : "Telegraph",
      "indices" : [ 16, 26 ],
      "id_str" : "16343974",
      "id" : 16343974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694637127754256384",
  "geo" : { },
  "id_str" : "694784842035257344",
  "in_reply_to_user_id" : 108946483,
  "text" : "@GetIntoEnglish @Telegraph um if u only read things like the torygraph that my well seem the case :\/",
  "id" : 694784842035257344,
  "in_reply_to_status_id" : 694637127754256384,
  "created_at" : "2016-02-03 07:29:49 +0000",
  "in_reply_to_screen_name" : "GetIntoEnglish",
  "in_reply_to_user_id_str" : "108946483",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sweetnam",
      "screen_name" : "GetIntoEnglish",
      "indices" : [ 0, 15 ],
      "id_str" : "108946483",
      "id" : 108946483
    }, {
      "name" : "The Telegraph",
      "screen_name" : "Telegraph",
      "indices" : [ 16, 26 ],
      "id_str" : "16343974",
      "id" : 16343974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694614964498239488",
  "geo" : { },
  "id_str" : "694628360392146944",
  "in_reply_to_user_id" : 108946483,
  "text" : "@GetIntoEnglish @Telegraph more likely he is just not funny (to current generation) ; )",
  "id" : 694628360392146944,
  "in_reply_to_status_id" : 694614964498239488,
  "created_at" : "2016-02-02 21:08:01 +0000",
  "in_reply_to_screen_name" : "GetIntoEnglish",
  "in_reply_to_user_id_str" : "108946483",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 41, 54 ],
      "id_str" : "19658826",
      "id" : 19658826
    }, {
      "name" : "Alison George",
      "screen_name" : "alisonge",
      "indices" : [ 59, 68 ],
      "id_str" : "21769809",
      "id" : 21769809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAP",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "tleap",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/N2glkdC03x",
      "expanded_url" : "http:\/\/ow.ly\/XQxoU",
      "display_url" : "ow.ly\/XQxoU"
    } ]
  },
  "geo" : { },
  "id_str" : "694532459082440704",
  "text" : "RT @lexicojules: More of my interview w. @newscientist ed. @alisonge about the lang of the genre &amp; if it's helpful for #EAP #tleap https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Scientist",
        "screen_name" : "newscientist",
        "indices" : [ 24, 37 ],
        "id_str" : "19658826",
        "id" : 19658826
      }, {
        "name" : "Alison George",
        "screen_name" : "alisonge",
        "indices" : [ 42, 51 ],
        "id_str" : "21769809",
        "id" : 21769809
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAP",
        "indices" : [ 106, 110 ]
      }, {
        "text" : "tleap",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/N2glkdC03x",
        "expanded_url" : "http:\/\/ow.ly\/XQxoU",
        "display_url" : "ow.ly\/XQxoU"
      } ]
    },
    "geo" : { },
    "id_str" : "694526132251660288",
    "text" : "More of my interview w. @newscientist ed. @alisonge about the lang of the genre &amp; if it's helpful for #EAP #tleap https:\/\/t.co\/N2glkdC03x",
    "id" : 694526132251660288,
    "created_at" : "2016-02-02 14:21:48 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 694532459082440704,
  "created_at" : "2016-02-02 14:46:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "C Wigham",
      "screen_name" : "Loopy63",
      "indices" : [ 10, 18 ],
      "id_str" : "55195789",
      "id" : 55195789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694523331580674048",
  "geo" : { },
  "id_str" : "694525013144268800",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @Loopy63 legume anorexia hehe : )",
  "id" : 694525013144268800,
  "in_reply_to_status_id" : 694523331580674048,
  "created_at" : "2016-02-02 14:17:21 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "thehiveelt",
      "screen_name" : "thehiveelt",
      "indices" : [ 13, 24 ],
      "id_str" : "4474734376",
      "id" : 4474734376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694492219324108800",
  "geo" : { },
  "id_str" : "694500363047665664",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @thehiveelt fyi unless u were already registered for Futurelearn CL course, u can't access materials",
  "id" : 694500363047665664,
  "in_reply_to_status_id" : 694492219324108800,
  "created_at" : "2016-02-02 12:39:24 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]