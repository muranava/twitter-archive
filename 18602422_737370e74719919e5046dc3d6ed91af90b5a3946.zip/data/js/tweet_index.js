var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2016_08.js",
  "year" : 2016,
  "var_name" : "tweets_2016_08",
  "tweet_count" : 87,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2016_07.js",
  "year" : 2016,
  "var_name" : "tweets_2016_07",
  "tweet_count" : 353,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2016_06.js",
  "year" : 2016,
  "var_name" : "tweets_2016_06",
  "tweet_count" : 278,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2016_05.js",
  "year" : 2016,
  "var_name" : "tweets_2016_05",
  "tweet_count" : 364,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2016_04.js",
  "year" : 2016,
  "var_name" : "tweets_2016_04",
  "tweet_count" : 495,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2016_03.js",
  "year" : 2016,
  "var_name" : "tweets_2016_03",
  "tweet_count" : 273,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2016_02.js",
  "year" : 2016,
  "var_name" : "tweets_2016_02",
  "tweet_count" : 334,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2016_01.js",
  "year" : 2016,
  "var_name" : "tweets_2016_01",
  "tweet_count" : 178,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2015_12.js",
  "year" : 2015,
  "var_name" : "tweets_2015_12",
  "tweet_count" : 190,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2015_11.js",
  "year" : 2015,
  "var_name" : "tweets_2015_11",
  "tweet_count" : 190,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2015_10.js",
  "year" : 2015,
  "var_name" : "tweets_2015_10",
  "tweet_count" : 195,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2015_09.js",
  "year" : 2015,
  "var_name" : "tweets_2015_09",
  "tweet_count" : 160,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2015_08.js",
  "year" : 2015,
  "var_name" : "tweets_2015_08",
  "tweet_count" : 158,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2015_07.js",
  "year" : 2015,
  "var_name" : "tweets_2015_07",
  "tweet_count" : 218,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2015_06.js",
  "year" : 2015,
  "var_name" : "tweets_2015_06",
  "tweet_count" : 209,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2015_05.js",
  "year" : 2015,
  "var_name" : "tweets_2015_05",
  "tweet_count" : 274,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2015_04.js",
  "year" : 2015,
  "var_name" : "tweets_2015_04",
  "tweet_count" : 406,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2015_03.js",
  "year" : 2015,
  "var_name" : "tweets_2015_03",
  "tweet_count" : 278,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2015_02.js",
  "year" : 2015,
  "var_name" : "tweets_2015_02",
  "tweet_count" : 214,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2015_01.js",
  "year" : 2015,
  "var_name" : "tweets_2015_01",
  "tweet_count" : 191,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2014_12.js",
  "year" : 2014,
  "var_name" : "tweets_2014_12",
  "tweet_count" : 184,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2014_11.js",
  "year" : 2014,
  "var_name" : "tweets_2014_11",
  "tweet_count" : 218,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2014_10.js",
  "year" : 2014,
  "var_name" : "tweets_2014_10",
  "tweet_count" : 251,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2014_09.js",
  "year" : 2014,
  "var_name" : "tweets_2014_09",
  "tweet_count" : 254,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2014_08.js",
  "year" : 2014,
  "var_name" : "tweets_2014_08",
  "tweet_count" : 100,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2014_07.js",
  "year" : 2014,
  "var_name" : "tweets_2014_07",
  "tweet_count" : 87,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2014_06.js",
  "year" : 2014,
  "var_name" : "tweets_2014_06",
  "tweet_count" : 159,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2014_05.js",
  "year" : 2014,
  "var_name" : "tweets_2014_05",
  "tweet_count" : 180,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2014_04.js",
  "year" : 2014,
  "var_name" : "tweets_2014_04",
  "tweet_count" : 236,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2014_03.js",
  "year" : 2014,
  "var_name" : "tweets_2014_03",
  "tweet_count" : 189,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2014_02.js",
  "year" : 2014,
  "var_name" : "tweets_2014_02",
  "tweet_count" : 214,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2014_01.js",
  "year" : 2014,
  "var_name" : "tweets_2014_01",
  "tweet_count" : 261,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2013_12.js",
  "year" : 2013,
  "var_name" : "tweets_2013_12",
  "tweet_count" : 163,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2013_11.js",
  "year" : 2013,
  "var_name" : "tweets_2013_11",
  "tweet_count" : 120,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2013_10.js",
  "year" : 2013,
  "var_name" : "tweets_2013_10",
  "tweet_count" : 228,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2013_09.js",
  "year" : 2013,
  "var_name" : "tweets_2013_09",
  "tweet_count" : 202,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2013_08.js",
  "year" : 2013,
  "var_name" : "tweets_2013_08",
  "tweet_count" : 102,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2013_07.js",
  "year" : 2013,
  "var_name" : "tweets_2013_07",
  "tweet_count" : 73,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2013_06.js",
  "year" : 2013,
  "var_name" : "tweets_2013_06",
  "tweet_count" : 193,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2013_05.js",
  "year" : 2013,
  "var_name" : "tweets_2013_05",
  "tweet_count" : 186,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2013_04.js",
  "year" : 2013,
  "var_name" : "tweets_2013_04",
  "tweet_count" : 34,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2013_03.js",
  "year" : 2013,
  "var_name" : "tweets_2013_03",
  "tweet_count" : 291,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2013_02.js",
  "year" : 2013,
  "var_name" : "tweets_2013_02",
  "tweet_count" : 184,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2013_01.js",
  "year" : 2013,
  "var_name" : "tweets_2013_01",
  "tweet_count" : 307,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2012_12.js",
  "year" : 2012,
  "var_name" : "tweets_2012_12",
  "tweet_count" : 177,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2012_11.js",
  "year" : 2012,
  "var_name" : "tweets_2012_11",
  "tweet_count" : 163,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2012_10.js",
  "year" : 2012,
  "var_name" : "tweets_2012_10",
  "tweet_count" : 74,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2012_08.js",
  "year" : 2012,
  "var_name" : "tweets_2012_08",
  "tweet_count" : 1,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2012_07.js",
  "year" : 2012,
  "var_name" : "tweets_2012_07",
  "tweet_count" : 31,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2012_06.js",
  "year" : 2012,
  "var_name" : "tweets_2012_06",
  "tweet_count" : 111,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2012_05.js",
  "year" : 2012,
  "var_name" : "tweets_2012_05",
  "tweet_count" : 135,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2012_04.js",
  "year" : 2012,
  "var_name" : "tweets_2012_04",
  "tweet_count" : 208,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2012_03.js",
  "year" : 2012,
  "var_name" : "tweets_2012_03",
  "tweet_count" : 206,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2012_02.js",
  "year" : 2012,
  "var_name" : "tweets_2012_02",
  "tweet_count" : 71,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2010_12.js",
  "year" : 2010,
  "var_name" : "tweets_2010_12",
  "tweet_count" : 3,
  "month" : 12
} ]