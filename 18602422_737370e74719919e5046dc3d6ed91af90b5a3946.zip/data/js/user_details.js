var user_details =  {
  "screen_name" : "muranava",
  "location" : "Paris, France",
  "full_name" : "Mura Nava",
  "bio" : "The Shed:https:\/\/t.co\/e8kZronG5C   Quick Cups of COCA ebook:https:\/\/t.co\/5QyzQm27Ej",
  "id" : "18602422",
  "created_at" : "2009-01-04 14:17:23 +0000"
}